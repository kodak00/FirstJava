/*-------------------------------------------------------------*/
/* �м����� (4km ����)                                         */
/*-------------------------------------------------------------*/
#define  NX_S  1080	/* S : ���� �ƽþ� ��ü ���� */
#define  NY_S  1170
#define  NX_M  1200	/* M : MM5 ���ƽþ� ���� */
#define  NY_M  1040
#define  NX_R  240	/* R : ���̴� ���� */
#define  NY_R  300
#define  NX_B  288	/* B : AWS B-map ���� */
#define  NY_B  360
#define  NX_A  144	/* A : AWS A-map ���� */
#define  NY_A  180

/*-------------------------------------------------------------*/
/* �м��������� �������� ��ġ (4km ����)                       */
/*-------------------------------------------------------------*/
#define  SX_S  480
#define  SY_S  570
#define  SX_M  655
#define  SY_M  445
#define  SX_R  80
#define  SY_R  128
#define  SX_B  125
#define  SY_B  128
#define  SX_A  14
#define  SY_A  60

#define  GMSRG_LEN  (NY_S+1)*(NX_S+1)+513
#define  GMSLC_LEN  (NY_B+1)*(NX_B+1)+515

#define  BOUNDARY_pixel  20
#define  TITLE_pixel     20
#define  TITLE_pixel2    15
#define  LEVEL_pixel     35
#define  TTL_pixel       15
#define  LVL_pixel       27
#define  LEG_pixel       8
#define  END_pixel       14

struct TIMES {
    int  Year;
    int  Month;
    int  Day;
    int  Hour;
    int  Minute;
};

struct COLOR {
    int  R;
    int  G;
    int  B;
};

struct GMSRG_FILE {
    short index[256];
    char  blank;
    char  d[NY_S+1][NX_S+1];
};

struct GMSLC_FILE {
    short index[256];
    char  blank[3];
    char  d[NY_B+1][NX_B+1];
};

struct WINDOW {
    int  width;
    int  height;
    int  border_width;
    int  background;
    int  foreground;
    int  border;
    int  shadow;
};

struct LEVEL {
    int   num;
    float itv;
    float min;
    int   color[128];
};

struct POINT {
    int x;
    int y;
};
