/*----------------------------------------------------------------------------
 * Name       : ZwoCodeUtil.c
 * Description: Zenowoo's Code Utilities
 * Version    : 1.0
 *----------------------------------------------------------------------------*/

#ifndef ZWOCODEUTIL_C
#define ZWOCODEUTIL_C



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <signal.h>			// for GetSignalStr()
#include <fcntl.h>			// for O_WRONLY
#include <stdarg.h>			// for Variable Arguments



#define true	1			// for Bool Type Variable
#define false	0



// Logging
//#ifdef ZWO_LOG
//#define ZLOG(...) if (PRINT_LOG) WriteLog(__VA_ARGS__);
//#else
//#define ZLOG(...)
//#endif
int	  PRINT_LOG			= false;	// Print Detail Log?
int   log_fd			= -1;		// File Descriptor for Log

int  KILL_BY_SIGTERM_ONLY = false;


//====[ Logging ]===============================================================

int DetermineLog(int argc, char* argv[]);
int MakeLogHeader(int argc, char* argv[]);
int WriteLog (char* msg, ...);
void CloseLog();
char* GetTimeString();
void WriteBufferLog(char* title_buffer, char* buffer, int length);
void WriteShortArrayLog(char* title_buffer, short* array, int length);


//====[ Signal ]================================================================

void PrepareSignalLogger();
void WriteSignalLog(int sig_no);


//====[ String ]================================================================

int GetDir(char* org_str, char* result_str);
int GetFileName(char* org_str, char* result_str);
int ReplaceString(char* org_str, char* rep_str, char* new_str);
char** SplitText(char* org_text, char* seperator, int to_be_count, int* count);
int SplitText1(char * s1, char * s2, char ** result )
ssize_t readn(int fd, char* ptr, size_t n);
ssize_t writen(int fd, char* ptr, size_t n);



//====[ Time ]==================================================================

int GetTime(int *YY, int *MM, int *DD, int *HH, int *MI, int *sec);
int GetTimeAddedSeconds(int *YY, int *MM, int *DD, int *HH, int *MI, int *sec, int add);
int GetCurrentSecond();
int GetCurrentMinute();


//====[ Memory ]================================================================

void ShowBuffer(char* title_buffer, char* buffer, int length);
int RemoveBuffer(char* buf, int len_buf, int pos_start, int pos_end);


//====[ Converting Code to String ]=============================================

void GetErrStr(char* msg);
void GetSignalStr(int sig_no, char* msg);

#endif
