

#define _YY_      0
#define _MM_      1
#define _DD_      2
#define _HH_      3
#define _MI_      4
#define _SS_      5
#define _CT_      9

struct st_date              /* ���ڰ���  */
{
         int   m_yy;
         int   m_mm;
         int   m_dd;
         int   m_hh;
         int   m_mi;
         int   m_ss;
};

      typedef struct _md
      {
         char yyyy[5];
         char mm[3];
         char dd[3];
         char hh[3];
         char mi[3];
         char ss[3];
      } MD;

MD m_date;


int leapYear( int  );
int getDaysInMonth( int , int  );
int toDay( int , int  );
int leapDay( int , int  );
struct st_date calcTime( int , long , struct st_date  );
int gettime( const int  );
char* UTC( int , int , int , int  );
void f_getdate(char *);
void f_gettime(char *);
void get_DateTime(char *);
struct st_date calcTimeA(int, long,  MD *);

char *f_getdateA();
char *f_gettimeA();
char *f_getdatetimeA();
