/******************************************************************
 *
 *  ���û ���̴�����Ʈ NetCDF ���� �ڷ� �б�
 *
 ******************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include <netcdf.h>
#include <hdf5.h>

#include "cgiutil.h"
#include "rdr_file_header.h"

/*=============================================================================*
 *  ���û ���̴�����Ʈ NetCDF ������ ��� ���� �б�
 *=============================================================================*/
int rdr_nc_head_dec(
  char   *fname,
  struct RDR_VOL_HEAD *rdr,
  int    disp     // 1(�쵶��� ���)
)
{
  int     status;                     // error status
  int     ncid;                       // NetCDF ID
  int     ndims;                      // number of dimensions
  int     nvars;                      // number of variables
  int     ngatts;                     // number of global attributes
  int     unlimdimid;                 // unlimited dimension ID
  int     dim_id;                     // dimension ID
  int     *dim_ids;                   // dimension ID �迭
  char    dim_name[NC_MAX_NAME+1];    // dimension name
  int     unlim_dim_id;               // ������ ����ID
  int     dim_id_var;                 // ���������� �ش��ϴ� ����ID
  int     var_id;                     // variable ID
  int     *var_ids;                   // variable ID �迭
  char    var_name[NC_MAX_NAME+1];    // variable name
  nc_type var_type;                   // variable type
  int     var_ndims;                  // number of dims
  int     var_dims[NC_MAX_VAR_DIMS];  // variables shape
  int     var_natts;                  // number of attributes
  int     att_id;                     // attribute ID
  char    att_name[NC_MAX_NAME+1];    // attribute name
  nc_type att_type;                   // attribute type
  size_t  att_len;                    // attribute length
  int     num_grp_att;                // �׷�Ӽ� ����
  char    *pt_char;                   // char pointer
  short   *pt_short;                  // short pointer
  int     *pt_int;                    // int pointer
  float   *pt_float;                  // float pointer
  double  *pt_double;                 // double pointer
  size_t  rec1, recs, lenp, max_lenp; // number of records
  static  size_t index[] = {1, 2, 3};
  char    text[120], tmp[120], *p;
  int     seq, YY, MM, DD, HH, MI, SS;
  int     code, ok;
  int     i, j, k;

  // ���Ͽ��� (�����ϸ� -1, �����ϸ� 0 ����)
  status = nc_open(fname, 0, &ncid);
  if (status != NC_NOERR) { handle_error(status); goto error1; }

  // ���浵, �ع߰���
  status = nc_inq_varid(ncid, "latitude", &var_id);
  status = nc_get_var1_double(ncid, var_id, index, &((*rdr).lat));
  (*rdr).latd = (int)((*rdr).lat);
  (*rdr).latm = (int)(60.0*((*rdr).lat - (*rdr).latd));
  (*rdr).lats = 60.0*(60.0*((*rdr).lat - (*rdr).latd) - (*rdr).latm);
  if (disp) printf("latitude  : %12.8f / %d�� %d�� %.3f��<br>\n", (*rdr).lat, (*rdr).latd, (*rdr).latm, (*rdr).lats);

  status = nc_inq_varid(ncid, "longitude", &var_id);
  status = nc_get_var1_double(ncid, var_id, index, &((*rdr).lon));
  (*rdr).lond = (int)((*rdr).lon);
  (*rdr).lonm = (int)(60.0*((*rdr).lon - (*rdr).lond));
  (*rdr).lons = 60.0*(60.0*((*rdr).lon - (*rdr).lond) - (*rdr).lonm);
  if (disp) printf("longitude : %12.8f / %d�� %d�� %.3f��<br>\n", (*rdr).lon, (*rdr).lond, (*rdr).lonm, (*rdr).lons);

  status = nc_inq_varid(ncid, "altitude", &var_id);
  status = nc_get_var1_double(ncid, var_id, index, &((*rdr).ht));
  if (disp) printf("altitude : %f m<br>\n", (*rdr).ht);

  // �������۽ð�(UTC)
  status = nc_inq_varid(ncid, "time_coverage_start", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  status = nc_inq_dim(ncid, var_dims[0], dim_name, &rec1);
  status = nc_get_var_text(ncid, var_id, (*rdr).tm_st);
  sscanf((*rdr).tm_st, "%d-%d-%dT%d:%d:%dZ", &YY, &MM, &DD, &HH, &MI, &SS);
  seq = time2seq(YY, MM, DD, HH, MI, 'm');
  seq2time(seq+9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  (*rdr).nt_st.YY = YY;
  (*rdr).nt_st.MM = MM;
  (*rdr).nt_st.DD = DD;
  (*rdr).nt_st.HH = HH;
  (*rdr).nt_st.MI = MI;
  (*rdr).nt_st.SS = SS;
  if (disp) printf("time_coverage_start : %s / %04d.%02d.%02d.%02d:%02d:%02d<br>\n", (*rdr).tm_st, YY, MM, DD, HH, MI, SS);

  // ��������ð�(UTC)
  status = nc_inq_varid(ncid, "time_coverage_end", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  status = nc_inq_dim(ncid, var_dims[0], dim_name, &rec1);
  status = nc_get_var_text(ncid, var_id, (*rdr).tm_ed);
  sscanf((*rdr).tm_ed, "%d-%d-%dT%d:%d:%dZ", &YY, &MM, &DD, &HH, &MI, &SS);
  seq = time2seq(YY, MM, DD, HH, MI, 'm');
  seq2time(seq+9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  (*rdr).nt_ed.YY = YY;
  (*rdr).nt_ed.MM = MM;
  (*rdr).nt_ed.DD = DD;
  (*rdr).nt_ed.HH = HH;
  (*rdr).nt_ed.MI = MI;
  (*rdr).nt_ed.SS = SS;
  if (disp) printf("time_coverage_end   : %s / %04d.%02d.%02d.%02d:%02d:%02d<br>\n", (*rdr).tm_ed, YY, MM, DD, HH, MI, SS);

  // radar_antenna_gain_h
  status = nc_inq_varid(ncid, "radar_antenna_gain_h", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  status = nc_inq_dim(ncid, var_dims[0], dim_name, &rec1);
  status = nc_get_var_float(ncid, var_id, &((*rdr).antenna_gain_H));
  if (disp) printf("radar_antenna_gain_h : %f<br>\n", (*rdr).antenna_gain_H);

  // radar_antenna_gain_v
  status = nc_inq_varid(ncid, "radar_antenna_gain_v", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  status = nc_inq_dim(ncid, var_dims[0], dim_name, &rec1);
  status = nc_get_var_float(ncid, var_id, &((*rdr).antenna_gain_V));
  if (disp) printf("radar_antenna_gain_v : %f<br>\n", (*rdr).antenna_gain_V);

  // radar_beam_width_h
  status = nc_inq_varid(ncid, "radar_beam_width_h", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  status = nc_inq_dim(ncid, var_dims[0], dim_name, &rec1);
  status = nc_get_var_float(ncid, var_id, &((*rdr).beam_width_H));
  if (disp) printf("radar_beam_width_h : %f<br>\n", (*rdr).beam_width_H);

  // radar_beam_width_v
  status = nc_inq_varid(ncid, "radar_beam_width_v", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  status = nc_inq_dim(ncid, var_dims[0], dim_name, &rec1);
  status = nc_get_var_float(ncid, var_id, &((*rdr).beam_width_V));
  if (disp) printf("radar_beam_width_v : %f<br>\n", (*rdr).beam_width_V);

  // radar_receiver_bandwidth
  status = nc_inq_varid(ncid, "radar_receiver_bandwidth", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  status = nc_inq_dim(ncid, var_dims[0], dim_name, &rec1);
  status = nc_get_var_float(ncid, var_id, &((*rdr).recv_band_width));
  if (disp) printf("radar_receiver_bandwidth : %f<br>\n", (*rdr).recv_band_width);

  // frequency
  status = nc_inq_varid(ncid, "frequency", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  status = nc_inq_dim(ncid, var_dims[0], dim_name, &rec1);
  status = nc_get_var_float(ncid, var_id, &((*rdr).freq));
  if (disp) printf("frequency : %f<br>\n", (*rdr).freq);

  //////////////////////////////////////////////////////////////////////////////
  //  SWEEP

  // SWEEP �� ����
  status = nc_inq_varid(ncid, "sweep_number", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  for (recs = 0, i = 0; i < ndims; i++, recs += rec1)
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);
  (*rdr).num_swp = recs;

  // SWEEP �迭 ����
  (*rdr).swp = (struct RDR_SWP_HEAD *) malloc((*rdr).num_swp * sizeof(struct RDR_SWP_HEAD));

  // SWEEP ID Ȯ��
  pt_int = (int *) malloc(recs * sizeof(int));
  status = nc_get_var_int(ncid, var_id, pt_int);
  if (disp) printf("number of sweep : %d<br>\n", (*rdr).num_swp);
  for (k = 0; k < (*rdr).num_swp; k++) {
    (*rdr).swp[k].id = pt_int[k];
    if (disp) printf("sweep_number : swp=%d, %d<br>\n", k, (*rdr).swp[k].id);
  }
  free((char*) (pt_int));

  // SWEEP�� ray start index
  status = nc_inq_varid(ncid, "sweep_start_ray_index", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  for (recs = 0, i = 0; i < ndims; i++, recs += rec1)
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);

  pt_int = (int *) malloc(recs * sizeof(int));
  status = nc_get_var_int(ncid, var_id, pt_int);
  for (k = 0; k < recs; k++) {
    (*rdr).swp[k].ray_start = pt_int[k];
    if (disp) printf("sweep_start_ray_index : swp= %d, %d<br>\n", k, (*rdr).swp[k].ray_start);
  }
  free((char*) (pt_int));

  // SWEEP�� ray end index
  status = nc_inq_varid(ncid, "sweep_end_ray_index", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  for (recs = 0, i = 0; i < ndims; i++, recs += rec1)
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);

  pt_int = (int *) malloc(recs * sizeof(int));
  status = nc_get_var_int(ncid, var_id, pt_int);
  for (k = 0; k < recs; k++) {
    (*rdr).swp[k].ray_end = pt_int[k];
    (*rdr).swp[k].num_ray = (*rdr).swp[k].ray_end - (*rdr).swp[k].ray_start + 1;
    if (disp) printf("sweep_end_ray_index : swp= %d, %d (%d)<br>\n", k, (*rdr).swp[k].ray_end, (*rdr).swp[k].num_ray);
  }
  free((char*) (pt_int));

  //////////////////////////////////////////////////////////////////////////////
  //  SWEEP + RAY

  // SWEEP�� Ray �迭 ����
  for (k = 0; k < (*rdr).num_swp; k++) {
    (*rdr).swp[k].ray = (struct RDR_RAY_HEAD *) malloc((*rdr).swp[k].num_ray * sizeof(struct RDR_RAY_HEAD));
  }

  // SWEEP�� ray_start_index
  status = nc_inq_varid(ncid, "ray_start_index", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  for (recs = 0, i = 0; i < ndims; i++, recs += rec1)
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);

  pt_int = (int *) malloc(recs * sizeof(int));
  status = nc_get_var_int(ncid, var_id, pt_int);
  for (k = 0; k < (*rdr).num_swp; k++) {
    for (j = 0, i = (*rdr).swp[k].ray_start; i <= (*rdr).swp[k].ray_end; i++, j++)
      (*rdr).swp[k].ray[j].ray1 = pt_int[i];

    (*rdr).swp[k].ray1 = (*rdr).swp[k].ray[0].ray1;
    if (disp) printf("ray_start_index : swp=%d, %d<br>\n", k, (*rdr).swp[k].ray1);
  }
  free((char*) (pt_int));

  // SWEEP+RAY�� ������
  status = nc_inq_varid(ncid, "azimuth", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  for (recs = 0, i = 0; i < ndims; i++, recs += rec1)
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);

  pt_float = (float *) malloc(recs * sizeof(float));
  status = nc_get_var_float(ncid, var_id, pt_float);
  for (k = 0; k < (*rdr).num_swp; k++) {
    for (j = 0, i = (*rdr).swp[k].ray_start; i <= (*rdr).swp[k].ray_end; i++, j++)
      (*rdr).swp[k].ray[j].az = pt_float[i];
  }
  free((char*) (pt_float));

  // SWEEP�� ������
  status = nc_inq_varid(ncid, "elevation", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  for (recs = 0, i = 0; i < ndims; i++, recs += rec1)
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);

  pt_float = (float *) malloc(recs * sizeof(float));
  status = nc_get_var_float(ncid, var_id, pt_float);
  for (k = 0; k < (*rdr).num_swp; k++) {
    i = (recs/(*rdr).num_swp)*k + recs/(*rdr).num_swp/2;
    (*rdr).swp[k].elev = pt_float[i];
    if (disp) printf("elevation : swp=%d, %f degree<br>\n", k, (*rdr).swp[k].elev);

    for (j = 0, i = (*rdr).swp[k].ray_start; i <= (*rdr).swp[k].ray_end; i++, j++)
      (*rdr).swp[k].ray[j].elev = pt_float[i];
  }
  free((char*) (pt_float));

  // SWEEP�� radar_measured_transmit_power_h
  status = nc_inq_varid(ncid, "radar_measured_transmit_power_h", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  for (recs = 0, i = 0; i < ndims; i++, recs += rec1)
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);

  pt_float = (float *) malloc(recs * sizeof(float));
  status = nc_get_var_float(ncid, var_id, pt_float);
  for (k = 0; k < (*rdr).num_swp; k++) {
    i = (recs/(*rdr).num_swp)*k + recs/(*rdr).num_swp/2;
    (*rdr).swp[k].power_H = pt_float[i];
    if (disp) printf("radar_measured_transmit_power_h : swp=%d, %f<br>\n", k, (*rdr).swp[k].power_H);

    for (j = 0, i = (*rdr).swp[k].ray_start; i <= (*rdr).swp[k].ray_end; i++, j++)
      (*rdr).swp[k].ray[j].power_H = pt_float[i];
  }
  free((char*) (pt_float));

  // SWEEP�� radar_measured_transmit_power_v
  status = nc_inq_varid(ncid, "radar_measured_transmit_power_v", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  for (recs = 0, i = 0; i < ndims; i++, recs += rec1)
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);

  pt_float = (float *) malloc(recs * sizeof(float));
  status = nc_get_var_float(ncid, var_id, pt_float);
  for (k = 0; k < (*rdr).num_swp; k++) {
    i = (recs/(*rdr).num_swp)*k + recs/(*rdr).num_swp/2;
    (*rdr).swp[k].power_V = pt_float[i];
    if (disp) printf("radar_measured_transmit_power_v : swp=%d, %f<br>\n", k, (*rdr).swp[k].power_V);

    for (j = 0, i = (*rdr).swp[k].ray_start; i <= (*rdr).swp[k].ray_end; i++, j++)
      (*rdr).swp[k].ray[j].power_V = pt_float[i];
  }
  free((char*) (pt_float));

  // SWEEP�� pulse_width
  status = nc_inq_varid(ncid, "pulse_width", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  for (recs = 0, i = 0; i < ndims; i++, recs += rec1)
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);

  pt_float = (float *) malloc(recs * sizeof(float));
  status = nc_get_var_float(ncid, var_id, pt_float);
  for (k = 0; k < (*rdr).num_swp; k++) {
    i = (recs/(*rdr).num_swp)*k + recs/(*rdr).num_swp/2;
    if (pt_float[i] < 0.001)
      (*rdr).swp[k].pulse_width = pt_float[i]*1000000;
    else
      (*rdr).swp[k].pulse_width = pt_float[i];
    if (disp) printf("pulse_width : swp=%d, %f<br>\n", k, (*rdr).swp[k].pulse_width);

    for (j = 0, i = (*rdr).swp[k].ray_start; i <= (*rdr).swp[k].ray_end; i++, j++)
      (*rdr).swp[k].ray[j].pulse_width = pt_float[i]*1000000;
  }
  free((char*) (pt_float));

  // SWEEP�� pulse repetition time
  status = nc_inq_varid(ncid, "prt", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  for (recs = 0, i = 0; i < ndims; i++, recs += rec1)
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);

  pt_float = (float *) malloc(recs * sizeof(float));
  status = nc_get_var_float(ncid, var_id, pt_float);
  for (k = 0; k < (*rdr).num_swp; k++) {
    i = (recs/(*rdr).num_swp)*k + recs/(*rdr).num_swp/2;
    (*rdr).swp[k].prt = pt_float[i]*1000;
    if (disp) printf("prt : swp=%d, %f<br>\n", k, (*rdr).swp[k].prt);

    for (j = 0, i = (*rdr).swp[k].ray_start; i <= (*rdr).swp[k].ray_end; i++, j++)
      (*rdr).swp[k].ray[j].prt = pt_float[i]*1000;
  }
  free((char*) (pt_float));

  // SWEEP�� multiple pulse repetition time
  status = nc_inq_varid(ncid, "prt_ratio", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  for (recs = 0, i = 0; i < ndims; i++, recs += rec1)
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);

  pt_float = (float *) malloc(recs * sizeof(float));
  status = nc_get_var_float(ncid, var_id, pt_float);
  for (k = 0; k < (*rdr).num_swp; k++) {
    i = (recs/(*rdr).num_swp)*k + recs/(*rdr).num_swp/2;
    (*rdr).swp[k].prt_ratio = pt_float[i];
    if (disp) printf("prt_ratio : swp=%d, %f<br>\n", k, (*rdr).swp[k].prt_ratio);

    for (j = 0, i = (*rdr).swp[k].ray_start; i <= (*rdr).swp[k].ray_end; i++, j++)
      (*rdr).swp[k].ray[j].prt_ratio = pt_float[i];
  }
  free((char*) (pt_float));

  // SWEEP�� Nyq_Vel
  status = nc_inq_varid(ncid, "nyquist_velocity", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  for (recs = 0, i = 0; i < ndims; i++, recs += rec1)
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);

  pt_float = (float *) malloc(recs * sizeof(float));
  status = nc_get_var_float(ncid, var_id, pt_float);
  for (k = 0; k < (*rdr).num_swp; k++) {
    i = (recs/(*rdr).num_swp)*k + recs/(*rdr).num_swp/2;
    (*rdr).swp[k].nyq_vel = pt_float[i];
    if (disp) printf("nyquist_velocity : swp=%d, %f<br>\n", k, (*rdr).swp[k].nyq_vel);

    for (j = 0, i = (*rdr).swp[k].ray_start; i <= (*rdr).swp[k].ray_end; i++, j++)
      (*rdr).swp[k].ray[j].nyq_vel = pt_float[i];
  }
  free((char*) (pt_float));

  // SWEEP�� ���ü�
  status = nc_inq_varid(ncid, "n_samples", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  for (recs = 0, i = 0; i < ndims; i++, recs += rec1)
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);

  pt_int = (int *) malloc(recs * sizeof(int));
  status = nc_get_var_int(ncid, var_id, pt_int);
  for (k = 0; k < (*rdr).num_swp; k++) {
    i = (recs/(*rdr).num_swp)*k + recs/(*rdr).num_swp/2;
    (*rdr).swp[k].nsamples = pt_int[i];
    if (disp) printf("n_samples : swp=%d, %d<br>\n", k, (*rdr).swp[k].nsamples);

    for (j = 0, i = (*rdr).swp[k].ray_start; i <= (*rdr).swp[k].ray_end; i++, j++)
      (*rdr).swp[k].ray[j].nsamples = pt_int[i];
  }
  free((char*) (pt_int));

  // SWEEP�� Ray�� bin��
  status = nc_inq_varid(ncid, "ray_n_gates", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  for (recs = 0, i = 0; i < ndims; i++, recs += rec1)
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);

  pt_int = (int *) malloc(recs * sizeof(int));
  status = nc_get_var_int(ncid, var_id, pt_int);
  for (k = 0; k < (*rdr).num_swp; k++) {
    i = (recs/(*rdr).num_swp)*k + recs/(*rdr).num_swp/2;
    (*rdr).swp[k].num_gate = pt_int[i];
    if (disp) printf("ray_n_gates : swp=%d, %d<br>\n", k, (*rdr).swp[k].num_gate);

    for (j = 0, i = (*rdr).swp[k].ray_start; i <= (*rdr).swp[k].ray_end; i++, j++)
      (*rdr).swp[k].ray[j].num_gate = pt_int[i];
  }
  free((char*) (pt_int));

  // SWEEP�� �ּ�bin�Ÿ�, ���binũ��
  status = nc_inq_varid(ncid, "range", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  for (recs = 0, i = 0; i < ndims; i++, recs += rec1)
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);

  pt_float = (float *) malloc(recs * sizeof(float));
  status = nc_get_var_float(ncid, var_id, pt_float);
  for (k = 0; k < (*rdr).num_swp; k++) {
    (*rdr).swp[k].gate1 = pt_float[0]*2;    // nc�� �� bin�� �߰���, uf�� �����̶� uf�� ���߾� �����Ͽ���
    (*rdr).swp[k].gate_size = pt_float[1]-pt_float[0];
    if (disp) printf("range : swp=%d, gate1=%f, gate_size=%f<br>\n", k, (*rdr).swp[k].gate1, (*rdr).swp[k].gate_size);
  }
  free((char*) (pt_float));

  //////////////////////////////////////////////////////////////////////////////
  //  ��������

  // ���������� �ش��ϴ� ����ID ã�� (���� ���ڵ���� �� ������ ����.��)
  status = nc_inq(ncid, &ndims, &nvars, &num_grp_att, &unlim_dim_id);
  if (status != NC_NOERR) handle_error(status);
  if (disp) printf("nc_inq : ndims = %d, nvars = %d, num_grp_att = %d, unlim_dim_id = %d<br>\n", ndims, nvars, num_grp_att, unlim_dim_id);

  dim_ids = (int *) malloc(sizeof(int) * ndims);
  status = nc_inq_dimids(ncid, &ndims, dim_ids, 0);
  for (max_lenp = 0, i = 0; i < ndims; i++) {
    status = nc_inq_dim(ncid, dim_ids[i], dim_name, &lenp);
    if (disp) printf("dim : i = %d, %d, %s, %d<br>\n", i, dim_ids[i], dim_name, lenp);
    if (max_lenp < lenp) {
      max_lenp = lenp;
      dim_id_var = dim_ids[i];
    }
  }
  if (disp) printf("dim_id_var = %d<br>\n", dim_id_var);
  free((char*) (dim_ids));

  // �迭ũ�� ������ ���Ͽ� ������ �߿��� ���������� ���� ã�� (����ID�� dim_id_var�� ������)
  var_ids = (int *) malloc(sizeof(int) * nvars);
  nc_inq_varids(ncid, &nvars, var_ids);
  for ((*rdr).num_var = 0, i = 0; i < nvars; i++) {
    status = nc_inq_var(ncid, var_ids[i], var_name, &var_type, &var_ndims, var_dims, &var_natts);
    for (j = 0; j < var_ndims; j++) {
      if (disp) printf("i = %d, var_id = %d / j = %d, var_dim = %d (%d)<br>\n", i, var_ids[i], j, var_dims[j], var_ndims);
      if (var_dims[j] == dim_id_var) {
        (*rdr).num_var += 1;
        //break;
      }
    }
  }

  // �������� �迭 ����
  (*rdr).var = (struct RDR_VAR_HEAD *) malloc((*rdr).num_var * sizeof(struct RDR_VAR_HEAD));

  // �������� �Ӽ� �б�
  for (k = 0, i = 0; i < nvars; i++) {
    status = nc_inq_var(ncid, var_ids[i], var_name, &var_type, &var_ndims, var_dims, &var_natts);
    for (ok = 0, j = 0; j < var_ndims; j++) {
      if (var_dims[j] == dim_id_var) {
        ok = 1;
        break;
      }
    }
    if (ok != 1) continue;

    (*rdr).var[k].var_id = var_ids[i];
    strcpy((*rdr).var[k].var_cd, var_name);
    for (j = 0; j < var_natts; j++) {
      status = nc_inq_attname(ncid, var_ids[i], j, att_name);
      if (strstr(att_name,"long_name")) status = nc_get_att_text(ncid, var_ids[i], att_name, (*rdr).var[k].var_name);
      else if (strstr(att_name,"_FillValue")) status = nc_get_att_short(ncid, var_ids[i], att_name, &((*rdr).var[k].blank));
      else if (strstr(att_name,"scale_factor")) status = nc_get_att_float(ncid, var_ids[i], att_name, &((*rdr).var[k].scale));
      else if (strstr(att_name,"add_offset")) status = nc_get_att_float(ncid, var_ids[i], att_name, &((*rdr).var[k].add));
    }
    if (disp) printf("var : %d, %s, blank=%d, scale=%f, add=%f, name=%s<br>\n",
                     (*rdr).var[k].var_id, (*rdr).var[k].var_cd, (*rdr).var[k].blank, (*rdr).var[k].scale, (*rdr).var[k].add, (*rdr).var[k].var_name);
    k++;
    if (k >= (*rdr).num_var) break;
  }
  free((char*) (var_ids));

/*
  status = nc_inq_varid(ncid, "UH", &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);
  printf("var_id = %d<br>\n", var_id);
  for (recs = 0, i = 0; i < ndims; i++) {
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);
    recs += rec1;
    printf("ndims=%d, i=%d, %d, rec1=%d, recs=%d, %s<br>\n", ndims, i, var_dims[i], rec1, recs, dim_name);
  }
  pt_short = (short *) malloc(recs * sizeof(short));
  status = nc_get_var_short(ncid, var_id, pt_short);
  for (i = 0; i < 360; i++) {
    printf("i = %d, %d<br>\n", i, pt_short[i]);
  }
  free((char*) (pt_short));
*/

error1:
  status = nc_close(ncid);
  if (status != NC_NOERR) handle_error(status);

  return 0;
}

/*=============================================================================*
 *  ���û ���̴�����Ʈ NetCDF ������ 1�� Sweep �ڷ� �б�
 *=============================================================================*/
 /*
int rdr_nc_swp_dec(
  char   *fname,            // ���ϸ�
  struct RDR_VOL_HEAD rdr,  // �������
  int    var_id,    // ����ID (���Ͽ� �����)
  int    swpn,      // Sweep��ȣ
  short  **ray      // ���
)
{
  static  int ncid;   // NetCDF ID
  int     status;
  int     first = 0;
  size_t  ray1[] = {rdr.swp[swpn].ray[0].ray1};
  size_t  num_gate[] = {rdr.swp[swpn].num_gate*rdr.swp[swpn].num_ray};

  // ���Ͽ��� (�����ϸ� -1, �����ϸ� 0 ����)
  if (first == 0) {
    status = nc_open(fname, 0, &ncid);
    if (status != NC_NOERR) return -1;
    first = 1;
  }

  // 1�� ray �б�
  status = nc_get_vara_short(ncid, var_id, ray1, num_gate, ray);
  if (status != NC_NOERR) handle_error(status);

  return 0;
}
*/

/*=============================================================================*
 *  ���û ���̴�����Ʈ NetCDF ������ 1�� Ray �ڷ� �б�
 *=============================================================================*/
int rdr_nc_ray_dec(
  char   *fname,            // ���ϸ�
  struct RDR_VOL_HEAD rdr,  // �������
  int    var_id,    // ����ID (���Ͽ� �����)
  int    swpn,      // Sweep��ȣ
  int    rayn,      // Ray��ȣ
  short  *ray       // ���
)
{
  static  int ncid;   // NetCDF ID
  int     status;
  int     first = 0;
  size_t  ray1[] = {rdr.swp[swpn].ray[rayn].ray1};
  size_t  num_gate[] = {rdr.swp[swpn].ray[rayn].num_gate};

  // ���Ͽ��� (�����ϸ� -1, �����ϸ� 0 ����)
  if (first == 0) {
    status = nc_open(fname, 0, &ncid);
    if (status != NC_NOERR) return -1;
    first = 1;
  }

  // 1�� ray �б�
  status = nc_get_vara_short(ncid, var_id, ray1, num_gate, ray);
  if (status != NC_NOERR) handle_error(status);

  return 0;
}

/*=============================================================================*
 *  NetCDF ���� ó���� ����ó��
 *=============================================================================*/
int handle_error(int status)
{
  if (status != NC_NOERR) {
    fprintf(stderr, "%s\n", nc_strerror(status));
    return -1;
  }
  return 0;
}
