/*
           editor : �����й� ������
           edit date : 2006.09.14
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>

#include "stringprocess.h"
//int white_cvt(char *, char *);

int isdigitA(char *snumber, int *num)
{
     int i=0, nlen=0;

     if(snumber == 0x00) return -1;
     nlen = strlen(snumber);

     for(i=0; i<nlen; i++)
     {
          if(isdigit(*(snumber+i)) == 0) return -3;
     }

     *num = atoi(snumber);

     return nlen;
}

int f_getfilesize(char *fname)
{
     int nsize=0;
     struct stat st;

     if(fname == 0x00) return -1;

     if( lstat(fname, &st)) return -2;
     else nsize = st.st_size;

     return nsize;
}

char *f_getprivatestring(char *strfilename, char *strfirst, char *strsecond)
{
        FILE *fp;
        char *strtemp, str1line[1024], strret[128], *p, *token;
        int nstart = 0, npoint = 0;

        fp=fopen(strfilename, "r");
        if(fp == CNULL) return CNULL;

        memset(strret, CNULL, sizeof(strret));

        while(!feof(fp))
        {
                fgets(str1line, 1024, fp);

                strtemp = f_strlefttrim(str1line);
                if(*strtemp == LEFTPAREN)
                {
                     if(nstart == -1) break;
                     nstart++;
                     strtemp = strtemp + 1;
                     strtemp = f_strlefttrim(strtemp);

                     if(strncmp(strtemp, strfirst, strlen(strfirst)) == 0)
                     {
                          strtemp = strtemp + strlen(strfirst);
                          strtemp = f_strlefttrim(strtemp);
                          if(*strtemp == RIGHTPAREN)
                              nstart = -1;
                          else
                              nstart = 0;
                     }
                     else
                         nstart = 0;
                }
                else
                    {
                        if(nstart == -1)
                        {
                             if(strncmp(strtemp, strsecond, strlen(strsecond)) == 0)
                             {
                                   strtemp = strtemp + strlen(strsecond);

                                   strtemp = f_strlefttrim(strtemp);
                                   if(*strtemp == INIDELI)
                                   {
                                         strtemp = strtemp + 1;
                                         strcpy(strret, f_strtrim(strtemp));
                                         break;
                                   }
                             }
                        }
                    }
        }
        fclose(fp);

        p = (char *)malloc( strlen( strret ) );
        strcpy( p, strret );

        return p;

}


char *f_getprivatestringA(char *strfilename, char *strsecond)
{
        FILE *fp;
        char *strtemp, str1line[1024], *token, strret[128], *p;
        int nstart = 0, npoint = 0;

        fp=fopen(strfilename, "r");
        if(fp == CNULL) return CNULL;

        memset(strret, CNULL, sizeof(strret));

        while(!feof(fp))
        {
                fgets(str1line, 1024, fp);

                strtemp = f_strlefttrim(str1line);
                             if(strncmp(strtemp, strsecond, strlen(strsecond)) == 0)
                             {
                                   strtemp = strtemp + strlen(strsecond);
                                   strtemp = f_strlefttrim(strtemp);
                                   if(*strtemp == INIDELI)
                                   {
                                         strtemp = strtemp + 1;
                                         strcpy(strret, f_strtrim(strtemp));
                                         break;
                                   }
                             }
        }
        fclose(fp);

        p = (char *)malloc( strlen( strret ) );
        strcpy( p, strret );

        return p;

}



/*
     function name : char *f_strreplace(char *strparam1, char *strparam2, char *strparam3)
     ���ڿ� strsrc�� strsearch�� ������ strdest�� ��ü�Ѵ�.
 */


char *f_strreplace(char strsrc[], char *strsearch, char *strdest)
{
       int num=0, ncount=0, index=0, nstart=0;
       char *p;
 
       if(strsrc[0] == 0x00) return CNULL;
       if(strsearch == 0x00) return CNULL;
       if(strdest == 0x00) return CNULL;

       int nlength1 = strlen(strsrc);
       int nlength2 = strlen(strsearch);
       int nlength3 = strlen(strdest);

       ncount = f_instrnum( strsrc, strsearch, 0);
       num = nlength1 + ncount * (nlength3 - nlength2);

       char stemp[num];
     
       nstart = 0; 
       ncount = 0;
       index=0; 
       while(index<nlength1)
       { 
            if(strncmp(strsrc+index, strsearch, nlength2)) 
            {
                 stemp[ncount++] = strsrc[index];
            }
            else
            {
                 strcat(stemp, strdest);
                 ncount = strlen(stemp);
                 index += nlength2-1;
            }
            index++;
            stemp[ncount] = CNULL;
       }
   
       p = (char *)malloc( strlen( stemp ) );
       strcpy( p, stemp );
   
       return p;
}

/*
     function name : char *strright(char * strparam, int index)
     ���ڿ� strparam�� �����ʿ��� index���̸�ŭ �ڸ���.
*/
char *f_strright(char *strparam, int index)
{
       char *p;

       if(strparam == 0x00) return CNULL;
       if(index <= 0) return CNULL;
       if(strlen(strparam) < index) return strparam;
       else
       {
             int nlength = strlen(strparam);

             p = (char *)malloc(index);
             strncpy( p, (strparam+nlength-index), index);
             *(p+index) = CNULL;
       }
       return p; 
}

/*
     function name : char *strleft(char * strparam, int index)
     ���ڿ� strparam�� ���ʿ��� index���̸�ŭ �ڸ���.
*/
char *f_strleft(char *strparam, int index)
{
       int i=0;
       char *p;

       if(strparam == 0x00) return CNULL;
       if(index <= 0) return CNULL;
       if(strlen(strparam) < index) return strparam;
       else
       {
             p = (char *)malloc(index);
             strncpy( p, strparam, index);
             *(p+index) = CNULL;
       }
      
       return p;
}


/*
     function name : char *strtrim(char * strparam)
     ���ڿ� strparam�� �հ� �ڿ��� �����̽��� ���� ���ش�.
*/
char *f_strtrim(char *strparam)
{
       char *strtemp;

       (char *)strtemp = (char *)strparam;

       strtemp = f_strrighttrim(strtemp);
       strtemp = f_strlefttrim(strtemp);

       return strtemp;
}

/*
     function name : char *strrighttrim(char *strparam)
     ���ڿ� strparam�� �ڿ��� �����̽��� ���� ���ش�.
*/
char *f_strrighttrim(char *strparam)
{
	char *strtemp = CNULL;
        int index=0, nlength=0;
        
        (char *)strtemp = (char *)strparam;
        if(strtemp == 0x00) return CNULL;
 
        nlength = strlen(strparam);
       
        for(index=nlength-1; index>0; index--)
        {
               
              if(strncmp(strtemp+index, " ", 1) == 0)
              {
                  *(strtemp+index) = CNULL;
                  continue;
              }
	      else if(WHITE_SPACE == *(strtemp+index) || TAB == *(strtemp+index) ||  ENTER == *(strtemp+index))
              {
                  *(strtemp+index) = CNULL;
                  continue;
              }
/*
              else if( ENTER == *(strtemp+index))
              {
                  *(strtemp+index) = CNULL;
                  break;
              }
*/
              else
              {
                  *(strtemp+index+1) = CNULL;
                  break;
              }
        }
        
        return strtemp;
}

/*
     function name : char *strlefttrim(char *strparam)
     ���ڿ� strparam�� �տ��� �����̽��� ���� ���ش�.
*/
char *f_strlefttrim(char *strparam)
{
	char *strtemp = CNULL;
        int index=0, nlength=0;
       
        (char *)strtemp = (char *)strparam; 
        if(strtemp == 0x00) return CNULL;
        nlength = strlen(strtemp);
        
        for(index=0; index<nlength; index++)
        {
	      if(WHITE_SPACE == *(strtemp+index) || TAB == *(strtemp+index) || ENTER == *(strtemp+index))
              {
                    continue;
              }
              else if(strncmp(strtemp+index, " ", 1) == 0)
              {
                  continue;
              }
              else
              {
                  strtemp = strparam+index;
                  break;
              }
        }
        
        return strtemp;
}

char* substr( char *src, int s, int e )
{
   char  buf[1024], *p;
   int   i, len = strlen( src );

   *buf = '\0';

   for( i=0; i < e && e < len; i++ )
      buf[i] = src[s+i];
   buf[i] = '\0';

   p = (char *)malloc( strlen( buf ) );
   strcpy( p, buf );

   return p;
}

int f_instrnum( char *src, char *tgt, int nstart)
{
   char  strtemp[MAX_BUF30];
   int   i=0, slen=0, tlen=0, nret=0;

   if(src == 0x00 || tgt == 0x00 || nstart < 0 ) return -1;

   slen = strlen( src );
   tlen = strlen( tgt );
   if(slen < tlen+nstart) return -2;

   strcpy(strtemp, src);

   for( i=nstart; i < slen; i++ )
       if(!strncmp(strtemp+i, tgt, tlen)) nret++;
   return nret;
}

int f_instr( char *src, char *tgt, int nstart)
{
   //char  strtemp[MAX_BUF30];
   char  strtemp[100000];
   int   i=0, slen=0, tlen=0;

   if(src == 0x00 || tgt == 0x00 || nstart < 0 ) return -1;

   slen = strlen( src );
   tlen = strlen( tgt );
   if(slen < tlen+nstart) return -2;

   strcpy(strtemp, src);

   for( i=nstart; i < slen; i++ )
       if(!strncmp(strtemp+i, tgt, tlen)) return i;
   return -3;
}

/*
* src : source string
*   s : start point
*  nn : length
*/
char * f_substr( char *src, int s, int nn )
{
   char  strtemp[MAX_BUF30], *p;
   int   i=0, len=0;

   memset(strtemp, 0x00, sizeof(strtemp));

   if(src == 0x00 || nn <= 0) return CNULL;

   len = strlen( src );
   if((s+nn) > len) return CNULL;

   for( i=0; i < nn; i++ )
      strtemp[i] = src[s+i];

   strtemp[i] = '\0';

   p = (char *)malloc( strlen( strtemp ) );
   strcpy( p, strtemp );

   return p;
}

char * subrstr( char *src, int s, int e )
{
   char  buf[1024], *p;
   int   i, len = strlen( src );

   *buf = '\0';

   s = len - e;
   for( i=0; i < e && e < len; i++ )
      buf[i] = src[s+i];

   buf[i] = '\0';

   p = (char *)malloc( strlen( buf ) );
   strcpy( p, buf );

   return p;
}

char* trim( char *src )
{
   int len = strlen( src );

   if( len <= 0 ) return "";

   char *p = src;

   while( *p == ' ' || *p == '\t' || *p == '\r' || *p == '\n' ) p++;

   char *t = &(src[len]);

   while( *t == ' ' || *t == '\t' || *t == '\r' || *t == '\n' || *t == '\0' ) t--;

   *(++t) = '\0';

   return p;
}

char* replace( char *src, int s, int t )
{
   int len = strlen( src );

   if( len <= 0 ) return "";

   char *p = src;

   while( *p != '\0' )
   {
      if( *p == s ) *p = t;
      p++;
   }
   return src;
}

/*
      src�� ���ڸ� ������ ���� ������ ���� �� ������ 0
*/
int f_strdgtchk(char* src)
{
      int i,j=0;

      if(src == 0x00) return -1;

      for(i=0; i < (int)strlen(src); i++)
	  if( isdigit(*(src+i))) j++;
          else return 0;
			  
      return j;
}

/*
     SRC�� ���� ����
*/
int f_strdgtnum(char* src)
{
      int i,j=0;

      if(src == 0x00) return -1;

      for(i=0; i < (int)strlen(src); i++)
          if( isdigit( *(src+i) ) )
                 j++;

      return j;
}

/*
int main()
{
        char strsrc[10000];
        char *strsearch;
        char *strdest;
        char strCR[2];
        char *strtemp;
        strcpy(strsrc, "2006621133|0.0|3.4|0.0|0.0|0.0|3.4|19.5|19.4|19.7|21.8|20.7|21.8|21.8|20.9|21.8|19.3|19.2|19.5|0.0|10.2|0.0|0.0|11.0|0.0|0.0|94.0|93.0|95.0|18.8|18.5|19.1|66.9|66.7|67.3|1008.3|1007.6|1009.5|1011.8|1011.1|1013.0||||0.0|12.2|43809.0$$2006621132|1.7|2.3|68.4|63.3|1.7|2.3|19.5|19.4|19.7|21.7|20.7|21.8|21.8|20.9|21.8|18.3|18.2|18.5|0.0|10.2|0.0|0.0|11.0|0.0|10.0|94.0|93.0|95.0|18.8|18.5|19.1|66.9|66.7|67.3|1008.3|1007.6|1009.5|1011.8|1011.1|1013.0||||0.0|12.2|43801.0$$2006621131|1.2|2.1|61.4|73.5|1.2|2.1|19.5|19.4|19.7|21.7|20.7|21.8|21.8|20.9|21.8|19.3|19.3|19.6|0.0|10.2|0.0|0.0|11.0|0.0|10.0|94.0|93.0|95.0|18.8|18.5|19.1|66.9|66.7|67.3|1008.3|1007.6|1009.5|1011.8|1011.1|1013.0||||60.0|12.1|43715.0$$2006621130|2.2|2.6|79.3|73.3|2.2|2.6|19.5|19.4|19.7|21.7|20.7|21.8|21.7|20.9|21.7|17.4|17.3|17.7|0.0|10.2|0.0|0.5|11.0|0.0|10.0|95.0|93.0|95.0|18.8|18.5|19.1|66.9|66.7|67.3|1008.3|1007.6|1009.5|1011.8|1011.1|1013.0||||60.0|12.1|43655.0$$");
        strcpy(strsrc, "2006621133|0.0|3.4|0.0|0.0|0.0|3.4|19.5");
        printf("strsrc:%s:", strsrc);
        printf("f_strdgtchk(char* src):%d:\n", f_strdgtchk(strsrc));
        printf("f_strdgtnum(char* src):%d:\n", f_strdgtnum(strsrc));

        strcpy(strsrc, "200 6621 133|0. 0|3.4|	0.0|0.0|0.0|3.4|19.5");
        printf("strsrc:%s:", strsrc);
//        printf("white_cvt(char *c,char *txt):%d:%s:\n", white_cvt(strsrc, strdest), strdest);      
         strCR[0] = '\n'; strCR[1] = CNULL;
         strdest = strCR;
         strdest = "";
         printf("dest:%s:\n", strdest);
         strsearch =  "33";
         printf(":%s:\n\n", strsrc); 
        (char *)strtemp = f_strreplace(strsrc, strsearch, strdest);
         printf(":%s:\n", strtemp); 

        strcpy(strsrc, "2006621133|0.0|3.4|0.0|0.0|0.0|3.4|19.5");
        printf("f_strleft:%s:\n", f_strleft(strsrc, 7));
        printf("f_strright:%s:\n", f_strright(strsrc, 5));
}
*/

