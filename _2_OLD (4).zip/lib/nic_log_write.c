/******************************************************************************
 *
 *  Nic Log Write Sub Program
 *
 ******************************************************************************/
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/file.h>
#include <sys/errno.h>
#include "comn.h"

#define  LOG_DIR  "/LOGD/NIC"

int nic_log_write(char *nic, int num, struct FILE_OUT ft)
{
    FILE  *fg;
    char  ipc_time[19],trn_time[19],trn_ymd[8];
    char  fname[120], nic_log_name[60], buf[160];
    int  YY, MM, DD, HH, MI, SS, n, code;
    struct tm  *now;
    struct NIC_LOG_BUF nlb;
    struct stat    st;
    
    memset(fname, 0x00, sizeof(fname));    
    strncpy(fname, ft.fname,sizeof(fname));
    lstat(fname, &st);
    
    now  = localtime( &ft.tm );
    YY  = ( now -> tm_year ) + 1900;
    MM = ( now -> tm_mon  ) + 1;
    DD = now -> tm_mday;
    HH = now -> tm_hour;
    MI = now -> tm_min;
    SS = now -> tm_sec; 
    sprintf(ipc_time,"%04d.%02d.%02d.%02d:%02d:%02d",YY, MM, DD, HH, MI, SS);
    
    now  = localtime( &ft.tm_out );
    YY  = ( now -> tm_year ) + 1900;
    MM = ( now -> tm_mon  ) + 1;
    DD = now -> tm_mday;
    HH = now -> tm_hour;
    MI = now -> tm_min;
    SS = now -> tm_sec; 
    sprintf(trn_time,"%04d.%02d.%02d.%02d:%02d:%02d",YY, MM, DD, HH, MI, SS);
    sprintf(trn_ymd,"%04d%02d%02d",YY, MM, DD);
        
    memset(nic_log_name, 0x00, sizeof(nic_log_name));    
    sprintf(nic_log_name,"%s/%s_%s.log", LOG_DIR, nic, trn_ymd);
    
    if ( ( fg = fopen(nic_log_name, "a") ) == (FILE *)NULL )
    {
    	printf( "[%s] NIC_YMD ���� OPEN ����!=>[%d]\n", nic_log_name, errno );
        return -9;
    }

    strcpy(nlb.ipc_time, ipc_time);    
     
    memset(buf, 0x00, sizeof(buf));
    sprintf(buf,"%8d", ft.seq);
    strcpy(nlb.seq, buf); 
    
    strcpy(nlb.trn_time, trn_time);
 
    memset(buf, 0x00, sizeof(buf));
    sprintf(buf,"%2d", num);
    strcpy(nlb.num, buf); 
    
    memset(buf, 0x00, sizeof(buf));
    sprintf(buf,"%-120s", fname);
    strcpy(nlb.fname, buf);
    
    memset(buf, 0x00, sizeof(buf));
    sprintf(buf,"%11d", st.st_size);
    strcpy(nlb.size, buf);
    
    nlb.fl_1 = nlb.fl_2 = nlb.fl_3 = nlb.fl_4 = nlb.fl_5 = nlb.fl_6 = '|';
    nlb.dummy = '\n';
    
    n = fwrite(&nlb, 1, sizeof(nlb), fg);
    if (n <= 0) return -3;
        
    fclose( fg );
    chmod ( nic_log_name, 0666 );
    
    return 0;
}
