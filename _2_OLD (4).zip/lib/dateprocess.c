#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "dateprocess.h"

/*
*/

#ifndef _INC_CDATE_
#define _INC_CDATE_

/******************************************************************
*
*  �ð������� ���� �Ϸù�ȣ�� ��ȯ
*
*    o YY,MM,DD,HH,MI  : ��,��,��,��,��
*    o mode            : ��ȯ�� ����
*         . mode = 'd' : 1900. 1. 1.       ���� �ϼ�
*         . mode = 'h' : 1900. 1. 1. 00    ���� �ð���
*         . mode = 'm' : 1900. 1. 1. 00:00 ���� �м�
*
******************************************************************/

int  time2seq( YY, MM, DD, HH, MI, mode )

int  YY, MM, DD, HH, MI;
char mode;
{
     static int  month[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
     int  seq;
     int  i;

     seq = YY - 1900;
     seq = seq*365 + (seq + 3)/4;
     for( i = 0; i < MM-1; i++ )
          seq += month[i];
     if( ( MM > 2 ) && ( YY % 4 == 0 ) )  seq += 1;
     seq += DD - 1;

     if( mode == 'h' )
          seq = seq*24 + HH;
     else if( mode == 'm' )
          seq = ( seq*24 + HH )*60 + MI;

     return seq;
}

/******************************************************************
*
*  �Ϸù�ȣ�� �ð����� ��ȯ
*
*    o seq             : �Ϸù�ȣ
*    o YY,MM,DD,HH,MI  : �ð�
*    o mode            : seq�� ����
*         . mode = 'd' : 1900. 1. 1.       ���� �ϼ�
*         . mode = 'h' : 1900. 1. 1. 00    ���� �ð���
*         . mode = 'm' : 1900. 1. 1. 00:00 ���� �м�
*    o c24             : �ð���ȯ ���
*         . c24  = 'n' : 00:00
*         . c24  = 'y' : 24:00
*
******************************************************************/

int  seq2time( seq, YY, MM, DD, HH, MI, mode, c24 )

int  seq;
int  *YY, *MM, *DD, *HH, *MI;
char mode, c24;
{
     static int  month[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
     int    iseq, i;

     *MI = 0;
     if( mode == 'm' )
     {
          *MI = seq % 60;
          seq /= 60;
     }
     *HH = 0;
     if( mode == 'h' || mode == 'm' )
     {
          *HH  = seq % 24;
          seq /= 24;
          if( c24 == 'y' )
          {
               if( *HH == 0 && *MI == 0 )
               {
                    *HH = 24;
                    *MI = 0;
                    seq -= 1;
               }
          }
     }
     *YY = (seq/1461)*4 + 1900;
     if( (seq %= 1461) > 365 )
     {
          seq -= 366;
          *YY += seq/365 + 1;
          seq %= 365;
     }

     seq += 1;
     if( (*YY % 4) == 0 )
     month[1] = 29;
     else
     month[1] = 28;

     for( i = 0; i < 12; i++ )
     {
          if( seq > month[i] )
          seq -= month[i];
          else
          {
               *MM = i + 1;
               *DD = seq;
               break;
          }
     }
     return 0;
}




      int leapYear( int year ) 
      {
         if( ((year % 4)==0) && ((year % 100)!=0) || ((year % 400)==0) )
            return 1;
         else
            return 0;
      }

      int getDaysInMonth( int year, int month )  
      {
         int days;
         
         if( month==1 || month==3 || month==5 || month==7 || month==8 || month==10 || month==12 )  
            days=31;
         else if( month==4 || month==6 || month==9 || month==11 ) 
            days=30;
         else if( month==2 )  
         {
            if( leapYear( year ) )
               days=29;
            else
               days=28;
         }
         return days;
      }

      int toDay( int year, int month )
      {
         int i, days=0;
         
         for( i=1; i< month; i++ )
         {
            days += getDaysInMonth( year, i );
         }
         return days;
      }
      /*
       *    ���۰� ��������� ������ ��(d > 365)�� ���� ���Ѵ�.
       */
      int leapDay( int sY, int eY )
      {
         int y, tY, leapD=0, plus=-1;
         
         if( sY > eY ) { tY = sY; sY = eY; eY = tY; plus = 1; }
         
         for( y = sY; y < eY; y++ ) if( leapYear( y ) ) ++leapD;
         
         return leapD * plus;
      }

      struct st_date calcTime( int factor, long alpha, struct st_date md )
      {

         long yy, mm, nD, nH=0;
         long x = alpha;
     
         switch( factor )
         {
            case _YY_:  
               md.m_yy += x; 
               break;  
      
            case _MM_:
               /* '�����'�� '�߰���'�� ���� �������� �̵����� ǥ��  */
               mm = (int)( ( md.m_mm + x ) % 12 );
               mm = ( mm >= 0 )? mm: 12 + mm;
               
               if( x >= 0 )
                  yy = (int)( ( md.m_mm + x - 1) / 12 );
               else
               {
                  if( ( abs( x ) + 12 - md.m_mm ) != 12 )
                     yy = (int)( ( abs( x ) + 12 - md.m_mm ) / 12 ) * -1;
                  else
                     yy = -1;
               }
      
               if( !mm )
                  md.m_mm = 12;
               else
                  md.m_mm = mm;
      
               md.m_yy += yy;
               break;  
      
            case _DD_:
               if( alpha > 0 )
               {
                  /*    �Ⱚ ���    */
                  nD = ( leapYear( md.m_yy ) )? 366: 365;
                  nD = nD - toDay( md.m_yy, md.m_mm ) - md.m_dd;
                  x  = alpha - nD;
      
                  if( x > 0 )
                  {
                     for( md.m_mm=1, md.m_dd=0;; )
                     {
                        nD = ( leapYear( ++md.m_yy ) )? 366: 365;
      
                        if( ( x-nD ) > 0 ) 
                           x-=nD;
                        else
                           break;
                     }
                  }
                  else
                     x = alpha;
               }
               else
               {
                  /*    �Ⱚ ���    */
                  nD = toDay( md.m_yy, md.m_mm ) + md.m_dd;
                  x  = alpha + nD;
      
                  md.m_mm = 1;
                  md.m_dd = 0;
      
                  if( x < 0 )
                  {
                     for( ;; )
                     {
                        nD = ( leapYear( --md.m_yy ) )? 366: 365;
      
                        if( ( nD+x ) > 0 ) 
                        {
                           x+=nD;
                           break;
                        }
                        x+=nD;
                     }
                  }
                  else
                  {
                     if( x == 0 )
                     {
                        md.m_yy--;
                        md.m_mm = 12;
                        md.m_dd = 31;
                        x = 0;
                     }
                  }
               }
               /*    ���� ���    */
               for( mm=md.m_mm, x+=md.m_dd;; mm++ )
               {
                  nD = getDaysInMonth( md.m_yy, mm );
                  if( ( x-nD ) > 0 )
                     x-=nD;
                  else
                     break;
               }
               md.m_mm = mm;
               md.m_dd = abs( x );
               break; 
               
            case _HH_:
               /*    ���    */
               nD   = (int)( ( alpha + md.m_hh ) / 24 );
               calcTime( _DD_, nD, md );
               md.m_hh = (int)( ( alpha + md.m_hh ) % 24 );
               if( md.m_hh < 0 ) 
               {
                  md = calcTime( _DD_, -1, md );
                  md.m_hh = 24 + md.m_hh;
               }
               break;
      
            case _MI_:  
               nH   = (int)( ( alpha + md.m_mi ) / 60 );
               calcTime( _HH_, nH, md );
               md.m_mi = (int)( ( alpha + md.m_mi ) % 60 );
               if( md.m_mi < 0 )
               {
                  md = calcTime( _HH_, -1, md );
                  md.m_mi = 60 + md.m_mi;
               }
               break;  
      
            case _SS_:  
               md.m_ss += alpha; 
               break;  
         }
      
         return md;
      }


      struct st_date calcTimeA( int factor, long alpha, MD *m_date )
      {

         long yy, mm, nD, nH=0;
         long x = alpha;

         struct st_date md;


         md.m_yy = atoi(m_date->yyyy);
         md.m_mm = atoi(m_date->mm);
         md.m_dd = atoi(m_date->dd);
         md.m_hh = atoi(m_date->hh);
         md.m_mi = atoi(m_date->mi);
         md.m_ss = atoi(m_date->ss);

         //sd = md;

         //printf("===:%d:%s:%s:%s:%s:%s:%s:\n", alpha, m_date->yyyy, m_date->mm, m_date->dd, m_date->hh, m_date->mi, m_date->ss);
    
         switch( factor )
         {
            case _CT_:  
               md.m_yy = gettime( _YY_ );
               md.m_mm = gettime( _MM_ );
               md.m_dd = gettime( _DD_ );
               md.m_hh = gettime( _HH_ );
               md.m_mi = gettime( _MI_ );
               md.m_ss = gettime( _SS_ );
               break;  

            case _YY_:  
               md.m_yy += x; 
               break;  
      
            case _MM_:
               /* '�����'�� '�߰���'�� ���� �������� �̵����� ǥ��  */
               mm = (int)( ( md.m_mm + x ) % 12 );
               mm = ( mm >= 0 )? mm: 12 + mm;
               
               if( x >= 0 )
                  yy = (int)( ( md.m_mm + x - 1) / 12 );
               else
               {
                  if( ( abs( x ) + 12 - md.m_mm ) != 12 )
                     yy = (int)( ( abs( x ) + 12 - md.m_mm ) / 12 ) * -1;
                  else
                     yy = -1;
               }
      
               if( !mm )
                  md.m_mm = 12;
               else
                  md.m_mm = mm;
      
               md.m_yy += yy;
               break;  
      
            case _DD_:
               if( alpha > 0 )
               {
                  /*    �Ⱚ ���    */
                  nD = ( leapYear( md.m_yy ) )? 366: 365;
                  nD = nD - toDay( md.m_yy, md.m_mm ) - md.m_dd;
                  x  = alpha - nD;
      
                  if( x > 0 )
                  {
                     for( md.m_mm=1, md.m_dd=0;; )
                     {
                        nD = ( leapYear( ++md.m_yy ) )? 366: 365;
      
                        if( ( x-nD ) > 0 ) 
                           x-=nD;
                        else
                           break;
                     }
                  }
                  else
                     x = alpha;
               }
               else
               {
                  /*    �Ⱚ ���    */
                  nD = toDay( md.m_yy, md.m_mm ) + md.m_dd;
                  x  = alpha + nD;
      
                  md.m_mm = 1;
                  md.m_dd = 0;
      
                  if( x < 0 )
                  {
                     for( ;; )
                     {
                        nD = ( leapYear( --md.m_yy ) )? 366: 365;
      
                        if( ( nD+x ) > 0 ) 
                        {
                           x+=nD;
                           break;
                        }
                        x+=nD;
                     }
                  }
                  else
                  {
                     if( x == 0 )
                     {
                        md.m_yy--;
                        md.m_mm = 12;
                        md.m_dd = 31;
                        x = 0;
                     }
                  }
               }
               /*    ���� ���    */
               for( mm=md.m_mm, x+=md.m_dd;; mm++ )
               {
                  nD = getDaysInMonth( md.m_yy, mm );
                  if( ( x-nD ) > 0 )
                     x-=nD;
                  else
                     break;
               }
               md.m_mm = mm;
               md.m_dd = abs( x );
               break; 
               
            case _HH_:
               /*    ���    */
               nD   = (int)( ( alpha + md.m_hh ) / 24 );
               //printf("HH1nD:%d:%d:\n", nD, md.m_hh);
               if(nD > 0) calcTimeA( _DD_, nD, m_date );
               md.m_hh = (int)( ( alpha + md.m_hh ) % 24 );
               //printf("HH2nD:%d:%d:\n", nD, md.m_hh);
               if( md.m_hh < 0 ) 
               {
                  sprintf(m_date->hh, "%02d", md.m_hh);
                  md = calcTimeA( _DD_, -1, m_date );
                  md.m_hh = 24 + md.m_hh;
               }
               break;
      
            case _MI_:  
               nH   = (int)( ( alpha + md.m_mi ) / 60 );
               if(nH > 0) md = calcTimeA( _HH_, nH, m_date );
               md.m_mi = (int)( ( alpha + md.m_mi ) % 60 );
               if( md.m_mi < 0 )
               {
                  sprintf(m_date->mi, "%02d", md.m_mi);
                  md = calcTimeA( _HH_, -1, m_date );
                  md.m_mi = 60 + md.m_mi;
               }
               break;  
      
            case _SS_:  
               md.m_ss += alpha; 
               break;  
         }
      
         //printf("+++:%d:%s:%s:%s:%s:%s:%s:\n", alpha, m_date->yyyy, m_date->mm, m_date->dd, m_date->hh, m_date->mi, m_date->ss);
         sprintf(m_date->yyyy, "%04d", md.m_yy);
         sprintf(m_date->mm, "%02d", md.m_mm);
         sprintf(m_date->dd, "%02d", md.m_dd);
         sprintf(m_date->hh, "%02d", md.m_hh);
         sprintf(m_date->mi, "%02d", md.m_mi);
         sprintf(m_date->ss, "%02d", md.m_ss);
          
         //printf("---:%d:%s:%s:%s:%s:%s:%s:\n", alpha, m_date->yyyy, m_date->mm, m_date->dd, m_date->hh, m_date->mi, m_date->ss);
         return md; 
      }

int gettime( int sep )
{
   struct tm *tp;
	time_t t;

   time( &t );
	tp = localtime( &t );
  
   switch( sep )
   {
      case _YY_: return tp->tm_year + 1900;
      case _MM_: return tp->tm_mon + 1;
      case _DD_: return tp->tm_mday;
      case _HH_: return tp->tm_hour;
      case _MI_: return tp->tm_min;
      case _SS_: return tp->tm_sec;
   }
   return -1;
}

char* UTC( int yy, int mm, int dd, int hh )
{
   static char buf[32];
   struct st_date md, sd;

        md.m_yy = yy;
        md.m_mm = mm;
        md.m_dd = dd;
        md.m_hh = hh;

   *buf = '\0';
   sd = calcTime( _HH_, -9, md);
   	
	sprintf( buf, "%04d%02d%02d%02d", sd.m_yy, sd.m_mm, sd.m_dd, sd.m_hh );
	
	return buf;
}


void f_getdate(char *date)
{
	/*struct tm *x,y;
	long clock;
	
	time ( &clock );
	x = (struct tm *)&y.tm_sec;
	x = localtime ( &clock );
	
	if (x->tm_year > 50)
		sprintf(date, "%04d%02d%02d",
			x->tm_year + 1900, x->tm_mon + 1, x->tm_mday);*/
   time_t curtime;
   struct tm *loctime;

   curtime = time (NULL);
   loctime = localtime (&curtime);

   sprintf(date, "%04d%02d%02d",
        loctime->tm_year + 1900, loctime->tm_mon + 1, loctime->tm_mday);
}

void f_gettime(char *time_s)
{
/*	struct tm *x, y;
	long clock;
	
	time( &clock );
	x = (struct tm *)&y.tm_sec;
	x = localtime ( &clock );
	sprintf(time_s, "%02d%02d%02d", x->tm_hour,x->tm_min, x->tm_sec);*/
   time_t curtime;
   struct tm *loctime;

   curtime = time (NULL);
   loctime = localtime (&curtime);

	sprintf(time_s, "%02d%02d%02d", 
			loctime->tm_hour, loctime->tm_min, loctime->tm_sec);
}

void get_DateTime(char *DateTime)
{
	char DateStr[10];
	char TimeStr[10];

	memset(DateStr, 0x00, sizeof(DateStr));
	memset(TimeStr, 0x00, sizeof(TimeStr));
	f_getdate(DateStr);
	f_gettime(TimeStr);
	
	sprintf(DateTime, "%s%s", DateStr, TimeStr);
}

char *f_getdateA()
{
        char sdate[10];
        char *p;

        time_t curtime;
        struct tm *loctime;

        curtime = time (NULL);
        loctime = localtime (&curtime);

        memset(sdate, 0x00, sizeof(sdate));
        sprintf(sdate, "%04d%02d%02d", loctime->tm_year + 1900, loctime->tm_mon + 1, loctime->tm_mday);
        
        p = (char *)malloc( strlen( sdate ) );
        strcpy( p, sdate );

        return p;

}

char *f_gettimeA()
{
        char stime[10];
        char *p;

        time_t curtime;
        struct tm *loctime;

        curtime = time (NULL);
        loctime = localtime (&curtime);

        memset(stime, 0x00, sizeof(stime));
        sprintf(stime, "%02d%02d%02d", loctime->tm_hour, loctime->tm_min, loctime->tm_sec);

        p = (char *)malloc( strlen( stime ) );
        strcpy( p, stime );

        return p;
}

char *f_getdatetimeA()
{
        char sdt[20];
        char *p;

        memset(sdt, 0x00, sizeof(sdt));
        sprintf(sdt, "%s%s", f_getdateA(), f_gettimeA());
 
        p = (char *)malloc( strlen( sdt ) );
        strcpy( p, sdt );

        return p;
}

void subtest(int *index, char *DateStr)
{
        *index = 1;
        strcpy(DateStr, "test");
        printf("1__:%d:\t:%s:\n", *index, DateStr);
   
}

#endif


/*
int main()
{
        struct st_date md, sd;
	printf("leapYear:%d\n", leapYear(2006));
	printf("getDaysInMonth:%d\n", getDaysInMonth(2006, 9));
	printf("toDay:%d\n", toDay(2006, 9));
	printf("leapDay:%d\n", leapDay(2000, 2006));

        md.m_yy = 2006;
        md.m_mm = 1;
        md.m_dd = 1;
        md.m_hh = 0;
        md.m_mi = 0;
        md.m_ss = 0;

        sd = calcTime(_MI_, -100, md); 
        printf("sd = calcTime(_MI_, -100, md)\n"); 
        printf("mmd.m_yy:%d:==>:%d: \n", md.m_yy, sd.m_yy);
        printf("mmd.m_mm:%d:==>:%d: \n", md.m_mm, sd.m_mm);
        printf("mmd.m_dd:%d:==>:%d: \n", md.m_dd, sd.m_dd);
        printf("mmd.m_hh:%d:==>:%d: \n", md.m_hh, sd.m_hh);
        printf("mmd.m_mi:%d:==>:%d: \n", md.m_mi, sd.m_mi);
        printf("mmd.m_ss:%d:==>:%d: \n", md.m_ss, sd.m_ss);
	printf("getTime:%d\n", gettime(_HH_));

        printf("UTC(2006,9,15,03):%s:\n", UTC( 2006, 9, 15, 3 ));

	char DateStr[10];
	char TimeStr[10];
	memset(DateStr, 0x00, sizeof(DateStr));
	memset(TimeStr, 0x00, sizeof(TimeStr));
	f_getdate(DateStr);
        printf("getdate:%s:\n", DateStr);
	f_gettime(TimeStr);
        printf("gettime:%s:\n", TimeStr);
        get_DateTime(DateStr);
        printf("get_DateTime:%s:\n", DateStr);
        
        int index=5;
        printf("1:%d:\t:%s:\n", index, DateStr);
        subtest(&index, DateStr);
        printf("2:%d:\t:%s:\n", index, DateStr);
 
        MD m_date;

        strcpy(m_date.yyyy, "2006");
        strcpy(m_date.mm, "01");
        strcpy(m_date.dd, "01");
        strcpy(m_date.hh, "00");
        strcpy(m_date.mi, "00");
        strcpy(m_date.ss, "00");
 
        printf( "m_date:%s:%s:%s:%s:%s:%s:\n", m_date.yyyy, m_date.mm, m_date.dd, m_date.hh, m_date.mi, m_date.ss );
        printf("\n");
        sd = calcTimeA(_HH_, -21, &m_date); 
        printf( "calcTimeA(dd):%s:%s:%s:%s:%s:%s:\n", m_date.yyyy, m_date.mm, m_date.dd, m_date.hh, m_date.mi, m_date.ss );
        printf( "calcTimeA(sd):%d:%d:%d:%d:%d:%d:\n", sd.m_yy, sd.m_mm, sd.m_dd, sd.m_hh, sd.m_mi, sd.m_ss );
        printf("\n");
        sd = calcTimeA(_HH_, -21, &m_date); 
        printf( "calcTimeA(dd):%s:%s:%s:%s:%s:%s:\n", m_date.yyyy, m_date.mm, m_date.dd, m_date.hh, m_date.mi, m_date.ss );
        printf( "calcTimeA(sd):%d:%d:%d:%d:%d:%d:\n", sd.m_yy, sd.m_mm, sd.m_dd, sd.m_hh, sd.m_mi, sd.m_ss );
        printf("\n");
        sd = calcTimeA(_DD_, +21, &m_date); 
        printf( "calcTimeA(dd):%s:%s:%s:%s:%s:%s:\n", m_date.yyyy, m_date.mm, m_date.dd, m_date.hh, m_date.mi, m_date.ss );
        printf( "calcTimeA(sd):%d:%d:%d:%d:%d:%d:\n", sd.m_yy, sd.m_mm, sd.m_dd, sd.m_hh, sd.m_mi, sd.m_ss );
        printf("\n");
        sd = calcTimeA(_HH_, -21, &m_date); 
        printf( "calcTimeA(dd):%s:%s:%s:%s:%s:%s:\n", m_date.yyyy, m_date.mm, m_date.dd, m_date.hh, m_date.mi, m_date.ss );
        printf( "calcTimeA(sd):%d:%d:%d:%d:%d:%d:\n", sd.m_yy, sd.m_mm, sd.m_dd, sd.m_hh, sd.m_mi, sd.m_ss );
        printf("\n");
        sd = calcTimeA(_MI_, -21, &m_date); 
        printf( "calcTimeA(dd):%s:%s:%s:%s:%s:%s:\n", m_date.yyyy, m_date.mm, m_date.dd, m_date.hh, m_date.mi, m_date.ss );
        printf( "calcTimeA(sd):%d:%d:%d:%d:%d:%d:\n", sd.m_yy, sd.m_mm, sd.m_dd, sd.m_hh, sd.m_mi, sd.m_ss );

        printf("\n");
        sd = calcTimeA(_CT_, -21, &m_date); 
        printf( "calcTimeA(dd):%s:%s:%s:%s:%s:%s:\n", m_date.yyyy, m_date.mm, m_date.dd, m_date.hh, m_date.mi, m_date.ss );
        printf( "calcTimeA(sd):%d:%d:%d:%d:%d:%d:\n", sd.m_yy, sd.m_mm, sd.m_dd, sd.m_hh, sd.m_mi, sd.m_ss );
}
*/

