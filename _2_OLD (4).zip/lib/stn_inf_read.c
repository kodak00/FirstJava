#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stn_inf.h"

int str_split(char *tmp, char *buf, char s)
{
    int  i = 0;

    tmp[0] = '\0';

    for (i = 0; i < strlen(buf); i++)
    {
        if (buf[i] == s)
        {
            tmp[i] = '\0';
            i++;
            break;
        }
        tmp[i] = buf[i];
    }
    return i;
}

int str2stn_sfc(char *buf, struct STN_SFC *stn)
{
    char  tmp[201];
    int   n = 0;

    n += str_split(tmp, &buf[n], ',');  (*stn).stn_id = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_ed = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_st = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_ko, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_en, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_sp, tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lat = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lon = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht_pa = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht_ta = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht_wd = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht_rn = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).fct_id, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).law_id, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).basin_id, tmp);

    return 0;
}

int str2stn_aws(char *buf, struct STN_AWS *stn)
{
    char  tmp[201];
    int   n = 0;

    n += str_split(tmp, &buf[n], ',');  (*stn).stn_id = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_ed = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_st = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_ko, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_en, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_sp, tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lat = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lon = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht_wd = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lau_id = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).stn_ad = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).fct_id, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).law_id, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).basin_id, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).law_name, tmp);

    return 0;
}

int str2stn_awso(char *buf, struct STN_AWSO *stn)
{
    char  tmp[201];
    int   n = 0;

    n += str_split(tmp, &buf[n], ',');  (*stn).stn_num = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).stn_id = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_ed = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_st = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).gov_cd, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_ko, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_en, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_sp, tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lat = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lon = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht_wd = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).fct_id, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).wrn_id, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).law_id, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).basin_id, tmp);

    return 0;
}

int str2stn_awos(char *buf, struct STN_AWOS *stn)
{
    char  tmp[201];
    int   n = 0;

    n += str_split(tmp, &buf[n], ',');  (*stn).stn_id = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_ed = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_st = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_ko, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_en, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_sp, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_sp2, tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lat = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lon = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht_wd = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lau_id = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).stn_ad = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).fct_id, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).law_id, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).basin_id, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).gov_cd, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).eqp_cd, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).law_name, tmp);

    return 0;
}

int str2stn_lau(char *buf, struct STN_LAU *stn)
{
    char  tmp[201];
    int   n = 0;

    n += str_split(tmp, &buf[n], ',');  (*stn).lau_id = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_ed = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_st = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_ko, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_en, tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lat = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lon = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lau_ud = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).lau_ip, tmp);

    return 0;
}

int str2stn_rdr(char *buf, struct STN_RDR *stn)
{
    char  tmp[201];
    int   n = 0;

    n += str_split(tmp, &buf[n], ',');  (*stn).stn_id = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_ed = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_st = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_cd, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_ko, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_en, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_sp, tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lat = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lon = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).stn_ad = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).range = atoi(tmp);

    return 0;
}

int str2stn_buoy(char *buf, struct STN_BUOY *stn)
{
    char  tmp[201];
    int   n = 0;

    n += str_split(tmp, &buf[n], ',');  (*stn).stn_id = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_ed = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_st = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_ko, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_en, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_sp, tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lat = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lon = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).stn_ad = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).fct_id, tmp);

    return 0;
}

int str2stn_pm10(char *buf, struct STN_PM10 *stn)
{
    char  tmp[201];
    int   n = 0;

    n += str_split(tmp, &buf[n], ',');  (*stn).stn_id = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_ed = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_st = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_ko, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_en, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_sp, tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lat = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lon = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).stn_ad = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).fct_id, tmp);

    return 0;
}

int str2stn_snow(char *buf, struct STN_SNOW *stn)
{
    char  tmp[201];
    int   n = 0;

    n += str_split(tmp, &buf[n], ',');  (*stn).stn_id = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_ed = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_st = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_ko, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_sp, tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lat = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lon = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).stn_ad = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).fct_id, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).law_id, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).basin_id, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_loc, tmp);

    return 0;
}

int str2stn_nko(char *buf, struct STN_NKO *stn)
{
    char  tmp[201];
    int   n = 0;

    n += str_split(tmp, &buf[n], ',');  (*stn).stn_id = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_ed = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_st = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_ko, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_en, tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_sp, tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lat = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).lon = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht_pa = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht_ta = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht_wd = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).ht_rn = atof(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).fct_id, tmp);

    return 0;
}

int str2stn_aws2lamp(char *buf, struct STN_AWS2LAMP *stn)
{
    char  tmp[128];
    int   n = 0;

    n += str_split(tmp, &buf[n], ',');  (*stn).lamp_id = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).lamp_nm, tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).stn_id = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy((*stn).stn_ko, tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_ed = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  (*stn).tm_st = atoi(tmp);

    return 0;
}

