#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

/*---------------------------------------------------------------------------*/
/*  ȯ�溯�� ����                                                            */
/*---------------------------------------------------------------------------*/
int oracle_env_set()
{
    putenv("COMIS_HOME=/comis");
    putenv("LOCAL=/usr/local");
    putenv("ORACLE_BASE=/home/oracle");
    putenv("ORACLE_HOME=/home/oracle/ORA10G");
    putenv("NLS_LANG=American_America.KO16KSC5601");
    putenv("ORA_NLS10=/home/oracle/ORA10G/nls/data");
    putenv("CLASSPATH=/home/oracle/ORA10G/JRE:/home/oracle/ORA10G/jlib:/home/oracle/ORA10G/rdbms/jlib:/home/oracle/ORA10G/network/jlib");
    putenv("LD_LIBRARY_PATH=/home/oracle/ORA10G/lib:/usr/lib:/comis/src/lib:/usr/local/lib:/usr/local/trmm/GVBOX/lib");
    putenv("TNS_ADMIN=/home/oracle/ORA10G/network/admin");
    putenv("ORACLE_SID=SVC_COM");
    putenv("ORA_USER=comis@SVC_COM");
    putenv("ORA_PW=comis");
    putenv("PATH=/comis/bin:/usr/local/php/bin:/usr/local/bin:/bin:/usr/bin:/home/oracle/ORA10G/bin:/sbin:/usr");
    return 0;
}
