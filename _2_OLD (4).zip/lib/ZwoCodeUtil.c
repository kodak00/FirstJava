/*----------------------------------------------------------------------------
 * Name       : ZwoCodeUtil.c
 * Description: Zenowoo's Code Utilities
 * Version    : 1.0
 *----------------------------------------------------------------------------*/

#ifndef ZWOCODEUTIL_C
#define ZWOCODEUTIL_C



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <signal.h>																// for GetSignalStr()
#include <fcntl.h>																// for O_WRONLY
#include <stdarg.h>																// for Variable Arguments



#define true					1												// for Bool Type Variable
#define false					0



// Logging
//#ifdef ZWO_LOG
//#define ZLOG(...) if (PRINT_LOG) WriteLog(__VA_ARGS__);
//#else
//#define ZLOG(...)
//#endif
int	  PRINT_LOG			= false;												// Print Detail Log?
int   log_fd			= -1;													// File Descriptor for Log

int	  DetermineLog      (int argc, char* argv[]);
int   MakeLogHeader     (int argc, char* argv[]);
int   WriteLog          (char* msg, ...);
void  CloseLog			();
char* GetTimeString     (void);
void  WriteBufferLog    (char* title_buffer, char* buffer, int length);
void  WriteShortArrayLog(char* title_buffer, short* array, int length);

// Signal
int  KILL_BY_SIGTERM_ONLY = false;

void PrepareSignalLogger  ();
void WriteSignalLog       (int sig_no);

// String
int 	GetDir	   (char* org_str, char* result_str);
int     GetFileName(char* org_str, char* result_str);
int		ReplaceString(char* org_str, char* rep_str, char* new_str);
char**  SplitText  (char* org_text, char* seperator, int to_be_count, int* count);
ssize_t readn	   (int fd, char* ptr, size_t n);
ssize_t writen     (int fd, char* ptr, size_t n);

// Time
int     GetTime            (int *YY, int *MM, int *DD, int *HH, int *MI, int *sec);
int     GetTimeAddedSeconds(int *YY, int *MM, int *DD, int *HH, int *MI, int *sec, int add);
int 	GetCurrentSecond();
int 	GetCurrentMinute();

// Memory
void    ShowBuffer  (char* title_buffer, char* buffer, int length);
int     RemoveBuffer(char* buf, int len_buf, int pos_start, int pos_end);

// Converting Code to String
void    GetErrStr	(char* msg);
void    GetSignalStr(int sig_no, char* msg);

// Leejh String Converting
int SplitText1(char * s1, char * s2, char ** result );

//====[ Logging ]===============================================================



/*----------------------------------------------------------------------------
 * Name       : DetermineLog()
 * Description: Check Arguments to Determine Log Printing ('-log')
 * Parameter  : int argc, char** argv: Same with main()
 * Return     : Always 0
 *----------------------------------------------------------------------------*/
int DetermineLog(int argc, char* argv[])
{
	// Initialize
	int i;
	
	// Check Arguments
	PRINT_LOG = false;
	for (i = 1; i<argc; i++)
		if (!strcmp(argv[i], "-log"))
			PRINT_LOG = true;
			
	if (PRINT_LOG) MakeLogHeader(argc, argv);
			
	// Finalize
	return 0;
}

/*----------------------------------------------------------------------------
 * Name       : MakeLogHeader()
 * Description: Create Log File & Show Log Introduce
 * Parameter  : argv[0]: Program File Name
 * Return     :  0: Normal
 *				-1: Error
 *----------------------------------------------------------------------------*/
int MakeLogHeader(int argc, char* argv[])
{
	// Initialize
	char  prg_filename[256];													// Program Name to Make Log
	char  log_filename[256];													// File Name of Log
	int   YY, MM, DD, HH, MI, SS;												// Time Values	
	char  buf         [256];													// Temporary Buffer
	int   i;																	// Temporary Integer
	
	PRINT_LOG = true;															// for Directly Executed Log Preparation
	GetFileName(argv[0], prg_filename);
	
	// Create Log File
	GetTime(&YY, &MM, &DD, &HH, &MI, &SS);
	sprintf(log_filename, "/LOGD/RECV/%s_%04d%02d%02d.log", 
		          prg_filename, YY, MM, DD);
	if ((log_fd = open(log_filename, O_WRONLY | O_CREAT | O_APPEND, 0644)) == -1)
	{
		GetErrStr(buf);
		printf("[ ERROR: Couldn't Open Log File(%s) - %s (%s) ]\n", 
				log_filename, buf, GetTimeString());
		goto OnErr;
	}
	
	// Show Log Introduce
	WriteLog("[ Starting %s(pid: %d)... (%s) ]\n", prg_filename, getpid(), GetTimeString());
	WriteLog("[ Statement: ");
	for (i=0; i<argc; i++)
		WriteLog("%s ", argv[i]);
	WriteLog(" ]\n");
	WriteLog("[ Log File is %s ]\n\n", log_filename);
	
	// Prepare Signal Logger
	PrepareSignalLogger();
	
	// Finalize
	return 0;
	
OnErr:
	return -1;
}

/*----------------------------------------------------------------------------
 * Name       : WriteLog()
 * Description: Write Log to stdout and Log File
 * Parameter  : msg : String Format to Write
 *				... : Arguments to Formatting
 * Return     : Always 0
 *----------------------------------------------------------------------------*/
int WriteLog (char* msg, ...)
{	
	// Initialize
	char   log_va_buf[256];															// String buffer for va_list
	
	// Make String from va_list
	va_list argptr;
	va_start(argptr, msg);
	vsprintf(log_va_buf, msg, argptr);
	va_end(argptr);
	
	// Write Log
	printf("%s", log_va_buf);
	write(log_fd, log_va_buf, strlen(log_va_buf));
	
	// Finalize
	return 0;
}

/*----------------------------------------------------------------------------
 * Name       : CloseLog()
 * Description: Close Log File Descriptor
 * Parameter  : (nothing)
 * Return     : (nothing)
 *----------------------------------------------------------------------------*/
void CloseLog()
{
	close(log_fd);
}

/*----------------------------------------------------------------------------
 * Name       : GetTimeString()
 * Description: Get Time String with Micro Seconds
 * Parameter  : (nothing)
 * Return     : (Time String)
 *----------------------------------------------------------------------------*/
char* GetTimeString()
{
	// Initialize
	struct timeval tv	;
	static char str[30]	;
	char*  ptr			;
	
	// Get Time String
	if (gettimeofday(&tv, NULL) < 0 )
	{
		WriteLog("[ ERROR: gettimeofday error! ]\n");
		return NULL;
	}

	ptr = ctime(&tv.tv_sec);
	strcpy(str, &ptr[11]);
	snprintf(str + 8, sizeof(str) - 8, ".%06d", tv.tv_usec);

	// Finalize
	return str;
}

/*----------------------------------------------------------------------------
 * Name       : WriteBufferLog()
 * Description: Write Buffer Log
 * Parameter  : title_buffer: the Title of Buffer
 *				buffer      : Character Array to Show
 *				length      : the Length of Array
 * Return     : (void)
 *----------------------------------------------------------------------------*/
void WriteBufferLog(char* title_buffer, char* buffer, int length)
{
	// Initialize
	char c[  16+1];
	char u[3*16+1];
	char s[3     ];
	int  i, j;
	
	c[  16  ] = 0;
	u[3*16  ] = 0;
	s[3   -1] = 0;
	
	// Show Buffer
	WriteLog("[ %s - %d bytes (%s) ]\n" , title_buffer, length, GetTimeString());
	
	if (length == 0) return;
	
	WriteLog("  -0123456789abcdef---0--1--2--3--4--5--6--7--8--9--a--b--c--d--e--f--\n");
	for (i=0; i<length; i+=16)
	{
		for (j=0; j<16; j++)
		{
			if (i+j < length)
			{
				if (32<=buffer[i+j] && buffer[i+j]<=126)
					c[j] = buffer[i+j];
				else
					c[j] = ' ';
				
				sprintf(s, "%3x", (unsigned char)buffer[i+j]);
				strcpy(u+(j*3+2-strlen(s)), s);
				u[j*3+2] = ' ';
			}
			else
			{
				c[j] = ' ';
				strcpy(u+(j*3), "   ");
			}
		}

		WriteLog("  |%s| %s|\n", c, u);
	}
	WriteLog("\n");
}

/*----------------------------------------------------------------------------
 * Name       : WriteShortArrayLog()
 * Description: Write Short-Type Array Log
 * Parameter  : title_buffer: the Title of Short Array
 *				buffer      : Character Array to Show
 *				length      : the Length of Array
 * Return     : (void)
 *----------------------------------------------------------------------------*/
void WriteShortArrayLog(char* title_buffer, short* array, int length)
{
	// Initialize
	int  i, j, k;
	
	// Show Array
	WriteLog("[ %s - %d items (%s) ]\n" , title_buffer, length, GetTimeString());
	
	WriteLog("      |\t");
	for (i=0; i<10; i++)
		WriteLog(" %6d ", i);
	WriteLog(" |\n");
	for (i=0; i<90; i++)
		WriteLog("-");
	WriteLog("\n");
	
	for (i=0; i<length; i+=10)
	{
		WriteLog("%5d |\t", i);
		for (j=0; j<10; j++)
		{
			if (i+j < length)
				WriteLog(" %6d ", array[i+j]);
			else
				WriteLog("        ");
		}

		WriteLog(" |\n");
	}
	WriteLog("\n");
}



//====[ Signal ]================================================================



void PrepareSignalLogger()
{
	// PreCheck
	if (!PRINT_LOG)
	{
		printf("[ ERROR: Signal Logger Needs PRINT_LOG Mode! ]\n");
		return;
	}
	
	// Initialize	
	void WriteSignalLog(int);
	static struct sigaction log_act;												// Signal Action for Logging
	int i;
	
	sigfillset(&(log_act.sa_mask));
	log_act.sa_handler = WriteSignalLog;
	
	// Register Signal Handler
	for (i = 1; i<= 32; i++)
		sigaction(i, &log_act, NULL);
}

void WriteSignalLog(int sig_no)
{
	// Initialize
	char   log_buf[256];															// String buffer for Logging
	
	// Show Signal Message
	GetSignalStr(sig_no, log_buf);
	WriteLog("\n[ SIGNAL: PID %d - %s (%s) ]\n\n", getpid(), log_buf, GetTimeString());

	// Exit or Ignore
	if (sig_no != SIGCONT && sig_no != SIGUSR1 && sig_no != SIGUSR2 && 
		(!KILL_BY_SIGTERM_ONLY || (sig_no == SIGTERM)))
	{
		CloseLog();
		exit(1);
	}
}



//====[ String ]================================================================



/*----------------------------------------------------------------------------
 * Name       : GetDir()
 * Description: Copy ONLY Directory Path from Original String to Result Buffer
 * Parameter  : org_str   : Original String
 *				result_str: (Return) Result Buffer
 * Return     : Always 0
 *----------------------------------------------------------------------------*/
int GetDir(char* org_str, char* result_str)
{
	// Initialize
	char* p;
		
	// Get Directory Path
	p = strrchr(org_str, '/');
	if (p == NULL)
	{
		strcpy (result_str, org_str);
	}
	else
	{
		strncpy(result_str, org_str, p-org_str);
		result_str[p-org_str] = 0;
	}

	// Finalize
	return 0;
}

/*----------------------------------------------------------------------------
 * Name       : GetFileName()
 * Description: Copy ONLY File Name from Original String to Result Buffer
 * Parameter  : org_str   : Original String
 *				result_str: (Return) Result Buffer
 * Return     : Always 0
 *----------------------------------------------------------------------------*/
int GetFileName(char* org_str, char* result_str)
{
	// Initialize
	char* p;
		
	// Get File Name
	p = strrchr(org_str, '/');
	if (p == NULL)
		strcpy(result_str, org_str);
	else
		strcpy(result_str, p+1);

	// Finalize
	return 0;
}

/*----------------------------------------------------------------------------
 * Name       : ReplaceString()
 * Description: Replace String to New String
 * Parameter  : char* org_str, char* rep_str, char* new_str
 * Return     : Always 0
 *----------------------------------------------------------------------------*/
int ReplaceString(char* org_str, char* rep_str, char* new_str)
{
	// Initialize
	char* p;
	char  buf_before[32768];
	char  buf_after [32768];

	strcpy(buf_before, org_str);
	strcpy(buf_after , org_str);

	// Search rep_str
	p = strstr(buf_before, rep_str);
	while (p != NULL)
	{
		// Replace String
		strncpy(buf_after, buf_before, p-buf_before-1);
		buf_after[p-buf_before] = 0;
		strcat (buf_after, new_str);
		buf_after[p-buf_before+strlen(new_str)] = 0;
		strcat (buf_after, p+strlen(rep_str));
		
		// Next Step
		strcpy(buf_before, buf_after);
		p = strstr(buf_before, rep_str);
	}
	
	// Finalize
	strcpy(org_str, buf_after);
}

/*----------------------------------------------------------------------------
 * Name       : SplitText()
 * Description: Split Text by Seperator using strtok()
 * Parameter  : org_text   : Original Text Buffer
 				seperator  : Seperating Character
 				to_be_count: the TO-BE Number of Result String.
 							 If count < to_be_count, Filled '(null)'.
 							 If to_be_count < 1, NOT Filled.
 				count      : (Result)the Number of Result String. NULLABLE 				
 * Return     : Splitted String Array
 *----------------------------------------------------------------------------*/
char** SplitText(char* org_text, char* seperator, int to_be_count, int* count)
{
	// Initialize
	char** split = NULL;
	char* token;
	int count_string = 0;
		
	// Split the Text
	token = strtok(org_text, seperator);
	while (token != NULL)
	{
		// ReAllocate Splitted String Array		
		split = (char**)realloc(split, sizeof(char*)*(count_string+1));
		split[count_string] = (char*)malloc(strlen(token)+1);
		strcpy(split[count_string], token);
		
		// Next Step
		count_string++;
		token = strtok(NULL, seperator);
	}
	
	// Fill Empty Data to '(null)'
	if (0<to_be_count)
	{
		for (; count_string<to_be_count; count_string++)
		{
			// ReAllocate Splitted String Array		
			split = (char**)realloc(split, sizeof(char*)*(count_string+1));
			split[count_string] = NULL;
		}
	}
	
	// Finalize
	if (count!=NULL) *count = count_string;
	return split;
}

int SplitText1(char * s1, char * s2, char ** result )
{
    char *p;
    int i=0,a;
	 
    p = strtok (s1,s2);
    result[i] = p;
				  
    while(p !=NULL)
    {
		i++;
		p = strtok (NULL,s2);
		result[i] = p;
	}
													   
	return i;
}


/*----------------------------------------------------------------------------
 * Name       : readn() 
 * Description: Read "n" bytes from a descriptor
 * Origin     : "Unix Network Programming" p. 78
 * Parameter  : fd : File Descriptor
				prt: Read Buffer
				n  : Length to Read
 * Return     : Read Length
 *----------------------------------------------------------------------------*/
ssize_t readn(int fd, char* ptr, size_t n)
{
	size_t nleft;
	ssize_t nread;
	
	nleft = n;
	while(0 < nleft)
	{
		if ( (nread=read(fd, ptr, nleft)) < 0 )
		{
			if (errno == EINTR)
				nread = 0;														// AND call read() again
			else
				return -1;			
		}
		else if (nread == 0)
		{
			break;																// EOF
		}
		
		nleft -= nread;
		ptr += nread;		
	}
	
	return (n-nleft);															// Return >= 0
}

/*----------------------------------------------------------------------------
 * Name       : writen() 
 * Description: Write "n" bytes to a descriptor
 * Origin     : "Unix Network Programming" p. 78
 * Parameter  : fd : File Descriptor
				ptr: Read Buffer
				n  : Length to Write
 * Return     : Written Length
 *----------------------------------------------------------------------------*/
ssize_t writen(int fd, char* ptr, size_t n)
{
	size_t nleft;
	ssize_t nwritten;
	
	nleft = n;
	while(0 < nleft)
	{
		if ( (nwritten = write(fd, ptr, nleft)) <=0)
		{
			if (errno == EINTR)
				nwritten = 0;													// AND Call write() Again
			else
				return -1;
		}
		nleft -= nwritten;
		ptr += nwritten;
	}
	
	return n;
}



//====[ Time ]==================================================================



/*----------------------------------------------------------------------------
 * Name       : GetTime
 * Description: Get Time Values
 * Origin     : /comis/src/aws2/rcv/aws2_lau_Rercv.c
 * Parameter  : YY : ������ ������ ������
  				MM : ����   ������ ������
 				DD : ��¥�� ������ ������
 				HH : �ø�   ������ ������
 				MI : ����   ������ ������
 				sec: �ʸ�   ������ ������
 * Return     : 0(Always Success)
 *----------------------------------------------------------------------------*/
int GetTime(int *YY, int *MM, int *DD, int *HH, int *MI, int *sec)
{
	// Initialize
    time_t     ctm;
    struct tm* now;

	// Get Time
    time(&ctm);
    now  = localtime(&ctm);
    *YY  = now -> tm_year;
    if (*YY < 1900) *YY += 1900;
    *MM  = now -> tm_mon + 1;
    *DD  = now -> tm_mday;
    *HH  = now -> tm_hour;
    *MI  = now -> tm_min;
    *sec = now -> tm_sec;

	// Finalize
    return 0;
}

/*----------------------------------------------------------------------------
 * Name       : GetTimeAddedSeconds
 * Description: Get Time Values Added Seconds
 * Parameter  : YY : ������ ������ ������
  				MM : ����   ������ ������
 				DD : ��¥�� ������ ������
 				HH : �ø�   ������ ������
 				MI : ����   ������ ������
 				sec: �ʸ�   ������ ������
 				add: ���� �ð��� ���� ��
 * Return     : 0(Always Success)
 *----------------------------------------------------------------------------*/
int GetTimeAddedSeconds(int *YY, int *MM, int *DD, int *HH, int *MI, int *sec, int add)
{
	// Initialize
    time_t     ctm;
    struct tm* now;

	// Get Time
    time(&ctm);
    ctm += add;
    now  = localtime(&ctm);
    *YY  = now -> tm_year;
    if (*YY < 1900) *YY += 1900;
    *MM  = now -> tm_mon + 1;
    *DD  = now -> tm_mday;
    *HH  = now -> tm_hour;
    *MI  = now -> tm_min;
    *sec = now -> tm_sec;

	// Finalize
    return 0;
}

/*----------------------------------------------------------------------------
 * Name       : GetCurrentSecond()
 * Description: Get Second Value from Current Time
 * Parameter  : 
 * Return     : Current Second
 *----------------------------------------------------------------------------*/
int GetCurrentSecond()
{
	struct tm* now;
    time_t     ctm;

    time(&ctm);
    now = localtime(&ctm);
    return now->tm_sec;
}

/*----------------------------------------------------------------------------
 * Name       : GetCurrentMinute()
 * Description: Get Minute Value from Current Time
 * Parameter  : 
 * Return     : Current Minute
 *----------------------------------------------------------------------------*/
int GetCurrentMinute()
{
	struct tm* now;
    time_t     ctm;

    time(&ctm);
    now = localtime(&ctm);
    return now->tm_min;
}



//====[ Memory ]================================================================



void ShowBuffer(char* title_buffer, char* buffer, int length)
{
	// Initialize
	char c[  16+1];
	char u[3*16+1];
	char s[3     ];
	int  i, j;
	
	c[  16  ] = 0;
	u[3*16  ] = 0;
	s[3   -1] = 0;
	
	// Show Buffer
	printf("[ %s - %d bytes (%s) ]\n" , title_buffer, length, GetTimeString());
	
	if (length == 0) return;
	
	printf("  -0123456789abcdef---0--1--2--3--4--5--6--7--8--9--a--b--c--d--e--f--\n");
	for (i=0; i<length; i+=16)
	{
		for (j=0; j<16; j++)
		{
			if (i+j < length)
			{
				if (32<=buffer[i+j] && buffer[i+j]<=126)
					c[j] = buffer[i+j];
				else
					c[j] = ' ';
				
				sprintf(s, "%3x", (unsigned char)buffer[i+j]);
				strcpy(u+(j*3+2-strlen(s)), s);
				u[j*3+2] = ' ';
			}
			else
			{
				c[j] = ' ';
				strcpy(u+(j*3), "   ");
			}
		}

		printf("  |%s| %s|\n", c, u);
	}
	printf("\n");
}

/*----------------------------------------------------------------------------
 * Name       : RemoveBuffer()
 * Description: Remove Characters in Buffer
 * Parameter  : buf       : Buffer has characters to Remove
 *				len_buf   : the Length of buf
 *				pos_start : the Start Position to Remove
 * 				pos_end   : the End   Position to Remove
 * Return     : Always 0
 *----------------------------------------------------------------------------*/
int RemoveBuffer(char* buf, int len_buf, int pos_start, int pos_end)
{
	// Initialize
	int len_remove = pos_end-pos_start+1;

	memcpy(buf+pos_start, buf+pos_end+1, len_buf-pos_end-1);
	memset(buf+len_buf-len_remove, 0, len_remove);

	// Finalize
	return len_remove;
}



//====[ Converting Code to String ]=============================================



/*----------------------------------------------------------------------------
 * Name       : GetErrStr()
 * Description: Get Socket Error Message by errno
 * Parameter  : (nothing)
 * Return     : (Error Message)
 *----------------------------------------------------------------------------*/
void GetErrStr(char* msg)
{
    // Get Socket Error Message
    switch (errno)
    {
        case EPERM: // 1
            sprintf(msg, "Operation not permitted (%d EPERM)", errno);
            break;
        case ENOENT: // 2
            sprintf(msg, "No such file or directory (%d ENOENT)", errno);
            break;
        case ESRCH: // 3
            sprintf(msg, "No such process (%d ESRCH)", errno);
            break;
        case EINTR: // 4
            sprintf(msg, "Interrupted system call (%d EINTR)", errno);
            break;
        case EIO: // 5
            sprintf(msg, "I/O error (%d EIO)", errno);
            break;
        case ENXIO: // 6
            sprintf(msg, "No such device or address (%d ENXIO)", errno);
            break;
        case E2BIG: // 7
            sprintf(msg, "Arg list too long (%d E2BIG)", errno);
            break;
        case ENOEXEC: // 8
            sprintf(msg, "Exec format error (%d ENOEXEC)", errno);
            break;
        case EBADF: // 9
            sprintf(msg, "Bad file number (%d EBADF)", errno);
            break;
        case ECHILD: // 10
            sprintf(msg, "No child processes (%d ECHILD)", errno);
            break;
        case EAGAIN: // 11
            sprintf(msg, "Try again (%d EAGAIN)", errno);
            break;
        case ENOMEM: // 12
            sprintf(msg, "Out of memory (%d ENOMEM)", errno);
            break;
        case EACCES: // 13
            sprintf(msg, "Permission denied (%d EACCES)", errno);
            break;
        case EFAULT: // 14
            sprintf(msg, "Bad address (%d EFAULT)", errno);
            break;
        case ENOTBLK: // 15
            sprintf(msg, "Block device required (%d ENOTBLK)", errno);
            break;
        case EBUSY: // 16
            sprintf(msg, "Device or resource busy (%d EBUSY)", errno);
            break;
        case EEXIST: // 17
            sprintf(msg, "File exists (%d EEXIST)", errno);
            break;
        case EXDEV: // 18
            sprintf(msg, "Cross-device link (%d EXDEV)", errno);
            break;
        case ENODEV: // 19
            sprintf(msg, "No such device (%d ENODEV)", errno);
            break;
        case ENOTDIR: // 20
            sprintf(msg, "Not a directory (%d ENOTDIR)", errno);
            break;
        case EISDIR: // 21
            sprintf(msg, "Is a directory (%d EISDIR)", errno);
            break;
        case EINVAL: // 22
            sprintf(msg, "Invalid argument (%d EINVAL)", errno);
            break;
        case ENFILE: // 23
            sprintf(msg, "File table overflow (%d ENFILE)", errno);
            break;
        case EMFILE: // 24
            sprintf(msg, "Too many open files (%d EMFILE)", errno);
            break;
        case ENOTTY: // 25
            sprintf(msg, "Not a typewriter (%d ENOTTY)", errno);
            break;
        case ETXTBSY: // 26
            sprintf(msg, "Text file busy (%d ETXTBSY)", errno);
            break;
        case EFBIG: // 27
            sprintf(msg, "File too large (%d EFBIG)", errno);
            break;
        case ENOSPC: // 28
            sprintf(msg, "No space left on device (%d ENOSPC)", errno);
            break;
        case ESPIPE: // 29
            sprintf(msg, "Illegal seek (%d ESPIPE)", errno);
            break;
        case EROFS: // 30
            sprintf(msg, "Read-only file system (%d EROFS)", errno);
            break;
        case EMLINK: // 31
            sprintf(msg, "Too many links (%d EMLINK)", errno);
            break;
        case EPIPE: // 32
            sprintf(msg, "Broken pipe (%d EPIPE)", errno);
            break;
        case EDOM: // 33
            sprintf(msg, "Math argument out of domain of func (%d EDOM)", errno);
            break;
        case ERANGE: // 34
            sprintf(msg, "Math result not representable (%d ERANGE)", errno);
            break;
        case EDEADLK: // 35
            sprintf(msg, "Resource deadlock would occur (%d EDEADLK)", errno);
            break;
        case ENAMETOOLONG: // 36
            sprintf(msg, "File name too long (%d ENAMETOOLONG)", errno);
            break;
        case ENOLCK: // 37
            sprintf(msg, "No record locks available (%d ENOLCK)", errno);
            break;
        case ENOSYS: // 38
            sprintf(msg, "Function not implemented (%d ENOSYS)", errno);
            break;
        case ENOTEMPTY: // 39
            sprintf(msg, "Directory not empty (%d ENOTEMPTY)", errno);
            break;
        case ELOOP: // 40
            sprintf(msg, "Too many symbolic links encountered (%d ELOOP)", errno);
            break;
        case ENOMSG: // 42
            sprintf(msg, "No message of desired type (%d ENOMSG)", errno);
            break;
        case EIDRM: // 43
            sprintf(msg, "Identifier removed (%d EIDRM)", errno);
            break;
        case ECHRNG: // 44
            sprintf(msg, "Channel number out of range (%d ECHRNG)", errno);
            break;
        case EL2NSYNC: // 45
            sprintf(msg, "Level 2 not synchronized (%d EL2NSYNC)", errno);
            break;
        case EL3HLT: // 46
            sprintf(msg, "Level 3 halted (%d EL3HLT)", errno);
            break;
        case EL3RST: // 47
            sprintf(msg, "Level 3 reset (%d EL3RST)", errno);
            break;
        case ELNRNG: // 48
            sprintf(msg, "Link number out of range (%d ELNRNG)", errno);
            break;
        case EUNATCH: // 49
            sprintf(msg, "Protocol driver not attached (%d EUNATCH)", errno);
            break;
        case ENOCSI: // 50
            sprintf(msg, "No CSI structure available (%d ENOCSI)", errno);
            break;
        case EL2HLT: // 51
            sprintf(msg, "Level 2 halted (%d EL2HLT)", errno);
            break;
        case EBADE: // 52
            sprintf(msg, "Invalid exchange (%d EBADE)", errno);
            break;
        case EBADR: // 53
            sprintf(msg, "Invalid request descriptor (%d EBADR)", errno);
            break;
        case EXFULL: // 54
            sprintf(msg, "Exchange full (%d EXFULL)", errno);
            break;
        case ENOANO: // 55
            sprintf(msg, "No anode (%d ENOANO)", errno);
            break;
        case EBADRQC: // 56
            sprintf(msg, "Invalid request code (%d EBADRQC)", errno);
            break;
        case EBADSLT: // 57
            sprintf(msg, "Invalid slot (%d EBADSLT)", errno);
            break;
        case EBFONT: // 59
            sprintf(msg, "Bad font file format (%d EBFONT)", errno);
            break;
        case ENOSTR: // 60
            sprintf(msg, "Device not a stream (%d ENOSTR)", errno);
            break;
        case ENODATA: // 61
            sprintf(msg, "No data available (%d ENODATA)", errno);
            break;
        case ETIME: // 62
            sprintf(msg, "Timer expired (%d ETIME)", errno);
            break;
        case ENOSR: // 63
            sprintf(msg, "Out of streams resources (%d ENOSR)", errno);
            break;
        case ENONET: // 64
            sprintf(msg, "Machine is not on the network (%d ENONET)", errno);
            break;
        case ENOPKG: // 65
            sprintf(msg, "Package not installed (%d ENOPKG)", errno);
            break;
        case EREMOTE: // 66
            sprintf(msg, "Object is remote (%d EREMOTE)", errno);
            break;
        case ENOLINK: // 67
            sprintf(msg, "Link has been severed (%d ENOLINK)", errno);
            break;
        case EADV: // 68
            sprintf(msg, "Advertise error (%d EADV)", errno);
            break;
        case ESRMNT: // 69
            sprintf(msg, "Srmount error (%d ESRMNT)", errno);
            break;
        case ECOMM: // 70
            sprintf(msg, "Communication error on send (%d ECOMM)", errno);
            break;
        case EPROTO: // 71
            sprintf(msg, "Protocol error (%d EPROTO)", errno);
            break;
        case EMULTIHOP: // 72
            sprintf(msg, "Multihop attempted (%d EMULTIHOP)", errno);
            break;
        case EDOTDOT: // 73
            sprintf(msg, "RFS specific error (%d EDOTDOT)", errno);
            break;
        case EBADMSG: // 74
            sprintf(msg, "Not a data message (%d EBADMSG)", errno);
            break;
        case EOVERFLOW: // 75
            sprintf(msg, "Value too large for defined data type (%d EOVERFLOW)", errno);
            break;
        case ENOTUNIQ: // 76
            sprintf(msg, "Name not unique on network (%d ENOTUNIQ)", errno);
            break;
        case EBADFD: // 77
            sprintf(msg, "File descriptor in bad state (%d EBADFD)", errno);
            break;
        case EREMCHG: // 78
            sprintf(msg, "Remote address changed (%d EREMCHG)", errno);
            break;
        case ELIBACC: // 79
            sprintf(msg, "Can not access a needed shared library (%d ELIBACC)", errno);
            break;
        case ELIBBAD: // 80
            sprintf(msg, "Accessing a corrupted shared library (%d ELIBBAD)", errno);
            break;
        case ELIBSCN: // 81
            sprintf(msg, ".lib section in a.out corrupted (%d ELIBSCN)", errno);
            break;
        case ELIBMAX: // 82
            sprintf(msg, "Attempting to link in too many shared libraries (%d ELIBMAX)", errno);
            break;
        case ELIBEXEC: // 83
            sprintf(msg, "Cannot exec a shared library directly (%d ELIBEXEC)", errno);
            break;
        case EILSEQ: // 84
            sprintf(msg, "Illegal byte sequence (%d EILSEQ)", errno);
            break;
        case ERESTART: // 85
            sprintf(msg, "Interrupted system call should be restarted (%d ERESTART)", errno);
            break;
        case ESTRPIPE: // 86
            sprintf(msg, "Streams pipe error (%d ESTRPIPE)", errno);
            break;
        case EUSERS: // 87
            sprintf(msg, "Too many users (%d EUSERS)", errno);
            break;
        case ENOTSOCK: // 88
            sprintf(msg, "Socket operation on non-socket (%d ENOTSOCK)", errno);
            break;
        case EDESTADDRREQ: // 89
            sprintf(msg, "Destination address required (%d EDESTADDRREQ)", errno);
            break;
        case EMSGSIZE: // 90
            sprintf(msg, "Message too long (%d EMSGSIZE)", errno);
            break;
        case EPROTOTYPE: // 91
            sprintf(msg, "Protocol wrong type for socket (%d EPROTOTYPE)", errno);
            break;
        case ENOPROTOOPT: // 92
            sprintf(msg, "Protocol not available (%d ENOPROTOOPT)", errno);
            break;
        case EPROTONOSUPPORT: // 93
            sprintf(msg, "Protocol not supported (%d EPROTONOSUPPORT)", errno);
            break;
        case ESOCKTNOSUPPORT: // 94
            sprintf(msg, "Socket type not supported (%d ESOCKTNOSUPPORT)", errno);
            break;
        case EOPNOTSUPP: // 95
            sprintf(msg, "Operation not supported on transport endpoint (%d EOPNOTSUPP)", errno);
            break;
        case EPFNOSUPPORT: // 96
            sprintf(msg, "Protocol family not supported (%d EPFNOSUPPORT)", errno);
            break;
        case EAFNOSUPPORT: // 97
            sprintf(msg, "Address family not supported by protocol (%d EAFNOSUPPORT)", errno);
            break;
        case EADDRINUSE: // 98
            sprintf(msg, "Address already in use (%d EADDRINUSE)", errno);
            break;
        case EADDRNOTAVAIL: // 99
            sprintf(msg, "Cannot assign requested address (%d EADDRNOTAVAIL)", errno);
            break;
        case ENETDOWN: // 100
            sprintf(msg, "Network is down (%d ENETDOWN)", errno);
            break;
        case ENETUNREACH: // 101
            sprintf(msg, "Network is unreachable (%d ENETUNREACH)", errno);
            break;
        case ENETRESET: // 102
            sprintf(msg, "Network dropped connection because of reset (%d ENETRESET)", errno);
            break;
        case ECONNABORTED: // 103
            sprintf(msg, "Software caused connection abort (%d ECONNABORTED)", errno);
            break;
        case ECONNRESET: // 104
            sprintf(msg, "Connection reset by peer (%d ECONNRESET)", errno);
            break;
        case ENOBUFS: // 105
            sprintf(msg, "No buffer space available (%d ENOBUFS)", errno);
            break;
        case EISCONN: // 106
            sprintf(msg, "Transport endpoint is already connected (%d EISCONN)", errno);
            break;
        case ENOTCONN: // 107
            sprintf(msg, "Transport endpoint is not connected (%d ENOTCONN)", errno);
            break;
        case ESHUTDOWN: // 108
            sprintf(msg, "Cannot send after transport endpoint shutdown (%d ESHUTDOWN)", errno);
            break;
        case ETOOMANYREFS: // 109
            sprintf(msg, "Too many references: cannot splice (%d ETOOMANYREFS)", errno);
            break;
        case ETIMEDOUT: // 110
            sprintf(msg, "Connection timed out (%d ETIMEDOUT)", errno);
            break;
        case ECONNREFUSED: // 111
            sprintf(msg, "Connection refused (%d ECONNREFUSED)", errno);
            break;
        case EHOSTDOWN: // 112
            sprintf(msg, "Host is down (%d EHOSTDOWN)", errno);
            break;
        case EHOSTUNREACH: // 113
            sprintf(msg, "No route to host (%d EHOSTUNREACH)", errno);
            break;
        case EALREADY: // 114
            sprintf(msg, "Operation already in progress (%d EALREADY)", errno);
            break;
        case EINPROGRESS: // 115
            sprintf(msg, "Operation now in progress (%d EINPROGRESS)", errno);
            break;
        case ESTALE: // 116
            sprintf(msg, "Stale NFS file handle (%d ESTALE)", errno);
            break;
        case EUCLEAN: // 117
            sprintf(msg, "Structure needs cleaning (%d EUCLEAN)", errno);
            break;
        case ENOTNAM: // 118
            sprintf(msg, "Not a XENIX named type file (%d ENOTNAM)", errno);
            break;
        case ENAVAIL: // 119
            sprintf(msg, "No XENIX semaphores available (%d ENAVAIL)", errno);
            break;
        case EISNAM: // 120
            sprintf(msg, "Is a named type file (%d EISNAM)", errno);
            break;
        case EREMOTEIO: // 121
            sprintf(msg, "Remote I/O error (%d EREMOTEIO)", errno);
            break;
        case EDQUOT: // 122
            sprintf(msg, "Quota exceeded (%d EDQUOT)", errno);
            break;
        case ENOMEDIUM: // 123
            sprintf(msg, "No medium found (%d ENOMEDIUM)", errno);
            break;
        case EMEDIUMTYPE: // 124
            sprintf(msg, "Wrong medium type (%d EMEDIUMTYPE)", errno);
            break;
            
        default:
        	sprintf(msg, "Error No: %d", errno);
        	break;
    }
}

void GetSignalStr(int sig_no, char* msg)
{
    // Get Signal Message
    switch (sig_no)
    {
        case SIGABRT:
            sprintf(msg, "���μ��� �ߴ�(abort) �ñ׳� (%d SIGABRT)", sig_no);
            break;
            
		case SIGALRM:
			sprintf(msg, "�˶� Ŭ�� (%d SIGALRM)", sig_no);
			break;
			
		case SIGBUS:
			sprintf(msg, "���� ���� (%d SIGBUS)", sig_no);
			break;
			
		case SIGCHLD:
			sprintf(msg, "�ڽ� ���μ����� �����ϰų� �ߴܵ��� (%d SIGCHLD)", sig_no);
			break;
			
		case SIGCONT:
			sprintf(msg, "���� �ߴܵ��� ��쿡�� ������ ����϶� (%d SIGCONT)", sig_no);
			break;
			
		case SIGFPE:
			sprintf(msg, "�ε��� ���� (%d SIHFPE)", sig_no);
			break;
			
		case SIGHUP:
			sprintf(msg, "Hangup Signal(Console is Closed?) (%d SIGHUP)", sig_no);
			break;
			
		case SIGILL:
			sprintf(msg, "�ҹ��� ���ɾ� (%d SIGILL)", sig_no);
			break;
			
		case SIGINT:
			sprintf(msg, "Interrupt(Ctrl+Pause?) (%d SIGINT)", sig_no);
			break;
			
		case SIGKILL:
			sprintf(msg, "Kill (%d SIGKILL)", sig_no);
			break;
			
		case SIGPIPE:
			sprintf(msg, "�������� ������ �������� ���Ͽ� ���� (%d SIGPIPE)", sig_no);
			break;
			
		case SIGPOLL:
			sprintf(msg, "�� ������(pollable) ��� (%d SIGPOLL)", sig_no);
			break;
			
		case SIGPROF:
			sprintf(msg, "���������ϴ� �ð��� ����Ǿ��� (%d SIGPROF)", sig_no);
			break;
			
		case SIGQUIT:
			sprintf(msg, "Quit (%d SIGQUIT)", sig_no);
			break;
			
		case SIGSEGV:
			sprintf(msg, "��ȿ���� ���� �޸� ���� (%d SIGSEGV)", sig_no);
			break;
			
		case SIGSTOP:
			sprintf(msg, "������ �ߴ��϶� (%d SIGSTOP)", sig_no);
			break;
			
		case SIGSYS:
			sprintf(msg, "��ȿ�� �ý��� ȣ�� (%d SIGSYS)", sig_no);
			break;
			
		case SIGTERM:
			sprintf(msg, "����Ʈ���� ���� �ñ׳�(kill?) (%d SIGTERM)", sig_no);
			break;
			
		case SIGTRAP:
			sprintf(msg, "Trace Trap (%d SIGTRAP)", sig_no);
			break;
			
		case SIGTSTP:
			sprintf(msg, "�ܸ��� �ߴ� �ñ׳� (%d SIGSTP)", sig_no);
			break;
			
		case SIGTTIN:
			sprintf(msg, "��׶��� ���μ����� �б⸦ �õ� (%d SIGTTIN)", sig_no);
			break;
			
		case SIGTTOU:
			sprintf(msg, "��׶��� ���μ����� ���⸦ �õ� (%d SIGTTOU)", sig_no);
			break;
			
		case SIGURG:
			sprintf(msg, "���Ͽ� ���� �뿪���� �ڷᰡ �̿밡���� (%d SIGURG)", sig_no);
			break;
			
		case SIGUSR1:
			sprintf(msg, "User Signal 1 (%d SIGUSR1)", sig_no);
			break;
			
		case SIGUSR2:
			sprintf(msg, "User Signal 2 (%d SIGUSR2)", sig_no);
			break;
			
		case SIGVTALRM:
			sprintf(msg, "���� Ÿ�̸Ӱ� ������ (%d SIGVTALRM)", sig_no);
			break;
			
		case SIGXCPU:
			sprintf(msg, "CPU �ð� ������ �ʰ����� (%d SIGXCPU)", sig_no);
			break;
		
		case SIGXFSZ:
			sprintf(msg, "���� ũ�� ������ �ʰ����� (%d SIGXFSZ)", sig_no);
			break;
			
		default:
			sprintf(msg, "Signal No: %d", sig_no);
			break;
    }
}

#endif
