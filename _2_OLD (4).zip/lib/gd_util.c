#include <stdio.h>
#include <math.h>
#include <gd.h>
#include <gdfontg.h>
#include <gdfontl.h>
#include <gdfontmb.h>
#include <gdfonts.h>
#include <gdfontt.h>
#include "disp.h"

/**************************************************************************
*
*  �⺻���� �ۼ�
*
**************************************************************************/

void    base_map(im,filename,gis_x1,gis_y1,gis_x2,gis_y2,map_color)

gdImagePtr  im;
char        filename[];                     /* GIS ���ϸ� */
float       gis_x1,gis_y1,gis_x2,gis_y2;    /* ǥ���� �������� ���� */
int         map_color;                      /* �⺻ �������� Į��� */
{
    FILE    *fd;
    int     n, code;
    float   x, y;
    int     gif_sx, gif_sy;
    float   angle_x, angle_y;
    int     xp1, yp1, xp2, yp2;
    int     i, mode;

    gif_sx = gdImageSX(im) - LEVEL_pixel;
    gif_sy = gdImageSY(im) - TITLE_pixel;
    angle_x = (float)gif_sx / (gis_x2 - gis_x1);
    angle_y = (float)gif_sy / (gis_y2 - gis_y1);

    fd  = fopen(filename,"r");
    if (fd != NULL) {
        while(fscanf(fd, "%d %d", &n, &code) != EOF) {
            mode = 0;
            fscanf(fd, "%f %f", &x, &y);
            if ( (y >= gis_y1 && y <= gis_y2) && (x >= gis_x1 && x <= gis_x2) ) {
                mode = 1;
                xp1 = angle_x * (x - gis_x1);
                yp1 = angle_y * (y - gis_y1) + TITLE_pixel;
            }

            for(i=1; i<n; i++) {
                fscanf(fd, "%f %f", &x, &y);
                if ( (y >= gis_y1 && y <= gis_y2) && (x >= gis_x1 && x <= gis_x2) ) {
                    xp2 = angle_x * (x - gis_x1);
                    yp2 = angle_y * (y - gis_y1) + TITLE_pixel;
                    if (mode == 1)
                        gdImageLine(im, xp1, yp1, xp2, yp2, map_color);
                    xp1 = xp2;
                    yp1 = yp2;
                    mode = 1;
                } else {
                    mode = 0;
                }
            }
        }
        fclose(fd);
    }
}

/**************************************************************************
*
*  ��
*
**************************************************************************/

void    FilledCircle(im, cx, cy, r, color)

gdImagePtr  im;
int         cx, cy;
int         r;
int         color;
{
    int     i;

    for(i=0; i<=r; i++) {
        gdImageArc(im, cx, cy, 2*i, 2*i, 0, 360, color);
    }
}

/**************************************************************************
*
*  � ��ġ�� ���� �ٰ����ȿ� �ִ��� �ۿ� �ִ��� �Ǵ��ϴ� ���α׷�
*
*      (�ٰ��� ���̸� 1, ���̸� 0)
*
**************************************************************************/

#define X 0
#define Y 1

int pointinpoly(point, pgon, num_pgon)

double point[2];
double pgon[][2];
int    num_pgon;
{
    int i, numverts, inside_flag, xflag0;
    int crossings;
    double *p, *stop;
    double tx, ty, y;

    for(i=0; pgon[i][X] != -1 && i < num_pgon; i++);

    numverts = i;
    crossings = 0;

    tx = point[X];
    ty = point[Y];

    y = pgon[numverts - 1][Y];

    p = (double *)pgon + 1;
    if ((y >= ty) != (*p >= ty)) {
        if ((xflag0 = (pgon[numverts - 1][X] >= tx)) == (*(double *)pgon >= tx)) {
            if (xflag0) crossings++;
        }
        else {
            crossings += (pgon[numverts - 1][X] - (y - ty) * (*(double *)pgon
                            - pgon[numverts - 1][X]) / (*p - y)) >= tx;
        }
    }

    stop = pgon[numverts];

    for(y = *p, p += 2; p < stop; y = *p, p += 2) {
        if (y >= ty) {
            while((p < stop) && (*p >= ty)) p += 2;
            if (p >= stop) break;
            if ((xflag0 = (*(p - 3) >= tx)) == (*(p - 1) >= tx)) {
                if (xflag0) crossings++;
            }
            else {
                crossings += (*(p - 3) - (*(p - 2) - ty) * (*(p - 1) - *(p - 3)) /
                             (*p - *(p - 2))) >= tx;
            }
        }
        else {
            while((p < stop) && (*p < ty)) p += 2;
            if (p >= stop) break;
            if ((xflag0 = (*(p - 3) >= tx)) == (*(p - 1) >= tx)) {
                if (xflag0) crossings++;
            }
            else {
                crossings += (*(p - 3) - (*(p - 2) - ty) * (*(p - 1) - *(p - 3)) /
                             (*p - *(p - 2))) >= tx;
            }
        }
    }

    inside_flag = crossings & 0x01;
    return(inside_flag);
}

/**************************************************************************
*
*  �⺻����
*
**************************************************************************/

void legend (im, xs, ys, lx, ly, n, value, color)

gdImagePtr  im;
int         xs, ys;
int         lx, ly;
int         n;
float       value[];
int         color[];
{
    int     black, white;
    int     i;
    int     y1, y2;
    float   dy;
    char    label[5];
    unsigned char  gd_label[5];

    black = gdImageColorAllocate(im, 0, 0, 0);
    white = gdImageColorAllocate(im, 255, 255, 255);

    dy = (float)(ly)/(float)(n+1);

    for(i = 0; i <= n; i++) {
        y1 = (int)(dy * i);
        y2 = (int)(dy * (i + 1));
        gdImageFilledRectangle(im, xs, y1, xs+lx, y2, color[i]);
        gdImageRectangle(im, xs, y1, xs+lx, y2, black);
    }

    for(i = 0; i < n; i++) {
        y1 = (int)((dy * i) + 5.0);
        sprintf(label, "%3d", (int)value[i]);
/*        gdImageString(im, gdFontSmall, xs+5, y1, (unsigned char)label, black);*/
/*        gdImageString(im, gdFontSmall, xs+5, y1, "11", black);*/
    }
}

/**************************************************************************
 *
 *  ��ȯ : {U,S,L} color  --> {R,G,B} color
 *
 **************************************************************************/
struct COLOR USL2RGB(U,S,L)
    int  U, S, L;
{
    struct COLOR rgb;
    float  L1;
    float  Max, Min;
    int    C[3];
    int    i, v;

    L1 = (255.0 - (float)L) * 0.5;

    if (S < 128)
    {
        Max = (255.0 - L1) / 127.0 * (float)S;
        Min = L1 / 127.0 * (float)S;
    }
    else
    {
        Min = 255.0 - (255.0 - L1) * (255.0 - (float)S) / 127.0;
        Max = 255.0 - L1 * (255.0 - (float)S) / 127.0;
    }

    for (i = 0; i < 3; i++)
    {
        if (i == 0)
            v = (U + 85) % 256;
        else if (i == 1)
            v = U;
        else
            v = (U + 170) % 256;

        if (v <= 42)
            C[i] = (int)( (Max - Min) * (float)v / 42.0 + Min );
        else if (v <= 127)
            C[i] = (int)Max;
        else if (v <= 170)
            C[i] = (int)( (Min - Max) * ((float)v - 127.0) / 43.0 + Max );
        else
            C[i] = (int)Min;
    }
    rgb.R = C[0];
    rgb.G = C[1];
    rgb.B = C[2];
    return rgb;
}

/**************************************************************************
*
*  ��ȯ : {H,S,L} color  --> {R,G,B} color
*
**************************************************************************/

struct COLOR HSL2RGB(H,S,L)

int  H, S, L;
{
    struct COLOR rgb;
    float S1;
    float Max, Min;
    int   C[3];
    int   i, v;

    S1 = (255.0 - (float)S) * 0.5;
    if (L < 128) {
        Max = (255.0 - S1) / 127.0 * (float)L;
        Min = S1 / 127.0 * (float)L;
    } else {
        Min = 255.0 - (255.0 - S1) * (255.0 - (float)L) / 127.0;
        Max = 255.0 - S1 * (255.0 - (float)L) / 127.0;
    }

    for(i = 0; i < 3; i++) {
        if (i == 0)
            v = (H + 85) % 256;
        else if (i == 1)
            v = H;
        else
            v = (H + 170) % 256;

        if (v <= 42)
            C[i] = (int)( (Max - Min) * (float)v / 42.0 + Min );
        else if (v <= 127)
            C[i] = (int)Max;
        else if (v <= 170)
            C[i] = (int)( (Min - Max) * ((float)v - 127.0) / 43.0 + Max );
        else
            C[i] = (int)Min;
    }
    rgb.R = C[0];
    rgb.G = C[1];
    rgb.B = C[2];
    return rgb;
}
