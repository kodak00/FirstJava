#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

/*---------------------------------------------------------------------------*/
/*  ȯ�溯�� ����                                                            */
/*---------------------------------------------------------------------------*/
int tibero_env_set()
{
    putenv("TB_HOME=/app_sw/tbclient");
    putenv("LD_LIBRARY_PATH=/app_sw/tbclient/client/lib:/usr/lib:/usr/local/lib:/usr/local/trmm/lib:/app_sw/tbclient/lib");
    putenv("PATH=/usr/lib64/qt-3.3/bin:/usr/kerberos/sbin:/usr/kerberos/bin:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/local/oracle/client/11g/bin:/home/obs/bin:/usr/local/php/bin:.");
    putenv("TB_PROF_DIR=/app_sw/tbclient/bin/prof");
    putenv("TB_SID=COMIS");
    putenv("TB_USER=afs@COMIS");
    putenv("TB_PW=afs");
    return 0;
}
