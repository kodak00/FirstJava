/*******************************************************************************
**
**  �����ڷ� ó�� ����
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2019.6.29)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "cgiutil.h"
#include "nrutil.h"

#define  MAP_INI_FILE   "/rdr/REF/MAP/map.ini"  // �������� ��������

// �����ڷ��� ���� ����
struct GRID_MAP {
  int   nx, ny;   // �迭ũ�� [0:ny][0:nx]
  float sx, sy;   // ������ ��ġ(���ڰŸ�)
  float grid;     // ���ڰ���(km)
};

/*=============================================================================*
 *  �ٸ� ������ �ٸ� ���ڰ��ݰ��� ���� ��ȯ
 *=============================================================================*/
int Grid_intp1(
  struct GRID_MAP gm1,  // ��ȯ�� ���ڿ���
  struct GRID_MAP gm2,  // ��ȯ�� ���ڿ���
  float **g1,     // ��ȯ�� �ڷ�
  float **g2,     // ��ȯ�� �ڷ�
  float missing   // ���°�
)
{
  float rate, xo, yo;
  float *p, dv[4];
  float x1, y1, dx, dy;
  int   i, j, k, i1, j1;

  // 0. �ʱ�ȭ
  for (j = 0; j <= gm2.ny; j++) {
    for (i = 0; i <= gm2.nx; i++)
      g2[j][i] = missing;
  }

  // 1. ��ȯ��
  rate = gm2.grid/gm1.grid;
  yo = gm1.sy - gm2.sy*rate;
  xo = gm1.sx - gm2.sx*rate;

  // 2. Y��
  for (j = 0; j <= gm2.ny; j++) {
    y1 = j*rate + yo;
    j1 = (int)(y1);
    if (j1 < 0 || j1 > gm1.ny) continue;
    dy = y1 - j1;

    // 3. X��
    for (i = 0; i <= gm2.nx; i++) {
      x1 = i*rate + xo;
      i1 = (int)(x1);
      if (i1 < 0 || i1 > gm1.nx) continue;
      dx = x1 - i1;

      // 4.1. �׵θ�
      if (j == gm2.ny || j1 == gm1.ny) {
        if (i1 < gm1.nx)
          g2[j][i] = g1[j1][i1]*(1.0-dx) + g1[j1][i1+1]*dx;
        else
          g2[j][i] = g1[j1][i1];
      }
      else if (i == gm2.nx || i1 == gm1.nx) {
        if (j1 < gm1.ny)
          g2[j][i] = g1[j1][i1]*(1.0-dy) + g1[j1+1][i1]*dy;
        else
          g2[j][i] = g1[j1][i1];
      }

      // 4.2. 4�� ����
      else if (i1 >= 1 && i1 <= gm1.nx-2 && j1 >= 1 && j1 <= gm1.ny-2) {
        for (k = 0; k < 4; k++) {
          p = &g1[j1+k-1][i1];
          dv[k] = *p + dx*(*(p+1) - *p + 0.25*(dx-1.0)*(*(p-1) - *p - *(p+1) + *(p+2)) );
        }
        g2[j][i] = dv[1] + dy*(dv[2] - dv[1] + 0.25*(dy-1.0)*(dv[0] - dv[1] - dv[2] + dv[3]) );
      }

      // 4.3. 2�� ����(��������)
      else if (i1 < 1 || i1 >= gm1.nx-1 || j1 < 1 || j1 >= gm1.ny-1) {
        dv[0] = g1[j1][i1]*(1.0-dx) + g1[j1][i1+1]*dx;
        dv[1] = g1[j1+1][i1]*(1.0-dx) + g1[j1+1][i1+1]*dx;
        g2[j][i] = dv[0]*(1.0-dy) + dv[1]*dy;
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  ���� ������ �ٸ� ���ڰ��ݰ��� ���� ��ȯ
 *=============================================================================*/
int Grid_intp2(
  int   nx1,  // ��ȯ�� ���ڿ���
  int   ny1,  // [0:ny1][0:nx1]
  int   nx2,  // ��ȯ�� ���ڿ���
  int   ny2,  // [0:ny2][0:nx2]
  float **g1, // ��ȯ�� �ڷ�
  float **g2  // ��ȯ�� �ڷ�
)
{
  float rate_x, rate_y;
  float *p, dv[4];
  float x1, y1, dx, dy;
  int   i, j, k, i1, j1;

  // 1. ��ȯ��
  rate_y = (float)ny1/(float)ny2;
  rate_x = (float)nx1/(float)nx2;

  // 2. Y��
  for (j = 0; j <= ny2; j++) {
    y1 = j*rate_y;
    j1 = (int)(y1);
    if (j1 < 0 || j1 > ny1) continue;
    dy = y1 - j1;

    // 3. X��
    for (i = 0; i <= nx2; i++) {
      x1 = i*rate_x;
      i1 = (int)(x1);
      if (i1 < 0 || i1 > nx1) continue;
      dx = x1 - i1;

      // 4.1. �׵θ�
      if (j == ny2 || j1 == ny1) {
        g2[j][i] = g1[j1][i1]*(1.0-dx) + g1[j1][i1+1]*dx;
      }
      else if (i == nx2 || i1 == nx1) {
        g2[j][i] = g1[j1][i1]*(1.0-dy) + g1[j1+1][i1]*dy;
      }

      // 4.2. 4�� ����
      else if (i1 >= 1 && i1 <= nx1-2 && j1 >= 1 && j1 <= ny1-2) {
        for (k = 0; k < 4; k++) {
          p = &g1[j1+k-1][i1];
          dv[k] = *p + dx*(*(p+1) - *p + 0.25*(dx-1.0)*(*(p-1) - *p - *(p+1) + *(p+2)) );
        }
        g2[j][i] = dv[1] + dy*(dv[2] - dv[1] + 0.25*(dy-1.0)*(dv[0] - dv[1] - dv[2] + dv[3]) );
      }

      // 4.3. 2�� ����(��������)
      else if (i1 < 1 || i1 >= nx1-1 || j1 < 1 || j1 >= ny1-1) {
        dv[0] = g1[j1][i1]*(1.0-dx) + g1[j1][i1+1]*dx;
        dv[1] = g1[j1+1][i1]*(1.0-dx) + g1[j1+1][i1+1]*dx;
        g2[j][i] = dv[0]*(1.0-dy) + dv[1]*dy;
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  Grid data Smoothing (by 1-2-1 Smoothing) .. missing�� �ִ� ���
 *=============================================================================*/
int Grid_sms121(
  int   nx,   // ���� [0:nx,0:ny]
  int   ny,
  float **g,  // input -> output
  float missing   // �� �� ���ϴ� �ڷ� ����
)
{
  float  *vv, *p1, *p2, *p3, e1, e2;
  int    i, j;

  for (j = 0; j <= ny; j++) {
    p1 = &g[j][0];
    p2 = &g[j][1];
    p3 = &g[j][2];
    e1 = g[j][0];

    for (i = 1; i < nx; i++, p1++, p2++, p3++) {
      if (*p1 <= missing || *p3 <= missing)
        e2 = *p2;
      else {
        if (*p2 <= missing)
          e2 = (*p1 + *p3)*0.5;
        else
          e2 = (*p1 + 2*(*p2) + *p3)*0.25;
      }
      *p1 = e1;
      e1 = e2;
    }
    g[j][nx-1] = e1;
  }

  vv = vector(0, nx);
  for (j = 1; j < ny; j++) {
    p1 = &g[j-1][0];
    p2 = &g[j][0];
    p3 = &g[j+1][0];

    for (i = 0; i <= nx; i++, p1++, p2++, p3++) {
      if (*p1 <= missing || *p3 <= missing)
        e2 = *p2;
      else {
        if (*p2 <= missing)
          e2 = (*p1 + *p3)*0.5;
        else
          e2 = (*p1 + 2*(*p2) + *p3)*0.25;
      }
      if (j > 1) *p1 = vv[i];
      vv[i] = e2;
    }
  }
  for (p1 = &g[ny-1][0], i = 0; i <= nx; i++, p1++)
    *p1 = vv[i];
  free_vector(vv, 0, nx);
  return 0;
}

/*=============================================================================*
 *  Grid data Smoothing (by 1-2-1 Smoothing) .. missing�� ���� ���
 *=============================================================================*/
int Grid_sms121a(
  int   nx,   // ���� [0:nx,0:ny]
  int   ny,
  float **g   // input -> output
)
{
  float  *vv, *p1, *p2, *p3, e1, e2;
  int    i, j;

  for (j = 0; j <= ny; j++) {
    p1 = &g[j][0];
    p2 = &g[j][1];
    p3 = &g[j][2];
    e1 = g[j][0];

    for (i = 1; i < nx; i++, p1++, p2++, p3++) {
      e2 = (*p1 + 2*(*p2) + *p3)*0.25;
      *p1 = e1;
      e1 = e2;
    }
    g[j][nx-1] = e1;
  }

  vv = vector(0, nx);
  for (j = 1; j < ny; j++) {
    p1 = &g[j-1][0];
    p2 = &g[j][0];
    p3 = &g[j+1][0];

    for (i = 0; i <= nx; i++, p1++, p2++, p3++) {
      e1 = (*p1 + 2*(*p2) + *p3)*0.25;
      if (j > 1) *p1 = vv[i];
      vv[i] = e1;
    }
  }
  for (p1 = &g[ny-1][0], i = 0; i <= nx; i++, p1++)
    *p1 = vv[i];
  free_vector(vv, 0, nx);
  return 0;
}

/*=============================================================================*
 *  Grid data Smoothing (by 1-1-1 Smoothing) .. missing�� ���� ���
 *=============================================================================*/
int Grid_sms111a(
  int   nx,   // ���� [0:nx,0:ny]
  int   ny,
  float **g   // input -> output
)
{
  float  *vv, *p1, *p2, *p3, e1, e2;
  int    i, j;

  for (j = 0; j <= ny; j++) {
    p1 = &g[j][0];
    p2 = &g[j][1];
    p3 = &g[j][2];
    e1 = g[j][0];

    for (i = 1; i < nx; i++, p1++, p2++, p3++) {
      e2 = (*p1 + *p2 + *p3)/3;
      *p1 = e1;
      e1 = e2;
    }
    g[j][nx-1] = e1;
  }

  vv = vector(0, nx);
  for (j = 1; j < ny; j++) {
    p1 = &g[j-1][0];
    p2 = &g[j][0];
    p3 = &g[j+1][0];

    for (i = 0; i <= nx; i++, p1++, p2++, p3++) {
      e1 = (*p1 + *p2 + *p3)/3;
      if (j > 1) *p1 = vv[i];
      vv[i] = e1;
    }
  }
  for (p1 = &g[ny-1][0], i = 0; i <= nx; i++, p1++)
    *p1 = vv[i];
  free_vector(vv, 0, nx);
  return 0;
}

/*=============================================================================*
 *  ���� ���� ���� �б�
 *
 *      map : inp:������ ����
 *      nx  : out:�������� �������� (km)
 *      ny  : out:���Ϲ��� �������� (km)
 *      sx  : out:�������� ������ġ (km)
 *      sy  : out:���Ϲ��� ������ġ (km)
 *=============================================================================*/
int grid_map_inf(char *map, float *nx, float *ny, float *sx, float *sy)
{
  FILE  *fp;
  char  buf[1024], map_list[8], value[16];

  fp = fopen(MAP_INI_FILE,"r");
  if (fp == NULL) exit(-1);

  while (fgets(buf,1024,fp)) {
    if (buf[0] == '#') continue;
    getword(map_list, buf, ':');

    if ( !strcmp(map, map_list) ) {
      getword(value, buf, ':');  *nx = atof(value);
      getword(value, buf, ':');  *ny = atof(value);
      getword(value, buf, ':');  *sx = atof(value);
      getword(value, buf, ':');  *sy = atof(value);
      break;
    }
  }
  fclose(fp);
  return 0;
}