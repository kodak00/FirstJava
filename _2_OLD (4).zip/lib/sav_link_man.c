/******************************************************************
 *
 *  dst_main�� ���� �ڷ�ó���� ó���� ���ϸ�� ó�� (MAIN) - ����
 *
 *================================================================*
 *
 *     o �ۼ��� : ����ȯ (2002.11.4)
 *
 ******************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>
#include "comn.h"

#define LOG_DIR    "/LOGD/RECV"        /* �α� ���丮 */

FILE  *log_open();
FILE  *fd_log;                               /* Log File fd */
int   YYg, MMg, HHg, DDg, HHg, MIg, SSg;
char  msg_ini[256];


int main(int argc, char *argv[])
{
    struct FILE_OUT ft;
    char   out[512],fname[512],nic[16];
    int    code;
    
    if (argc != 3)
    {
        printf("Error -> Correct arguments : [%s <nic> <FIle_name>] \n", argv[0]);
        exit(0);
    }

    memset(out, 0, sizeof(out));
    memset(fname, 0, sizeof(fname));
    
    strcpy(nic, argv[1]);
    strcpy(fname, argv[2]);

    /* Log File Open */
    fd_log = log_open(LOG_DIR, argv[0]);
    
    get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);
                
    /* ���� ó�� */
    ft.seq = 10;
    time( &ft.tm );
    strcpy(ft.fname, fname);
    
    code = file_link(nic, ft);
    sprintf(out, "%s, %s (%d)\n",nic, fname, code);
    fputs(out, stdout);
        
    /* Log File Close */
    fclose(fd_log);

    return 0;
}
