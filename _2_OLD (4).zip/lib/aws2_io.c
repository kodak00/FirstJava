#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "aws_data.h"
#include "aws2_data.h"

#define  MAXLINE  1024
//#define  AWS2_DIR  "/DATA/AWS2/AWSDB"
//#define  AWS2_DIR  "/C4N_DATA/DATA/AWS/AWSDB"
#define  AWS2_DIR  "/C4N2_DATA/AWS/AWSDB"

unsigned getbit(unsigned, int);
unsigned setbit(unsigned, int, unsigned);
unsigned long aws2_getbit_long(unsigned long, int);
unsigned long aws2_setbit_long(unsigned long, int, unsigned long);
void aws2io_error();

/*****************************************************************************
 *
 *  �ظ����
 *
 *****************************************************************************/
float
aws2_slp
(
    float  p,       /* �������(hPa) */
    float  t,       /* ���(C)       */
    float  h,       /* ��������(m)   */
    float  lat      /* ����(deg.)    */
)
{
    float  e[16] = {0.1, 0.1, 0.1, 0.2, 0.3, 0.4, 0.5, 0.7, 1.0, 1.4,
                    2.1, 2.8, 3.2, 3.3, 3.3, 3.3};
    float  tm, em;
    float  cs, g, sp;
    int    j;

    if (p < 500.0 || p > 1200.0) return -99.9;

    lat *= asin(1.0) / 90.0;
    cs = cos(2.0*lat);
    g  = 980.616 * (1.0 - 0.00263*cs + 0.0000059*cs*cs) - 0.0003086*h;
    g *= 0.01;

    if (t > -40 && t < 45)
    {
        tm = t + 0.0025*h;

        j = (int)((tm+30.0)/5.0);

        if (j < 0)        em = 0.1;
        else if (j > 15)  em = 3.3;
        else              em = e[j] + (e[j+1] - e[j])*(tm+30.0-j*5.0);

        sp = g*h/(287.04*(273.16+tm+em));
        sp = p*exp(sp);
    } else {
        sp = -99.9;
    }
    return sp;
}

/*****************************************************************************
 *
 *  AWSM �ڷῡ�� � ����Ͻú��� AWS �ź��ڷḦ ó��
 *
 *****************************************************************************/
int
AWSM2_IO
(
    int    YY,                  /* �� */
    int    MM,                  /* �� */
    int    DD,                  /* �� */
    int    HH,                  /* �� */
    int    MI,                  /* �� */
    int    aws_id,              /* aws_id > -1 (�ش�����), aws_id = -1 (��ü����) */
    struct AWS2_DATA  aws[],    /* AWS �ڷ� */
    char   mode                 /* 'r' : �б� (���� 0, ���� < 0) */
                                /* 'w' : ���� (���� 0, ���� < 0) */
                                /* 'c' : ���ϴݱ� */
)
{
    static FILE  *fd;
    static int   fnode = -1;
    static char  rw = 'r';
    long   offset = 0;
    char   dname[120], tmp[MAXLINE];
    int    node, nstn, nio, code;

    /*
    File Close & ID range check
    */

    if (mode == 'c')
    {
        if (fd != NULL) fclose(fd);
        fd = NULL;
        fnode = -1;
        rw = 'r';
        return 0;
    }
    if (aws_id >= NUM_AWS2) aws_id %= NUM_AWS2;

    /*
    File Open
    */

    node = ((YY*100 + MM)*100 + DD)*100 + HH;
    if (node != fnode || (rw != 'w' && mode == 'w'))
    {
        if (fd != NULL) fclose(fd);
        if (rw != 'w' && mode == 'w') rw = mode;

        sprintf(dname, "%s/%04d%02d/%02d/AWSM_%04d%02d%02d%02d", AWS2_DIR, YY, MM, DD, YY, MM, DD, HH);

        if (rw == 'w')
            fd = fopen(dname, "rb+");
        else
            fd = fopen(dname, "rb");

        if (fd == NULL)
        {
            sprintf(tmp, "[ AWSM ] File not opened (%s,%c)", dname, rw);
            aws2io_error(&fnode, &offset, tmp);
            return -1;
        }
        else
        {
            fnode = node;
        }
    }

    /*
    Move to Read Pointer
    */

    offset = MI * NUM_AWS2 * AWS2_DATA_len;
    if (aws_id < 0)
    {
        nstn = NUM_AWS2;
    }
    else
    {
        offset += aws_id * AWS2_DATA_len;
        nstn = 1;
    }

    if (fseek(fd, offset, SEEK_SET) != 0)
    {
        sprintf(tmp, "[ AWSM ] fseek error (%s,%d)", dname, offset);
        aws2io_error(&fnode, &offset, tmp);
        return -3;
    }

    /*
    Data Read & Write
    */
   
    if      (mode == 'r') nio = fread(aws, AWS2_DATA_len, nstn, fd);
    else if (mode == 'w') nio = fwrite(aws, AWS2_DATA_len, nstn, fd);

    if (nio != nstn)
    {
        sprintf(tmp, "[ AWSM ] IO error (%c,%04d%02d%02d%02d%02d_%d)",
                mode, YY, MM, DD, HH, MI, aws_id);
        aws2io_error(&fnode, &offset, tmp);
        return -4;
    }
    return 0;
}

/*****************************************************************************
 *
 *  QC�ڷḦ ������ AWS �����ڷḦ MASKING �ϴ� ��ƾ
 *
 *****************************************************************************/
int
AWS2_QCD
(
    struct AWS2_DATA  aws[]
)
{
    char qcd[AWS2_DATA_dnum];
    unsigned long q;
    int  i, j, k;

    for (k = 0; k < 8; k++)
    {
        if (k == 2 || k >= 4) continue;     /* RQMOD ���� �̻��Ͽ� ������ */

        q = aws[0].qc[k];

        for (i = 0; i < AWS2_DATA_dnum; i++)
        {
            qcd[i] = q & 0x0000000000000001;
            q = q >> 1;
        }

        for (i = 0; i < AWS2_DATA_dnum; i++)
        {
            if (qcd[i] == 1)
            {
                aws[0].d[i] = -998 + k;
            }
        }
    }
    return 0;
}

/*****************************************************************************
 *  AWSM �ڷῡ�� � ����Ͻú��� AWS �ź��ڷḦ ����
 *  - �ڷᰡ ���� ���, ���� 5�а��� �ڷῡ�� ã����, �������� �Ѿ�� ����
 *  - �߰� : ����ȯ(2014.7.7)
 *****************************************************************************/
int
QAWSM2_IO
(
    int    YY,                  /* �� */
    int    MM,                  /* �� */
    int    DD,                  /* �� */
    int    HH,                  /* �� */
    int    MI,                  /* �� */
    int    aws_id,              /* AWS ID (1�� ������ ����) */
    struct AWS2_DATA  aws[],    /* AWS �ڷ� */
    char   mode                 /* 'q' : �ش�ð��� �ڷḸ ���� (���� 0, ���� < 0)  */
                                /* 'r' : ���� 5�а��� �ڷῡ�� ���� (���� 0, ���� < 0) */
)
{
    struct AWS2_DATA  aws1[1];
    int    code = -1;
    int    seq, seq1, seq2, i;

    // 1. ID ���� ����
    if (aws_id < 0) return -2;

    // 2. �ش� �ð��� �ڷḦ ����
    code = AWSM2_IO(YY, MM, DD, HH, MI, aws_id, aws, 'r');
    if (code >= 0) AWS2_QCD(&aws[0]);
    if (mode == 'q' || code >= 0) return code;

    // 3. ���� ���, ���� 5�е��ȿ��� �ڷḦ ã��
    seq1 = time2seq(YY, MM, DD, HH, MI, 'm') - 1;
    seq2 -= 4;
    if (HH*60+MI <= 5) seq2 = seq1 - MI + 1;

    for (seq = seq1; seq >= seq2; seq--) {
        seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
        code = AWSM2_IO(YY, MM, DD, HH, MI, aws_id, &aws[0], 'r');
        if (code >= 0) {
            AWS2_QCD(&aws[0]);
            break;
        }
    }
    return code;
}

/*****************************************************************************
 *
 *  AWSM �ڷῡ�� � ����Ͻú��� AWS �ź��ڷḦ ����
 *
 *****************************************************************************/
int
QAWSM2_READ
(
    int    YY,                  /* �� */
    int    MM,                  /* �� */
    int    DD,                  /* �� */
    int    HH,                  /* �� */
    int    MI,                  /* �� */
    int    aws_id,              /* AWS ID (1�� ������ ����) */
    struct AWS2_DATA  aws[],    /* AWS �ڷ� */
    char   mode                 /* 'q' : �ش�ð��� �ڷḸ ���� (���� 0, ���� < 0)  */
                                /* 'r' : ���� 5�а��� �ڷῡ�� ���� (���� 0, ���� < 0) */
)
{
    struct AWS2_DATA  aws1[5];
    int    d[5], code = -1;
    int    seq, i;

    /*
    ID ���� ����
    */

    if (aws_id < 0) return -2;

    /*
    �ش� �ð� ����
    */

    code = AWSM2_IO(YY, MM, DD, HH, MI, aws_id, aws, 'r');
    if (code >= 0) AWS2_QCD(&aws[0]);
    if (mode == 'q' || code >= 0) return code;

    /*
    ���� ���, ���� 5�е��ȿ��� �ڷḦ ã��
    */

    seq = time2seq(YY, MM, DD, HH, MI, 'm') - 5;

    for (i = 4; i >= 0; i--)
    {
        seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
        code = AWSM2_IO(YY, MM, DD, HH, MI, aws_id, &aws1[i], 'r');

        d[i] = 0;
        if (code >= 0) d[i] = 1;
        seq++;
    }

    code = -1;
    for (i = 0; i < 5; i++)
    {
        if (d[i])
        {
            aws[0] = aws1[i];
            AWS2_QCD(&aws[0]);
            code = 0;
            break;
        }
    }
    return code;
}

/*****************************************************************************
 *
 *  AWSD �ڷῡ�� � ������� AWS ���ڷḦ ó��
 *
 *****************************************************************************/
int
AWSD2_IO
(
    int    YY,                  /* �� */
    int    MM,                  /* �� */
    int    DD,                  /* �� */
    int    aws_id,              /* aws_id > -1 (�ش�����), aws_id = -1 (��ü����) */
    struct AWS2_DAY  aws[],     /* AWS ���ڷ� */
    char   mode                 /* 'r' : �б� (���� 0, ���� < 0) */
                                /* 'w' : ���� (���� 0, ���� < 0) */
                                /* 'c' : ���ϴݱ� */
)
{
    static FILE  *fd;
    static int   fnode = -1;
    static char  rw = 'r';
    long   offset = 0;
    char   dname[120], tmp[MAXLINE];
    int    node, nstn, nio, code;

    /*
    File Close & ID range check
    */

    if (mode == 'c')
    {
        if (fd != NULL) fclose(fd);
        fd = NULL;
        fnode = -1;
        rw = 'r';
        return 0;
    }
    if (aws_id >= NUM_AWS2) aws_id %= NUM_AWS2;

    /*
    File Open
    */

    node = (YY*100 + MM)*100 + DD;
    if (node != fnode || (rw != 'w' && mode == 'w'))
    {
        if (fd != NULL) fclose(fd);
        if (rw != 'w' && mode == 'w') rw = mode;

        sprintf(dname, "%s/%04d%02d/%02d/AWSD_%04d%02d%02d", AWS2_DIR, YY, MM, DD, YY, MM, DD);

        if (rw == 'w')
            fd = fopen(dname, "rb+");
        else
            fd = fopen(dname, "rb");

        if (fd == NULL)
        {
            sprintf(tmp, "[ AWSD ] File not opened (%s,%c)", dname, rw);
            aws2io_error(&fnode, &offset, tmp);
            return -1;
        }
        else
        {
            fnode = node;
        }
    }

    /*
    Move to Read Pointer
    */

    if (aws_id < 0)
    {
        offset = 0;
        nstn = NUM_AWS2;
    }
    else
    {
        offset = aws_id * AWS2_DAY_len;
        nstn = 1;
    }

    if (fseek(fd, offset, SEEK_SET) != 0)
    {
        sprintf(tmp, "[ AWSD ] fseek error (%s,%d)", dname, offset);
        aws2io_error(&fnode, &offset, tmp);
        return -3;
    }

    /*
    Data Read & Write
    */

    if      (mode == 'r') nio = fread(aws, AWS2_DAY_len, nstn, fd);
    else if (mode == 'w') nio = fwrite(aws, AWS2_DAY_len, nstn, fd);

    if (nio != nstn)
    {
        sprintf(tmp, "[ AWSD ] IO error (%c,%04d%02d%02d_%d)",
                mode, YY, MM, DD, aws_id);
        aws2io_error(&fnode, &offset, tmp);
        return -4;
    }
    return 0;
}

/*****************************************************************************
 *
 *  AWS �ź� �� �����ڷ� �ʱ�ȭ
 *
 *    o ID, ������ : -999,  �ð� : 0
 *
 *****************************************************************************/
int
AWS2_DATA_ini
(
    struct AWS2_DATA *aws
)
{
    int  i;

    (*aws).aws_id = -999;   (*aws).lau_id = -999;
    (*aws).aws_tm.YY = 0;   (*aws).aws_tm.MM = 0;   (*aws).aws_tm.DD = 0;
    (*aws).aws_tm.HH = 0;   (*aws).aws_tm.MI = 0;
    (*aws).lau_tm.YY = 0;   (*aws).lau_tm.MM = 0;   (*aws).lau_tm.DD = 0;
    (*aws).lau_tm.HH = 0;   (*aws).lau_tm.MI = 0;
    (*aws).rec_tm.YY = 0;   (*aws).rec_tm.MM = 0;   (*aws).rec_tm.DD = 0;
    (*aws).rec_tm.HH = 0;   (*aws).rec_tm.MI = 0;

    for (i = 0; i < AWS2_DATA_dnum; i++) (*aws).d[i] = -999;
    for (i = 0; i <  8; i++) (*aws).qc[i] = 0;

    return 0;
}

/*****************************************************************************
 *
 *  AWS ���ڷ� �ʱ�ȭ
 *
 *    o ID, ������ : -999,  �ð� : 0
 *
 *****************************************************************************/
int
AWS2_DAY_ini
(
    struct AWS2_DAY *day
)
{
    int  i;

    (*day).aws_id = -999;
    (*day).YY = 0;   (*day).MM = 0;   (*day).DD = 0;

    for (i = 0; i < AWS2_DAY_dnum; i++) (*day).d[i] = -999;

    return 0;
}

/*****************************************************************************
 *
 *  �ź��ڷ��� ���, 15��/60��/12�ð� �̵����������� ���
 *
 *****************************************************************************/
int
aws2_rain_acc
(
    struct AWS2_DATA  *aws
)    
{
    struct AWS2_DATA  aws1, aws2;
    int    YY1, MM1, DD1, HH1, MI1;     /* ���� ���� �ð� */
    int    YY2, MM2, DD2, HH2, MI2;     /* ���� ���� �ð� */
    int    YY3, MM3, DD3, HH3, MI3;     /* �ϰ谡 �ٲ�� ���, ���� ������ �ð� */
    int    seq1, seq2, seq3;
    int    rain1, rain2, rain3;
    float  rain;
    int    acc_min[3] = {15,60,720}, min;
    int    i, j, k, n;

    /*
    ���� �������� �𸣸� ������� ����
    */

    (*aws).d[53] = -999;
    (*aws).d[54] = -999;
    (*aws).d[55] = -999;

    aws1 = *aws;
    AWS2_QCD(&aws1);

    if (aws1.d[10] < 0) return -1;
    rain1 = aws1.d[10];

    /*
    ���۽ð� Ȯ��
    */

    YY1 = aws1.aws_tm.YY;
    MM1 = aws1.aws_tm.MM;
    DD1 = aws1.aws_tm.DD;
    HH1 = aws1.aws_tm.HH;
    MI1 = aws1.aws_tm.MI;
    seq1 = time2seq(YY1, MM1, DD1, HH1, MI1, 'm');

    /*
    �̵� ���� ������ ���
    */

    for (n = 0; n < 3; n++)
    {
        seq2 = seq1 - acc_min[n];

        /*
        ���۽����� ������ Ȯ�� (������ ���� 3�б��� �ڷ� ���)
        */

        rain2 = -999;

        for (k = 0; k <= 3; k++)
        {
            for (j = -1; j <= 1; j += 2)
            {
                seq2time(seq2+j*k, &YY2, &MM2, &DD2, &HH2, &MI2, 'm', 'n');
                AWS2_DATA_ini(&aws2);
                AWSM2_IO(YY2, MM2, DD2, HH2, MI2, (int)aws1.aws_id, &aws2, 'r');
                AWS2_QCD(&aws2);

                if (aws2.d[10] >= 0)
                {
                    rain2 = aws2.d[10];
                    seq2 += j*k;
                    break;
                }
                if (k == 0) break;      /* �ѹ��� ��� */
            }
            if (rain2 >= 0) break;      /* ���������� ����� AWS �ϰ������� 0 �̻��� */
        }
        if (HH2 == 0 && MI2 == 0 && rain2 >= 0) rain2 = 0;  /* 00:00 �� ������ �ϴ����� */

        /*
        �̵����������� ��� (���� �����Ⱓ�� ������ 80%���� ���) �ϰ谡 �ٲ�� ��� ����
        */

        rain = -999;

        if ((DD1 == DD2) || (HH1 == 0 && MI1 == 0))
        {
            min = seq1 - seq2;
            if ((float)acc_min[n]*0.8 <= (float)min && rain2 <= rain1 && rain2 >= 0)
//                rain = (float)(rain1 - rain2)*acc_min[n]/(float)min;
                rain = rain1 - rain2;
            else
                rain = -999;
        }

        /*
        �ϰ谡 �ɸ��� ���, ���ϰ������� 24�ÿ��� 15�������� ���
        */

        else
        {
            seq3 = time2seq(YY1, MM1, DD1, 0, 0, 'm');
            rain3 = -999;

            for (j = 0; j <= 15; j++)
            {
                seq2time(seq3, &YY3, &MM3, &DD3, &HH3, &MI3, 'm', 'n');
                AWS2_DATA_ini(&aws2);
                AWSM2_IO(YY3, MM3, DD3, HH3, MI3, (int)aws1.aws_id, &aws2, 'r');
                AWS2_QCD(&aws2);

                if (aws2.d[10] >= 0 && rain3 < aws2.d[10]) rain3 = aws2.d[10];
                if (seq3 <= seq2 || rain3 >= 0) break;
                seq3--;
            }

            if (rain2 >= 0 && rain3 >= 0 && rain3 >= rain2)
            {
                rain = (float)(rain3 - rain2) + (float)rain1;
                min = (seq3 - seq2) + (HH1*60 + MI1);

/* ������ ������ ���� ����
                if ((float)acc_min[n]*0.8 <= (float)min)
                    rain = rain*acc_min[n]/(float)min;
                else
                    rain = -999;
*/
                if ((float)acc_min[n]*0.8 > (float)min) rain = -999;
            }
            else
            {
                rain = -999;
            }
        }

        /*
        ��� ���
        */

        if (rain >= 0)
        {
            if      (n == 0) (*aws).d[53] = (int)(rain + 0.5);
            else if (n == 1) (*aws).d[54] = (int)(rain + 0.5);
            else if (n == 2) (*aws).d[55] = (int)(rain + 0.5);
        }
    }
    return 0;
}

/*****************************************************************************
 *
 *  �ź��ڷ��� ���, 10�� ��� ǳ��/ǳ�� ��� (8���̻� ������ ��츸 ó��)
 *
 *****************************************************************************/
int
aws2_wd10_avg
(
    struct AWS2_DATA  *aws
)
{
    struct AWS2_DATA  aws1, aws2;
    float  x, y, v, deg, deg2rad, rad2deg;
    int    YY1, MM1, DD1, HH1, MI1;
    int    YY2, MM2, DD2, HH2, MI2;
    int    seq1, seq2, seq3;
    int    wd[10], ws[10];
    int    ws10 = 0, wd10 = 0, code;
    int    i, j, k, n, m;

    /*
    �ʱ�ȭ
    */

    deg2rad = asin(1.0)/90.0;
    rad2deg = 90.0/asin(1.0);

    /*
    �ڷ� �ð� �� ǳ��/ǳ�� Ȯ��
    */

    aws1 = *aws;
    AWS2_QCD(&aws1);

    YY1 = aws1.aws_tm.YY;
    MM1 = aws1.aws_tm.MM;
    DD1 = aws1.aws_tm.DD;
    HH1 = aws1.aws_tm.HH;
    MI1 = aws1.aws_tm.MI;
    seq1 = time2seq(YY1, MM1, DD1, HH1, MI1, 'm');

    wd[0] = aws1.d[1];
    ws[0] = aws1.d[2];

    /*
    ���� 10�а� ǳ��/ǳ�� ����
    */

    for (i = 1; i < 10; i++)
    {
        seq2 = seq1 - i;

        seq2time(seq2, &YY2, &MM2, &DD2, &HH2, &MI2, 'm', 'n');
        AWS2_DATA_ini(&aws2);
        code = AWSM2_IO(YY2, MM2, DD2, HH2, MI2, (int)(aws1.aws_id), &aws2, 'r');

        if (code < 0 || aws2.aws_id <= 0)
        {
            wd[i] = -999;
            ws[i] = -999;
        }
        else
        {
            AWS2_QCD(&aws2);

            wd[i] = aws2.d[1];
            ws[i] = aws2.d[2];
        }
    }

    /*
    10�� ��� ǳ��
    */

    for (n = 0, i = 0; i < 10; i++)
    {
        if (ws[i] >= 0)
        {
            ws10 += ws[i];
            n++;
        }
    }

    if (n >= 8)
        ws10 = (int)((float)ws10/(float)n + 0.5);
    else
        ws10 = -999;

    (*aws).d[52] = ws10;

    /*
    10�� ��� ǳ��
    */

    x = 0;
    y = 0;

    for (n = 0, i = 0; i < 10; i++)
    {
        if (wd[i] >= 0 && ws[i] >= 0)
        {
            n++;

            if (wd[i] > 0 && ws[i] > 0)
            {
                deg = 0.1 * (float)wd[i] * deg2rad;
                x += cos(deg);
                y += sin(deg);
                m++;
            }
        }
    }

    if (n >= 8)
    {
        if (m > 0)
        {
            x /= (float)m;
            y /= (float)m;

            v = atan2(y,x) * rad2deg * 10;
            if (v < 0) v += 3600;
            wd10 = (int)(v + 0.5);
        }
        else
        {
            wd10 = 0;
        }
    }
    else
    {
        wd10 = -999;
    }

    (*aws).d[51] = wd10;

    return 0;
}

/*****************************************************************************
 *
 *  ��)�������� ���� (���������)
 *
 *****************************************************************************/
int 
aws1_to_aws2
(
    struct AWS_DATA  aws1
)
{
    struct AWS2_DATA  aws2;
    unsigned short v1, v2;
    unsigned int   m1;
    unsigned long  m2;
    int    YY, MM, DD, HH, MI, aws_id;
    int    b1;
    int    code, i, j, k;

    /*
    �б�
    */

    aws_id = aws1.aws_id;
    YY = aws1.aws_tm.YY;
    MM = aws1.aws_tm.MM;
    DD = aws1.aws_tm.DD;
    HH = aws1.aws_tm.HH;
    MI = aws1.aws_tm.MI;

    /*
    ������ �ڷᰡ ������ ó������ ����
    */

    code = AWSM2_IO(YY, MM, DD, HH, MI, aws_id, &aws2, 'r');
    if (code < 0) return -2;
//    if (aws2.aws_id >= 0) return 1;

    /*
    ��ȯ
    */

    aws2.aws_id = aws1.aws_id;
    aws2.lau_id = aws1.lau_id;

    aws2.aws_tm.YY = aws1.aws_tm.YY;
    aws2.aws_tm.MM = aws1.aws_tm.MM;
    aws2.aws_tm.DD = aws1.aws_tm.DD;
    aws2.aws_tm.HH = aws1.aws_tm.HH;
    aws2.aws_tm.MI = aws1.aws_tm.MI;

    aws2.lau_tm.YY = aws1.lau_tm.YY;
    aws2.lau_tm.MM = aws1.lau_tm.MM;
    aws2.lau_tm.DD = aws1.lau_tm.DD;
    aws2.lau_tm.HH = aws1.lau_tm.HH;
    aws2.lau_tm.MI = aws1.lau_tm.MI;

    aws2.rec_tm.YY = aws1.rec_tm.YY;
    aws2.rec_tm.MM = aws1.rec_tm.MM;
    aws2.rec_tm.DD = aws1.rec_tm.DD;
    aws2.rec_tm.HH = aws1.rec_tm.HH;
    aws2.rec_tm.MI = aws1.rec_tm.MI;

    aws2.d[0] = aws1.d[6];      // ���
    aws2.d[1] = aws1.d[0];      // ǳ��
    aws2.d[2] = aws1.d[1];      // ǳ��
    aws2.d[3] = aws1.d[4];      // ��ǳǳ��
    aws2.d[4] = aws1.d[5];      // ��ǳǳ��
    aws2.d[5] = aws1.d[12];     // �ϰ�����(0.5)
    aws2.d[6] = aws1.d[17];     // �������
    aws2.d[7] = aws1.d[9];      // ��������
    aws2.d[9] = aws1.d[14];     // ������
    aws2.d[50] = aws1.d[26];    // �ظ���
    aws2.d[51] = aws1.d[27];    // 10��ǳ��
    aws2.d[52] = aws1.d[28];    // 10��ǳ��
    aws2.d[53] = aws1.d[24];    // 15�а�����
    aws2.d[54] = aws1.d[25];    // 60�а�����
    aws2.d[55] = aws1.d[11];    // 12�ð�������

    //  ���л���

    v1 = (unsigned short)(aws1.d[22]);
    v2 = 0;
    b1 = getbit(v1, 0);  v2 = setbit(v2, 0, b1);
    b1 = getbit(v1, 8);  v2 = setbit(v2, 1, b1);
    b1 = getbit(v1, 9);  v2 = setbit(v2, 2, b1);
    b1 = getbit(v1,10);  v2 = setbit(v2, 3, b1);
    b1 = getbit(v1,11);  v2 = setbit(v2, 4, b1);
    aws2.d[44] = v2;

    //  ��������

    v1 = (unsigned short)(aws1.d[23]);
    v2 = 0;
    b1 = getbit(v1, 0);  v2 = setbit(v2, 0, b1);
    b1 = getbit(v1, 1);  v2 = setbit(v2, 1, b1);
    b1 = getbit(v1, 2);  v2 = setbit(v2, 2, b1);
    b1 = getbit(v1, 3);  v2 = setbit(v2, 3, b1);
    b1 = getbit(v1, 4);  v2 = setbit(v2, 4, b1);
    b1 = getbit(v1, 5);  v2 = setbit(v2, 5, b1);
    b1 = getbit(v1, 6);  v2 = setbit(v2, 6, b1);
    b1 = getbit(v1, 8);  v2 = setbit(v2,15, b1);
    aws2.d[45] = v2;
    aws2.d[46] = 0;

    //  QC

    for (k = 0; k < 4; k++)
    {
        m1 = (unsigned int)(aws1.qc[k]);
        m2 = 0;
        b1 = getbit(m1, 6);  m2 = aws2_setbit_long(m2, 0, (unsigned long)b1);
        b1 = getbit(m1, 0);  m2 = aws2_setbit_long(m2, 1, (unsigned long)b1);
        b1 = getbit(m1, 1);  m2 = aws2_setbit_long(m2, 2, (unsigned long)b1);
        b1 = getbit(m1, 4);  m2 = aws2_setbit_long(m2, 3, (unsigned long)b1);
        b1 = getbit(m1, 5);  m2 = aws2_setbit_long(m2, 4, (unsigned long)b1);
        b1 = getbit(m1,12);  m2 = aws2_setbit_long(m2, 5, (unsigned long)b1);
        b1 = getbit(m1,17);  m2 = aws2_setbit_long(m2, 6, (unsigned long)b1);
        b1 = getbit(m1, 9);  m2 = aws2_setbit_long(m2, 7, (unsigned long)b1);
        b1 = getbit(m1,14);  m2 = aws2_setbit_long(m2, 9, (unsigned long)b1);
        b1 = getbit(m1,26);  m2 = aws2_setbit_long(m2,50, (unsigned long)b1);
        b1 = getbit(m1,27);  m2 = aws2_setbit_long(m2,51, (unsigned long)b1);
        b1 = getbit(m1,28);  m2 = aws2_setbit_long(m2,52, (unsigned long)b1);
        b1 = getbit(m1,24);  m2 = aws2_setbit_long(m2,53, (unsigned long)b1);
        b1 = getbit(m1,25);  m2 = aws2_setbit_long(m2,54, (unsigned long)b1);
        b1 = getbit(m1,11);  m2 = aws2_setbit_long(m2,55, (unsigned long)b1);
        aws2.qc[k] = m2;
    }

    /*
    ������
    */

    code = AWSM2_IO(YY, MM, DD, HH, MI, aws_id, &aws2, 'w');
    if (code < 0) return -9;

    return 0;
}

/*****************************************************************************
 *
 *  ����� AWS�ڷ� ��)�������� ��ȯ�Ͽ� ����
 *
 *****************************************************************************/
int 
aws1_agr_aws2
(
    struct AWS_DATA  aws1
)
{
    struct AWS2_DATA  aws2;
    unsigned short v1, v2;
    unsigned int   m1;
    unsigned long  m2;
    int    YY, MM, DD, HH, MI, aws_id;
    int    b1;
    int    code, i, j, k;

    /*
    �б�
    */

    aws_id = aws1.aws_id;
    YY = aws1.aws_tm.YY;
    MM = aws1.aws_tm.MM;
    DD = aws1.aws_tm.DD;
    HH = aws1.aws_tm.HH;
    MI = aws1.aws_tm.MI;

    /*
    ������ �ڷᰡ ������ ó������ ����
    */

    code = AWSM2_IO(YY, MM, DD, HH, MI, aws_id, &aws2, 'r');
    if (code < 0) return -2;
//    if (aws2.aws_id >= 0) return 1;

    /*
    ��ȯ
    */

    aws2.aws_id = aws1.aws_id;
    aws2.lau_id = aws1.lau_id;

    aws2.aws_tm.YY = aws1.aws_tm.YY;
    aws2.aws_tm.MM = aws1.aws_tm.MM;
    aws2.aws_tm.DD = aws1.aws_tm.DD;
    aws2.aws_tm.HH = aws1.aws_tm.HH;
    aws2.aws_tm.MI = aws1.aws_tm.MI;

    aws2.lau_tm.YY = aws1.lau_tm.YY;
    aws2.lau_tm.MM = aws1.lau_tm.MM;
    aws2.lau_tm.DD = aws1.lau_tm.DD;
    aws2.lau_tm.HH = aws1.lau_tm.HH;
    aws2.lau_tm.MI = aws1.lau_tm.MI;

    aws2.rec_tm.YY = aws1.rec_tm.YY;
    aws2.rec_tm.MM = aws1.rec_tm.MM;
    aws2.rec_tm.DD = aws1.rec_tm.DD;
    aws2.rec_tm.HH = aws1.rec_tm.HH;
    aws2.rec_tm.MI = aws1.rec_tm.MI;

    aws2.d[34] = aws1.d[0]-1000;    // ���(0.5m)
    aws2.d[0]  = aws1.d[1]-1000;    // ���(1.5m)
    aws2.d[35] = aws1.d[2]-1000;    // ���(4.0m)
    aws2.d[36] = aws1.d[3];         // ����(0.5m)
    aws2.d[9]  = aws1.d[4];         // ����(1.5m)
    aws2.d[37] = aws1.d[5];         // ����(4.0m)
    aws2.d[15] = aws1.d[6]+1000;    // ǳ��(1.5m)
    aws2.d[16] = aws1.d[7]+1000;    // ǳ��(4.0m)
    aws2.d[12] = aws1.d[8]+1000;    // ������
    aws2.d[23] = aws1.d[9]-1000;    // ����µ�
    aws2.d[25] = aws1.d[10]-1000;   // ���߿µ�(5cm)
    aws2.d[26] = aws1.d[11]-1000;   // ���߿µ�(10cm)
    aws2.d[27] = aws1.d[12]-1000;   // ���߿µ�(20cm)
    aws2.d[28] = aws1.d[13]-1000;   // ���߿µ�(30cm)
//    aws2.d[] = aws1.d[14];        // ���ϼ���
    aws2.d[38] = aws1.d[15];        // ������(10cm)
    aws2.d[39] = aws1.d[16];        // ������(20cm)
    aws2.d[40] = aws1.d[17];        // ������(30cm)
    aws2.d[13] = aws1.d[18];        // ��õ����
    aws2.d[14] = aws1.d[19];        // �ݻ纹��
    aws2.d[42] = aws1.d[20];        // ����
    aws2.d[41] = aws1.d[21];        // ������(50cm)

    //  ���л���

    v1 = (unsigned short)(aws1.d[22]);
    v2 = 0;
    b1 = getbit(v1, 0);  v2 = setbit(v2, 0, b1);
    b1 = getbit(v1, 8);  v2 = setbit(v2, 1, b1);
    b1 = getbit(v1, 9);  v2 = setbit(v2, 2, b1);
    b1 = getbit(v1,10);  v2 = setbit(v2, 3, b1);
    b1 = getbit(v1,11);  v2 = setbit(v2, 4, b1);
    aws2.d[44] = v2;

    //  ��������

    aws2.d[45] = aws1.d[23];
    aws2.d[46] = 0;

    //  QC

    for (k = 0; k < 4; k++)
    {
        aws2.qc[k] = 0;
    }

    /*
    ������
    */

    code = AWSM2_IO(YY, MM, DD, HH, MI, aws_id, &aws2, 'w');
    if (code < 0) return -9;

    return 0;
}

unsigned
getbit
(
    unsigned x,
    int  p
)
{
    return ((x >> p) & 1);
}

unsigned long
aws2_getbit_long
(
    unsigned long x,
    int  p
)
{
    return ((x >> p) & 1);
}

unsigned 
setbit
(
    unsigned x,
    int  p,
    unsigned v
)
{
    return (x | (v << p));
}

unsigned long
aws2_setbit_long
(
    unsigned long x,
    int  p,
    unsigned long v
)
{
    return (x | (v << p));
}

/*****************************************************************************
 *
 *  �ϱذ� ��
 *
 *****************************************************************************/
int
aws2_day_calc
(
    struct AWS2_DATA  aws,
    struct AWS2_DAY  *day
)
{
    int    d1, d2;
    int    YY, MM, DD, HH, MI;

    /*
    �ź��ڷ� QC
    */

    AWS2_QCD(&aws);

    /*
    �ð� Ȯ��
    */

    YY = aws.aws_tm.YY;
    MM = aws.aws_tm.MM;
    DD = aws.aws_tm.DD;
    HH = aws.aws_tm.HH;
    MI = aws.aws_tm.MI;

    if (YY < 1990 || YY > 2100) return -79;
    if (MM < 1 || MM > 12) return -78;
    if (DD < 1 || DD > 31) return -77;
    if (HH < 0 || HH > 24) return -76;
    if (MI < 0 || MI > 60) return -75;

    /*
    ���ڷ� ������ȣ �� ����
    */

    (*day).aws_id = aws.aws_id;
    (*day).YY = (short)YY;
    (*day).MM = (short)MM;
    (*day).DD = (short)DD;

    /*
    �ִ� ����ǳ
    */
    //old=>new 4=>3, 5=>4
    if ((int)((*day).d[1]) < (int)(aws.d[4]))
    {
        (*day).d[0] = aws.d[3];
        (*day).d[1] = aws.d[4];
        (*day).d[2] = (short)(HH*100 + MI);
    }

    /*
    1�� ��� �ִ�ǳ
    */
    //old=>new 0=>1, 1=>2
   
    if ((int)((*day).d[4]) < (int)(aws.d[2]))
    {
        (*day).d[3] = aws.d[1];
        (*day).d[4] = aws.d[2];
        (*day).d[5] = (short)(HH*100 + MI);
    }

    /*
    10�� ��� �ִ�ǳ
    */
    //old=>new 27=>51, 28=>52

    if ((int)((*day).d[7]) < (int)(aws.d[52]))
    {
        (*day).d[6] = aws.d[51];
        (*day).d[7] = aws.d[52];
        (*day).d[8] = (short)(HH*100 + MI);
    }

    /*
    1����� ������� �ذ��� ���
    */
    //old=>new 6=>0

    d1 = (int)(aws.d[0]);
    if (d1 > -500 && d1 < 500)
    {
        d2 = (int)((*day).d[9]);
        if (d2 > d1 || d2 < -500)               /* ���� ��� */
        {
            (*day).d[9]  = (short)d1;
            (*day).d[10] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[11]) < d1)           /* �ְ� ��� */
        {
            (*day).d[11] = (short)d1;
            (*day).d[12] = (short)(HH*100 + MI);
        }
    }

    /*
    1����� ������ �ذ��� ���
    */
    //old=>new 14=>9

    d1 = (int)(aws.d[9]);
    if (d1 > 50 && d1 <= 1000)
    {
        d2 = (int)((*day).d[13]);
        if (d2 > d1 || d2 < 0)                  /* ���� ���� */
        {
            (*day).d[13] = (short)d1;
            (*day).d[14] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[15]) < d1)           /* �ְ� ���� */
        {
            (*day).d[15] = (short)d1;
            (*day).d[16] = (short)(HH*100 + MI);
        }
    }

    /*
    1����� �ظ������� �ذ��� ���
    */
    //old=>new 26=>50

    d1 = (int)(aws.d[50]);
    if (d1 > 6000 && d1 < 12000)
    {
        d2 = (int)((*day).d[17]);
        if (d2 > d1 || d2 < 0)                  /* ���� �ظ��� */
        {
            (*day).d[17] = (short)d1;
            (*day).d[18] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[19]) < d1)           /* �ְ� �ظ��� */
        {
            (*day).d[19] = (short)d1;
            (*day).d[20] = (short)(HH*100 + MI);
        }
    }

    /*
    �� ������ (1�б��� ������ �ϰ������� �� ��찡 ����. AWS �ΰ��� ���α׷� ���� ����)
    */
    //old=>new 12=>10

    if ((int)aws.d[10] > (int)(*day).d[21])
    {
        if (HH*100+MI > 1)
        {
            (*day).d[21] = aws.d[10];
            (*day).d[22] = (short)(HH*100 + MI);
        }
    }
    /*day.d[21] = aws.d[10];*/


    /*
    1����� �ϻ緮���� �ذ��� ���
    */

    d1 = (int)(aws.d[21]);
    if (d1 > 0)
    {
        d2 = (int)((*day).d[23]);
        if (d2 > d1 || d2 < 0)                  /* ���� �ϻ緮 */
        {
            (*day).d[23] = (short)d1;
            (*day).d[24] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[25]) < d1)           /* �ְ� �ϻ緮 */
        {
            (*day).d[25] = (short)d1;
            (*day).d[26] = (short)(HH*100 + MI);
        }
    }

    /*
    1����� ����µ����� �ذ��� ���
    */

    d1 = (int)(aws.d[23]);
    if (d1 > -500 && d1 < 500)
    {
        d2 = (int)((*day).d[27]);
        if (d2 > d1 || d2 < -500)                  /* ���� ����µ�  */
        {
            (*day).d[27] = (short)d1;
            (*day).d[28] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[29]) < d1)           /* �ְ� ����µ� */
        {
            (*day).d[29] = (short)d1;
            (*day).d[30] = (short)(HH*100 + MI);
        }
    }

    /*
    1����� ����µ����� �ذ��� ���
    */

    d1 = (int)(aws.d[24]);
    if (d1 > -500 && d1 < 500)
    {
        d2 = (int)((*day).d[31]);
        if (d2 > d1 || d2 < -500)                  /* ���� ����µ� */
        {
            (*day).d[31] = (short)d1;
            (*day).d[32] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[33]) < d1)           /* �ְ� ����µ� */
        {
            (*day).d[33] = (short)d1;
            (*day).d[34] = (short)(HH*100 + MI);
        }
    }

    /*
    1����� ���߿µ�(5cm)���� �ذ��� ���
    */

    d1 = (int)(aws.d[25]);
    if (d1 > -500 && d1 < 500)
    {
        d2 = (int)((*day).d[35]);
        if (d2 > d1 || d2 < -500)                  /* ���� ���߿µ�(5cm) */
        {
            (*day).d[35] = (short)d1;
            (*day).d[36] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[37]) < d1)           /* �ְ� ���߿µ�(5cm) */
        {
            (*day).d[37] = (short)d1;
            (*day).d[38] = (short)(HH*100 + MI);
        }
    }

    /*
    1����� ���߿µ�(10cm)���� �ذ��� ���
    */

    d1 = (int)(aws.d[26]);
    if (d1 > -500 && d1 < 500)
    {
        d2 = (int)((*day).d[39]);
        if (d2 > d1 || d2 < -500)                  /* ���� ���߿µ�(10cm) */
        {
            (*day).d[39] = (short)d1;
            (*day).d[40] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[41]) < d1)           /* �ְ� ���߿µ�(10cm) */
        {
            (*day).d[41] = (short)d1;
            (*day).d[42] = (short)(HH*100 + MI);
        }
    }

    /*
    1����� ���߿µ�(20cm)���� �ذ��� ���
    */

    d1 = (int)(aws.d[27]);
    if (d1 > -500 && d1 < 500)
    {
        d2 = (int)((*day).d[43]);
        if (d2 > d1 || d2 < -500)                  /* ���� ���߿µ�(20cm) */
        {
            (*day).d[43] = (short)d1;
            (*day).d[44] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[45]) < d1)           /* �ְ� ���߿µ�(20cm) */
        {
            (*day).d[45] = (short)d1;
            (*day).d[46] = (short)(HH*100 + MI);
        }
    }

    /*
    1����� ���߿µ�(30cm)���� �ذ��� ���
    */

    d1 = (int)(aws.d[28]);
    if (d1 > -500 && d1 < 500)
    {
        d2 = (int)((*day).d[47]);
        if (d2 > d1 || d2 < -500)                  /* ���� ���߿µ�(30cm) */
        {
            (*day).d[47] = (short)d1;
            (*day).d[48] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[49]) < d1)           /* �ְ� ���߿µ�(30cm) */
        {
            (*day).d[49] = (short)d1;
            (*day).d[50] = (short)(HH*100 + MI);
        }
    }

    /*
    1����� ���߿µ�(50cm)���� �ذ��� ���
    */

    d1 = (int)(aws.d[29]);
    if (d1 > -500 && d1 < 500)
    {
        d2 = (int)((*day).d[51]);
        if (d2 > d1 || d2 < -500)                  /* ���� ���߿µ�(50cm) */
        {
            (*day).d[51] = (short)d1;
            (*day).d[52] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[53]) < d1)           /* �ְ� ���߿µ�(50cm) */
        {
            (*day).d[53] = (short)d1;
            (*day).d[54] = (short)(HH*100 + MI);
        }
    }

    /*
    1����� ���߿µ�(100cm)���� �ذ��� ���
    */

    d1 = (int)(aws.d[30]);
    if (d1 > -500 && d1 < 500)
    {
        d2 = (int)((*day).d[55]);
        if (d2 > d1 || d2 < -500)                  /* ���� ���߿µ�(100cm) */
        {
            (*day).d[55] = (short)d1;
            (*day).d[56] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[57]) < d1)           /* �ְ� ���߿µ�(100cm) */
        {
            (*day).d[57] = (short)d1;
            (*day).d[58] = (short)(HH*100 + MI);
        }
    }

    /*
    1����� ���߿µ�(150cm)���� �ذ��� ���
    */

    d1 = (int)(aws.d[31]);
    if (d1 > -500 && d1 < 500)
    {
        d2 = (int)((*day).d[59]);
        if (d2 > d1 || d2 < -500)                  /* ���� ���߿µ�(150cm) */
        {
            (*day).d[59] = (short)d1;
            (*day).d[60] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[61]) < d1)           /* �ְ� ���߿µ�(150cm) */
        {
            (*day).d[61] = (short)d1;
            (*day).d[62] = (short)(HH*100 + MI);
        }
    }

    /*
    1����� ���߿µ�(300cm)���� �ذ��� ���
    */

    d1 = (int)(aws.d[32]);
    if (d1 > -500 && d1 < 500)
    {
        d2 = (int)((*day).d[63]);
        if (d2 > d1 || d2 < -500)                  /* ���� ���߿µ�(300cm) */
        {
            (*day).d[63] = (short)d1;
            (*day).d[64] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[65]) < d1)           /* �ְ� ���߿µ�(300cm) */
        {
            (*day).d[65] = (short)d1;
            (*day).d[66] = (short)(HH*100 + MI);
        }
    }

    /*
    1����� ���߿µ�(500cm)���� �ذ��� ���
    */

    d1 = (int)(aws.d[33]);
    if (d1 > -500 && d1 < 500)
    {
        d2 = (int)((*day).d[67]);
        if (d2 > d1 || d2 < -500)                  /* ���� ���߿µ�(500cm) */
        {
            (*day).d[67] = (short)d1;
            (*day).d[68] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[69]) < d1)           /* �ְ� ���߿µ�(500cm) */
        {
            (*day).d[69] = (short)d1;
            (*day).d[70] = (short)(HH*100 + MI);
        }
    }


    return 0;
}

/*****************************************************************************
 *  Error message print
 *****************************************************************************/
void
aws2io_error
(
    int  *fnode,
    long *offset,
    char *s
)
{
    int mode = 1;

    *fnode = -1;
    *offset = 0;

    if (strlen(s) > 0 && mode)
    {
        strcat(s, " : ");
        strcat(s, strerror(errno));
        strcat(s, "\n");
        fputs(s, stdout);
    }
    return;
}
