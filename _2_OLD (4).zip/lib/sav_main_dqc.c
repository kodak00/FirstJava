/******************************************************************
 *
 *  dst_main�� ���� �ڷ�ó���� ó���� ���ϸ�� ó�� (MAIN)
 *
 ******************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>
#include "comn.h"

#define PROC_USER  "comis"                 /* ���μ��� ���� */
#define RCV_DIR    "/BUFD"                 /* ���� ���丮 */
#define LOG_DIR    "/LOGD/RECV"            /* �α� ���丮 */
#define FILE_MAX   100    


/* max. file number per child process */

FILE  *log_open();
FILE  *fp_log;
int    YYg, MMg, DDg, HHg, MIg, SSg;
char   msg_ini[256];
struct DST_INF  dst;                /* ó�� ���� */

short g_qcstep = 0;

#define WLOG(...)	fprintf(fp_log, __VA_ARGS__)	/* write error log */

#ifdef  DEBUG
#define DLOG(...)   fprintf(stderr, __VA_ARGS__)
#else
#define DLOG(...)	
#endif


int main(int argc, char *argv[])
{
    struct FILE_OUT ft[FILE_MAX];   /* ó���� ���� ��� */
    char   out[120];
    int    num_files = 0;
    int    code, mode;

    /*
    �μ��� Ȯ��
    */

    if (argc != 3) {
		printf("\n");
		printf("Usage: %s <ini_info> <qc_flag>\n", argv[0]);
		printf("\n");			
		exit(0);		
    }

    if (dst_inf_dec(argv[1], &dst) < 0 ) {
    	DLOG("[%s] argument decode error [%s]\n", argv[0], argv[1]);
        exit(0);
    }

	if (memcmp(argv[2], "F1", 2) == 0)
	{
		g_qcstep = 1;
	}
	else if (memcmp(argv[2], "F2", 2) == 0)
	{
		g_qcstep = 2;
	}
	else if (memcmp(argv[2], "F3", 2) == 0)
	{
		g_qcstep = 3;
	}
	else if (memcmp(argv[2], "F4", 2) == 0)
	{
		g_qcstep = 4;
	}
	else if (memcmp(argv[2], "F5", 2) == 0)
	{
		g_qcstep = 5;
	}
	else if (memcmp(argv[2], "F6", 2) == 0)
	{
		g_qcstep = 6;
	}
	else 
	{
    	DLOG("[%s] unkown qc flag [%s]\n", argv[0], argv[2]);
		exit(0);		
	}
    /*
    ó�� ���ѽð� ����
    */

    alarm(dst.limit);

    /*
    ��ó��
    */

    if ( sav_init(argv[0], PROC_USER, RCV_DIR, 11) < 0 ) return -1;

    /*
    �α����� ����
    */

    fp_log = log_open(LOG_DIR, argv[0]);

    /*
    �ڷ�ó��
    */

    if ( exe_check(dst.nic, dst.num, dst.limit) > 0 )   /* ó������ ���� */
    {
        if ( (num_files = file_list(dst, ft)) > 0)      /* ó���� ���ϸ�� ���� */
        {
            get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);
            file_process(num_files, ft);
        }
    }

    /*
    �α����� �ݱ�
    */

    fclose(fp_log);

    alarm(0);
    return 0;
}


/*****************************************************************************
 * function    : file_process
 * description : 
 * input       : num_files :  ó���� ���ϼ�, struct FILE_OUT ft[] : ó���� ���ϸ��
 * output      : 
 * return      : 
 *****************************************************************************/
int file_process(int num_files, struct FILE_OUT ft[] )
{
	struct COM_OPC  o1, o2;
    struct COM_OUT  t1;
    time_t tm;
    char   line[256];
    int    n, code, i, log_err;

    /*
    ���� ó������ ����
    */

    code = com_opc_io(dst.nic, dst.num, &o1, 'r');
    code = com_opc_io(dst.nic, dst.num, &o2, 'r');
    if (code < 0) return -1;

    /*
    ���Ϻ� ó��
    */

    for(i = 0; i < num_files; i++)
    {
        /*
        ���� ó��
        */

        code = file_main(ft[i].fname);

        if (code == 0) ft[i].mode = 1;
        else            continue;

		DLOG("[%s:%d] %s (%d)\n", dst.nic, dst.num, ft[i].fname, code);

        /*
        ó������� ���
        */

        time(&tm);
        t1.tm = ft[i].tm;
        if (ft[i].mode == 1)
        {
            t1.tm_out = tm;
            ft[i].tm_out = tm;
        }
        else
        {
            t1.tm_out = -2;
        }
        com_out_io(dst.nic, ft[i].seq, dst.num, &t1, 'w');
        o1.seq_out = ft[i].seq;
        o1.tm_out  = ft[i].tm_out;
        o1.seq1    = ft[i].seq;
        o1.tm_st   = ft[i].tm_out;
        code = com_opc_io(dst.nic, dst.num, &o1, 'w');
    }

    /*
    ó�� ���հ�� ���
    */

    for (n = 0, i = 0; i < num_files; i++)
    {
        if (ft[i].mode == 1)
        {
            o1.seq_out = ft[i].seq;
            o1.tm_out  = ft[i].tm_out;
            o1.seq1    = ft[i].seq;
            o1.seq2    = ft[i].seq;
            o1.tm_st   = ft[i].tm_out;
            o1.mode    = 0;
            n++;
        }
    }

    if (n > 0)
    {
        code = com_opc_io(dst.nic, dst.num, &o1, 'w');
    }
    else
    {
        time(&tm);
        o2.seq1 = o2.seq_out;
        o2.seq2 = o2.seq_out;
        o2.tm_st = tm;
        o2.mode = 0;
        code = com_opc_io(dst.nic, dst.num, &o2, 'w');
    }
    com_opc_io(dst.nic, 0, &o1, 'c');
    com_out_io(dst.nic, 0, 0, &t1, 'c');

    return 0;
}
