/******************************************************************************
 *
 *  Link User Log Write Sub Program
 *
 ******************************************************************************/
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/file.h>
#include <sys/errno.h>
#include "comn.h"

#define  LOG_DIR  "/LOGD/LNK"

int user_log_write(char *user, char *nic, int seq, time_t tm, char *sname, int st_size)
{
    FILE  *fg;
    char  ipc_time[19],trn_time[19],trn_ymd[8];
    char  fname[120], lnk_log_name[60], buf[140];
    int  YY, MM, DD, HH, MI, SS, n, code;
    struct tm  *now;
    struct USER_LOG_BUF ulb;
    
    memset(fname, 0x00, sizeof(fname));    
    strncpy(fname, sname,sizeof(fname));
    
    now  = localtime( &tm );
    YY  = ( now -> tm_year ) + 1900;
    MM = ( now -> tm_mon  ) + 1;
    DD = now -> tm_mday;
    HH = now -> tm_hour;
    MI = now -> tm_min;
    SS = now -> tm_sec; 
    sprintf(ipc_time,"%04d.%02d.%02d.%02d:%02d:%02d",YY, MM, DD, HH, MI, SS);
    
    get_time(&YY, &MM, &DD, &HH, &MI, &SS); 
    sprintf(trn_time,"%04d.%02d.%02d.%02d:%02d:%02d",YY, MM, DD, HH, MI, SS); 
    sprintf(trn_ymd,"%04d%02d%02d",YY, MM, DD);
        
    memset(lnk_log_name, 0x00, sizeof(lnk_log_name));    
    sprintf(lnk_log_name,"%s/%s_%s.log", LOG_DIR, user, trn_ymd);
    
    if ( ( fg = fopen(lnk_log_name, "a") ) == (FILE *)NULL )
    {
    	printf( "[%s] LOG ���� OPEN ����!=>[%d]\n", lnk_log_name, errno );
        return -9;
    }

    strcpy(ulb.ipc_time, ipc_time);
    strcpy(ulb.trn_time, trn_time);
    
    memset(buf, 0x00, sizeof(buf));
    sprintf(buf,"%-16s", nic);
    strcpy(ulb.nic, buf);
     
    memset(buf, 0x00, sizeof(buf));
    sprintf(buf,"%8d", seq);
    strcpy(ulb.seq, buf); 
    
    memset(buf, 0x00, sizeof(buf));
    sprintf(buf,"%-120s", fname);
    strcpy(ulb.fname, buf);
    
    memset(buf, 0x00, sizeof(buf));
    sprintf(buf,"%11d", st_size);
    strcpy(ulb.size, buf);
    
    ulb.fl_1 = ulb.fl_2 = ulb.fl_3 = ulb.fl_4 = ulb.fl_5 = ulb.fl_6 = '|';
    ulb.dummy = '\n';
    
    n = fwrite(&ulb, 1, sizeof(ulb), fg);
    if (n <= 0) return -3;
        
    fclose( fg );
    chmod ( lnk_log_name, 0666 );
    
    return 0;
}
