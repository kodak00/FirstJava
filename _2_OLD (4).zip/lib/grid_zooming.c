#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/*******************************************************************************
 *
 *  zd�� Ȯ�� ��ƾ (���밡��: �ݵ�� ������ X,Y ���� zd�� ������+1 �̾�� ��)
 *      Ȯ��� �������� sub 4-point ����� �⺻���� ���
 *
 *  by ����ȯ (2006. 5. 22)
 *
 *******************************************************************************/
int
grid_zoom
(
    float **g,      /* input -> output */
    int   nx,       /* [0:nx,0:ny] zd�� �������̾�� ��. (�ּ� zd^2) */
    int   ny,
    int   zd,       /* Ȯ���� (2��,3�� ... ) */
    int   ox,       /* ���� �Ʒ� ������ X-��ǥ */
    int   oy,       /* ���� �Ʒ� ������ Y-��ǥ */
    float missing,  /* ���ϴ� �ڷ� ���� */
    int   mode      /* 0:����(X), 1:����(O) */
)
{
    float x;
    int   i, j, k;

    /*
    Y ���� Ȯ��
    */

    for (i = ox; i <= ox+nx/zd; i++)
    {
        for (k = 0, j = oy; j < oy*zd/(zd-1); j++, k += zd) g[k][i] = g[j][i];
        for (k = ny, j = oy+ny/zd; j >= oy*zd/(zd-1); j--, k -= zd) g[k][i] = g[j][i];
    }

    /*
    X ���� Ȯ��
    */

    for (j = 0; j <= ny; j += zd)
    {
        for (k = 0, i = ox; i < ox*zd/(zd-1); i++, k += zd) g[j][k] = g[j][i];
        for (k = nx, i = ox+nx/zd; i >= ox*zd/(zd-1); i--, k -= zd) g[j][k] = g[j][i];
    }

    /*
    Y ���� ����
    */

    for (i = 0; i <= nx; i += zd)
    {
        /*
        (0, zd) ���� ������ ��� : �������� ���
        */

        if (mode && g[0][i] > missing && g[zd][i] > missing)
        {
            for (k = 1; k < zd; k++)
            {
                g[k][i] = (g[0][i]*(float)(zd - k) + g[zd][i]*(float)k) / (float)zd;
            }
        }
        else
        {
            for (k = 1; k < zd; k++)
            {
                if (k <= zd/2) g[k][i] = g[0][i];
                else           g[k][i] = g[zd][i];
            }
        }

        /*
        (ny-zd, ny) ���� ������ ��� : �������� ���
        */

        if (mode && g[ny-zd][i] > missing && g[ny][i] > missing)
        {
            for (k = 1; k < zd; k++)
            {
                g[ny-k][i] = (g[ny-zd][i]*(float)k + g[ny][i]*(float)(zd-k)) / (float)zd;
            }
        }
        else
        {
            for (k = 1; k < zd; k++)
            {
                if (k < zd/2) g[ny-k][i] = g[ny][i];
                else          g[ny-k][i] = g[ny-zd][i];
            }
        }

        /*
        ������ (zd,ny-zd) ���� ������ ��� : �ؼ������� ��� (4-point)
        */

        for (j = zd; j < ny-zd; j += zd)
        {
            for (k = 1; k < zd; k++)
            {
                if (mode && g[j][i] > missing && g[j+zd][i] > missing)
                {
                    x = (float)k / (float)zd;

                    if (g[j-zd][i] > missing && g[j+zd*2][i] > missing)
                        g[j+k][i] = g[j][i] + x*(g[j+zd][i] - g[j][i] + (x-1.0)*0.125*(g[j-zd][i] - g[j][i] - g[j+zd][i] + g[j+zd*2][i]));
                    else
                        g[j+k][i] = g[j][i]*(1.0-x) + g[j+zd][i]*x;
                }
                else
                {
                    if (k <= zd/2) g[j+k][i] = g[j][i];
                    else           g[j+k][i] = g[j+zd][i];
                }
            }
        }
    }

    /*
    X ���� ����
    */

    for (j = 0; j <= ny; j++)
    {
        /*
        (0, zd) ���� ������ ��� : �������� ���
        */

        if (mode && g[j][0] > missing && g[j][zd] > missing)
        {
            for (k = 1; k < zd; k++)
            {
                g[j][k] = (g[j][0]*(float)(zd - k) + g[j][zd]*(float)k) / (float)zd;
            }
        }
        else
        {
            for (k = 1; k < zd; k++)
            {
                if (k <= zd/2) g[j][k] = g[j][0];
                else           g[j][k] = g[j][zd];
            }
        }

        /*
        (ny-zd, ny) ���� ������ ��� : �������� ���
        */

        if (mode && g[j][ny-zd] > missing && g[j][ny] > missing)
        {
            for (k = 1; k < zd; k++)
            {
                g[j][ny-k] = (g[j][ny-zd]*(float)k + g[j][ny]*(float)(zd-k)) / (float)zd;
            }
        }
        else
        {
            for (k = 1; k < zd; k++)
            {
                if (k < zd/2) g[j][ny-k] = g[j][ny];
                else          g[j][ny-k] = g[j][ny-zd];
            }
        }

        /*
        ������ (zd,ny-zd) ���� ������ ��� : �ؼ������� ��� (4-point)
        */

        for (i = zd; i < ny-zd; i += zd)
        {
            for (k = 1; k < zd; k++)
            {
                if (mode && g[j][i] > missing && g[j][i+zd] > missing)
                {
                    x = (float)k / (float)zd;

                    if (g[j][i-zd] > missing && g[j][i+zd*2] > missing)
                        g[j][i+k] = g[j][i] + x*(g[j][i+zd] - g[j][i] + (x-1.0)*0.125*(g[j][i-zd] - g[j][i] - g[j][i+zd] + g[j][i+zd*2]));
                    else
                        g[j][i+k] = g[j][i]*(1.0-x) + g[j][i+zd]*x;
                }
                else
                {
                    if (k <= zd/2) g[j][i+k] = g[j][i];
                    else           g[j][i+k] = g[j][i+zd];
                }
            }
        }
    }
    return 0;
}

/*******************************************************************************
 *
 *  Grid data Smoothing (by 1-2-1 Smoothing)
 *
 *  by ����ȯ (1997. 3. 15)
 *
 *******************************************************************************/
int
grid_smooth
(
    float **g,      /* input -> output  */
    int   nx,       /* ���� [0:nx,0:ny] */
    int   ny,
    int   missing   /* ���ϴ� �ڷ� ���� */
)
{
    float  e[4], e1, e2;
    int    i, j;

    for (j = 0; j <= ny; j++)
    {
        e1 = g[j][0];
        e[0] = g[j][0];
        e[1] = g[j][1];

        for (i = 1; i < nx; i++)
        {
            e[2] = g[j][i+1];

            if (e[0] > missing && e[1] > missing && e[2] > missing)
                e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
            else if (e[0] > missing && e[1] <= missing && e[2] > missing)
                e2 = (e[0] + e[2]) * 0.5;
            else
                e2 = e[1];

            g[j][i-1] = e1;
            e1 = e2;
            e[0] = e[1];
            e[1] = e[2];
        }
        g[j][i-1] = e1;
    }

    for (i = 0; i <= nx; i++)
    {
        e1 = g[0][i];
        e[0] = g[0][i];
        e[1] = g[1][i];

        for (j = 1; j < ny; j++)
        {
            e[2] = g[j+1][i];

            if (e[0] > missing && e[1] > missing && e[2] > missing)
                e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
            else if (e[0] > missing && e[1] <= missing && e[2] > missing)
                e2 = (e[0] + e[2]) * 0.5;
            else
                e2 = e[1];

            g[j-1][i] = e1;
            e1 = e2;
            e[0] = e[1];
            e[1] = e[2];
        }
        g[j-1][i] = e1;
    }
    return 0;
}
