/******************************************************************
 *
 *  dst_main�� ���� �ڷ�LINKó���� ó���� ���ϸ�� ó�� (MAIN)
 *
 *================================================================*
 *
 *     o �ۼ��� : ����� (2006.10.13)
 *
 ******************************************************************
 *    2006.10.30 : nic���ں� log �߰�
 ******************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>
#include "comn.h"

#define PROC_USER  "comis"                 /* ���μ��� ���� */
#define RCV_DIR    "/BUFB"                 /* ���� ���丮 */
#define LOG_DIR    "/LOGD/RECV"            /* �α� ���丮 */
#define FILE_MAX   100                     /* max. file number per child process */

FILE  *log_open();
FILE  *fd_log;
int    YYg, MMg, DDg, HHg, MIg, SSg;
char   msg_ini[256];
struct DST_INF  dst;                /* ó�� ���� */


int main(int argc, char *argv[])
{
    struct FILE_OUT ft[FILE_MAX];   /* ó���� ���� ��� */
    char   out[120];
    int    num_files = 0;
    int    code;

    /*------------------------------------------------------------------------*/
    /* �μ��� decode */

    if (argc == 2)
    {
        if ( dst_inf_dec(argv[1], &dst) < 0 )
        {
            sprintf(out, "[%s] argument decode error\n", argv[0]);
            fputs(out, stdout);
            exit(0);
        }
    }
    else
    {
        sprintf(out, "[%s] Incorrect arguments\n", argv[0]);
        fputs(out, stdout);
        exit(0);
    }

    alarm(dst.limit);

    /*------------------------------------------------------------------------*/
    /* ��ó�� */

    if ( sav_init(argv[0], PROC_USER, RCV_DIR, 11) < 0 ) return -1;

    /* Log File Open */
    fd_log = log_open(LOG_DIR, argv[0]);

    /*------------------------------------------------------------------------*/

    if ( exe_check(dst.nic, dst.num, dst.limit) > 0 )   /* ó������ ���� */
    {
        /* ó���� ���� ��� */
        num_files = file_list(dst, ft);

        if (num_files > 0)
        {
            /* ���� �ð� */
            get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);

            /* ���� ó�� */
            file_process(num_files, ft);
        }
    }

    /* Log File Close */
    fclose(fd_log);

    alarm(0);
    return 0;
}

/******************************************************************************
 *
 *  FILE ó��
 *
 ******************************************************************************/
int file_process(num_files, ft)

    int    num_files;
    struct FILE_OUT ft[];
{
    struct COM_OPC  o1, o2;
    struct COM_OUT  t1;
    time_t tm;
    char   line[256];
    int    n, code, i, log_err;

    /*------------------------------------------------------------------------*/
    /* ���� ���ۻ��� ���� */

    code = com_opc_io(dst.nic, dst.num, &o1, 'r');
    code = com_opc_io(dst.nic, dst.num, &o2, 'r');
    if (code < 0) return -1;

    /*------------------------------------------------------------------------*/

    for(i = 0; i < num_files; i++)
    {
        /* ���� ó�� */
        code = file_link(dst.nic, ft[i]);
        sprintf(line, "[%s:%d] %s (%d)\n", dst.nic, dst.num, ft[i].fname, code);
        fputs(line, stdout);

        if (code ==  0) ft[i].mode = 1;
        else            continue;

        /* ó������� ��� */
        time(&tm);
        t1.tm = ft[i].tm;
        if (ft[i].mode == 1)
        {
            t1.tm_out = tm;
            ft[i].tm_out = tm;
        }
        else
        {
            t1.tm_out = -2;
        }
        com_out_io(dst.nic, ft[i].seq, dst.num, &t1, 'w');
        o1.seq_out = ft[i].seq;
        o1.tm_out  = ft[i].tm_out;
        o1.seq1    = ft[i].seq;
        o1.tm_st   = ft[i].tm_out;
        code = com_opc_io(dst.nic, dst.num, &o1, 'w');
        
        /*--------- nic ���ں� log write  ------------*/
        log_err = nic_log_write(dst.nic, dst.num, ft[i]);
        if (log_err != 0) {
           fprintf(fd_log, ":Nic Log write error : %s:%d:%d:%s<%d>\n", 
                           dst.nic, ft[i].seq, dst.num, ft[i].fname, log_err);
        }
        
    }

    /*------------------------------------------------------------------------*/
    /* ó�� ���հ�� ��� */

    n = 0;
    for(i = 0; i < num_files; i++)
    {
        if (ft[i].mode == 1)
        {
            o1.seq_out = ft[i].seq;
            o1.tm_out  = ft[i].tm_out;
            o1.seq1    = ft[i].seq;
            o1.seq2    = ft[i].seq;
            o1.tm_st   = ft[i].tm_out;
            o1.mode    = 0;
            n++;
        }
    }

    if (n > 0)
    {
        code = com_opc_io(dst.nic, dst.num, &o1, 'w');
    }
    else
    {
        time(&tm);
        o2.seq1 = o2.seq_out;
        o2.seq2 = o2.seq_out;
        o2.tm_st = tm;
        o2.mode = 0;
        code = com_opc_io(dst.nic, dst.num, &o2, 'w');
    }
    com_opc_io(dst.nic, 0, &o1, 'c');
    com_out_io(dst.nic, 0, 0, &t1, 'c');

    return 0;
}
