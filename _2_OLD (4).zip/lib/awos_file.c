#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "aws_data.h"
#include "aws2_data.h"

char* dec2bin(short v, char *s, int n)
{    
    int i, j;
     
    n = n + (n-1)/8;
    *(s+n) = 0;
					     
    for (i = n-1, j = 1; i >= 0; i--, j++)
    {    
        *(s+i) = (v & 0x01) + 0x30;
        if (n > 8 && i > 0 && j%8 == 0) {i--; *(s+i) = '/';}
        v = v >> 1;
    }

    return (s);
}

int aws2_to_awoskma_file(fp, aws, YY, MM, DD, HH, MI)
    FILE *fp,
    struct AWS2_DATA *aws,
	int YY, MM, DD, HH, MI;
{
    int i;
    char bstr[24];

    fprintf(fp, "%04d%02d%02d%02d%02d#B#0#%d#", YY, MM, DD, HH, MI, aws.aws_id);

    for(i=0; i<=33; i++)
    {
        if(i==7)
            fprintf(fp, "%02d#", aws.d[i]);
        else if(((i>=0 && i<=6) || (i>=8 && i<=10) || (i>=23 && i<=33)) && aws.d[i] > 0)
            fprintf(fp, "%.1f#", (float)aws.d[i]/10.0);
        else if(i==21 && aws.d[i] > 0)
            fprintf(fp, "%.2f#", (float)aws.d[i]/100.0);
        else
            fprintf(fp, "%d#", aws.d[i]);
    }
    //for(i=49; i<=62; i++) fprintf(fp, "%d#", aws.d[i]);
    for(i=47; i<=49; i++) fprintf(fp, "%d#", aws.d[i]);
    for(i=56; i<=62; i++) fprintf(fp, "%d#", aws.d[i]);
    for(i=44; i<=46; i++)
    {
        if(i == 44)
            fprintf(fp, "%s#", dec2bin(aws.d[i], bstr, 8));
        else if(i == 45)
            fprintf(fp, "%s#", dec2bin(aws.d[i], bstr, 16));
        else if(i == 46)
            fprintf(fp, "%s#", dec2bin(aws.d[i], bstr, 8));
    }
    fprintf(fp, "=\n");
}

int aws1_to_awoskma_file(fp, aws, YY, MM, DD, HH, MI)
    FILE *fp,
    struct AWS_DATA *aws,
	int YY, MM, DD, HH, MI;
{
    int i;
    char bstr[24];

    fprintf(fp, "%04d%02d%02d%02d%02d#B#0#%d#", YY, MM, DD, HH, MI, aws.aws_id);

    if(aws.d[6] <= 0) 
        fprintf(fp, "%d#", aws.d[6]);
	else
        fprintf(fp, "%.1f#", (float)aws.d[6]/10.0);

    if(aws.d[0] <= 0) 
        fprintf(fp, "%d#", aws.d[0]);
	else
        fprintf(fp, "%.1f#", (float)aws.d[0]/10.0);

    if(aws.d[1] <= 0) 
        fprintf(fp, "%d#", aws.d[1]);
	else
        fprintf(fp, "%.1f#", (float)aws.d[1]/10.0);

    if(aws.d[4] <= 0) 
        fprintf(fp, "%d#", aws.d[4]);
	else
    fprintf(fp, "%.1f#", (float)aws.d[4]/10.0);

    if(aws.d[5] <= 0) 
        fprintf(fp, "%d#", aws.d[5]);
	else
    fprintf(fp, "%.1f#", (float)aws.d[5]/10.0);

    if(aws.d[12] <= 0) 
        fprintf(fp, "%d#", aws.d[12]);
	else
    fprintf(fp, "%.1f#", (float)aws.d[12]/10.0);

    if(aws.d[17] <= 0) 
        fprintf(fp, "%d#", aws.d[17]);
	else
        fprintf(fp, "%.1f#", (float)aws.d[17]/10.0);

    fprintf(fp, "-999#%d#", aws.d[14]);

    for(i=1; i<=34; i++) fprintf(fp, "-999#");
    
    fprintf(fp, "%s#", dec2bin(aws.d[22], bstr, 8));
    fprintf(fp, "%s#", dec2bin(aws.d[23], bstr, 16));
    fprintf(fp, "-999#");
    fprintf(fp, "=\n");
}

