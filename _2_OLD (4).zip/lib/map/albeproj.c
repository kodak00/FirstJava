#include <stdio.h>
#include <math.h>
#include "map_ini.h"

/***************************************************************************
*
*  [ Albers Equal-area Conic projection ]
*
*      o lon, lat : (longitude,latitude) at earth  [degree]
*      o x, y     : (x,y) cordinate in map  [grid]
*      o code = 0 : (lon,lat) --> (x,y)
*               1 : (x,y) --> (lon,lat)
*      o map      : map parameter
*
***************************************************************************/
int  albeproj( lon, lat, x, y, code, map )
  float  *lon, *lat;         /* Longitude, Latitude [degree]  */
  float  *x, *y;             /* Coordinate in Map   [grid]    */
  int    code;               /* (0) lon,lat -> x,y  (1) x,y -> lon,lat */
  struct albe_parameter *map;
{
  static double  PI, DEGRAD, RADDEG;
  static double  re, slat1, slat2, sn, sc, ro, olon, olat;
  double         alon, alat, xn, yn, ra, theta;

  if ((*map).first == 0) {
    PI = asin(1.0)*2.0;
    DEGRAD = PI/180.0;
    RADDEG = 180.0/PI;

    re = (*map).Re/(*map).grid;
    slat1 = (*map).slat1 * DEGRAD;
    slat2 = (*map).slat2 * DEGRAD;
    olon = (*map).olon * DEGRAD;
    olat = (*map).olat * DEGRAD;

    sn = (sin(slat1) + sin(slat2)) * 0.5;
    if (fabs(sn) <= 0.0) return -1;
    sc = 1.0 + sin(slat1) * sin(slat2);
    if (sn*olat < 0.0 && fabs(olat) > 89.9*DEGRAD) return -1;
    ro = re * sqrt(sc - 2.0*sn*sin(olat))/sn;
    (*map).first = 1;
  }

  if (code == 0) {
    if ((*lat)*sn < 0.0 && fabs(*lat) > 89.9) return -1;
    ra = re * sqrt(sc - 2.0*sn*sin((*lat)*DEGRAD))/sn;
    theta = (*lon)*DEGRAD - olon;
    if (theta >  PI) theta -= 2.0*PI;
    if (theta < -PI) theta += 2.0*PI;
    theta *= sn;
    *x = ra * sin(theta) + (*map).xo;
    *y = ro - ra * cos(theta) + (*map).yo;
  }
  else {
    xn = *x - (*map).xo;
    yn = ro - *y + (*map).yo;
    ra = sqrt(xn*xn + yn*yn);
    *lat = 0.5*(sc - pow(ra*sn/re, 2))/sn;
    *lat = asin(*lat) * RADDEG;
    if (fabs(xn) <= 0.0)
      theta = 0.0;
    else {
      if (fabs(yn) <= 0.0) {
        theta = 0.5 * PI;
        if (xn < 0.0) theta = -theta;
      }
      else
        theta = atan2(xn, yn);
    }
    *lon = (theta/sn + olon) * RADDEG;
  }
  return 0;
}
