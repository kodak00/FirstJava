#include <stdio.h>
#include <math.h>
#include "map_ini.h"

/***************************************************************************
*
*  [ Oblique Mercator Projection ]
*
*      o lon, lat : (longitude,latitude) at earth  [degree]
*      o x, y     : (x,y) cordinate in map  [grid]
*      o code = 0 : (lon,lat) --> (x,y)
*               1 : (x,y) --> (lon,lat)
*
***************************************************************************/
int  oblmproj( lon, lat, x, y, code, map )
  float  *lon, *lat;         /* Longitude, Latitude [degree]  */
  float  *x, *y;             /* Coordinate in Map   [grid]    */
  int    code;               /* (0) lon,lat -> x,y  (1) x,y -> lon,lat */
  struct oblm_parameter *map;
{
  static double  PI, DEGRAD, RADDEG;
  static double  re, slat, slon, olon, olat, xo, yo;
  double         xn, yn, alat, alon, a, b, c, b1;

  if ((*map).first == 0) {
    PI = asin(1.0)*2.0;
    DEGRAD = PI/180.0;
    RADDEG = 180.0/PI;

    re = (*map).Re/(*map).grid;
    slon = (*map).slon * DEGRAD;
    slat = (*map).slat * DEGRAD;
    olon = (*map).olon * DEGRAD;
    olat = (*map).olat * DEGRAD;

    b = sin(olon - slon);
    if (fabs(olat) >= 0.5*PI) {
      xn = 0.5*PI;
      if (olat*b < 0.0) xn = -xn;
    }
    else {
      c = tan(olat)*cos(slat) - sin(slat)*cos(olon - slon);
      if (fabs(c) <= 0.0)
        xn = 0.0;
      else {
        if (fabs(b) <= 0.00001) {
          xn = 0.5*PI;
          if (c*b < 0.0) xn = -xn;
        }
        else
          xn = atan2(c, b);
      }
    }
    xo = re*xn - (*map).xo;
    a = sin(slat)*sin(olat) + cos(slat)*cos(olat)*cos(olon-slon);
    if (fabs(a) >= 0.99999) return -1;
    yo = 0.5*re*log((1.0+a)/(1.0-a)) - (*map).yo;
    (*map).first = 1;
  }

  if (code == 0) {
    alat = (*lat)*DEGRAD;
    alon = (*lon)*DEGRAD - slon;
    b = sin(alon);
    if (fabs(*lat) >= 90.0) {
      xn = 0.5*PI;
      if (*lat < 0.0) xn = -xn;
    }
    else {
      c = tan(alat)*cos(slat) - sin(slat)*cos(alon);
      if (fabs(c) <= 0.0)
        xn = 0.0;
      else {
        if (fabs(b) <= 0.00001) {
          b1 = cos(alon);
          if ((b1 > 0.0 && alat < slat) || (b1 < 0.0 && alat < -slat))
            xn = -0.5*PI;
          else
            xn = 0.5*PI;
        }
        else
          xn = atan2(c, b);
      }
    }
    *x = re*xn - xo;
    a = sin(slat)*sin(alat) + cos(slat)*cos(alat)*cos(alon);
    if (fabs(a) >= 0.99999) return -1;
    *y = 0.5*re*log((1.0+a)/(1.0-a)) - yo;
  }
  else {
    xn = (*x + xo)/re;
    yn = (*y + yo)/re;
    *lat = sin(slat)*tanh(yn) + cos(slat)*sin(xn)/cosh(yn);
    *lat = asin(*lat) * RADDEG;

    c = sin(slat)*sin(xn) - cos(slat)*sinh(yn);
    b = cos(xn);
    if (fabs(c) <= 0.0)
      *lon = 0.0;
    else if (fabs(b) <= 0.00001) {
      *lon = 0.5*PI;
      if (c*b < 0.0) *lon = -(*lon);
    }
    else
      *lon = atan2(c, b) + 0.5*PI;
    *lon = (*lon + slon) * RADDEG;
  }
  return 0;
}
