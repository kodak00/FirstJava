#include <stdio.h>
#include <math.h>
#include "map_ini.h"

/***************************************************************************
*
*  [ Sinusoidal Projection ]
*
*      o lon, lat : (longitude,latitude) at earth  [degree]
*      o x, y     : (x,y) cordinate in map  [grid]
*      o code = 0 : (lon,lat) --> (x,y)
*               1 : (x,y) --> (lon,lat)
*
***************************************************************************/
int  sinuproj( lon, lat, x, y, code, map )
  float  *lon, *lat;         /* Longitude, Latitude [degree]  */
  float  *x, *y;             /* Coordinate in Map   [grid]    */
  int    code;               /* (0) lon,lat -> x,y  (1) x,y -> lon,lat */
  struct sinu_parameter *map;
{
  static double  PI, DEGRAD, RADDEG;
  static double  re, slon, olon, olat, xo, yo;
  double         alat, alon;

  if ((*map).first == 0) {
    PI = asin(1.0)*2.0;
    DEGRAD = PI/180.0;
    RADDEG = 180.0/PI;

    re = (*map).Re/(*map).grid;
    slon = (*map).slon * DEGRAD;
    olon = (*map).olon * DEGRAD;
    olat = (*map).olat * DEGRAD;

    xo = re*(olon-slon)*cos(olat) - (*map).xo;
    yo = (*map).yo;
    (*map).first = 1;
  }

  if (code == 0) {
    alat = (*lat)*DEGRAD;
    alon = (*lon)*DEGRAD - slon;
    if (alon < -PI) alon += 2.0*PI;
    if (alon >  PI) alon -= 2.0*PI;

    *x = re*alon*cos(alat) - xo;
    *y = re*(alat - olat) + yo;
  }
  else {
    *lat = (*y - yo)/re + olat;
    *lon = ((*x + xo)/(re*cos(*lat)) + slon) * RADDEG;
    *lat = (*lat) * RADDEG;
  }
  return 0;
}
