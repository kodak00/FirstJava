#include <stdio.h>
#include <math.h>
#include "map_ini.h"

/***************************************************************************
*
*  [ Radar data coordinate ] �⺻ ������ ������ ���� (AZED ��� ��õ)
*
*      o lon, lat : (longitude,latitude) at earth  [degree]
*      o x, y     : (x,y) cordinate in map  [grid]
*      o code = 0 : (lon,lat) --> (x,y)
*               1 : (x,y) --> (lon,lat)
*
***************************************************************************/
int  radarcon( lon, lat, x, y, code, map )
  float  *lon, *lat;         /* Longitude, Latitude [degree]  */
  float  *x, *y;             /* Coordinate in Map   [grid]    */
  int    code;               /* (0) lon,lat -> x,y  (1) x,y -> lon,lat */
  struct rdr_parameter *map;
{
  static double  PI, DEGRAD, RADDEG;
  static double  re, rc, olon, olat, xo, yo, co;
  double         xn, yn, rr, dr, da, angle, theta, c, dlon, dlat;

  if ((*map).first == 0) {
    PI = asin(1.0)*2.0;
    DEGRAD = PI/180.0;
    RADDEG = 180.0/PI;

    re = (*map).Re/(*map).grid;
    rc = (*map).Rc/(*map).grid;
    co = cos((*map).olat*DEGRAD);
    (*map).first = 1;
  }

  if (code == 0) {
    dlat = (*lat - (*map).olat)*DEGRAD;
    dlon = (*lon - (*map).olon)*DEGRAD;
    c = acos( cos(dlat) * cos(dlon*co) );
    if ((*map).curve == 0)
      rr = re*c;
    else if ((*map).curve == 1)
      rr = re*tan(c);
    else if ((*map).curve == 2) {
      dr = (rc - re)/rc;
      da = dr*sin(2.0*c);
      angle = -da * sqrt(da*da + 4.0 + 4.0*dr*dr);
      angle = asin(angle*0.5);
      rr = rc*angle;
    }

    if (fabs(c) <= 0.0000001) {
      *x = (*map).xo;
      *y = (*map).yo;
    }
    else {
      theta = sin(dlat)/sin(c);
      if (fabs(theta) >= 1.0)
        *x = 0;
      else
        *x = rr*cos(asin(theta));

      *y = rr*theta + (*map).yo;
      if (dlon < 0.0) *x = -(*x);
      *x += (*map).xo;
    }
  }
  else {
    xn = (*x) - (*map).xo;
    yn = (*y) - (*map).yo;
    rr = sqrt(xn*xn + yn*yn);
    if ((*map).curve == 0)
      c = rr/re;
    else if ((*map).curve == 1)
      c = atan(rr/re);
    else if ((*map).curve == 2) {
      c = re/(rc * sin(rr/rc)) - tan(0.5*rr/rc);
      c = atan(1.0/c);
    }

    if (fabs(yn) <= 0.0)
      theta = 0.0;
    else if (fabs(xn) <= 0.0) {
      theta = PI*0.5;
      if (yn < 0.0) theta = -theta;
    }
    else
      theta = atan2(yn, xn);

    dlat = asin(sin(theta)*sin(c));
    dlon = acos(cos(c)/cos(dlat))/co;
    if (fabs(theta) > PI*0.5) dlon = -dlon;
    *lat = dlat*RADDEG + (*map).olat;
    *lon = dlon*RADDEG + (*map).olon;
  }
  return 0;
}
