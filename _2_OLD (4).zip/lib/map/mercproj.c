#include <stdio.h>
#include <math.h>
#include "map_ini.h"

/***************************************************************************
*
*  [ Mercator Projection ]
*
*      o lon, lat : (longitude,latitude) at earth  [degree]
*      o x, y     : (x,y) cordinate in map  [grid]
*      o code = 0 : (lon,lat) --> (x,y)
*               1 : (x,y) --> (lon,lat)
*
***************************************************************************/
int  mercproj( lon, lat, x, y, code, map )
  float  *lon, *lat;         /* Longitude, Latitude [degree]  */
  float  *x, *y;             /* Coordinate in Map   [grid]    */
  int    code;               /* (0) lon,lat -> x,y  (1) x,y -> lon,lat */
  struct merc_parameter *map;
{
  static double  PI, DEGRAD, RADDEG;
  static double  re, slon, slat, olon, olat, xo, yo;
  double         alon, alat, xn;

  if (code == 0 && fabs(*lat) > 89.9) return -1;

  if ((*map).first == 0) {
    PI = asin(1.0)*2.0;
    DEGRAD = PI/180.0;
    RADDEG = 180.0/PI;

    slon = (*map).slon * DEGRAD;
    slat = (*map).slat * DEGRAD;
    olon = (*map).olon * DEGRAD;
    olat = (*map).olat * DEGRAD;
    re = ((*map).Re/(*map).grid)*cos(slat);

    xn = olon - slon;
    if      (xn >  PI) xn -= 2.0*PI;
    else if (xn < -PI) xn += 2.0*PI;
    xo = re*xn - (*map).xo;
    yo = re*log( tan( PI*0.25 + olat*0.5 ) ) - (*map).yo;
    (*map).first = 1;
  }

  if (code == 0) {
    xn = (*lon)*DEGRAD - slon;
    if      (xn >  PI) xn -= 2.0*PI;
    else if (xn < -PI) xn += 2.0*PI;
    (*x) = re*xn - xo;
    (*y) = re*log( tan( PI*0.25 + (*lat)*DEGRAD*0.5 ) ) - yo;
  }
  else {
    alat = PI*0.5 - 2.0*atan(exp(-((*y)+yo)/re));
    alon = ((*x)+xo)/re + slon;
    *lat = alat * RADDEG;
    *lon = alon * RADDEG;
  }
  return 0;
}
