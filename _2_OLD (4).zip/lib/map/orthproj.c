#include <stdio.h>
#include <math.h>
#include "map_ini.h"

/***************************************************************************
*
*  [ Orthographic Projection ]
*
*      o lon, lat : (longitude,latitude) at earth  [degree]
*      o x, y     : (x,y) cordinate in map  [grid]
*      o code = 0 : (lon,lat) --> (x,y)
*               1 : (x,y) --> (lon,lat)
*
***************************************************************************/
int  orthproj( lon, lat, x, y, code, map )
  float  *lon, *lat;         /* Longitude, Latitude [degree]  */
  float  *x, *y;             /* Coordinate in Map   [grid]    */
  int    code;               /* (0) lon,lat -> x,y  (1) x,y -> lon,lat */
  struct orth_parameter *map;
{
  static double  PI, DEGRAD, RADDEG;
  static double  re, slon, slat, olon, olat, xo, yo;
  double         xn, yn, alon, alat, theta, a1, a2, ch, ra, ac;

  if ((*map).first == 0) {
    PI = asin(1.0)*2.0;
    DEGRAD = PI/180.0;
    RADDEG = 180.0/PI;

    re = (*map).Re/(*map).grid;
    slon = (*map).slon * DEGRAD;
    slat = (*map).slat * DEGRAD;
    olon = (*map).olon * DEGRAD;
    olat = (*map).olat * DEGRAD;

    xo = re*cos(olat)*sin(olon-slon) - (*map).xo;
    ch = sin(slat)*sin(olat) + cos(slat)*cos(olat)*cos(olon-slon);
    if (ch < -0.00001) return -1;
    yo = re*(cos(slat)*sin(olat) - sin(slat)*cos(olat)*cos(olon-slon)) - (*map).yo;
    (*map).first = 1;
  }

  if (code == 0) {
    alat = (*lat)*DEGRAD;
    alon = (*lon)*DEGRAD - slon;
    ch = sin(slat)*sin(alat) + cos(slat)*cos(alat)*cos(alon);
    if (ch < -0.00001) return -1;
    *x = re*cos(alat)*sin(alon) - xo;
    *y = re*(cos(slat)*sin(alat) - sin(slat)*cos(alat)*cos(alon)) - yo;
  }
  else {
    xn = *x + xo;
    yn = *y + yo;
    ra = xn*xn + yn*yn;
    if (ra <= 0.0) {
      ac = 0.0;
      *lat = slat * RADDEG;
    }
    else {
      ra = sqrt(ra);
      ac = asin(ra/re);
      *lat = cos(ac)*sin(slat) + yn*sin(ac)*cos(slat)/ra;
      *lat = asin(*lat) * RADDEG;
    }

    a1 = xn*sin(ac);
    a2 = ra*cos(slat)*cos(ac) - yn*sin(slat)*sin(ac);
    if (fabs(a1) <= 0.0)
      theta = 0.0;
    else if (fabs(a2) <= 0.0) {
      theta = 0.5*PI;
      if (a2 < 0.0) theta = -theta;
    }
    else
      theta = atan2(a1, a2);
    *lon = (theta + slon) * RADDEG;
  }
  return 0;
}
