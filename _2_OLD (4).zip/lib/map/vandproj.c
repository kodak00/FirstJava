#include <stdio.h>
#include <math.h>
#include "map_ini.h"

/***************************************************************************
*
*  [ Van der grinten Projection ]
*
*      o lon, lat : (longitude,latitude) at earth  [degree]
*      o x, y     : (x,y) cordinate in map  [grid]
*      o code = 0 : (lon,lat) --> (x,y)
*               1 : (x,y) --> (lon,lat)
*
***************************************************************************/
int  vandproj( lon, lat, x, y, code, map )
  float  *lon, *lat;         /* Longitude, Latitude [degree]  */
  float  *x, *y;             /* Coordinate in Map   [grid]    */
  int    code;               /* (0) lon,lat -> x,y  (1) x,y -> lon,lat */
  struct vand_parameter *map;
{
  static double  PI, DEGRAD, RADDEG;
  static double  re, slat, slon, olon, olat, xo, yo;
  double         xn, yn, alat, alon, theta, a, g, p;

  if ((*map).first == 0) {
    PI = asin(1.0)*2.0;
    DEGRAD = PI/180.0;
    RADDEG = 180.0/PI;

    re = (*map).Re/(*map).grid;
    slon = (*map).slon * DEGRAD;
    olon = (*map).olon * DEGRAD;
    olat = (*map).olat * DEGRAD;

    if (olat == 0.0) {
      xn = re*fabs(olon - slon);
      yn = 0.0;
    }
    else if (olon == slon) {
      theta = asin(fabs(2.0*olat/PI));
      xn = 0.0;
      yn = re*tan(theta*0.5)*PI;
    }
    else {
      theta = asin(fabs(2.0*olat/PI));
      a = 0.5*fabs(PI/(olon-slon) - (olon-slon)/PI);
      g = cos(theta)/(sin(theta) + cos(theta) - 1.0);
      p = g*(2.0/cos(theta) - 1.0);
      xn = a*(g-p*p) + sqrt(a*a*pow((g-p*p), 2) - (p*p+a*a)*(g*g-p*p));
      xn = PI*re*xn/(a*a+p*p);
      yn = PI*re*sqrt(1.0 - pow((xn/PI*re), 2) - 2.0*a*fabs(xn/(PI*re)));
    }
    if (olon < slon) xn = -xn;
    if (olat <  0.0) yn = -yn;
    xo = xn - (*map).xo;
    yo = yn - (*map).yo;
    (*map).first = 1;
  }

  if (code == 0) {
    alat = (*lat)*DEGRAD;
    alon = (*lon)*DEGRAD - slon;
    if (alon < -PI) alon += 2.0*PI;
    if (alon >  PI) alon -= 2.0*PI;

    if (alat == 0.0) {
      *x = re*fabs(alon);
      *y = 0.0;
    }
    else if (fabs(alon) == 0.0) {
      *x = 0.0;
      theta = asin(fabs(2.0*alat/PI));
      *y = PI*re*tan(theta*0.5);
    }
    else {
      theta = asin(fabs(2.0*alat/PI));
      a = 0.5*fabs(PI/alon - alon/PI);
      g = cos(theta) / (sin(theta) + cos(theta) - 1.0);
      p = g*(2.0/sin(theta) - 1.0);
      *x = a*(g-p*p) + sqrt(a*a*pow((g-p*p), 2) - (p*p+a*a)*(g*g-p*p));
      *x = PI*re*(*x)/(a*a+p*p);
      *y = 1.0 - pow(*x/(PI*re),2) - 2.0*a*fabs(*x/(PI*re));
      if (*y <= 0.0)
        *y = 0.0;
      else
        *y = PI*re*sqrt(*y);
    }
    if (alon < 0.0) *x = -(*x);
    if (alat < 0.0) *y = -(*y);
    *x -= xo;
    *y -= yo;
  }
  else {
    xn = *x + xo;
    yn = *y + yo;
    if (xn == 0.0) {
      theta = 2.0*atan(yn/(PI*re));
      *lat = 0.5*PI*sin(theta);
      *lon = olon;
    }
    else if (yn == 0.0) {
      *lat = 0.0;
      *lon = xn/re + olon;
    }
    else
      return -1;
    *lat *= RADDEG;
    *lon *= RADDEG;
  }
  return 0;
}
