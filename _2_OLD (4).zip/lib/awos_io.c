#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>

#include "aws_data.h"
#include "aws2_data.h"

#define NUM_OBS_ELEMS 51
char gObsData[NUM_OBS_ELEMS][16];

/****************************************************************************
 * �������� üũ��
 *  - ����: 0, ����: -1
 ****************************************************************************/
int chk_missing(short v)
{
     if (-999 <= v && v <= -990) return (-1);
         return (0);
}

/****************************************************************************
 * ������ ����
 *  - �����̸� NULL ó����
 ****************************************************************************/
void set_obsdata(char *obs, short v, char *s)
{
     if (chk_missing(v) < 0) return;
         strcpy(obs, s);
}

/****************************************************************************
 * �����ڷ� (����, ��������)�� ����
 *  - ����Ȱ��� �����ϰ� ���ڿ��� ����(BIT0�� ���ڿ���������)
 *  - X, Y���� ���⸸ (8BIT ������)
 *  - m: 0(������Ʈ), 1(������Ʈ)
 ****************************************************************************/
char *dec2binstr(short v, char *s, int m)
{
     int i, n;

     *(s+8) = 0;
     for (i = 0; i < 8; i++)
     {
         n = i + (m*8);
         *(s+7-i) = ((v>>n)&0x01) + 0x30;
     }
     return (s);
}

int aws2_to_kmafile(aws2, buf)
    struct AWS2_DATA  aws2;
	char *buf;
{
      int i;
      int YY, MM, DD, HH, MI;
      char sval[16];

	  YY = aws2.aws_tm.YY;
	  MM = aws2.aws_tm.MM;
	  DD = aws2.aws_tm.DD;
	  HH = aws2.aws_tm.HH;
	  MI = aws2.aws_tm.MI;

      memset(gObsData, 0, sizeof(gObsData));
      sprintf(gObsData[0], "%04d%02d%02d%02d%02d", YY, MM, DD, HH, MI);
      sprintf(gObsData[1], "%c", 'B');
      sprintf(gObsData[2], "%c", '0');
      sprintf(gObsData[3], "%04d", aws2.aws_id);
      
      for(i = 0; i <= 43; i++)
      {
            if (i == 7)
            {
                  sprintf(sval, "%02d", aws2.d[i]);
            }
            else if (i == 21)
            {
                  sprintf(sval, "%.2f", (float)aws2.d[i]/100.0);
            }
            else if (i == 22) // �ϴ����ϻ緮�� �����ΰ�� ����� ��ȯ�ؾ���
            {
                  if (chk_missing(aws2.d[i]) < 0) continue;
                  else if (aws2.d[i] < 0) sprintf(sval, "%d", aws2.d[i] + 65536);
                  else                    sprintf(sval, "%d", aws2.d[i]);
            }
            else
            {
                  sprintf(sval, "%.1f", (float)aws2.d[i]/10.0);
            }
            set_obsdata(gObsData[4+i], aws2.d[i], sval);
      }
      dec2binstr(aws2.d[44], gObsData[48], 0);
      dec2binstr(aws2.d[45], gObsData[49], 0);
      dec2binstr(aws2.d[45], gObsData[50], 1);
    
	  write_obsdata(buf);

	  return 0; 
}


int write_obsdata(char *buf)
{
    int i;

    for (i = 0; i < NUM_OBS_ELEMS; i++)
    {
        sprintf(buf, "%s%s#", buf, gObsData[i]);
    }
    strcat(buf, "=\n");

    return (0);
}


int
aws1_to_aws2_value
(
    struct AWS_DATA  aws1,
    struct AWS2_DATA  *aws2
)
{
    unsigned short v1, v2;
    unsigned int   m1;
    unsigned long  m2;
    int    YY, MM, DD, HH, MI, aws_id;
    int    b1;
    int    code, i, j, k;

    aws_id = aws1.aws_id;
    YY = aws1.aws_tm.YY;
    MM = aws1.aws_tm.MM;
    DD = aws1.aws_tm.DD;
    HH = aws1.aws_tm.HH;
    MI = aws1.aws_tm.MI;

    (*aws2).aws_id = aws1.aws_id;
    (*aws2).lau_id = aws1.lau_id;
    
    (*aws2).aws_tm.YY = aws1.aws_tm.YY;
    (*aws2).aws_tm.MM = aws1.aws_tm.MM;
    (*aws2).aws_tm.DD = aws1.aws_tm.DD;
    (*aws2).aws_tm.HH = aws1.aws_tm.HH;
    (*aws2).aws_tm.MI = aws1.aws_tm.MI;
    
    (*aws2).lau_tm.YY = aws1.lau_tm.YY;
    (*aws2).lau_tm.MM = aws1.lau_tm.MM;
    (*aws2).lau_tm.DD = aws1.lau_tm.DD;
    (*aws2).lau_tm.HH = aws1.lau_tm.HH;
    (*aws2).lau_tm.MI = aws1.lau_tm.MI;

    (*aws2).rec_tm.YY = aws1.rec_tm.YY;
    (*aws2).rec_tm.MM = aws1.rec_tm.MM;
    (*aws2).rec_tm.DD = aws1.rec_tm.DD;
    (*aws2).rec_tm.HH = aws1.rec_tm.HH;
    (*aws2).rec_tm.MI = aws1.rec_tm.MI;
    
    (*aws2).d[0] = aws1.d[6];      // ���
    (*aws2).d[1] = aws1.d[0];      // ǳ��
    (*aws2).d[2] = aws1.d[1];      // ǳ��
    (*aws2).d[3] = aws1.d[4];      // ��ǳǳ��
    (*aws2).d[4] = aws1.d[5];      // ��ǳǳ��
    (*aws2).d[5] = aws1.d[12];     // �ϰ�����(0.5)
    (*aws2).d[6] = aws1.d[17];     // �������
    (*aws2).d[7] = aws1.d[9];      // ��������
    (*aws2).d[9] = aws1.d[14];     // ������
    (*aws2).d[50] = aws1.d[26];    // �ظ���
    (*aws2).d[51] = aws1.d[27];    // 10��ǳ��
    (*aws2).d[52] = aws1.d[28];    // 10��ǳ��
    (*aws2).d[53] = aws1.d[24];    // 15�а�����
    (*aws2).d[54] = aws1.d[25];    // 60�а�����
    (*aws2).d[55] = aws1.d[11];    // 12�ð�������
    
    //  ���л���

    v1 = (unsigned short)(aws1.d[22]);
    v2 = 0;
    b1 = getbit(v1, 0);  v2 = setbit(v2, 0, b1);
    b1 = getbit(v1, 8);  v2 = setbit(v2, 1, b1);
    b1 = getbit(v1, 9);  v2 = setbit(v2, 2, b1);
    b1 = getbit(v1,10);  v2 = setbit(v2, 3, b1);
    b1 = getbit(v1,11);  v2 = setbit(v2, 4, b1);
    (*aws2).d[44] = v2;

    //  ��������

    v1 = (unsigned short)(aws1.d[23]);
    v2 = 0;
    b1 = getbit(v1, 0);  v2 = setbit(v2, 0, b1);
    b1 = getbit(v1, 1);  v2 = setbit(v2, 1, b1);
    b1 = getbit(v1, 2);  v2 = setbit(v2, 2, b1);
    b1 = getbit(v1, 3);  v2 = setbit(v2, 3, b1);
    b1 = getbit(v1, 4);  v2 = setbit(v2, 4, b1);
    b1 = getbit(v1, 5);  v2 = setbit(v2, 5, b1);
    b1 = getbit(v1, 6);  v2 = setbit(v2, 6, b1);
    b1 = getbit(v1, 8);  v2 = setbit(v2,15, b1);
    (*aws2).d[45] = v2;
    (*aws2).d[46] = 0;

    //  QC

    for (k = 0; k < 4; k++)
    {
        m1 = (unsigned int)(aws1.qc[k]);
        m2 = 0;
        b1 = getbit(m1, 6);  m2 = setbit_long(m2, 0, (unsigned long)b1);
        b1 = getbit(m1, 0);  m2 = setbit_long(m2, 1, (unsigned long)b1);
        b1 = getbit(m1, 1);  m2 = setbit_long(m2, 2, (unsigned long)b1);
        b1 = getbit(m1, 4);  m2 = setbit_long(m2, 3, (unsigned long)b1);
        b1 = getbit(m1, 5);  m2 = setbit_long(m2, 4, (unsigned long)b1);
        b1 = getbit(m1,12);  m2 = setbit_long(m2, 5, (unsigned long)b1);
        b1 = getbit(m1,17);  m2 = setbit_long(m2, 6, (unsigned long)b1);
        b1 = getbit(m1, 9);  m2 = setbit_long(m2, 7, (unsigned long)b1);
        b1 = getbit(m1,14);  m2 = setbit_long(m2, 9, (unsigned long)b1);
        b1 = getbit(m1,26);  m2 = setbit_long(m2,50, (unsigned long)b1);
        b1 = getbit(m1,27);  m2 = setbit_long(m2,51, (unsigned long)b1);
        b1 = getbit(m1,28);  m2 = setbit_long(m2,52, (unsigned long)b1);
        b1 = getbit(m1,24);  m2 = setbit_long(m2,53, (unsigned long)b1);
        b1 = getbit(m1,25);  m2 = setbit_long(m2,54, (unsigned long)b1);
        b1 = getbit(m1,11);  m2 = setbit_long(m2,55, (unsigned long)b1);
        (*aws2).qc[k] = m2;
    }

    return 0;
}

int aws1_to_kmafile(aws1, buf)
    struct AWS_DATA  aws1;
	char *buf;
{
    int code;

    struct AWS2_DATA  aws2;
	
    code = aws1_to_aws2_value(aws1, &aws2);

    if(code >= 0)
         code = aws2_to_kmafile(aws2, buf);

    return code;
}

