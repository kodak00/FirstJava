
#include <stdio.h>
#include <time.h>
#include "fileprocess.h"


int LogToFile(fullPath, str1, str2)
char *fullPath;
char *str1;
char *str2;
{
	FILE	*stm;
	time_t	lTime;
	struct	tm	 *datetime;
	int		cnt;			/* write byte count */

/*
	Followings are added to control logging level
	bFlag : read one times only to check logging option
	bLogData : if comm. contents logged ?
	logopt	 : forced logging option
*/
	static int	 bFlag	   = 0;
	static int	 bLogData  = 0;
	static short logopt	   = 0;


	/*------- open the file ----------------*/
	stm = fopen(fullPath, "a");

	if (stm == NULL)
				return LOG_OPENERR;		/*	open error */

	/* IF log file is too big, backup it */
	{
		fseek(stm, 0, SEEK_END);
		cnt = ftell(stm);
		if(cnt > LogFileMaxSize)
		{		/* backup */
			char	backPath[256];
			fclose(stm);
			/*strcpy(backPath, fullPath);
			strncpy(&backPath[strlen(backPath)-3], "bak", 3);*/
			memset(backPath, 0x00, sizeof(backPath));
			sprintf(backPath, "%s.bak", fullPath);
			rename(fullPath, backPath);
			stm = fopen(fullPath, "w");

		}
		fseek(stm, 0, SEEK_SET);
	}

	/*----- log current time -----*/
	{
		/*	write date & time string */
		lTime = time (NULL);
		datetime = localtime (&lTime);
		cnt = fprintf(stm, "%04d/%02d/%02d %2d:%02d:%02d ",
				LYEAR, LMONTH, LDAY, LHOUR, LMINU, LSEC);
		fflush(stm);
		if (cnt <= 0) goto WriteError;
	}
	
	/* log requested comment with time to the logging file */
	cnt = fprintf(stm, str1);
	{
		cnt = fprintf(stm, "\t");
		fflush(stm);
		cnt = fprintf(stm, str2);
		fflush(stm);
	cnt = fprintf(stm, "\n");
		fflush(stm);
		if (cnt <= 0) goto WriteError;
	}
	
	/* if LOG_TIME or LOG_COMMENT then, change line */

	fclose(stm);
	return LOG_SUCCESS;
/*-------------------------------------------------------------------------*/
WriteError:
	printf("LogToFile Error occurs !!! cnt = %d\n", cnt);
	fclose(stm);
	return LOG_WRITERR;
}


