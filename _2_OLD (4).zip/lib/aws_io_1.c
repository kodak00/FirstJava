#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include <aws_data.h>

#define  MAXLINE  1024
#define  AWS_DIR  "/DATA/AWS/AWSDB"

void awsio_error();

/*****************************************************************************
 *
 *  AWSM �ڷῡ�� � ����Ͻú��� AWS �ź��ڷḦ ����
 *
 *    o YY,MM,DD,HH,MI   : ��,��,��,��,��
 *    o aws_id           : AWS ID (1�� ������ ����)
 *    o aws[]            : AWS �ڷ�
 *    o mode             : �ڷ� ����� ���
 *         . mode = 'q'  : �ش�ð��� �ڷḸ ���� (���� 0, ���� < 0)
 *         . mode = 'r'  : ���� 5�а��� �ڷῡ�� ���� (���� 0, ���� < 0)
 *
 *****************************************************************************/
int QAWSM_READ(YY, MM, DD, HH, MI, aws_id, aws, mode)
    int    YY, MM, DD, HH, MI, aws_id;
    struct AWS_DATA  aws[];
    char   mode;
{
    struct AWS_DATA  aws1[5];
    int    d[5], code = -1;
    int    seq, i;

    /*
    ID ���� ����
    */

    if (aws_id < 0) return -2;

    /*
    �ش� �ð� ����
    */

    code = AWSM_READ(YY, MM, DD, HH, MI, aws_id, aws, 'r');
    if (code >= 0) AWS_QCD(&aws[0]);
    if (mode == 'q' || code >= 0) return code;

    /*
    ���� ���, ���� 5�е��ȿ��� �ڷḦ ã��
    */

    seq = time2seq(YY, MM, DD, HH, MI, 'm') - 5;

    for (i = 4; i >= 0; i--)
    {
        seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
        code = AWSM_READ(YY, MM, DD, HH, MI, aws_id, &aws1[i], 'r');

        d[i] = 0;
        if (code >= 0) d[i] = 1;
        seq++;
    }

    code = -1;
    for (i = 0; i < 5; i++)
    {
        if (d[i])
        {
            aws[0] = aws1[i];
            AWS_QCD(&aws[0]);
            code = 0;
            break;
        }
    }
    return code;
}

/*****************************************************************************
 *
 *  AWSH �ڷῡ�� � ����Ͻ��� AWS �����ڷḦ ����
 *
 *    o YY,MM,DD,HH      : ��,��,��,��
 *    o aws_id           : AWS ID (1�� ������ ����)
 *    o aws[]            : AWS �ڷ�
 *    o mode             : �ڷ� ����� ���
 *         . mode = 'q'  : �ش�ð��� �ڷḸ ���� (���� 0, ���� < 0)
 *         . mode = 'r'  : ���� 5�а��� �ڷῡ�� ���� (���� 0, ���� < 0)
 *
 *****************************************************************************/
int QAWSH_READ(YY, MM, DD, HH, aws_id, aws, mode)
    int    YY, MM, DD, HH, aws_id;
    struct AWS_DATA  aws[];
    char   mode;
{
    struct AWS_DATA  aws1[6];
    int    d[6], code = -1;
    int    seq, MI = 0, i;

    /*
    ID ���� ����
    */

    if (aws_id < 0) return -2;

    /*
    �����ڷ� ����
    */

    code = AWSH_IO(YY, MM, DD, HH, aws_id, aws, 'r');
    if (code >= 0) AWS_QCD(&aws[0]);
    if (mode == 'q' || code >= 0) return code;

    /*
    �����ڷᰡ ������ ���� 5�а��� �ź��ڷῡ�� ã��
    */

    seq = time2seq(YY, MM, DD, HH, 0, 'm') - 5;

    for (i = 5; i >= 0; i--)
    {
        seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
        code = AWSM_READ(YY, MM, DD, HH, MI, aws_id, &aws1[i], 'r');

        d[i] = 0;
        if (code >= 0) d[i] = 1;
        seq++;
    }

    code = -1;
    for (i = 0; i <= 5; i++)
    {
        if (d[i])
        {
            aws[0] = aws1[i];
            AWS_QCD(&aws[0]);
            code = 0;
            break;
        }
    }
    return code;
}

/*****************************************************************************
 *
 *  QC�ڷḦ ������ AWS �����ڷḦ MASKING �ϴ� ��ƾ
 *
 *    o aws[]            : AWS �ڷ�
 *
 *****************************************************************************/
int AWS_QCD(aws)
    struct AWS_DATA  aws[];
{
    char qcd[AWS_DATA_dnum];
    int  q;
    int  i, j, k;

    for (k = 0; k < 4; k++)
    {
        q = aws[0].qc[k];
        for (i = 0; i < AWS_DATA_dnum; i++)
        {
            qcd[i] = q & 0x00000001;
            q = q >> 1;
        }
        for (i = 0; i < AWS_DATA_dnum; i++)
        {
            if (qcd[i] == 1)
            {
                aws[0].d[i] = -998 + k;
            }
        }
    }
    return 0;
}

/*****************************************************************************
 *
 *  AWSM �ڷῡ�� � ����Ͻú��� AWS �ź��ڷḦ ����
 *
 *    o YY,MM,DD,HH,MI   : ��,��,��,��,��
 *    o aws_id           : AWS ID
 *         . aws_id > -1 : �ش������� AWS �ڷ�
 *         . aws_id = -1 : ��û�ð��� ��� AWS �ڷ�
 *    o aws[]            : AWS �ڷ�
 *    o mode             : �ڷ� ����� ���
 *         . mode = 'r'  : �б� (���� 0, ���� < 0)
 *         . mode = 'w'  : ���� (���� 0, ���� < 0)
 *         . mode = 'c'  : File Close
 *
 *****************************************************************************/
int AWSM_READ(YY, MM, DD, HH, MI, aws_id, aws, mode)
    int    YY, MM, DD, HH, MI, aws_id;
    struct AWS_DATA  aws[];
    char   mode;
{
    static int access = 1;
    int code;

    /*
    FILE CLOSE
    */

    if (mode == 'c')
    {
        AWSM_IO(YY, MM, DD, HH, MI, aws_id, aws, mode);
        GZAWSM_IO(YY, MM, DD, HH, MI, aws_id, aws, mode);
        return 0;
    }
    if (mode != 'r') return -1;

    /*
    1�� READ
    */

    printf("acc : %d\n", access);
    
    if (access == 2)
        code = GZAWSM_IO(YY, MM, DD, HH, MI, aws_id, aws, mode);
    else
        code = AWSM_IO(YY, MM, DD, HH, MI, aws_id, aws, mode);

    /*
    2�� READ
    */

    printf("code1 : %d\n", code);
    if (code == -1)
    {
        if (access == 2)
        {
            code = AWSM_IO(YY, MM, DD, HH, MI, aws_id, aws, mode);
            if (code >= 0) access = 1;
        }
        else
        {
            code = GZAWSM_IO(YY, MM, DD, HH, MI, aws_id, aws, mode);
            if (code >= 0) access = 2;
        }
    }

    if (aws_id%1000 != (aws[0].aws_id)%1000) return -5;
    return code;
}

/*****************************************************************************
 *
 *  AWSM �ڷῡ�� � ����Ͻú��� AWS �ź��ڷḦ ó��
 *
 *    o YY,MM,DD,HH,MI   : ��,��,��,��,��
 *    o aws_id           : AWS ID
 *         . aws_id > -1 : �ش������� AWS �ڷ�
 *         . aws_id = -1 : ��û�ð��� ��� AWS �ڷ�
 *    o aws[]            : AWS �ڷ�
 *    o mode             : �ڷ� ����� ���
 *         . mode = 'r'  : �б� (���� 0, ���� < 0)
 *         . mode = 'w'  : ���� (���� 0, ���� < 0)
 *         . mode = 'c'  : File Close
 *
 *****************************************************************************/
int AWSM_IO(YY, MM, DD, HH, MI, aws_id, aws, mode)
    int    YY, MM, DD, HH, MI, aws_id;
    struct AWS_DATA  aws[];
    char   mode;
{
    static FILE  *fd;
    static int   fnode = -1;
    static char  rw = 'r';
    long   offset = 0;
    char   dname[120], tmp[MAXLINE];
    int    node, nstn, nio, code;

    /*
    File Close & ID range check
    */

    if (mode == 'c')
    {
        fclose(fd);
        fnode = -1;
        rw = 'r';
        return 0;
    }
    if (aws_id >= 1000) aws_id %= 1000;

    /*
    File Open
    */

    printf("1\n");
    node = ((YY*100 + MM)*100 + DD)*100 + HH;
    printf("1-1\n");
    if (node != fnode || (rw != mode && rw != 'w'))
    {
      
        if (fd != NULL) 
            fclose(fd)  
            ;
      
        if (rw != 'w') rw = mode;

        sprintf(dname, "%s/%04d%02d/%02d/AWSM_%04d%02d%02d%02d",
                AWS_DIR, YY, MM, DD, YY, MM, DD, HH);
        
    printf("11:%s\n",dname);
        if (rw == 'w') fd = fopen(dname, "rb+");
        else           fd = fopen(dname, "rb");
    printf("111:%s\n",dname);
        if (fd == NULL)
        {
            sprintf(tmp, "[ AWSM ] File not opened (%s,%c)", dname, rw);
            awsio_error(&fnode, &offset, tmp);
            printf("open error\n");
            return -1;
        }
        else
        {
            fnode = node;
        }
    }

    /*
    Move to Read Pointer
    */

    printf("2\n");
    offset = MI * NUM_AWS * AWS_DATA_len;
    if (aws_id < 0)
    {
        nstn = NUM_AWS;
    }
    else
    {
        offset += aws_id * AWS_DATA_len;
        nstn = 1;
    }

    printf("len:offset:%d:%d\n", AWS_DATA_len, offset);
    if (fseek(fd, offset, SEEK_SET) != 0)
    {
        sprintf(tmp, "[ AWSM ] fseek error (%s,%d)", dname, offset);
        awsio_error(&fnode, &offset, tmp);
        return -3;
    }

    /*
    Data Read & Write
    */

    if      (mode == 'r') nio = fread(aws, AWS_DATA_len, nstn, fd);
    else if (mode == 'w') nio = fwrite(aws, AWS_DATA_len, nstn, fd);

    if (nio != nstn)
    {
        sprintf(tmp, "[ AWSM ] IO error (%c,%04d%02d%02d%02d%02d_%d)",
                mode, YY, MM, DD, HH, MI, aws_id);
        awsio_error(&fnode, &offset, tmp);
        return -4;
    }
    return 0;
}

/*****************************************************************************
 *
 *  gzip ����� AWSM �ڷῡ�� � ����Ͻú��� AWS �ź��ڷḦ ����
 *
 *    o YY,MM,DD,HH,MI   : ��,��,��,��,��
 *    o aws_id           : AWS ID
 *         . aws_id > -1 : �ش������� AWS �ڷ�
 *         . aws_id = -1 : ��û�ð��� ��� AWS �ڷ�
 *    o aws[]            : AWS �ڷ�
 *    o mode             : �ڷ� ����� ���
 *         . mode = 'r'  : �б� (���� 0, ���� < 0)
 *         . mode = 'c'  : File Close
 *    *) �б��ɸ� ����
 *
 *****************************************************************************/
int GZAWSM_IO(YY, MM, DD, HH, MI, aws_id, aws, mode)
    int    YY, MM, DD, HH, MI, aws_id;
    struct AWS_DATA  aws[];
    char   mode;
{
    static FILE  *fd;
    static int   fnode = -1;
    static long  offset = 0;
    char   dname[120], tmp[MAXLINE];
    int    node, nstn, nio, code;
    long   pt, len;

    /*
    File Close & ID range check
    */

    if (mode == 'c')
    {
        gzclose(fd);
        fnode = -1;
        return 0;
    }
    if (mode != 'r') return -2;
    if (aws_id >= 1000) aws_id %= 1000;

    /*
    File Open
    */

    node = ((YY*100 + MM)*100 + DD)*100 + HH;
    if (node != fnode)
    {
        if (fd != NULL) gzclose(fd);

        sprintf(dname, "%s/%04d%02d/%02d/AWSM_%04d%02d%02d%02d.gz",
                AWS_DIR, YY, MM, DD, YY, MM, DD, HH);

        fd = gzopen(dname, "rb");

        if (fd == NULL)
        {
            sprintf(tmp, "[ GZAWSM ] File not opened (%s)", dname);
            awsio_error(&fnode, &offset, tmp);
            return -1;
        }
        fnode = node;
        offset = 0;
    }

    /*
    Move to Read Pointer
    */

    pt = MI * NUM_AWS * AWS_DATA_len;
    if (aws_id < 0)
    {
        nstn = NUM_AWS * AWS_DATA_len;
    }
    else
    {
        pt += (aws_id * AWS_DATA_len);
        nstn = AWS_DATA_len;
    }

    len = pt - offset;
    if (len < 0)
    {
        gzrewind(fd);
        code = gzseek(fd, pt, SEEK_SET);
    }
    else
    {
        code = gzseek(fd, len, SEEK_CUR);
    }

    if (code < 0)
    {
        sprintf(tmp, "[ GZAWSM ] fseek error (%s,%d)", dname, code);
        gzrewind(fd);
        awsio_error(&fnode, &offset, tmp);
        return -3;
    }

    /*
    Data Read
    */

    nio = gzread(fd, aws, nstn);
    if (nio != nstn)
    {
        sprintf(tmp, "[ GZAWSM ] IO error (%c,%04d%02d%02d%02d%02d_%d)",
                mode, YY, MM, DD, HH, MI, aws_id);
        awsio_error(&fnode, &offset, tmp);
        return -4;
    }
    offset = pt + nstn;
    return 0;
}

/*****************************************************************************
 *
 *  AWSH �ڷῡ�� � ����Ͻ��� AWS �����ڷḦ ó��
 *
 *    o YY,MM,DD,HH      : ��,��,��,��
 *    o aws_id           : AWS ID
 *         . aws_id > -1 : �ش������� AWS �ڷ�
 *         . aws_id = -1 : ��û�ð��� ��� AWS �ڷ�
 *    o aws[]            : AWS �ڷ�
 *    o mode             : �ڷ� ����� ���
 *         . mode = 'r'  : �б� (���� 0, ���� < 0)
 *         . mode = 'w'  : ���� (���� 0, ���� < 0)
 *         . mode = 'c'  : File Close
 *
 *****************************************************************************/
int AWSH_IO(YY, MM, DD, HH, aws_id, aws, mode)
    int    YY, MM, DD, HH, aws_id;
    struct AWS_DATA  aws[];
    char   mode;
{
    static FILE  *fd;
    static int   fnode = -1;
    static char  rw = 'r';
    long   offset = 0;
    char   dname[120], tmp[MAXLINE];
    int    node, nstn, nio, code;

    /*
    File Close & ID range check
    */

    if (mode == 'c')
    {
        fclose(fd);
        fnode = -1;
        rw = 'r';
        return 0;
    }
    if (aws_id >= 1000) aws_id %= 1000;

    /*
    File Open
    */

    node = (YY*100 + MM)*100 + DD;
    if (node != fnode || (rw != mode && rw != 'w'))
    {
        if (fd != NULL) fclose(fd);
        if (rw != 'w') rw = mode;

        sprintf(dname, "%s/%04d%02d/%02d/AWSH_%04d%02d%02d",
                AWS_DIR, YY, MM, DD, YY, MM, DD);

        if (rw == 'w') fd = fopen(dname, "rb+");
        else           fd = fopen(dname, "rb");

        if (fd == NULL)
        {
            sprintf(tmp, "[ AWSH ] File not opened (%s,%c)", dname, rw);
            awsio_error(&fnode, &offset, tmp);
            return -1;
        }
        else
        {
            fnode = node;
        }
    }

    /*
    Move to Read Pointer
    */

    offset = HH * NUM_AWS * AWS_DATA_len;
    if (aws_id < 0)
    {
        nstn = NUM_AWS;
    }
    else
    {
        offset += aws_id * AWS_DATA_len;
        nstn = 1;
    }

    if (fseek(fd, offset, SEEK_SET) != 0)
    {
        sprintf(tmp, "[ AWSH ] fseek error (%s,%d)", dname, offset);
        awsio_error(&fnode, &offset, tmp);
        return -3;
    }

    /*
    Data Read & Write
    */

    if      (mode == 'r') nio = fread(aws, AWS_DATA_len, nstn, fd);
    else if (mode == 'w') nio = fwrite(aws, AWS_DATA_len, nstn, fd);

    if (nio != nstn)
    {
        sprintf(tmp, "[ AWSH ] IO error (%c,%04d%02d%02d%02d_%d)",
                mode, YY, MM, DD, HH, aws_id);
        awsio_error(&fnode, &offset, tmp);
        return -4;
    }
    return 0;
}

/*****************************************************************************
 *
 *  AWSD �ڷῡ�� � ������� AWS ���ڷḦ ó��
 *
 *    o YY,MM,DD         : ��,��,��
 *    o aws_id           : AWS ID
 *         . aws_id > -1 : �ش������� AWS �ڷ�
 *         . aws_id = -1 : ��û�ð��� ��� AWS �ڷ�
 *    o aws[]            : AWS �ڷ�
 *    o mode             : �ڷ� ����� ���
 *         . mode = 'r'  : �б� (���� 0, ���� < 0)
 *         . mode = 'w'  : ���� (���� 0, ���� < 0)
 *         . mode = 'c'  : File Close
 *
 *****************************************************************************/
int AWSD_IO(YY, MM, DD, aws_id, aws, mode)
    int    YY, MM, DD, aws_id;
    struct AWS_DAY  aws[];
    char   mode;
{
    static FILE  *fd;
    static int   fnode = -1;
    static char  rw = 'r';
    long   offset = 0;
    char   dname[120], tmp[MAXLINE];
    int    node, nstn, nio, code;

    /*
    File Close & ID range check
    */

    if (mode == 'c')
    {
        fclose(fd);
        fnode = -1;
        rw = 'r';
        return 0;
    }
    if (aws_id >= 1000) aws_id %= 1000;

    /*
    File Open
    */

    node = (YY*100 + MM)*100 + DD;
    if (node != fnode || (rw != mode && rw != 'w'))
    {
        if (fd != NULL) fclose(fd);
        if (rw != 'w') rw = mode;

        sprintf(dname, "%s/%04d%02d/%02d/AWSD_%04d%02d%02d",
                AWS_DIR, YY, MM, DD, YY, MM, DD);

        if (rw == 'w') fd = fopen(dname, "rb+");
        else           fd = fopen(dname, "rb");

        if (fd == NULL)
        {
            sprintf(tmp, "[ AWSD ] File not opened (%s,%c)", dname, rw);
            awsio_error(&fnode, &offset, tmp);
            return -1;
        }
        else
        {
            fnode = node;
        }
    }

    /*
    Move to Read Pointer
    */

    if (aws_id < 0)
    {
        offset = 0;
        nstn = NUM_AWS;
    }
    else
    {
        offset = aws_id * AWS_DAY_len;
        nstn = 1;
    }

    if (fseek(fd, offset, SEEK_SET) != 0)
    {
        sprintf(tmp, "[ AWSD ] fseek error (%s,%d)", dname, offset);
        awsio_error(&fnode, &offset, tmp);
        return -3;
    }

    /*
    Data Read & Write
    */

    if      (mode == 'r') nio = fread(aws, AWS_DAY_len, nstn, fd);
    else if (mode == 'w') nio = fwrite(aws, AWS_DAY_len, nstn, fd);

    if(nio != nstn)
    {
        sprintf(tmp, "[ AWSD ] IO error (%c,%04d%02d%02d_%d)",
                mode, YY, MM, DD, aws_id);
        awsio_error(&fnode, &offset, tmp);
        return -4;
    }
    return 0;
}

/*****************************************************************************
 *
 *  AWS �ź� �� �����ڷ� �ʱ�ȭ
 *
 *    o ID, ������ : -999,  �ð� : 0
 *
 *****************************************************************************/
int AWS_DATA_ini(aws)
    struct AWS_DATA *aws;
{
    int  i;

    (*aws).aws_id = -999;   (*aws).lau_id = -999;
    (*aws).aws_tm.YY = 0;   (*aws).aws_tm.MM = 0;   (*aws).aws_tm.DD = 0;
    (*aws).aws_tm.HH = 0;   (*aws).aws_tm.MI = 0;
    (*aws).lau_tm.YY = 0;   (*aws).lau_tm.MM = 0;   (*aws).lau_tm.DD = 0;
    (*aws).lau_tm.HH = 0;   (*aws).lau_tm.MI = 0;
    (*aws).rec_tm.YY = 0;   (*aws).rec_tm.MM = 0;   (*aws).rec_tm.DD = 0;
    (*aws).rec_tm.HH = 0;   (*aws).rec_tm.MI = 0;
    for(i = 0; i < AWS_DATA_dnum; i++) (*aws).d[i] = -999;
    for(i = 0; i <  4; i++) (*aws).qc[i] = 0;

    return 0;
}

/*****************************************************************************
 *
 *  AWS ���ڷ� �ʱ�ȭ
 *
 *    o ID, ������ : -999,  �ð� : 0
 *
 *****************************************************************************/
int AWS_DAY_ini(day)
    struct AWS_DAY *day;
{
    int  i;

    (*day).aws_id = -999;
    (*day).YY = 0;   (*day).MM = 0;   (*day).DD = 0;
    for(i = 0; i < AWS_DAY_dnum; i++) (*day).d[i] = -999;

    return 0;
}

/*****************************************************************************
 *
 *  �ź��ڷ��� ���, 15��/60��/12�ð� �̵����������� ���
 *
 *****************************************************************************/
int rain_acc(aws)
    struct AWS_DATA  *aws;
{
    struct AWS_DATA  aws1, aws2;
    int    YY1, MM1, DD1, HH1, MI1;     /* ���� ���� �ð� */
    int    YY2, MM2, DD2, HH2, MI2;     /* ���� ���� �ð� */
    int    YY3, MM3, DD3, HH3, MI3;     /* �ϰ谡 �ٲ�� ���, ���� ������ �ð� */
    int    seq1, seq2, seq3;
    int    rain1, rain2, rain3;
    float  rain;
    int    acc_min[3] = {15,60,720}, min;
    int    i, j, k, n;

    /*
    ���� �������� �𸣸� ������� ����
    */

    (*aws).d[11] = -999;
    (*aws).d[24] = -999;
    (*aws).d[25] = -999;

    aws1 = *aws;
    AWS_QCD(&aws1);
    if (aws1.d[12] < 0) return -1;
    rain1 = aws1.d[12];

    /*
    ���۽ð� Ȯ��
    */

    YY1 = aws1.aws_tm.YY;
    MM1 = aws1.aws_tm.MM;
    DD1 = aws1.aws_tm.DD;
    HH1 = aws1.aws_tm.HH;
    MI1 = aws1.aws_tm.MI;
    seq1 = time2seq(YY1, MM1, DD1, HH1, MI1, 'm');

    /*
    �̵� ���� ������ ���
    */

    for (n = 0; n < 3; n++)
    {
        seq2 = seq1 - acc_min[n];

        /*
        ���۽����� ������ Ȯ�� (������ ���� 3�б��� �ڷ� ���)
        */

        rain2 = -999;

        for (k = 0; k <= 3; k++)
        {
            for (j = -1; j <= 1; j += 2)
            {
                seq2time(seq2+j*k, &YY2, &MM2, &DD2, &HH2, &MI2, 'm', 'n');
                AWS_DATA_ini(&aws2);
                AWSM_IO(YY2, MM2, DD2, HH2, MI2, (int)aws1.aws_id, &aws2, 'r');
                AWS_QCD(&aws2);

                if (aws2.d[12] >= 0)
                {
                    rain2 = aws2.d[12];
                    seq2 += j*k;
                    break;
                }
                if (k == 0) break;      /* �ѹ��� ��� */
            }
            if (rain2 >= 0) break;      /* ���������� ����� AWS �ϰ������� 0 �̻��� */
        }
        if (HH2 == 0 && MI2 == 0 && rain2 >= 0) rain2 = 0;  /* 00:00 �� ������ �ϴ����� */

        /*
        �̵����������� ��� (���� �����Ⱓ�� ������ 80%���� ���) �ϰ谡 �ٲ�� ��� ����
        */

        rain = -999;

        if ((DD1 == DD2) || (HH1 == 0 && MI1 == 0))
        {
            min = seq1 - seq2;
            if ((float)acc_min[n]*0.8 <= (float)min && rain2 <= rain1 && rain2 >= 0)
                rain = (float)(rain1 - rain2)*acc_min[n]/(float)min;
            else
                rain = -999;
        }

        /*
        �ϰ谡 �ɸ��� ���, ���ϰ������� 24�ÿ��� 15�������� ���
        */

        else
        {
            seq3 = time2seq(YY1, MM1, DD1, 0, 0, 'm');
            rain3 = -999;

            for (j = 0; j <= 15; j++)
            {
                seq2time(seq3, &YY3, &MM3, &DD3, &HH3, &MI3, 'm', 'n');
                AWS_DATA_ini(&aws2);
                AWSM_IO(YY3, MM3, DD3, HH3, MI3, (int)aws1.aws_id, &aws2, 'r');
                AWS_QCD(&aws2);
                if (aws2.d[12] >= 0 && rain3 < aws2.d[12]) rain3 = aws2.d[12];
                if (seq3 <= seq2 || rain3 >= 0) break;
                seq3--;
            }

            if (rain2 >= 0 && rain3 >= 0 && rain3 >= rain2)
            {
                rain = (float)(rain3 - rain2) + (float)rain1;
                min = (seq3 - seq2) + (HH1*60 + MI1);

                if ((float)acc_min[n]*0.8 <= (float)min) rain = rain*acc_min[n]/(float)min;
                else rain = -999;
            }
            else
            {
                rain = -999;
            }
        }

        /*
        ��� ���
        */

        if (rain >= 0)
        {
            if      (n == 0) (*aws).d[24] = (int)(rain + 0.5);
            else if (n == 1) (*aws).d[25] = (int)(rain + 0.5);
            else if (n == 2) (*aws).d[11] = (int)(rain + 0.5);
        }
    }
    return 0;
}

/*****************************************************************************
 *
 *  �ź��ڷ��� ���, 10�� ��� ǳ��/ǳ�� ���
 *
 *****************************************************************************/
int wd10_avg(aws)
    struct AWS_DATA  *aws;
{
    struct AWS_DATA  aws1, aws2;
    float  x, y, v, deg, deg2rad, rad2deg;
    int    YY1, MM1, DD1, HH1, MI1;
    int    YY2, MM2, DD2, HH2, MI2;
    int    seq1, seq2, seq3;
    int    wd[10], ws[10];
    int    ws10 = 0, wd10 = 0;
    int    i, j, k, n;

    /*
    �ʱ�ȭ
    */

    deg2rad = asin(1.0)/90.0;
    rad2deg = 90.0/asin(1.0);

    /*
    �ڷ� �ð� �� ǳ��/ǳ�� Ȯ��
    */

    aws1 = *aws;
    AWS_QCD(&aws1);

    YY1 = aws1.aws_tm.YY;
    MM1 = aws1.aws_tm.MM;
    DD1 = aws1.aws_tm.DD;
    HH1 = aws1.aws_tm.HH;
    MI1 = aws1.aws_tm.MI;
    seq1 = time2seq(YY1, MM1, DD1, HH1, MI1, 'm');

    wd[0] = aws1.d[0];
    ws[0] = aws1.d[1];

    /*
    ���� 10�а� ǳ��/ǳ�� ����
    */

    for (i = 1; i < 10; i++)
    {
        seq2 = seq1 - i;

        seq2time(seq2, &YY2, &MM2, &DD2, &HH2, &MI2, 'm', 'n');
        AWS_DATA_ini(&aws2);
        AWSM_IO(YY2, MM2, DD2, HH2, MI2, (int)aws1.aws_id, &aws2, 'r');
        AWS_QCD(&aws2);

        wd[i] = aws2.d[0];
        ws[i] = aws2.d[1];
    }

    /*
    10�� ��� ǳ��
    */

    for (n = 0, i = 0; i < 10; i++)
    {
        if (ws[i] >= 0)
        {
            ws10 += ws[i];
            n++;
        }
    }

    if (n > 5)
        ws10 = (int)((float)ws10/(float)n + 0.5);
    else
        ws10 = -999;

    (*aws).d[28] = ws10;

    /*
    10�� ��� ǳ��
    */

    x = 0;
    y = 0;

    for (n = 0, i = 0; i < 10; i++)
    {
        if (wd[i] >= 0 && ws[i] >= 0)
        {
            deg = 0.1 * (float)wd[i] * deg2rad;
            x += (float)ws[i] * cos(deg);
            y += (float)ws[i] * sin(deg);

            n++;
        }
    }

    if (n > 5)
    {
        x /= (float)n;
        y /= (float)n;

        v = atan2(y,x) * rad2deg * 10;
        if (v < 0) v += 3600;
        wd10 = (int)(v + 0.5);
    }
    else
    {
        wd10 = -999;
    }

    (*aws).d[27] = wd10;

    return 0;
}

/*****************************************************************************
 *
 *  �ϱذ� ��
 *
 *****************************************************************************/
int aws_day_calc(aws, day)
    struct AWS_DATA  aws;
    struct AWS_DAY  *day;
{
    int    d1, d2;
    int    YY, MM, DD, HH, MI;

    /*
    �ź��ڷ� QC
    */

    AWS_QCD(&aws);

    /*
    �ð� Ȯ��
    */

    YY = aws.aws_tm.YY;
    MM = aws.aws_tm.MM;
    DD = aws.aws_tm.DD;
    HH = aws.aws_tm.HH;
    MI = aws.aws_tm.MI;

    if (YY < 1990 || YY > 2100) return -79;
    if (MM < 1 || MM > 12) return -78;
    if (DD < 1 || DD > 31) return -77;
    if (HH < 0 || HH > 24) return -76;
    if (MI < 0 || MI > 60) return -75;

    /*
    ���ڷ� ������ȣ �� ����
    */

    (*day).aws_id = aws.aws_id;
    (*day).YY = (short)YY;
    (*day).MM = (short)MM;
    (*day).DD = (short)DD;

    /*
    �ִ� ����ǳ
    */

    if ((int)((*day).d[1]) < (int)(aws.d[5]))
    {
        (*day).d[0] = aws.d[4];
        (*day).d[1] = aws.d[5];
        (*day).d[2] = (short)(HH*100 + MI);
    }

    /*
    1�� ��� �ִ�ǳ
    */

    if ((int)((*day).d[4]) < (int)(aws.d[1]))
    {
        (*day).d[3] = aws.d[0];
        (*day).d[4] = aws.d[1];
        (*day).d[5] = (short)(HH*100 + MI);
    }

    /*
    10�� ��� �ִ�ǳ
    */

    if ((int)((*day).d[7]) < (int)(aws.d[28]))
    {
        (*day).d[6] = aws.d[27];
        (*day).d[7] = aws.d[28];
        (*day).d[8] = (short)(HH*100 + MI);
    }

    /*
    1����� ������� �ذ��� ���
    */

    d1 = (int)(aws.d[6]);
    if (d1 > -500 && d1 < 500)
    {
        d2 = (int)((*day).d[9]);
        if (d2 > d1 || d2 < -500)               /* ���� ��� */
        {
            (*day).d[9]  = (short)d1;
            (*day).d[10] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[11]) < d1)           /* �ְ� ��� */
        {
            (*day).d[11] = (short)d1;
            (*day).d[12] = (short)(HH*100 + MI);
        }
    }

    /*
    1����� ������ �ذ��� ���
    */

    d1 = (int)(aws.d[14]);
    if (d1 > 50 && d1 <= 1000)
    {
        d2 = (int)((*day).d[13]);
        if (d2 > d1 || d2 < 0)                  /* ���� ���� */
        {
            (*day).d[13] = (short)d1;
            (*day).d[14] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[15]) < d1)           /* �ְ� ���� */
        {
            (*day).d[15] = (short)d1;
            (*day).d[16] = (short)(HH*100 + MI);
        }
    }

    /*
    1����� �ظ������� �ذ��� ���
    */

    d1 = (int)(aws.d[26]);
    if (d1 > 6000 && d1 < 12000)
    {
        d2 = (int)((*day).d[17]);
        if (d2 > d1 || d2 < 0)                  /* ���� �ظ��� */
        {
            (*day).d[17] = (short)d1;
            (*day).d[18] = (short)(HH*100 + MI);
        }

        if ((int)((*day).d[19]) < d1)           /* �ְ� �ظ��� */
        {
            (*day).d[19] = (short)d1;
            (*day).d[20] = (short)(HH*100 + MI);
        }
    }

    /*
    �� ������ (1�б��� ������ �ϰ������� �� ��찡 ����. AWS �ΰ��� ���α׷� ���� ����)
    */

    if ((int)aws.d[12] > (int)(*day).d[21])
    {
        if (HH*100+MI > 1)
        {
            (*day).d[21] = aws.d[12];
            (*day).d[22] = (short)(HH*100 + MI);
        }
    }
    /*day.d[21] = aws.d[12];*/

    return 0;
}

/*****************************************************************************
 *
 *  �ظ����
 *
 *****************************************************************************/
float slp(p, t, h, lat)
    float  p;          /* �������    */
    float  t;          /* ���(C)     */
    float  h;          /* ��������(m) */
    float  lat;        /* ����        */
{
    float  e[16] = {0.1, 0.1, 0.1, 0.2, 0.3, 0.4, 0.5, 0.7, 1.0, 1.4,
                    2.1, 2.8, 3.2, 3.3, 3.3, 3.3};
    float  tm, em;
    float  cs, g, sp;
    int    j;

    if (p < 500.0 || p > 1200.0) return -99.9;

    lat *= asin(1.0) / 90.0;
    cs = cos(2.0*lat);
    g  = 980.616 * (1.0 - 0.00263*cs + 0.0000059*cs*cs) - 0.0003086*h;
    g *= 0.01;

    if (t > -40 && t < 45)
    {
        tm = t + 0.0025*h;

        j = (int)((tm+30.0)/5.0);

        if (j < 0)        em = 0.1;
        else if (j > 15)  em = 3.3;
        else              em = e[j] + (e[j+1] - e[j])*(tm+30.0-j*5.0);

        sp = g*h/(287.04*(273.16+tm+em));
        sp = p*exp(sp);
    } else {
        sp = -99.9;
    }
    return sp;
}

/*****************************************************************************
 *  Error message print
 *****************************************************************************/
void awsio_error(int *fnode, long *offset, char *s)
{
    int mode = 0;

    *fnode = -1;
    *offset = 0;

    if (strlen(s) > 0 && mode)
    {
        strcat(s, " : ");
        strcat(s, strerror(errno));
        strcat(s, "\n");
        fputs(s, stdout);
    }
    return;
}
