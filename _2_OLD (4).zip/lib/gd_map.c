#include <stdio.h>
#include <stdlib.h>
#include <gd.h>
#include "map_ini.h"

/******************************************************************
 *
 *  gd image�� ���� ��輱 ǥ�� (Albert Equal-Area Projection)
 *
 ******************************************************************/
int gd_bln_albe(im, color, depth, map, xm, ym, fname)
    gdImagePtr  im;
    int    color;                   /* ��輱�� ��   */
    int    depth;                   /* ��輱�� �β� */
    struct albe_parameter  map;
    float  xm, ym;                  /* BOX�� ũ�� [0:xm,0:ym] */
    char   fname[256];              /* �������� �̸� */
{
    int    i, num, now;
    char   code[16], cc;
    float  x1, y1, x2, y2, x, y;
    float  lon, lat;
    FILE   *fd;

    if( (fd = fopen(fname, "r")) == NULL ) {
        printf(" file not opened (%s)\n", fname);
        return -1;
    }
    for(;;) {
        if( fscanf(fd, "%d %s", &num, code) != EOF ) {
            cc = atoi(code);
            fscanf(fd, "%f %f", &lon, &lat);
            if (cc != 3) {
                albeproj(&lon, &lat, &x1, &y1, 0, map);
                y1 = ym - y1;
                if( x1 >= 0.0 && x1 <= xm && y1 >= 0.0 && y1 <= ym )
                    now = 1;
                else
                    now = 0;
            }

            for(i = 1; i < num; i++) {
                fscanf(fd, "%f %f", &lon, &lat);
                if (cc == 3) continue;
                albeproj(&lon, &lat, &x2, &y2, 0, map);
                y2 = ym - y2;
                if( x2 >= 0.0 && x2 <= xm && y2 >= 0.0 && y2 <= ym ) {
                    if( now != 1 ) {
                        CrossPoint(x1, y1, x2, y2, xm, ym, &x, &y);
                        x1 = x;
                        y1 = y;
                        now = 1;
                    }
                    gdImageLine(im, (int)(x1+0.5), (int)(y1+0.5),
                                    (int)(x2+0.5), (int)(y2+0.5), color);
                    if( depth > 0 ) {
                        gdImageLine(im, (int)(x1+1.5), (int)(y1+0.5),
                                        (int)(x2+1.5), (int)(y2+0.5), color);
                    }
                } else {
                    if( now == 1 ) {
                        CrossPoint(x1, y1, x2, y2, xm, ym, &x, &y);
                        gdImageLine(im, (int)(x1+0.5), (int)(y1+0.5),
                                        (int)(x+0.5), (int)(y+0.5), color);
                        if( depth > 0 ) {
                            gdImageLine(im, (int)(x1+1.5), (int)(y1+0.5),
                                            (int)(x+1.5), (int)(y+0.5), color);
                        }
                        now = 0;
                    }
                }
                x1 = x2;
                y1 = y2;
            }
        } else {
            break;
        }
    }
    fclose(fd);
    return 0;
}

/******************************************************************
 *
 *  gd image�� ���� ��輱 ǥ�� (Lambert Conformal Conic Projection)
 *
 ******************************************************************/
int gd_bln_lamc(im, color, depth, map, xm, ym, fname)
    gdImagePtr  im;
    int    color;                   /* ��輱�� ��   */
    int    depth;                   /* ��輱�� �β� */
    struct lamc_parameter  map;
    float  xm, ym;                  /* BOX�� ũ�� [0:xm,0:ym] */
    char   fname[256];              /* �������� �̸� */
{
    int    i, num, now;
    char   code[16], cc;
    float  x1, y1, x2, y2, x, y;
    float  lon, lat;
    FILE   *fd;

    if( (fd = fopen(fname, "r")) == NULL ) {
        printf(" file not opened (%s)\n", fname);
        return -1;
    }
    for(;;) {
        if( fscanf(fd, "%d %s", &num, code) != EOF ) {
            cc = atoi(code);
            fscanf(fd, "%f %f", &lon, &lat);
            if (cc != 3) {
                lamcproj(&lon, &lat, &x1, &y1, 0, map);
                y1 = ym - y1;
                if( x1 >= 0.0 && x1 <= xm && y1 >= 0.0 && y1 <= ym )
                    now = 1;
                else
                    now = 0;
            }

            for(i = 1; i < num; i++) {
                fscanf(fd, "%f %f", &lon, &lat);
                if (cc == 3) continue;
                lamcproj(&lon, &lat, &x2, &y2, 0, map);
                y2 = ym - y2;
                if( x2 >= 0.0 && x2 <= xm && y2 >= 0.0 && y2 <= ym ) {
                    if( now != 1 ) {
                        CrossPoint(x1, y1, x2, y2, xm, ym, &x, &y);
                        x1 = x;
                        y1 = y;
                        now = 1;
                    }
                    gdImageLine(im, (int)(x1+0.5), (int)(y1+0.5),
                                    (int)(x2+0.5), (int)(y2+0.5), color);
                    if( depth > 0 ) {
                        gdImageLine(im, (int)(x1+1.5), (int)(y1+0.5),
                                        (int)(x2+1.5), (int)(y2+0.5), color);
                    }
                } else {
                    if( now == 1 ) {
                        CrossPoint(x1, y1, x2, y2, xm, ym, &x, &y);
                        gdImageLine(im, (int)(x1+0.5), (int)(y1+0.5),
                                        (int)(x+0.5), (int)(y+0.5), color);
                        if( depth > 0 ) {
                            gdImageLine(im, (int)(x1+1.5), (int)(y1+0.5),
                                            (int)(x+1.5), (int)(y+0.5), color);
                        }
                        now = 0;
                    }
                }
                x1 = x2;
                y1 = y2;
            }
        } else {
            break;
        }
    }
    fclose(fd);
    return 0;
}

/******************************************************************
 *
 *  gd image�� ���� ��輱 ǥ�� (Polar Stereographic Projection)
 *
 ******************************************************************/
int gd_bln_ster(im, color, depth, map, xm, ym, fname)
    gdImagePtr  im;
    int    color;                   /* ��輱�� ��   */
    int    depth;                   /* ��輱�� �β� */
    struct ster_parameter  map;
    float  xm, ym;                  /* BOX�� ũ�� [0:xm,0:ym] */
    char   fname[256];              /* �������� �̸� */
{
    int    i, num, code, now;
    float  x1, y1, x2, y2, x, y;
    float  lon, lat;
    FILE   *fd;

    if( (fd = fopen(fname, "r")) == NULL ) {
        printf(" file not opened (%s)\n", fname);
        return -1;
    }
    for(;;) {
        if( fscanf(fd, "%d %d", &num, &code) != EOF ) {
            fscanf(fd, "%f %f", &lon, &lat);
            if( code == 3 ) continue;
            sterproj(&lon, &lat, &x1, &y1, 0, map);
            y1 = ym - y1;
            if( x1 >= 0.0 && x1 <= xm && y1 >= 0.0 && y1 <= ym )
                now = 1;
            else
                now = 0;

            for(i = 1; i < num; i++) {
                fscanf(fd, "%f %f", &lon, &lat);
                sterproj(&lon, &lat, &x2, &y2, 0, map);
                y2 = ym - y2;
                if( x2 >= 0.0 && x2 <= xm && y2 >= 0.0 && y2 <= ym ) {
                    if( now != 1 ) {
                        CrossPoint(x1, y1, x2, y2, xm, ym, &x, &y);
                        x1 = x;
                        y1 = y;
                        now = 1;
                    }
                    gdImageLine(im, (int)(x1+0.5), (int)(y1+0.5),
                                    (int)(x2+0.5), (int)(y2+0.5), color);
                } else {
                    if( now == 1 ) {
                        CrossPoint(x1, y1, x2, y2, xm, ym, &x, &y);
                        gdImageLine(im, (int)(x1+0.5), (int)(y1+0.5),
                                        (int)(x+0.5), (int)(y+0.5), color);
                        now = 0;
                    }
                }
                x1 = x2;
                y1 = y2;
            }
        } else {
            break;
        }
    }
    fclose(fd);
    return 0;
}

/******************************************************************
 *
 *  gd image�� ���� ��輱 ǥ�� (Azimuthal Equidistant Projection)
 *
 ******************************************************************/
int gd_bln_azed(im, color, depth, map, xm, ym, fname)
    gdImagePtr  im;
    int    color;                   /* ��輱�� ��   */
    int    depth;                   /* ��輱�� �β� */
    struct azed_parameter  map;
    float  xm, ym;                  /* BOX�� ũ�� [0:xm,0:ym] */
    char   fname[256];              /* �������� �̸� */
{
    int    i, num, code, now;
    float  x1, y1, x2, y2, x, y;
    float  lon, lat;
    FILE   *fd;

    if( (fd = fopen(fname, "r")) == NULL ) {
        printf(" file not opened (%s)\n", fname);
        return -1;
    }
    for(;;) {
        if( fscanf(fd, "%d %d", &num, &code) != EOF ) {
            fscanf(fd, "%f %f", &lon, &lat);
            if( code == 3 ) continue;
            azedproj(&lon, &lat, &x1, &y1, 0, map);
            y1 = ym - y1;
            if( x1 >= 0.0 && x1 <= xm && y1 >= 0.0 && y1 <= ym )
                now = 1;
            else
                now = 0;

            for(i = 1; i < num; i++) {
                fscanf(fd, "%f %f", &lon, &lat);
                azedproj(&lon, &lat, &x2, &y2, 0, map);
                y2 = ym - y2;
                if( x2 >= 0.0 && x2 <= xm && y2 >= 0.0 && y2 <= ym ) {
                    if( now != 1 ) {
                        CrossPoint(x1, y1, x2, y2, xm, ym, &x, &y);
                        x1 = x;
                        y1 = y;
                        now = 1;
                    }
                    gdImageLine(im, (int)(x1+0.5), (int)(y1+0.5),
                                    (int)(x2+0.5), (int)(y2+0.5), color);
                } else {
                    if( now == 1 ) {
                        CrossPoint(x1, y1, x2, y2, xm, ym, &x, &y);
                        gdImageLine(im, (int)(x1+0.5), (int)(y1+0.5),
                                        (int)(x+0.5), (int)(y+0.5), color);
                        now = 0;
                    }
                }
                x1 = x2;
                y1 = y2;
            }
        } else {
            break;
        }
    }
    fclose(fd);
    return 0;
}

/******************************************************************
 *
 *  BOX �Ȱ� ���� ������ �մ� ���� ��輱�� ������ ���� ��ǥ ���
 *
 ******************************************************************/
int CrossPoint(x1, y1, x2, y2, xm, ym, x, y)
    float  x1, y1, x2, y2;  /* �Ȱ� �ۿ� �ִ� ������ ��ǥ */
    float  xm, ym;          /* BOX�� ũ�� [0:xm,0:ym]     */
    float  *x, *y;          /* ��輱�� ������ ���� ��ǥ  */
{
    *y = -1.0;
    if( x1 < 0.0 || x2 < 0.0 ) {
        *y = -x1*(y2-y1)/(x2-x1) + y1;
        *x = 0.0;
    }
    else if( x1 > xm || x2 > xm ) {
        *y = (xm-x1)*(y2-y1)/(x2-x1) + y1;
        *x = xm;
    }

    if( *y < 0.0 || *y > ym ) {
        if( y1 < 0.0 || y2 < 0.0 ) {
            *x = -y1*(x2-x1)/(y2-y1) + x1;
            *y = 0.0;
        }
        else if( y1 > ym || y2 > ym ) {
            *x = (ym-y1)*(x2-x1)/(y2-y1) + x1;
            *y = ym;
        }
    }
    return 0;
}

/******************************************************************
 *
 *  ���浵�� (Lambert Conformal Conic Projection)
 *
 ******************************************************************/
int LonLat_lamc(im, lon1, lat1, lon2, lat2, dlon, dlat, map, xm, ym, color)
    gdImagePtr  im;
    float  lon1, lat1, lon2, lat2;
    float  dlon, dlat;
    struct lamc_parameter  map;
    int    color;
    float  xm, ym;
{
    float  lon, lat;
    float  x1, y1, x2, y2;

    /* �浵�� */
    for( lon = lon1; lon < lon2; lon += dlon ) {
        lamcproj(&lon, &lat1, &x1, &y1, 0, map);
        lamcproj(&lon, &lat2, &x2, &y2, 0, map);
        gdImageLine(im, (int)x1, (int)(ym-y1), (int)x2, (int)(ym-y2), color);
    }

    /* ������ */
    for( lat = lat1; lat < lat2; lat += dlat ) {
        lamcproj(&lon1, &lat, &x1, &y1, 0, map);
        for( lon = lon1 + 0.1; lon < lon2; lon += 0.1 ) {
            lamcproj(&lon, &lat, &x2, &y2, 0, map);
            gdImageLine(im, (int)x1, (int)(ym-y1), (int)x2, (int)(ym-y2), color);
            x1 = x2;
            y1 = y2;
        }
    }
    return 0;
}

/******************************************************************
 *
 *  ���浵�� (Lambert Conformal Conic Projection)
 *
 ******************************************************************/
int LonLat_azed(im, lon1, lat1, lon2, lat2, dlon, dlat, map, xm, ym, color)
    gdImagePtr  im;
    float  lon1, lat1, lon2, lat2;
    float  dlon, dlat;
    struct azed_parameter  map;
    int    color;
    float  xm, ym;
{
    float  lon, lat;
    float  x1, y1, x2, y2;

    /* �浵�� */
    for( lon = lon1; lon < lon2; lon += dlon ) {
        azedproj(&lon, &lat1, &x1, &y1, 0, map);
        azedproj(&lon, &lat2, &x2, &y2, 0, map);
        gdImageLine(im, (int)x1, (int)(ym-y1), (int)x2, (int)(ym-y2), color);
    }

    /* ������ */
    for( lat = lat1; lat < lat2; lat += dlat ) {
        azedproj(&lon1, &lat, &x1, &y1, 0, map);
        for( lon = lon1 + 0.1; lon < lon2; lon += 0.1 ) {
            azedproj(&lon, &lat, &x2, &y2, 0, map);
            gdImageLine(im, (int)x1, (int)(ym-y1), (int)x2, (int)(ym-y2), color);
            x1 = x2;
            y1 = y2;
        }
    }
    return 0;
}
