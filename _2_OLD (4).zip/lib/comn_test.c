#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "comn.h"

int com_bin_sav(char *nic, time_t tp, char *head, char *dname, int size)
{
    FILE   *fd;
    char   fname[120];
    struct COM_IPC  s1;
    struct COM_BIN  d1;
    time_t tm;
    int    s1_len, d1_len;
    
    printf("\ncomn_tes0 %s\n", dname);
    s1_len = sizeof(s1);
    d1_len = sizeof(d1);

    /*
    �Ϸù�ȣ ���Ͽ� ���
    */

    sprintf(fname, "%s/%s.ipc", REF_DST_DIR, nic);
    fd = fopen(fname, "rb+");
    if (fd == NULL) return -1;

    time(&tm);

    fread(&s1, 1, s1_len, fd);
    rewind(fd);

    s1.seq = (s1.seq + 1) % s1.max;
    s1.tm = tm;

    fwrite(&s1, 1, s1_len, fd);
    fclose(fd);

    printf("\ncomn_test %s\n", fname);
    /*
    �ڷḦ ��ȯ���Ͽ� ���
    */

    d1.tm    = tm;
    d1.cnt   = 0;
    d1.tm_fn = tp;
    d1.size  = size;
    strcpy(d1.head, head);
    strcpy(d1.fname, dname);

    sprintf(fname, "%s/%s.bin", REF_DST_DIR, nic);
    fd = fopen(fname, "rb+");
    if (fd == NULL) return -2;

    fseek(fd, (long)(d1_len*s1.seq), SEEK_SET);
    fwrite(&d1, 1, d1_len, fd);
    fclose(fd);
    printf("\ncomn_tes1 %s\n", fname);

    return 0;
}

/*===========================================================================*
 *  ���� �ֱ� ���� ���ϸ�� ��ġ
 *===========================================================================*/
int com_ipc_io(char *nic, struct COM_IPC *s1, char mode)
{
    static FILE  *fd;
    static char  nic_sav[64] = "-";
    static char  mode_sav = '-';
    char   fname[120];
    time_t tm;
    int    n, s1_len;
    
    s1_len = sizeof(*s1);

    if (mode == 'c')
    {
        fclose(fd);
        strcpy(nic_sav, "-");
        return 0;
    }

    if (strcmp(nic, nic_sav) != 0 || mode_sav != mode)
    {
        if (fd != NULL) fclose(fd);
        sprintf(fname, "%s/%s.ipc", REF_DST_DIR, nic);

        if (mode == 'w') fd = fopen(fname, "rb+");
        else             fd = fopen(fname, "rb");

        if (fd == NULL) return -1;
        strcpy(nic_sav, nic);
    }

    if (mode == 'w')
    {
        n = fread(s1, 1, s1_len, fd);
        if (n <= 0) return -2;

        rewind(fd);
        (*s1).seq = ((*s1).seq + 1) % (*s1).max;
        time(&tm);
        (*s1).tm = tm;
        n = fwrite(s1, 1, s1_len, fd);
        if (n <= 0) return -3;
        fflush(fd);
    }
    else
    {
        n = fread(s1, 1, s1_len, fd);
        if (n <= 0) return -2;
    }
    rewind(fd);

    return 0;
}

/*===========================================================================*
 *  ���� ���� ���
 *===========================================================================*/
int com_bin_io(char *nic, int seq, struct COM_BIN *b1, char mode)
{
    static FILE  *fd;
    static char  nic_sav[64] = "-";
    static char  mode_sav = '-';
    char   fname[120];
    time_t tm;
    int    code, n, b1_len;
    
    b1_len = sizeof(*b1);

    if (mode == 'c')
    {
        fclose(fd);
        strcpy(nic_sav, "-");
        return 0;
    }

    if (strcmp(nic, nic_sav) != 0 || mode_sav != mode)
    {
        if (fd != NULL) fclose(fd);
        sprintf(fname, "%s/%s.bin", REF_DST_DIR, nic);

        if (mode == 'w') fd = fopen(fname, "rb+");
        else             fd = fopen(fname, "rb");

        if (fd == NULL) return -1;
        strcpy(nic_sav, nic);
    }

    code = fseek(fd, (long)(b1_len*seq), SEEK_SET);
    if (code != 0) return -2;

    if (mode == 'w')
    {
        n = fwrite(b1, 1, b1_len, fd);
        if (n <= 0) return -3;
        fflush(fd);
    }
    else
    {
        n = fread(b1, 1, b1_len, fd);
        if (n <= 0) return -3;
    }
    return 0;
}

/*===========================================================================*
 *  ó����Ȳ�� ���
 *===========================================================================*/
int com_out_io(char *nic, int seq, int nic_num, struct COM_OUT *t1, char mode)
{
    static FILE  *fd;
    static char  nic_sav[64] = "-";
    static char  mode_sav = '-';
    char   fname[120];
    time_t tm;
    int    code, n, t1_len;

    t1_len = sizeof(*t1);
    
    if (mode == 'c')
    {
        fclose(fd);
        strcpy(nic_sav, "-");
        return 0;
    }

    if (strcmp(nic, nic_sav) != 0 || mode_sav != mode)
    {
        if (fd != NULL) fclose(fd);
        sprintf(fname, "%s/%s.out", REF_DST_DIR, nic);

        if (mode == 'w') fd = fopen(fname, "rb+");
        else             fd = fopen(fname, "rb");

        if (fd == NULL) return -1;
        strcpy(nic_sav, nic);
    }

/*-------------------------------------------------------------------
    type time_t (unix:4byte -> linux:8byte)���� length����(8 -> 16)
    ������ : choijy  2006/09/14   
    old : code = fseek(fd, (long)(8*NUM_OPC*seq + 8*nic_num), SEEK_SET);
  -------------------------------------------------------------------*/
    code = fseek(fd, (long)(t1_len*NUM_OPC*seq + t1_len*nic_num), SEEK_SET);
    if (code != 0) return -2;

    if (mode == 'w')
    {
        n = fwrite(t1, 1, sizeof(*t1), fd);
        if (n <= 0) return -3;
        fflush(fd);
    }
    else
    {
        n = fread(t1, 1, sizeof(*t1), fd);
        if (n <= 0) return -3;
    }
    return 0;
}

/*===========================================================================*
 *  ó�� �Ϸ� �ð�
 *===========================================================================*/
int com_opc_io(char *nic, int nic_num, struct COM_OPC *o1, char mode)
{
    static FILE  *fd;
    static char  nic_sav[64] = "-";
    static char  mode_sav = '-';
    char   fname[120];
    time_t tm;
    int    code, n, o1_len;
    
    o1_len = sizeof(*o1);

    if (mode == 'c')
    {
        fclose(fd);
        strcpy(nic_sav, "-");
        return 0;
    }

    if (strcmp(nic, nic_sav) != 0 || mode_sav != mode)
    {
        if (fd != NULL) fclose(fd);
        sprintf(fname, "%s/%s.opc", REF_DST_DIR, nic);

        if (mode == 'w') fd = fopen(fname, "rb+");
        else             fd = fopen(fname, "rb");

        if (fd == NULL) return -1;
        strcpy(nic_sav, nic);
    }

/*-------------------------------------------------------------------
    type time_t (unix:4byte -> linux:8byte)���� length����(32 -> 48)
    ������ : choijy  2006/09/14   
    old :  code = fseek(fd, (long)(32*nic_num), SEEK_SET);
  -------------------------------------------------------------------*/
    code = fseek(fd, (long)(o1_len*nic_num), SEEK_SET);
    if (code != 0) return -2;

    if (mode == 'w')
    {
        n = fwrite(o1, 1, o1_len, fd);
        if (n <= 0) return -3;
        fflush(fd);
    }
    else
    {
        n = fread(o1, 1, o1_len, fd);
        if (n <= 0) return -3;
    }
    return 0;
}

/*===========================================================================*
 *  ��ȯ���ϵ� ����
 *===========================================================================*/
int com_bin_make(char *nic, int max)
{
    FILE   *fd;
    char   fname[120];
    struct COM_IPC  s1;
    struct COM_OPC  f1;
    struct COM_BIN  d1;
    struct COM_OUT  o1;
    struct stat  st;
    time_t tm;
    int    i, j;

    /*
    �Ϸù�ȣ ���� ���� (.IPC)
    */

    sprintf(fname, "%s/%s.ipc", REF_DST_DIR, nic);
    if (stat(fname,&st) == 0) return -1;

    fd = fopen(fname, "wb");
    if (fd == NULL) return -1;

    s1.max = max;
    s1.seq = -1;
    time(&tm);
    s1.tm = tm;
    s1.mode = 0;

    fwrite(&s1, 1, sizeof(s1), fd);
    fclose(fd);

    /*
    ��ȯ���� ���� (.BIN)
    */

    d1.tm    = 0;
    d1.cnt   = 0;
    d1.tm_fn = 0;
    d1.size  = 0;
    /*
    strcpy(d1.head, "");
    strcpy(d1.fname, "");
    */
    memset(d1.head, 0x00, sizeof(d1.head));
    memset(d1.fname, 0x00, sizeof(d1.fname));

    sprintf(fname, "%s/%s.bin", REF_DST_DIR, nic);
    if (stat(fname,&st) == 0) return -2;

    fd = fopen(fname, "wb");
    if (fd == NULL) return -2;

    for(i = 0; i < max; i++)
    {
        fwrite(&d1, 1, sizeof(d1), fd);
    }
    fclose(fd);

    /*
    ���� �Ϸù�ȣ ���� ���� (.OPC)
    */

    sprintf(fname, "%s/%s.opc", REF_DST_DIR, nic);
    if (stat(fname,&st) == 0) return -3;

    fd = fopen(fname, "wb");
    if (fd == NULL) return -3;

    f1.seq_out = -1;
    f1.tm_out  = 0;
    f1.cnt[0]  = 0;
    f1.cnt[1]  = 0;
    f1.seq1    = -1;
    f1.seq2    = -1;
    f1.tm_st   = 0;
    f1.mode    = 0;

    for(i = 0; i < 100; i++)
    {
        fwrite(&f1, 1, sizeof(f1), fd);
    }
    fclose(fd);

    /*
    ���۰������ ���� (.OUT)
    */

    o1.tm = 0;
    o1.tm_out = 0;

    sprintf(fname, "%s/%s.out", REF_DST_DIR, nic);
    if (stat(fname,&st) == 0) return -4;

    fd = fopen(fname, "wb");
    if (fd == NULL) return -4;

    for(i = 0; i < max; i++)
    {
        for(j = 0; j < 100; j++)
        {
            fwrite(&o1, 1, sizeof(o1), fd);
        }
    }
    fclose(fd);

    return 0;
}
