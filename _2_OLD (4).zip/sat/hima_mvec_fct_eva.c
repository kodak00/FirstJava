/*******************************************************************************
**
**  Ư�� ������ �����͸� �̵����ͷ� ������ ����� ���� ���� ��
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2019.7.10)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>

#include "cgiutil.h"
#include "nrutil.h"
#include "map_ini.h"
#include "url_io.h"
#include "sat_mvec.h"

#define  DEGRAD   0.01745329251994329576923690768489    // PI/180
#define  RADDEG   57.295779513082320876798154814105     // 180/PI

// �����͸� ���ڿ��� (2km ����ũ��)
#define  HIMA_NX   4599
#define  HIMA_NY   3999
#define  HIMA_SX   2299
#define  HIMA_SY   2717
#define  HIMA_GRID 2

// H5-map(���ƽþ�+) ����(km)
#define  H5_NX  5760
#define  H5_NY  5760
#define  H5_SX  3328
#define  H5_SY  3328

// �����ڷ��� ���� ����
struct GRID_MAP {
  int   nx, ny;   // �迭ũ�� [0:ny][0:nx]
  float sx, sy;   // ������ ��ġ(���ڰŸ�)
  float grid;     // ���ڰ���(km)
};

// rdr.kma.go.kr/cgi-bin/sat/nph-hima_mvec_fct_img?tm=201906271200&ef=60&map=H4&mvec=2&disp=2&tp1=-99&tp2=-30
/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main(int argc, char *argv[])
{
  char  tm[20], tmp[20], map[8];
  int   YY, MM, DD, HH, MI;
  int   seq, seq1, seq2, itv, chn, mvec;

  // 0. �μ� Ȯ��
  if (argc != 7) {
    printf("[Usage] %s {����Ͻú�} {����Ͻú�} {�ð�����(��)} {ä�ι�ȣ} {�����ڵ�} {�����}\n", argv[0]);
    return 0;
  }

  // 1. ����� ��û Ȯ��
  strcpy(tm, argv[1]);
  strncpy(tmp, &tm[0], 4);  tmp[4]='\0';  YY = atoi(tmp);
  strncpy(tmp, &tm[4], 2);  tmp[2]='\0';  MM = atoi(tmp);
  strncpy(tmp, &tm[6], 2);  tmp[2]='\0';  DD = atoi(tmp);
  strncpy(tmp, &tm[8], 2);  tmp[2]='\0';  HH = atoi(tmp);
  strncpy(tmp, &tm[10],2);  tmp[2]='\0';  MI = atoi(tmp);
  seq1 = time2seq(YY, MM, DD, HH, MI, 'm');
  //printf("%04d%02d%02d%02d%02d-", YY, MM, DD, HH, MI);

  strcpy(tm, argv[2]);
  strncpy(tmp, &tm[0], 4);  tmp[4]='\0';  YY = atoi(tmp);
  strncpy(tmp, &tm[4], 2);  tmp[2]='\0';  MM = atoi(tmp);
  strncpy(tmp, &tm[6], 2);  tmp[2]='\0';  DD = atoi(tmp);
  strncpy(tmp, &tm[8], 2);  tmp[2]='\0';  HH = atoi(tmp);
  strncpy(tmp, &tm[10],2);  tmp[2]='\0';  MI = atoi(tmp);
  seq2 = time2seq(YY, MM, DD, HH, MI, 'm');
  //printf("%04d%02d%02d%02d%02d", YY, MM, DD, HH, MI);

  itv = atoi(argv[3]);
  chn = atoi(argv[4]);
  strcpy(map, argv[5]);
  mvec = atoi(argv[6]);
  //printf(" : %2d %2d %s %2d\n", itv, chn, map, mvec);

  // �ð����� ó��
  hima_mvec_fct_eva(seq1, seq2, itv, chn, map, mvec);
  return 0;
}

/*******************************************************************************
 *
 *  ��
 *
 *******************************************************************************/
int hima_mvec_fct_eva(
  int  seq1,  // ���۽ð�(��)
  int  seq2,  // ����ð�(��)
  int  itv,   // �ð�����(��)
  int  chn,   // ü�ι�ȣ
  char *map,  // �����ڵ�
  int  mvec   // �����
)
{
  struct GRID_MAP gm0, gm2;
  float  **sat1, **sat2, **sat3, *s1, *s2, *s3;
  float  GX, GY, SX, SY;
  int    xo, yo;
  int    seq, ef;
  int    YY, MM, DD, HH, MI;
  int    code;
  int    i, j, k, i1, j1;

  // 1. ����ڷ��� ���ڿ��� ���� �� �迭 ����
  grid_map_inf(map, &GX, &GY, &SX, &SY);

  gm2.grid = HIMA_GRID;
  gm2.nx = (int)(GX/gm2.grid);  gm2.ny = (int)(GY/gm2.grid);
  gm2.sx = SX/gm2.grid;  gm2.sy = SY/gm2.grid;
  sat2 = matrix(0, gm2.ny, 0, gm2.nx);
  sat3 = matrix(0, gm2.ny, 0, gm2.nx);

  // 2. �����ڷ��� ���ڿ����� �迭 ����
  gm0.grid = HIMA_GRID;
  gm0.nx = HIMA_NX;  gm0.ny = HIMA_NY;
  gm0.sx = HIMA_SX;  gm0.sy = HIMA_SY;
  sat1 = matrix(0, gm0.ny, 0, gm0.nx);

  xo = (int)(gm0.sx - gm2.sx);
  yo = (int)(gm0.sy - gm2.sy);

  // 3. �ð���, �����ð���
  for (seq = seq1; seq <= seq2; seq += itv) {
    for (ef = 10; ef <= 6*60; ef +=10) {
      if (ef > 60 && ef%30 != 0) continue;
      seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
      //printf("%04d%02d%02d%02d%02d, %3d,=\n", YY, MM, DD, HH, MI, ef);

      // seq���� seq+ef�� ������ ���
      code = hima_mvec_fct_calc(seq, ef, chn, mvec, gm2, sat2);
      if (code < 0) continue;

      // seq+ef������ �����ڷ�
      if ((code = hima_get(seq+ef, chn, 0, sat1)) < 0) continue;

      for (j = 0; j <= gm2.ny; j++) {
      for (s1 = &sat1[j+yo][xo], s3 = sat3[j], i = 0; i <= gm2.nx; i++, s1++, s3++) {
        *s3 = *s1;
      }
      }
      Grid_sms121a(gm2.nx, gm2.ny, sat3);
      Grid_sms121a(gm2.nx, gm2.ny, sat2);

      // ��� ���
      sat_diff_stat(seq, ef, chn, map, mvec, gm2, sat2, sat3);
    }
    if (seq1 == seq2) break;
  }

  // 4. �迭����
  free_matrix(sat1, 0, gm0.ny, 0, gm0.nx);
  free_matrix(sat3, 0, gm2.ny, 0, gm2.nx);
  free_matrix(sat2, 0, gm2.ny, 0, gm2.nx);
  return 0;
}

/*=============================================================================*
 *  ���̿� ���� ���
 *=============================================================================*/
int sat_diff_stat(
  int    seq,     // ���ؽð�(��)
  int    ef,      // �����ð�(��)
  int    chn,     // ü�ι�ȣ
  char   *map,    // �����ڵ�
  int    mvec,    // �����
  struct GRID_MAP gm2,  // ���ڿ���
  float  **sat2,  // �����ڷ�
  float  **sat3   // �����ڷ�
)
{
  double mae = 0, g1_avg = 0, g2_avg = 0, g1_std = 0, g2_std = 0;
  double cov = 0, corr = 0, dnum = 0;
  float  *t1, *t2, csi, acc;
  float  *g1, *g2;
  float  tp1 = -90, tp2 = -30;
  int    H, F, M, C;
  int    xo, yo;
  int    YY, MM, DD, HH, MI;
  int    i, j, k, n, i1, j1;

  // ���� ����
  for (dnum = 0, j = 0; j <= gm2.ny; j++) {
  for (g1 = sat2[j], g2 = sat3[j], i = 0; i <= gm2.nx; i++, g1++, g2++) {
    if (*g1 > -900 && *g2 > -900) {
      mae += fabs(*g1 - *g2);
      dnum++;
    }
  }
  }
  mae /= dnum;

  // ������ ���
  for (dnum = 0, j = 0; j <= gm2.ny; j++) {
  for (g1 = sat2[j], g2 = sat3[j], i = 0; i <= gm2.nx; i++, g1++, g2++) {
    if (*g1 > -900 && *g2 > -900) {
      g1_avg += *g1;
      g2_avg += *g2;
      dnum++;
    }
  }
  }
  g1_avg /= dnum;
  g2_avg /= dnum;

  // ������
  for (dnum = 0, j = 0; j <= gm2.ny; j++) {
  for (g1 = sat2[j], g2 = sat3[j], i = 0; i <= gm2.nx; i++, g1++, g2++) {
    if (*g1 > -900 && *g2 > -900) {
      cov += (*g1 - g1_avg)*(*g2 - g2_avg);
      g1_std += (*g1 - g1_avg)*(*g1 - g1_avg);
      g2_std += (*g2 - g2_avg)*(*g2 - g2_avg);
      dnum++;
    }
  }
  }
  cov /= dnum;
  g1_std = sqrt(g1_std/dnum);
  g2_std = sqrt(g2_std/dnum);
  corr = cov/(g1_std*g2_std);

  // CSI
  H = F = M = C = 0;
  for (j = 0; j <= gm2.ny; j++) {
  for (g1 = sat2[j], g2 = sat3[j], i = 0; i <= gm2.nx; i++, g1++, g2++) {
    if (*g1 >= tp1 && *g1 <= tp2) {
      if (*g2 >= tp1 && *g2 <= tp2)
        H++;
      else
        F++;
    }
    else {
      if (*g2 >= tp1 && *g2 <= tp2)
        M++;
      else
        C++;
    }
  }
  }
  csi = 100.0*H/(float)(F+M+H);
  acc = 100.0*(H+C)/(float)(F+M+H+C);

  // ��� ���
  seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  printf("%04d%02d%02d%02d%02d,", YY, MM, DD, HH, MI);
  printf("%3d,%2d,%s,%2d,", ef, chn, map, mvec);
  printf("%5.3f, ", mae);   // ��������
  printf("%5.4f, ", corr);  // ������
  printf("%6.3f, ", acc);   // ACC
  printf("%6.3f, ", csi);   // CSI
  printf("%7.3f, %6.3f, ", g1_avg, g1_std);   // �������� ���, ǥ������
  printf("%7.3f, %6.3f,", g2_avg, g2_std);   // �������� ���, ǥ������
  printf("=\n");
  fflush(stdout);
  return 0;
}

/*=============================================================================*
 *  ����ð� ���
 *=============================================================================*/
int time_print(char *buf)
{
  int  YYg, MMg, DDg, HHg, MIg, SSg;
  get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);
  printf("#%04d%02d%02d%02d%02d%02d:%s\n", YYg, MMg, DDg, HHg, MIg, SSg, buf);
  return 0;
}

/*
hima_mvec_fct_eva 201811010000 201811052330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181101-05.csv &
hima_mvec_fct_eva 201811060000 201811102330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181106-10.csv &
hima_mvec_fct_eva 201811110000 201811152330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181111-15.csv &
hima_mvec_fct_eva 201811160000 201811202330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181116-20.csv &
hima_mvec_fct_eva 201811210000 201811252330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181121-25.csv &
hima_mvec_fct_eva 201811260000 201811302330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181126-30.csv &

hima_mvec_fct_eva 201812010000 201812052330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181201-05.csv &
hima_mvec_fct_eva 201812060000 201812102330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181206-10.csv &
hima_mvec_fct_eva 201812110000 201812152330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181211-15.csv &
hima_mvec_fct_eva 201812160000 201812202330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181216-20.csv &
hima_mvec_fct_eva 201812210000 201812252330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181221-25.csv &
hima_mvec_fct_eva 201812260000 201812312330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181226-31.csv &

hima_mvec_fct_eva 201904010000 201904052330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190401-05.csv &
hima_mvec_fct_eva 201904060000 201904102330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190406-10.csv &
hima_mvec_fct_eva 201904110000 201904152330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190411-15.csv &
hima_mvec_fct_eva 201904160000 201904202330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190416-20.csv &
hima_mvec_fct_eva 201904210000 201904252330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190421-25.csv &
hima_mvec_fct_eva 201904260000 201904302330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190426-30.csv &

hima_mvec_fct_eva 201906010000 201906012330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190601.csv &
hima_mvec_fct_eva 201906020000 201906022330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190602.csv &
hima_mvec_fct_eva 201906030000 201906032330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190603.csv &
hima_mvec_fct_eva 201906040000 201906042330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190604.csv &
hima_mvec_fct_eva 201906050000 201906052330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190605.csv &
hima_mvec_fct_eva 201906060000 201906062330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190606.csv &
hima_mvec_fct_eva 201906070000 201906072330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190607.csv &
hima_mvec_fct_eva 201906080000 201906082330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190608.csv &
hima_mvec_fct_eva 201906090000 201906092330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190609.csv &
hima_mvec_fct_eva 201906100000 201906102330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190610.csv &
hima_mvec_fct_eva 201906110000 201906112330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190611.csv &
hima_mvec_fct_eva 201906120000 201906122330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190612.csv &
hima_mvec_fct_eva 201906130000 201906132330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190613.csv &
hima_mvec_fct_eva 201906140000 201906142330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190614.csv &
hima_mvec_fct_eva 201906150000 201906152330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190615.csv &
hima_mvec_fct_eva 201906160000 201906162330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190616.csv &
hima_mvec_fct_eva 201906170000 201906172330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190617.csv &
hima_mvec_fct_eva 201906180000 201906182330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190618.csv &
hima_mvec_fct_eva 201906190000 201906192330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190619.csv &
hima_mvec_fct_eva 201906200000 201906202330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190620.csv &
hima_mvec_fct_eva 201906210000 201906212330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190621.csv &
hima_mvec_fct_eva 201906220000 201906222330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190622.csv &
hima_mvec_fct_eva 201906230000 201906232330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190623.csv &
hima_mvec_fct_eva 201906240000 201906242330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190624.csv &
hima_mvec_fct_eva 201906250000 201906252330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190625.csv &
hima_mvec_fct_eva 201906260000 201906262330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190626.csv &
hima_mvec_fct_eva 201906270000 201906272330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190627.csv &
hima_mvec_fct_eva 201906280000 201906282330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190628.csv &
hima_mvec_fct_eva 201906290000 201906292330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190629.csv &
hima_mvec_fct_eva 201906300000 201906302330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190630.csv &
hima_mvec_fct_eva 201906310000 201906312330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190631.csv &
HR : �Ϸ�(18��7-8��,19��5-6��)
H4 : �Ϸ�(18��7-8��,19��5-6��) ������(18��9-12��,19��1-4��)

hima_mvec_fct_eva 201810010000 201810052330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181001-05.csv &
hima_mvec_fct_eva 201901261500 201901312330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190126-31.csv &
hima_mvec_fct_eva 201901211830 201901252330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190121-25.csv &
hima_mvec_fct_eva 201902161700 201902202330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190216-20.csv &
hima_mvec_fct_eva 201902061800 201902102330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190206-10.csv &
hima_mvec_fct_eva 201901070030 201901102330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190106-10.csv &
hima_mvec_fct_eva 201901162130 201901202330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190116-20.csv &
hima_mvec_fct_eva 201902120600 201902152330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190211-15.csv &
hima_mvec_fct_eva 201809270800 201809302330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20180926-30.csv &
hima_mvec_fct_eva 201901021800 201901052330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20190101-05.csv &
hima_mvec_fct_eva 201811070900 201811102330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181106-10.csv &
hima_mvec_fct_eva 201810171130 201810202330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181016-20.csv &
hima_mvec_fct_eva 201811222330 201811252330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181121-25.csv &
hima_mvec_fct_eva 201810271430 201810202330 30 9 H4 21 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_eva_H4_ch09_21_20181016-20.csv &

*/