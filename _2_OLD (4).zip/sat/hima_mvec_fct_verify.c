/*******************************************************************************
**
**  �����͸� �̵����Ϳ� ���� �������� ���� ���� �ִ�ġ �м�
**  - �̹� ���� 10�а����� �̵����ͷ� �̵��������� ��������� �ִ�ġ�� ����.
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2019.7.9)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>

#include "cgiutil.h"
#include "nrutil.h"
#include "map_ini.h"
#include "url_io.h"
#include "sat_mvec.h"

#define  DEGRAD   0.01745329251994329576923690768489    // PI/180
#define  RADDEG   57.295779513082320876798154814105     // 180/PI

// �����͸� ���ڿ��� (2km ����ũ��)
#define  HIMA_NX   4599
#define  HIMA_NY   3999
#define  HIMA_SX   2299
#define  HIMA_SY   2717
#define  HIMA_GRID 2

// H5-map(���ƽþ�+) ����(km)
#define  H5_NX  5760
#define  H5_NY  5760
#define  H5_SX  3328
#define  H5_SY  3328

// �����ڷ��� ���� ����
struct GRID_MAP {
  int   nx, ny;   // �迭ũ�� [0:ny][0:nx]
  float sx, sy;   // ������ ��ġ(���ڰŸ�)
  float grid;     // ���ڰ���(km)
};

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main(int argc, char *argv[])
{
  char  tm[20], tmp[20], map[8];
  int   YY, MM, DD, HH, MI;
  int   seq, seq1, seq2, itv, chn, mvec;

  // 0. �μ� Ȯ��
  if (argc != 7) {
    printf("[Usage] %s {����Ͻú�} {����Ͻú�} {�ð�����(��)} {ä�ι�ȣ} {�����ڵ�} {�����}\n", argv[0]);
    return 0;
  }

  // 1. ����� ��û Ȯ��
  strcpy(tm, argv[1]);
  strncpy(tmp, &tm[0], 4);  tmp[4]='\0';  YY = atoi(tmp);
  strncpy(tmp, &tm[4], 2);  tmp[2]='\0';  MM = atoi(tmp);
  strncpy(tmp, &tm[6], 2);  tmp[2]='\0';  DD = atoi(tmp);
  strncpy(tmp, &tm[8], 2);  tmp[2]='\0';  HH = atoi(tmp);
  strncpy(tmp, &tm[10],2);  tmp[2]='\0';  MI = atoi(tmp);
  seq1 = time2seq(YY, MM, DD, HH, MI, 'm');
  //printf("%04d%02d%02d%02d%02d-", YY, MM, DD, HH, MI);

  strcpy(tm, argv[2]);
  strncpy(tmp, &tm[0], 4);  tmp[4]='\0';  YY = atoi(tmp);
  strncpy(tmp, &tm[4], 2);  tmp[2]='\0';  MM = atoi(tmp);
  strncpy(tmp, &tm[6], 2);  tmp[2]='\0';  DD = atoi(tmp);
  strncpy(tmp, &tm[8], 2);  tmp[2]='\0';  HH = atoi(tmp);
  strncpy(tmp, &tm[10],2);  tmp[2]='\0';  MI = atoi(tmp);
  seq2 = time2seq(YY, MM, DD, HH, MI, 'm');
  //printf("%04d%02d%02d%02d%02d", YY, MM, DD, HH, MI);

  itv = atoi(argv[3]);
  chn = atoi(argv[4]);
  strcpy(map, argv[5]);
  mvec = atoi(argv[6]);
  //printf(" : %2d %2d %s %2d\n", itv, chn, map, mvec);

  // �ð����� ó��
  hima_mvec_fct_verify(seq1, seq2, itv, chn, map, mvec);
  return 0;
}

/*******************************************************************************
 *
 *  ��
 *
 *******************************************************************************/
int hima_mvec_fct_verify(
  int  seq1,  // ���۽ð�(��)
  int  seq2,  // ����ð�(��)
  int  itv,   // �ð�����(��)
  int  chn,   // ü�ι�ȣ
  char *map,  // �����ڵ�
  int  mvec   // �����
)
{
  struct GRID_MAP gm0, gm2;
  float  **sat1, **sat2, **sat3, *s1, *s2, *s3;
  float  GX, GY, SX, SY;
  int    xo, yo;
  int    seq, ef;
  int    YY, MM, DD, HH, MI;
  int    code;
  int    i, j, k, i1, j1;

  // 1. ����ڷ��� ���ڿ��� ���� �� �迭 ����
  grid_map_inf(map, &GX, &GY, &SX, &SY);

  gm2.grid = HIMA_GRID;
  gm2.nx = (int)(GX/gm2.grid);  gm2.ny = (int)(GY/gm2.grid);
  gm2.sx = SX/gm2.grid;  gm2.sy = SY/gm2.grid;
  sat2 = matrix(0, gm2.ny, 0, gm2.nx);
  sat3 = matrix(0, gm2.ny, 0, gm2.nx);

  // 2. �����ڷ��� ���ڿ����� �迭 ����
  gm0.grid = HIMA_GRID;
  gm0.nx = HIMA_NX;  gm0.ny = HIMA_NY;
  gm0.sx = HIMA_SX;  gm0.sy = HIMA_SY;
  sat1 = matrix(0, gm0.ny, 0, gm0.nx);

  xo = (int)(gm0.sx - gm2.sx);
  yo = (int)(gm0.sy - gm2.sy);

  // 3. �ð���, �����ð���
  for (seq = seq1; seq <= seq2; seq += itv) {
    for (ef = 10; ef <= 6*60; ef +=10) {
      if (ef > 60 && ef%30 != 0) continue;
      seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
      //printf("%04d%02d%02d%02d%02d, %3d,=\n", YY, MM, DD, HH, MI, ef);

      // seq-ef���� seq�� ������ ���
      code = hima_mvec_back_calc(seq, ef, chn, mvec, gm2, sat2);
      if (code < 0) continue;

      // seq������ �����ڷ�
      if ((code = hima_get(seq, chn, 0, sat1)) < 0) continue;

      for (j = 0; j <= gm2.ny; j++) {
      for (s1 = &sat1[j+yo][xo], s3 = sat3[j], i = 0; i <= gm2.nx; i++, s1++, s3++) {
        *s3 = *s1;
      }
      }
      Grid_sms121a(gm2.nx, gm2.ny, sat3);
      Grid_sms121a(gm2.nx, gm2.ny, sat2);

      // ��� ���
      sat_diff_stat(seq, ef, chn, map, mvec, gm2, sat2, sat3);
    }
    if (seq1 == seq2) break;
  }

  // 4. �迭����
  free_matrix(sat1, 0, gm0.ny, 0, gm0.nx);
  free_matrix(sat3, 0, gm2.ny, 0, gm2.nx);
  free_matrix(sat2, 0, gm2.ny, 0, gm2.nx);
  return 0;
}

/*=============================================================================*
 *  ���̿� ���� ���
 *=============================================================================*/
int sat_diff_stat(
  int    seq,     // ���ؽð�(��)
  int    ef,      // �����ð�(��)
  int    chn,     // ü�ι�ȣ
  char   *map,    // �����ڵ�
  int    mvec,    // �����
  struct GRID_MAP gm2,  // ���ڿ���
  float  **sat2,  // �����ڷ�
  float  **sat3   // �����ڷ�
)
{
  double mae = 0, g1_avg = 0, g2_avg = 0, g1_std = 0, g2_std = 0;
  double cov = 0, corr = 0, dnum = 0;
  float  *t1, *t2, csi, acc;
  float  *g1, *g2;
  float  tp1 = -90, tp2 = -30;
  int    H, F, M, C;
  int    xo, yo;
  int    YY, MM, DD, HH, MI;
  int    i, j, k, n, i1, j1;

  // ���� ����
  for (dnum = 0, j = 0; j <= gm2.ny; j++) {
  for (g1 = sat2[j], g2 = sat3[j], i = 0; i <= gm2.nx; i++, g1++, g2++) {
    if (*g1 > -900 && *g2 > -900) {
      mae += fabs(*g1 - *g2);
      dnum++;
    }
  }
  }
  mae /= dnum;

  // ������ ���
  for (dnum = 0, j = 0; j <= gm2.ny; j++) {
  for (g1 = sat2[j], g2 = sat3[j], i = 0; i <= gm2.nx; i++, g1++, g2++) {
    if (*g1 > -900 && *g2 > -900) {
      g1_avg += *g1;
      g2_avg += *g2;
      dnum++;
    }
  }
  }
  g1_avg /= dnum;
  g2_avg /= dnum;

  // ������
  for (dnum = 0, j = 0; j <= gm2.ny; j++) {
  for (g1 = sat2[j], g2 = sat3[j], i = 0; i <= gm2.nx; i++, g1++, g2++) {
    if (*g1 > -900 && *g2 > -900) {
      cov += (*g1 - g1_avg)*(*g2 - g2_avg);
      g1_std += (*g1 - g1_avg)*(*g1 - g1_avg);
      g2_std += (*g2 - g2_avg)*(*g2 - g2_avg);
      dnum++;
    }
  }
  }
  cov /= dnum;
  g1_std = sqrt(g1_std/dnum);
  g2_std = sqrt(g2_std/dnum);
  corr = cov/(g1_std*g2_std);

  // CSI
  H = F = M = C = 0;
  for (j = 0; j <= gm2.ny; j++) {
  for (g1 = sat2[j], g2 = sat3[j], i = 0; i <= gm2.nx; i++, g1++, g2++) {
    if (*g1 >= tp1 && *g1 <= tp2) {
      if (*g2 >= tp1 && *g2 <= tp2)
        H++;
      else
        F++;
    }
    else {
      if (*g2 >= tp1 && *g2 <= tp2)
        M++;
      else
        C++;
    }
  }
  }
  csi = 100.0*H/(float)(F+M+H);
  acc = 100.0*(H+C)/(float)(F+M+H+C);

  // ��� ���
  seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  printf("%04d%02d%02d%02d%02d,", YY, MM, DD, HH, MI);
  printf("%3d,%2d,%s,%2d,", ef, chn, map, mvec);
  printf("%5.3f, ", mae);   // ��������
  printf("%5.4f, ", corr);  // ������
  printf("%6.3f, ", acc);   // ACC
  printf("%6.3f, ", csi);   // CSI
  printf("%7.3f, %6.3f, ", g1_avg, g1_std);   // �������� ���, ǥ������
  printf("%7.3f, %6.3f,", g2_avg, g2_std);   // �������� ���, ǥ������
  printf("=\n");
  fflush(stdout);
  return 0;
}

/*=============================================================================*
 *  ����ð� ���
 *=============================================================================*/
int time_print(char *buf)
{
  int  YYg, MMg, DDg, HHg, MIg, SSg;
  get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);
  printf("#%04d%02d%02d%02d%02d%02d:%s\n", YYg, MMg, DDg, HHg, MIg, SSg, buf);
  return 0;
}

/*
hima_mvec_fct_verify 201808010000 201808012330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180801.csv &
hima_mvec_fct_verify 201808020000 201808022330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180802.csv &
hima_mvec_fct_verify 201808030000 201808032330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180803.csv &
hima_mvec_fct_verify 201808040000 201808042330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180804.csv &
hima_mvec_fct_verify 201808050000 201808052330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180805.csv &
hima_mvec_fct_verify 201808060000 201808062330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180806.csv &
hima_mvec_fct_verify 201808070000 201808072330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180807.csv &
hima_mvec_fct_verify 201808080000 201808082330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180808.csv &
hima_mvec_fct_verify 201808090000 201808092330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180809.csv &
hima_mvec_fct_verify 201808100000 201808102330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180810.csv &
hima_mvec_fct_verify 201808110000 201808112330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180811.csv &
hima_mvec_fct_verify 201808120000 201808122330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180812.csv &
hima_mvec_fct_verify 201808130000 201808132330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180813.csv &
hima_mvec_fct_verify 201808140000 201808142330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180814.csv &
hima_mvec_fct_verify 201808150000 201808152330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180815.csv &
hima_mvec_fct_verify 201808160000 201808162330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180816.csv &
hima_mvec_fct_verify 201808170000 201808172330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180817.csv &
hima_mvec_fct_verify 201808180000 201808182330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180818.csv &
hima_mvec_fct_verify 201808190000 201808192330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180819.csv &
hima_mvec_fct_verify 201808200000 201808202330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180820.csv &
hima_mvec_fct_verify 201808210000 201808212330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180821.csv &
hima_mvec_fct_verify 201808220000 201808222330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180822.csv &
hima_mvec_fct_verify 201808230000 201808232330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180823.csv &
hima_mvec_fct_verify 201808240000 201808242330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180824.csv &
hima_mvec_fct_verify 201808250000 201808252330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180825.csv &
hima_mvec_fct_verify 201808260000 201808262330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180826.csv &
hima_mvec_fct_verify 201808270000 201808272330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180827.csv &
hima_mvec_fct_verify 201808280000 201808282330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180828.csv &
hima_mvec_fct_verify 201808290000 201808292330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180829.csv &
hima_mvec_fct_verify 201808300000 201808302330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180830.csv &
hima_mvec_fct_verify 201808310000 201808312330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180831.csv &

HR : �Ϸ�(18��7-8��,19��5-6��)
H4 : ������(19��5-6��)

hima_mvec_fct_verify 201807030530 201807032330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180703.csv &
hima_mvec_fct_verify 201807040400 201807042330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180704.csv &
hima_mvec_fct_verify 201807061000 201807062330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180706.csv &
hima_mvec_fct_verify 201807071100 201807072330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180707.csv &
hima_mvec_fct_verify 201807090430 201807092330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180709.csv &
hima_mvec_fct_verify 201807100430 201807102330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180710.csv &
hima_mvec_fct_verify 201807112130 201807122330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180711.csv &
hima_mvec_fct_verify 201807120400 201807122330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180712.csv &
hima_mvec_fct_verify 201807150800 201807152330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180715.csv &
hima_mvec_fct_verify 201807200730 201807202330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180720.csv &
hima_mvec_fct_verify 201807260600 201807262330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180726.csv &
hima_mvec_fct_verify 201807310500 201807312330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180731.csv &
hima_mvec_fct_verify 201808030430 201808032330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180803.csv &
hima_mvec_fct_verify 201808081030 201808082330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180808.csv &
hima_mvec_fct_verify 201808090530 201808092330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180809.csv &
hima_mvec_fct_verify 201808100400 201808102330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180810.csv &

hima_mvec_fct_verify 201808111400 201808112330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180811.csv &
hima_mvec_fct_verify 201808141400 201808142330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180814.csv &
hima_mvec_fct_verify 201807181400 201807182330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180718.csv &
hima_mvec_fct_verify 201808121730 201808122330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180812.csv &
hima_mvec_fct_verify 201808151530 201808152330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180815.csv &
hima_mvec_fct_verify 201807231600 201807232330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180723.csv &
hima_mvec_fct_verify 201807302130 201807302330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180730.csv &
hima_mvec_fct_verify 201807211900 201807212330 30 9 H4 11 >> /rdr/STADB/MVEC/VERIFY/hima_mvec_fct_verify_H4_ch09_11_20180721.csv &

*/