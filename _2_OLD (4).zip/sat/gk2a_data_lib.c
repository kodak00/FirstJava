/*******************************************************************************
 *  ���ǽð�, Ư�� ���, Ư�������� õ����2 �ڷḦ �������� ��ƾ
 *******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include <netcdf.h>
#include <hdf5.h>
#include "cgiutil.h"
#include "nrutil.h"
#include "map_ini.h"
#include "url_io.h"

#define  GK2A_L1B_DIR   "/GK2A/AMI/PRIMARY/L1B/COMPLETE"
#define  GK2A_CONV_DIR  "/rdr/REF/GK2A"

// �����ڷ��� ���� ����
struct GRID_MAP {
  int   nx, ny;   // �迭ũ�� [0:ny][0:nx]
  float sx, sy;   // ������ ��ġ(���ڰŸ�)
  float grid;     // ���ڰ���(km)
};

/*******************************************************************************
 *  õ����2 �ڷ� ��������
 *******************************************************************************/
int gk2a_get(
  int  seq,     // �ð�(KST)
  char *band,   // ä��&����
  char *scn,    // �ڷ῵��
  struct GRID_MAP gm2,  // ������ڿ���
  float **g,     // ���: ���ڰ�
  float missing  // �ڷ������
)
{
  FILE    *fp1;
  int     ncid;                       /* NetCDF ID */
  int     ndims;                      /* number of dimensions */
  int     nvars;                      /* number of variables */
  int     ngatts;                     /* number of global attributes */
  int     unlimdimid;                 /* unlimited dimension ID */
  char    dim_name[NC_MAX_NAME+1];    /* dimension name */
  size_t  recs, x_recs, y_recs, h_recs, rec1;   /* number of records */
  int     status;                     /* error status */
  int     var_id;                     /* variable ID */
  char    var_name[NC_MAX_NAME+1];    /* variable name */
  nc_type var_type;                   /* variable type */
  int     var_ndims;                  /* number of dims */
  int     var_dims[NC_MAX_VAR_DIMS];  /* variables shape */
  int     var_natts;                  /* number of attributes */
  int     att_id;                     /* attribute ID */
  char    att_name[NC_MAX_NAME+1];    /* attribute name */
  nc_type att_type;                   /* attribute type */
  size_t  att_len;                    /* attribute length */
  char    *cp;                        /* char pointer */
  short   *sp;                        /* short pointer */
  int     *ip;                        /* int pointer */
  float   *p2;                        /* float pointer */
  double  *dp;                        /* double pointer */
  short  *p1;
  char   fname[120];
  double sx, sy;
  struct GRID_MAP gm1;
  float  rate, xo, yo;
  float  cnv[20000];
  int    num_cnv;
  int    x1, y1, nskip, v1;
  int    code, i, j, k, n, i1, j1;

  // 1. ���� ���翩�� Ȯ��
  if (gk2a_file(seq, band, scn, fname) < 0) return -10;
  //printf("%s\n", fname);

  // 2. nc���� ����
  status = nc_open(fname, 0, &ncid);
  if (status != NC_NOERR) return -11;

  // 3. �ڷ� ���� �б�
  strcpy(var_name, "image_pixel_values");
  status = nc_inq_varid(ncid, var_name, &var_id);
  status = nc_inq_varndims(ncid, var_id, &ndims);
  status = nc_inq_vardimid(ncid, var_id, var_dims);

  for (recs = 1, i = 0; i < ndims; i++) {
    status = nc_inq_dim(ncid, var_dims[i], dim_name, &rec1);
    recs *= rec1;

    if (i == 0)
      gm1.ny = rec1 - 1;
    else if (i == 1)
      gm1.nx = rec1 - 1;
  }
  if (!strcmp(band,"vi006")) gm1.grid = 0.5;       // 500m
  else if (!strncmp(band,"vi",2)) gm1.grid = 1.0;  // 1km
  else gm1.grid = 2.0;   // 2km

  //status = nc_inq_att(ncid, NC_GLOBAL, "upper_left_easting", &att_type, &att_len);
  //if (att_type == NC_FLOAT) printf("---1---\n");
  //if (att_type == NC_DOUBLE) printf("---2---\n");
  status = nc_get_att_double(ncid, NC_GLOBAL, "upper_left_easting", &sx);
  status = nc_get_att_double(ncid, NC_GLOBAL, "lower_left_northing", &sy);

  gm1.sx = -(sx*0.001)/gm1.grid;    // m -> km
  gm1.sy = -(sy*0.001)/gm1.grid;
  //printf("%f %f %f %f\n", sx, sy, gm1.sx, gm1.sy);

  // 4. ���������ڷ� �а�, ���� ����
  p1 = (short *) malloc(recs * sizeof(short));
  status = nc_get_var_short(ncid, var_id, p1);
  if (status != NC_NOERR) {
    status = nc_close(ncid);
    return -12;
  }
  status = nc_close(ncid);

  // 5. ��ȯ���̺� ����
  num_cnv = gk2a_conv_table(band, cnv);

  // 6. �ʱ�ȭ
  for (j = 0; j <= gm2.ny; j++) {
  for (i = 0; i <= gm2.nx; i++) {
    g[j][i] = missing;
  }
  }

  // 7. gm1���� �ڷ� -> gm2���� �ڷ�
  // 7.1. ���ڰ����� ���� ���
  if (fabs(gm1.grid - gm2.grid) < 0.0001) {
    for (j = 0; j <= gm2.ny; j++) {
      j1 = (int)(j + gm1.sy - gm2.sy + 0.5);
      if (j1 < 0 || j1 > gm1.ny) continue;

      for (i = 0; i <= gm2.nx; i++) {
        i1 = (int)(i + gm1.sx - gm2.sx + 0.5);
        if (i1 < 0 || i1 > gm1.nx) continue;

        k = (gm1.nx+1)*(gm1.ny-j1) + i1;
        n = p1[k]&0x3fff;
        if (n >= 0 && n < num_cnv) g[j][i] = cnv[n];
      }
    }
  }
  // 7.2. ���ڰ����� �ٸ� ���
  else {
    rate = gm2.grid/gm1.grid;
    yo = gm1.sy - gm2.sy*rate;
    xo = gm1.sx - gm2.sx*rate;

    for (j = 0; j <= gm2.ny; j++) {
      j1 = (int)(j*rate + yo + 0.5);
      if (j1 < 0 || j1 > gm1.ny) continue;

      for (i = 0; i <= gm2.nx; i++) {
        i1 = (int)(i*rate + xo + 0.5);
        if (i1 < 0 || i1 > gm1.nx) continue;

        k = (gm1.nx+1)*(gm1.ny-j1) + i1;
        n = p1[k]&0x3fff;
        if (n >= 0 && n < num_cnv) g[j][i] = cnv[n];
      }
    }
  }

  // 8. �迭 ����
  free((char*) (p1));
  return 0;
}

/*=============================================================================*
 *  õ����2 �����ڷ� ��ȯǥ �б�
 *=============================================================================*/
int gk2a_conv_table(
  char *band,   // ä��&����
  float cnv[]   // ��ȯ���̺�
)
{
  FILE  *fp;
  char  fname[120];
  int   i, j, k, n;

  // 1. ��ȯ���̺� ���� ����
  if (strstr(band,"VI") || strstr(band,"NR"))
    sprintf(fname, "%s/%s_con_alb.txt", GK2A_CONV_DIR, band);
  else
    sprintf(fname, "%s/%s_con_bt.txt", GK2A_CONV_DIR, band);
  if ((fp = fopen(fname,"r")) == NULL) return -1;

  n = 0;
  while (fscanf(fp, "%f", &cnv[n]) != EOF) {
    n++;
  }
  fclose(fp);

  // 2. ���ð� �ƴ� ���� �����µ��� ��ȯ
  if (!strstr(band,"VI") && !strstr(band,"NR")) {
    for (i = 0; i < n; i++) {
      if (cnv[i] > 0) cnv[i] -= 273.15;
    }
  }
  return n;
}

/*=============================================================================*
 *  õ����2 �����ڷ� ���� ���� Ȯ�� (���ϸ��� UTC)
 *=============================================================================*/
int gk2a_file(
  int   seq,    // �ð�(KST)
  char *band,   // ä��&����
  char *scn,    // �ڷ῵��
  char *fname
)
{
  struct stat st;
  char   dir_code[8], dir1[60];
  int    grid;
  int    YY, MM, DD, HH, MI;
  int    code;

  // 1. �ð�(KST->UTC)
  seq2time(seq-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  // 2. BAND�� ����ũ��
  if (!strcmp(band,"vi006")) grid = 5;        // 500m
  else if (!strncmp(band,"vi",2)) grid = 10;  // 1km
  else grid = 20;   // 2km

  // 3. ���丮
  if      (!strcmp(scn,"ea"))  strcpy(dir_code,"EA");   // ���ƽþ�
  else if (!strcmp(scn,"ela")) strcpy(dir_code,"ELA");  // Ȯ�� ����
  else if (!strcmp(scn,"enh")) strcpy(dir_code,"ENH");  // Ȯ�� �Ϲݱ�
  else if (!strcmp(scn,"fd"))  strcpy(dir_code,"FD");   // ����
  else if (!strcmp(scn,"ko"))  strcpy(dir_code,"KO");   // �ѹݵ�
  else if (!strcmp(scn,"la"))  strcpy(dir_code,"LA");   // ����
  else if (!strcmp(scn,"nko")) strcpy(dir_code,"NKO");  // ����
  else if (!strcmp(scn,"sko")) strcpy(dir_code,"SKO");  // ����
  else if (!strcmp(scn,"tp"))  strcpy(dir_code,"TP");   // ��ǳ
  sprintf(dir1, "%s/%s/%04d%02d/%02d/%02d", GK2A_L1B_DIR, dir_code, YY, MM, DD, HH);

  // 4. ���ϸ�
  sprintf(fname, "%s/gk2a_ami_le1b_%s_%s%03dlc_%04d%02d%02d%02d%02d.nc",
          dir1, band, scn, grid, YY, MM, DD, HH, MI);
  code = stat(fname, &st);
  //printf("%s (%d)\n", fname, code);

  // 5. ���翩��
  if (code < 0 || st.st_size <= 100) return -1;
  return 0;
}

/*=============================================================================*
 *  ä�� ���� -> ���&����
 *=============================================================================*/
int gk2a_chn2band(
  int  chn,     // ä�μ���
  char *band    // õ����2 ����
)
{
  switch (chn) {
    case 1:  strcpy(band,"vi004");  break;
    case 2:  strcpy(band,"vi005");  break;
    case 3:  strcpy(band,"vi006");  break;
    case 4:  strcpy(band,"vi008");  break;
    case 5:  strcpy(band,"nr013");  break;
    case 6:  strcpy(band,"nr016");  break;
    case 7:  strcpy(band,"sw038");  break;
    case 8:  strcpy(band,"wv063");  break;
    case 9:  strcpy(band,"wv069");  break;
    case 10:  strcpy(band,"wv073");  break;
    case 11:  strcpy(band,"ir087");  break;
    case 12:  strcpy(band,"ir096");  break;
    case 13:  strcpy(band,"ir105");  break;
    case 14:  strcpy(band,"ir112");  break;
    case 15:  strcpy(band,"ir123");  break;
    case 16:  strcpy(band,"ir133");  break;
  }
  return 0;
}
