/*******************************************************************************
**
**  �����͸� �̵����� ǥ��
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2019.6.10)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include <gd.h>
#include <gdfontt.h>
#include <gdfonts.h>
#include <gdfontmb.h>
#include <gdfontl.h>
#include <gdfontg.h>

#include "cgiutil.h"
#include "nrutil.h"
#include "map_ini.h"
#include "url_io.h"
#include "sat_mvec.h"

#define  DEGRAD   0.01745329251994329576923690768489    // PI/180
#define  RADDEG   57.295779513082320876798154814105     // 180/PI

#define  HIMA_BIN_DIR   "/DATA/SAT/HIMA/BIN"
#define  HIMA_MVEC_DIR  "/rdr/STADB/MVEC"
#define  HIMA_CONV_FILE "/rdr/REF/INI/hima_conv.csv"
#define  MAP_INI_FILE   "/rdr/REF/MAP/map.ini"

// �����͸� ���ڿ��� (2km ����ũ��)
#define  HIMA_NX   4599
#define  HIMA_NY   3999
//#define  HIMA_SX   2299.5
//#define  HIMA_SY   2717.5
#define  HIMA_SX   2299
#define  HIMA_SY   2717
#define  HIMA_GRID 2

// H5-map(���ƽþ�+) ����(km)
#define  H5_NX  5760
#define  H5_NY  5760
#define  H5_SX  3328
#define  H5_SY  3328

// ��� �� �ڷ��
struct SAT_MVEC_HEAD  sat_mvec_head;
float  **uu, **vv;
char log_str[200];

/*******************************************************************************
 *
 *  main
 *
 *******************************************************************************/
/*
int main()
{
  float  **sat;
  int  seq, dt = 10, chn1 = 9, chn2 = 0;
  int  nx, ny;
  int  code;
  int  i, j, k;

  seq = time2seq(2019, 6, 18, 12, 30, 'm');
  nx = (int)(H5_NX/HIMA_GRID);
  ny = (int)(H5_NY/HIMA_GRID);
  sat = matrix(0, ny, 0, nx);

  code = hima_mvec_move(seq, dt, chn1, chn2, sat);
  sprintf(log_str, "hima_mvec_move: %d", code);  time_print(log_str);


  for (j = 0; j <= ny; j++) {
  for (i = 0; i <= nx; i++) {
    if (i == nx/2) {
      printf("(%3d,%3d), %6.2f\n", i, j, sat[j][i]);
    }
  }
  }
  return 0;
}
*/

/*******************************************************************************
 *
 *  H5������ ���Ͽ� �̵��� ���
 *
 *******************************************************************************/
int hima_mvec_move(
  int  seq,
  int  dt,
  int  chn1,
  int  chn2,
  int  mvec,
  float **sat2
)
{
  gzFile fg;
  char   fname[120];
  short  com1[HIMA_NX+1];
  float  cnv1[18000];
  float  **sat1, **u, **v, **up, **vp;
  int    nx, ny, sx, sy, c1;
  int    i, j, k, i1, j1;

  // 1. HIMA ������ �����ڷ� �б�
  // 1.1. ������ �ִ��� Ȯ���ϰ� ����µ� ��ȯǥ �б�
  if (hima_file1(seq-dt, chn1, fname) < 0) return -1;
  if (hima_conv_read1(chn1, cnv1) < 0) return -2;

  // 1.2. �ڷ� �а�, ����µ������� ��ȯ
  if ((fg = gzopen(fname, "rb")) != NULL) {
    sat1 = matrix(0, HIMA_NY, 0, HIMA_NX);
    gzbuffer(fg, 64*1024);
    for (j = 0; j <= HIMA_NY; j++) {
      j1 = HIMA_NY - j;
      gzread(fg, com1, 2*(HIMA_NX+1));
      for (i = 0; i <= HIMA_NX; i++) {
        c1 = com1[i];
        if (c1 >= 0 && c1 < 18000)
          sat1[j1][i] = cnv1[c1];
        else
          sat1[j1][i] = -999;
      }
    }
    gzclose(fg);
  }
  else 
    return -3;
  sprintf(log_str, "fname = %s", fname);  time_print(log_str);

  // 2. H5������ �� �̵����� ����
  nx = (int)(H5_NX/HIMA_GRID);   ny = (int)(H5_NY/HIMA_GRID);
  sx = (int)(H5_SX/HIMA_GRID);   sy = (int)(H5_SY/HIMA_GRID);
  u = matrix(0, ny, 0, nx);   v = matrix(0, ny, 0, nx);
  up = matrix(0, ny, 0, nx);  vp = matrix(0, ny, 0, nx);
  for (j = 0; j <= ny; j++) {
  for (i = 0; i <= nx; i++) {
    up[j][i] = 0;
    vp[j][i] = 0;
  }
  }

  // �ش� �Ⱓ������ ��� �̵����ͷ� �̵�
  if (mvec == 2) {
    if (hima_mvec_ext(seq, dt, chn1, chn2, nx, ny, u, v) < 0) return -4;
    for (k = 0; k < dt; k += 10) {
      for (j = 0; j <= ny; j++) {
      for (i = 0; i <= nx; i++) {
        i1 = (int)(i + up[j][i] + 0.49);
        j1 = (int)(j + vp[j][i] + 0.49);
        if (i1 < 0 || i1 > nx || j1 < 0 || j1 > ny) {
          up[j][i] = vp[j][i] = -999;
        }
        else {
          up[j][i] -= u[j1][i1];
          vp[j][i] -= v[j1][i1];
        }
      }
      }
    }
  }
  // �ش� �Ⱓ����, 10�� ������ �̵����ͷ� �̵�
  else {
    for (k = 0; k < dt; k += 10) {
      if (hima_mvec_ext(seq-k, 10, chn1, chn2, nx, ny, u, v) < 0) return -4;

      for (j = 0; j <= ny; j++) {
      for (i = 0; i <= nx; i++) {
        i1 = (int)(i + up[j][i] + 0.49);
        j1 = (int)(j + vp[j][i] + 0.49);
        if (i1 < 0 || i1 > nx || j1 < 0 || j1 > ny) {
          up[j][i] = vp[j][i] = -999;
        }
        else {
          up[j][i] -= u[j1][i1];
          vp[j][i] -= v[j1][i1];
        }
      }
      }
    }
  }
  time_print("hima_mvec_ext: end");

  // 4. H5������ �̵��� �����ڷ� �����
  //sat2 = matrix(0, ny, 0, nx);
  for (j = 0; j <= ny; j++) {
  for (i = 0; i <= nx; i++) {
    if (up[j][i] < -900 || vp[j][i] < -900) {
      sat2[j][i] = -999;
    }
    else {
      i1 = i + (int)(up[j][i] + 0.49) + HIMA_SX - sx;
      j1 = j + (int)(vp[j][i] + 0.49) + HIMA_SY - sy;
      if (i1 >= 0 && i1 <= HIMA_NX && j1 >= 0 && j1 <= HIMA_NY)
        sat2[j][i] = sat1[j1][i1];
      else
        sat2[j][i] = -999;
    }
    //if (i == nx/2) {
    //  printf("(%3d,%3d), %6.2f, %6.2f\n", i, j, sat1[j][i], sat2[j][i]);
    //}
  }
  }

  // 5. �迭 ����
  free_matrix(u, 0, ny, 0, nx);
  free_matrix(v, 0, ny, 0, nx);
  free_matrix(sat1, 0, HIMA_NY, 0, HIMA_NX);
  return 0;
}

/*******************************************************************************
 *  HIMA_GRID �������� Ȯ��� �����͸� �̵����� ��� (H5 ����)
 *******************************************************************************/
int hima_mvec_ext(
  int  seq,
  int  dt,
  int  chn1,
  int  chn2,
  int  nx,
  int  ny,
  float **u,
  float **v
)
{
  float **us, **vs;
  float *p, dv[4];
  float rate_x, rate_y;
  float x1, y1;
  float dx, dy, num_mvec;
  int   wn;
  int   i, j, k, ix, iy;

  // 1. ���� �̵����� �б�
  if (dt > 10) {
    for (k = 0; k < dt; k += 10) {
      if (hima_mvec_file_get(seq-k, 10, chn1, chn2) < 0) return -1;
      if (k == 0) {
        us = matrix(0, sat_mvec_head.nj, 0, sat_mvec_head.ni);
        vs = matrix(0, sat_mvec_head.nj, 0, sat_mvec_head.ni);
        for (j = 0; j < sat_mvec_head.nj; j++) {
        for (i = 0; i < sat_mvec_head.ni; i++) {
          us[j][i] = uu[j][i];
          vs[j][i] = vs[j][i];
        }
        }
      }
      else {
        for (j = 0; j < sat_mvec_head.nj; j++) {
        for (i = 0; i < sat_mvec_head.ni; i++) {
          us[j][i] += uu[j][i];
          vs[j][i] += vs[j][i];
        }
        }
      }
    }

    num_mvec = (float)dt/10.0;
    for (j = 0; j < sat_mvec_head.nj; j++) {
    for (i = 0; i < sat_mvec_head.ni; i++) {
      uu[j][i] = us[j][i]/num_mvec;
      vv[j][i] = vs[j][i]/num_mvec;
    }
    }
  }
  else {
    if (hima_mvec_file_get(seq, dt, chn1, chn2) < 0) return -1;
  }
  time_print("hima_mvec_file_get: end");

  // 2. H5������ ���������� �̵����� ���(����)
  rate_y = (sat_mvec_head.nj - 1)/(float)ny;
  rate_x = (sat_mvec_head.ni - 1)/(float)nx;
  wn = sat_mvec_head.wn1/HIMA_GRID;
  printf("nx=%d, ny=%d / wn=%d / (%d,%d) / %f, %f\n",
          nx, ny, wn, sat_mvec_head.ni, sat_mvec_head.nj, rate_x, rate_y);

  // 2.1. Y��
  for (j = 0; j <= ny; j++) {
    y1 = j*rate_y;
    iy = (int)(y1);
    if (iy < 0 || iy > sat_mvec_head.nj-2) continue;
    dy = y1 - iy;
    //printf("j = %d, iy = %d\n", j, iy);

    // 2.2. X��
    for (i = 0; i <= nx; i++) {
      x1 = i*rate_x;
      ix = (int)(x1);
      if (ix < 0 || ix > sat_mvec_head.ni-2) continue;
      dx = x1 - ix;
      //printf("  i = %d, ix = %d\n", i, ix);

      // 3.1. �������� ��ġ�ϸ� �ٷ� ��� (�ð�����)
      if (j%wn == 0 && i%wn == 0) {
        u[j][i] = uu[iy][ix];
        v[j][i] = vv[iy][ix];
      }
      // 3.2. 4�� ����
      else if (ix >= 1 && ix <= sat_mvec_head.ni-3 && iy >= 1 && iy <= sat_mvec_head.nj-3) {
        // 3.2.1. U����
        for (k = 0; k < 4; k++) {
          p = &uu[iy+k-1][ix];
          dv[k] = *p + dx*(*(p+1) - *p + 0.25*(dx-1.0)*(*(p-1) - *p - *(p+1) + *(p+2)) );
        }
        u[j][i] = dv[1] + dy*(dv[2] - dv[1] + 0.25*(dy-1.0)*(dv[0] - dv[1] - dv[2] + dv[3]) );

        // 3.2.2. V����
        for (k = 0; k < 4; k++) {
          p = &vv[iy+k-1][ix];
          dv[k] = *p + dx*(*(p+1) - *p + 0.25*(dx-1.0)*(*(p-1) - *p - *(p+1) + *(p+2)) );
        }
        v[j][i] = dv[1] + dy*(dv[2] - dv[1] + 0.25*(dy-1.0)*(dv[0] - dv[1] - dv[2] + dv[3]) );
      }
      // 3.3. 2�� ����(��������)
      else if (ix <= sat_mvec_head.ni-2 && iy <= sat_mvec_head.nj-2) {
        // 3.3.1. U����
        for (k = 0; k < 2; k++) {
          p = &uu[iy+k][ix];
          dv[k] = *p*(1.0-dx) + *(p+1)*dx;
        }
        u[j][i] = dv[0]*(1.0-dy) + dv[1]*dy;

        // 3.3.2. V����
        for (k = 0; k < 2; k++) {
          p = &vv[iy+k][ix];
          dv[k] = *p*(1.0-dx) + *(p+1)*dx;
        }
        v[j][i] = dv[0]*(1.0-dy) + dv[1]*dy;
      }

      //printf("u = %f, v = %f\n", u[j][i], v[j][i]);
    }
  }

  // 4. �迭 ����
  free_matrix(uu, 0, sat_mvec_head.nj, 0, sat_mvec_head.ni);
  free_matrix(vv, 0, sat_mvec_head.nj, 0, sat_mvec_head.ni);
  return 0;
}

/*=============================================================================*
 *  �����͸� �̵����� �������� (H5 ����)
 *=============================================================================*/
int hima_mvec_file_get(
  int  seq,
  int  dt,
  int  chn1,
  int  chn2
)
{
  gzFile fg;
  char   fname[120];
  char   *uv;
  char   iu, iv, flag;
  short  *vec;
  float  wt1;
  float  ws, wd;
  int    i, j, k;

  // 1. ������ �ִ��� Ȯ��
  if (hima_mvec_file(seq, dt, chn1, chn2, fname) < 0) return -1;
  sprintf(log_str, "fname = %s", fname);  time_print(log_str);

  // 2. �ڷ� �б�
  // 2.0. ���� ����, ��� ����
  fg = gzopen(fname, "rb");
  gzread(fg, &sat_mvec_head, 64);

  // 2.1. �迭 ���� �� �պκ� skip
  vec = svector(0, (int)(sat_mvec_head.ni - 1));
  gzseek(fg, sat_mvec_head.nj*sat_mvec_head.ni*2, SEEK_CUR);
  uu = matrix(0, sat_mvec_head.nj, 0, sat_mvec_head.ni);
  vv = matrix(0, sat_mvec_head.nj, 0, sat_mvec_head.ni);
  wt1 = 100.0/sat_mvec_head.wn1;

  // 2.2. U����
  for (j = 0; j < sat_mvec_head.nj; j++) {
    gzread(fg, vec, (int)(sat_mvec_head.ni*2));
    for (i = 0; i < sat_mvec_head.ni; i++)
      uu[j][i] = vec[i]*0.01;
  }

  // 2.3. V����
  for (j = 0; j < sat_mvec_head.nj; j++) {
    gzread(fg, vec, (int)(sat_mvec_head.ni*2));
    for (i = 0; i < sat_mvec_head.ni; i++)
      vv[j][i] = vec[i]*0.01;
  }
  gzclose(fg);

  // 3. �迭 ����
  free_svector(vec, 0, (int)(sat_mvec_head.ni - 1));
  return 0;
}

/*=============================================================================*
 *  �����͸� �̵����� ���ϸ�
 *=============================================================================*/
int hima_mvec_file(
  int  seq,
  int  dt,
  int  chn1,
  int  chn2,
  char *fname
)
{
  struct stat st;
  int    YY, MM, DD, HH, MI;
  int    code;

  // 1. �ð�
  seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  chn1 = 9;
  chn2 = 0;

  // 3. ���ϸ�
  if (chn2 == 0 || chn1 == chn2)
    sprintf(fname, "%s/%04d%02d/%02d/hima_mvec_m%d_ch%02d_raw_%04d%02d%02d%02d%02d.bin.gz",
            HIMA_MVEC_DIR, YY, MM, DD, dt, chn1, YY, MM, DD, HH, MI);
  else
    sprintf(fname, "%s/%04d%02d/%02d/hima_mvec_m%d_ch%02d_ch%02d_raw_%04d%02d%02d%02d%02d.bin.gz",
            HIMA_MVEC_DIR, YY, MM, DD, dt, chn1, chn2, YY, MM, DD, HH, MI);
  printf("%s\n", fname);

  // 4. ���翩��
  code = stat(fname, &st);
  if (code < 0 || st.st_size <= 100) return -1;
  return 0;
}

/*=============================================================================*
 *  õ���� �����ڷ� ��ȯǥ �б�
 *=============================================================================*/
int hima_conv_read1(int chn, float cnv[])
{
  FILE  *fp;
  char  buf[4000], tmp[40];
  int   ta = 1;
  int   i, j, k, n;

  // 1. ��ȯǥ ä�� Ȯ�� (ch6������ ����)
  if (chn <= 6) ta = 0;
  chn = chn*2 - 1;

  // 2. �ش��� �� ���, ��ȯ ���� �б�
  if ((fp = fopen(HIMA_CONV_FILE,"r")) == NULL) return -1;
  while (fgets(buf, 1024, fp) != NULL) {
    if (buf[0] == '#') continue;
    getword(tmp, buf, ',');
    n = atoi(tmp);
    for (i = 0; i < 32; i++) {
      getword(tmp, buf, ',');
      if (chn == i) {
        cnv[n] = atof(tmp);
        break;
      }
    }
  }
  fclose(fp);

  // 3. ���ð� �ƴ� ���� �����µ��� ��ȯ
  if (ta) {
    for (i = 0; i < 18000; i++) {
      if (cnv[i] > 0) cnv[i] -= 273.15;
    }
  }
  return 0;
}

/*=============================================================================*
 *  �����͸� �����ڷ� ���� ���� Ȯ�� (���ϸ��� UTC)
 *=============================================================================*/
int hima_file1(int seq, int chn, char *fname)
{
  struct stat st;
  char   hima_head[60], tmp[10];
  int    YY, MM, DD, HH, MI;
  int    code;

  // 1. �ð�(KST->UTC)
  seq2time(seq-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  // 2. ä��Ȯ��
  sprintf(hima_head, "himawari8_ahi_le1b_ch%02d_nwpn", chn);

  // 3. ���ϸ�
  sprintf(fname, "%s/%04d%02d/%02d/%s_%04d%02d%02d%02d%02d.bin.gz",
          HIMA_BIN_DIR, YY, MM, DD, hima_head, YY, MM, DD, HH, MI);

  // 4. ���翩��
  code = stat(fname, &st);
  if (code < 0 || st.st_size <= 100) return -1;
  return 0;
}

/*=============================================================================*
 *  ����ð� ���
 *=============================================================================*/
int time_print(char *buf)
{
  int  YYg, MMg, DDg, HHg, MIg, SSg;
  get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);
  printf("#%04d%02d%02d%02d%02d%02d:%s\n", YYg, MMg, DDg, HHg, MIg, SSg, buf);
  return 0;
}