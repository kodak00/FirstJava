#include "main.h"

#define SWAP(a, b, type) do { \
    type temp; \
    temp=(a); (a)=(b); (b)=temp; \
} while(0)

VER_PROFILE *Init_VER_profile(void)
{
  VER_PROFILE *ver=NULL;
  int i;

  ver = (VER_PROFILE *) malloc(sizeof(VER_PROFILE));

  sprintf(ver->gh.site, "%s", "------");
  ver->gh.site[6]='\0';

  for (i = 0; i < MAX_N_DATA; i++)
    strcpy(ver->gh.ftypes[i], "NO");

  ver->gh.year = 0;
  ver->gh.month = 0;
  ver->gh.day = 0;
  ver->gh.latd = 0;
  ver->gh.latm = 0;
  ver->gh.lats = 0;
  ver->gh.lond = 0;
  ver->gh.lonm = 0;
  ver->gh.lons = 0;
  ver->gh.altitude = SHRT_MIN;
  ver->gh.ndata = SHRT_MIN;
  ver->gh.nheight = SHRT_MIN;
  ver->gh.resolution = SHRT_MIN;
  ver->gh.scale_factor = SHRT_MIN;

  ver->lh.hour = 0;
  ver->lh.min = 0;
  ver->lh.azimuth = SHRT_MIN;
//  ver->lh.nrays = SHRT_MIN;

  return ver;
}

VER_PROFILE *Create_VER_profile(RDR *nc)
{
  VER_PROFILE *ver=NULL;
  int k, j;
  int nvols, nswps;
  char start_time[50], tmp[10];
  int YY, MM, DD, HH, MI;
  unsigned char latd, latm, lats, lond, lonm, lons;

  if (nc == NULL)
  {
    fprintf(logfp, LOG_ERROR, __FILE__, __LINE__, "RDR is NULL");
    return NULL;
  }

  ver = Init_VER_profile();

  strncpy(ver->gh.site, nc->att.site_name, 7);

  strcpy(start_time, nc->var.time_coverage_start);
  strncpy(tmp, start_time+0,  4); tmp[4]="\0"; YY = atoi(tmp);
  strncpy(tmp, start_time+5,  2); tmp[2]="\0"; MM = atoi(tmp);
  strncpy(tmp, start_time+8,  2); tmp[2]="\0"; DD = atoi(tmp);
  strncpy(tmp, start_time+11, 2); tmp[2]="\0"; HH = atoi(tmp);
  strncpy(tmp, start_time+14, 2); tmp[2]="\0"; MI = atoi(tmp);

  utc2kst(&YY, &MM, &DD, &HH, &MI);

  latd = (int)( nc->var.latitude );
  latm = (int)( (nc->var.latitude-latd)*60 );
  lats = (int)( ((nc->var.latitude-latd)*60-latm)*60 );
  lond = (int)( nc->var.longitude );
  lonm = (int)( (nc->var.longitude-lond)*60 );
  lons = (int)( ((nc->var.longitude-lond)*60-lonm)*60 );
  
  ver->gh.year = (short)YY;
  ver->gh.month = (unsigned char)MM;
  ver->gh.day = (unsigned char)DD;
  ver->gh.latd = (unsigned char)latd;
  ver->gh.latm = (unsigned char)latm;
  ver->gh.lats = (unsigned char)lats;
  ver->gh.lond = (unsigned char)lond;
  ver->gh.lonm = (unsigned char)lonm;
  ver->gh.lons = (unsigned char)lons;
  ver->gh.altitude = (short)nc->var.altitude;

  ver->lh.hour = (unsigned char)HH;
  ver->lh.min = (unsigned char)MI;

  nvols = nc->nvars;
  nswps = nc->dim.sweep;
  for (k = 0; k < nvols; k++) {
    strcpy(ver->gh.ftypes[k], nc->mom[k].name);
  }

  ver->gh.ndata = MAX_N_DATA;
  ver->gh.scale_factor = (short)(1/SCALE_FACTOR);
  ver->gh.nheight = nc->dim.range;
  ver->gh.resolution = nc->var.range[1]-nc->var.range[0];

//  ver->lh.azimuth = (float)nc->var.fixed_angle[nc->dim.sweep-1];
//fprintf(stderr, "azimuth %f\n", (float)nc->var.fixed_angle[nc->dim.sweep-1]);

  ver->data = (short **) malloc(MAX_N_DATA * sizeof(short *));
  for (k = 0; k < MAX_N_DATA; k++)
      ver->data[k] = (short *) malloc(ver->gh.nheight * sizeof(short));

  for (k = 0; k < MAX_N_DATA; k++)
    for (j = 0; j < ver->gh.nheight; j++)
      ver->data[k][j] = SHRT_MIN;

  return ver;
}

int Write_VER_profile(VER_PROFILE *ver, char *outfname, char*tmpfname)
{
  size_t tsize=0, seek=0;
  FILE *fp = NULL;
  char sysCmd[MAX_STR]={0,};
  char hour;
  char *tmpfile;
  int i, j, rt;

  VER_PROFILE *ver_tmp=NULL;

  if (ver == NULL)
  {
    fprintf(logfp, LOG_ERROR, __FILE__, __LINE__, "profile is NULL");
    return -1;
  }

  if (access(outfname, F_OK))
  {
    fp = fopen(outfname, "wb");
    if (fp == NULL)
    {
      fprintf(logfp, LOG_ERROR, __FILE__, __LINE__, "led to write file");
      return -1;
    }
    else
    {
      ver_tmp = Init_VER_profile();
      ver_tmp->data = (short **) malloc(MAX_N_DATA * sizeof(short *));
      for (i = 0; i < MAX_N_DATA; i++)
        ver_tmp->data[i] = (short *) malloc(ver->gh.nheight * sizeof(short));

      for (j = 0; j < MAX_N_DATA; j++)
        for (i = 0; i < ver->gh.nheight; i++)
          ver_tmp->data[j][i] = SHRT_MIN;

      fwrite(&(ver->gh), sizeof(VER_GLOBAL_HEADER), 1, fp);
      for (i = 0; i < 24*60/TIME_INTERVAL; i++)
      {
        fwrite(&(ver_tmp->lh), sizeof(VER_LOCAL_HEADER), 1, fp);
        fwrite(ver_tmp->data, sizeof(short)*ver->gh.nheight, MAX_N_DATA, fp);
      }
      Free_VER_profile(ver_tmp);
    }
    fclose(fp);
  }

  fp = fopen(outfname, "r+");
  if (fp == NULL)
  {
    fprintf(logfp, LOG_ERROR, __FILE__, __LINE__, "Failed to write file");
    return -1;
  }

  tsize = sizeof(VER_LOCAL_HEADER)+sizeof(short)*(ver->gh.nheight)*(MAX_N_DATA);
  if (hour > 23) hour -= 24;
  tsize *= (ver->lh.min + ver->lh.hour*60) / TIME_INTERVAL;
  tsize += sizeof(VER_GLOBAL_HEADER);
  if ((seek = fseek(fp, tsize, SEEK_SET)) < 0)
  {
    fprintf(logfp, LOG_ERROR, __FILE__, __LINE__, "Failed to write data in dummy file");
    return -1;
  }

  rt = fwrite(&(ver->lh), sizeof(VER_LOCAL_HEADER), 1, fp);
  for (j = 0; j < MAX_N_DATA; j++)
  {
    fwrite(ver->data[j], sizeof(short)*ver->gh.nheight, 1, fp);
  }
  fclose(fp);

  sprintf(sysCmd, "cp -auprf %s %s", outfname, tmpfname);
  system(sysCmd);
  sleep(2);
  
  memset(sysCmd, 0, sizeof(sysCmd));
  sprintf(sysCmd, "gzip -f %s", tmpfname);
  system(sysCmd);
  sleep(1);

  memset(sysCmd, 0, sizeof(sysCmd));
  tmpfile = basename(tmpfname);
  sprintf(sysCmd, "mv %s.gz %s/%s.gz.tmp", tmpfname, DST_PATH, tmpfile); system(sysCmd);

  memset(sysCmd, 0, sizeof(sysCmd));
  sprintf(sysCmd, "mv %s/%s.gz.tmp %s/%s.gz", DST_PATH, tmpfile, DST_PATH, tmpfile); system(sysCmd);

  return 0;
}

int Free_VER_profile(VER_PROFILE *ver)
{
  int i;

  if (ver == NULL)
    return -1;

  for (i = 0; i < MAX_N_DATA; i++)
    free(ver->data[i]);

  free(ver->data);
  free(ver);

  return 0;
}


/*
 * Numerical Recipes in C (p.341)
 * 8.5 Selecting the Mth largest
 */
float selection(int k, int n, float *tmp)
{
    unsigned int i, ir, j, l, mid;
    float a;
    float arr[n];

    for (i = 0; i < n; i++)
        arr[i] = *(tmp+i);

    l=0;
    ir=n-1;
    for (;;)
    {   
        if (ir <= l+1)
        {   
            if (ir == l+1 && arr[ir] < arr[l]) SWAP(arr[l], arr[ir], float);
            return arr[k];
        }   
        else
        {   
            mid = (l+ir) >> 1;
            SWAP(arr[mid], arr[l+1], float);
            if (arr[l]   > arr[ir]) SWAP(arr[l], arr[ir], float);
            if (arr[l+1] > arr[ir]) SWAP(arr[l+1], arr[ir], float);
            if (arr[l]  > arr[l+1]) SWAP(arr[l], arr[l+1], float);

            i = l+1;
            j = ir; 
            a = arr[l+1];
            for (;;)
            {   
                do i++; while (arr[i] < a); 
                do j--; while (arr[j] > a); 
                if (j < i) break;
                SWAP(arr[i], arr[j], float);
            }   
            arr[l+1] = arr[j];
            arr[j] = a;
            if (j >= k) ir = j-1;
            if (j <= k) l = i;
        }
    }
}

int selection_index(int k, int n, float *tmp)
{
    unsigned int i, ir, j, l, mid;
    float a, ai;
    float arr[n];
    int   ind[n];

    for (i = 0; i < n; i++)
    {
        arr[i] = *(tmp+i);
        ind[i] = i;
    }

    l=0;
    ir=n-1;
    for (;;)
    {   
        if (ir <= l+1)
        {   
            if (ir == l+1 && arr[ir] < arr[l])
            {
              SWAP(arr[l], arr[ir], float);
              SWAP(ind[l], ind[ir], float);
            }
            return ind[k];
        }   
        else
        {   
            mid = (l+ir) >> 1;
            SWAP(arr[mid], arr[l+1], float);
            SWAP(ind[mid], ind[l+1], float);
            if (arr[l]   > arr[ir])
            {
              SWAP(arr[l], arr[ir], float);
              SWAP(ind[l], ind[ir], float);
            }
            if (arr[l+1] > arr[ir])
            {
              SWAP(arr[l+1], arr[ir], float);
              SWAP(ind[l+1], ind[ir], float);
            }
            if (arr[l] > arr[l+1])
            {
              SWAP(arr[l], arr[l+1], float);
              SWAP(ind[l], ind[l+1], float);
            }

            i = l+1;
            j = ir; 
            a = arr[l+1];
            ai = ind[l+1];
            for (;;)
            {   
                do i++; while (arr[i] < a); 
                do j--; while (arr[j] > a); 
                if (j < i) break;
                SWAP(arr[i], arr[j], float);
                SWAP(ind[i], ind[j], float);
            }   
            arr[l+1] = arr[j];
            ind[l+1] = ind[j];
            arr[j] = a;
            ind[j] = ai;
            if (j >= k) ir = j-1;
            if (j <= k) l = i;
        }
    }
}

int select_ray_by_median_filtering(float *data, int nrays)
{
  return selection_index(nrays/2, nrays, data);
}

int Median_VER_filtering(float **swp, VER_PROFILE *ver, int nrays, int index)
{
  int i, j;
  int nbins;
  float *tmp, select;
  
  nbins = ver->gh.nheight;
  tmp = (float *) malloc(nrays * sizeof(float));
  for (j = 0; j < nbins; j++)
  {
    for (i = 0; i < nrays; i++)
    {
      tmp[i] = swp[j][i];
    }
    
    select = selection(nrays/2, nrays, tmp);
    if (select == BADVAL)
      ver->data[index][j] = SHRT_MIN;
    else
      ver->data[index][j] = (short)(select * ver->gh.scale_factor);
  }

  return 0;
}

int utc2kst(int *YY, int *MM, int *DD, int *HH, int *MI)
{
  struct tm utc, *kst=NULL;
  time_t kst_time;

  utc.tm_year = *YY - 1900;
  utc.tm_mon  = *MM - 1;
  utc.tm_mday = *DD;
  utc.tm_hour = *HH;
  utc.tm_min  = *MI;
  utc.tm_sec  = 0;

  kst_time = mktime(&utc) + (9 * 3600);
  kst = localtime(&kst_time);

  *YY = kst->tm_year + 1900;
  *MM = kst->tm_mon + 1;
  *DD = kst->tm_mday;
  *HH = kst->tm_hour;
  *MI = kst->tm_min;

  return 0;
}


int kst2utc(int *YY, int *MM, int *DD, int *HH, int *MI)
{
  struct tm kst, *utc=NULL;
  time_t utc_time;

  kst.tm_year = *YY - 1900;
  kst.tm_mon  = *MM - 1;
  kst.tm_mday = *DD;
  kst.tm_hour = *HH;
  kst.tm_min  = *MI;
  kst.tm_sec  = 0;

  utc_time = mktime(&kst) - (9 * 3600);
  utc = localtime(&utc_time);

  *YY = utc->tm_year + 1900;
  *MM = utc->tm_mon + 1;
  *DD = utc->tm_mday;
  *HH = utc->tm_hour;
  *MI = utc->tm_min;

  return 0;
}
