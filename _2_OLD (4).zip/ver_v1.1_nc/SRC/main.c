/***************************************************************************
 *
 * 2019.06.20
 *
 * 작성자: 백길호(기상레이더센터)
 *
 * 연직지향 관측자료 시계열 표출을 위한 자료 생산 프로그램
 *   - 각 ray 별 DZ(H)의 총 합(VIL과 유사)의 중간값(median)인
 *     하나의 ray를 대표 ray로 설정
 *
 ***************************************************************************/

#include "main.h"

FILE *logfp;

int main(int argc, char *argv[])
{
  RDR *nc=NULL;
  float *db_sum=NULL, dbz, ftmp;
  int i, j, k, count, nswps=0, nrays=0, nbins=0;
  unsigned long index, ind_dbz=0, ind_azim=0, ind_start=0;
  char *ptr=NULL, *base=NULL;
  char input[MAX_STR]={0,}, *seperate[10]={NULL,};
  char site_name[8]={0,}, date[13]={0,};
  char tmp_path[MAX_STR]={0,}, tmp_fname[MAX_STR]={0,};
  char out_path[MAX_STR]={0,}, out_fname[MAX_STR]={0,};
  char log_path[MAX_STR]={0,}, log_fname[MAX_STR]={0,};

  struct tm time;
  VER_PROFILE *ver=NULL;

  if (argc < 2)
  {
    fprintf(stderr, LOG_ERROR, __FILE__, __LINE__, "No input variables...");
    fprintf(stderr, "\tSYNTAX: %s RDR_{SITE}_{YYMMDDHHMI}.uf\n", argv[0]);
//    return -1;
    exit(EXIT_SUCCESS);
  }

  strcpy(input, argv[1]);
  base = basename(input);
  ptr = strtok(base, "_"); count=0;
  while (ptr != NULL)
  {
    seperate[count++] = ptr;
    ptr = strtok(NULL, "_");
  }
  strcpy(site_name, seperate[1]);
  strncpy(date, seperate[count-1], 12);

  strptime(date, "%Y%m%d%H%M", &time);
  sprintf(log_path, LOG_PATH, site_name);
  strftime(log_fname, sizeof(log_fname), log_path, &time);

  logfp = fopen(log_fname, "at");
  if (logfp != NULL)
    fprintf(logfp, LOG_START);
  else
  {
    fprintf(logfp, LOG_ERROR, __FILE__, __LINE__, "Log file can't open");
    fprintf(logfp, LOG_END);
//    return -1;
    exit(EXIT_SUCCESS);
  }

  // 1. UF 파일 읽기
  fprintf(logfp, LOG_READ, "Read UF data", argv[1]);
  if ( (nc = WRC_nc_to_rdr(argv[1])) == NULL)
  {
    fprintf(logfp, LOG_ERROR, __FILE__, __LINE__, "RSL_anyformat_to_radar is fail");
    fprintf(logfp, LOG_END);
//    return -1;
    exit(EXIT_SUCCESS);
  }

  // 2. VER 저장용 profile 생성
  fprintf(logfp, LOG_FUNC, "Make VER profile");
  ver = Create_VER_profile(nc);
  if (ver == NULL)
  {
    fprintf(logfp, LOG_ERROR, __FILE__, __LINE__, "Fail to make VER profile");
    fprintf(logfp, LOG_END);
//    return -1;
    exit(EXIT_SUCCESS);
  }

  // 3. 대표값으로 VER 추출
  //    - DZ(H)을 Ray 방향으로 합한 후, 중간값으로 대표 방위각 선택
  //    - 대표 방위각의 ray로 VER 생성
  nswps = nc->dim.sweep;
  nrays = nc->var.sweep_end_ray_index[nswps-1] + 1;
  nbins = nc->var.ray_n_gates[nrays-1];

  for (k = 0; k < MAX_N_DATA; k++)
  {
    if (!strcmp(ver->gh.ftypes[k], "UH"))
    {
      ind_dbz = k;
      break;
    }
  }

  ind_start = nc->var.sweep_start_ray_index[nswps-1];
  db_sum = (float *) malloc(sizeof(float) * nrays);
  for (j = 0; j < nrays; j++)
  {
    db_sum[j] = 0;
    for (i = 0; i < nbins; i++)
    {
      index = ind_start + j + i * nbins;
      dbz = nc->mom[ind_dbz].data[index]
          * nc->mom[ind_dbz].scale_factor
          + nc->mom[ind_dbz].add_offset;

      db_sum[j] += pow(10, dbz/10.0);
    }
  }

  ind_azim = select_ray_by_median_filtering(db_sum, nrays);

  for (k = 0; k < MAX_N_DATA; k++)
  {
    if (!strcmp(ver->gh.ftypes[k], "NO")) continue;

    ver->lh.azimuth = nc->var.azimuth[ind_start+ind_azim];
    for (j = 0; j < nbins; j++)
    {
      index = j + ind_azim * nbins;
      ftmp = nc->mom[k].data[index]
           * nc->mom[k].scale_factor
           + nc->mom[k].add_offset;

      ver->data[k][j] = (short)(ftmp * ver->gh.scale_factor);
    }
  }

  // 4. VER profile 저장
  sprintf(tmp_path, TMP_PATH, ver->gh.site);
  sprintf(out_path, OUT_PATH, ver->gh.site);
  strftime(tmp_fname, sizeof(tmp_fname), tmp_path, &time);
  strftime(out_fname, sizeof(out_fname), out_path, &time);

  fprintf(logfp, LOG_FUNC, "Write VER product");
  if (Write_VER_profile(ver, out_fname, tmp_fname) < 0)
  {
    fprintf(logfp, LOG_ERROR, __FILE__, __LINE__, "Fail to write VER product");
    fprintf(logfp, LOG_END);
//    return -1;
    exit(EXIT_SUCCESS);
  }
  
  // 5. 메모리 해제
  free(db_sum);
  WRC_free_rdr(nc);
  Free_VER_profile(ver);

  fprintf(logfp, LOG_END);
  return 0;
}
