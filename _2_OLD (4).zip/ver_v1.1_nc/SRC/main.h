#ifndef MAIN_H_
#define MAIN_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <libgen.h>
#include <time.h>
#include <math.h>
#include <limits.h>
#include "zlib.h"
#include "ver.h"
#include "rsl.h"
#include "wrc_nc.h"

#define MAX_STR 128

#define BASE "/rdr/src/ver_v1.1_nc"
#define TMP_PATH BASE"/TMP/RDR_%s_VER_%%Y%%m%%d.bin"
#define OUT_PATH BASE"/DATA/RDR_%s_VER_%%Y%%m%%d.bin"
#define LOG_PATH BASE"/LOG/log_%s_%%Y%%m%%d"
//#define DST_PATH BASE"/DATA"
#define DST_PATH "/rdr/BUFD/PRG/VER"

// LOG comment
#define LOG_START   "==================== LOG START ====================\n"
#define LOG_END     "==================== LOG   END ====================\n"
#define LOG_READ    "| START | %s ( %s )\n"
#define LOG_FUNC    "| START | %s\n"
#define LOG_ERROR   "| ERROR | %s : %d | %s\n"
extern FILE *logfp;

#endif /* MAIN_H_ */
