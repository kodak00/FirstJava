#ifndef VER_H_
#define VER_H_

#include "rsl.h"
#include "wrc_nc.h"

// VER 관측 설정
#define TIME_INTERVAL   (30)
#define MAX_N_DATA      (30)
#define SCALE_FACTOR    (0.01)

typedef struct
{
    char site[7];
    char ftypes[MAX_N_DATA][10];
    short year;
    unsigned char  month;
    unsigned char  day;
    unsigned char  latd;
    unsigned char  latm;
    unsigned char  lats;
    unsigned char  lond;
    unsigned char  lonm;
    unsigned char  lons;
    short altitude;
    short ndata;
    short nheight;
    short resolution;
    short scale_factor;
    short dummy1;
    short dummy2;
    short dummy3;
    short dummy4;
} VER_GLOBAL_HEADER;

typedef struct
{
    unsigned char  hour;
    unsigned char  min;
    float azimuth;
    short dummy1;
    short dummy2;
} VER_LOCAL_HEADER;

typedef struct
{
    VER_GLOBAL_HEADER gh; 
    VER_LOCAL_HEADER  lh; 
    short **data;
} VER_PROFILE;

VER_PROFILE *Init_VER_profile(void);
VER_PROFILE *Create_VER_profile(RDR *nc);
int Write_VER_profile(VER_PROFILE *ver, char *outfname, char*tmpfname);
int Free_VER_profile(VER_PROFILE *ver);
float selection(int k, int n, float *tmp);
int selection_index(int k, int n, float *tmp);
int select_ray_by_median_filtering(float *data, int nrays);
int Median_VER_filtering(float **swp, VER_PROFILE *ver, int nrays, int index);
int utc2kst(int *YY, int *MM, int *DD, int *HH, int *MI);
int kst2utc(int *YY, int *MM, int *DD, int *HH, int *MI);

#endif
