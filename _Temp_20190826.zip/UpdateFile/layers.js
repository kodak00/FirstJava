// baseMap.setVisible(true)
// baseMap.setZIndex(6)
// baseMap.setOpacity(0.7)

// 베이스맵 (국가 경계)
var baseMap = new ol.layer.Image({
	      source: new ol.source.ImageWMS({
	        ratio: 1,
	        url: geoServerUrl,
	        params: {'FORMAT': format,
	                 'VERSION': '1.1.1',  
	              STYLES: '',
	              LAYERS: 'NECIS:t_world_nation'
	        },
            crossOrigin : 'anonymous'
	      })
	    });

//우리나라국가 - 경계
var koreaLay = new ol.layer.Image({
	      source: new ol.source.ImageWMS({
	        ratio: 1,
	        url: geoServerUrl,
	        params: {'FORMAT': format,
	                 'VERSION': '1.1.1',  
	              STYLES: '',
	              LAYERS: 'NECIS:korea'
	        },
            crossOrigin : 'anonymous'
	      })
	    });

// 행정구역(시도) - 경계
var emdSidoLay = new ol.layer.Image({
	      source: new ol.source.ImageWMS({
	        ratio: 1,
	        url: geoServerUrl,
	        params: {'FORMAT': format,
	                 'VERSION': '1.1.1',  
	              STYLES: '',
	              LAYERS: 'NECIS:koreaSido'
	        },
            crossOrigin : 'anonymous'
	      })
	    });
 
//행정구역(시도) - 명칭+경계
var emdSidoLabelLay = new ol.layer.Image({
	      source: new ol.source.ImageWMS({
	        ratio: 1,
	        url: geoServerUrl,
	        params: {'FORMAT': format,
	                 'VERSION': '1.1.1',  
	              STYLES: '',
	              LAYERS: 'NECIS:koreaSidoLabel'
	        },
            crossOrigin : 'anonymous'
	      })
	    });

//행정구역(시군구) - 경계
var emdSigunguLay = new ol.layer.Image({
	      source: new ol.source.ImageWMS({
	        ratio: 1,
	        url: geoServerUrl,
	        params: {'FORMAT': format,
	                 'VERSION': '1.1.1',  
	              STYLES: '',
	              LAYERS: 'NECIS:koreaSigungu'
	        },
            crossOrigin : 'anonymous'
	      })
	    });

//행정구역(시군구) - 경계+명칭
var emdSigunguLabelLay = new ol.layer.Image({
	      source: new ol.source.ImageWMS({
	        ratio: 1,
	        url: geoServerUrl,
	        params: {'FORMAT': format,
	                 'VERSION': '1.1.1',  
	              STYLES: '',
	              LAYERS: '	NECIS:koreaSigunguLabel'
	        },
            crossOrigin : 'anonymous'
	      })
	    });

//행정구역(읍면동) - 경계
var emdDongLay = new ol.layer.Image({
	      source: new ol.source.ImageWMS({
	        ratio: 1,
	        url: geoServerUrl,
	        params: {'FORMAT': format,
	                 'VERSION': '1.1.1',  
	              STYLES: '',
	              LAYERS: 'NECIS:koreaDong'
	        },
            crossOrigin : 'anonymous'
	      })
	    });

//행정구역(읍면동) - 경계+명칭
var emdDongLabelLay = new ol.layer.Image({
	      source: new ol.source.ImageWMS({
	        ratio: 1,
	        url: geoServerUrl,
	        params: {'FORMAT': format,
	                 'VERSION': '1.1.1',  
	              STYLES: '',
	              LAYERS: 'NECIS:koreaDongLayerLabel'
	        },
            crossOrigin : 'anonymous'
	      })
	    });
// 위성
var stlLay = new ol.layer.Image({
	      source: new ol.source.ImageWMS({
	        ratio: 1,
	        url: geoServerUrl,
	        params: {'FORMAT': format,
	                 'VERSION': '1.1.1',  
	              STYLES: '',
	              LAYERS: 'NECIS:NasaWorld'
	        },
            crossOrigin : 'anonymous'
	      })
	    });

// 음영기복도
var sriLay = new ol.layer.Image({
	      source: new ol.source.ImageWMS({
	        ratio: 1,
	        url: geoServerUrl,
	        params: {'FORMAT': format,
	                 'VERSION': '1.1.1',  
	              STYLES: '',
	              LAYERS: 'NECIS:Korea_DEM'
	        },
            crossOrigin : 'anonymous'
	      })
	    });

// 도로
var roadLay = new ol.layer.Image({
	      source: new ol.source.ImageWMS({
	        ratio: 1,
	        url: geoServerUrl,
	        params: {'FORMAT': format,
	                 'VERSION': '1.1.1',  
	              STYLES: '',
	              LAYERS: 'NECIS:road'
	        },
            crossOrigin : 'anonymous'
	      })
	    });

// 고속국도
var expressLay = new ol.layer.Image({
    source: new ol.source.ImageWMS({
      ratio: 1,
      url: geoServerUrl,
      params: {'FORMAT': format,
               'VERSION': '1.1.1',  
            STYLES: '',
            LAYERS: 'NECIS:express_road'
      },
      crossOrigin : 'anonymous'
    })
  }); 

// 일반국도
var generalLay = new ol.layer.Image({
    source: new ol.source.ImageWMS({
      ratio: 1,
      url: geoServerUrl,
      params: {'FORMAT': format,
               'VERSION': '1.1.1',  
            STYLES: '',
            LAYERS: 'NECIS:general_road'
      },
      crossOrigin : 'anonymous'
    })
  });

// 지방도
var localLay = new ol.layer.Image({
    source: new ol.source.ImageWMS({
      ratio: 1,
      url: geoServerUrl,
      params: {'FORMAT': format,
               'VERSION': '1.1.1',  
            STYLES: '',
            LAYERS: 'NECIS:local_road'
      },
      crossOrigin : 'anonymous'
    })
  });

// 국가하천
var riverLay = new ol.layer.Image({
	      source: new ol.source.ImageWMS({
	        ratio: 1,
	        url: geoServerUrl,
	        params: {'FORMAT': format,
	                 'VERSION': '1.1.1',  
	              STYLES: '',
	              LAYERS: 'NECIS:t_river_nation'
	        },
            crossOrigin : 'anonymous'
	      })
	    });
// 지방하천
var riverAreaLay = new ol.layer.Image({
    source: new ol.source.ImageWMS({
      ratio: 1,
      url: geoServerUrl,
      params: {'FORMAT': format,
               'VERSION': '1.1.1',  
            STYLES: '',
            LAYERS: 'NECIS:t_river_area'
      },
      crossOrigin : 'anonymous'
    })
  });

// 위경도(5도)
var gidLayer = new ol.layer.Image({
    source: new ol.source.ImageWMS({
        ratio: 1,
        url: geoServerUrl,
        params: {'FORMAT': format,
                 'VERSION': '1.1.1',  
              STYLES: '',
              LAYERS: 'NECIS:GRID_LINE'
        },
        crossOrigin : 'anonymous'
      })
    });

//위경도(1도)
var gid1kLayer = new ol.layer.Image({
	source: new ol.source.ImageWMS({
		ratio: 1,
		url: geoServerUrl,
		params: {'FORMAT': format,
			'VERSION': '1.1.1',  
			STYLES: '',
			LAYERS: 'NECIS:grid_line_1k'
		},
        crossOrigin : 'anonymous'
	})
});

baseMap.setZIndex(ObjectIndex.EDT)

koreaLay.setVisible(false);
koreaLay.setZIndex(ObjectIndex.KOR);

//oskim 20181219 , set to default SidoLay !
emdSidoLay.setVisible(true);
emdSidoLay.setZIndex(ObjectIndex.EMD);

emdSidoLabelLay.setVisible(false);
emdSidoLabelLay.setZIndex(ObjectIndex.EML);

emdSigunguLay.setVisible(false);
emdSigunguLay.setZIndex(ObjectIndex.EMD);

emdSigunguLabelLay.setVisible(false);
emdSigunguLabelLay.setZIndex(ObjectIndex.EML);

emdDongLay.setVisible(false);
emdDongLay.setZIndex(ObjectIndex.EMD);

emdDongLabelLay.setVisible(false);
emdDongLabelLay.setZIndex(ObjectIndex.EML);

stlLay.setVisible(false);
stlLay.setZIndex(ObjectIndex.STL);

sriLay.setVisible(false);
sriLay.setZIndex(ObjectIndex.SRI);

roadLay.setVisible(false);
roadLay.setZIndex(ObjectIndex.ROD);

expressLay.setVisible(false);
expressLay.setZIndex(ObjectIndex.EXR);

generalLay.setVisible(false);
generalLay.setZIndex(ObjectIndex.GNR);

localLay.setVisible(false);
localLay.setZIndex(ObjectIndex.LCR);

riverLay.setVisible(false);
riverLay.setZIndex(ObjectIndex.NAV);

riverAreaLay.setVisible(false);
riverAreaLay.setZIndex(ObjectIndex.LCV);

gidLayer.setVisible(false);
gidLayer.setZIndex(ObjectIndex.GID);

gid1kLayer.setVisible(false);
gid1kLayer.setZIndex(ObjectIndex.GID);


// 비행정보구역 레이어
var firLayer;
// 태풍경계구역 레이어
var typRouteLayer = new Array();
var typLayer;
// AWS 지점 레이어
var awsLayer = new Array();
// 주요공항지점 레이어
var airLayer;
// AWS 지점 툴팁 박스 레이어
var tooltipBoxLayer;
// AWS 지점 툴팁 텍스트(값) 레이어
var tooltipTextLayer;

// CGI 이미지 레이어
var cgiImageLayer = new Array();
cgiImageLayer[0] = new ol.layer.Image({
	source: new ol.source.ImageStatic({
        url: '',
        crossOrigin : 'anonymous',
        projection: 'EPSG:222222',
        imageExtent: [0,0,0,0]
    }),
    opacity: 1
});
cgiImageLayer[1] = new ol.layer.Image({
	source: new ol.source.ImageStatic({
        url: '',
        crossOrigin : 'anonymous',
        projection: 'EPSG:222222',
        imageExtent: [0,0,0,0]
    }),
    opacity: 1
});
cgiImageLayer[2] = new ol.layer.Image({
	source: new ol.source.ImageStatic({
        url: '',
        crossOrigin : 'anonymous',
        projection: 'EPSG:222222',
        imageExtent: [0,0,0,0]
    }),
    opacity: 1
});
cgiImageLayer[3] = new ol.layer.Image({
	source: new ol.source.ImageStatic({
        url: '',
        crossOrigin : 'anonymous',
        projection: 'EPSG:222222',
        imageExtent: [0,0,0,0]
    }),
    opacity: 1
});
cgiImageLayer[0].setZIndex(ObjectIndex.CGI + Number(0));
cgiImageLayer[1].setZIndex(ObjectIndex.CGI + Number(1));
cgiImageLayer[2].setZIndex(ObjectIndex.CGI + Number(2));
cgiImageLayer[3].setZIndex(ObjectIndex.CGI + Number(3));

// CGI 위험기상경보 레이어
var cgiTitImageLayer;

//연직단면 선 긋기 소스
var drawCrosssource = new ol.source.Vector();
//연직단면 선 긋기 벡터 레이어
var drawCrossLayer = new ol.layer.Vector({
	  name : 'vectorCross',
	  source: drawCrosssource,
	  style: new ol.style.Style({
	    fill: new ol.style.Fill({
	      color: '#ff0000'
	    }),
	    stroke: new ol.style.Stroke({
	      color: '#ff0000',
	      width: 2
	    })
	  })
});
drawCrossLayer.setZIndex(ObjectIndex.DRAW);
