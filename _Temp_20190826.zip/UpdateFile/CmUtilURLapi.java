package kres.cm.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class CmUtilURLapi {
	
	public CmUtilURLapi() {
	}

	public static List<List<String>> getURLTyphoonList(String strYear) throws Exception {
		
		List<List<String>> records = new ArrayList<>();
		
	    //urlString = "http://172.20.134.91/url/typ_lst.php?YY=2012&disp=0&help=0";
		String urlString = "http://172.20.134.91/url/typ_lst.php?YY="+strYear+"&disp=0&help=0";
	    
	    // create the url
	    //URL url = new URL(urlString);
	    if(strYear.equals("2011") == false)
	    	return null;
	    
	    // open the url stream, wrap it an a few "readers"
	    //BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
	    BufferedReader reader = Files.newBufferedReader(Paths.get("C:\\Temp\\_Temp_\\tl.txt"), StandardCharsets.UTF_8);

	    String line;
	    while ((line = reader.readLine()) != null)
	    {
	        if(line.indexOf("#") != 0){
                //typhoon list
	        	//String field = line.substring(45,64);	//(0,4), (4,9), (9,14) (14,19) (19,32) (32,45) (45,64) (64,85)
                ///*
	        	List<String> tmpList = new ArrayList<String>();
	        	tmpList.add(line.substring(0,4));		//YY
	        	tmpList.add(line.substring(4,9));		//SEQ
	        	tmpList.add(line.substring(9,14));		//NOW
	        	tmpList.add(line.substring(14,19));		//EFF
	        	tmpList.add(line.substring(19,32));		//TM_ST
	        	tmpList.add(line.substring(32,45));		//TM_ED
	        	tmpList.add(line.substring(45,63));		//TYP_NAME
	        	tmpList.add(line.substring(63,84));		//TYP_EN
                //System.out.println(tmpList);
                records.add(tmpList);
                //*/		       
	        }
	    }
	    
	    for(List<String> newLine : records){
	    	List<String> list = newLine;
	    	for(String data : list){
	    		data = data.replaceAll("\\s+","");
	    		System.out.print(data);
	    		System.out.print(",");
	    	}
	    	//개행코드추가
	    	System.out.print("\n");
	    }
	    
	    // close our reader
	    reader.close();
	    
	    return records;
	}
	
	public static List<List<String>> getURLTyphoonRoute(String strYear, String strSeq) throws Exception {
		
		List<List<String>> records = new ArrayList<>();
		
	    //String urlString = "http://172.20.134.91/url/typ_data.php?YY=2011&typ=9&seq=8&mode=1&disp=0&help=0";
	    String urlString = "http://172.20.134.91/url/typ_data.php?YY="+strYear+"&typ="+strSeq+"&seq=8&mode=1&disp=0&help=0";
	    
	    // create the url
	    //URL url = new URL(urlString);
	    if((strYear.equals("2011") && strSeq.equals("9")) == false)
	    	return null;
	    	
	    // open the url stream, wrap it an a few "readers"
	    //BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
	    BufferedReader reader = Files.newBufferedReader(Paths.get("C:\\Temp\\_Temp_\\tr.txt"), StandardCharsets.UTF_8);

	    String line;
	    while ((line = reader.readLine()) != null)
	    {
	        if(line.indexOf("#") != 0){
	        	//typhoon route
	        	//String field = line.substring(64,69);	//(0,4), (4,9), (9,14) (14,19) (19,24) (24,38) (38,50) (50,58) (58,64) (64,69)
	        	List<String> tmpList = new ArrayList<String>();
	        	tmpList.add(line.substring(0,4));		//FT
	        	tmpList.add(line.substring(4,9));		//YY
	        	tmpList.add(line.substring(9,14));		//TYP
	        	tmpList.add(line.substring(14,19));		//SEQ
	        	tmpList.add(line.substring(19,24));		//TMD
	        	tmpList.add(line.substring(24,38));		//TYP_TM
	        	tmpList.add(line.substring(38,50));		//FT_TM
	        	tmpList.add(line.substring(50,58));		//LAT
	        	tmpList.add(line.substring(58,64));		//LON
	        	tmpList.add(line.substring(64,69));		//DIR
	        	tmpList.add(line.substring(69,74));		//SP
	        	
                records.add(tmpList);
	        }
	    }
	    // close our reader
	    reader.close();
	    
	    return records;
	}	
}
