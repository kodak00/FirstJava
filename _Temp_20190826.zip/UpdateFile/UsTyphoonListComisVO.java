package kres.us.cmmn.service;

public class UsTyphoonListComisVO {
	private int				YY		= 0;
	private int				SEQ		= 0;
	private int 			NOW		= 0;
	private int 			EFF		= 0;
	private String			TM_ST	= "";
	private String			TM_ED	= "";
	private String 			TYP_NAME= "";
	private String			TYP_EN	= "";
	
	public int getYY() {
		return YY;
	}
	public void setYY(int yY) {
		YY = yY;
	}
	public int getSEQ() {
		return SEQ;
	}
	public void setSEQ(int sEQ) {
		SEQ = sEQ;
	}
	public int getNOW() {
		return NOW;
	}
	public void setNOW(int nOW) {
		NOW = nOW;
	}
	public int getEFF() {
		return EFF;
	}
	public void setEFF(int eFF) {
		EFF = eFF;
	}
	public String getTM_ST() {
		return TM_ST;
	}
	public void setTM_ST(String tM_ST) {
		TM_ST = tM_ST;
	}
	public String getTM_ED() {
		return TM_ED;
	}
	public void setTM_ED(String tM_ED) {
		TM_ED = tM_ED;
	}
	public String getTYP_NAME() {
		return TYP_NAME;
	}
	public void setTYP_NAME(String tYP_NAME) {
		TYP_NAME = tYP_NAME;
	}
	public String getTYP_EN() {
		return TYP_EN;
	}
	public void setTYP_EN(String tYP_EN) {
		TYP_EN = tYP_EN;
	}
	
}
