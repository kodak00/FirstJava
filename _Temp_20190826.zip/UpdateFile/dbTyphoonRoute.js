(function() {
	
	var prevLST = '';
	var prevLON = '';
	var prevLAT = '';
	
    var db = {   	
        loadData: function(filter) {
        	//var selName = $("#typhoonName").val();
        	//name = encodeURIComponent(selName);
        	//name = encodeURIComponent('문');
        	
        	var selName = $("#selectTyphoon option:checked").text();
        	name = encodeURIComponent(selName);
        	
            return $.ajax({
                type: "GET",
                url: "/cmmn/typhoonRouteGET.do",
                cache: false,
                data: {filter:filter, name:name}
            });
        },

        insertItem: function(item) {
        	//var selName = $("#typhoonName").val();
        	var selName = $("#selectTyphoon option:checked").text();
        	
        	var diffHour = 0;
        	var distance = 0;
        	var azimuth = 0;
        	
        	var LST = item.LST;
        	
        	//LST -> Date형 변환
        	LST = getDateToStr2(LST);
        	currTimeDate = getDateFormatTime(LST);
        	
        	//if(typeof prevLST !== 'undefined' && typeof prevLON !== 'undefined' && typeof prevLAT !== 'undefined'){
        	if( prevLST !== '' &&  prevLON !== '' &&  prevLAT !== ''){
        		prevLST = getDateToStr2(prevLST);
        		prevTimeDate = getDateFormatTime(prevLST);
        		
        		diffHour = (currTimeDate.getTime() - prevTimeDate.getTime()) / (1000*60*60);	//hour
        		distance = cfGetDistance([prevLON,prevLAT,item.LON,item.LAT], 'EPSG:4326') / 1000.0;	//km
        		azimuth = calAzimuth(prevLON,prevLAT,item.LON,item.LAT);
        	}
        	
        	//자동 필드 계산
        	item.UTC 	= getDateToStr(new Date(Date.parse(currTimeDate) - 1000 * 60 * 60 * 9));	//9시간 전
        	item.DIST 	= distance;
        	item.DIR 	= azimuth;
        	item.SPEED 	= diffHour == 0 ? 0 : distance / diffHour;
        	
        	item.NAME	= selName;
        	
        	prevLST = item.LST;
        	prevLON = item.LON;
        	prevLAT = item.LAT;
        	
            return $.ajax({
                type: "POST",
                cache: false,
                url: "/cmmn/typhoonRoutePOST.do",
                data: item
            });
        },

        updateItem: function(item) {
        	//수정시 자동 필드 계산 안됨, UTC, DIST, DIR, SPEED      	
        	var data = $("#jsGrid").jsGrid("option", "data");
        	
    		for(var i = 1;i < data.length; i++){
    			
            	LST = getDateToStr2(data[i]['LST']);
            	currTimeDate = getDateFormatTime(LST);
            	
        		prevLST = getDateToStr2(data[i-1]['LST']);
        		prevTimeDate = getDateFormatTime(prevLST);            	
    			
    			data[i]['UTC'] 	= getDateToStr(new Date(Date.parse(currTimeDate) - 1000 * 60 * 60 * 9));
    			data[i]['DIST'] = cfGetDistance([data[i-1]['LON'],data[i-1]['LAT'],data[i]['LON'],data[i]['LAT']], 'EPSG:4326') / 1000.0;
    			data[i]['DIR']	= calAzimuth(data[i-1]['LON'],data[i-1]['LAT'],data[i]['LON'],data[i]['LAT']);
    			data[i]['SPEED']= 55;//data[i]['DIST'] / (currTimeDate.getTime() - prevTimeDate.getTime()) / (1000*60*60);
    			
    			//alert(lon + ',' + lat); 			
    		}        	
    		$("#jsGrid").jsGrid("deleteItem", data[i]);
    		
    		//$("#jsGrid").jsGrid("updateItem", data[0]);
        	
            return $.ajax({
                type: "POST",
                cache: false,
                url: "/cmmn/typhoonRoutePUT.do",
                data: item
            });        	
        },

        deleteItem: function(item) {
            return $.ajax({
                type: "POST",
                cache: false,
                url: "/cmmn/typhoonRouteDELETE.do",
                data: item
            });
        }

    };

    window.db = db;
    
    var db2 = {   	
            loadData: function(filter) {
            	var year = $("#selectYear option:checked").val();
            	var typ = $("#selectTyphoon option:checked").val();
            	
                return $.ajax({
                    type: "GET",
                    cache: false,
                    url: "/cmmn/typhoonRouteComis.do",
                    data: {filter:filter, year:year, typ:typ}
                });
            },
    
		    deleteItem: function(item) {
		        var clientIndex = $.inArray(item, this.clients);
		        this.clients.splice(clientIndex, 1);
		    }
    };

    window.db2 = db2;    

}());