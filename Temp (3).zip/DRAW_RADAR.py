#!/usr/local/anaconda2/bin/python
## -*- coding: utf-8 -*-
import sys
import os
from os.path import basename

import time
import matplotlib.pyplot as plt
import numpy as np
import netCDF4
import pyart



#=== READ FILE ========================================================+
home        = '/work/rnd/PYART/'
raw         = os.path.join(home, 'DATA/RDR_RKJK_20180301004513.raw')
raw         = os.path.join(home, 'DATA/RDR_RKSG_20180101101137.raw')
uf          = os.path.join(home, 'DATA/RDR_RKJK_20180301004513.uf')
uf          = os.path.join(home, 'DATA/RDR_RKSG_20180101101137_1.uf')
uf          = os.path.join(home, 'DATA/RDR_KWK_201802282045.uf')
nc3         = os.path.join(home, 'ewr/nc3/Output04K03170824012720.RAWBAR2_sweep1.nc3')  #KeyError: 'time'
nc4         = os.path.join(home, 'ewr/nc4/Output04K03170824012720.RAWBAR2_sweep1.nc4')  #KeyError: 'time'
hdf4        = os.path.join(home, 'ewr/hdf4/Pyongchang170824012720.RAW0855.h4')  #Unable to open file (File signature not found)
hdf5        = os.path.join(home, 'ewr/hdf5/Pyongchang170824012720.RAW0855.h5')  #KeyError: "Can't open attribute (Can't locate attribute: 'source')"


if len(sys.argv) > 1:
  filename	= str(sys.argv[1])
else :
  filename  = nc4

basename    = os.path.basename(filename)
extension   = os.path.splitext(filename)

## CHECK FILE EXTENSION
if extension[1] == '.hdf' or extension[1] == '.h4' or extension[1] == '.h5':
  radar       = pyart.aux_io.read_odim_h5(filename, file_field_names=True, exclude_field='height')
  #radar       = pyart.aux_io.read_odim_h5(filename)
else :
  radar       = pyart.io.read(filename)



#=== RADAR INFO =======================================================+
type        = pyart.io.auto_read.determine_filetype(filename)

print
print("File: \t\t"+filename)
print("FileType: \t\t"+type)
print "Total Num. of Field: \t", len(radar.fields.keys())
print("Field_Name: ")
for field_name in radar.fields.keys():
  print(" \t"+field_name)

print(radar)


#=== PLOT =============================================================+
qnum = len(radar.fields.keys()) / 3
rnum = len(radar.fields.keys()) % 3
if(rnum > 0) :
  qnum = qnum+1

print(qnum)
print(rnum)

fig = plt.figure(figsize=[15, 15])
title = str(basename)+'   '+str(type)
plt.suptitle(title, fontsize=12)

i=1
for field_name in radar.fields.keys():
  ax = fig.add_subplot(qnum,3,i)
  display = pyart.graph.RadarDisplay(radar)
  display.plot(field_name, 0, ax=ax, colorbar_label='', title='Field: '+field_name)
  i=i+1


#if(qnum == 1):
# #plt.subplots_adjust(top=0.95, bottom=0, wspace=0.3, hspace=0.2)
#  plt.subplots_adjust(hspace=0.2)
#elif qnum == 2:
#  plt.subplots_adjust(wspace=0.2, hspace=0.2)
#elif qnum == 3:
#  plt.subplots_adjust(wspace=0.2, hspace=0.2)

plt.show()

