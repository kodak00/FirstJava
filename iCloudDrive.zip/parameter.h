#ifndef PARAMETER_H
#define PARAMETER_H

/* ================================================================================ */
// DEFINE

#define PARAM_MAX_STR           1024
#define PTYPE_DEFAULT           "PPI"
#define QTYPE_DEFAULT           "NOQC"
#define COMP_METHOD_DEFAULT     "MAX"

#define RDR_FTP_HSR				"/rdr/FTPD/CMP_HSR"    // HSR합성파일 임시저장소
/* ================================================================================ */
// STRUCT

typedef struct
{
    char*   m_szP_type;                 
    char*   m_szQ_type;                 
    char    m_szF_name[PARAM_MAX_STR];  
    char    m_szDate[PARAM_MAX_STR];    
    char*   m_szC_method;               
    char    m_szComp_method;            
    float   m_fLU_lon;                  
    float   m_fLU_lat;                  
    float   m_fRL_lon;                  
    float   m_fRL_lat;                  
    int     m_nImgXdim;                 
    int     m_nImgYdim;                 
    float   m_fXDist;                   
    float   m_fYDist;                   
    char    m_szUnit[PARAM_MAX_STR];    
    int     m_nSmooth;                  
    int     m_nEcho3d;                  
    int     m_nWst;                     
    int     m_nUnitBar;                 
    float   m_fImgGridKm;               
    int     m_nPointRain;               
    float   m_fPointLon;                
    float   m_fPointLat;               
    int     m_nW_Flag;
    long    m_lN_Date; 

    int     m_nCompMix; //oskim 20180716
    int     m_nCompDsp; //oskim 20180827, 20180920 no more use this pararmater. just use D_TYPE !!
} st_Option;
  
typedef struct
{
    float   m_fCompLon;           
    float   m_fCompLat;           
    float   m_nCompXo;            
    float   m_nCompYo;            
    int     m_nCompXdim;          
    int     m_nCompYdim;          
    float   m_fCompGridKm;        
} st_Comp;

/* ================================================================================ */
// FUNCTION PROTO

int     fnParamSet(void);
int     fnFileFormatName(char *HDF5_FILE_FORMAT_NAME, char *BIN_FILE_FORMAT_NAME);
char* GetFileName(char file_path[]);
/* ================================================================================ */

#endif /* PARAMETER_H */
