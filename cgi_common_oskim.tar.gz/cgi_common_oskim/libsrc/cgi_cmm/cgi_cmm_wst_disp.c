/* ================================================================================ */
//
// 레이더 에코 영상 GIS - comp_wst_disp.c (합성 일기현상 표출)   
//
// 2016.08.05
//
// SnK
//
/* ================================================================================ */
// INCLUDE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gd.h>
#include <time.h>

#include "cgi_cmm_color.h"
#include "cgi_cmm_map_ini.h"
#include "cgi_cmm_wst_disp.h"

char    *strptime(const char *s, const char *format, struct tm *tm);
/* ================================================================================ */
// LOCAL FUNTION

static void fnCompWstDraw(int nImgXdim, int nImgYdim, int nNum, float fXIdx, float fYIdx, gdImagePtr pImg, int nWstColor)
{
    int  nX_n      = 0;        //VARIABLE
    int  nY_n      = 0;        //VARIABLE

    nX_n = (int)(fXIdx);
    nY_n = (int)(fYIdx);

    if((nX_n > 0) && (nX_n < nImgXdim) && (nY_n > 0) && (nY_n < nImgYdim)) 
    {
        if((0 <= nNum) && (nNum <= 2))
        {
            gdImageArc(pImg, nX_n, nY_n, 9, 9, 0, 360, nWstColor);
        }
        else if((3 <= nNum) && (nNum <= 5))
        {
            gdImageArc(pImg,nX_n, nY_n, 9, 9, 0, 360, nWstColor);
            gdImageLine(pImg, nX_n, nY_n-3, nX_n, nY_n+3, nWstColor);
        }
        else if((6 <= nNum) && (nNum <= 8))
        {
            gdImageArc(pImg, nX_n, nY_n, 9, 9, 0, 360, nWstColor);
            gdImageLine(pImg, nX_n-1, nY_n-3, nX_n-1, nY_n+3, nWstColor);
            gdImageLine(pImg, nX_n+1, nY_n-3, nX_n+1, nY_n+3, nWstColor);
        }
        else if((9 <= nNum) && (nNum <= 10))
        {
            gdImageArc(pImg, nX_n, nY_n, 9, 9, 0, 360, nWstColor);
            gdImageArc(pImg, nX_n, nY_n, 5, 5, 0, 360, nWstColor);
        }
        else if(((50 <= nNum) && (nNum <= 66)) || ((80 <= nNum) && (nNum <= 82)))
        {
            gdImageFilledArc(pImg, nX_n, nY_n, 9, 9, 0, 360, nWstColor, gdArc);
        }
        else if(((70 <= nNum) && (nNum <= 78)) || ((85 <= nNum) && (nNum <= 88)))
        {
            gdImageLine(pImg, nX_n-3, nY_n, nX_n+3, nY_n, nWstColor);
            gdImageLine(pImg, nX_n-3, nY_n-3, nX_n+3, nY_n+3, nWstColor);
            gdImageLine(pImg, nX_n-3, nY_n+3, nX_n+3, nY_n-3, nWstColor);
        }
        else if(((68 <= nNum) && (nNum <= 69)) || ((83 <= nNum) && (nNum <= 84)))
        {
            gdImageFilledArc(pImg, nX_n, nY_n, 7, 7, 0, 360, nWstColor, gdArc);
            gdImageLine(pImg, nX_n-3, nY_n+5, nX_n+3, nY_n+5, nWstColor);
            gdImageLine(pImg, nX_n-3, nY_n-3+5, nX_n+3, nY_n+3+5, nWstColor);
            gdImageLine(pImg, nX_n-3, nY_n+3+5, nX_n+3, nY_n-3+5, nWstColor);
        }
    }
}

/* ================================================================================ */
// FUNCTION

int fnCompWstDisp(float fLU_lon, float fLU_lat, char szDate[], int nImgXdim, int nImgYdim, float fXDist, float fYDist, gdImagePtr pImg)
{
    FILE                  *pfp                      = NULL;            //VARIABLE
    char                  szBuf[WST_BUF_MAX_STR]    = { 0, };          //VARIABLE
    int                   nNum                      = 0;               //VARIABLE
    float                 fLon                      = 0.0;             //VARIABLE
    float                 fLat                      = 0.0;             //VARIABLE
    int                   nCnt                      = 0;               //VARIABLE
    float                 fXIdx                     = 0.0;             //VARIABLE
    float                 fYIdx                     = 0.0;             //VARIABLE
    char                  szFileName[WST_FILE_SIZE] = { 0, };          //VARIABLE
    int                   nWstColor                 = 0;               //VARIABLE
    int                   nTemp_I                   = 0;               //VARIABLE
    float                 fImgXGridM                = 0.0;             //VARIABLE
    float                 fImgYGridM                = 0.0;             //VARIABLE
    float                 fImgLU_lon                = 0.0;             //VARIABLE
    float                 fImgLU_lat                = 0.0;             //VARIABLE
    float                 fImgLU_x                  = 0.0;             //VARIABLE
    float                 fImgLU_y                  = 0.0;             //VARIABLE
    
    st_LAMC_PARAMETER     map;                                         //VARIABLE
    st_LAMC_VAR           var;                                         //VARIABLE
    struct tm             stTime;                                      //VARIABLE
    
    if(pImg == NULL)
    {
        return -1;
    }

    nWstColor  = gdImageColorAllocate(pImg,  51,  51,  51); 
    
    fImgXGridM = fXDist/nImgXdim;
    fImgYGridM = fYDist/nImgYdim;

    var.m_nFirst = 0;
    map = fnCgiGetMapInfo(GIS_MAP_RE, 30, 60, 126, 0, 0.001, 0, 0);

    fImgLU_lon = fLU_lon;
    fImgLU_lat = fLU_lat;
    fnCgiLamcproj(&fImgLU_lon,  &fImgLU_lat,  &fImgLU_x,       &fImgLU_y,       0, &map, &var);

    strptime(szDate, "%Y%m%d%H%M", &stTime);
    strftime(szFileName, WST_FILE_SIZE, WST_FILE, &stTime);

    if((pfp=fopen(szFileName, "rt")) != NULL)
    {
        if(fgets(szBuf, WST_BUF_MAX_STR, pfp) == NULL)
        {
            fclose(pfp);
            return -1;
        }
        else
        {
            sscanf(szBuf, "%d", &nCnt);
        }

        while((fgets(szBuf, WST_BUF_MAX_STR, pfp) != NULL) && (nTemp_I < nCnt))
        {
            sscanf(szBuf, "%d %f %f", &nNum, &fLat, &fLon);

            fnCgiLamcproj(&fLon, &fLat, &fXIdx, &fYIdx, 0, &map, &var);

            fXIdx = (int)((fXIdx- fImgLU_x)/fImgXGridM);
            fYIdx = (int)((fImgLU_y - fYIdx)/fImgYGridM);
            
            if((int)fXIdx < 0 || (int)fXIdx >= nImgXdim ||
                    (int)fYIdx < 0 || (int)fYIdx >= nImgYdim)
            {
                nTemp_I++;
                continue;
            }


            fnCompWstDraw(nImgXdim, nImgYdim, nNum, fXIdx, fYIdx, pImg, nWstColor);
            nTemp_I++;
        }
        
        fclose(pfp);
    }
  
    return 0;
}

/* ================================================================================ */
