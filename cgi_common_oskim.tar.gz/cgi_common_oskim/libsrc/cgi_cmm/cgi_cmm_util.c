/* ================================================================================ */
//
// 레이더 에코 영상 GIS 
//
// 2016.07.29
//
// SnK
//
/* ================================================================================ */
// INCLUDE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <gd.h>

#include "cgi_cmm_util.h"


/* ================================================================================ */
// FUNCTION

float** fnGetMatrixFloat(int nYDim, int nXDim)
{
    float** fTempData   = NULL; //VARIABLE
    int     nYIdx       = 0;    //VARIABLE

    if(nYDim < 0 || nXDim < 0)
    {
        return NULL;
    }

    if((fTempData = (float **)calloc(nYDim, sizeof(float *))) == NULL)
    {
        return NULL;
    }
    
    for(nYIdx = 0; nYIdx < nYDim; nYIdx++)
    {
        if((fTempData[nYIdx] = (float *)calloc(nXDim, sizeof(float))) == NULL)
        {
            fnFreeMatrixFloat(fTempData, nYDim);
            return NULL;
        }                                  
    }    
     
    return fTempData;
}


int** fnGetMatrixInt(int nYDim, int nXDim)
{
    int**   nTempData   = NULL; //VARIABLE
    int     nYIdx       = 0;    //VARIABLE

    if(nYDim < 0 || nXDim < 0)
    {
        return NULL;
    }

    if((nTempData = (int **)calloc(nYDim, sizeof(int *))) == NULL)
    {
        return NULL;
    }
    
    for(nYIdx = 0; nYIdx < nYDim; nYIdx++)
    {
        if((nTempData[nYIdx] = (int *)calloc(nXDim, sizeof(int))) == NULL)
        {
            fnFreeMatrixInt(nTempData, nYDim);
            return NULL;
        }                                  
    }    
     
    return nTempData;
}

double* fnGetAxisDataDouble(int nDim)
{
    double* fTempData   = NULL; //VARIABLE

    if(nDim < 0)
    {
        return NULL;
    }

    if((fTempData = (double *)calloc(nDim, sizeof(double))) == NULL)
    {
        return NULL;
    }
    
    return fTempData;
}

void fnFreeMatrixFloat(float** pMatrix, int nXDim)
{
    int     nXIdx       = 0;    //VARIABLE

    if(pMatrix != NULL)
    {
        for(nXIdx = 0; nXIdx < nXDim; nXIdx++)
        {
            if(pMatrix[nXIdx] != NULL)
            {
                free(pMatrix[nXIdx]);
            }
        }
        
        free(pMatrix);
    }
}

void fnFreeMatrixInt(int** pMatrix, int nXDim)
{
    int     nXIdx       = 0;    //VARIABLE

    if(pMatrix != NULL)
    {
        for(nXIdx = 0; nXIdx < nXDim; nXIdx++)
        {
            if(pMatrix[nXIdx] != NULL)
            {
                free(pMatrix[nXIdx]);
            }
        }
        
        free(pMatrix);
    }
}

void fnFreeAxisDataFloat(float* pAxis)
{
    if(pAxis != NULL)
    {
        free(pAxis);
    }
}

int fnDbzToRainrate(float** data, int nYDim, int nXDim, float fOutBound_f, float fBadValue_f, float fZr_a, float fZr_b)
{
    int     nXidx    = 0;
    int     nYidx    = 0;

    if(data == NULL)
        return -1;

    for(nYidx = 0; nYidx < nYDim; nYidx++)
    {
        for(nXidx = 0; nXidx < nXDim; nXidx++)
        {
            if(data[nYidx][nXidx] <= 0 && data[nYidx][nXidx] != fOutBound_f && data[nYidx][nXidx] != fBadValue_f)
            {
                data[nYidx][nXidx] = fBadValue_f;
            }
            else if(data[nYidx][nXidx] != fOutBound_f && data[nYidx][nXidx] != fBadValue_f)
                data[nYidx][nXidx] = (float)fnDbz_To_R_f((double)data[nYidx][nXidx], fZr_a, fZr_b); 
        }
    }

    return 0;
}

int fnRainrateToDbz(float** data, int nYDim, int nXDim, float fOutBound_f, float fBadValue_f, float fZr_a, float fZr_b)
{
    int     nXidx    = 0;
    int     nYidx    = 0;

    if(data == NULL)
        return -1;

    for(nYidx = 0; nYidx < nYDim; nYidx++)
    {
        for(nXidx = 0; nXidx < nXDim; nXidx++)
        {
            if(data[nYidx][nXidx] <= 0 && data[nYidx][nXidx] != fOutBound_f && data[nYidx][nXidx] != fBadValue_f)
            {
                data[nYidx][nXidx] = fBadValue_f;
            }
            else if(data[nYidx][nXidx] != fOutBound_f && data[nYidx][nXidx] != fBadValue_f)
                data[nYidx][nXidx] = (float)fnR_to_dBZ_f((double)data[nYidx][nXidx], fZr_a, fZr_b); 
        }
    }

    return 0;
}

double fnDbz_To_R_f(double dDbz,float fZr_a,float fZr_b)
{
    return (pow(pow(10.,(double)(dDbz/10.))/fZr_a, 1/fZr_b));
}

double fnR_to_dBZ_f(double fRain, float fZr_a, float fZr_b)
{
    return (10*log10(fZr_a) + (fZr_b*10)*log10(fRain));
}

struct tm fnGetIncYear(struct tm tm_ptr, int nAddYear)
{
    struct  tm new_tm_ptr;
    time_t  tTime           = 0;
    int     nNewYear        = 0;
    int     nMonth          = 0;
    int     nDay            = 0;

    nMonth = tm_ptr.tm_mon+1;
    nDay   = tm_ptr.tm_mday;

    new_tm_ptr = tm_ptr;

    new_tm_ptr.tm_year += nAddYear;

    if(nMonth == 2 && nDay == 29)
    {
        nNewYear = new_tm_ptr.tm_year+1900;
        if(fnChkLeapYear(nNewYear) == 0)
        {
            new_tm_ptr.tm_mday = 28;
        }
    }

    tTime = mktime(&new_tm_ptr);
    localtime_r(&tTime, &new_tm_ptr);

    return new_tm_ptr;
}

struct tm fnGetIncMonth(struct tm tm_ptr, int nAddMonth)
{
    struct  tm new_tm_ptr;
    int     nMonth          = 0;
    int     nTempMonth      = 0;
    int     nDay            = 0;
    int     nTempDay        = 0;
    int     nMonthChgCnt    = 0;
    int     nSign           = 0;
    int     nIsFirst        = 0;

    if(nAddMonth < 0)
        nSign = -1;
    else if(nAddMonth > 0)
        nSign = 1;
    else
        return tm_ptr;

    nMonth = tm_ptr.tm_mon+1;
    nDay   = tm_ptr.tm_mday;

    new_tm_ptr = tm_ptr;

    while(1)
    {
        new_tm_ptr = fnGetIncDay(new_tm_ptr, nSign);
        nTempMonth = new_tm_ptr.tm_mon+1;
        if(nMonth != nTempMonth)
        {
            nMonthChgCnt++;
            nMonth = nTempMonth;
            if(nMonthChgCnt == abs(nAddMonth))
                break;
        }
    }

    while(1)
    {
        if(nSign > 0)
        {
            nTempDay = new_tm_ptr.tm_mday;
            if(nDay == nTempDay)
                break;

            nTempMonth = new_tm_ptr.tm_mon+1;
            if(nMonth != nTempMonth)
            {
                new_tm_ptr = fnGetIncDay(new_tm_ptr, -1);
                break;
            }
            new_tm_ptr = fnGetIncDay(new_tm_ptr, -1);
        }
        else
        {
            nTempDay = new_tm_ptr.tm_mday;
            if(nIsFirst == 1)
            {
                nIsFirst = 0;
                if(nDay >= nTempDay)
                    break;

            }

            if(nDay == nTempDay)
                break;

            new_tm_ptr = fnGetIncDay(new_tm_ptr, -1);
        }
    }

    return new_tm_ptr;
}

struct tm fnGetIncDay(struct tm tm_ptr, int nAddDay)
{   
    time_t tTime    = 0;
    struct tm new_tm_ptr;

    tTime = mktime(&tm_ptr);
    tTime = tTime + (60 * 60 * 24 * nAddDay);
    memset(&new_tm_ptr, 0x00, sizeof(struct tm));
    localtime_r(&tTime, &new_tm_ptr);

    return new_tm_ptr;
}

struct tm fnGetIncMin(struct tm tm_ptr, int nAddMin)
{   
    time_t tTime    = 0;
    struct tm new_tm_ptr;

    tTime = mktime(&tm_ptr);
    tTime = tTime + (60 * nAddMin);
    memset(&new_tm_ptr, 0x00, sizeof(struct tm));
    localtime_r(&tTime, &new_tm_ptr);

    return new_tm_ptr;
}

int fnChkLeapYear(int nYear)
{
    if(((nYear % 4 == 0) && ( nYear % 100 != 0)) || (nYear % 400 == 0)) 
        return 1;
    else
        return 0;
}

int fnGetLastDay(int nYear, int nMon)
{
    int nYearIdx = 0;

    int rgnDay[2][12] = 
    {
        { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 },
        { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }
    };

    if(nYear < 1 || nMon < 1 || nMon > 12)
        return 0;

    if(fnChkLeapYear(nYear) == 1)
    {
        nYearIdx = 1;
    }
    else
    {
        nYearIdx = 0;
    }

    return rgnDay[nYearIdx][nMon];
}

void fnSwap2bytes(void *pWord)
{
    unsigned char *pByte = NULL; //VARIABLE
    unsigned char cTemp  = 0;    //VARIABLE

    pByte    = pWord;
    cTemp    = pByte[0];
    pByte[0] = pByte[1];
    pByte[1] = cTemp;
}


void fnDumpDisp(void)
{
    gdImagePtr  pImg;
    int         nTransparent    = 0;

    pImg = gdImageCreateTrueColor(1000, 1000);
    gdImageAlphaBlending(pImg, 0);
    gdImageSaveAlpha(pImg, 1);
    nTransparent = gdImageColorAllocateAlpha(pImg, 0, 0, 0, 127);

    gdImageFilledRectangle(pImg, 0, 0, 1000, 1000, nTransparent);

    fprintf(stdout, "Content-type: image/png\r\n\r\n");
    gdImagePng(pImg,stdout);
    gdImageDestroy(pImg);
}

/* ================================================================================ */



