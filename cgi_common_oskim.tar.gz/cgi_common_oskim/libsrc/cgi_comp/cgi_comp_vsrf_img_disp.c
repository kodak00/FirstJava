/* ================================================================================ */
//
// VSRF, MAPLE. KONOS IMG 
// 
// 2016.09
//
// SnK
//
/* ================================================================================ */
// INCLUDE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gd.h>
#include <sys/time.h>

#include <pthread.h>

#include "cgi_comp_value.h"
#include "cgi_cmm_color.h"
#include "cgi_cmm_util.h"
#include "cgi_comp_origin_data_process.h"
#include "cgi_comp_img_data_process.h"
#include "cgi_comp_echo_disp.h"
#include "cgi_comp_extra_disp.h"
#include "cgi_comp_vsrf_img_disp.h"

/* ================================================================================ */
// LOCAL FUNTION

static void fnDrawline(double dStart_x, double dStart_y, double dEnd_x, double dEnd_y, float dContour, float rgfContours[], int fgnContours_line_color[], int nIsGuide, gdImagePtr pImg)
{
    if(nIsGuide == 1)
    {
        gdImageLine(pImg, dStart_x, dStart_y, dEnd_x,  dEnd_y, gdBrushed);
    }
    else
    {
        if(rgfContours[1] > dContour)
            gdImageLine(pImg, dStart_x,  dStart_y, dEnd_x,  dEnd_y, fgnContours_line_color[1]);
        else if(rgfContours[1] <= dContour && rgfContours[2] > dContour)
            gdImageLine(pImg, dStart_x,  dStart_y, dEnd_x,  dEnd_y, fgnContours_line_color[2]);
        else if(rgfContours[2] <= dContour && rgfContours[3] > dContour)
            gdImageLine(pImg, dStart_x,  dStart_y, dEnd_x,  dEnd_y, fgnContours_line_color[3]);
        else if(rgfContours[3] <= dContour && rgfContours[4] > dContour)
            gdImageLine(pImg, dStart_x,  dStart_y, dEnd_x,  dEnd_y, fgnContours_line_color[4]);
        else if(rgfContours[4] <= dContour && rgfContours[5] > dContour)
            gdImageLine(pImg, dStart_x,  dStart_y, dEnd_x,  dEnd_y, fgnContours_line_color[5]);
    }
}

static void CONREC(float **pImgData, int nIlb, int nIub, int nJib, int nJub, float *pXaxis, float *pYaxis, int nCnt, float *rgfContours, int rgnContours_line_color[], gdImagePtr pImg, int nIsGuide)
{
#define XSECT(p1,p2) (rgfHvalue[p2]*rgfXh[p1]-rgfHvalue[p1]*rgfXh[p2])/(rgfHvalue[p2]-rgfHvalue[p1])
#define YSECT(p1,p2) (rgfHvalue[p2]*rgfYh[p1]-rgfHvalue[p1]*rgfYh[p2])/(rgfHvalue[p2]-rgfHvalue[p1])

    int     nM1             = 0;  
    int     nM2             = 0; 
    int     nM3             = 0; 
    int     nCase_value     = 0; 
    float   fMin            = 0.0;
    float   fMax            = 0.0;   
    float   fX1             = 0.0;
    float   fX2             = 0.0;
    float   fY1             = 0.0;
    float   fY2             = 0.0;
    int     nXIdx           = 0;
    int     nYIdx           = 0;
    int     nKIdx           = 0;
    int     nMIdx           = 0;
    float   rgfHvalue[5]    = { 0.0, };
    int     rgnSh[5]        = { 0, };
    float   rgfXh[5]        = { 0.0, };
    float   rgfYh[5]        = { 0.0, };
    int     rgnIm[4]        = {0,1,1,0};
    int     rgnJm[4]        ={0,0,1,1};
    float   fTemp1          = 0.0;
    float   fTemp2          = 0.0;
    int     rgnCastab[3][3][3] = {
                { {0,0,8},{0,2,5},{7,6,9} },
                { {0,3,4},{1,3,1},{4,3,0} },
                { {9,6,7},{5,2,0},{8,0,0} }
            };


    for(nYIdx=(nJub-1); nYIdx>=nJib; nYIdx--)
    {
        for(nXIdx = nIlb; nXIdx <= nIub-1; nXIdx++)
        {
            fTemp1 = MIN(pImgData[nYIdx][nXIdx], pImgData[nYIdx+1][nXIdx]);
            fTemp2 = MIN(pImgData[nYIdx][nXIdx+1], pImgData[nYIdx+1][nXIdx+1]);
            fMin  = MIN(fTemp1, fTemp2);
            fTemp1 = MAX(pImgData[nYIdx][nXIdx], pImgData[nYIdx+1][nXIdx]);
            fTemp2 = MAX(pImgData[nYIdx][nXIdx+1], pImgData[nYIdx+1][nXIdx+1]);
            fMax  = MAX(fTemp1, fTemp2);
            if(fMax < rgfContours[0] || fMin > rgfContours[nCnt-1])
                continue;
            for(nKIdx=0; nKIdx<nCnt; nKIdx++)
            {
                if(rgfContours[nKIdx] < fMin || rgfContours[nKIdx] > fMax)
                    continue;
                for(nMIdx=4; nMIdx>=0; nMIdx--)
                {
                    if(nMIdx > 0)
                    {
                        rgfHvalue[nMIdx]  = pImgData[nYIdx+rgnJm[nMIdx-1]][nXIdx+rgnIm[nMIdx-1]]-rgfContours[nKIdx];
                        rgfXh[nMIdx] = pXaxis[nXIdx+rgnIm[nMIdx-1]];
                        rgfYh[nMIdx] = pYaxis[nYIdx+rgnJm[nMIdx-1]];
                    }
                    else
                    {
                        rgfHvalue[0]  = 0.25 * (rgfHvalue[1]+rgfHvalue[2]+rgfHvalue[3]+rgfHvalue[4]);
                        rgfXh[0] = 0.50 * (pXaxis[nXIdx]+pXaxis[nXIdx+1]);
                        rgfYh[0] = 0.50 * (pYaxis[nYIdx]+pYaxis[nYIdx+1]);
                    }
                    if(rgfHvalue[nMIdx] > 0.0)
                        rgnSh[nMIdx] = 1;
                    else if(rgfHvalue[nMIdx] < 0.0)
                        rgnSh[nMIdx] = -1;
                    else
                        rgnSh[nMIdx] = 0;
                }

                for(nMIdx=1; nMIdx<=4; nMIdx++)
                {
                    nM1 = nMIdx;
                    nM2 = 0;
                    if(nMIdx != 4)
                        nM3 = nMIdx + 1;
                    else
                        nM3 = 1;
                    if((nCase_value = rgnCastab[rgnSh[nM1]+1][rgnSh[nM2]+1][rgnSh[nM3]+1]) == 0)
                        continue;
                    switch(nCase_value)
                    {
                        case 1:
                            fX1 = rgfXh[nM1];
                            fY1 = rgfYh[nM1];
                            fX2 = rgfXh[nM2];
                            fY2 = rgfYh[nM2];
                            break;
                        case 2:
                            fX1 = rgfXh[nM2];
                            fY1 = rgfYh[nM2];
                            fY2 = rgfYh[nM3];
                            break;
                        case 3:
                            fX1 = rgfXh[nM3];
                            fY1 = rgfYh[nM3];
                            fX2 = rgfXh[nM1];
                            fY2 = rgfYh[nM1];
                            break;
                        case 4:
                            fX1 = rgfXh[nM1];
                            fY1 = rgfYh[nM1];
                            fX2 = XSECT(nM2,nM3);
                            fY2 = YSECT(nM2,nM3);
                            break;
                        case 5:
                            fX1 = rgfXh[nM2];
                            fY1 = rgfYh[nM2];
                            fX2 = XSECT(nM3,nM1);
                            fY2 = YSECT(nM3,nM1);
                            break;
                        case 6:
                            fX1 = rgfXh[nM1];
                            fY1 = rgfYh[nM1];
                            fX2 = XSECT(nM1,nM2);
                            fY2 = YSECT(nM1,nM2);
                            break;
                        case 7:
                            fX1 = XSECT(nM1,nM2);
                            fY1 = YSECT(nM1,nM2);
                            fX2 = XSECT(nM2,nM3);
                            fY2 = YSECT(nM2,nM3);
                            break;
                        case 8:
                            fX1 = XSECT(nM2,nM3);
                            fY1 = YSECT(nM2,nM3);
                            fX2 = XSECT(nM3,nM1);
                            fY2 = YSECT(nM3,nM1);
                            break;
                        case 9:
                            fX1 = XSECT(nM3,nM1);
                            fY1 = YSECT(nM3,nM1);
                            fX2 = XSECT(nM1,nM2);
                            fY2 = YSECT(nM1,nM2);
                            break;
                        default:
                            break;
                    }

                    fnDrawline(fX1, fY1, fX2, fY2, rgfContours[nKIdx], rgfContours, rgnContours_line_color, nIsGuide, pImg);
                }
            }
        }
    }
}


static int fnCreateTitanImg(float** pImgData, char szP_type[], int nImgXdim, int nImgYdim, char szUnit[])
{
#define TITAN_FREE() \
    free(pColor_ini); \
    gdImageDestroy(pImgTitan);

    gdImagePtr      pImgTitan                                   = NULL;   
    int             nTransparentTitan                           = 0;        
    int             titanEchoColorBar[CGI_DF_COLOR_MAX]         = { 0, };  
    int             titanDispColorBar[CGI_EN_DISP_COLOR_MAX]    = { 0, }; 
    CGI_COLOR_TBL*  pColor_ini                                  = NULL;   

    if(pImgData == NULL)
    {
        return -1;
    }

    pImgTitan          = gdImageCreateTrueColor(nImgXdim, nImgYdim);
    gdImageAlphaBlending(pImgTitan, 0);
    gdImageSaveAlpha(pImgTitan, 1);
    nTransparentTitan  = gdTrueColorAlpha(255, 255, 255, 127);

    pColor_ini = fnReadColorTable(CGI_DF_RN_COLOR_FILE);
    fnAllocColorTbl(pImgTitan, pColor_ini, titanEchoColorBar, titanDispColorBar);
    gdImageFilledRectangle(pImgTitan, 0, 0, nImgXdim, nImgYdim, nTransparentTitan);

    if(fnCompTitanDisp(nImgXdim, nImgYdim, szUnit, pImgData, pImgTitan, titanEchoColorBar, pColor_ini) < 0)
    {
        TITAN_FREE()
        return -1;
    }

    fprintf(stdout, "Content-type: image/png\r\n\r\n");
    gdImagePng(pImgTitan, stdout);
    fflush(stdout);

    TITAN_FREE()
    return 0;
}

static int fnCreateNoTitanImg(float** pImgData, char szP_type[], int nImgXdim, int nImgYdim, char szDate[], char szUnit[], char szForecastDate[])
{
#define NO_TITAN_FREE() \
    free(pColor_ini); \
    gdImageDestroy(pImg);

    gdImagePtr      pImg                                 = NULL;    
    int             nTransparent                         = 0;    
    int             echoColorBar[CGI_DF_COLOR_MAX]       = { 0, };  
    int             dispColorBar[CGI_EN_DISP_COLOR_MAX]  = { 0, };  
    CGI_COLOR_TBL*  pColor_ini                           = NULL;

    if(pImgData == NULL)
    {
        return -1;
    }

    pImg = gdImageCreateTrueColor(nImgXdim, nImgYdim);
    gdImageAlphaBlending(pImg, 0);
    gdImageSaveAlpha(pImg, 1);
    nTransparent  = gdTrueColorAlpha(255, 255, 255, 127);
    
    pColor_ini = fnReadColorTable(CGI_DF_RN_COLOR_FILE);
    fnAllocColorTbl(pImg, pColor_ini, echoColorBar, dispColorBar);
    gdImageFilledRectangle(pImg, 0, 0, nImgXdim, nImgYdim, nTransparent);
    
    if(fnCompEchoDisp(nImgXdim, nImgYdim, szP_type, szUnit, pImgData, pImg, echoColorBar, pColor_ini) < 0)
    {
        NO_TITAN_FREE()
        return -1;
    }

    if(fnImgTopTextDisp(pImg, szP_type, "", szUnit, szDate, nImgXdim, 5, szForecastDate) < 0)
    {
        NO_TITAN_FREE()
        return -1;
    }

    if(fnVsrfMapleContentDisp(nImgXdim, nImgYdim, pImg, szDate, szForecastDate) < 0)
    {
        NO_TITAN_FREE()
        return -1;
    }

    fprintf(stdout, "Content-type: image/png\r\n\r\n");
    gdImagePng(pImg, stdout);
    fflush(stdout);

    NO_TITAN_FREE()
    return 0;
}

static int fnCreateContourImg(float** pImgData, char szP_type[], int nImgXdim, int nImgYdim, char szDate[], int nIsGuide, char szUnit[], char szForecastDate[])
{
#define CONTOUR_FREE() \
    free(pColor_ini); \
    gdImageDestroy(pImg);

    int             nTransparent                         = 0;       
    int             echoColorBar[CGI_DF_COLOR_MAX]       = { 0, };  
    int             dispColorBar[CGI_EN_DISP_COLOR_MAX]  = { 0, };  
    float           *pXaxis                              = NULL;   
    float           *pYaxis                              = NULL;   
    int             nSum                                 = 0.0;    
    float           rgfContours[CONTOUR_CNT]             = { 0.0, };
    int             rgnContours_line_color[CONTOUR_CNT]  = { 0, }; 
    int             nSmoothXIdx                          = 0;   
    int             nSmoothYIdx                          = 0;       
    int             nCnt                                 = 0;     
    int             nXIdx                                = 0;      
    int             nYIdx                                = 0;     
    gdImagePtr      pImg                                 = NULL;   
    CGI_COLOR_TBL*  pColor_ini                           = NULL;  

    if(pImgData == NULL)
    {
        return -1;
    }

    pImg = gdImageCreateTrueColor(nImgXdim, nImgYdim);
    gdImageAlphaBlending(pImg, 0);
    gdImageSaveAlpha(pImg, 1);
    nTransparent  = gdTrueColorAlpha(255, 255, 255, 127);

    pColor_ini = fnReadColorTable(CGI_DF_RN_COLOR_FILE);
    fnAllocColorTbl(pImg, pColor_ini, echoColorBar, dispColorBar);
    gdImageFilledRectangle(pImg, 0, 0, nImgXdim, nImgYdim, nTransparent);

    if((pXaxis = (float *)calloc(nImgXdim, sizeof(float))) == NULL)
    {
        CONTOUR_FREE()
        return -1;
    }

    if((pYaxis = (float *)calloc(nImgYdim, sizeof(float))) == NULL)
    {
        fnFreeAxisDataFloat(pXaxis);
        CONTOUR_FREE()
        return -1;
    }

    for(nYIdx = 0; nYIdx < nImgYdim; nYIdx++)
    {
        for(nXIdx = 0; nXIdx < nImgXdim; nXIdx++)
        {
            nCnt = 0;
            nSum = 0;
            for(nSmoothYIdx =- CONTOUR_SMOOTH; nSmoothYIdx <= CONTOUR_SMOOTH; nSmoothYIdx++)
            {
                for(nSmoothXIdx =- CONTOUR_SMOOTH; nSmoothXIdx <= CONTOUR_SMOOTH; nSmoothXIdx++)
                {
                    if(nYIdx + nSmoothYIdx < 0 || nYIdx + nSmoothYIdx >= nImgYdim)
                        continue;

                    if(nXIdx + nSmoothXIdx < 0 || nXIdx + nSmoothXIdx >= nImgXdim)
                        continue;

                    nSum += pImgData[nYIdx + nSmoothYIdx][nXIdx + nSmoothXIdx];
                    nCnt++;
                }
            }
            
            if(nCnt > 0)
                pImgData[nYIdx][nXIdx] = (float)(nSum / nCnt);
        }
    }

    for(nXIdx = 0; nXIdx < nImgXdim; nXIdx++)
        pXaxis[nXIdx] = nXIdx;

    for(nXIdx = 0; nXIdx < nImgYdim; nXIdx++)
        pYaxis[nXIdx] = nXIdx;

    rgfContours[0] = -7000.0f;
    rgnContours_line_color[0] = gdImageColorAllocate(pImg, 0, 0, 0);

    rgfContours[1] = 100.0f;
    rgnContours_line_color[1] = gdImageColorAllocate(pImg, 0, 119, 179);

    rgfContours[2] = 500.0f;
    rgnContours_line_color[2] = gdImageColorAllocate(pImg, 0, 128, 0);

    rgfContours[3] = 1200.0f;
    rgnContours_line_color[3] = gdImageColorAllocate(pImg, 255, 156, 0);

    rgfContours[4] = 5000.0f;
    rgnContours_line_color[4] = gdImageColorAllocate(pImg, 179, 0, 0);

    rgfContours[5] = 10000.0f;
    rgnContours_line_color[5] = gdImageColorAllocate(pImg, 127, 0, 191);

    CONREC((float **)pImgData, 0, nImgXdim - 1, 0, nImgYdim - 1,
            pXaxis, pYaxis, CONTOUR_CNT, rgfContours, rgnContours_line_color, pImg, nIsGuide);

    if(fnImgTopTextDisp(pImg, szP_type, "", szUnit, szDate, nImgXdim, 5, szForecastDate) < 0)
    {
        CONTOUR_FREE()
        return -1;
    }

    fnVsrfMapleContentDisp(nImgXdim, nImgYdim, pImg, szDate, szForecastDate);

    fprintf(stdout, "Content-type: image/png\r\n\r\n");
    gdImagePng(pImg, stdout);
    fflush(stdout);

    fnFreeAxisDataFloat(pXaxis);
    fnFreeAxisDataFloat(pYaxis);
    CONTOUR_FREE()
    return 0;
}

static void* fnGuideDataReadThread(void *arg)
{
    GUIDE_THR_ARG   *pArg   = (GUIDE_THR_ARG *)arg;

    if((strcmp(pArg->m_szP_type, "MAPLE") == 0) || 
       (strcmp(pArg->m_szP_type, "KONOS") == 0)) 
    {
        pArg->m_ppGuidData = fnGetCompMapleData(pArg->m_szFileName, 
                                                pArg->m_nCompXdim,
                                                pArg->m_nCompYdim,
                                                pArg->m_nFcstTime);
    }
    else
    {
        pArg->m_ppGuidData = fnGetCompVsrfData(pArg->m_szFileName,
                                                pArg->m_nCompXdim,
                                                pArg->m_nCompYdim,
                                                pArg->m_nFcstTime);
    }

    return (void *)0;
}

static int fnCreateForeGuideImg(float** pImgData, char szP_type[], int nImgXdim, int nImgYdim, char szF_name[], int nCompXdim, int nCompYdim, float fLU_lon, float fLU_lat, float fXDist, float fYDist, float fCompGridKm, char szDate[], int nIsGuide, char szUnit[], char szForecastDate[])
{
#define FOREGUIDE_FREE() \
        free(pColor_ini); \
        gdImageDestroy(pImg); \
        gdImageDestroy(pBrush); \
        if(thrArg[0].m_ppGuidData != NULL) { fnFreeMatrixFloat(thrArg[0].m_ppGuidData, nCompYdim); } \
        if(thrArg[1].m_ppGuidData != NULL) { fnFreeMatrixFloat(thrArg[1].m_ppGuidData, nCompYdim); } \
        if(thrArg[2].m_ppGuidData != NULL) { fnFreeMatrixFloat(thrArg[2].m_ppGuidData, nCompYdim); } \

    int             nTransparent                         = 0;       
    int             echoColorBar[CGI_DF_COLOR_MAX]       = { 0, };  
    int             dispColorBar[CGI_EN_DISP_COLOR_MAX]  = { 0, };  
    float           *pXaxis                              = NULL;    
    float           *pYaxis                              = NULL;    
    int             nSum                                 = 0.0;     
    float           fContourValue                        = 0.0;     
    int             rgnContours_line_color[CONTOUR_CNT]  = { 0, };  
    int             nSmoothXIdx                          = 0;       
    int             nSmoothYIdx                          = 0;       
    int             nCnt                                 = 0;       
    int             nXIdx                                = 0;       
    int             nYIdx                                = 0;       
    int             nBrush_size                          = 2;       
    int             nBrushColor                          = 0;       
    int             nTimes                               = 0;       
    float           **pCompData                          = NULL;
    gdImagePtr      pBrush                               = NULL;    
    gdImagePtr      pImg                                 = NULL;    
    CGI_COLOR_TBL*  pColor_ini                           = NULL;    

    pthread_t       dataThr[3]                          = { -1, -1, -1 };
    GUIDE_THR_ARG   thrArg[3];

    pImg = gdImageCreateTrueColor(nImgXdim, nImgYdim);
    gdImageAlphaBlending(pImg, 0);
    gdImageSaveAlpha(pImg, 1);
    nTransparent  = gdTrueColorAlpha(255, 255, 255, 127);

    pBrush = gdImageCreate(nBrush_size, nBrush_size);

    pColor_ini = fnReadColorTable(CGI_DF_RN_COLOR_FILE);
    fnAllocColorTbl(pImg, pColor_ini, echoColorBar, dispColorBar);
    gdImageFilledRectangle(pImg, 0, 0, nImgXdim, nImgYdim, nTransparent);

    if((pXaxis = (float *)calloc(nImgXdim, sizeof(float))) == NULL)
    {
        FOREGUIDE_FREE()
        return -1;
    }

    if((pYaxis = (float *)calloc(nImgYdim, sizeof(float))) == NULL)
    {
        fnFreeAxisDataFloat(pXaxis);
        FOREGUIDE_FREE()
        return -1;
    } 

    for(nTimes = 0; nTimes < 3; nTimes++)
    {
        snprintf(thrArg[nTimes].m_szP_type,   sizeof(thrArg[nTimes].m_szP_type),   "%s", szP_type);
        snprintf(thrArg[nTimes].m_szFileName, sizeof(thrArg[nTimes].m_szFileName), "%s", szF_name);
        thrArg[nTimes].m_nCompXdim = nCompXdim;
        thrArg[nTimes].m_nCompYdim = nCompYdim;
        thrArg[nTimes].m_nFcstTime = (nTimes*3)*60;
        thrArg[nTimes].m_ppGuidData = NULL;
        
        pthread_create(&dataThr[nTimes], NULL, fnGuideDataReadThread, (void*)&thrArg[nTimes]);
    }

    for(nTimes = 0; nTimes < 3; nTimes++)
    {
        pthread_join(dataThr[nTimes], NULL);

        pCompData = thrArg[nTimes].m_ppGuidData;
        if(pCompData == NULL)
        {
            fnNoCompDataDisp(nImgXdim, nImgYdim);
            fnFreeAxisDataFloat(pXaxis);
            fnFreeAxisDataFloat(pYaxis);
            FOREGUIDE_FREE()
            return -1;
        }

        if((pImgData = fnMakeCompVsrfConGuideImgData(pImgData, pCompData, nImgXdim,
                        nImgYdim, fLU_lon, fLU_lat, fXDist, fYDist, nCompXdim, nCompYdim, fCompGridKm)) == NULL)
        {
            fnFreeAxisDataFloat(pXaxis);
            fnFreeAxisDataFloat(pYaxis);
            FOREGUIDE_FREE()
            return -1;
        }

        for(nYIdx = 0; nYIdx < nImgYdim; nYIdx++)
        {
            for(nXIdx = 0; nXIdx < nImgXdim; nXIdx++)
            {
                nCnt = 0;
                nSum = 0;
                for(nSmoothYIdx =- GUIDE_SMOOTH; nSmoothYIdx <= GUIDE_SMOOTH; nSmoothYIdx++)
                {
                    for(nSmoothXIdx =- GUIDE_SMOOTH; nSmoothXIdx <= GUIDE_SMOOTH; nSmoothXIdx++)
                    {
                        if(nYIdx + nSmoothYIdx < 0 || nYIdx + nSmoothYIdx >= nImgYdim)
                            continue;

                        if(nXIdx + nSmoothXIdx < 0 || nXIdx + nSmoothXIdx >= nImgXdim)
                            continue;

                        nSum += pImgData[nYIdx + nSmoothYIdx][nXIdx + nSmoothXIdx];
                        nCnt++;
                    }
                }

                if(nCnt > 0)
                    pImgData[nYIdx][nXIdx] = (float)(nSum / nCnt);
            }
        }

        for(nXIdx = 0; nXIdx < nImgXdim; nXIdx++)
            pXaxis[nXIdx] = nXIdx;

        for(nXIdx = 0; nXIdx < nImgYdim; nXIdx++)
            pYaxis[nXIdx] = nXIdx;

        if(nTimes * 3 == 0)
        {
            fContourValue = -7000.0f;

            nBrushColor = gdImageColorAllocate(pBrush, 255, 0, 0);
            gdImageFilledRectangle(pBrush, 0, 0, nBrush_size, nBrush_size, nBrushColor);

            gdImageSetBrush(pImg, pBrush);
        }
        else if(nTimes * 3 == 3)
        {
            fContourValue = -7000.0f;

            nBrushColor = gdImageColorAllocate(pBrush, 0, 255, 0);
            gdImageFilledRectangle(pBrush, 0, 0, nBrush_size, nBrush_size, nBrushColor);

            gdImageSetBrush(pImg, pBrush);
        }
        else if(nTimes * 3 == 6)
        {
            fContourValue = -7000.0f;

            nBrushColor = gdImageColorAllocate(pBrush, 0, 0, 255);
            gdImageFilledRectangle(pBrush, 0, 0, nBrush_size, nBrush_size, nBrushColor);

            gdImageSetBrush(pImg, pBrush);
        }

        CONREC((float **)pImgData, 0, nImgXdim - 1, 0, nImgYdim - 1,
                pXaxis, pYaxis, 1, &fContourValue, rgnContours_line_color, pImg, nIsGuide);
    
        fnFreeMatrixFloat(pImgData, nImgYdim);
    }

    if(fnImgTopTextDisp(pImg, szP_type, "", szUnit, szDate, nImgXdim, 5, szForecastDate) < 0)
    {
        FOREGUIDE_FREE()
        return -1;
    }

    fnVsrfMapleContentDisp(nImgXdim, nImgYdim, pImg, szDate, szForecastDate);

    fprintf(stdout, "Content-type: image/png\r\n\r\n");
    gdImagePng(pImg, stdout);
    fflush(stdout);

    fnFreeAxisDataFloat(pXaxis);
    fnFreeAxisDataFloat(pYaxis);
    FOREGUIDE_FREE()
    return 0;
}

/* ================================================================================ */
// FUNCTION

int fnCreateCompVsrfImg(float** pImgData, char szP_type[], int nImgXdim, int nImgYdim, char szUnit[], int nTitan, int nContour, int nForeGuide, char szF_name[], int nCompXdim, int nCompYdim, float fLU_lon, float fLU_lat, float fXDist, float fYDist, int nSmooth, float fCompGridKm, char szDate[], char szForecastDate[])
{
    int isGuide = 0;

    if(nTitan == 1)
    {
        if(fnCreateTitanImg(pImgData, szP_type, nImgXdim, nImgYdim, szUnit) < 0)
        {
            return -1;
        }
    }
    else
    {
        if(nContour == 1)
        {
            if(fnCreateContourImg(pImgData, szP_type, nImgXdim, nImgYdim, szDate, isGuide, szUnit, szForecastDate) < 0)
            {
                return -1;
            }
        }
        else if(nForeGuide == 1)
        {
            isGuide = nForeGuide;
            if(fnCreateForeGuideImg(pImgData, szP_type, nImgXdim, nImgYdim, szF_name, nCompXdim, nCompYdim, 
                                    fLU_lon, fLU_lat, fXDist, fYDist, fCompGridKm, szDate, 
                                    isGuide, szUnit, szForecastDate) < 0)
            {
                return -1;
            }
        }
        else
        {
            if(fnCreateNoTitanImg(pImgData, szP_type, nImgXdim, nImgYdim, szDate, szUnit, szForecastDate) < 0)
            {
                return -1;
            } 
        }
    }
    return 0;
}

/* ================================================================================ */



