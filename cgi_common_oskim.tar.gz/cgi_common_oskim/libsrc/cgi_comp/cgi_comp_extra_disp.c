/* ================================================================================ */
//
// 레이더 에코 영상 GIS - comp_extra_disp.c (합성 영상 기타 기능)   
//
// 2016.08.28
//
// SnK
//
/* ================================================================================ */
// INCLUDE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "gd.h"
#include "gdfonts.h"

#include "cgi_comp_value.h"
#include "cgi_cmm_util.h"
#include "cgi_cmm_color.h"
#include "cgi_cmm_map_ini.h"
#include "cgi_comp_calc.h"
#include "cgi_comp_img_data_process.h"
#include "cgi_comp_extra_disp.h"

char *strptime(const char *s, const char *format, struct tm *tm);
/* ================================================================================ */
// LOCAL FUNTION

static int fnNoDataDisp(int nImgXdim, int nImgYdim, gdImagePtr pImg)
{
    int           rgnBrect[BRECT_SIZE]  = { 0, };   
    char*         szErr                 = NULL;     
    double        dSize                 = 16.;      
    char          szFont[FONT_SIZE]     = { 0, };   
    char          szText[TEXT_SIZE]     = { 0, };   
    int           nText_start_x         = 0;        
    int           nText_start_y         = 0;        
    int           nBlack                = 0;

    if(pImg == NULL)
    { 
        return -1;
    }

    nText_start_x = (nImgXdim/2) - 170;
    nText_start_y = (nImgYdim/2) + 0.5;

    nBlack         = gdImageColorAllocate(pImg, 0, 0, 0);
    sprintf(szFont, "%s/NanumGothic.ttf", FONT_PATH); 
    sprintf(szText, " %s","선택된 시각의 레이더자료가 없습니다.");

    szErr = gdImageStringFT(pImg, &rgnBrect[0], nBlack, szFont, dSize, 0.0, nText_start_x, nText_start_y, szText);
    if(szErr)
    {
        return -1; 
    }

    return 0;
}

/* ================================================================================ */
// FUNCTION

int fnMapLineDisp(int nImgYdim, gdImagePtr pImg, int nMap_color, float fXo, float fYo, int nMoveX, int nMoveY, float fZm)
{
    FILE    *pfp                    = NULL;      
    char    szFname[FILE_SIZE]      = { 0, };    
    float   fNum                    = 0.0;       
    float   fCode                   = 0.0;       
    float   rgfTmp[MAP_TEMP_SIZE]   = { 0.0, };  
    float   rgfBuf[MAP_BUF_SIZE]    = { 0.0, };  
    int     nTemp_I                 = 0;         
    int     nIx_start               = 0;         
    int     nIx_finish              = 0;         
    int     nIy_start               = 0;         
    int     nIy_finish              = 0;         

    if(pImg == NULL)
    { 
        return -1;
    }

    sprintf(szFname, "%s", MAP_LINE_FILE);

    if((pfp = fopen(szFname, "rb")) != NULL )
    {
        while(fread(rgfTmp, sizeof(float), 2, pfp) > 0)
        {
            fNum  = rgfTmp[0];
            fCode = rgfTmp[1];
            fread(rgfBuf, sizeof(float), 2, pfp);
            
            nIx_start = (int)( fZm * (rgfBuf[0] - fXo) + nMoveX);
            nIy_start = (int)(nImgYdim - (fZm * (rgfBuf[1] + fYo)) - nMoveY);

            for(nTemp_I=1; nTemp_I<fNum; nTemp_I++)
            {
                fread(rgfBuf, sizeof(float), 2, pfp);

                nIx_finish = (int)(fZm * (rgfBuf[0] - fXo) + nMoveX);
                nIy_finish = (int)(nImgYdim - (fZm * (rgfBuf[1] + fYo)) - nMoveY);
            
                if(fCode == 0 || fCode == 1 || fCode == 6 || fCode == 7 || fCode == 8)
                {
                    gdImageLine(pImg, nIx_start, nIy_start, nIx_finish, nIy_finish, nMap_color);
                }

                if(fCode == 2 || fCode == 5)
                {
                    gdImageLine(pImg, nIx_start, nIy_start, nIx_finish, nIy_finish, nMap_color);
                }

                nIx_start = nIx_finish;
                nIy_start = nIy_finish;
            }
        }
        fclose(pfp);
    }

    return 0;
}

int fnMapLevelColorDisp(int nImgXdim, int nImgYdim, char szP_type[], char szUnit[], gdImagePtr pImg, int rgnColor[], CGI_COLOR_TBL* pColor_ini)
{
    char    szText[TEXT_SIZE]  = { 0, };  
    float   fDy                = 0.0;     
    float   fRain              = 0.0;     
    int     nTemp_I            = 0;       
    int     nTemp_J            = 0;       
    int     nCnt               = 0;       
    int     nTable_start_x     = 0;       
    int     nTable_start_y     = 0;       
    int     nTable_finish_x    = 0;       
    int     nTable_finish_y    = 0;       
    char    szFont[FONT_SIZE]  = { 0, };  
    int     nX_pos             = 0;       
    int     nY_pos             = 0;       
    int     nWhite             = 0;       
    int     nBlack             = 0;       

    if((pImg == NULL) || (pColor_ini == NULL))
    {
        return -1;
    }

    gdImageAlphaBlending(pImg, 0);
    gdImageSaveAlpha(pImg, 1);
    nWhite  = gdImageColorAllocate(pImg, 255, 255, 255);
    nBlack  = gdImageColorAllocate(pImg,  51,  51,  51);

    gdImageFilledRectangle(pImg, nImgXdim, 0, nImgXdim + IMAGE_INDEX_RIGHT_SIZE, nImgYdim, nWhite); 

    sprintf(szFont, "%s/gulim.ttc", FONT_PATH); 

    nCnt = pColor_ini->m_iEchoColorCnt;
    
    nTable_start_x  = nImgXdim;
    nTable_finish_x = nImgXdim + 10;
    nTable_start_y  = 0;
    nTable_finish_y = nImgYdim + 4;

    fDy = (nTable_finish_y - nTable_start_y)/(nCnt + 0.5) + 0.2;

    for(nTemp_I=0; nTemp_I<nCnt; nTemp_I++)
    {
        gdImageFilledRectangle(pImg, nTable_start_x, nTable_start_y + fDy * nTemp_I, nTable_finish_x, nTable_start_y + fDy * (nTemp_I+1), rgnColor[nCnt-nTemp_I-1]);
    }

    gdImageRectangle(pImg, nTable_start_x, nTable_start_y, nTable_finish_x, nTable_start_y + fDy * nCnt -2, nBlack); 

    nTemp_I=0;
    for(nTemp_J=(nCnt-2); nTemp_J >= 0; nTemp_J--)
    {
        if((strcmp(szP_type, "ETOP") == 0) || (strcmp(szP_type, "VIL") == 0))
        {
            if((strcmp(szUnit, "RN") == 0))
            {
                fRain = pColor_ini->m_echoColorTbl[nTemp_J].m_fRain; 
            }
            else
            {
                fRain = pColor_ini->m_echoColorTbl[nTemp_J].m_fUnit; 
            }

            if(fRain < 10)
            {
                sprintf(szText, "%.1f", fRain);
            }
            else
            {
                sprintf(szText, "%.0f", fRain);
            }
        }
        else 
        {
            if((strcmp(szUnit, "CZ") == 0) || (strcmp(szUnit, "DZ") == 0))
            {
                fRain = pColor_ini->m_echoColorTbl[nTemp_J].m_fUnit;  
                sprintf(szText, "%.0f", fRain);
            }
            else if(strcmp(szUnit, "RN") == 0)
            {
                fRain = pColor_ini->m_echoColorTbl[nTemp_J].m_fRain;

                if(fRain < 10)
                {
                    sprintf(szText, "%.1f", fRain);
                }
                else
                {
                    sprintf(szText, "%.0f", fRain);
                }
            }
        }

        nX_pos = nTable_finish_x + 5;
        nY_pos = fDy * nTemp_I;
        nY_pos += fDy - gdFontGetSmall()->h/2;

        gdImageString(pImg, gdFontGetSmall(), nX_pos, nY_pos, (unsigned char *)szText, nBlack);

        nTemp_I++;
    }

    return 0;
}

int fnLevelColorDisp(int nImgYdim, char szP_type[], char szUnit[], gdImagePtr pImg, int rgnColor[], CGI_COLOR_TBL* pColor_ini)
{
    char    szText[TEXT_SIZE]       = { 0, };  
    char    szTitleUnit[TEXT_SIZE]  = { 0, };  
    int     rgnBrect[BRECT_SIZE]    = { 0, };  
    float   fDy                     = 0.0;     
    float   fRain                   = 0.0;     
    int     nTemp_I                 = 0;       
    int     nTemp_J                 = 0;       
    int     nCnt                    = 0;       
    int     nTable_start_x          = 0;       
    int     nTable_start_y          = 0;       
    int     nTable_finish_x         = 0;       
    int     nTable_finish_y         = 0;       
    char    szFont[FONT_SIZE]       = { 0, };  
    int     nX_pos                  = 0;       
    int     nY_pos                  = 0;       
    int     nWhite                  = 0;       
    int     nBlack                  = 0;       
    int     nTransparent            = 0;       
    
    if((pImg == NULL) || (pColor_ini == NULL))
    {
        return -1;
    }
    
    gdImageAlphaBlending(pImg, 0);
    gdImageSaveAlpha(pImg, 1);
    nWhite        = gdImageColorAllocate(pImg, 255, 255, 255);
    nBlack        = gdImageColorAllocate(pImg,  0,  0,  0);
    nTransparent  = gdTrueColorAlpha(255, 255, 255, 127);

    gdImageFilledRectangle(pImg, 0, 0, IMAGE_INDEX_RIGHT_SIZE, nImgYdim, nTransparent); 

    sprintf(szFont, "%s/gulim.ttc", FONT_PATH); 

    if(strcmp(szP_type, "ETOP") == 0)
    {
        sprintf(szTitleUnit, "%s", pColor_ini->m_szUnitTitle);
    }
    else if(strcmp(szP_type, "VIL") == 0)
    {
        sprintf(szTitleUnit, "%s", pColor_ini->m_szRainTitle);
    }
    else
    {
        if((strcmp(szUnit, "RN") == 0) || (strcmp(szUnit, "SN") == 0))
        {
            sprintf(szTitleUnit, "%s", pColor_ini->m_szRainTitle);
        }
        else if((strcmp(szUnit, "CZ") == 0))
        {
            sprintf(szTitleUnit, "%s", pColor_ini->m_szUnitTitle);
        }
    }

    gdImageStringFT(pImg, &rgnBrect[0], nWhite, szFont, 10, 0.0, 0, 20, szTitleUnit);

    nCnt = pColor_ini->m_iEchoColorCnt;
    
    nTable_start_x  = 0;
    nTable_finish_x = 10;
    nTable_start_y  = 30;
    nTable_finish_y = nImgYdim + 4;

    fDy = (nTable_finish_y - nTable_start_y)/(nCnt + 0.5) + 0.2;

    for(nTemp_I = 0; nTemp_I < nCnt; nTemp_I++)
    {
        gdImageFilledRectangle(pImg, nTable_start_x, nTable_start_y + fDy * nTemp_I, nTable_finish_x, nTable_start_y + fDy * (nTemp_I+1), rgnColor[nCnt-nTemp_I-1]);
    }

    if((strcmp(szUnit, "SN") == 0))
    {
        gdImageRectangle(pImg, nTable_start_x, nTable_start_y, nTable_finish_x, nTable_start_y + fDy * nCnt , nBlack); 
    }
    else
    {
        gdImageRectangle(pImg, nTable_start_x, nTable_start_y, nTable_finish_x, nTable_start_y + fDy * nCnt-2, nBlack); 
    }

    nTemp_I=0;
    for(nTemp_J=(nCnt-2); nTemp_J >= 0; nTemp_J--)
    {
        if((strcmp(szP_type, "ETOP") == 0) || (strcmp(szP_type, "VIL") == 0))
        {
            if((strcmp(szUnit, "RN") == 0))
            {
                fRain = pColor_ini->m_echoColorTbl[nTemp_J].m_fRain; 
            }
            else
            {
                fRain = pColor_ini->m_echoColorTbl[nTemp_J].m_fUnit; 
            }

            if(fRain < 10)
            {
                sprintf(szText, "%.1f", fRain);
            }
            else
            {
                sprintf(szText, "%.0f", fRain);
            }
        }
        else
        {
            if((strcmp(szUnit, "CZ") == 0) || (strcmp(szUnit, "DZ") == 0))
            {
                fRain = pColor_ini->m_echoColorTbl[nTemp_J].m_fUnit; 
                sprintf(szText, "%.0f", fRain);
            }
            else if((strcmp(szUnit, "RN") == 0) || (strcmp(szUnit, "SN") == 0))
            {
                fRain = pColor_ini->m_echoColorTbl[nTemp_J].m_fRain; 

                if(fRain < 10)
                {
                    sprintf(szText, "%.1f", fRain);
                }
                else
                {
                    sprintf(szText, "%.0f", fRain);
                }
            }
        }

        nX_pos = nTable_finish_x + 5;
        nY_pos = fDy * nTemp_I;
        nY_pos += fDy - gdFontGetSmall()->h/2;

        gdImageString(pImg, gdFontGetSmall(), nX_pos, nY_pos+30, (unsigned char *)szText, nWhite);

        nTemp_I++;
    }

    return 0;
}

int fnBoundDisp(int nImgXdim, int nImgYdim, float** pImgData, gdImagePtr pImg, float fOutBoundValue)
{
    int     nXIdx      = 0;       
    int     nYIdx      = 0;       
    float   fFval      = 0.0;     
    int     nGray      = 0;       
    
    nGray  = gdTrueColorAlpha(0, 0, 0, 100);

    if(pImg == NULL) 
    {
        return -1;
    }
    
    for(nYIdx = 0; nYIdx < nImgYdim; nYIdx++)
    {
        for(nXIdx = 0; nXIdx < nImgXdim; nXIdx++)
        {
            fFval = pImgData[nYIdx][nXIdx];
            
            if(fFval == fOutBoundValue) 
            {
                gdImageSetPixel(pImg, nXIdx, nYIdx, nGray);
            }
        }
    }
    return 0;
}

int fnNoCompDataDisp(int nImgXdim, int nImgYdim)
{
    gdImagePtr    pImg                  = NULL;     
    int           nTransparent          = 0;        
    int           nBlack                = 0;        
    char          szFont[FONT_SIZE]     = { 0, };   
    char          szText[TEXT_SIZE]     = { 0, };   
    int           rgnBrect[BRECT_SIZE]  = { 0, };   
    char*         szErr                 = NULL;     
    double        dSize                 = 16.;      
    int           nBrectlength          = 0;        

    pImg           = gdImageCreateTrueColor(nImgXdim, nImgYdim);
    gdImageAlphaBlending(pImg, 0);
    gdImageSaveAlpha(pImg, 1);

    nTransparent   = gdTrueColorAlpha(255, 255, 255, 127);
    nBlack         = gdImageColorAllocate(pImg,  0,  0,  0);

    gdImageFilledRectangle(pImg, 0, 0, nImgXdim, nImgYdim, nTransparent);

    sprintf(szFont, "%s/NanumGothic.ttf", FONT_PATH); 
    sprintf(szText, " %s", "선택된 시각의 레이더자료가 없습니다.");

    gdImageStringFT(NULL, &rgnBrect[0], nBlack, szFont, dSize, 0.0, 0, 0, szText);
    nBrectlength = rgnBrect[2] - rgnBrect[0];

    szErr = gdImageStringFT(pImg, &rgnBrect[0], nBlack, szFont, dSize, 0.0, (nImgXdim - nBrectlength)/2, nImgYdim/2, szText);
    if(szErr)
    {
        gdImageDestroy(pImg);
        return -1;
    }

    fprintf(stdout, "Content-type: image/png\r\n\r\n");
    gdImagePng(pImg, stdout);
    fflush(stdout);

    gdImageDestroy(pImg);
    return 0;
}

int fnNoCompMapDataDisp(char szP_type[], int nImgXdim, int nImgYdim, char szUnit[])
{
#define NO_DATA_FREE() \
    free(pColor_ini); \
    gdImageDestroy(pImg);

    gdImagePtr      pImg                                 = NULL;     
    int             nWhite                               = 0;        
    int             nBlack                               = 0;        
    int             echoColorBar[CGI_DF_COLOR_MAX]       = { 0, };   
    int             dispColorBar[CGI_EN_DISP_COLOR_MAX]  = { 0, };   
    CGI_COLOR_TBL*  pColor_ini                           = NULL;     
    float           fOriginGrid                          = 4.0;                      
    float           fCompGrid                            = 2.0;                      
    float           fZm                                  = fOriginGrid / fCompGrid;  
    float           fXo                                  = 0.0 / fZm;                
    float           fYo                                  = 0.0 / fZm;                
    int             nMoveX                               = 0;                        
    int             nMoveY                               = 0;                        

    pImg = gdImageCreateTrueColor(nImgXdim + IMAGE_INDEX_RIGHT_SIZE +1, nImgYdim+25+1);

    nWhite  = gdImageColorAllocate(pImg, 255, 255, 255);
    nBlack  = gdImageColorAllocate(pImg,  51,  51,  51);
    
    if(strcmp(szP_type, "ETOP") == 0)
    {
        pColor_ini = fnReadColorTable(CGI_DF_ETOP_COLOR_FILE);
    }
    else if(strcmp(szP_type, "VIL") == 0)
    {
        pColor_ini = fnReadColorTable(CGI_DF_VIL_COLOR_FILE);
    }
    else
    {
        pColor_ini = fnReadColorTable(CGI_DF_RN_COLOR_FILE);
    }   

    fnAllocColorTbl(pImg, pColor_ini, echoColorBar, dispColorBar);
    gdImageFilledRectangle(pImg, 0, 0, nImgXdim, nImgYdim+25, nWhite);

    if(fnMapLineDisp(nImgYdim, pImg, dispColorBar[CGI_EN_LINE_COLOR], fXo, fYo, nMoveX, nMoveY, fZm) < 0)
    {
        NO_DATA_FREE()
        return -1;
    }
    
    fnMapLevelColorDisp(nImgXdim, nImgYdim+25, szP_type, szUnit, pImg, echoColorBar, pColor_ini);
    gdImageRectangle(pImg, 0, 0, nImgXdim, nImgYdim+25, nBlack);

    if(fnNoDataDisp(nImgXdim, nImgYdim, pImg) < 0)
    {
        NO_DATA_FREE()
        return -1;
    }

    fprintf(stdout, "Content-type: image/png\r\n\r\n");
    gdImagePng(pImg, stdout);
    fflush(stdout);

    NO_DATA_FREE()
    
    return 0;
}

int fnCreateLevelColorImg(char szP_type[], int nImgYdim, char szUnit[])
{
    gdImagePtr      pImg                                 = NULL;     
    int             echoColorBar[CGI_DF_COLOR_MAX]       = { 0, };   
    int             dispColorBar[CGI_EN_DISP_COLOR_MAX]  = { 0, };   
    CGI_COLOR_TBL*  pColor_ini                           = NULL;     

    pImg    = gdImageCreateTrueColor(IMAGE_INDEX_RIGHT_SIZE, nImgYdim);

    if(strcmp(szP_type, "ETOP") == 0)
    {
        pColor_ini = fnReadColorTable(CGI_DF_ETOP_COLOR_FILE);
    }
    else if(strcmp(szP_type, "VIL") == 0)
    {
        pColor_ini = fnReadColorTable(CGI_DF_VIL_COLOR_FILE);
    }
    else
    {
        if(strcmp(szUnit, "SN") == 0)
        {
            pColor_ini = fnReadColorTable(CGI_DF_SN_COLOR_FILE);
        }
        else
        {        
            pColor_ini = fnReadColorTable(CGI_DF_RN_COLOR_FILE);
        }
    }

    fnAllocColorTbl(pImg, pColor_ini, echoColorBar, dispColorBar);

    fnLevelColorDisp(nImgYdim, szP_type, szUnit, pImg, echoColorBar, pColor_ini);

    fprintf(stdout, "Content-type: image/png\r\n\r\n");
    gdImagePng(pImg, stdout);
    fflush(stdout);

    free(pColor_ini);
    gdImageDestroy(pImg);

    return 0;
}

int fnVsrfMapleContentDisp(int nImgXdim, int nImgYdim, gdImagePtr pImg, char szDate[], char szForecastDate[])
{
    int           rgnBrect[BRECT_SIZE]          = { 0, };   
    double        dSize                         = 12.;      
    char*         szErr                         = NULL;     
    char          szFont[FONT_SIZE]             = { 0, };   
    char          szText[TEXT_SIZE]             = { 0, };   
    int           nBlack                        = 0;        
    int           nBrectlength                  = 0;        
    char          szTimes[TEXT_SIZE]            = "";       
    char          szForecastTimes[TEXT_SIZE]    = "";       
    
    struct tm     stTime;                           
    struct tm     stForecastTime;                           

    if(pImg == NULL)
    {
        return -1;
    }

    memset(&stTime,         0x00, sizeof(struct tm));
    memset(&stForecastTime, 0x00, sizeof(struct tm));

    nBlack = gdImageColorAllocate(pImg, 0, 0, 0);
    sprintf(szFont, "%s/times.ttf", FONT_PATH); 

    strcpy(szTimes, szDate);
    strptime(szTimes, "%Y%m%d%H%M", &stTime);
    strftime(szTimes, sizeof(szTimes), "%Y.%m.%d. %H:%M", &stTime);

    strcpy(szForecastTimes, szForecastDate);
    strptime(szForecastTimes, "%Y%m%d%H%M", &stForecastTime);
    strftime(szForecastTimes, sizeof(szForecastTimes), "%Y.%m.%d. %H:%M", &stForecastTime);

    sprintf(szText, "Forecast Time = %s", szForecastTimes);
    
    gdImageStringFT(NULL, &rgnBrect[0], nBlack, szFont, dSize, 0.0, 0, 0, szText);
    nBrectlength = rgnBrect[2] - rgnBrect[0];

    szErr = gdImageStringFT(pImg, &rgnBrect[0], nBlack, szFont, dSize, 0.0, (nImgXdim - nBrectlength)/2, nImgYdim - 45, szText);
    sprintf(szText, "Valid Time = %s", szTimes);
    szErr = gdImageStringFT(pImg, &rgnBrect[0], nBlack, szFont, dSize, 0.0, (nImgXdim - nBrectlength)/2, nImgYdim - 25, szText);

    if(szErr)
    {
        gdImageDestroy(pImg);
        return -1;
    }

    return 0;
}

int fnWritePointRain(float **pCompData, char szUnit[], int nCompXdim, int nCompYdim, float fCompGridKm, float fCompLon, float fCompLat, int nCompXo, int nCompYo, float fPointLon, float fPointLat, int nUnitFlag)
{
    int         nAwsX         = 0;
    int         nAwsY         = 0;
    float       fAwsX         = 0.0;
    float       fAwsY         = 0.0;

    st_LAMC_VAR       lamcVar;
    st_LAMC_PARAMETER lamcMap;

    if(pCompData == NULL)
    {
        return -1;
    }

    lamcVar.m_nFirst = 0;
    lamcMap = fnCgiGetMapInfo(KMA_MAP_RE, 30, 60, fCompLon, fCompLat, fCompGridKm, nCompXo, nCompYo);

    fnCgiLamcproj(&fPointLon, &fPointLat, &fAwsX, &fAwsY, 0, &lamcMap, &lamcVar);
    nAwsX = (int)(fAwsX+0.5);
    nAwsY = (int)(nCompYdim-fAwsY-1);

    if(nAwsX < 0 || nAwsX > nCompXdim || nAwsY < 0 || nAwsY > nCompYdim)
    {
        fprintf(stdout, "Content-type: text/html\r\n\r\n");
        fprintf(stdout, "%s\r\n\r\n", "-");
    }
    else
    {
        if((pCompData[nAwsY][nAwsX] == BAD_VALUE_F) || (pCompData[nAwsY][nAwsX] == BOUND_VALUE_C) || (pCompData[nAwsY][nAwsX] == BAD_VALUE_C))
        {
            fprintf(stdout, "Content-type: text/html\r\n\r\n");
            fprintf(stdout, "%s\r\n\r\n", "-");
        }
        else
        {
            if(nUnitFlag == 0)
            {
                if(strcmp(szUnit, "RN") == 0)
                    pCompData[nAwsY][nAwsX] = (float)fnDbz_To_R_f((double)pCompData[nAwsY][nAwsX], CGI_DF_DEFAULT_ZR_A, CGI_DF_DEFAULT_ZR_B);
                else if(strcmp(szUnit, "SN") == 0)
                    pCompData[nAwsY][nAwsX] = (float)fnDbz_To_R_f((double)pCompData[nAwsY][nAwsX], CGI_DF_SNOW_ZR_A, CGI_DF_SNOW_ZR_B);
            }
            else if(nUnitFlag == 1)
            {
                if((strcmp(szUnit, "CZ") == 0) || (strcmp(szUnit, "SN") == 0))
                {
                    pCompData[nAwsY][nAwsX] = (float)fnR_to_dBZ_f((double)pCompData[nAwsY][nAwsX], CGI_DF_DEFAULT_ZR_A, CGI_DF_DEFAULT_ZR_B);
                    if(strcmp(szUnit, "SN") == 0)
                        pCompData[nAwsY][nAwsX] = (float)fnDbz_To_R_f((double)pCompData[nAwsY][nAwsX], CGI_DF_SNOW_ZR_A, CGI_DF_SNOW_ZR_B);
                }
            
            }

            fprintf(stdout, "Content-type: text/html\r\n\r\n");
            fprintf(stdout, "%.2f\r\n\r\n", pCompData[nAwsY][nAwsX]);
        }
    }

    return 0;
}

int fnImgTopTextDisp(gdImagePtr pImg, char szP_type[], char szQ_type[], char szUnit[], char szDate[], int nImgXdim, int nFlag, char szForecastDate[])
{
    int         nBlack                               = 0;     
    int         nBlue                                = 0;     
    int         rgnBrect[BRECT_SIZE]                 = { 0, };
    char        szFont[FONT_SIZE]                    = { 0, }; 
    char        szText[TEXT_SIZE]                    = { 0, };
    char        szQcName[TEXT_SIZE]                  = { 0, }; 
    int         nBrectlength                         = 0;   
    char*       szErr                                = NULL;    
    char        szTimes[TEXT_SIZE]                   = "";
    char        szForecastTimes[TEXT_SIZE]           = "";       
    struct tm   stTime;                         
    struct tm   stForecastTime;                           

    if(pImg == NULL)
    {
        return -1;
    }
 
    memset(&stTime,         0x00, sizeof(struct tm));
    memset(&stForecastTime, 0x00, sizeof(struct tm));

    nBlack = gdImageColorAllocate(pImg, 0, 0, 0);
    nBlue  = gdImageColorAllocate(pImg, 0, 50, 255);
//    sprintf(szFont, "%s/NanumGothic.ttf", FONT_PATH);
    sprintf(szFont, "%s/timesbd.ttf", FONT_PATH);

    strcpy(szTimes, szDate);
    strptime(szTimes, "%Y%m%d%H%M", &stTime);
    strftime(szTimes, sizeof(szTimes), "%Y.%m.%d. %H:%M", &stTime);

    if(nFlag == 0)
    {
        sprintf(szText, "PPI0(%s) %s(KST) Rain Rate", szUnit, szTimes); 
    }
    else if(nFlag == 1)
    {
        if(strcmp(szQ_type, "NOQC") == 0)
        {
            sprintf(szQcName, "%s", "NoQC");
        }
        else if(strcmp(szQ_type, "FUZZYQC") == 0)
        {
            sprintf(szQcName, "%s", "Fuzzy");
        }
        else if(strcmp(szQ_type, "ORPGQC") == 0)
        {
            sprintf(szQcName, "%s", "ORPG");
        }
        else if(strcmp(szQ_type, "CHAFFQC") == 0)
        {
            sprintf(szQcName, "%s", "Chaff");
        }
        
        if(strcmp(szP_type, "ETOP") == 0)
        {   
            sprintf(szText, "%s %s(%s) %s(KST)", szP_type, szQcName, "CZ", szTimes);
        }
        else if(strcmp(szP_type, "VIL") == 0)
        {   
             sprintf(szText, "%s %s(%s) %s(KST)", szP_type, szQcName, "RN", szTimes);
        }
        else
        {
            sprintf(szText, "%s %s(%s) %s(KST) Rain Rate", szP_type, szQcName, szUnit, szTimes);
        }
    }
    else if(nFlag == 2)
    {
        sprintf(szText, "PPI0(%s) 480km Rainrate %s(KST)", szUnit, szTimes); 
    }
    else if(nFlag == 3)
    {
        sprintf(szText, "PPI0 Fuzzy(%s) %s(KST) Rain Rate", szUnit, szTimes); 
    }
    else if(nFlag == 4)
    {
        sprintf(szText, "PPI0 NoQC(%s) %s(KST) Rain Rate", szUnit, szTimes); 
    }
    else if(nFlag == 5)
    {
        strcpy(szForecastTimes, szForecastDate);
        strptime(szForecastTimes, "%Y%m%d%H%M", &stForecastTime);
        strftime(szForecastTimes, sizeof(szForecastTimes), "%Y.%m.%d. %H:%M", &stForecastTime);

        if(strcmp(szP_type, "VSRF") == 0) 
        {
            sprintf(szText, "%s(%s) 1km %s(KST) Rain Rate  Forecast Time = %s", szP_type, szUnit, szTimes, szForecastTimes);
        }
        else if((strcmp(szP_type, "MAPLE") == 0) || (strcmp(szP_type, "KONOS") == 0))
        {
             sprintf(szText, "%s(%s) %s(KST) Rain Rate  Forecast Time = %s", szP_type, szUnit, szTimes, szForecastTimes); 
        }
 
        gdImageStringFT(NULL, &rgnBrect[0], nBlue, szFont, 15, 0.0, 0, 0, szText);
        nBrectlength = rgnBrect[2] - rgnBrect[0];

        szErr = gdImageStringFT(pImg, &rgnBrect[0], nBlue, szFont, 15, 0.0, (nImgXdim - nBrectlength)/2, 20, szText);
        if(szErr)
        {
            gdImageDestroy(pImg);
            return -1;
        }
   
        return 0;
    }
    else if(nFlag == 6)
    {
        sprintf(szText, "PPI0 ORPG(%s) %s(KST) Rain Rate", szUnit, szTimes); 
    }
           
    gdImageStringFT(NULL, &rgnBrect[0], nBlack, szFont, 15, 0.0, 0, 0, szText);
    nBrectlength = rgnBrect[2] - rgnBrect[0];
 
    szErr = gdImageStringFT(pImg, &rgnBrect[0], nBlack, szFont, 15, 0.0, (nImgXdim - nBrectlength)/2, 20, szText);
    if(szErr)
    {
        gdImageDestroy(pImg);
        return -1;
    }

    return 0;
}

int fnRainPointFileWrite(float **pCompData, char szUnit[], long lN_Date, int nCompXdim, int nCompYdim, int nUnitFlag, int nImgXdim, int nImgYdim, float fLU_lon, float fLU_lat, float fXDist, float fYDist, float fCompGridKm, float fCompLU_lon_Value, float fCompLU_lat_Value,  float fCompRL_lon_Value, float fCompRL_lat_Value)
{
    FILE                    *pFp                            = NULL;
    int                     nXIdx                           = 0;
    int                     nYIdx                           = 0;
    char                    szWriteFileName[FILE_MAX_STR]   = {0,};
    float                   fZr_A                           = 0.0;
    float                   fZr_B                           = 0.0;
    float**                 pImgData                        = NULL;
    float                   fImgXGridM                      = 0.0;
    float                   fImgYGridM                      = 0.0;
    float                   fImgLU_lon                      = 0.0;
    float                   fImgLU_lat                      = 0.0;
    float                   fImgLU_x                        = 0.0;
    float                   fImgLU_y                        = 0.0;
    float                   fCompLU_lon                     = 0.0;
    float                   fCompLU_lat                     = 0.0;
    float                   fCompToImgLU_x                  = 0.0;
    float                   fCompToImgLU_y                  = 0.0;
    int                     nDiff_x                         = 0;
    int                     nDiff_y                         = 0;
    float                   fXGridScale                     = 0;
    float                   fYGridScale                     = 0;
    float                   fCompRL_lon                     = 0.0;
    float                   fCompRL_lat                     = 0.0;
    float                   fCompToImgRL_x                  = 0.0;
    float                   fCompToImgRL_y                  = 0.0;
    int                     nDiff_RL_x                      = 0;
    int                     nDiff_RL_y                      = 0;
    
    st_LAMC_VAR             lamcVar;
    st_LAMC_PARAMETER       lamcMap;

    if(pCompData == NULL)
    {
        return -1;
    }
    
    sprintf(szWriteFileName, "%s/%ld.bin", RAIN_POINT_WRITE_PATH, lN_Date);
    if((pFp = fopen(szWriteFileName, "wb")) == NULL)
        return -1;


    if((pImgData = fnGetMatrixFloat(nImgYdim, nImgXdim)) == NULL)
    {
        return -1;
    }

    for(nYIdx = 0; nYIdx < nImgYdim; nYIdx++)
    {
        for(nXIdx = 0; nXIdx < nImgXdim; nXIdx++)
        {
            pImgData[nYIdx][nXIdx] = BAD_VALUE_F;
        }
    }

    fImgXGridM = fXDist/nImgXdim;
    fImgYGridM = fYDist/nImgYdim;

    lamcVar.m_nFirst = 0;
    lamcMap = fnCgiGetMapInfo(GIS_MAP_RE, 30, 60, 126, 0, 0.001, 0, 0);

    fCompLU_lon = fCompLU_lon_Value;
    fCompLU_lat = fCompLU_lat_Value;

    fCompRL_lon = fCompRL_lon_Value;
    fCompRL_lat = fCompRL_lat_Value;
    
    fImgLU_lon = fLU_lon;
    fImgLU_lat = fLU_lat;
      
    fnCgiLamcproj(&fImgLU_lon,  &fImgLU_lat,  &fImgLU_x,       &fImgLU_y,       0, &lamcMap, &lamcVar);
    fnCgiLamcproj(&fCompLU_lon, &fCompLU_lat, &fCompToImgLU_x, &fCompToImgLU_y, 0, &lamcMap, &lamcVar);
    fnCgiLamcproj(&fCompRL_lon, &fCompRL_lat, &fCompToImgRL_x, &fCompToImgRL_y, 0, &lamcMap, &lamcVar);

    nDiff_x = (int)((fCompToImgLU_x - fImgLU_x)/fImgXGridM);
    nDiff_y = (int)((fImgLU_y - fCompToImgLU_y)/fImgYGridM);

    nDiff_RL_x = (int)((fCompToImgRL_x - fImgLU_x)/fImgXGridM);
    nDiff_RL_y = (int)((fImgLU_y - fCompToImgRL_y)/fImgYGridM);

    fXGridScale = fCompGridKm/(fImgXGridM/1000);
    fYGridScale = fCompGridKm/(fImgYGridM/1000);


    for(nYIdx = 0; nYIdx < nImgYdim; nYIdx++)
    {
        for(nXIdx = 0; nXIdx < nImgXdim; nXIdx++)
        {
            pImgData[nYIdx][nXIdx] = fnCalcRadarValue(pCompData,
                                                        nCompXdim,
                                                        nCompYdim,
                                                        nDiff_x,
                                                        nDiff_y,
                                                        nXIdx,
                                                        nYIdx,
                                                        fXGridScale,
                                                        fYGridScale);

            if(nUnitFlag == 3)
            {    
                if((pImgData[nYIdx][nXIdx] != BOUND_VALUE_F) && (pImgData[nYIdx][nXIdx] != BAD_VALUE_F))
                {
                    pImgData[nYIdx][nXIdx] = (float)(pImgData[nYIdx][nXIdx] / 100.);
                }
            }
        }
    }

    if(nUnitFlag == 3)
    {
        fnKmaPosToGisPos(pImgData, nImgYdim, nImgXdim, fImgYGridM, fImgXGridM, fLU_lon, fLU_lat, 0, 0, 0, 0);
    }
    else
    {
        fnKmaPosToGisPos(pImgData, nImgYdim, nImgXdim, fImgYGridM, fImgXGridM, fLU_lon, fLU_lat, nDiff_x, nDiff_y, nDiff_RL_x, nDiff_RL_y);
    }

    for(nYIdx = 0; nYIdx < nImgYdim; nYIdx++)
    {
        for(nXIdx = 0; nXIdx < nImgXdim; nXIdx++)
        {
            if(pImgData[nYIdx][nXIdx] == BAD_VALUE_F)
            {
                if(nXIdx >= 1 && nXIdx < nImgXdim - 2)
                {
                    if(pImgData[nYIdx][nXIdx-1] != BAD_VALUE_F && pImgData[nYIdx][nXIdx+1] != BAD_VALUE_F)
                        pImgData[nYIdx][nXIdx] = pImgData[nYIdx][nXIdx-1];
                }
                if(nYIdx >= 1 && nYIdx < nImgYdim - 2)
                {
                    if(pImgData[nYIdx-1][nXIdx] != BAD_VALUE_F && pImgData[nYIdx+1][nXIdx] != BAD_VALUE_F)
                        pImgData[nYIdx][nXIdx] = pImgData[nYIdx-1][nXIdx];
                }
            }
        }
    }

    if((strcmp(szUnit, "RN") == 0) || (strcmp(szUnit, "CZ") == 0))
    {
        fZr_A = CGI_DF_DEFAULT_ZR_A;
        fZr_B = CGI_DF_DEFAULT_ZR_B;
    }
    else if(strcmp(szUnit, "SN") == 0)
    {
        fZr_A = CGI_DF_SNOW_ZR_A;
        fZr_B = CGI_DF_SNOW_ZR_B;
    }

    if(nUnitFlag == 0)
    {
        for(nYIdx = 0; nYIdx < nImgYdim; nYIdx++)
        {
            if((strcmp(szUnit, "RN") == 0) || (strcmp(szUnit, "SN") == 0))
            {    
                for(nXIdx = 0; nXIdx < nImgXdim; nXIdx++)
                {
                    pImgData[nYIdx][nXIdx] = (float)fnDbz_To_R_f((double)pImgData[nYIdx][nXIdx], fZr_A, fZr_B);
                }
            }

            fwrite(pImgData[nYIdx], sizeof(float), nImgXdim, pFp);   
        }
        
        fclose(pFp);
        return 0;
    }
    else if(nUnitFlag == 1)
    {
        for(nYIdx = 0; nYIdx < nImgYdim; nYIdx++)
        {
            if((strcmp(szUnit, "CZ") == 0) || (strcmp(szUnit, "SN") == 0))
            {
                for(nXIdx = 0; nXIdx < nImgXdim; nXIdx++)
                {
                    pImgData[nYIdx][nXIdx] = (float)fnR_to_dBZ_f((double)pImgData[nYIdx][nXIdx], CGI_DF_DEFAULT_ZR_A, CGI_DF_DEFAULT_ZR_B);
                    if(strcmp(szUnit, "SN") == 0)
                        pImgData[nYIdx][nXIdx] = (float)fnDbz_To_R_f((double)pImgData[nYIdx][nXIdx], fZr_A, fZr_B);
                }
            }

            fwrite(pImgData[nYIdx], sizeof(float), nImgXdim, pFp);
        }

        fclose(pFp);
        return 0;
    }
    else if((nUnitFlag == 2) || (nUnitFlag == 3)) 
    {
        for(nYIdx = 0; nYIdx < nImgYdim; nYIdx++)
        {
            fwrite(pImgData[nYIdx], sizeof(float), nImgXdim, pFp);   
        }
        
        fclose(pFp);
        return 0;
    }

    fclose(pFp);
    return -1;
}


/* ================================================================================ */
