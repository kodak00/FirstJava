/* ================================================================================ */
//
// 레이더 에코 영상 GIS - comp_echo_disp.c (합성 에코 영상 표출)   
//
// 2016.08.03
//
// SnK
//
/* ================================================================================ */
// INCLUDE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "gd.h"

#include "cgi_comp_value.h"
#include "cgi_cmm_util.h"
#include "cgi_cmm_color.h"
#include "cgi_comp_calc.h"
#include "cgi_comp_echo_disp.h"

/* ================================================================================ */
// LOCAL FUNTION

static float** fnCompTitanData(float** pData, int m_nImgXdim, int m_nImgYdim, float fMax_cell_dbz)
{
    int     nCell_value    = 0;       
    int     nCell          = 0;       
    int     nXIdx          = 0;       
    int     nYIdx          = 0;       
    int     nXIdx_second   = 0;       
    int     nYIdx_second   = 0;       
    int     nX_start       = 0;       
    int     nX_end         = 0;       
    int     nY_start       = 0;       
    int     nY_end         = 0;       
    float   fPx2km         = 2.0;     
    float   fDis_a         = 0.0;     
    float   fDis_b         = 0.0;     
    float   fDis_c         = 0.0;     
    float   fMax_cell_len  = 10.0;    
    char*   szCell_ox      = NULL;    
 
    float** ppTemp         = NULL;    
    int**   pTitan         = NULL;    
    short*  nMin_x         = NULL;    
    short*  nMin_y         = NULL;    
    short*  nMax_x         = NULL;    
    short*  nMax_y         = NULL;    

    ppTemp = (float **)calloc(m_nImgYdim, sizeof(float *));
    for(nYIdx = 0; nYIdx < m_nImgYdim; nYIdx++) 
    {
        ppTemp[nYIdx] = (float *)calloc(m_nImgXdim, sizeof(float));
        for(nXIdx = 0; nXIdx < m_nImgXdim; nXIdx++) 
        {
            ppTemp[nYIdx][nXIdx] = pData[nYIdx][nXIdx];
            pData[nYIdx][nXIdx]  = BAD_VALUE_F;
        }
    }
    
    pTitan = (int **)malloc(m_nImgYdim*sizeof(int *));
    for(nYIdx = 0; nYIdx < m_nImgYdim; nYIdx++) 
    {
        pTitan[nYIdx] = (int *)malloc(m_nImgXdim*sizeof(int));
        for(nXIdx = 0; nXIdx < m_nImgXdim; nXIdx++) 
        {
            pTitan[nYIdx][nXIdx] = 999999;
        }
    }

    nX_start = 999;
    nX_end   = -1;
    nY_start = 999;
    nY_end   = -1;
    nCell    = -1;

    for(nYIdx = 0; nYIdx < m_nImgYdim; nYIdx++)
    {
        for(nXIdx=0; nXIdx < m_nImgXdim; nXIdx++) 
        {
            if(ppTemp[nYIdx][nXIdx] >= fMax_cell_dbz) 
            {
                if(nXIdx < nX_start) nX_start = nXIdx;
                if(nXIdx > nX_end) nX_end = nXIdx;
                if(nYIdx < nY_start) nY_start = nYIdx;
                if(nYIdx > nY_end) nY_end = nYIdx;

                if(nXIdx >= 1) 
                {
                    if(pTitan[nYIdx][nXIdx-1] <= nCell) 
                    {
                        pTitan[nYIdx][nXIdx] = pTitan[nYIdx][nXIdx-1];

                        if(nYIdx >= 1) 
                        {
                            if(pTitan[nYIdx-1][nXIdx] < pTitan[nYIdx][nXIdx]) 
                            {
                                for(nXIdx_second = 0; nXIdx_second <= nXIdx; nXIdx_second++) 
                                {
                                    if(pTitan[nYIdx][nXIdx_second] == pTitan[nYIdx][nXIdx]) 
                                        pTitan[nYIdx][nXIdx_second] = pTitan[nYIdx-1][nXIdx];
                                }
                            }
                        }
                    } 
                    else 
                    {
                        nCell++;
                        pTitan[nYIdx][nXIdx] = nCell;
                    }
                } 
                else 
                {
                    nCell++;
                    pTitan[nYIdx][nXIdx] = nCell;
                }
            }
        }
    }

    if(nCell == -1) 
    {
        for(nYIdx = 0; nYIdx < m_nImgYdim; nYIdx++) 
        {
            free(pTitan[nYIdx]);
            free(ppTemp[nYIdx]);
        }
        free(pTitan);
        free(ppTemp);

        return pData;
    }
/*
    szCell_ox = malloc((nCell+1) * sizeof(char));
    nMax_x = malloc((nCell+1) * sizeof(short));
    nMax_y = malloc((nCell+1) * sizeof(short));
    nMin_x = malloc((nCell+1) * sizeof(short));
    nMin_y = malloc((nCell+1) * sizeof(short));
*/
    szCell_ox = (char *)calloc((nCell+1), sizeof(char));
    nMax_x = (short *)calloc((nCell+1), sizeof(short));
    nMax_y = (short *)calloc((nCell+1), sizeof(short));
    nMin_x = (short *)calloc((nCell+1), sizeof(short));
    nMin_y = (short *)calloc((nCell+1), sizeof(short));

    for(nCell_value = 0; nCell_value <= nCell; nCell_value++) 
    {
        nMax_x[nCell_value] = 0;
        nMax_y[nCell_value] = 0;
        nMin_x[nCell_value] = 999;
        nMin_y[nCell_value] = 999;
        szCell_ox[nCell_value] = 1;
    }

    for(nXIdx = nX_start; nXIdx <= nX_end; nXIdx++) 
    {
        for(nYIdx = nY_start; nYIdx <= nY_end; nYIdx++) 
        {
            if(pTitan[nYIdx][nXIdx] <= nCell) 
            {
                if(nXIdx > nMax_x[pTitan[nYIdx][nXIdx]]) nMax_x[pTitan[nYIdx][nXIdx]] = nXIdx;
                if(nYIdx > nMax_y[pTitan[nYIdx][nXIdx]]) nMax_y[pTitan[nYIdx][nXIdx]] = nYIdx;
                if(nXIdx < nMin_x[pTitan[nYIdx][nXIdx]]) nMin_x[pTitan[nYIdx][nXIdx]] = nXIdx;
                if(nYIdx < nMin_y[pTitan[nYIdx][nXIdx]]) nMin_y[pTitan[nYIdx][nXIdx]] = nYIdx;

                if((nYIdx >= 1) && (nXIdx >= 1) && (nXIdx < m_nImgXdim-1) && (nYIdx < m_nImgYdim-1)) 
                {
                    nCell_value = pTitan[nYIdx][nXIdx];
                    if(pTitan[nYIdx][nXIdx+1] < nCell_value) nCell_value = pTitan[nYIdx][nXIdx+1];
                    if(pTitan[nYIdx][nXIdx-1] < nCell_value) nCell_value = pTitan[nYIdx][nXIdx-1];
                    if(pTitan[nYIdx+1][nXIdx] < nCell_value) nCell_value = pTitan[nYIdx+1][nXIdx];
                    if(pTitan[nYIdx-1][nXIdx] < nCell_value) nCell_value = pTitan[nYIdx-1][nXIdx];

                    if(pTitan[nYIdx][nXIdx] > nCell_value) 
                    {
                        if(szCell_ox[pTitan[nYIdx][nXIdx]] == 1) szCell_ox[pTitan[nYIdx][nXIdx]] = 0;
                        for(nXIdx_second = nX_start; nXIdx_second <= nX_end; nXIdx_second++) 
                        {
                            for(nYIdx_second = nY_start; nYIdx_second <= nY_end; nYIdx_second++) 
                            {
                                if(pTitan[nYIdx_second][nXIdx_second] == pTitan[nYIdx][nXIdx] && nYIdx_second != nYIdx && nXIdx_second != nXIdx)  
                                {
                                    pTitan[nYIdx_second][nXIdx_second] = nCell_value;
                                    if(nXIdx_second > nMax_x[nCell_value]) nMax_x[nCell_value] = nXIdx_second;
                                    if(nYIdx_second > nMax_y[nCell_value]) nMax_y[nCell_value] = nYIdx_second;
                                    if(nXIdx_second < nMin_x[nCell_value]) nMin_x[nCell_value] = nXIdx_second;
                                    if(nYIdx_second < nMin_y[nCell_value]) nMin_y[nCell_value] = nYIdx_second;
                                }
                            }
                        }
                        pTitan[nYIdx][nXIdx] = nCell_value;
                    }
                }
            }
        }
    }

    for(nCell_value = 0; nCell_value <= nCell; nCell_value++) 
    {
        fDis_a = 0.0;
        fDis_b = 0.0;
        fDis_c = 0.0;

        if(szCell_ox[nCell_value] == 1) 
        {
            if((nMax_x[nCell_value] != 0) && (nMax_y[nCell_value] != 0) && (nMin_x[nCell_value] != 999) && (nMin_y[nCell_value] != 999) )
            {
                fDis_a = (float)abs(nMax_x[nCell_value] - nMin_x[nCell_value]) * fPx2km;
                fDis_b = (float)abs(nMax_y[nCell_value] - nMin_y[nCell_value]) * fPx2km;
                fDis_c = (float)sqrt((float)(fDis_a*fDis_a)+(float)(fDis_b*fDis_b));

                if((fDis_a < fMax_cell_len) && (fDis_b < fMax_cell_len) && (fDis_c < fMax_cell_len)) 
                {
                    szCell_ox[nCell_value] = 0;
                }
            }
        }
    }

    for(nYIdx = 0; nYIdx < m_nImgYdim; nYIdx++)
    {
        for(nXIdx = 0; nXIdx < m_nImgXdim; nXIdx++) 
        {
            if(pTitan[nYIdx][nXIdx] <= nCell) 
            {
                if(szCell_ox[pTitan[nYIdx][nXIdx]] == 1 && ppTemp[nYIdx][nXIdx] > 0) 
                {
                    pData[nYIdx][nXIdx] = 0;
                }
            }
        }
    }

    for(nYIdx = 0; nYIdx < m_nImgYdim; nYIdx++) 
    {
        free(pTitan[nYIdx]);
        free(ppTemp[nYIdx]);
    }
    free(pTitan);
    free(ppTemp);
    free(szCell_ox);
    free(nMax_x);
    free(nMax_y);
    free(nMin_x);
    free(nMin_y);

    return pData;
}

/* ================================================================================ */
// FUNCTION

int fnComp480EchoDisp(int nImgXdim, int nImgYdim, char szUnit[], float** pImgData, gdImagePtr pImg, int rgnColor[], CGI_COLOR_TBL* pColor_ini)
{
    int       nXIdx             = 0;                    
    int       nYIdx             = 0;                    
    int       nColor            = -1;                   
    float     fFval             = 0.0;                  
    float     fMinValue         = 0.0;                  
    int       nDiffType         = 0;                    
    int       nMinDiffType      = 1;                    
    int       nColorKind        = CGI_EN_COLOR_RAIN;    

    if((pImgData == NULL) || (pImg == NULL) || (pColor_ini == NULL))
    {
        return -1;
    }

    if(strcmp(szUnit, "CZ") == 0)
        nColorKind = CGI_EN_COLOR_UNIT;
    else if(strcmp(szUnit, "DZ") == 0)
        nColorKind = CGI_EN_COLOR_UNIT;
    else if(strcmp(szUnit, "RN") == 0)
        nColorKind = CGI_EN_COLOR_RAIN;
    else if(strcmp(szUnit, "SN") == 0)
            nColorKind = CGI_EN_COLOR_RAIN;

    for(nYIdx = 0; nYIdx < nImgYdim; nYIdx++)
    {
        for(nXIdx = 0; nXIdx < nImgXdim; nXIdx++)
        {
            fFval = pImgData[nYIdx][nXIdx];
            
            nColor = fnGetColorLevel(fFval, pColor_ini, nColorKind, fMinValue, nMinDiffType, nDiffType);
            if((nColor >= 0) && (nColor < pColor_ini->m_iEchoColorCnt))
            {
                gdImageSetPixel(pImg, nXIdx, nYIdx, rgnColor[nColor]);
            }
        }
    }

    return 0;
}

int fnCompCj3EchoDisp(int nImgXdim, int nImgYdim, char szP_type[], char szUnit[], float** pImgData, gdImagePtr pImg, int rgnColor[], CGI_COLOR_TBL* pColor_ini)
{
    int       nXIdx             = 0;                 
    int       nYIdx             = 0;                 
    int       nColor            = -1;                
    float     fFval             = 0.0;               
    float     fMinValue         = 0.0;               
    int       nMinDiffType      = 1;                 
    int       nDiffType         = 0;                 
    int       nColorKind        = CGI_EN_COLOR_RAIN; 

    if((pImgData == NULL) || (pImg == NULL) || (pColor_ini == NULL))
    {
        return -1;
    }

    if(strcmp(szUnit, "CZ") == 0)
        nColorKind = CGI_EN_COLOR_UNIT;
    else if(strcmp(szUnit, "DZ") == 0)
        nColorKind = CGI_EN_COLOR_UNIT;
    else if(strcmp(szUnit, "RN") == 0)
        nColorKind = CGI_EN_COLOR_RAIN;
    else if(strcmp(szUnit, "SN") == 0)
        nColorKind = CGI_EN_COLOR_RAIN;

    for(nYIdx = 0; nYIdx < nImgYdim; nYIdx++)
    {
        for(nXIdx = 0; nXIdx < nImgXdim; nXIdx++)
        {
            fFval = pImgData[nYIdx][nXIdx];

            nColor = fnGetColorLevel(fFval, pColor_ini, nColorKind, fMinValue, nMinDiffType, nDiffType);
            if((nColor >= 0) && (nColor < pColor_ini->m_iEchoColorCnt))
            {
                gdImageSetPixel(pImg, nXIdx, nYIdx, rgnColor[nColor]);
            }
        }
    }

    return 0;
}

int fnCompEchoDisp(int nImgXdim, int nImgYdim, char szP_type[], char szUnit[], float** pImgData, gdImagePtr pImg, int rgnColor[], CGI_COLOR_TBL* pColor_ini)
{
    int       nXIdx             = 0;                 
    int       nYIdx             = 0;                 
    int       nColor            = -1;                
    float     fFval             = 0.0;               
    float     fMinValue         = 0.0;               
    int       nMinDiffType      = 1;                 
    int       nDiffType         = 0;                 
    int       nColorKind        = CGI_EN_COLOR_RAIN; 

    if((pImgData == NULL) || (pImg == NULL) || (pColor_ini == NULL))
    {
        return -1;
    }

    if(strcmp(szP_type, "ETOP") == 0)
    {
        nColorKind = CGI_EN_COLOR_UNIT;
    }
    else if(strcmp(szP_type, "VIL") == 0)
    {
        nColorKind   = CGI_EN_COLOR_RAIN;
        nMinDiffType = 0;
    }
    else
    {
        if(strcmp(szUnit, "CZ") == 0)
            nColorKind = CGI_EN_COLOR_UNIT;
        else if(strcmp(szUnit, "DZ") == 0)
            nColorKind = CGI_EN_COLOR_UNIT;
        else if(strcmp(szUnit, "RN") == 0)
            nColorKind = CGI_EN_COLOR_RAIN;
        else if(strcmp(szUnit, "SN") == 0)
            nColorKind = CGI_EN_COLOR_RAIN;

    }

    for(nYIdx = 0; nYIdx < nImgYdim; nYIdx++)
    {
        for(nXIdx = 0; nXIdx < nImgXdim; nXIdx++)
        {
            fFval = pImgData[nYIdx][nXIdx];

            nColor = fnGetColorLevel(fFval, pColor_ini, nColorKind, fMinValue, nMinDiffType, nDiffType);
            if((nColor >= 0) && (nColor < pColor_ini->m_iEchoColorCnt))
            {
                gdImageSetPixel(pImg, nXIdx, nYIdx, rgnColor[nColor]);
            }
        }
    }

    return 0;
}

int fnComp3dEchoDisp(int nImgXdim, int nImgYdim, char szP_type[], char szUnit[], float** pImgData, gdImagePtr pImg, int rgnColor[], CGI_COLOR_TBL* pColor_ini)
{
    int       nCnt               = 0;                   
    int       nXIdx              = 0;                   
    int       nYIdx              = 0;                   
    int       nColor             = -1;                  
    float     fFval              = 0.0;                 
    int       nR                 = 0;                   
    int       nG                 = 0;                   
    int       nB                 = 0;                   
    int       nShade             = 0;                   
    float     fMinValue          = 0.0;                 
    int       nMinDiffType       = 0;                   
    int       nDiffType          = 0;                   
    int       nColorKind         = CGI_EN_COLOR_RAIN;   

    if((pImgData == NULL) || (pImg == NULL) || (pColor_ini == NULL))
    {
        return -1;
    }

    if(strcmp(szP_type, "ETOP") == 0)
    {
        nColorKind = CGI_EN_COLOR_UNIT;
    }
    else if(strcmp(szP_type, "VIL") == 0)
    {
        nColorKind = CGI_EN_COLOR_RAIN;
    }
    else
    {
        if(strcmp(szUnit, "CZ") == 0)
            nColorKind = CGI_EN_COLOR_UNIT;
        else if(strcmp(szUnit, "DZ") == 0)
            nColorKind = CGI_EN_COLOR_UNIT;
        else if(strcmp(szUnit, "RN") == 0)
            nColorKind = CGI_EN_COLOR_RAIN;
        else if(strcmp(szUnit, "SN") == 0)
            nColorKind = CGI_EN_COLOR_RAIN;

    }
    
    for(nCnt = 0; nCnt < pColor_ini->m_iEchoColorCnt; nCnt++)
    {
        for(nYIdx = 1; nYIdx < nImgYdim-1; nYIdx++)
        {
            for(nXIdx = 1; nXIdx < nImgXdim-1; nXIdx++)
            {
                fFval  = pImgData[nYIdx][nXIdx];
            
                nColor = fnGetColorLevel(fFval, pColor_ini, nColorKind, fMinValue, nMinDiffType, nDiffType);
                if(nColor == nCnt)
                {
                    nR     = gdImageRed(pImg, rgnColor[nColor]) - 30;
                    nG     = gdImageGreen(pImg, rgnColor[nColor]) - 30;
                    nB     = gdImageBlue(pImg, rgnColor[nColor]) - 30;
                    nShade = gdImageColorAllocateAlpha(pImg, nR<0? 0:nR, nG<0? 0:nG, nB<0? 0:nB, 0);

                    gdImageSetPixel(pImg, nXIdx, nYIdx, rgnColor[nColor]);
                    gdImageSetPixel(pImg, nXIdx+2, nYIdx+2, nShade);
                }
            }
        }
    }

    return 0;
}

int fnCompTitanDisp(int nImgXdim, int nImgYdim, char szUnit[], float** pImgData, gdImagePtr pImgTitan, int rgnColorTitan[], CGI_COLOR_TBL* pColor_ini)
{
    int       nXIdx         = 0;                    
    int       nYIdx         = 0;                    
    int       nColor        = -1;                   
    float     fFval         = 0.0;                  
    float     fTitan        = 0.0;                  
    float     fMinValue     = 0.0;                  
    int       nDiffType     = 0;                    
    int       nMinDiffType  = 0;                    
    float**   fTempData     = NULL;                 
    int       nColorKind    = CGI_EN_COLOR_RAIN;    

    if((pImgData == NULL) || (pImgTitan == NULL) || (pColor_ini == NULL))
    {
        return -1;
    }

    fTempData = (float **)malloc(nImgYdim*sizeof(float *));
    for(nYIdx = 0; nYIdx < nImgYdim; nYIdx++) 
    {
        fTempData[nYIdx] = (float *)malloc(nImgXdim*sizeof(float));
    }

    if(strcmp(szUnit, "DZ") == 0 || strcmp(szUnit, "CZ") == 0) 
    {
        nColorKind = CGI_EN_COLOR_UNIT;
        fTitan = 40;
    } 
    else 
    {
        nColorKind = CGI_EN_COLOR_RAIN;
        fTitan = 15;
    }

    for(nYIdx=0; nYIdx < nImgYdim; nYIdx++)
    {
        for(nXIdx = 0; nXIdx < nImgXdim; nXIdx++)
        {
            fTempData[nYIdx][nXIdx] = pImgData[nYIdx][nXIdx];
        }
    }

    fTempData = fnCompTitanData(fTempData, nImgXdim, nImgYdim, fTitan);

    for(nYIdx = 0; nYIdx < nImgYdim; nYIdx++)
    {
        for(nXIdx = 0; nXIdx < nImgXdim; nXIdx++)
        {
            fFval = fTempData[nYIdx][nXIdx];
            nColor = fnGetColorLevel(fFval, pColor_ini, nColorKind, fMinValue, nMinDiffType, nDiffType);
            if(nColor >= 0 && nColor < pColor_ini->m_iEchoColorCnt) 
                gdImageSetPixel(pImgTitan, nXIdx, nYIdx, rgnColorTitan[nColor]);
        }
    }

    for(nYIdx = 0; nYIdx < nImgYdim; nYIdx++) 
    {
        free(fTempData[nYIdx]);
    }

    free(fTempData);

    return 0;
}

/* ================================================================================ */
