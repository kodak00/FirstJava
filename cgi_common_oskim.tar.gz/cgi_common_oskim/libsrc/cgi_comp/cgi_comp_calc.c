/* ================================================================================ */
//
// 레이더 에코 영상 GIS - calc.c
//
// 2016.07.29
//
// SnK
//
/* ================================================================================ */
// INCLUDE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cgi_comp_value.h"
#include "cgi_comp_calc.h"

/* ================================================================================ */
// LOCAL FUNTION

static double fnCalcSmoothValue(double dFdj, double dFdi, double dFx, double dFy, double dFz, double dFw)
{
    double dResult = 0;    
    double dX0     = 0;    
    double dX1     = 0;    

    dX0     =  dFx + ( dFw-dFx ) * (double)dFdj / 1.0 ;
    dX1     =  dFy + ( dFz-dFy ) * (double)dFdj / 1.0 ;
    dResult =  dX0 + ( dX1-dX0 ) * (double)dFdi / 1.0 ;

    return dResult;
}

/* ================================================================================ */
// FUNCTION

float fnCalcRadarValueSmooth480(float** pData, int nCompXdim, int nCompYdim, int nDiff_x, int nDiff_y, int nXIdx, int nYIdx, float fXGridScale, float fYGridScale)
{
    double   dCalcX  = 0.0;  
    double   dCalcY  = 0.0; 
    float    fValue  = 0.0; 
    int      nCalcY  = 0;   
    int      nCalcX  = 0;  
    double   dFdi    = 0.0; 
    double   dFdj    = 0.0; 
    double   dFx     = 0.0; 
    double   dFy     = 0.0;  
    double   dFz     = 0.0;
    double   dFw     = 0.0; 

    dCalcX  = ((double)(nXIdx - (double)nDiff_x) / (double)fXGridScale);
    dCalcY  = ((double)(nYIdx - (double)nDiff_y) / (double)fYGridScale);
    
    nCalcX = (int)dCalcX;
    nCalcY = (int)dCalcY;

    if((nCalcX > 0 && nCalcX < nCompXdim-1) && (nCalcY > 0 && nCalcY < nCompYdim-1))
    {
        if(pData[nCalcY][nCalcX] == BOUND_VALUE_F)
        {
            fValue = BOUND_VALUE_F;
            return fValue;
        }
        
        if((dCalcX == nCalcX) && (dCalcY == nCalcY))
        {
            fValue = pData[nCalcY][nCalcX];
        }
        else
        {
            dFdi =  dCalcX - nCalcX;
            dFdj =  dCalcY - nCalcY;

            if((dFdi == 0.0) && (dFdj != 0.0))
            {
                if((nCalcY+1) >= nCompYdim || (nCalcX+0) >= nCompXdim || pData[nCalcY+1][nCalcX+0] < 0) { dFx = 0; }  else{ dFx = pData[nCalcY+1][nCalcX+0];  }
                if((nCalcY+1) >= nCompYdim || (nCalcX+1) >= nCompXdim || pData[nCalcY+1][nCalcX+1] < 0) { dFy = 0; }  else{ dFy = pData[nCalcY+1][nCalcX+1];  }
                if((nCalcY+0) >= nCompYdim || (nCalcX+1) >= nCompXdim || pData[nCalcY+0][nCalcX+1] < 0) { dFz = 0; }  else{ dFz = pData[nCalcY+0][nCalcX+1];  }
                if((nCalcY+0) >= nCompYdim || (nCalcX+0) >= nCompXdim || pData[nCalcY+0][nCalcX+0] < 0) { dFw = 0; }  else{ dFw = pData[nCalcY+0][nCalcX+0];  }
                dFdj = 1.0 - dFdj;

                fValue = fnCalcSmoothValue(dFdj, dFdi, dFx, dFy, dFz ,dFw);
            }
            else if((dFdi != 0.0) && (dFdj == 0.0))
            {
                if((nCalcY+0) >= nCompYdim || (nCalcX+0) >= nCompXdim || pData[nCalcY+0][nCalcX+0] < 0) { dFx = 0; }  else{ dFx = pData[nCalcY+0][nCalcX+0];  }
                if((nCalcY+0) >= nCompYdim || (nCalcX+1) >= nCompXdim || pData[nCalcY+0][nCalcX+1] < 0) { dFy = 0; }  else{ dFy = pData[nCalcY+0][nCalcX+1];  }
                if((nCalcY+1) >= nCompYdim || (nCalcX+1) >= nCompXdim || pData[nCalcY+1][nCalcX+1] < 0) { dFz = 0; }  else{ dFz = pData[nCalcY+1][nCalcX+1];  }
                if((nCalcY+1) >= nCompYdim || (nCalcX+0) >= nCompXdim || pData[nCalcY+1][nCalcX+0] < 0) { dFw = 0; }  else{ dFw = pData[nCalcY+1][nCalcX+0];  }

                fValue = fnCalcSmoothValue(dFdj, dFdi, dFx, dFy, dFz ,dFw);
            }
            else if((dFdi != 0.0) && (dFdj != 0.0))
            {
                if((nCalcY+1) >= nCompYdim || (nCalcX+0) >= nCompXdim || pData[nCalcY+1][nCalcX+0] < 0) { dFx = 0; }  else{ dFx = pData[nCalcY+1][nCalcX+0];  }
                if((nCalcY+1) >= nCompYdim || (nCalcX+1) >= nCompXdim || pData[nCalcY+1][nCalcX+1] < 0) { dFy = 0; }  else{ dFy = pData[nCalcY+1][nCalcX+1];  }
                if((nCalcY+0) >= nCompYdim || (nCalcX+1) >= nCompXdim || pData[nCalcY+0][nCalcX+1] < 0) { dFz = 0; }  else{ dFz = pData[nCalcY+0][nCalcX+1];  }
                if((nCalcY+0) >= nCompYdim || (nCalcX+0) >= nCompXdim || pData[nCalcY+0][nCalcX+0] < 0) { dFw = 0; }  else{ dFw = pData[nCalcY+0][nCalcX+0];  }
                dFdj = 1.0 - dFdj;

                fValue = fnCalcSmoothValue(dFdj, dFdi, dFx, dFy, dFz ,dFw);
            }
        }
    }
    else
    {
        fValue = BOUND_VALUE_F;
    }

    return fValue;
}

float fnCalcRadarValueSmooth(float** pData, int nDataXdim, int nDataYdim, int nDiff_x, int nDiff_y, int nXpoint, int nYpoint, float fXGridScale, float fYGridScale)
{
    float   fValue  = 0.0;
    double  dCalcY  = 0.0;
    double  dCalcX  = 0.0;
    int     nCalcY  = 0;
    int     nCalcX  = 0;
    double  dFdi    = 0;  
    double  dFdj    = 0;  
    double  dFx     = 0;  
    double  dFy     = 0;  
    double  dFz     = 0;  
    double  dFw     = 0;  

    dCalcX  = ((double)(nXpoint - (double)nDiff_x) / (double)fXGridScale);
    dCalcY  = ((double)(nYpoint - (double)nDiff_y) / (double)fYGridScale);

    nCalcX = (int)dCalcX;
    nCalcY = (int)dCalcY;

    if((nCalcX > 0 && nCalcX < nDataXdim-1) && (nCalcY > 0 && nCalcY < nDataYdim-1))
    {
        if(pData[nCalcY][nCalcX] == BOUND_VALUE_F)
        {
            fValue = BOUND_VALUE_F;
            return fValue;
        }

        if((dCalcX == nCalcX) && (dCalcY == nCalcY))
        {
            fValue = pData[nCalcY][nCalcX];
        }
        else
        {
            dFdi =  dCalcX - nCalcX;        
            dFdj =  dCalcY - nCalcY;
            
            if((dFdi == 0.0) && (dFdj != 0.0))
            {
                if(pData[nCalcY+1][nCalcX+0] == BAD_VALUE_F) { dFx = 0; }   else{ dFx = pData[nCalcY+1][nCalcX+0];  }
                if(pData[nCalcY+1][nCalcX+1] == BAD_VALUE_F) { dFy = 0; }   else{ dFy = pData[nCalcY+1][nCalcX+1];  }
                if(pData[nCalcY+0][nCalcX+1] == BAD_VALUE_F) { dFz = 0; }   else{ dFz = pData[nCalcY+0][nCalcX+1];  }
                if(pData[nCalcY+0][nCalcX+0] == BAD_VALUE_F) { dFw = 0; }   else{ dFw = pData[nCalcY+0][nCalcX+0];  }
                dFdj = 1.0 - dFdj;
                
                if(pData[nCalcY+1][nCalcX+0] == BAD_VALUE_F &&
                   pData[nCalcY+1][nCalcX+1] == BAD_VALUE_F &&
                   pData[nCalcY+0][nCalcX+1] == BAD_VALUE_F &&
                   pData[nCalcY+0][nCalcX+0] == BAD_VALUE_F)
                {
                    fValue = BAD_VALUE_F;
                }
                else
                {
                    fValue = fnCalcSmoothValue(dFdj, dFdi, dFx, dFy, dFz , dFw) +0.5;
                }
            }
            else if((dFdi != 0.0) && (dFdj == 0.0))
            {
                if(pData[nCalcY+0][nCalcX+0] == BAD_VALUE_F) { dFx = 0; }   else{ dFx = pData[nCalcY+0][nCalcX+0];  }
                if(pData[nCalcY+0][nCalcX+1] == BAD_VALUE_F) { dFy = 0; }   else{ dFy = pData[nCalcY+0][nCalcX+1];  }                       
                if(pData[nCalcY-1][nCalcX+1] == BAD_VALUE_F) { dFz = 0; }   else{ dFz = pData[nCalcY-1][nCalcX+1];  }               
                if(pData[nCalcY-1][nCalcX+0] == BAD_VALUE_F) { dFw = 0; }   else{ dFw = pData[nCalcY-1][nCalcX+0];  }
                
                if(pData[nCalcY+0][nCalcX+0] == BAD_VALUE_F &&
                   pData[nCalcY+0][nCalcX+1] == BAD_VALUE_F &&
                   pData[nCalcY-1][nCalcX+1] == BAD_VALUE_F &&
                   pData[nCalcY-1][nCalcX+0] == BAD_VALUE_F)
                   {
                       fValue = BAD_VALUE_F;
                   }
                else
                {
                    fValue = fnCalcSmoothValue(dFdj, dFdi, dFx, dFy, dFz , dFw) +0.5;
                }
            }
            else if((dFdi != 0.0) && (dFdj != 0.0))
            {
                if(pData[nCalcY+1][nCalcX+0] == BAD_VALUE_F) { dFx = 0; }   else{ dFx = pData[nCalcY+1][nCalcX+0];  }
                if(pData[nCalcY+1][nCalcX+1] == BAD_VALUE_F) { dFy = 0; }   else{ dFy = pData[nCalcY+1][nCalcX+1];  }
                if(pData[nCalcY+0][nCalcX+1] == BAD_VALUE_F) { dFz = 0; }   else{ dFz = pData[nCalcY+0][nCalcX+1];  }
                if(pData[nCalcY+0][nCalcX+0] == BAD_VALUE_F) { dFw = 0; }   else{ dFw = pData[nCalcY+0][nCalcX+0];  }
                dFdj = 1.0 - dFdj;

                if(pData[nCalcY+1][nCalcX+0] == BAD_VALUE_F &&
                   pData[nCalcY+1][nCalcX+1] == BAD_VALUE_F &&
                   pData[nCalcY+0][nCalcX+1] == BAD_VALUE_F &&
                   pData[nCalcY+0][nCalcX+0] == BAD_VALUE_F)
                {
                    fValue = BAD_VALUE_F;
                }
                else
                {
                    fValue = fnCalcSmoothValue(dFdj, dFdi, dFx, dFy, dFz , dFw) +0.5;
                }
            }
        }
    }
    else
    {
        fValue = BOUND_VALUE_F;
    }
    
    return fValue;
}

float fnCalcRadarValue(float** pData, int nDataXdim, int nDataYdim, int nDiff_x, int nDiff_y, int nXpoint, int nYpoint, float fXGridScale, float fYGridScale)
{
    float   fValue  = 0.0;
    double  dCalcY  = 0.0;
    double  dCalcX  = 0.0;
    int     nCalcY  = 0;
    int     nCalcX  = 0;

    dCalcX  = ((double)(nXpoint - (double)nDiff_x) / (double)fXGridScale);
    dCalcY  = ((double)(nYpoint - (double)nDiff_y) / (double)fYGridScale);

    nCalcX = (int)dCalcX;
    nCalcY = (int)dCalcY;

    if((nCalcX >= 0 && nCalcX < nDataXdim) && (nCalcY >= 0 && nCalcY < nDataYdim))
    {
        fValue = pData[nCalcY][nCalcX];
    }
    else
    {
        fValue = BOUND_VALUE_F;
    }

    return fValue;
}

/* ================================================================================ */
