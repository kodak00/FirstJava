/* ================================================================================ */
// 2016. 7. 29
//
// SnK : Choi Hyun-Jun
//
// 데이터 처리 관련 함수 모음
//
/* ================================================================================ */
// INCLUDE

#include <pthread.h>

#include "cgi_site_common.h"
#include "cgi_cmm_util.h"
#include "cgi_site_uf.h"
#include "cgi_site_data.h"

/* ================================================================================ */
// GLOBAL

static float g_fKdpWaveLen = 0.5;

/* ================================================================================ */
// LOCAL FUNCTION

static float fnDeg60_to_100(int nDeg, int nMin, int nSec)
{
    return (nDeg+(nMin/60.0)+(nSec/3600.0));
}

static double fnDbz_To_Ze_f(double dDbz){
    return pow(10.,(dDbz/10.));
}

static double fnZe_To_Dbz_f(double dZe){
    if (dZe <= 0){
        return 0;
    }
    return (10. * log10(dZe));
}

static float fnGetAzimuth(float fXIdx, float fYIdx)
{
    float fAzimuth = 0.0;

    if (fXIdx < 0.0)
    { // ----------------------------------------------- The first and third plane
        fAzimuth = (atan(fYIdx/fXIdx) * 180.0/PI_DFS) + 270.0;
    }
    else if (fXIdx > 0.0)
    { // ----------------------------------------The second and fourth plane
        fAzimuth = (atan(fYIdx/fXIdx) * 180.0/PI_DFS) + 90.0;
    }else if ((fXIdx == 0.0) && (fYIdx <= 0.0))
    { // Boundary between the first and the second plane
        fAzimuth = 0.0;
    }
    else{ // -------------------------------------  Boundary between the third and the fourth plane
        fAzimuth = 180.0;
    }

    return fAzimuth;
}

static float fnMinusDegree(float fAlpha, float fBeta)
{
    float fMin = 0.0;

    fMin = fAlpha - fBeta;

    if (fAlpha == fBeta)
    {
        return 0.;
    }
    if (fMin > 180.)
    {
        return fMin - 360.;
    }
    else if (fMin < -180.)
    {
        return 360. + fMin;
    }

    return fMin;
}

static float fnDiffDegree(float fAlpha, float fBeta)
{
    return fabs(fnMinusDegree(fAlpha,fBeta));
}

static float fnKD_F(unsigned short nXIdx)
{
    if (nXIdx >= F_OFFSET)
    {
        nXIdx -= F_OFFSET;
        
        if (g_fKdpWaveLen == 0.0)
        {
            return BADVAL;
        }
        if (nXIdx < 128)
        {
            return (float)(-0.25 * pow((double)600.0,(double)((127-nXIdx)/126.0)))/g_fKdpWaveLen;
        }
        else if (nXIdx > 128)
        {
            return (float)(0.25 * pow((double)600.0,(double)((nXIdx-129)/126.0)))/g_fKdpWaveLen;
        }
        else
        {
            return 0.0;
        }
    }
    
    switch(nXIdx)
    {
        case 0:
            return BADVAL;
        case 1:
            return RFVAL;
        case 2:
            return APFLAG;
        case 3:
            return NOECHO;
        default:
            return BADVAL;
    }
}

static unsigned short fnKD_INVF(float fVal)
{
    if(fVal == BADVAL) return (unsigned short)0;
    if(fVal == RFVAL)  return (unsigned short)1;
    if(fVal == APFLAG) return (unsigned short)2;
    if(fVal == NOECHO) return (unsigned short)3;

    if(g_fKdpWaveLen == 0.0) return (unsigned short)0;

    if(fVal < 0)
        fVal = 127 - 126 * (log((double)-fVal) - log((double)(0.25/g_fKdpWaveLen))) / log((double)600.0) + 0.5;
    else if (fVal > 0)
        fVal = 129 + 126 * (log((double)fVal) - log((double)0.25/g_fKdpWaveLen)) / log((double)600.0) + 0.5;
    else
        fVal = 128;

    fVal += F_OFFSET;

    return (unsigned short)fVal;
}

static double fnCwise_Angle_Diff(float fXIdx, float fYIdx)
{
    double dIndx = 0.0;
    
    dIndx = (double)(fYIdx - fXIdx);
    if (dIndx < 0) dIndx += 360;
    return dIndx;
}

static double fnCwise_Angle_Diff2(float fXIdx, float fYIdx)
{
    double dIndx = 0.0;
    
    dIndx = (double)(fXIdx - fYIdx);
    if (dIndx < 0) dIndx += 360;
    return dIndx;
}

static double fnAngle_Diff(float fXIdx, float fYIdx)
{
    double dIndx = 0.0;
    dIndx = fabs((double)(fXIdx - fYIdx));
    if (dIndx > 180) dIndx = 360 - dIndx;
    return dIndx;
}

static int fnClosestRay(ST_UF_DATA* pUf, int nAzim, float fAzim, st_Azimuth* table, int nS)
{
    double dClow = 0.0;
    double dChigh = 0.0;
    double dCclow = 0.0;
    int nLow = 0;
    int nHigh = 0;
    float fAzim_Low = 0.0;
    float fAzim_High = 0.0;
    
    if(pUf == NULL)
        return -1;

    nLow = table[nAzim].m_nCon;
    nHigh = table[nLow].m_nHigh;

    fAzim_Low  = pUf->m_AZIM[nS][nLow];
    fAzim_High = pUf->m_AZIM[nS][nHigh];

    dClow  = fnCwise_Angle_Diff(fAzim, pUf->m_AZIM[nS][nLow]);
    dChigh = fnCwise_Angle_Diff(fAzim, pUf->m_AZIM[nS][nHigh]);
    dCclow = fnCwise_Angle_Diff2(fAzim, pUf->m_AZIM[nS][nLow]);
    
    while((dChigh > dClow) && (dClow != 0))
    {
        if(dClow < dCclow)
        {
            nLow = table[nLow].m_nLow;
            
            nHigh = table[nLow].m_nHigh;
        }
        else
        {
            nLow = table[nLow].m_nHigh;
            nHigh = table[nLow].m_nHigh;
        }
        
        dClow  = fnCwise_Angle_Diff(fAzim, pUf->m_AZIM[nS][nLow]);
        dChigh = fnCwise_Angle_Diff(fAzim, pUf->m_AZIM[nS][nHigh]);
        dCclow = fnCwise_Angle_Diff2(fAzim, pUf->m_AZIM[nS][nLow]);
    }
    
    if(dChigh <= dCclow)
    {
        return nHigh;
    }
    else
    {
        return nLow;
    }
}
static void fnGet_Slantr_And_Elev(ST_UF_DATA *pUf, CAPPI_LOC *pCappiLoc, float fGrange, float fHeight, int nBinIdx)
{
    double dRe          = (6374.0*4.0/3.0);
    double dSlant_r_2   = 0.0;
    double dElev        = 0.0;
    double dSlantr      = 0.0;

    if(pUf == NULL || pCappiLoc == NULL)
        return;

    if(fGrange == 0)
    {
        pCappiLoc[nBinIdx].m_fElev   = 0.0;
        pCappiLoc[nBinIdx].m_fSrange = 0.0;
        return;
    }

    fHeight += dRe;

    dSlant_r_2  = pow(dRe,2.0) + pow(fHeight,2.0) - (2*dRe*fHeight*cos(fGrange/dRe));
    dSlantr     = sqrt(dSlant_r_2);

    dElev        = acos((pow(dRe,2.0) + dSlant_r_2 - pow(fHeight,2.0)) / (2*dRe*(dSlantr)));
    dElev        *= 180.0/M_PI;
    dElev        -= 90.0;

    pCappiLoc[nBinIdx].m_fElev   = dElev;
    pCappiLoc[nBinIdx].m_fSrange = dSlantr;
}

static void fnNewCappi(ST_UF_DATA *pUf, float fHeight, CAPPI_LOC *pCappiLoc, float **ppTempData)
{
    int     nBinIdx     = 0;
    int     nRayIdx     = 0;
    int     nBinNum     = 0;
    float   fGrange      = 0.0;
    float   fStartBin   = 0.0;
    float   fSizeBin    = 0.0;
    
    if(pUf == NULL || ppTempData == NULL || pCappiLoc == NULL)
        return;

    for(nRayIdx = 0; nRayIdx < MAX_NUM_AZIMUTH; nRayIdx++)
    {
        for(nBinIdx = 0; nBinIdx < MAX_NUM_GATES; nBinIdx++)
        {
            ppTempData[nRayIdx][nBinIdx] = BAD_VALUE_F;
        }
    }
    
    for(nBinIdx = 0; nBinIdx < MAX_NUM_GATES; nBinIdx++)
    {
        pCappiLoc[nBinIdx].m_fElev   = 0.0;
        pCappiLoc[nBinIdx].m_fSrange = 0.0;
    }
    
    nBinNum     = pUf->m_nBins[0][0];
    fStartBin   = pUf->m_nRangeBin[0][0]/1000.0;
    fSizeBin    = pUf->m_nGateSize[0][0]/1000.0;
    
    for(nBinIdx = 0; nBinIdx < nBinNum; nBinIdx++)
    {
        fGrange = fStartBin + (nBinIdx * fSizeBin);
        fnGet_Slantr_And_Elev(pUf, pCappiLoc, fGrange, fHeight, nBinIdx);
    }
}

static int fnGetSweep(ST_UF_DATA *pUf, float fElev)
{
    int   nSweepIdx   = 0;
    int   nCIdx       = 0;
    float fDeltaAngle = 91.0;
    float fCheckAngle = 0.0;

    if(pUf == NULL)
        return -1;

    for(nSweepIdx = 0; nSweepIdx < pUf->m_nSweeps; nSweepIdx++)
    {
        fCheckAngle = fabs((double)(pUf->m_fUfElevation[nSweepIdx] - fElev));

        if(fCheckAngle <= fDeltaAngle)
        {
            fDeltaAngle = fCheckAngle;
            nCIdx       = nSweepIdx;
        }
    }

    if(fDeltaAngle <= pUf->m_fV_BeamWidth/2.0)
    {
        return nCIdx;
    }
    else
    {
        return -1;
    }
}

static float fnGetValue(ST_UF_DATA *pUf, float fElev, float fAzimuth, float fSrange, st_Azimuth** table)
{
    int     nSweepIdx   = 0;
    float   fVal         = 0.0;
    float   fRes         = 0.0;
    float   fRm          = 0.0;
    int     nAzim       = 0;
    int     nIdx         = 0;
    double  dCloseDiff  = 0.0;

    if(pUf == NULL || table == NULL)
        return BAD_VALUE_F;

    nSweepIdx = fnGetSweep(pUf, fElev);

    if(nSweepIdx >= 0)
    {
        fRes = 360.0/pUf->m_rgnRays[nSweepIdx];

        nIdx = (int)(fAzimuth/fRes + fRes/2.0);
        nIdx = nIdx % pUf->m_rgnRays[nSweepIdx];

        while(table[nSweepIdx][nIdx].m_nCon == -1)
        {
            nIdx = (nIdx + 1) % pUf->m_rgnRays[nSweepIdx];
        }

        if((nAzim = fnClosestRay(pUf, nIdx, fAzimuth, table[nSweepIdx], nSweepIdx)) < 0)
        {
           return BAD_VALUE_F;
        }

        nAzim = nAzim % pUf->m_rgnRays[nSweepIdx];

        dCloseDiff = fnAngle_Diff(fAzimuth, pUf->m_AZIM[nSweepIdx][nAzim]);

        fRm  = fSrange * 1000.0f;
        nIdx = (int)(fRm / pUf->m_nGateSize[nSweepIdx][nAzim]);
        fVal = (float)(pUf->m_fData[nSweepIdx][nAzim][nIdx]);
    }
    else
    {
        fVal = BAD_VALUE_F;
    }

    return  fVal;
}

static void fnFillCappi(ST_UF_DATA *pUf, st_Azimuth** table, CAPPI_LOC *pCappiLoc, float **ppTempData)
{
    int     nBinIdx     = 0;
    int     nRayIdx     = 0;
    int     nBinNum     = 0;
    float   fValue       = 0.0;

    if(pUf == NULL || pCappiLoc == NULL || ppTempData == NULL)
        return;

    for(nRayIdx = 0; nRayIdx < pUf->m_rgnRays[0]; nRayIdx++)
    {
        nBinNum = pUf->m_nBins[0][nRayIdx];
        for(nBinIdx = 0; nBinIdx < nBinNum; nBinIdx++)
        {
            fValue = fnGetValue(pUf, pCappiLoc[nBinIdx].m_fElev, pUf->m_AZIM[0][nRayIdx], pCappiLoc[nBinIdx].m_fSrange, table);
            ppTempData[nRayIdx][nBinIdx] = fValue;
        }
    }
}

static float* fnKRL_SweepToCart_CAPPI(ST_UF_DATA *pUf, int nXdim, int nYdim, float nRange, float **ppTempData, st_Azimuth* table)
{
    int     nXIdx       = 0;
    int     nYIdx       = 0;
    float   fAzim       = 0.0;
    float   fResult     = 0.0;
    float   fVal        = 0.0;
    int     nCartIdx    = 0;
    int     nIdx        = 0;
    float   fRes        = 0.0;
    float   fRm         = 0.0;
    int     nAzim       = 0;
    float*  pfCartImage = NULL;
    double  dCloseDiff  = 0.0;

    if(nXdim != nYdim || nYdim < 0 || nXdim < 0 || pUf == NULL || ppTempData == NULL)
    {
        return NULL;
    }

    pfCartImage = (float*)calloc(nXdim*nYdim, sizeof(float));
    for(nIdx = 0; nIdx < nXdim*nYdim; nIdx++)
    {
        pfCartImage[nIdx] = BAD_VALUE_F;
    }

    fRes = 360.0/pUf->m_rgnRays[0];

    for(nYIdx =- nYdim/2; nYIdx < nYdim/2; nYIdx++)
    {
        for (nXIdx =- nXdim/2; nXIdx < nXdim/2; nXIdx++)
        { /* Find azimuth and range, then search Volume. */
            fResult = (float)sqrt((double)(nXIdx * nXIdx) + (double)nYIdx * nYIdx);
            if(nYdim < nXdim)
            {
                fResult *= nRange/(.5 * nYdim);
            }
            else {
                fResult *= nRange/(.5 * nXdim);
            }

            if(fResult > nRange)
            {
                fVal = BAD_VALUE_F;
            }
            else
            {
                if(nXIdx !=0 )
                {
                    fAzim = (float)atan((double)nYIdx/(double)nXIdx)*180.0/3.14159;
                }
                else
                {
                    if (nYIdx < 0)  fAzim = -90.0;
                    else        fAzim = 90.0;
                }

                if(nYIdx < 0 && nXIdx < 0)
                {/* Quadrant 3 (math notation). */
                    fAzim -= 180;
                }
                else if(nYIdx >= 0 && nXIdx < 0)
                {/* Quad: 2 */
                    fAzim += 180;
                }
                fAzim = -fAzim;
                fAzim -= 90.0;
                if(fAzim < 0)    fAzim += 360.0;

                nIdx = (int)(fAzim/fRes + fRes/2.0);
                nIdx = nIdx % pUf->m_rgnRays[0];

                while(table[nIdx].m_nCon == -1)
                {
                    nIdx = (nIdx + 1) % pUf->m_rgnRays[0];
                }
                if((nAzim = fnClosestRay(pUf, nIdx, fAzim, table, 0)) < 0)
                {
                    fVal = BAD_VALUE_F;
                }
                else
                {
                    nAzim = nAzim % pUf->m_rgnRays[0];
                    dCloseDiff = fnAngle_Diff(fAzim, pUf->m_AZIM[0][nAzim]);

                    fRm = fResult * 1000.0f;
                    nIdx = (int)(fRm / pUf->m_nGateSize[0][nAzim]);
                    fVal = (float)(ppTempData[nAzim][nIdx]);
                }
            }

            nCartIdx =  (nYIdx + nYdim/2) * nYdim + (nXdim-1)-(nXIdx + nXdim/2);

            if(fVal == BADVAL || fVal == NOTFOUND_V || fVal == NOTFOUND_H )
            {
                pfCartImage[nCartIdx] =  BAD_VALUE_F;
            }
            else
            {
                pfCartImage[nCartIdx] = fVal;
            }

            if(dCloseDiff >  pUf->m_fBeamWidth)
            {
                pfCartImage[nCartIdx] = BAD_VALUE_F;
            }
        }
    }
    return pfCartImage;
}

static float* fnMakeCappi(ST_UF_DATA *pUf, float fHeight, st_Azimuth** table, int nXdim, int nYdim, int nRange)
{
    float       **ppTempData    = NULL;
    CAPPI_LOC   *pCappiLoc      = NULL;
    float       *pCappiData     = NULL;

    if(pUf == NULL || table == NULL)
        return NULL;

    if((ppTempData = fnGetMatrixFloat(MAX_NUM_AZIMUTH, MAX_NUM_GATES)) == NULL)
        return NULL;
    
    if((pCappiLoc = (CAPPI_LOC *)calloc(MAX_NUM_GATES, sizeof(CAPPI_LOC))) == NULL)
    {
        fnFreeMatrixFloat(ppTempData, MAX_NUM_AZIMUTH);
        return NULL;
    }

    fnNewCappi(pUf, fHeight, pCappiLoc, ppTempData);

    fnFillCappi(pUf, table, pCappiLoc, ppTempData);

    pCappiData = fnKRL_SweepToCart_CAPPI(pUf, nXdim, nYdim, nRange, ppTempData, table[0]);

    fnFreeMatrixFloat(ppTempData, MAX_NUM_AZIMUTH);
    free(pCappiLoc);

    return pCappiData;
}

static void* fnMakeCappiThread(void *arg)
{
    st_VilCappiThrArg   *thrArg = (st_VilCappiThrArg *)arg;
    float               *pData  = NULL;

    pData = fnMakeCappi(thrArg->m_pUf,   thrArg->m_nHeight, thrArg->m_ppTable,
                        thrArg->m_nXdim, thrArg->m_nYdim,   thrArg->m_nRange);

    thrArg->m_ppData[thrArg->m_nIdx] = pData;

    return (void *)0;
}

static void fnMakeVilThreadAction(float **ppData, int nHeight, int nStartIdx, int nEndIdx, float *pVilData)
{
    int         nIdx        = 0;
    int         nJIdx       = 0;
    double      dSum        = 0.0;
    float       fZ_Idx      = 0.0;
    float       fZ_Idx2     = 0.0;
    float       fDh         = 0.0;

    fDh = 1000;
    for(nIdx = nStartIdx; nIdx < nEndIdx; nIdx++)
    {
        dSum = 0;
        for(nJIdx = 0; nJIdx < nHeight; nJIdx++)
        {
            if(ppData[nJIdx] == NULL)
                continue;

            if(nJIdx == nHeight - 1)
            {
                if(ppData[nJIdx][nIdx] > 0)
                {
                    fZ_Idx = fnDbz_To_Ze_f(ppData[nJIdx][nIdx]);
                    dSum += 3.44 * pow(10.,-6.) * pow(fZ_Idx, 4./7.)*fDh;
                }
            }
            else
            {
                if(ppData[nJIdx][nIdx] > 0 && ppData[nJIdx+1][nIdx] > 0)
                {
                    fZ_Idx = fnDbz_To_Ze_f(ppData[nJIdx][nIdx]);
                    fZ_Idx2 = fnDbz_To_Ze_f(ppData[nJIdx+1][nIdx]);
                    dSum += 3.44 * pow(10.,-6.) * pow((fZ_Idx+fZ_Idx2)/2.,4./7.)*fDh;
                }
                else if(ppData[nJIdx][nIdx] > 0)
                {
                    //fZ_Idx = fnDbz_To_Ze_f(ppData[nJIdx][nIdx]);
                    dSum += 3.44 * pow(10., -6.) * pow(fZ_Idx, 4./7.) * fDh;
                }
            }
        }
        if(dSum > 0)
        {
            pVilData[nIdx] = dSum;
        }

        else
        {
            pVilData[nIdx] = BAD_VALUE_F;
        }
    }
}

static void* fnMakeVilThread(void *arg)
{
    st_VilThrArg       *thrArg = (st_VilThrArg *)arg;

    fnMakeVilThreadAction(thrArg->m_ppData, thrArg->m_nHeight, thrArg->m_nStartIdx, 
                          thrArg->m_nEndIdx, thrArg->m_pVilData);

    return (void *)0;
}

static float fnCalMohrCappiValue(ST_UF_DATA *pUf, st_CloestSweeps CloestSweeps, float fAzimuth, float fElevation, float fSlantRange, CAPPI_TYPE pseudo_cappi, int nIs_Dbz)
{
    int     nIdx            = 0;
    float   fResult       = BAD_VALUE_F;
    float   fdR           = 1.;
    float   fdT           = 1.;
    float   fR_Ri         = 0.0;
    float   fR_Rip1       = 0.0;//R-R_i,R-R_(i+1)
    float   fT_Tj         = 0.0;
    float   fT_Tjp1       = 0.0;//T-T_i,T-T_(j+1)
    float   fZe_i_j       = 0.0;
    float   fZe_ip1_j     = 0.0;
    float   fZe_i_jp1     = 0.0;
    float   fZe_ip1_jp1   = 0.0;
    float   rgfZe_R_T[2]  = {0.0};
    float   fZe_R_T_temp1 = 0.0;
    float   fZe_R_T_temp2 = 0.0;
    float   fdP           = 0.0;
    float   fP_Pk         = 0.0;
    float   fP_Pkp1       = 0.0;
    int     nProcessed    = 0;

    if(pUf == NULL)
        return BAD_VALUE_F;

    if (!CloestSweeps.m_tAzims[0].m_tValues[0].m_rgnValid[0] &&
            !CloestSweeps.m_tAzims[0].m_tValues[0].m_rgnValid[1] &&
            !CloestSweeps.m_tAzims[0].m_tValues[1].m_rgnValid[0] &&
            !CloestSweeps.m_tAzims[0].m_tValues[1].m_rgnValid[1] &&
            !CloestSweeps.m_tAzims[1].m_tValues[0].m_rgnValid[0] &&
            !CloestSweeps.m_tAzims[1].m_tValues[0].m_rgnValid[1] &&
            !CloestSweeps.m_tAzims[1].m_tValues[1].m_rgnValid[0] &&
            !CloestSweeps.m_tAzims[1].m_tValues[1].m_rgnValid[1])
    {
        return BAD_VALUE_F;
    }

    switch (pseudo_cappi)
    {
        case PSEUDO_CAPPI : break;
        case REAL_CAPPI :
                            if (CloestSweeps.m_rgnValid[1] && !CloestSweeps.m_rgnValid[0] && CloestSweeps.m_rgnS[1] == 0)
                            {
                                if (fElevation < pUf->m_fUfElevation[CloestSweeps.m_rgnS[1]])
                                {
                                    return BAD_VALUE_F;
                                }
                            }
                            break;
        default : return -9999;
    }
    for (nIdx = 0 ; nIdx < 2 ; nIdx++ )
    {
        fR_Ri = 0.5;
        fR_Rip1 = -0.5;
        fT_Tj = 1.;
        fT_Tjp1 = -1.;
        fZe_i_j = 0.;
        fZe_ip1_j = 0.;
        fZe_i_jp1 = 0.;
        fZe_ip1_jp1 = 0.;
        rgfZe_R_T[nIdx] = 0.;

        if (!CloestSweeps.m_rgnValid[nIdx])   continue;


        if (CloestSweeps.m_tAzims[nIdx].m_rgnAzim[0] != -1)
        {
            fR_Ri = (pUf->m_nGateSize[CloestSweeps.m_rgnS[nIdx]][CloestSweeps.m_tAzims[nIdx].m_rgnAzim[0]] / 1000.) / 2.;
            fR_Rip1 = -1. * fR_Ri;
            fdR = pUf->m_nGateSize[CloestSweeps.m_rgnS[nIdx]][CloestSweeps.m_tAzims[nIdx].m_rgnAzim[0]] / 1000.;
        }

        if (CloestSweeps.m_tAzims[nIdx].m_rgfTheta[0] != -250.f  && CloestSweeps.m_tAzims[nIdx].m_rgfTheta[1] != -250.f )
        {
            fT_Tj = fnDiffDegree(CloestSweeps.m_tAzims[nIdx].m_rgfTheta[0], CloestSweeps.m_tAzims[nIdx].m_rgfTheta[1]) / 2.;
            fT_Tjp1 = -1. * fT_Tj;
            fdT = fnDiffDegree(CloestSweeps.m_tAzims[nIdx].m_rgfTheta[0], CloestSweeps.m_tAzims[nIdx].m_rgfTheta[1]);
        }

        if (CloestSweeps.m_tAzims[nIdx].m_rgnValid[0])
        {
            fT_Tj =   fnMinusDegree(fAzimuth, CloestSweeps.m_tAzims[nIdx].m_rgfTheta[0]);
        }
        if (CloestSweeps.m_tAzims[nIdx].m_rgnValid[1])
        {
            fT_Tjp1 = fnMinusDegree(fAzimuth, CloestSweeps.m_tAzims[nIdx].m_rgfTheta[1]);
        }

        if (CloestSweeps.m_tAzims[nIdx].m_rgnValid[0])
        {
            if (CloestSweeps.m_tAzims[nIdx].m_tValues[0].m_rgnValid[0])
            {
                if (nIs_Dbz)
                    fZe_i_j = fnDbz_To_Ze_f(CloestSweeps.m_tAzims[nIdx].m_tValues[0].m_rgfDbz[0]);
                else
                    fZe_i_j = CloestSweeps.m_tAzims[nIdx].m_tValues[0].m_rgfDbz[0];
            }
            if (CloestSweeps.m_tAzims[nIdx].m_tValues[0].m_rgnValid[1])
            {
                if (nIs_Dbz)
                    fZe_ip1_j = fnDbz_To_Ze_f(CloestSweeps.m_tAzims[nIdx].m_tValues[0].m_rgfDbz[1]);
                else
                    fZe_ip1_j = CloestSweeps.m_tAzims[nIdx].m_tValues[0].m_rgfDbz[1];
            }
        }
        
        if (CloestSweeps.m_tAzims[nIdx].m_rgnValid[1])
        {
            if (CloestSweeps.m_tAzims[nIdx].m_tValues[1].m_rgnValid[0])
            {
                if (nIs_Dbz)
                    fZe_i_jp1 = fnDbz_To_Ze_f(CloestSweeps.m_tAzims[nIdx].m_tValues[1].m_rgfDbz[0]);
                else
                    fZe_i_jp1 = CloestSweeps.m_tAzims[nIdx].m_tValues[1].m_rgfDbz[0];
            }
            if (CloestSweeps.m_tAzims[nIdx].m_tValues[1].m_rgnValid[1])
            {
                if (nIs_Dbz)
                    fZe_ip1_jp1 = fnDbz_To_Ze_f(CloestSweeps.m_tAzims[nIdx].m_tValues[1].m_rgfDbz[1]);
                else
                    fZe_ip1_jp1 = CloestSweeps.m_tAzims[nIdx].m_tValues[1].m_rgfDbz[1];
            }
        }

        if (CloestSweeps.m_tAzims[nIdx].m_tValues[0].m_rgnValid[0])
        {
            fR_Ri = (fSlantRange - (
                        CloestSweeps.m_tAzims[nIdx].m_tValues[0].m_rgnBinNum[0] *
                        pUf->m_nGateSize[CloestSweeps.m_rgnS[nIdx]][CloestSweeps.m_tAzims[nIdx].m_rgnAzim[0]]  +
                        pUf->m_nRangeBin[CloestSweeps.m_rgnS[nIdx]][CloestSweeps.m_tAzims[nIdx].m_rgnAzim[0]])) / 1000.;

            fdR = pUf->m_nGateSize[CloestSweeps.m_rgnS[nIdx]][CloestSweeps.m_tAzims[nIdx].m_rgnAzim[0]] / 1000.;
        }
        else if (CloestSweeps.m_tAzims[nIdx].m_tValues[1].m_rgnValid[0])
        {
            fR_Ri = (fSlantRange - (
                        CloestSweeps.m_tAzims[nIdx].m_tValues[1].m_rgnBinNum[0] *
                        pUf->m_nGateSize[CloestSweeps.m_rgnS[nIdx]][CloestSweeps.m_tAzims[nIdx].m_rgnAzim[1]] +
                        pUf->m_nRangeBin[CloestSweeps.m_rgnS[nIdx]][CloestSweeps.m_tAzims[nIdx].m_rgnAzim[1]])) / 1000.;

            fdR = pUf->m_nGateSize[CloestSweeps.m_rgnS[nIdx]][CloestSweeps.m_tAzims[nIdx].m_rgnAzim[1]] / 1000.;
        }

        if (CloestSweeps.m_tAzims[nIdx].m_tValues[0].m_rgnValid[1])
        {
            fR_Rip1 = (fSlantRange - (
                        CloestSweeps.m_tAzims[nIdx].m_tValues[0].m_rgnBinNum[1] *
                        pUf->m_nGateSize[CloestSweeps.m_rgnS[nIdx]][CloestSweeps.m_tAzims[nIdx].m_rgnAzim[0]] +
                        pUf->m_nRangeBin[CloestSweeps.m_rgnS[nIdx]][CloestSweeps.m_tAzims[nIdx].m_rgnAzim[0]])) / 1000.;

            fdR =  pUf->m_nGateSize[CloestSweeps.m_rgnS[nIdx]][CloestSweeps.m_tAzims[nIdx].m_rgnAzim[0]] / 1000.;
        }
        else if (CloestSweeps.m_tAzims[nIdx].m_tValues[1].m_rgnValid[1])
        {
            fR_Rip1 = (fSlantRange - (
                        CloestSweeps.m_tAzims[nIdx].m_tValues[1].m_rgnBinNum[1] *
                        pUf->m_nGateSize[CloestSweeps.m_rgnS[nIdx]][CloestSweeps.m_tAzims[nIdx].m_rgnAzim[1]] +
                        pUf->m_nRangeBin[CloestSweeps.m_rgnS[nIdx]][CloestSweeps.m_tAzims[nIdx].m_rgnAzim[1]])) / 1000.;

            fdR =  pUf->m_nGateSize[CloestSweeps.m_rgnS[nIdx]][CloestSweeps.m_tAzims[nIdx].m_rgnAzim[1]] / 1000.;
        }
        if (CloestSweeps.m_tAzims[nIdx].m_rgnValid[0] && CloestSweeps.m_tAzims[nIdx].m_rgnValid[1])
        {
            fdT = fnDiffDegree(CloestSweeps.m_tAzims[nIdx].m_rgfTheta[1], CloestSweeps.m_tAzims[nIdx].m_rgfTheta[0]);
            fZe_R_T_temp1 = fR_Ri * ((fT_Tj * fZe_ip1_jp1) - (fT_Tjp1 * fZe_ip1_j));
            fZe_R_T_temp2 = fR_Rip1 * ((fT_Tj * fZe_i_jp1) - (fT_Tjp1 * fZe_i_j));

            rgfZe_R_T[nIdx] = (1/(fdR*fdT)) * (fZe_R_T_temp1 - fZe_R_T_temp2);
        }

        else if (CloestSweeps.m_tAzims[nIdx].m_rgnValid[0])
        {
            rgfZe_R_T[nIdx] = (1/(fdR)) * (fR_Ri * fZe_ip1_j - fR_Rip1 * fZe_i_j);
        }
        else if (CloestSweeps.m_tAzims[nIdx].m_rgnValid[1])
        {
            rgfZe_R_T[nIdx] = (1/(fdR)) * (fR_Ri * fZe_i_jp1 - fR_Rip1 * fZe_ip1_jp1);
        }
        else
        {
            return BAD_VALUE_F;
        }

        nProcessed++;
    }

    if (nProcessed <= 0)
    {
        return BAD_VALUE_F;
    }


    fdP = 1.;
    fP_Pk = 0.5;
    fP_Pkp1 = 0.5;


    if (CloestSweeps.m_rgnValid[0] && CloestSweeps.m_rgnValid[1])
    {
        if (fElevation == CloestSweeps.m_rgfPhi[0])
        {
            fResult = rgfZe_R_T[0];
        }
        else if (fElevation == CloestSweeps.m_rgfPhi[1])
        {
            fResult = rgfZe_R_T[1];
        }
        else
        {
            fdP = fnDiffDegree(CloestSweeps.m_rgfPhi[1],CloestSweeps.m_rgfPhi[0]);
            if (CloestSweeps.m_rgnValid[0])
            {
                fP_Pk = fnMinusDegree(fElevation, CloestSweeps.m_rgfPhi[0]);
            }

            if (CloestSweeps.m_rgnValid[1])
            {
                fP_Pkp1 = fnMinusDegree(fElevation, CloestSweeps.m_rgfPhi[1]);
            }
            fResult = (1/fdP) * (fP_Pk * rgfZe_R_T[1] - fP_Pkp1 * rgfZe_R_T[0]);
        }
    }
    else if (CloestSweeps.m_rgnValid[0] && !CloestSweeps.m_rgnValid[1])
    {
        fResult = rgfZe_R_T[0];
    }
    else if (!CloestSweeps.m_rgnValid[0] && CloestSweeps.m_rgnValid[1])
    {
        fResult = rgfZe_R_T[1];
    }
    else
    {
        return BAD_VALUE_F;
    }

    if (nIs_Dbz)
        return fnZe_To_Dbz_f(fResult);
    else
        return fResult;
}

static st_CloestValues fnGetCloest_2_Bins(ST_UF_DATA *pUf, int nIdx, int nAzim, float fRange)
{
    st_CloestValues CloestValues;
    float   fBinNum     = 0.0;
    int     nBinNum1    = 0;
    int     nBinNum2    = 0;
    float   fGateSize   = 0.0;
    float   fRangeBin   = 0.0;
    int16   nBins       = 0;

    CloestValues.m_rgfDbz[0] = BAD_VALUE_F;
    CloestValues.m_rgfDbz[1] = BAD_VALUE_F;
    CloestValues.m_rgnValid[0] = 0;
    CloestValues.m_rgnValid[1] = 0;
    CloestValues.m_rgnBinNum[0] = -1;
    CloestValues.m_rgnBinNum[1] = -1;
    CloestValues.m_rgfR[0] = -1.0f;
    CloestValues.m_rgfR[1] = -1.0f;

    if (pUf == NULL || nIdx == -1 || nAzim == -1)
        return CloestValues;

    fRangeBin  = pUf->m_nRangeBin[nIdx][nAzim];
    fGateSize  = pUf->m_nGateSize[nIdx][nAzim];
    nBins      = pUf->m_nBins[nIdx][nAzim];

    fBinNum  = (fRange - fRangeBin) / (fGateSize * 1.0);
    nBinNum1 = (int)(fBinNum);
    nBinNum2 = (int)(fBinNum + 1);

    if ((nBinNum1 < nBins) && (nBinNum1 >= 0) && (pUf->m_fData[nIdx][nAzim][nBinNum1] != BADVAL))
    {
        CloestValues.m_rgfDbz[0] = pUf->m_fData[nIdx][nAzim][nBinNum1];
        CloestValues.m_rgnBinNum[0] = nBinNum1;
        CloestValues.m_rgnValid[0] = 1;
        CloestValues.m_rgfR[0] = nBinNum1;
    }

    if ((nBinNum2 < nBins) && (nBinNum2 >= 0) && (pUf->m_fData[nIdx][nAzim][nBinNum2] != BADVAL))
    {
        CloestValues.m_rgfDbz[1] = pUf->m_fData[nIdx][nAzim][nBinNum2];
        CloestValues.m_rgnBinNum[1] = nBinNum2;
        CloestValues.m_rgnValid[1] = 1;
        CloestValues.m_rgfR[1] = nBinNum2;
    }
    return CloestValues;
}


static st_CloestAzims fnGetCloest_2_Azims(ST_UF_DATA *pUf,int nSIdx, float fAzimuth, float fLimit, st_Azimuth** table)
{
    int    nIdx         = 0;
    int    nAzim        = 0;
    int    nCwRay       = 0;
    int    nCcwRay      = 0;
    int    nRayTemp1    = -1;
    int    nRayTemp2    = -1;
    float  fRes         = 0.0;
    double dCloseDiff   = 0.0;

    st_CloestAzims CloestAzims = { { 0, 0 }, { -1, -1 }, { -250.0f, -250.0f }};

    if (pUf == NULL || nSIdx == -1)
        return CloestAzims;

    fRes = 360.0/pUf->m_rgnRays[nSIdx];
    nIdx = (int)(fAzimuth/fRes + fRes/2.0);
    nIdx = nIdx % pUf->m_rgnRays[nSIdx];

    while(table[nSIdx][nIdx].m_nCon == -1)
    {
        nIdx = (nIdx + 1) % pUf->m_rgnRays[nSIdx];
    }
    
    if((nAzim = fnClosestRay(pUf, nIdx, fAzimuth, table[nSIdx], nSIdx)) < 0)
        return CloestAzims;

    dCloseDiff = fnAngle_Diff(fAzimuth, pUf->m_AZIM[nSIdx][nAzim]);

    if(dCloseDiff <= fLimit)
    {
        nRayTemp1 = nAzim;
        nCwRay = table[nSIdx][nAzim].m_nHigh;
        nCcwRay = table[nSIdx][nAzim].m_nLow;
    }
    else
    {
        return CloestAzims;
    }
    if ((nCwRay != -1) && (fnDiffDegree(pUf->m_AZIM[nSIdx][nCwRay], fAzimuth) <= fLimit) &&
            (nCcwRay != -1) && (fnDiffDegree(pUf->m_AZIM[nSIdx][nCcwRay], fAzimuth) <= fLimit))
    {
        if (fnDiffDegree(pUf->m_AZIM[nSIdx][nCwRay], fAzimuth) > fnDiffDegree(pUf->m_AZIM[nSIdx][nCcwRay], fAzimuth))
        {
            nRayTemp2 = nCcwRay;
        }
        else
        {
            nRayTemp2 = nCwRay;
        }
    }
    else if ((nCwRay != -1) && (fnDiffDegree(pUf->m_AZIM[nSIdx][nCwRay], fAzimuth) <= fLimit))
    {
        nRayTemp2 = nCwRay;
    }
    else if ((nCcwRay != -1) && (fnDiffDegree(pUf->m_AZIM[nSIdx][nCcwRay], fAzimuth) <= fLimit))
    {
        nRayTemp2 = nCcwRay;
    }

    if(nRayTemp1 != -1)
    {
        if (fnMinusDegree(pUf->m_AZIM[nSIdx][nRayTemp1], fAzimuth) < 0)
        {
            CloestAzims.m_rgnAzim[0] = nRayTemp1;
            CloestAzims.m_rgnValid[0] = 1;
            CloestAzims.m_rgfTheta[0] = pUf->m_AZIM[nSIdx][nRayTemp1];
        }
        else
        {
            CloestAzims.m_rgnAzim[1] = nRayTemp1;
            CloestAzims.m_rgnValid[1] = 1;
            CloestAzims.m_rgfTheta[1] = pUf->m_AZIM[nSIdx][nRayTemp1];
        }
    }

    if (nRayTemp2 != -1)
    {
        if (fnMinusDegree(pUf->m_AZIM[nSIdx][nRayTemp2], fAzimuth) < 0)
        {
            CloestAzims.m_rgnAzim[0] = nRayTemp2;
            CloestAzims.m_rgnValid[0] = 1;
            CloestAzims.m_rgfTheta[0] = pUf->m_AZIM[nSIdx][nRayTemp2];
        }
        else
        {
            CloestAzims.m_rgnAzim[1] = nRayTemp2;
            CloestAzims.m_rgnValid[1] = 1;
            CloestAzims.m_rgfTheta[1] = pUf->m_AZIM[nSIdx][nRayTemp2];
        }
    }
    return CloestAzims;
}

static int fnGetClosestSweep_2_Index(ST_UF_DATA *pUf, float fSweepAngle, int* pnSweepIndex1, int* pnSweepIndex2)
{
    int nIdx          = 0;
    int nCi1          = -1;
    int nCi2          = -1;
    float fDeltaAngle = 91;
    float fCheckAngle = 0.0;
    int nSweeps       = 0;

    if(pUf == NULL)
        return -1;

    nSweeps = pUf->m_nSweeps;
    for (nIdx = 0; nIdx < nSweeps; nIdx++)
    {
        fCheckAngle = fnDiffDegree(pUf->m_fUfElevation[nIdx], fSweepAngle);

        if (pUf->m_fUfElevation[nIdx] > fSweepAngle)
        {
            break;
        }

        if(fCheckAngle <= fDeltaAngle)
        {
            fDeltaAngle = fCheckAngle;
            nCi1 = nIdx;
        }
    }

    fDeltaAngle = 91;
    for (nIdx = nSweeps - 1; nIdx >= 0 ; nIdx--)
    {
        if (nCi1 == nIdx)
            continue;

        fCheckAngle = fnDiffDegree(pUf->m_fUfElevation[nIdx], fSweepAngle);

        if (pUf->m_fUfElevation[nIdx] < fSweepAngle)
        {
            break;
        }

        if(fCheckAngle <= fDeltaAngle)
        {
            fDeltaAngle = fCheckAngle;
            nCi2 = nIdx;
        }
    }

    if ((nCi1 - nCi2) < 0)
    {
        if(pnSweepIndex1 != NULL) *pnSweepIndex1 = nCi1;
        if(pnSweepIndex2 != NULL) *pnSweepIndex2 = nCi2;
    }else
    {
        if(pnSweepIndex1 != NULL) *pnSweepIndex1 = nCi2;
        if(pnSweepIndex2 != NULL) *pnSweepIndex2 = nCi1;
    }

    return 0;
}

static float fnGetSlantRange(float fX, float fY, float fHeight,float fGridSize)
{
    float fRange_X = 0.0;
    float fRange_Y = 0.0;
    float fRange_Z = 0.0;

    fRange_X = fX * fGridSize;
    fRange_Y = fY * fGridSize;
    fRange_Z = fHeight;// * fGridSize;

    return sqrt(pow(fRange_X,2)+pow(fRange_Y,2)+pow(fRange_Z,2));
}

static float fnGetElevation(float fX, float fY, float fH, float fGridSize)
{
    double dAe      = 0.0;
    double dR       = 0.0;
    float fResult   = 0.0;

    dR  = fnGetSlantRange(fX, fY, fH, fGridSize);
    dAe = (MAP_RE * 1000.)*4./3.;

    //Doviak and Zrnic, 1993
    fResult = (180./PI_DFS) * asin((fH*fH - dR*dR + 2*dAe*fH) / (2*dR*dAe));

    return fResult;
}

static st_CloestSweeps fnGetCloest_2_Sweeps(ST_UF_DATA *pUf, float fElevation, float fLimit)
{
    st_CloestSweeps CloestSweeps;
    int nSweepIndex1 = 0;
    int nSweepIndex2 = 0;

    CloestSweeps.m_rgnS[0]      = -1;
    CloestSweeps.m_rgnValid[0]  = 0;
    CloestSweeps.m_rgfPhi[0]    = -250.0f;
    CloestSweeps.m_rgnS[1]      = -1;
    CloestSweeps.m_rgnValid[1]  = 0;
    CloestSweeps.m_rgfPhi[1]    = -250.0f;

    if(pUf == NULL)
        return CloestSweeps;

    if (fnGetClosestSweep_2_Index(pUf, fElevation, &nSweepIndex1,&nSweepIndex2) < 0)
    {
        CloestSweeps.m_rgnValid[0] = 0;
        CloestSweeps.m_rgnValid[1] = 0;
        return CloestSweeps;
    }

    if ((nSweepIndex1 >= 0) && fnDiffDegree(fElevation, pUf->m_fUfElevation[nSweepIndex1]) <= fLimit)
    {
        CloestSweeps.m_rgnS[0]      = nSweepIndex1;
        CloestSweeps.m_rgnValid[0]  = 1;
        CloestSweeps.m_rgfPhi[0]    = pUf->m_fUfElevation[nSweepIndex1];
    }
    else
    {
        CloestSweeps.m_rgnS[0]      = -1;
        CloestSweeps.m_rgnValid[0]  = 0;
    }

    if ((nSweepIndex2 >= 0) && fnDiffDegree(fElevation, pUf->m_fUfElevation[nSweepIndex2]) <= fLimit)
    {
        CloestSweeps.m_rgnS[1]      = nSweepIndex2;
        CloestSweeps.m_rgnValid[1]  = 1;
        CloestSweeps.m_rgfPhi[1]    = pUf->m_fUfElevation[nSweepIndex2];
    }else
    {
        CloestSweeps.m_rgnS[1]      = -1;
        CloestSweeps.m_rgnValid[1]  = 0;
    }
    return CloestSweeps;
}



/* ================================================================================ */
// FUNCTION

float fnCAPPI_At_h_Cart(ST_UF_DATA *pUf, float fHeight_Km, int nXdim, int nYdim, float fGridSize_Km, int nXIdx, int nYIdx, CAPPI_TYPE pseudo_cappi, int nIs_Dbz, int nIsCross, st_Azimuth** table)
{
    int     nCnt1           = 0;
    int     nCnt2           = 0;
    int     nCnt3           = 0;
    float   fCenter_X       = 0.0;
    float   fCenter_Y       = 0.0;
    float   fPoint_X        = 0.0;
    float   fPoint_Y        = 0.0;
    float   fGridSize_m     = 0.0;//(m)
    float   fElevation      = 0.0;
    float   fAzimuth        = 0.0;
    float   fHeight_m       = 0.0;//(m)
    float   fImsiData       = 0.0;
    float   fSlantRange     = 0.0;
    st_CloestSweeps CloestSweeps;
    float   fElevationLimit = 0.0;
    float   fAzimuthLimit   = 0.0;

    fGridSize_m = fGridSize_Km * 1000.;

    if(pUf == NULL)
        return BAD_VALUE_F;

    if(nIsCross == 1)
    {
        fElevationLimit = CROSS_ELEVATION_LIMIT;
        fAzimuthLimit = CROSS_AZIMUTH_LIMIT;
    }
    else
    {
        fElevationLimit = ELEVATION_LIMIT;
        fAzimuthLimit = AZIMUTH_LIMIT;
    }

    fHeight_m = fHeight_Km * 1000.;

    fCenter_X = (nXdim-1)/2.;
    fCenter_Y = (nYdim-1)/2.;

    for (nCnt1 = 0; nCnt1 < 2; nCnt1++ )
    {
        CloestSweeps.m_rgnValid[nCnt1] = 0;
        CloestSweeps.m_rgnS[nCnt1]     = -1;

        for (nCnt2 = 0; nCnt2 < 2; nCnt2++ )
        {
            CloestSweeps.m_tAzims[nCnt1].m_rgnValid[nCnt2] = 0;
            CloestSweeps.m_tAzims[nCnt1].m_rgnAzim[nCnt2]  = -1;

            for (nCnt3 = 0; nCnt3 < 2; nCnt3++ )
            {
                CloestSweeps.m_tAzims[nCnt1].m_tValues[nCnt2].m_rgnValid[nCnt3]  = 0;
                CloestSweeps.m_tAzims[nCnt1].m_tValues[nCnt2].m_rgfDbz[nCnt3]    = -127;
                CloestSweeps.m_tAzims[nCnt1].m_tValues[nCnt2].m_rgnBinNum[nCnt3] = -1;
                CloestSweeps.m_tAzims[nCnt1].m_tValues[nCnt2].m_rgfR[nCnt3]      = -1.0f;
            }
        }
    }

    fPoint_X = nXIdx - fCenter_X;
    fPoint_Y = nYIdx - fCenter_Y;
    fSlantRange = fnGetSlantRange(fPoint_X,fPoint_Y, fHeight_m, fGridSize_m);
    fElevation = fnGetElevation(fPoint_X,fPoint_Y, fHeight_m, fGridSize_m);
    fAzimuth = fnGetAzimuth(fPoint_X, fPoint_Y);

    CloestSweeps = fnGetCloest_2_Sweeps(pUf, fElevation, fElevationLimit);

    for (nCnt1 = 0; nCnt1 < 2; nCnt1++ )
    {
        CloestSweeps.m_tAzims[nCnt1] = fnGetCloest_2_Azims(pUf, CloestSweeps.m_rgnS[nCnt1], fAzimuth, fAzimuthLimit, table);

        for (nCnt2 = 0; nCnt2 < 2; nCnt2++ )
        {
            CloestSweeps.m_tAzims[nCnt1].m_tValues[nCnt2] =
                fnGetCloest_2_Bins(pUf, 
                        CloestSweeps.m_rgnS[nCnt1],
                        CloestSweeps.m_tAzims[nCnt1].m_rgnAzim[nCnt2],
                        fSlantRange
                        );

        }
    }

    fImsiData = fnCalMohrCappiValue(pUf, CloestSweeps, fAzimuth, fElevation, fSlantRange, pseudo_cappi, nIs_Dbz);

    return fImsiData;
}


ST_UF_DATA* fnReadUfFile(char *szFilename, char *szField, float fAzimuthCorrection)
{
    ST_UF_DATA*             pUf             = NULL;
    mandatory_header_block  header;
    uf_un_field_header      un_header;

    gzFile                  gz_file         = NULL;
    int                     nFirstWord      = 0;
    int                     nEndWord        = 0;
    short                   nTail           = -1;
    int                     nTailChkCnt     = 0;
    int16                   nSweepNumber    = 0;
    int16                   nRayNumber      = 1;
    int16                   nAzimuth        = 0;
    int16                   nFieldCounter   = 0;
    int16                   nRecordRay      = 0;
    int16                   nFieldsRay      = 0;
    int                     nMovepoint      = 0;
    char                    szDummy[28]     = {0,};
    float                   fTemp           = 0.0;
    int16                   *pnBuff         = NULL;
    int16                   nBinCnt         = 0;
    int16                   nMiss           = 0;
    int16                   nDataScale      = 0;
    int16                   nVal            = 0;
    int                     nIdx            = 0;
    int                     nRayIdx         = 0;
    int                     nBinIdx         = 0;
    int                     nBin            = 0;
    int16                   nNyqVel         = 0;
    int                     nFlag           = 0;
    int16                   nElev16         = 0;

    char                    szField_Name[MAX_FIELDS][2] = {{0}};
    int16                   rgnFieldLength[MAX_FIELDS]  = {0};
    
    pUf = (ST_UF_DATA *)calloc(1, sizeof(ST_UF_DATA));
    if(pUf == NULL)
        return NULL;

    for(nIdx = 0; nIdx < MAX_NUM_TILTS; nIdx++)
    {
        pUf->m_rgnRays[nIdx] = 0;
        pUf->m_fUfElevation[nIdx] = 0;
        for(nRayIdx = 0; nRayIdx < MAX_NUM_AZIMUTH; nRayIdx++)
        {
            pUf->m_AZIM[nIdx][nRayIdx] = BAD_VALUE_F;
            pUf->m_nBins[nIdx][nRayIdx] = 0;
            pUf->m_nGateSize[nIdx][nRayIdx] = 0;
            pUf->m_nRangeBin[nIdx][nRayIdx] = 0;
            for(nBinIdx = 0; nBinIdx < MAX_NUM_GATES; nBinIdx++)
            {
                pUf->m_fData[nIdx][nRayIdx][nBinIdx] = BAD_VALUE_F;
            }
        }
    }
    
    pnBuff = (int16*)malloc(sizeof(int16)*2000);
    if(pnBuff == NULL)
    {
        free(pUf);
        return NULL;
    }

    gz_file = gzopen(szFilename, "rb");
    if(gz_file == NULL)
    {
        free(pUf);
        free(pnBuff);
        return NULL;
    }
    
    gzbuffer(gz_file, 1024*1024*16);

    while(1)
    {
        if(gzread(gz_file, (char *)(&nFirstWord), sizeof(int)) != sizeof(int))
        {
            break;
        }
        
        nMovepoint = gztell(gz_file);
        
        if(gzread(gz_file, (char *)(&header), sizeof(header)) != sizeof(header))
        {
            gzclose(gz_file);
            free(pUf);
            free(pnBuff);
            return NULL;
        }
        
        if(nSweepNumber != SHORT_BSWAP(header.sweep_number))
        {
            nRayNumber = 1;
            nSweepNumber = SHORT_BSWAP(header.sweep_number);
        }
        
        nAzimuth = SHORT_BSWAP(header.azimuth);
        nElev16  = SHORT_BSWAP(header.fixed_angle);
        
        if (SHORT_BSWAP(header.first_word_position) != SHORT_BSWAP(header.first_word_data_header))
        {
            gzread(gz_file, (char *)(&szDummy), sizeof(szDummy));
        }
        gzread(gz_file, (char *)(&nFieldCounter), sizeof(nFieldCounter));
        gzread(gz_file, (char *)(&nRecordRay),    sizeof(nRecordRay));
        gzread(gz_file, (char *)(&nFieldsRay),    sizeof(nFieldsRay));
        
        nFieldCounter = SHORT_BSWAP(nFieldCounter);
        nRecordRay    = SHORT_BSWAP(nRecordRay);
        nFieldsRay    = SHORT_BSWAP(nFieldsRay);

        if (nFieldCounter > MAX_FIELDS)
        {
            gzclose(gz_file);
            free(pUf);
            free(pnBuff);
            return NULL;
        }
        
        for(nIdx = 0; nIdx < nFieldCounter; nIdx++)
        {
            gzread(gz_file, (char *)(&szField_Name[nIdx]),   sizeof(szField_Name[nIdx]));
            gzread(gz_file, (char *)(&rgnFieldLength[nIdx]), sizeof(rgnFieldLength[nIdx]));
            
            if(nSweepNumber == 1 && nRayNumber == 1)
            {
                pUf->m_nFieldCnt = nFieldCounter;
                pUf->szField_Name[nIdx][0] = szField_Name[nIdx][0];
                pUf->szField_Name[nIdx][1] = szField_Name[nIdx][1];
                pUf->szField_Name[nIdx][2] = '\0';
                
                if(szField_Name[nIdx][0] == szField[0] && szField_Name[nIdx][1] == szField[1])
                    nFlag = 1;
            }
            rgnFieldLength[nIdx] = SHORT_BSWAP(rgnFieldLength[nIdx]);
        }
        
        if(nFlag == 0)
        {
            gzclose(gz_file);
            free(pUf);
            free(pnBuff);
            return NULL;
        }
        
        for(nIdx = 0; nIdx < nFieldCounter; nIdx++)
        {
            gzseek(gz_file, nMovepoint + (rgnFieldLength[nIdx]*2) -2 , SEEK_SET);
            gzread(gz_file, (char *)&un_header, sizeof(un_header));
            un_header.first_word_data = SHORT_BSWAP(un_header.first_word_data);
            
            if(szField_Name[nIdx][0] != szField[0] || szField_Name[nIdx][1] != szField[1] )
            {
                if(szField_Name[nIdx][0] == 'V' && szField_Name[nIdx][1] == 'R')
                {
                    gzread(gz_file, (char *)(&szDummy), 2);
                    gzread(gz_file, (char *)(&szDummy), 2);
                    
                    gzseek(gz_file,
                            SHORT_BSWAP(un_header.number_of_sample_volumes) *
                            SHORT_BSWAP(un_header.bits_per_sample_volume) / 8,
                            SEEK_CUR);
                }
                else
                {
                    gzseek(gz_file, nMovepoint + (un_header.first_word_data * 2) - 2, SEEK_SET);
                    
                    gzseek(gz_file,
                            SHORT_BSWAP(un_header.number_of_sample_volumes) *
                            SHORT_BSWAP(un_header.bits_per_sample_volume) / 8,
                            SEEK_CUR);
                }
                continue;
            }
            if(szField_Name[nIdx][0] == szField[0] && szField_Name[nIdx][1] == szField[1])
            {
                fTemp = ((float)nAzimuth / 64.0f) + fAzimuthCorrection;
                
                if(fTemp < 0)
                {
                    fTemp = 360.f + fTemp;
                }
                else if(fTemp >= 360)
                {
                    fTemp = fTemp - 360.f;
                }

                pUf->m_AZIM[nSweepNumber-1][nRayNumber-1] = fTemp;
                
                nBinCnt = SHORT_BSWAP(un_header.number_of_sample_volumes);
                pUf->m_nBins[nSweepNumber-1][nRayNumber-1] = nBinCnt;
                pUf->m_nGateSize[nSweepNumber-1][nRayNumber-1] = SHORT_BSWAP(un_header.sample_volume_spacing);
                pUf->m_nRangeBin[nSweepNumber-1][nRayNumber-1] = SHORT_BSWAP(un_header.range_first_gate)*1000.0 + SHORT_BSWAP(un_header.adj_to_center);
                
                if(pUf->m_fUfElevation[nSweepNumber - 1] == 0)
                {
                    pUf->m_fUfElevation[nSweepNumber - 1] = (float)(nElev16/DEG_COEFF);
                }
                
                nMiss = SHORT_BSWAP(un_header.threshold_value);
                nDataScale = SHORT_BSWAP(un_header.scale_factor);
                
                if(szField_Name[nIdx][0] == 'V' && szField_Name[nIdx][1] == 'R')
                {
                    gzread(gz_file, &nNyqVel, 2);
                    gzread(gz_file, (char *)(&szDummy), 2);
                    
                    gzread(gz_file, (char *)pnBuff,
                            SHORT_BSWAP(un_header.number_of_sample_volumes) *
                            SHORT_BSWAP(un_header.bits_per_sample_volume) / 8);
                    pUf->m_fNyqVel = (float)SHORT_BSWAP(nNyqVel)/(float)nDataScale;
                }
                else
                {
                    gzseek(gz_file, nMovepoint + (un_header.first_word_data * 2) - 2, SEEK_SET);
                    gzread(gz_file, (char *)pnBuff,
                            SHORT_BSWAP(un_header.number_of_sample_volumes) *
                            SHORT_BSWAP(un_header.bits_per_sample_volume) / 8);
                }
                
                for (nBin = 0; nBin < nBinCnt; nBin++)
                {
                    nVal = SHORT_BSWAP(pnBuff[nBin]);
                    
                    if(szField_Name[nIdx][0] == 'K' && szField_Name[nIdx][1] == 'D' && nVal != nMiss)
                    {
                        fTemp = (float)nVal/(float)nDataScale;
                        
                        pUf->m_fData[nSweepNumber - 1][nRayNumber-1][nBin] = fnKD_F(fnKD_INVF(fTemp));
                        pUf->m_fData[nSweepNumber - 1][nRayNumber][nBin] = fnKD_F(fnKD_INVF(fTemp));
                    }
                    else if (nVal != nMiss)
                    {
                        pUf->m_fData[nSweepNumber - 1][nRayNumber-1][nBin] = (float)nVal / (float)nDataScale;
                        pUf->m_fData[nSweepNumber - 1][nRayNumber][nBin] = (float)nVal / (float)nDataScale;
                    }
                    else
                    {
                        pUf->m_fData[nSweepNumber - 1][nRayNumber-1][nBin] = BADVAL;
                        pUf->m_fData[nSweepNumber - 1][nRayNumber][nBin] = BADVAL;
                    }
                }
                nRayNumber++;
                pUf->m_rgnRays[nSweepNumber-1] += 1;
                
                if(nSweepNumber == 1)
                {
                    pUf->m_fBeamWidth   = SHORT_BSWAP(un_header.horizontal_beam_width)/64.0f;
                    pUf->m_fV_BeamWidth = SHORT_BSWAP(un_header.vertical_beam_width)/64.0f;
                }          
            }
        } // field_counter
        
        if(nTail == -1)
        {
            gzread(gz_file, (char *)(&szDummy), 12);
            
            for(nTailChkCnt = 0; nTailChkCnt < 12; nTailChkCnt++)
            {
                if(szDummy[nTailChkCnt] == 'U' && szDummy[nTailChkCnt + 1] == 'F')
                    break;
            }
            
            nTail = nTailChkCnt - (sizeof(nFirstWord) + sizeof(nEndWord));
            gzseek(gz_file, -12, SEEK_CUR);
        }
        
        if(nTail != 0)
        {
            if(gzread(gz_file, (char *)(&szDummy), nTail) != nTail)
            {
                gzclose(gz_file);
                free(pUf);
                free(pnBuff);
                return NULL;
            }
        }
        
        if(gzread(gz_file, (char *)(&nEndWord), sizeof(nEndWord)) != sizeof(nEndWord))
        {
            gzclose(gz_file);
            free(pUf);
            free(pnBuff);
            return NULL;
        }
    }
    header.degrees_longitude = SHORT_BSWAP(header.degrees_longitude);
    header.minutes_longitude = SHORT_BSWAP(header.minutes_longitude);
    header.seconds_longitude = SHORT_BSWAP(header.seconds_longitude)/64;
    header.degrees_latitude = SHORT_BSWAP(header.degrees_latitude);
    header.minutes_latitude = SHORT_BSWAP(header.minutes_latitude);
    header.seconds_latitude = SHORT_BSWAP(header.seconds_latitude)/64;

    pUf->m_fSiteLon = fnDeg60_to_100(header.degrees_longitude, header.minutes_longitude, header.seconds_longitude);
    pUf->m_fSiteLat = fnDeg60_to_100(header.degrees_latitude, header.minutes_latitude, header.seconds_latitude);
    pUf->m_nSweeps = SHORT_BSWAP(header.sweep_number);
    pUf->m_nHeight = SHORT_BSWAP(header.height);

    free(pnBuff);
    gzclose(gz_file);

    return pUf;
}

float fnGetGridKm(int nMapLevel)
{
    float   fGridKm = 2.0f;
    int     nIdx    = 0;
    
    for(nIdx = 0; nIdx < nMapLevel; nIdx++)
    {
        fGridKm = (float)(fGridKm/2);
    }
    
    return fGridKm;
}

float* fnMakeMohrCappi(ST_UF_DATA *pUf, int nIs_Dbz, int nYdim, int nXdim, float fSiteGridKm, int nY1, int nY2, int nX1, int nX2, float fHeightFromRadar, st_Azimuth** table)
{
    float   *pData = NULL;
    int     nXIdx  = 0;
    int     nYIdx  = 0;

    if(pUf == NULL)
        return NULL;

    pData = (float *)calloc(nYdim*nXdim, sizeof(float));
    if(pData == NULL)
        return NULL;

    for (nYIdx = nY1; nYIdx < nY2; nYIdx++ )
    {
        for (nXIdx = nX1; nXIdx < nX2; nXIdx++ )
        {
            pData[nYIdx*nXdim+nXIdx] = fnCAPPI_At_h_Cart(pUf, fHeightFromRadar, nXdim, nYdim, fSiteGridKm, 
                                                    nXIdx, nYIdx, PSEUDO_CAPPI, nIs_Dbz, 0, table);
        }
    }

    return pData;
}

float* fnVolumeToBASE(ST_UF_DATA *pUf, int nXdim, int nYdim, int nRange, st_Azimuth** table)
{
    float** pfImsiData  = NULL;
    float*  pfBaseData  = NULL;
    int     nIdx        = 0;
    int     nJIdx       = 0;
    int     nSweeps     = 0;

    if(pUf == NULL)
        return NULL;

    nSweeps = pUf->m_nSweeps;

    pfImsiData = (float **)malloc(nSweeps * sizeof(float *));
    for(nIdx = 0; nIdx < nSweeps; nIdx++)
    {
        pfImsiData[nIdx] = fnKRL_SweepToCart(pUf, nIdx, nXdim, nYdim, nRange, table[nIdx]);
    }

    pfBaseData = malloc(nXdim * nYdim * sizeof(float));
    for(nIdx = 0; nIdx < nXdim * nYdim; nIdx++)
    {
        pfBaseData[nIdx] = BAD_VALUE_F;
    }

    for(nIdx = 0; nIdx < nXdim * nYdim; nIdx++)
    {
        for(nJIdx = 0; nJIdx < nSweeps; nJIdx++)
        {
            if(pfImsiData[nJIdx][nIdx] != BAD_VALUE_F)
            {
                pfBaseData[nIdx] = pfImsiData[nJIdx][nIdx];
                break;
            }
        }
    }

    for(nIdx = 0; nIdx < nSweeps; nIdx++)
    {
        free(pfImsiData[nIdx]);
        pfImsiData[nIdx] = NULL;
    }
    free(pfImsiData);
    return pfBaseData;
}

float* fnVolumeToVIL(ST_UF_DATA *pUf, int nXdim, int nYdim, int nRange, int nTop_h_km, int nBottom_h_km, st_Azimuth** table)
{
    pthread_t           thrPid[VIL_MAX_THR] = { -1, };
    st_VilCappiThrArg   thrArg[VIL_MAX_THR];
    pthread_t           vilThrPid[2];
    st_VilThrArg        vilThrArg[2];
    int                 nThrCnt             = 0;
    int                 nThrIdx             = 0;

    float**     pfImsiData  = NULL;
    float*      pfVilData   = NULL;
    int         nIdx        = 0;
    int         nHeight     = 0;

    if(pUf == NULL)
        return NULL;

    nHeight = nTop_h_km - nBottom_h_km;

    pfImsiData = (float **)malloc(nHeight * sizeof(float *));
    if(pfImsiData == NULL)
        return NULL;

    for(nIdx = 0; nIdx < nHeight; nIdx++)
    {
        nThrCnt = nIdx % VIL_MAX_THR;
        thrArg[nThrCnt].m_pUf     = pUf;
        thrArg[nThrCnt].m_nHeight = (nIdx + nBottom_h_km);
        thrArg[nThrCnt].m_ppTable = table;
        thrArg[nThrCnt].m_nXdim   = nXdim;
        thrArg[nThrCnt].m_nYdim   = nYdim;
        thrArg[nThrCnt].m_nRange  = nRange;
        thrArg[nThrCnt].m_nIdx    = nIdx;
        thrArg[nThrCnt].m_ppData  = pfImsiData;
        pthread_create(&thrPid[nThrCnt], NULL, fnMakeCappiThread, (void *)&thrArg[nThrCnt]);

        if(nThrCnt == VIL_MAX_THR-1)
        {
            for(nThrIdx = 0; nThrIdx <= nThrCnt; nThrIdx++)
            {
                pthread_join(thrPid[nThrIdx], NULL);
            }
        }
    }

    if(nThrCnt < VIL_MAX_THR-1)
    {
        for(nThrIdx = 0; nThrIdx <= nThrCnt; nThrIdx++)
        {
            pthread_join(thrPid[nThrIdx], NULL);
        }
    }

    pfVilData = (float *)malloc(nXdim * nYdim * sizeof(float));
    for(nIdx = 0; nIdx < nXdim * nYdim; nIdx++)
    {
        pfVilData[nIdx] = BAD_VALUE_F;
    }

    vilThrArg[0].m_ppData       = pfImsiData;
    vilThrArg[0].m_nHeight      = nHeight;
    vilThrArg[0].m_nStartIdx    = 0;
    vilThrArg[0].m_nEndIdx      = (nXdim * nYdim)/2 + 1;
    vilThrArg[0].m_pVilData     = pfVilData;
    vilThrArg[1].m_ppData       = pfImsiData;
    vilThrArg[1].m_nHeight      = nHeight;
    vilThrArg[1].m_nStartIdx    = (nXdim * nYdim)/2;
    vilThrArg[1].m_nEndIdx      = (nXdim * nYdim);
    vilThrArg[1].m_pVilData     = pfVilData;

    pthread_create(&vilThrPid[0], NULL, fnMakeVilThread, (void *)&vilThrArg[0]);
    pthread_create(&vilThrPid[1], NULL, fnMakeVilThread, (void *)&vilThrArg[1]);

    pthread_join(vilThrPid[0], NULL);
    pthread_join(vilThrPid[1], NULL);

    for(nIdx = 0; nIdx < nHeight; nIdx++)
    {
        if(pfImsiData[nIdx] != NULL)
            free(pfImsiData[nIdx]);
    }
    free(pfImsiData);

    return pfVilData;
}

int fnDel_Indenpent_Echo(float *pfImsiData, int nXdim, int nYdim)
{
    int     nXIdx               = 0;
    int     nYIdx               = 0;
    int     nIdx                = 0;
    int     nJIdx               = 0;
    int     nCheckCnt           = 0;
    float  *pfImsiData_Backup   = NULL;
    int     nCnt                = 0;
    int     nTmp1               = 0;
    int     nTmp2               = 0;

    if (pfImsiData == NULL)
    {
        return -9999;
    }

    nCnt = nXdim * nYdim;
    pfImsiData_Backup = malloc(nCnt * sizeof(float));
    memcpy(pfImsiData_Backup,pfImsiData, nCnt * sizeof(float));

    for (nYIdx = 1; nYIdx < nYdim-1; nYIdx++)
    {
        for (nXIdx = 1; nXIdx < nXdim-1; nXIdx++)
        {
            nCheckCnt=0;
            for (nIdx = nYIdx-1; nIdx <= nYIdx+1; nIdx++)
            {
                for (nJIdx = nXIdx-1; nJIdx <= nXIdx+1; nJIdx++)
                {
                    if (pfImsiData_Backup[nIdx*nXdim+nJIdx] != BAD_VALUE_F ) nCheckCnt++;
                    nTmp1=nIdx;
                    nTmp2=nJIdx;
                }
            }
            if (nCheckCnt < 4 ) {
                pfImsiData[nTmp1*nXdim+nTmp2] = BAD_VALUE_F;
            }
        }
    }

    free(pfImsiData_Backup);

    return 1;
}

float* fnVolumeToCMAX(ST_UF_DATA *pUf, int nXdim, int nYdim, int nRange, st_Azimuth** table)
{
    float**     pfImsiData  = NULL;
    float*      pfCmaxData  = NULL;
    float       fTempData   = 0.0;
    int         nIdx        = 0;
    int         nJIdx       = 0;
    int         nSweeps     = 0;

    if(pUf == NULL)
        return NULL;

    nSweeps = pUf->m_nSweeps;
    pfImsiData = (float **)malloc(nSweeps * sizeof(float *));
    for(nIdx = 0; nIdx < nSweeps; nIdx++)
    {
        pfImsiData[nIdx] = fnKRL_SweepToCart(pUf, nIdx, nXdim, nYdim, nRange, table[nIdx]);
    }
    
    pfCmaxData = malloc(nXdim * nYdim * sizeof(float));
    for(nIdx = 0; nIdx < nXdim * nYdim; nIdx++)
    {
        pfCmaxData[nIdx] = BAD_VALUE_F;
    }

    for(nIdx = 0; nIdx < nXdim * nYdim; nIdx++)
    {
        fTempData = BAD_VALUE_F;
        for(nJIdx = 0; nJIdx < nSweeps; nJIdx++)
        {
            if((fTempData < pfImsiData[nJIdx][nIdx]) && (pfImsiData[nJIdx][nIdx] != BAD_VALUE_F))
            {
                fTempData = pfImsiData[nJIdx][nIdx];
            }
        }
        if(fTempData != BAD_VALUE_F)
        {
            pfCmaxData[nIdx] = fTempData;
        }
        else
        {
            pfCmaxData[nIdx] = BAD_VALUE_F;
        }
    }

    for(nIdx = 0; nIdx < nSweeps; nIdx++)
    {
        free(pfImsiData[nIdx]);
        pfImsiData[nIdx] = NULL;
    }
    free(pfImsiData);
    return pfCmaxData;
}

float* fnVolumeToETOP(ST_UF_DATA *pUf, int xdim, int ydim, int range, int radar_height, float etop_min_threshold, float grid_km, st_Azimuth** table)
{
    float**     pfImsiData   = NULL;
    float*      etop_data   = NULL;
    int         i, x, y, k;
    int         nSweeps;
    float       plane_dist;
    float       height;
    int         center_pos;
    float       elev;
    int         index;
    float       radar_height_f;
    double      Ae;
    double      r;

    if(pUf == NULL)
        return NULL;

    Ae = MAP_RE*4./3.;

    radar_height_f = radar_height/1000.;
    center_pos = (xdim - 1) / 2;
    nSweeps = pUf->m_nSweeps;

    pfImsiData = (float **)malloc(nSweeps * sizeof(float *));
    for(i = 0; i < nSweeps; i++)
    {
        pfImsiData[i] = fnKRL_SweepToCart(pUf, i, xdim, ydim, range, table[i]);
    }

    etop_data = malloc(xdim * ydim * sizeof(float));
    for(i = 0; i < xdim * ydim; i++)
    {
       etop_data[i] = BAD_VALUE_F;
    }   

    i = 0;
    for (y = 0 ; y < ydim ; y++ )
    {
        for (x = 0 ; x < xdim ; x++ )
        {
            index = y * xdim + x;
            height = BAD_VALUE_F;
            for (k = nSweeps - 1 ; k >= 0 ; k-- )
            {
                if (pfImsiData[k][index] > etop_min_threshold)
                {
                    elev = pUf->m_fUfElevation[k];
                    plane_dist = (sqrt(pow((center_pos - y)*grid_km,2.) + pow((center_pos - x)*grid_km,2.)));
                    r = plane_dist/cos(PI_DFS/180. * elev);
                    height = sqrt(r*r + Ae*Ae + 2*r*Ae*sin(PI_DFS/180.*elev)) - Ae + radar_height_f;
                    break;
                }
            }

            if(height > 0)
            {
                etop_data[i] = height;
            }
            else
            {
                etop_data[i] = BAD_VALUE_F;
            }
            i++;
        }
    }

    for(i = 0; i < nSweeps; i++)
    {
        free(pfImsiData[i]);
        pfImsiData[i] = NULL;
    }
    free(pfImsiData);

    return etop_data;
}

st_Azimuth* fnMakeHashTable(ST_UF_DATA *pUf, int nSweepNo)
{
    st_Azimuth* table = NULL;
    int     nXIdx        = 0;
    int     nYIdx        = 0;
    float   fRes         = 0.0;

    if(pUf == NULL)
        return NULL;

    table = (st_Azimuth*)malloc(sizeof(st_Azimuth)*pUf->m_rgnRays[nSweepNo]);
    if(table == NULL)
        return NULL;

    for(nXIdx = 0; nXIdx < pUf->m_rgnRays[nSweepNo]; nXIdx++)
    {
        table[nXIdx].m_fAzimuth = BAD_VALUE_F;
        table[nXIdx].m_nCon = -1;
        table[nXIdx].m_nHigh = -1;
        table[nXIdx].m_nLow = -1;
    }

    fRes = 360.0/pUf->m_rgnRays[nSweepNo];

    for (nXIdx = 0; nXIdx < pUf->m_rgnRays[nSweepNo]; nXIdx++)
    {
        if(pUf->m_AZIM[nSweepNo][nXIdx] == BAD_VALUE_F)
        {
            continue;
        }

        nYIdx = (int)(pUf->m_AZIM[nSweepNo][nXIdx]/fRes + fRes/2.0);

        if(nYIdx >= pUf->m_rgnRays[nSweepNo])
        {
            nYIdx = nYIdx % pUf->m_rgnRays[nSweepNo];
        }

        table[nYIdx].m_fAzimuth = pUf->m_AZIM[nSweepNo][nXIdx];
        table[nYIdx].m_nCon = nXIdx;
        table[nXIdx].m_nHigh = (nXIdx + 1) % pUf->m_rgnRays[nSweepNo];

        if(nXIdx - 1 <0)
        {
            table[nXIdx].m_nLow = (nXIdx-1)+pUf->m_rgnRays[nSweepNo];
        }
        else
        {
            table[nXIdx].m_nLow = nXIdx - 1;
        }
    }

    return table;
}

float *fnKRL_SweepToCart(ST_UF_DATA *pUf, int nSweepNo, int nXdim, int nYdim, float fRange, st_Azimuth* table)
{
    int          nXIdx          = 0;
    int          nYIdx          = 0;
    float        fAzim          = 0.0;
    float        fResult        = 0.0;
    float        fVal           = 0.0;
    int          nCartIdx       = 0;
    int          nIdx           = 0;
    float        fRes           = 0.0;
    float        fRm            = 0.0;
    int          nAzim          = 0;
    static float *pfCartImage   = NULL;
    double       dCloseDiff     = 0.0;
    
    if (nXdim != nYdim || nYdim < 0 || nXdim < 0 || pUf == NULL)
    {
        return NULL;
    }
    
    pfCartImage = (float*) calloc(nXdim*nYdim, sizeof(float));

    for (nXIdx = 0; nXIdx < nXdim * nYdim; nXIdx++ )
    {
        pfCartImage[nXIdx] = BAD_VALUE_F;
    }
   
    fRes = 360.0/pUf->m_rgnRays[nSweepNo];
    
    for (nYIdx = -nYdim/2; nYIdx < nYdim/2; nYIdx++)
    {
        for (nXIdx = -nXdim/2; nXIdx < nXdim/2; nXIdx++)
        {
            fResult = (float)sqrt((double)(nXIdx * nXIdx) + (double)nYIdx * nYIdx);

            if (nYdim < nXdim)
            {
                fResult *= fRange/(.5*nYdim);
            }
            else
            {
                fResult *= fRange/(.5*nXdim);
            }

            if(fResult > fRange)
            {
                fVal = BAD_VALUE_F;
            }
            else
            {
                if (nXIdx !=0 )
                {
                    fAzim = (float)atan((double)nYIdx/(double)nXIdx)*180.0/3.14159;
                }
                else
                {
                    if (nYIdx < 0)
                    {
                        fAzim = -90.0;
                    }
                    else
                    {
                        fAzim = 90.0;
                    }
                }
                if (nYIdx < 0 && nXIdx < 0)
                {/* Quadrant 3 (math notation). */
                    fAzim -= 180;
                }
                else if (nYIdx >= 0 && nXIdx<0)
                {/* Quad: 2 */
                    fAzim += 180;
                }
                
                fAzim = -fAzim;
                fAzim -= 90.0;

                if (fAzim < 0) fAzim += 360.0;
                
                nIdx = (int)(fAzim/fRes + fRes/2.0);
                
                nIdx = nIdx % pUf->m_rgnRays[nSweepNo];
                
                while(table[nIdx].m_nCon == -1)
                {
                    nIdx = (nIdx+1)% pUf->m_rgnRays[nSweepNo];
                }
                
                if((nAzim = fnClosestRay(pUf, nIdx, fAzim, table, nSweepNo)) < 0)
                {
                    fVal = BAD_VALUE_F;
                }
                else
                {
                    nAzim = nAzim % pUf->m_rgnRays[nSweepNo];
                    dCloseDiff = fnAngle_Diff(fAzim, pUf->m_AZIM[nSweepNo][nAzim]);
                    
                    fRm = fResult * 1000.0f;
                    nIdx = (int)((fRm - pUf->m_nRangeBin[nSweepNo][nAzim])/pUf->m_nGateSize[nSweepNo][nAzim]);
                    fVal = (float)(pUf->m_fData[nSweepNo][nAzim][nIdx]);
                }
            }
            
            nCartIdx =  (nYIdx + nYdim/2) * nYdim + (nXdim-1)-(nXIdx + nXdim/2);

            if(fVal == BADVAL || fVal == NOTFOUND_V || fVal == NOTFOUND_H )
            {
                pfCartImage[nCartIdx] =  BAD_VALUE_F;
            }
            else
            {
                pfCartImage[nCartIdx] = fVal;
            }
            
            if(dCloseDiff > pUf->m_fBeamWidth)
            {
                pfCartImage[nCartIdx] = BAD_VALUE_F;
            }
        }
    }
    return pfCartImage;
}

float fnUV_To_S(float u, float v)
{
    return pow(pow(u, 2) + pow(v, 2), 0.5);
}

float fnR_To_D(float r)
{
    return (r * 180.) / PI_DFS;
}

float fnUV_To_d(float u, float v)
{
    if(u >= 0 && v >= 0)
    {
        return 270. - fnR_To_D(atan2(fabs(v),fabs(u)));
    }
    else if(u >= 0 && v < 0)
    {
        return 270. + fnR_To_D(atan2(fabs(v),fabs(u)));
    }
    else if(u < 0 && v >= 0)
    {
        return 180. - fnR_To_D(atan2(fabs(u),fabs(v)));
    }
    else if(u < 0 && v < 0)
    {
        return fnR_To_D(atan2(fabs(u),fabs(v)));
    }
    else
    {
        return 0.;
    }
}
/* ================================================================================ */
