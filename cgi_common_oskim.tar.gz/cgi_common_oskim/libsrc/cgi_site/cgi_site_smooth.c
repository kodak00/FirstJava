/* ================================================================================ */
// 2016. 7. 29
//
// SnK : Choi Hyun-Jun
//
// 스무딩 함수 
//
/* ================================================================================ */
// INCLUDE

#include "cgi_site_common.h"
#include "cgi_site_smooth.h"

/* ================================================================================ */
// LOCAL FUNCTION

/* ================================================================================ */
// FUNCTION

int fnKmaSmooth(float** pData, int nYdim, int nXdim)
{
    float e[4], e1,e2;
    int nXIdx = 0;
    int nYIdx = 0;

    if(pData == NULL)
        return -1;
        
    for(nYIdx = 0; nYIdx < nYdim; nYIdx++)
    {
        e1 = pData[nYIdx][0];
        e[0] = pData[nYIdx][0];
        e[1] = pData[nYIdx][1];
        
        for(nXIdx = 1; nXIdx < nXdim - 1; nXIdx++)
        {
            e[2] = pData[nYIdx][nXIdx+1];
            if(e[0] > -50 && e[1] > -50 && e[2] > -50)
            {
                e2 = (e[0] + 2.0 * e[1] + e[2]) * 0.25;
            }
            else if(e[0] > -50 && e[1] <= -50 && e[2] > -50)
            {
                e2 = (e[0] + e[2]) * 0.5;
            }
            else
            {
                e2 = e[1];
            }
            pData[nYIdx][nXIdx-1] = e1;
            e1 = e2;
            e[0] = e[1];
            e[1] = e[2];
        }
        pData[nYIdx][nXIdx-1] = e1;
    }
    for(nXIdx = 0; nXIdx < nXdim; nXIdx++)
    {
        e1 = pData[0][nXIdx];
        e[0] = pData[0][nXIdx];
        e[1] = pData[1][nXIdx];
        
        for(nYIdx = 1; nYIdx < nYdim - 1; nYIdx++)
        {
            e[2] = pData[nYIdx+1][nXIdx];
            if (e[0] > -50 && e[1] > -50 && e[2] > -50)
            {
                e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
            }
            else if (e[0] > -50 && e[1] <= -50 && e[2] > -50)
            {
                e2 = (e[0] + e[2]) * 0.5;
            }
            else
            {
                e2 = e[1];
            }
            pData[nYIdx-1][nXIdx] = e1;
            e1 = e2;
            e[0] = e[1];
            e[1] = e[2];
        }
        pData[nYIdx-1][nXIdx] = e1;
    }
    return 0;
}

/* ================================================================================ */
