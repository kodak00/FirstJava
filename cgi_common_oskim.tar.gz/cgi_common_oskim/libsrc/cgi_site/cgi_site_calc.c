/* ================================================================================ */
// 2016. 7. 29
//
// SnK : Choi Hyun-Jun
//
// 계산과 관련된 함수 모음
//
/* ================================================================================ */
// INCLUDE

#include "cgi_site_common.h"
#include "cgi_site_calc.h"

/* ================================================================================ */
// LOCAL FUNCTION

/* ================================================================================ */
// FUNCTION

float fnCalcRadarValue_Map(float** pData, int nDataXdim, int nDataYdim, int nDiff_x, int nDiff_y, int nXpoint, int nYpoint, float fGridScale)
{
    float   fValue  = 0.0;
    double  dCalcY  = 0.0;
    double  dCalcX  = 0.0;
    int     nCalcY  = 0;
    int     nCalcX  = 0;

    dCalcX  = ((double)(nXpoint - (double)nDiff_x) / (double)fGridScale);
    dCalcY  = ((double)(nYpoint - (double)nDiff_y) / (double)fGridScale);

    nCalcX = (int)dCalcX;
    nCalcY = (int)dCalcY;
   
    if((nCalcX >= 0 && nCalcX < nDataXdim) && (nCalcY >= 0 && nCalcY < nDataYdim))
    {
        fValue = pData[nCalcY][nCalcX];
    }
    else
    {
        fValue = OUT_BOUND_F;
    }
    
    return fValue;
}

float fnCalcRadarValue(float** pData, int nDataXdim, int nDataYdim, int nDiff_x, int nDiff_y, int nXpoint, int nYpoint, float fXGridScale, float fYGridScale)
{
    float   fValue  = 0.0;
    double  dCalcY  = 0.0;
    double  dCalcX  = 0.0;
    int     nCalcY  = 0;
    int     nCalcX  = 0;
    
    dCalcX  = ((double)(nXpoint - (double)nDiff_x) / (double)fXGridScale);
    dCalcY  = ((double)(nYpoint - (double)nDiff_y) / (double)fYGridScale);
    
    nCalcX = (int)dCalcX;
    nCalcY = (int)dCalcY;
    
    if((nCalcX >= 0 && nCalcX < nDataXdim) && (nCalcY >= 0 && nCalcY < nDataYdim))
    {
        fValue = pData[nCalcY][nCalcX];
    }
    else
    {
        fValue = OUT_BOUND_F;
    }
    
    return fValue;
}


/* ================================================================================ */
