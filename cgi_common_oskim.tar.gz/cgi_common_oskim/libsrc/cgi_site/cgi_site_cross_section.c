/* ================================================================================ */
// 2016. 10. 05
//
// SnK : Choi Hyun-Jun
//
// 연직단면 함수 모음
//
/* ================================================================================ */

#include "cgi_site_common.h"
#include "cgi_site_cross_section.h"
#include "cgi_cmm_map_ini.h"

int fnGetCross_Section_Point(CROSS_SECTION *stCross_Section, POINT stStartPoint, POINT stEndPoint, int nYdim, int nXdim, float fSiteLon, float fSiteLat, float fSiteGridKm)
{
    int     nIdx                = 0;
    float   fTemp_A             = 0.0f;
    float   fTemp_B             = 0.0f;
    float   fX_Point            = 0.0f;
    float   fY_Point            = 0.0f;
    float   fLength             = 0.0f;
    float   fDistFromCenter_1   = 0.0f;
    float   fDistFromCenter_2   = 0.0f;
    POINT   stStartAzed;
    POINT   stEndAzed;
    POINT   stStartSorted;
    POINT   stEndSorted;
    st_AzedParameter    stAzedParameter;
    st_AzedVar          stAzedVar;

    stAzedParameter=fnCgiGetMapInfoAzed(KMA_MAP_RE, fSiteLon, fSiteLat, fSiteLon, fSiteLat, fSiteGridKm, nXdim/2, nYdim/2);
    stAzedVar.m_nFirst = 0;

    fnCgiAzedProj(&stStartPoint.m_fX_Point, &stStartPoint.m_fY_Point, &stStartAzed.m_fX_Point, &stStartAzed.m_fY_Point, 0, stAzedParameter, &stAzedVar);
    fnCgiAzedProj(&stEndPoint.m_fX_Point, &stEndPoint.m_fY_Point, &stEndAzed.m_fX_Point, &stEndAzed.m_fY_Point, 0, stAzedParameter, &stAzedVar);

    stStartAzed.m_fY_Point = (float)nYdim - stStartAzed.m_fY_Point;
    stEndAzed.m_fY_Point   = (float)nYdim - stEndAzed.m_fY_Point;

    if((fabs(stStartAzed.m_fX_Point - stEndAzed.m_fX_Point) < 1) && (fabs(stStartAzed.m_fY_Point - stEndAzed.m_fY_Point) < 1))
        return -1;

    fLength = (sqrt(pow(stEndAzed.m_fX_Point - stStartAzed.m_fX_Point,2) + pow(stEndAzed.m_fY_Point - stStartAzed.m_fY_Point,2))) * fSiteGridKm;


    // Y에 수평인 선일 경우
    if(stStartAzed.m_fX_Point == stEndAzed.m_fX_Point)
    {
        if(stEndAzed.m_fY_Point < stStartAzed.m_fY_Point)
        {
            stStartSorted = stEndAzed;
            stEndSorted = stStartAzed;
        }
        else
        {
            stStartSorted = stStartAzed;
            stEndSorted = stEndAzed;
        }

        for(nIdx = 1; nIdx <= XYDIM_CROSS; nIdx++)
        {
            fX_Point = stStartSorted.m_fX_Point;
            fY_Point = ((fLength/XYDIM_CROSS) * nIdx) + stStartSorted.m_fY_Point;
            stCross_Section->m_stPoint[nIdx-1].m_fX_Point = fX_Point;
            stCross_Section->m_stPoint[nIdx-1].m_fY_Point = fY_Point;
        }

        return 0;
    }

    if(stEndAzed.m_fX_Point < stStartAzed.m_fX_Point)
    {
        stStartSorted = stEndAzed;
        stEndSorted = stStartAzed;
    }
    else
    {
        stStartSorted = stStartAzed;
        stEndSorted = stEndAzed;
    }

    fTemp_A = (stEndSorted.m_fY_Point - stStartSorted.m_fY_Point) / ( stEndSorted.m_fX_Point - stStartSorted.m_fX_Point);
    fTemp_B = stEndAzed.m_fY_Point - fTemp_A * stEndAzed.m_fX_Point;

    fDistFromCenter_1 = sqrt(pow(nXdim, 2) + pow(nYdim, 2));
    for(nIdx = 1; nIdx <= XYDIM_CROSS; nIdx++)
    {
        fX_Point = (((stEndSorted.m_fX_Point - stStartSorted.m_fX_Point)/XYDIM_CROSS)*nIdx) + stStartSorted.m_fX_Point;
        fY_Point = fTemp_A * fX_Point + fTemp_B;
     
        stCross_Section->m_stPoint[nIdx-1].m_fX_Point = fX_Point;
        stCross_Section->m_stPoint[nIdx-1].m_fY_Point = fY_Point;

        fDistFromCenter_2 = sqrt(pow(nXdim/2 - fX_Point, 2) + pow(nYdim/2 - fY_Point, 2));
        if(fDistFromCenter_2 < fDistFromCenter_1)
        {
            stCross_Section->m_nCenter_Idx = nIdx-1;
            fDistFromCenter_1 = fDistFromCenter_2;
        }
    }
    return 0;
}

