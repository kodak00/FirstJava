/* ================================================================================ */
// 2016. 7. 29
//
// SnK : Choi Hyun-Jun
//
// 이미지를 그려주는 함수 모음
//
/* ================================================================================ */
// INCLUDE

#include "cgi_site_common.h"
#include "cgi_cmm_map_ini.h"
#include "cgi_cmm_color.h"
#include "cgi_cmm_util.h"
#include "cgi_site_draw.h"

/* ================================================================================ */
// STRUCT

static st_ColorInfo  ColorInfoTbl[] =
{
    { "PPI", "DZ", CGI_DF_RN_COLOR_FILE, "%.0f", CGI_EN_COLOR_UNIT, 0.0},
    { "PPI", "RN", CGI_DF_RN_COLOR_FILE, "%.1f", CGI_EN_COLOR_RAIN, 0.0},
    { "PPI", "CZ", CGI_DF_RN_COLOR_FILE, "%.0f", CGI_EN_COLOR_UNIT, 0.0},
    { "PPI", "SW", CGI_DF_SW_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "PPI", "RH", CGI_DF_RH_COLOR_FILE, "%.2f", CGI_EN_COLOR_UNIT, 0.0},
    { "PPI", "PH", CGI_DF_PH_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "PPI", "VR", CGI_DF_VR_COLOR_FILE, "%.0f", CGI_EN_COLOR_UNIT, -50.0},
    { "PPI", "DR", CGI_DF_DR_COLOR_FILE, "%.2f", CGI_EN_COLOR_UNIT, -3.0},
    { "PPI", "KD", CGI_DF_KD_COLOR_FILE, "%.2f", CGI_EN_COLOR_UNIT, -20.0},
    { "PPI", "SN", CGI_DF_SN_COLOR_FILE, "%.2f", CGI_EN_COLOR_RAIN, 0.0},

    { "CAPPI", "DZ", CGI_DF_RN_COLOR_FILE, "%.0f", CGI_EN_COLOR_UNIT, 0.0},
    { "CAPPI", "RN", CGI_DF_RN_COLOR_FILE, "%.1f", CGI_EN_COLOR_RAIN, 0.0},
    { "CAPPI", "CZ", CGI_DF_RN_COLOR_FILE, "%.0f", CGI_EN_COLOR_UNIT, 0.0},
    { "CAPPI", "SW", CGI_DF_SW_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "CAPPI", "RH", CGI_DF_RH_COLOR_FILE, "%.2f", CGI_EN_COLOR_UNIT, 0.0},
    { "CAPPI", "PH", CGI_DF_PH_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "CAPPI", "VR", CGI_DF_VR_COLOR_FILE, "%.0f", CGI_EN_COLOR_UNIT, -50.0},
    { "CAPPI", "DR", CGI_DF_DR_COLOR_FILE, "%.2f", CGI_EN_COLOR_UNIT, -3.0},
    { "CAPPI", "KD", CGI_DF_KD_COLOR_FILE, "%.2f", CGI_EN_COLOR_UNIT, -20.0},
    { "CAPPI", "SN", CGI_DF_SN_COLOR_FILE, "%.2f", CGI_EN_COLOR_RAIN, 0.0},

    { "BASE", "DZ", CGI_DF_RN_COLOR_FILE, "%.0f", CGI_EN_COLOR_UNIT, 0.0},
    { "BASE", "RN", CGI_DF_RN_COLOR_FILE, "%.1f", CGI_EN_COLOR_RAIN, 0.0},
    { "BASE", "CZ", CGI_DF_RN_COLOR_FILE, "%.0f", CGI_EN_COLOR_UNIT, 0.0},
    { "BASE", "SW", CGI_DF_SW_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "BASE", "RH", CGI_DF_RH_COLOR_FILE, "%.2f", CGI_EN_COLOR_UNIT, 0.0},
    { "BASE", "PH", CGI_DF_PH_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "BASE", "VR", CGI_DF_VR_COLOR_FILE, "%.0f", CGI_EN_COLOR_UNIT, -50.0},
    { "BASE", "DR", CGI_DF_DR_COLOR_FILE, "%.2f", CGI_EN_COLOR_UNIT, -3.0},
    { "BASE", "KD", CGI_DF_KD_COLOR_FILE, "%.2f", CGI_EN_COLOR_UNIT, -20.0},
    { "BASE", "SN", CGI_DF_SN_COLOR_FILE, "%.1f", CGI_EN_COLOR_RAIN, 0.0},

    { "CMAX", "DZ", CGI_DF_RN_COLOR_FILE, "%.0f", CGI_EN_COLOR_UNIT, 0.0},
    { "CMAX", "RN", CGI_DF_RN_COLOR_FILE, "%.1f", CGI_EN_COLOR_RAIN, 0.0},
    { "CMAX", "CZ", CGI_DF_RN_COLOR_FILE, "%.0f", CGI_EN_COLOR_UNIT, 0.0},
    { "CMAX", "SW", CGI_DF_SW_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "CMAX", "RH", CGI_DF_RH_COLOR_FILE, "%.2f", CGI_EN_COLOR_UNIT, 0.0},
    { "CMAX", "PH", CGI_DF_PH_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "CMAX", "VR", CGI_DF_VR_COLOR_FILE, "%.0f", CGI_EN_COLOR_UNIT, -50.0},
    { "CMAX", "DR", CGI_DF_DR_COLOR_FILE, "%.2f", CGI_EN_COLOR_UNIT, -3.0},
    { "CMAX", "KD", CGI_DF_KD_COLOR_FILE, "%.2f", CGI_EN_COLOR_UNIT, -20.0},
    { "CMAX", "SN", CGI_DF_SN_COLOR_FILE, "%.1f", CGI_EN_COLOR_RAIN, 0.0},

    { "VIL", "RN", CGI_DF_VIL_COLOR_FILE, "%.1f", CGI_EN_COLOR_RAIN, 0.0},
    { "VIL", "CZ", CGI_DF_VIL_COLOR_FILE, "%.1f", CGI_EN_COLOR_RAIN, 0.0},
    { "VIL", "DZ", CGI_DF_VIL_COLOR_FILE, "%.1f", CGI_EN_COLOR_RAIN, 0.0},
    { "VIL", "SW", CGI_DF_VIL_COLOR_FILE, "%.1f", CGI_EN_COLOR_RAIN, 0.0},
    { "VIL", "RH", CGI_DF_VIL_COLOR_FILE, "%.1f", CGI_EN_COLOR_RAIN, 0.0},
    { "VIL", "PH", CGI_DF_VIL_COLOR_FILE, "%.1f", CGI_EN_COLOR_RAIN, 0.0},
    { "VIL", "VR", CGI_DF_VIL_COLOR_FILE, "%.1f", CGI_EN_COLOR_RAIN, 0.0},
    { "VIL", "DR", CGI_DF_VIL_COLOR_FILE, "%.1f", CGI_EN_COLOR_RAIN, 0.0},
    { "VIL", "KD", CGI_DF_VIL_COLOR_FILE, "%.1f", CGI_EN_COLOR_RAIN, 0.0},
    { "VIL", "SN", CGI_DF_VIL_COLOR_FILE, "%.1f", CGI_EN_COLOR_RAIN, 0.0},

    { "ETOP", "CZ", CGI_DF_ETOP_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "ETOP", "DZ", CGI_DF_ETOP_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "ETOP", "RN", CGI_DF_ETOP_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "ETOP", "SW", CGI_DF_ETOP_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "ETOP", "RH", CGI_DF_ETOP_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "ETOP", "PH", CGI_DF_ETOP_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "ETOP", "VR", CGI_DF_ETOP_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "ETOP", "DR", CGI_DF_ETOP_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "ETOP", "KD", CGI_DF_ETOP_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},
    { "ETOP", "SN", CGI_DF_ETOP_COLOR_FILE, "%.1f", CGI_EN_COLOR_UNIT, 0.0},

    { NULL, NULL, {0,}, 0, 0 }
};
/* ================================================================================ */
// LOCAL FUNCTION
static float dtor(float d)
{
    return (d * PI_DFS) / 180.;
}


/* ================================================================================ */
// FUNCTION
gdImagePtr fnSiteImgComment(struct tm stFileTime, char *szSiteName, char *szProductType, char *szDataType, int nImgXdim)
{
    char szStr[MAX_STR] = {0,};
    char szComment[MAX_STR] = {0,};
    gdImagePtr pImg_Comment;
    int nWhite = 0;
    int nBlack = 0;
    char szDateTime[MAX_STR] = {0,};

    if(szSiteName == NULL || szDataType == NULL)
        return NULL;

    if((pImg_Comment = gdImageCreateTrueColor(nImgXdim, CGI_SITE_DF_TOP_HEIGHT)) == NULL)
        return NULL;

    strftime(szDateTime, sizeof(szDateTime), "%Y.%m.%d. %H:%M(KST)", &stFileTime);


    nWhite = gdImageColorAllocate(pImg_Comment, 255, 255, 255);
    nBlack = gdImageColorAllocate(pImg_Comment, 0, 0, 0);

    gdImageFilledRectangle(pImg_Comment, 0, 0, nImgXdim, CGI_SITE_DF_TOP_HEIGHT, nWhite);

    if(strcmp(szDataType, "DZ") == 0)
    {
        sprintf(szStr,"dBZ");
    }
    else if(strcmp(szDataType, "VR") == 0)
    {
        sprintf(szStr,"m/s");
    }
    else if(strcmp(szDataType, "SW") == 0)
    {
        sprintf(szStr,"m/s");
    }
    else if(strcmp(szDataType, "CZ") == 0)
    {
        sprintf(szStr,"dBZ");
    }
    else if((strcmp(szDataType, "RN") == 0) || (strcmp(szDataType, "SN") == 0))
    {
        sprintf(szStr,"mm/hr");
    }
    else if(strcmp(szDataType, "DR") == 0)
    {
        sprintf(szStr,"dB");
    }
    else if(strcmp(szDataType, "RH") == 0)
    {
        sprintf(szStr," ");
    }
    else if(strcmp(szDataType, "PH") == 0)
    {
        sprintf(szStr,"deg");
    }
    else if(strcmp(szDataType, "KD") == 0)
    {
        sprintf(szStr,"deg/km");
    }
    else
    {
        sprintf(szStr,"dBZ");
    }

    sprintf(szComment, "%s Radar %s(%s) %s", szSiteName, szProductType, szDataType, szDateTime);
    gdImageStringTTF(pImg_Comment, NULL, nBlack, NANUMGOTHIC_FONT_PATH, 11, 0.0, 10, CGI_SITE_DF_TOP_HEIGHT-5, szComment);
    gdImageStringTTF(pImg_Comment, NULL, nBlack, NANUMGOTHIC_FONT_PATH, 8, 0.0, nImgXdim-55, CGI_SITE_DF_TOP_HEIGHT-5, szStr);

    return pImg_Comment;
}

void fnNoDataDisp(int nImgYdim, int nImgXdim)
{
    gdImagePtr  pImg;
    char        rgcText[126]    = {0,};
    int         rgnBrect[8]     = {0};
    char        *rgcErr         = NULL;
    int         nWhite          = 0;
    int         nBlack          = 0;
    int         nTransparent    = 0;
    char        rgcFont[MAX_STR]     = {0,};
    int         nX              = 0;

    pImg = gdImageCreateTrueColor(nImgXdim, nImgYdim);
    gdImageAlphaBlending(pImg, 0);
    gdImageSaveAlpha(pImg, 1);
    nBlack = gdImageColorAllocate(pImg, 0, 0, 0);
    nWhite = gdImageColorAllocateAlpha(pImg, 255, 255, 255, 0);
    nTransparent = gdImageColorAllocateAlpha(pImg, 0, 0, 0, 127);

    gdImageFilledRectangle(pImg, 0, 0, nImgXdim, nImgYdim, nTransparent);

    sprintf(rgcFont, "%s", NANUMGOTHIC_FONT_PATH);

    sprintf(rgcText, "%s", "선택된 시각의 레이더자료가 없습니다.");
    gdImageStringFT(NULL, &rgnBrect[0], nBlack, rgcFont, CGI_SITE_DF_NODISP_FONT_SIZE, 0.0, 0, 0, rgcText);

    nX = rgnBrect[2];
    rgcErr = gdImageStringFT(pImg, &rgnBrect[0], nBlack, rgcFont, CGI_SITE_DF_NODISP_FONT_SIZE, 
                             0.0, (nImgXdim-nX)/2, nImgYdim/2, rgcText);

    fprintf(stdout, "Content-type: image/png\r\n\r\n");
    gdImagePng(pImg,stdout);
    gdImageDestroy(pImg);
}

void fnNoDataDisp_MAP(char *szQC_Type, char *szProductType, char *szDataType, float fProductArg, float fMaxRange, int nGateSize, int nBinCount, float fNyqVel, int nImgXdim, int nImgYdim)
{
    gdImagePtr  pImg;
    char        rgcText[126]        = {0,};
    int         rgnBrect[8]         = {0};
    char        *rgcErr             = NULL;
    int         nWhite              = 0;
    int         nBlack              = 0;
    char        rgcFont[MAX_STR]    = {0,};
    int         nX                  = 0;
    int         echoColorTbl[CGI_DF_COLOR_MAX] = { 0, };
    int         dispColorTbl[CGI_EN_DISP_COLOR_MAX] = { 0, };
    CGI_COLOR_TBL *pColor_ini = NULL;
    st_ColorInfo  stColorInfo;

    if(szProductType == NULL || szDataType == NULL)
        return;

    if(fnGetColorInfo(szProductType, szDataType, &stColorInfo) == -1)
        return;

    if((pColor_ini = fnReadColorTable(stColorInfo.m_szColorFile)) == NULL)
        return;

    pImg = gdImageCreateTrueColor(nImgXdim+CGI_SITE_DF_RIGHT_WIDTH, nImgYdim+CGI_SITE_DF_BOTTOM_HEIGHT);

    fnAllocColorTbl(pImg, pColor_ini, echoColorTbl, dispColorTbl);

    gdImageAlphaBlending(pImg, 0);
    gdImageSaveAlpha(pImg, 1);
    nBlack = gdImageColorAllocate(pImg, 0, 0, 0);
    nWhite = gdImageColorAllocateAlpha(pImg, 255, 255, 255, 0);

    gdImageFilledRectangle(pImg, 0, 0, nImgXdim-1, nImgYdim-1, nWhite);
    gdImageRectangle(pImg, 0, 0, nImgXdim, nImgYdim, nBlack);

    sprintf(rgcFont, "%s", NANUMGOTHIC_FONT_PATH);

    sprintf(rgcText, "%s", "선택된 시각의 레이더자료가 없습니다.");
    gdImageStringFT(NULL, &rgnBrect[0], nBlack, rgcFont, CGI_SITE_DF_NODISP_FONT_SIZE, 0.0, 0, 0, rgcText);

    nX = rgnBrect[2];
    rgcErr = gdImageStringFT(pImg, &rgnBrect[0], nBlack, rgcFont, CGI_SITE_DF_NODISP_FONT_SIZE, 
                             0.0, (nImgXdim-nX)/2, nImgYdim/2, rgcText);

    fnWriteSiteColorIndx(pImg, nImgXdim, nImgYdim, pColor_ini, echoColorTbl, stColorInfo, "RN");
    fnWriteBottomText(pImg, szQC_Type, szProductType, szDataType, fProductArg, fMaxRange, nGateSize, fNyqVel, nBinCount, nImgXdim, nImgYdim);

    fprintf(stdout, "Content-type: image/png\r\n\r\n");
    gdImagePng(pImg,stdout);
    gdImageDestroy(pImg);

    free(pColor_ini);
}

int fnDrawMap(gdImagePtr pImg, float fSiteLon, float fSiteLat, float fXo, float fYo, float fImgGridKm, int nMapColor)
{
    FILE *fp;
    int     nLine   = 0;
    int     nType   = 0;
    int     nIdx    = 0;
    float   fXIdx   = 0.0;
    float   fYIdx   = 0.0;
    float   fIdx_x  = 0.0;
    float   fIdx_y  = 0.0;
    float   fLon    = 0.0;
    float   fLat    = 0.0;
    st_AzedParameter azed_parameter;
    st_AzedVar azed_var;

    // 지도 파일을 읽자
    if (!(fp = fopen (MAP_FILE , "r")))
    {
        return -1;
    }
    //지도 초기화
    azed_parameter = fnCgiGetMapInfoAzed(KMA_MAP_RE, fSiteLon, fSiteLat, fSiteLon, fSiteLat, fImgGridKm, fXo, fYo);
    azed_var.m_nFirst = 0;

    while(fread(&nLine,sizeof(nLine),1,fp) != 0)
    {
        fread(&nType,sizeof(nType),1,fp);
        fread(&fLat,sizeof(fLat),1,fp);
        fread(&fLon,sizeof(fLon),1,fp);
        fnCgiAzedProj(&fLon, &fLat, &fXIdx, &fYIdx, 0, azed_parameter, &azed_var);
        fIdx_x = fXIdx;
        fIdx_y = fYIdx;

        //선 두께 정의
        gdImageSetThickness(pImg,1);
        for (nIdx = 1; nIdx < nLine; nIdx++)
        {
            fread(&fLat,sizeof(fLat),1,fp);
            fread(&fLon,sizeof(fLon),1,fp);

            if(nType == 3)
                continue;

            fnCgiAzedProj(&fLon, &fLat, &fXIdx, &fYIdx, 0, azed_parameter, &azed_var);
            gdImageLine(pImg, (int)(fXIdx+0.5),  (fYo*2-(int)(fYIdx+0.5)-1), 
                              (int)(fIdx_x+0.5), (fYo*2-(int)(fIdx_y+0.5)-1), nMapColor);

            fIdx_x = fXIdx;
            fIdx_y = fYIdx;
        }
    }
    fclose(fp);

    return 0;
}

int fnGetColorInfo(char* szProductType, char* szDataType, st_ColorInfo *pBuf)
{
    int nCnt = 0;

    if(pBuf == NULL || szProductType == NULL || szDataType == NULL)
        return -1;

    while(nCnt < 1000)
    {
        if(ColorInfoTbl[nCnt].m_szProductType == NULL)
        {
            break;
        }

        if(!strcmp(ColorInfoTbl[nCnt].m_szProductType, szProductType) && 
           !strcmp(ColorInfoTbl[nCnt].m_szDataType,    szDataType))
        {
            memcpy(pBuf , &ColorInfoTbl[nCnt], sizeof(st_ColorInfo));
            return 0;
        }

        nCnt++;
    }

    return -1;
}

int fnDrawRangeRing(gdImagePtr pImg, int nLineColor, float fImgGridKm, int nDimCenter)
{
    int nIdx = 0;
    int nRadiusGap = 100/fImgGridKm;
    
    nIdx = nRadiusGap * 2;
    while (nIdx < (nDimCenter * 2))
    {
        gdImageArc(pImg, nDimCenter, nDimCenter, nIdx, nIdx, 0, 360, nLineColor);
        nIdx += (nRadiusGap * 2);
    }

    return 0;
}

int fnDrawRangeDirection(gdImagePtr pImg, int nLineColor)
{
    int nDimCenter = 256;
    int nXdim = nDimCenter*2+1;
    int nYdim = nDimCenter*2+1;


    gdImageLine(pImg, 0, 0, nXdim-1, nYdim-1, nLineColor);
    gdImageLine(pImg, nXdim-1, 0, 0, nYdim-1, nLineColor);
    gdImageLine(pImg, nDimCenter, 0, nDimCenter, nYdim-1, nLineColor);
    gdImageLine(pImg, 0, nDimCenter, nXdim-1, nDimCenter, nLineColor);

    return 0;
}

int fnWriteSiteColorIndx(gdImagePtr pImg, int nImgXdim, int nImgYdim, CGI_COLOR_TBL *pColor_ini, int rgnColor[], st_ColorInfo stColorInfo, char *szDataType)
{
    int     nIdx                = 0;
    int     nCellYdim           = 0;
    int     nYdim               = 0;
    int     nBlack              = 0;
    int     nWhite              = 0;
    int     nX_pos              = 0;
    int     nY_pos              = 0;
    int     nCount              = 0;
    char    szStr[MAX_STR]      = {0,}; //출력할 파일 경로
    char    szFormat[MAX_STR]   = {0,};
    int     nX_Cell             = CGI_SITE_DF_COLOR_BAR_WIDTH;

    if(pImg == NULL || pColor_ini == NULL || rgnColor == NULL)
        return -1;

    nBlack       = gdImageColorAllocate(pImg, 0, 0, 0);
    nWhite       = gdImageColorAllocate(pImg, 255, 255, 255);

    gdImageFilledRectangle(pImg, nImgXdim, 0, nImgXdim+CGI_SITE_DF_RIGHT_WIDTH, nImgYdim, nWhite);

    nX_pos = nImgXdim;
    nYdim = nImgYdim;
    nCellYdim = (nYdim) / (pColor_ini->m_iEchoColorCnt);
    nCount = 0;
    for(nIdx = (pColor_ini->m_iEchoColorCnt)-1; nIdx >= 0; nIdx--)
    {
        nY_pos = nCellYdim * nCount++;
        if(nIdx > 0)
        {
            gdImageFilledRectangle(pImg, nX_pos, nY_pos , nX_pos + nX_Cell , nY_pos + nCellYdim, rgnColor[nIdx]);
        }
        else
        {
            gdImageFilledRectangle(pImg, nX_pos, nY_pos , nX_pos + nX_Cell , nImgYdim, rgnColor[nIdx]);
        }
    }

    nCount = 0;
    for(nIdx = (pColor_ini->m_iEchoColorCnt)-2; nIdx >= 0; nIdx--)
    {
        if(stColorInfo.m_nColorKind == CGI_EN_COLOR_RAIN)
        {
            if(strcmp(szDataType,"SN") == 0)
            {
                if(pColor_ini->m_echoColorTbl[nIdx].m_fRain < 1)
                    strcpy(szFormat, "%.2f");
                else
                    strcpy(szFormat, "%.0f");
            }
            else
            {
                if(pColor_ini->m_echoColorTbl[nIdx].m_fRain < 10)
                    strcpy(szFormat, "%.1f");
                else
                    strcpy(szFormat, "%.0f");
            }
        }
        else
        {
            strcpy(szFormat, stColorInfo.m_szDispFormat);
        }

        if(stColorInfo.m_nColorKind == CGI_EN_COLOR_RAIN)
            sprintf(szStr, szFormat, pColor_ini->m_echoColorTbl[nIdx].m_fRain);
        else
            sprintf(szStr, szFormat, pColor_ini->m_echoColorTbl[nIdx].m_fUnit);

        nX_pos = nImgXdim + nX_Cell + 5;
        nY_pos = nCellYdim * nCount;
        nY_pos += nCellYdim - gdFontGetSmall()->h/2;

        gdImageString(pImg, gdFontGetSmall(), nX_pos, nY_pos, (unsigned char*)szStr, nBlack);
        nCount++;
    }

    nX_pos = nImgXdim;
    nY_pos = 0;
    gdImageRectangle(pImg, nX_pos, nY_pos, nX_pos + nX_Cell, nImgYdim, nBlack);

    return 0;
}

int fnWriteBottomText(gdImagePtr pImg, char *szQC_Type, char *szProductType, char *szDataType, float fProductArg, float fMaxRange, int nGateSize, int nBinCount, float fNyqVel, int nImgXdim, int nImgYdim)
{
    int nBlack              = 0;
    int nWhite              = 0;
    char szStr[MAX_STR]     = {0,}; //출력할 파일 경로
    char szTemp1[MAX_STR]   = {0,};
    char szTemp2[MAX_STR]   = {0,};
    char szTemp3[MAX_STR]   = {0,};
    int nX_pos              = 0;
    int nY_pos              = 0;
    int nBotTextSize        = CGI_SITE_DF_BOTTOM_HEIGHT;
    int nX_Cell             = CGI_SITE_DF_COLOR_BAR_WIDTH;

    nBlack = gdImageColorAllocate(pImg, 0, 0, 0);
    nWhite = gdImageColorAllocate(pImg, 255, 255, 255);

    gdImageFilledRectangle(pImg, 0, nImgYdim, nImgXdim + CGI_SITE_DF_RIGHT_WIDTH, nImgYdim + nBotTextSize, nWhite);
    gdImageRectangle(pImg, 0, nImgYdim-1, nImgXdim + nX_Cell, nImgYdim + nBotTextSize+30-1, nBlack);

    if(strcmp(szProductType, "PPI") == 0)
        sprintf(szTemp1, "Elevation:%.2f", fProductArg);
    else if(strcmp(szProductType, "CAPPI") == 0)
        sprintf(szTemp1,"Height:%.1f km", fProductArg);
    else
        sprintf(szTemp1,"Height:%.1f km", fProductArg);

    sprintf(szTemp2,"MaxRange:%.0fkm  GateSize:%dm  Gates:%d", fMaxRange, nGateSize, nBinCount);

    sprintf(szTemp3, szQC_Type);

    if(strcmp(szDataType, "VR") != 0)
        sprintf(szStr, "%s %s %s", szTemp1, szTemp2, szTemp3);
    else
        sprintf(szStr,"%s %s Nyq.Vel:%.2fm/s, %s", szTemp1, szTemp2, fNyqVel, szTemp3);

    nX_pos = 10; // SPACE
    nY_pos = nImgYdim + 2;

    gdImageString(pImg, gdFontGetSmall(), nX_pos, nY_pos, (unsigned char*)szStr, nBlack);

    return 0;
}

int fnSiteAws(gdImagePtr pImg, int nImgXdim, int nImgYdim, float fImgGridKm, float fSiteLon, float fSiteLat, float fXo, float fYo, int iAwsColor, int iFontColor)
{
    char        szAwsFile[MAX_STR]   = "";
    FILE*       pFp                  = NULL;
    int         iAwsNum              = 0;
    int         iAwsIdx              = 0;
    int         iAwsX                = 0;
    int         iAwsY                = 0;
    char        szAwsName[MAX_STR]   = "";
    float       fAwsLon              = 0.0;
    float       fAwsLat              = 0.0;
    float       fAwsX                = 0.0;
    float       fAwsY                = 0.0;
    char        szFontFile[MAX_STR]  = "";
    double      dFontSize            = 0.0;

    st_AzedParameter azed_parameter;
    st_AzedVar azed_var;

    if(pImg == NULL)
        return -1;

    azed_parameter = fnCgiGetMapInfoAzed(KMA_MAP_RE, fSiteLon, fSiteLat, fSiteLon, fSiteLat, fImgGridKm, fXo, fYo);
    azed_var.m_nFirst = 0;
    
    snprintf(szFontFile, sizeof(szFontFile), "%s", AWS_FONT);
    dFontSize = CGI_DF_AWS_FONT_SIZE;

    snprintf(szAwsFile, sizeof(szAwsFile), "%s", AWS_FILE);

    if((pFp = fopen(szAwsFile, "rt")) == NULL)
        return -1;
    
    if(fscanf(pFp, "%d", &iAwsNum) != 1) 
    {   fclose(pFp); return -1; }

    for(iAwsIdx = 0; iAwsIdx < iAwsNum; iAwsIdx++)
    {
        memset(szAwsName, 0x00, sizeof(szAwsName));
        if(fscanf(pFp, "%s %f %f", szAwsName, &fAwsLat, &fAwsLon) != 3)
            break;

        fnCgiAzedProj(&fAwsLon, &fAwsLat, &fAwsX, &fAwsY, 0, azed_parameter, &azed_var);
        iAwsX = (int)fAwsX+1;
        iAwsY = nImgYdim- (int)fAwsY-1;
        if(iAwsX < 0 || iAwsX > nImgXdim || iAwsY < 0 || iAwsY > nImgYdim) continue;

        gdImageFilledEllipse(pImg, iAwsX, iAwsY, 4, 4, iAwsColor);

        iAwsX -= CGI_DF_AWS_NAME_MV_POSITION_X;
        iAwsY -= CGI_DF_AWS_NAME_MV_POSITION_Y;

        gdImageStringTTF(pImg, NULL, iFontColor, szFontFile, dFontSize, 0.0, iAwsX, iAwsY, szAwsName);
    }

    fclose(pFp);

    return 0;
}

int fnWritePointRain(float **pSiteData, char *szDataType, int nSiteXdim, int nSiteYdim, float fSiteGridKm, float fSiteLon, float fSiteLat, float fXo, float fYo, float fPointLon, float fPointLat, float fZr_A, float fZr_B)
{
    int   iAwsX = 0;
    int   iAwsY = 0;
    float fAwsX = 0.0;
    float fAwsY = 0.0;

    st_AzedParameter azed_parameter;
    st_AzedVar azed_var;

    azed_parameter = fnCgiGetMapInfoAzed(KMA_MAP_RE, fSiteLon, fSiteLat, fSiteLon, fSiteLat, fSiteGridKm, fXo, fYo);
    azed_var.m_nFirst = 0;
    
    fnCgiAzedProj(&fPointLon, &fPointLat, &fAwsX, &fAwsY, 0, azed_parameter, &azed_var);
    iAwsX = (int)(fAwsX+0.5);
    iAwsY = (int)(nSiteYdim- fAwsY-1);

    if(iAwsX < 0 || iAwsX > nSiteXdim || iAwsY < 0 || iAwsY > nSiteYdim)
    {
        fprintf(stdout, "Content-type: text/html\r\n\r\n");
        fprintf(stdout, "%s\r\n\r\n", "-");
    }
    else
    {
        if(pSiteData[iAwsY][iAwsX] == BAD_VALUE_F)
        {
            fprintf(stdout, "Content-type: text/html\r\n\r\n");
            fprintf(stdout, "%s\r\n\r\n", "-");
        }
        else
        {
            if((strcmp(szDataType, "RN") == 0) || (strcmp(szDataType, "SN") == 0))
                pSiteData[iAwsY][iAwsX] = (float)fnDbz_To_R_f((double)pSiteData[iAwsY][iAwsX], fZr_A, fZr_B);
            fprintf(stdout, "Content-type: text/html\r\n\r\n");
            fprintf(stdout, "%.2f\r\n\r\n", pSiteData[iAwsY][iAwsX]);
        }
    }
    
    return 0;
}

int fnRainPointFileWrite(float **pImgData, char *szDataType, long lN_Date, int nSiteYdim, int nSiteXdim, float fZr_A, float fZr_B)
{
    FILE    *pFp                     = NULL;
    int     nXIdx                    = 0;
    int     nYIdx                    = 0;
    char    szWriteFileName[MAX_STR] = {0,};

    sprintf(szWriteFileName, "%s/%ld.bin", RAIN_POINT_WRITE_PATH, lN_Date);
    if((pFp = fopen(szWriteFileName, "wb")) == NULL)
        return -1;
    
    for(nYIdx = 0; nYIdx < nSiteYdim; nYIdx++)
    {
        if((strcmp(szDataType, "RN") == 0) || (strcmp(szDataType, "SN") == 0))
        {
            for(nXIdx = 0; nXIdx < nSiteXdim; nXIdx++)
            {
                pImgData[nYIdx][nXIdx] = (float)fnDbz_To_R_f((double)pImgData[nYIdx][nXIdx], fZr_A, fZr_B);
            }
        }
        fwrite(pImgData[nYIdx], sizeof(float), nSiteXdim, pFp);
    }

    fclose(pFp);
    return 0;
}

int fnWriteEchoInfo(gdImagePtr pImg, char *szProductType, char *szDataType, char *szSiteName, struct tm FileTime, int nBlack, int nImgXdim, int nFlag)    // nFlag = 1 이면 대기수상체
{
    char szFormat[MAX_STR]  = "";
    char szInfo[MAX_STR]    = "";
    int  rgnBrect[8]        = {0};
    int  nX                 = 0;
    int  nFont_Size         = 15;
    int  nY_pos             = 20;

    if(pImg == NULL)
        return -1;

    if(nFlag == 0)
    {
        sprintf(szFormat, "%s Radar %s(%s) %%Y.%%m.%%d. %%H:%%M(KST)", szSiteName, szProductType, szDataType);
        strftime(szInfo, sizeof(szInfo), szFormat, &FileTime);
    }
    else
    {
        sprintf(szFormat, "%s Radar Hydrometeors %%Y.%%m.%%d. %%H:%%M(KST)", szSiteName);
        strftime(szInfo, sizeof(szInfo), szFormat, &FileTime);
    }   

    gdImageStringFT(NULL, &rgnBrect[0], nBlack, FONT_PATH, nFont_Size, 0.0, 0, 0, szInfo);
    nX = rgnBrect[2];
    gdImageStringFT(pImg, &rgnBrect[0], nBlack, FONT_PATH, nFont_Size, 0.0, (nImgXdim-nX)/2, nY_pos, szInfo);

    return 0;
}

int fnWindDraw(gdImagePtr pImg, WIND w, int nLine_Color, int nSize, int nWing, int nImgXdim, int nImgYdim)
{
    int     i           = 0;
    float   r           = 0.0f;
    float   fStart_X    = 0.0f;
    float   fStart_Y    = 0.0f;
    float   fEnd_X      = 0.0f;
    float   fEnd_Y      = 0.0f;
    int     nCnt_25     = 0;
    int     nCnt_5      = 0;
    int     nFlg_2      = 0;
    float   fU_X        = 0.0f;
    float   fU_Y        = 0.0f;
    float   fW_R        = 0.0f; 
    gdPoint w_2[5][2];
    gdPoint w_5[5][2];
    gdPoint w_25[5][3];

    if (w.ws <= 0)
    {
        return 1;
    }
    fStart_X = w.x;
    fStart_Y = w.y;
    if (fStart_X < 0 || fStart_X > nImgXdim) return -1;
    if (fStart_Y < 0 || fStart_Y > nImgYdim) return -1;

    r = dtor(w.wd - 90);

    fEnd_X = fStart_X + (cos(r) * nSize);
    fEnd_Y = fStart_Y + (sin(r) * nSize);

    gdImageLine(pImg, fStart_X, fStart_Y, fEnd_X, fEnd_Y, nLine_Color);
    fU_X = (fEnd_X - fStart_X) / 5.;
    fU_Y = (fEnd_Y - fStart_Y) / 5.;
    fW_R = dtor(w.wd - 30);


    for(i = 0; i < 5; i++)
    {
        w_5[i][0].x = fEnd_X - fU_X * i;
        w_5[i][0].y = fEnd_Y - fU_Y * i;
        w_5[i][1].x = w_5[i][0].x + (cos(fW_R) * nWing);
        w_5[i][1].y = w_5[i][0].y + (sin(fW_R) * nWing);

        w_2[i][0].x = fEnd_X - fU_X * i;
        w_2[i][0].y = fEnd_Y - fU_Y * i;
        w_2[i][1].x = w_2[i][0].x + (cos(fW_R) * (nWing / 2.));
        w_2[i][1].y = w_2[i][0].y + (sin(fW_R) * (nWing / 2.));

        w_25[i][0].x = fEnd_X - fU_X * (i - 1);
        w_25[i][0].y = fEnd_Y - fU_Y * (i - 1);
        w_25[i][1].x = fEnd_X - fU_X * i;
        w_25[i][1].y = fEnd_Y - fU_Y * i;
        w_25[i][2].x = w_25[i][1].x + (cos(fW_R) * nWing);
        w_25[i][2].y = w_25[i][1].y + (sin(fW_R) * nWing);
    }

    nCnt_25 = floor(w.ws / 25.);
    nCnt_25 += (w.ws - (nCnt_25 * 25) >= 24) ? 1 : 0;
    r = w.ws - (nCnt_25 * 25);

    if(r > 0)
    {
        nCnt_5 = floor(r / 5.);
        nCnt_5 += r - (nCnt_5 * 5) >= 4 ? 1 : 0;
        r = r - ((nCnt_25 * 25) + (nCnt_5 * 5));
    }

    if(r >= 1.5)
    {
        nFlg_2 = 1;
    }

    // 25 m/s
    for(i = 0; i < nCnt_25; i++)
    {
        gdImageFilledPolygon(pImg, w_25[i], 3, nLine_Color);
    }

    // 5 m/s
    for(i = nCnt_25; i < nCnt_5 + nCnt_25; i++)
    {
        gdImageLine(pImg, w_5[i][0].x, w_5[i][0].y, w_5[i][1].x, w_5[i][1].y, nLine_Color);
    }

    // 2 m/s
    if(nFlg_2 == 1)
    {
        if(i == 0) i = 1;
        gdImageLine(pImg, w_2[i][0].x, w_2[i][0].y, w_2[i][1].x, w_2[i][1].y, nLine_Color);
    }

    return 1;

}



/* ================================================================================ */
