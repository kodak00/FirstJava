/* ================================================================================ */
//
// LGT Disp Function
//
// 2016.09.26 SnK 
//
/* ================================================================================ */
// Include

#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "gd.h"
#include "cgi_cmm_util.h"
#include "cgi_cmm_color.h"
#include "cgi_lgt_disp.h"

char *strptime(const char *s, const char *format, struct tm *tm);
/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function

struct tm getConvStrToDateTime(char *str)
{
    struct tm   tm_ptr;
    char        szBuf[15];

    switch (strlen(str))
    {
        case 14 :
            sprintf(szBuf, "%s", str);
            break;
        case 12 :
            sprintf(szBuf, "%s00", str);
            break;
        case 10 :
            sprintf(szBuf, "%s0000", str);
            break;
        case 8 :
            sprintf(szBuf, "%s000000", str);
            break;
        case 6 :
            sprintf(szBuf, "%s01000000", str);
            break;
        case 4 :
            sprintf(szBuf, "%s0101000000", str);
            break;
        case 0 :
            sprintf(szBuf, "%s20000101000000", str);
            break;
        default :
            sprintf(szBuf, "%s20000101000000", str);
            break;
    }

    strptime(szBuf, "%Y%m%d%H%M%S", &tm_ptr);

    return tm_ptr;
}

static int fnLevelColorDisp(char szP_type[], int nImgYdim, char szUnit[], gdImagePtr pImg, int rgnColor[], CGI_COLOR_TBL* pColor_ini, char szEndTime[], int nLgt_intv)
{
    char    szText[TEXT_SIZE]       = { 0, };  
    char    szTitleUnit[TEXT_SIZE]  = { 0, };  
    int     rgnBrect[BRECT_SIZE]    = { 0, };  
    float   fDy                     = 0.0;     
    int     nTemp_I                 = 0;       
    int     nTemp_J                 = 0;       
    int     nCnt                    = 0;       
    int     nTable_start_x          = 0;       
    int     nTable_start_y          = 0;       
    int     nTable_finish_x         = 0;       
    int     nTable_finish_y         = 0;       
    char    szFont[FONT_SIZE]       = { 0, };  
    int     nX_pos                  = 0;       
    int     nY_pos                  = 0;       
    int     nWhite                  = 0;       
    int     nBlack                  = 0;       
    int     nTransparent            = 0;       
    int     nStrYsize               = 0;
    char    szDatetime[DATE_SIZE]   = { 0, };
    
    struct tm run_datetime;
    struct tm tmp_datetime;

    if((pImg == NULL) || (pColor_ini == NULL))
    {
        return -1;
    }

    memset(&run_datetime, 0x00, sizeof(struct tm));
    memset(&tmp_datetime, 0x00, sizeof(struct tm));

    gdImageAlphaBlending(pImg, 0);
    gdImageSaveAlpha(pImg, 1);
    nWhite  = gdImageColorAllocate(pImg, 255, 255, 255);
    nBlack  = gdImageColorAllocate(pImg,  0,  0,  0);
    nTransparent  = gdTrueColorAlpha(255, 255, 255, 127);

    gdImageFilledRectangle(pImg, 0, 0, IMAGE_INDEX_RIGHT_SIZE, nImgYdim, nTransparent);

    sprintf(szFont, "%s/gulim.ttc", FONT_PATH); 

    sprintf(szTitleUnit, "%s", szUnit);

    if(strcmp(szP_type, "LGTVWORLD") == 0)
    {
        gdImageStringFT(pImg, &rgnBrect[0], nBlack, szFont, 10, 0.0, 1, 20, szTitleUnit);
    }
    else
    {
        gdImageStringFT(pImg, &rgnBrect[0], nWhite, szFont, 10, 0.0, 1, 20, szTitleUnit);
    }

    nCnt = LEVEL_MAX;
    nTable_start_x  = 0;
    nTable_finish_x = 10;
    nTable_start_y  = 30;
    nTable_finish_y = nImgYdim;

    fDy = (int)((nTable_finish_y-nTable_start_y)/(nCnt));

    for (nTemp_I = 0, nTemp_J = nCnt - 1; nTemp_I < nCnt; nTemp_I++, nTemp_J--) 
    {
        gdImageFilledRectangle(pImg, 
                nTable_start_x, 
                nTable_start_y + (fDy * nTemp_I), 
                nTable_finish_x, 
                nTable_start_y + (fDy * (nTemp_I + 1)),
                rgnColor[nTemp_J]);
    }

    gdImageRectangle(pImg,
            nTable_start_x,
            nTable_start_y,
            nTable_finish_x,
            nTable_start_y + (fDy * nCnt),
            nBlack);

    nStrYsize = (rgnBrect[1] - rgnBrect[7]);

    if((strcmp(szP_type, "LGTTIME") == 0) || (strcmp(szP_type, "LGTAREA") == 0) || (strcmp(szP_type, "LGTVWORLD") == 0))
    {
        for(nTemp_I = 0; nTemp_I <= nCnt; nTemp_I++) 
        {
            sprintf(szDatetime, "%s", szEndTime);
            run_datetime = getConvStrToDateTime(szDatetime);

            tmp_datetime = fnGetIncMin(run_datetime, (-nTemp_I*nLgt_intv));

            strftime(szText, sizeof(szText), "%m.%d\n%H:%M", &tmp_datetime);

            nX_pos = nTable_finish_x + LEVEL_TEXT_GAP;

            if(nTemp_I == 0) 
            {
                nY_pos = nTable_start_y + nStrYsize - 5;
            }
            else if(nTemp_I == nCnt) 
            {
                nY_pos = nTable_start_y + (fDy * nTemp_I) - (nStrYsize/2) -12;
            }
            else
            {
                nY_pos = nTable_start_y + (fDy * nTemp_I) + (nStrYsize/2) -5;
            }

            if(strcmp(szP_type, "LGTVWORLD") == 0)
            {
                gdImageStringFT(pImg, NULL, nBlack, szFont, 8, 0.0, nX_pos, nY_pos, szText);
            }
            else
            {
                gdImageStringFT(pImg, NULL, nWhite, szFont, 8, 0.0, nX_pos, nY_pos, szText);
            }
        }
    }
    else if(strcmp(szP_type, "LGTINTN") == 0)
    {
        for(nTemp_I = 1, nTemp_J= nCnt-1; nTemp_J>=0; nTemp_I++, nTemp_J--) 
        {
            sprintf(szText, "%3d", (int)pColor_ini->m_echoColorTbl[nTemp_J].m_fRain);
            
            nX_pos = nTable_finish_x + LEVEL_TEXT_GAP;

            if(nTemp_I == 0) 
            {
                nY_pos = nTable_start_y + nStrYsize;
            }
            else if(nTemp_I == nCnt) 
            {
                nY_pos = nTable_start_y + (fDy * nTemp_I) - (nStrYsize/2) ;
            }
            else
            {
                nY_pos = nTable_start_y + (fDy * nTemp_I) + (nStrYsize/2);
            }

            gdImageStringFT(pImg, NULL, nWhite, szFont, 8, 0.0, nX_pos, nY_pos, szText);
        }
    }

    return 0;
}

/* ================================================================================ */
// Function
 
void fnImageCircle(gdImagePtr pImg, int nX, int nY, int nColor)
{
    if(pImg == NULL)
        return;

    gdImageLine(pImg, nX-3,nY-1, nX-3, nY+1, nColor);
    gdImageLine(pImg, nX+3,nY-1, nX+3, nY+1, nColor);
    gdImageLine(pImg, nX-1,nY-3, nX+1, nY-3, nColor);
    gdImageLine(pImg, nX-1,nY+3, nX+1, nY+3, nColor);
    gdImageSetPixel(pImg, nX-2, nY-2, nColor);
    gdImageSetPixel(pImg, nX+2, nY-2, nColor);
    gdImageSetPixel(pImg, nX-2, nY+2, nColor);
    gdImageSetPixel(pImg, nX+2, nY+2, nColor);
}

void fnImagePlus(gdImagePtr pImg, int nX, int nY, int nColor)
{
    int nDiff = 3;

    if(pImg == NULL)
        return;
    
    gdImageLine(pImg, nX-nDiff, nY, nX+nDiff, nY, nColor);
    gdImageLine(pImg, nX, nY-nDiff, nX, nY+nDiff, nColor);
}

void fnImageFillArc(gdImagePtr pImg, int nX, int nY, int nWidth, int nHeight, int nColor)
{
    if(pImg == NULL)
        return;

    gdImageFilledArc(pImg, nX, nY, nWidth, nHeight, 0, 360, nColor, gdArc);
}

int fnCreateLevelColorImg(char szP_type[], int nImgYdim, char szEndTime[], int nLgt_intv)
{
    gdImagePtr      pImg                                 = NULL;    
    int             echoColorBar[CGI_DF_COLOR_MAX]       = { 0, };   
    int             dispColorBar[CGI_EN_DISP_COLOR_MAX]  = { 0, };   
    CGI_COLOR_TBL*  pColor_ini                           = NULL;     
    char            szUnit[TEXT_SIZE]                    = {0, };
    
    pImg    = gdImageCreateTrueColor(IMAGE_INDEX_RIGHT_SIZE, nImgYdim);

    if(strcmp(szP_type, "LGTTIME") == 0)
    {
        pColor_ini = fnReadColorTable(LGT_TIME_COLOR_FILE);
        sprintf(szUnit, "%s\n", "times");
    }
    else if(strcmp(szP_type, "LGTINTN") == 0)
    {
        pColor_ini = fnReadColorTable(LGT_POW_COLOR_FILE);
        sprintf(szUnit, "%s\n", "kA");
    }
    else /*LGTAREA*/
    {
        pColor_ini = fnReadColorTable(LGT_AREA_COLOR_FILE);
        sprintf(szUnit, "%s\n", "times");
    }
    
    fnAllocColorTbl(pImg, pColor_ini, echoColorBar, dispColorBar);

    fnLevelColorDisp(szP_type, nImgYdim, szUnit, pImg, echoColorBar, pColor_ini, szEndTime, nLgt_intv);

    fprintf(stdout, "Content-type: image/png\r\n\r\n");
    gdImagePng(pImg, stdout);
    fflush(stdout);

    gdFreeFontCache();
    free(pColor_ini);
    gdImageDestroy(pImg);

    return 0;
}

int fnImgTopTextDisp(gdImagePtr pImg, char szP_type[], char szStartTime[], char szEndTime[], int nLgt_intv, int nImgXdim)
{
    int         nBlack                               = 0;
    int         rgnBrect[BRECT_SIZE]                 = { 0, };
    char        szFont[FONT_SIZE]                    = { 0, };
    char        szText[TEXT_SIZE]                    = { 0, };
    int         nBrectlength                         = 0;
    char*       szErr                                = NULL;
    char        szEndTimes[TEXT_SIZE]                = "";
    char        szStartTimes[TEXT_SIZE]              = "";
    char        szIntv[TEXT_SIZE]                    = "";
    struct tm   stTime;

    if(pImg == NULL)
    {
        return -1;
    }

    memset(&stTime, 0x00, sizeof(struct tm));
    nBlack = gdImageColorAllocate(pImg, 0, 0, 0);
//    sprintf(szFont, "%s/NanumGothic.ttf", FONT_PATH);
    sprintf(szFont, "%s/times.ttf", FONT_PATH);

    strcpy(szEndTimes, szEndTime);
    strptime(szEndTimes, "%Y%m%d%H%M", &stTime);
    strftime(szEndTimes, sizeof(szEndTimes), "%Y.%m.%d. %H:%M", &stTime);


    if((strcmp(szP_type, "LGTTIME") == 0) || (strcmp(szP_type, "LGTINTN") == 0))
    {
        if(nLgt_intv >= 60)
        {
            nLgt_intv = nLgt_intv / 60;
            sprintf(szIntv, "%d HOUR", nLgt_intv);
        }
        else
        {   
            sprintf(szIntv, "%d MIN", nLgt_intv);
        }

        sprintf(szText, "LIGHTNING %s %s(KST)", szIntv, szEndTimes);
    }
    else if(strcmp(szP_type, "LGTAREA") == 0)
    {
        strcpy(szStartTimes, szStartTime);
        strptime(szStartTimes, "%Y%m%d%H%M", &stTime);
        strftime(szStartTimes, sizeof(szStartTimes), "%Y.%m.%d. %H:%M", &stTime);

        sprintf(szText, "LIGHTNING %s ~ %s(KST)", szStartTimes, szEndTimes);
    }

    gdImageStringFT(NULL, &rgnBrect[0], nBlack, szFont, 15, 0.0, 0, 0, szText);
    nBrectlength = rgnBrect[2] - rgnBrect[0];

    szErr = gdImageStringFT(pImg, &rgnBrect[0], nBlack, szFont, 15, 0.0, (nImgXdim - nBrectlength)/2, 40, szText);

    if(szErr)
    {
        gdFreeFontCache();
        gdImageDestroy(pImg);
        return -1;
    }

    gdFreeFontCache();
    return 0;
}


/* ================================================================================ */



