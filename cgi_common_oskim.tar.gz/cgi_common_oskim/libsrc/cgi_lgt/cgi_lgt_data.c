/* ================================================================================ */
//
// LGT Data Read  Function
//
// 2016.09.26 SnK 
//
/* ================================================================================ */
// Include

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <zlib.h>

#include "cgi_cmm_util.h"
#include "cgi_lgt_data.h"

char *strptime(const char *s, const char *format, struct tm *tm);

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable

static int  g_Nx1StrkesIdHashTbl[CGI_LGT_NX1_HASH_SCALE][CGI_LGT_NX1_HASH_MAX];

/* ================================================================================ */
// Static Function

static int fnChkLgtNx1StrkesId(int nStrkesId)
{
    int             nHashValue  = 0;
    int             nTblIdx     = 0;
    int             nRes        = 0;

    nHashValue = nStrkesId % CGI_LGT_NX1_HASH_SCALE;

    for(nTblIdx = 0; nTblIdx < CGI_LGT_NX1_HASH_MAX; nTblIdx++)
    {
        if(g_Nx1StrkesIdHashTbl[nHashValue][nTblIdx] == nStrkesId)
        {
            nRes = 0;
            break;
        }
        else if(g_Nx1StrkesIdHashTbl[nHashValue][nTblIdx] == 0)
        {
            g_Nx1StrkesIdHashTbl[nHashValue][nTblIdx] = nStrkesId;
            nRes = 1;
            break;
        }
    }

    return nRes;
}

static int fnSplitLgtDataLX1(char *szLine, LGT_NX1_DATA *pLgtData)
{
    char            szTemp[CGI_LGT_MAX_STR_LEN]         = "";
    char            *pToken                             = NULL;
    char            *pSavePtr                           = NULL;
    int             nItem                               = 0;
    char            szDate[32]                          = "";
    char            szTime[32]                          = "";
    char            szDateTime[CGI_LGT_ITEM_STR_LEN]    = "";
    struct  tm      lgtTm;

    if(szLine == NULL || pLgtData == NULL)
        return -1;

    snprintf(szTemp, sizeof(szTemp), "%s", szLine);
    pToken = strtok_r(szTemp, " ", &pSavePtr);

    for(nItem = 0; nItem < LGT_NX1_DATA_MAX && pToken != NULL; nItem++, pToken = strtok_r(NULL, " ", &pSavePtr))
    {
        if(nItem == LGT_NX1_STRKES_ID)
            pLgtData->m_nStrkes_id = atoi(pToken);
        else if(nItem == LGT_NX1_DATE)
            snprintf(szDate, sizeof(szDate), "%s", pToken);
        else if(nItem == LGT_NX1_TIME)
        {
            snprintf(szTime, strlen("HH:MM")+1, "%s", pToken);
            snprintf(szDateTime, sizeof(szDateTime) ,"%s %s", szDate, szTime);
            memset(&lgtTm, 0x00, sizeof(struct tm));
            strptime(szDateTime, "%Y-%m-%d %H:%M", &lgtTm);
            strftime(pLgtData->m_szDateTime, sizeof(pLgtData->m_szDateTime), "%Y%m%d%H%M", &lgtTm);
        }
        else if(nItem == LGT_NX1_NSFRAC)
            pLgtData->m_nNsfrac = atoi(pToken);
        else if(nItem == LGT_NX1_WKT)
            snprintf(pLgtData->m_szWKT_info, sizeof(pLgtData->m_szWKT_info), "%s", pToken);
        else if(nItem == LGT_NX1_LON)
            pLgtData->m_fLon = atof(pToken);
        else if(nItem == LGT_NX1_LAT)
            pLgtData->m_fLat = atof(pToken);
        else if(nItem == LGT_NX1_ALTITUDE)
            pLgtData->m_fAltitude = atof(pToken);
        else if(nItem == LGT_NX1_IMPACT)
            pLgtData->m_fImpact = atof(pToken);
        else if(nItem == LGT_NX1_ERR_RADIUS)
            pLgtData->m_fErrRadius = atof(pToken);
        else if(nItem == LGT_NX1_TYPE)
            pLgtData->m_cType = *(pToken);
        else if(nItem == LGT_NX1_N_SENSOR)
            pLgtData->m_nSensor = atoi(pToken);
        else if(nItem == LGT_NX1_SENOSR_NUM1)
            pLgtData->m_rgnSensorNum[0] = atoi(pToken);
        else if(nItem == LGT_NX1_SENOSR_NUM2)
            pLgtData->m_rgnSensorNum[1] = atoi(pToken);
        else if(nItem == LGT_NX1_SENOSR_NUM3)
            pLgtData->m_rgnSensorNum[2] = atoi(pToken);
        else if(nItem == LGT_NX1_SENOSR_NUM4)
            pLgtData->m_rgnSensorNum[3] = atoi(pToken);
        else if(nItem == LGT_NX1_SENOSR_NUM5)
            pLgtData->m_rgnSensorNum[4] = atoi(pToken);
        else if(nItem == LGT_NX1_SENOSR_NUM6)
            pLgtData->m_rgnSensorNum[5] = atoi(pToken);
        else if(nItem == LGT_NX1_SENOSR_NUM7)
            pLgtData->m_rgnSensorNum[6] = atoi(pToken);
        else if(nItem == LGT_NX1_SENOSR_NUM8)
            pLgtData->m_rgnSensorNum[7] = atoi(pToken);
        else if(nItem == LGT_NX1_QUALITY)
            pLgtData->m_nQuality = atoi(pToken);
        else if(nItem == LGT_NX1_FLASH_ID)
            snprintf(pLgtData->m_szFlash_id, sizeof(pLgtData->m_szFlash_id), "%s", pToken);
    }

    return 0;
}

static int fnSplitLgtDataKMA(char *szLine, LGT_KMA_DATA *pLgtData)
{
    char            szTemp[CGI_LGT_MAX_STR_LEN]         = "";
    char            *pToken                             = NULL;
    char            *pSavePtr                           = NULL;
    int             nItem                               = 0;
    char            szDate[32]                          = "";
    char            szTime[32]                          = "";
    char            szDateTime[CGI_LGT_ITEM_STR_LEN]    = "";
    struct  tm      lgtTm;

    if(szLine == NULL || pLgtData == NULL)
        return -1;

    snprintf(szTemp, sizeof(szTemp), "%s", szLine);
    pToken = strtok_r(szTemp, " ", &pSavePtr);

    for(nItem = 0; nItem < LGT_KMA_DATA_MAX && pToken != NULL; nItem++, pToken = strtok_r(NULL, " ", &pSavePtr))
    {
        if(nItem == LGT_KMA_DATE)
            snprintf(szDate, sizeof(szDate), "%s", pToken);
        else if(nItem == LGT_KMA_TIME)
        {
            snprintf(szTime, strlen("HH:MM")+1, "%s", pToken);
            snprintf(szDateTime, sizeof(szDateTime) ,"%s %s", szDate, szTime);
            memset(&lgtTm, 0x00, sizeof(struct tm));
            strptime(szDateTime, "%m/%d/%Y %H:%M", &lgtTm);
            lgtTm.tm_year += 2000;
            strftime(pLgtData->m_szDateTime, sizeof(pLgtData->m_szDateTime), "%Y%m%d%H%M", &lgtTm);
        }
        else if(nItem == LGT_KMA_LON)
            pLgtData->m_fLon = atof(pToken);
        else if(nItem == LGT_KMA_LAT)
            pLgtData->m_fLat = atof(pToken);
        else if(nItem == LGT_KMA_IMPACT)
            pLgtData->m_fImpact = atof(pToken);
        else if(nItem == LGT_KMA_TYPE)
            pLgtData->m_cType = *(pToken);
        else if(nItem == LGT_KMA_N_SENSOR)
            pLgtData->m_nSensor = atoi(pToken);
        else
            continue;
    }

    return 0;
}

/* ================================================================================ */
// Function
 
int fnReadLgtDataNX1(char *szStartTime, char *szEndTime, LGT_NX1_DATA pBuf[], int nBufMax)
{
    FILE            *pFp                        = NULL;
    char            szFile[CGI_LGT_MAX_STR_LEN] = "";
    char            szLine[CGI_LGT_MAX_STR_LEN] = "";
    int             nFileCnt                    = 0;
    int             nLgtCnt                     = 0;
    char            szRunDate[32]               = "";

    struct  tm      run_datetime;
    LGT_NX1_DATA    lgtData;

    if(szStartTime == NULL || szEndTime == NULL || pBuf == NULL)
        return -1;

    // 중복체크용 테이블 초기화
    memset(&g_Nx1StrkesIdHashTbl, 0x00, sizeof(g_Nx1StrkesIdHashTbl));

    memset(&run_datetime,   0x00, sizeof(struct tm));
    strptime(szStartTime, "%Y%m%d%H%M", &run_datetime);

    while(++nFileCnt <= CGI_LGT_NX1_FILE_READ_MAX)
    {
        strftime(szRunDate, sizeof(szRunDate), "%Y%m%d0000", &run_datetime);
        if(strcmp(szRunDate, szEndTime) > 0)
            break;

        strftime(szFile, sizeof(szFile), CGI_LGT_NX1_FILE_FORMAT, &run_datetime);

        if((pFp = fopen(szFile, "rt")) == NULL)
        {
            run_datetime = fnGetIncDay(run_datetime, 1);
            continue;
        }

        while(fgets(szLine, sizeof(szLine), pFp) != NULL)
        {
            szLine[strlen(szLine)-1] = '\0';

            memset(&lgtData, 0x00 ,sizeof(LGT_NX1_DATA));
            fnSplitLgtDataLX1(szLine, &lgtData);

            if(strcmp(lgtData.m_szDateTime, szStartTime) >= 0 && strcmp(lgtData.m_szDateTime, szEndTime) <= 0)
            {
                if(nLgtCnt < nBufMax)
                {
                    if(fnChkLgtNx1StrkesId(lgtData.m_nStrkes_id) == 1)
                    {
                        memcpy(&pBuf[nLgtCnt], &lgtData, sizeof(LGT_NX1_DATA));
                        nLgtCnt++;
                    }
                }
            }
        }

        fclose(pFp);
        run_datetime = fnGetIncDay(run_datetime, 1);
    }

    return nLgtCnt;
}

int fnReadLgtDataKMA(char *szStartTime, char *szEndTime, LGT_KMA_DATA *pBuf, int nBufMax)
{
    FILE            *pFp                        = NULL;
    char            szFile[CGI_LGT_MAX_STR_LEN] = "";
    char            szLine[CGI_LGT_MAX_STR_LEN] = "";
    int             nFileCnt                    = 0;
    int             nLgtCnt                     = 0;
    char            szRunDate[32]               = "";

    struct  tm      run_datetime;
    LGT_KMA_DATA    lgtData;

    if(szStartTime == NULL || szEndTime == NULL || pBuf == NULL)
        return -1;

    memset(&run_datetime,   0x00, sizeof(struct tm));
    strptime(szStartTime, "%Y%m%d%H%M", &run_datetime);

    while(++nFileCnt <= CGI_LGT_KMA_FILE_READ_MAX)
    {
        strftime(szRunDate, sizeof(szRunDate), "%Y%m%d0000", &run_datetime);
        if(strcmp(szRunDate, szEndTime) > 0)
            break;

        strftime(szFile, sizeof(szFile), CGI_LGT_KMA_FILE_FORMAT, &run_datetime);

        if((pFp = fopen(szFile, "rt")) == NULL)
        {
            run_datetime = fnGetIncDay(run_datetime, 1);
            continue;
        }

        while(fgets(szLine, sizeof(szLine), pFp) != NULL)
        {
            szLine[strlen(szLine)-1] = '\0';

            memset(&lgtData, 0x00, sizeof(LGT_KMA_DATA));
            fnSplitLgtDataKMA(szLine, &lgtData);

            if(strcmp(lgtData.m_szDateTime, szStartTime) >= 0 && strcmp(lgtData.m_szDateTime, szEndTime) <= 0)
            {
                if(nLgtCnt < nBufMax)
                {
                    memcpy(&pBuf[nLgtCnt], &lgtData, sizeof(LGT_KMA_DATA));
                    nLgtCnt++;
                }
            }
        }

        fclose(pFp);
        run_datetime = fnGetIncDay(run_datetime, 1);
    }

    return nLgtCnt;
}

int fnInitLgtBasinData(char *szFile, int nType, BASIN_DATA *pBuf, int nBufMax)
{
    FILE        *pFp                        = NULL;
    char        szLine[CGI_LGT_MAX_STR_LEN] = "";
    int         nBasinIdx                   = 0;
    int         nTotalCnt                   = 0;
    int         nDoCnt                      = 0;
    int         nSiguCnt                    = 0;
    char        szName[CGI_LGT_MAX_STR_LEN] = "";
    int         nCode                       = 0;
    int         nCnt                        = 0;

    if(szFile == NULL || pBuf == NULL || nBufMax <= 0)
        return -1;

    for(nBasinIdx = 0; nBasinIdx < nBufMax; nBasinIdx++)
    {
        pBuf[nBasinIdx].m_nColor = -1;
        pBuf[nBasinIdx].m_nCode = 0;
        pBuf[nBasinIdx].m_nLgtCnt = 0;
        pBuf[nBasinIdx].m_dTot_impact = 0.0;
        pBuf[nBasinIdx].m_fMax_impact = 0.0;
        pBuf[nBasinIdx].m_fMin_impact = 999.0;
    }

    if((pFp = fopen(szFile, "rt")) == NULL)
        return -1;

    if(fgets(szLine, sizeof(szLine), pFp) == NULL)
    {
        fclose(pFp);
        return -1;
    }
    sscanf(szLine, "%d %d %d", &nTotalCnt, &nDoCnt, &nSiguCnt);

    // DO 일때 DO를 읽고
    for(nBasinIdx = 0; nBasinIdx < nDoCnt && nBasinIdx < nBufMax; nBasinIdx++)
    {
        if(fgets(szLine, sizeof(szLine), pFp) == NULL)
            break;
        
        if(nType == LGT_BASIN_TYPE_DO)
        {
            sscanf(szLine, "%s %d", szName, &nCode);
            snprintf(pBuf[nBasinIdx].m_szName, sizeof(pBuf[nBasinIdx].m_szName),
                     "%s", szName);
            pBuf[nBasinIdx].m_nCode = nCode;
        }
    }
    if(nType == LGT_BASIN_TYPE_DO)
    {
        nCnt = nBasinIdx;
    }

    // SIGU 일때 DO는 저장하지 않고, SIGU만 저장한다.
    for(nBasinIdx = 0; nBasinIdx < nSiguCnt && nBasinIdx < nBufMax; nBasinIdx++)
    {
        if(fgets(szLine, sizeof(szLine), pFp) == NULL)
            break;

        if(nType == LGT_BASIN_TYPE_SIGU)
        {
            sscanf(szLine, "%s %d", szName, &nCode);
            snprintf(pBuf[nBasinIdx].m_szName, sizeof(pBuf[nBasinIdx].m_szName),
                     "%s", szName);
            pBuf[nBasinIdx].m_nCode = nCode;
        }
    }
    if(nType == LGT_BASIN_TYPE_SIGU)
    {
        nCnt = nBasinIdx;
    }

    fclose(pFp);

    return nCnt;
}

int fnReadLgtDataBasin(char *szEndTime, char cLgt_t_mode, int nLgt_intv, BASIN_DATA *pBuf, int nBufMax)
{
    gzFile      pFp                         = NULL;
    char        szFile[CGI_LGT_MAX_STR_LEN] = "";
    int         nIntvIdx                    = 0;
    int         nBasinIdx                   = 0;
    int         nBasinCnt                   = 0;
    int         nBasinMax                   = 0;
    int         rgnBuf[2]                   = { 0, 0};
    float       rgfBuf[2]                   = { 0.0, 0.0 };
    double      rgdBuf[1]                   = { 0.0 };

    struct  tm  run_datetime;

    if(szFile == NULL || pBuf == NULL || nBufMax <= 0)
        return -1;

    memset(&run_datetime,   0x00, sizeof(struct tm));
    strptime(szEndTime, "%Y%m%d%H%M", &run_datetime);

    for(nIntvIdx = 0; nIntvIdx < nLgt_intv; nIntvIdx++)
    {
        if(cLgt_t_mode == 'Y')
        {
            if(nIntvIdx > 0)
                run_datetime = fnGetIncYear(run_datetime, -1);

            strftime(szFile, sizeof(szFile), CGI_LGT_BASIN_YEAR_FILE_FORMAT, &run_datetime);
        }
        else if(cLgt_t_mode == 'M')
        {
            if(nIntvIdx > 0)
                run_datetime = fnGetIncMonth(run_datetime, -1);

            strftime(szFile, sizeof(szFile), CGI_LGT_BASIN_MONTH_FILE_FORMAT, &run_datetime);
        }
        else if(cLgt_t_mode == 'D')
        {
            if(nIntvIdx > 0)
                run_datetime = fnGetIncDay(run_datetime, -1);

            strftime(szFile, sizeof(szFile), CGI_LGT_BASIN_DAY_FILE_FORMAT, &run_datetime);
        }

        if((pFp = gzopen(szFile, "rb")) != NULL)
        {
            gzread(pFp, &nBasinCnt, sizeof(int));
            if(nBasinMax < nBasinCnt)
                nBasinMax = nBasinCnt;

            for(nBasinIdx = 0; nBasinIdx < nBasinCnt && nBasinIdx < nBufMax; nBasinIdx++)
            {
                gzread(pFp, &rgnBuf, sizeof(rgnBuf));
                pBuf[nBasinIdx].m_nCode    = rgnBuf[0];
                pBuf[nBasinIdx].m_nLgtCnt += rgnBuf[1];

                gzread(pFp, &rgdBuf, sizeof(rgdBuf));
                pBuf[nBasinIdx].m_dTot_impact += rgdBuf[0];

                gzread(pFp, &rgfBuf, sizeof(rgfBuf));
                if(pBuf[nBasinIdx].m_fMax_impact < rgfBuf[0])
                {
                    pBuf[nBasinIdx].m_fMax_impact = rgfBuf[0];
                }
                if(pBuf[nBasinIdx].m_fMin_impact > rgfBuf[1])
                {
                    pBuf[nBasinIdx].m_fMin_impact = rgfBuf[1];
                }
            }
            gzclose(pFp);
        }
    }

    return nBasinMax;
}

/* ================================================================================ */



