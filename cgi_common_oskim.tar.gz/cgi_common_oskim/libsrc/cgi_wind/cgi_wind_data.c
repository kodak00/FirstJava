/* ================================================================================ */
// 2016. 7. 29
//
// SnK : Choi Hyun-Jun
//
// 다중 바람장 데이터 계산 함수 모음
//
/* ================================================================================ */
// INCLUDE

#include "cgi_wind_cmm.h"
#include "cgi_cmm_util.h"
#include "cgi_wind_data.h"

/* ================================================================================ */
// GLOBAL


/* ================================================================================ */
// FUNCTION

float fnUV_To_S(float u, float v)
{
    return pow(pow(u, 2) + pow(v, 2), 0.5);
}

float fnR_To_D(float r)
{
    return (r * 180.) / PI_DFS;
}

float fnUV_To_D(float u, float v)
{
    if(u >= 0 && v >= 0)
    {
        return 270. - fnR_To_D(atan2(fabs(v),fabs(u)));
    }
    else if(u >= 0 && v < 0)
    {
        return 270. + fnR_To_D(atan2(fabs(v),fabs(u)));
    }
    else if(u < 0 && v >= 0)
    {
        return 180. - fnR_To_D(atan2(fabs(u),fabs(v)));
    }
    else if(u < 0 && v < 0)
    {
        return fnR_To_D(atan2(fabs(u),fabs(v)));
    }
    else
    {
        return 0.;
    }
}
/* ================================================================================ */
