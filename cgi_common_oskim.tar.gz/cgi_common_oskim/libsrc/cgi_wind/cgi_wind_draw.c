/* ================================================================================ */
// 2016. 7. 29
//
// SnK : Choi Hyun-Jun
//
// 이미지를 그려주는 함수 모음
//
/* ================================================================================ */
// INCLUDE

#include "cgi_wind_cmm.h"
#include "cgi_cmm_map_ini.h"
#include "cgi_cmm_util.h"
#include "cgi_wind_draw.h"

/* ================================================================================ */
// STRUCT

/* ================================================================================ */
// LOCAL FUNCTION
static float dtor(float d)
{
    return (d * PI_DFS) / 180.;
}

/* ================================================================================ */
// FUNCTION
void fnNoDataDisp(int nImgYdim, int nImgXdim)
{
    gdImagePtr  pImg;
    char        rgcText[126]        = {0,};
    int         rgnBrect[8]         = {0};
    char        *rgcErr             = NULL;
    int         nWhite              = 0;
    int         nBlack              = 0;
    int         nTransparent        = 0;
    char        rgcFont[MAX_STR]    = {0,};
    int         nX                  = 0;

    pImg = gdImageCreateTrueColor(nImgXdim, nImgYdim);
    gdImageAlphaBlending(pImg, 0);
    gdImageSaveAlpha(pImg, 1);
    nBlack = gdImageColorAllocate(pImg, 0, 0, 0);
    nWhite = gdImageColorAllocateAlpha(pImg, 255, 255, 255, 0);
    nTransparent = gdImageColorAllocateAlpha(pImg, 0, 0, 0, 127);

    gdImageFilledRectangle(pImg, 0, 0, nImgXdim, nImgYdim, nTransparent);

    sprintf(rgcFont, "%s", FONT_PATH);

    sprintf(rgcText, "%s", "선택된 시각의 레이더자료가 없습니다.");
    gdImageStringFT(NULL, &rgnBrect[0], nBlack, rgcFont, CGI_WIND_DF_NODISP_FONT_SIZE, 0.0, 0, 0, rgcText);

    nX = rgnBrect[2];
    rgcErr = gdImageStringFT(pImg, &rgnBrect[0], nBlack, rgcFont, CGI_WIND_DF_NODISP_FONT_SIZE, 
                             0.0, (nImgXdim-nX)/2, nImgYdim/2, rgcText);

    fprintf(stdout, "Content-type: image/png\r\n\r\n");
    gdImagePng(pImg,stdout);
    gdImageDestroy(pImg);
}

int fnWindDraw(gdImagePtr pImg, WIND w, int nLine_Color, int nSize, int nWing, int nImgXdim, int nImgYdim)
{
    int i = 0;
    float r;
    float x1, y1;
    float x2, y2;
    gdPoint w_2[5][2];
    gdPoint w_5[5][2];
    gdPoint w_25[5][3];
    int cnt_25 = 0, cnt_5 = 0, flg_2 = 0;
    float u_x, u_y, w_r;

    if (w.ws <= 0)
    {
        return 1;
    }
    x1 = w.x;
    y1 = w.y;
    if (x1 < 0 || x1 > nImgXdim) return -1;
    if (y1 < 0 || y1 > nImgYdim) return -1;

    r = dtor(w.wd - 90);

    x2 = x1 + (cos(r) * nSize);
    y2 = y1 + (sin(r) * nSize);

    gdImageLine(pImg, x1, y1, x2, y2, nLine_Color);
    u_x = (x2 - x1) / 5.;
    u_y = (y2 - y1) / 5.;
    w_r = dtor(w.wd - 30);


    for(i = 0; i < 5; i++)
    {
        w_5[i][0].x = x2 - u_x * i;
        w_5[i][0].y = y2 - u_y * i;
        w_5[i][1].x = w_5[i][0].x + (cos(w_r) * nWing);
        w_5[i][1].y = w_5[i][0].y + (sin(w_r) * nWing);

        w_2[i][0].x = x2 - u_x * i;
        w_2[i][0].y = y2 - u_y * i;
        w_2[i][1].x = w_2[i][0].x + (cos(w_r) * (nWing / 2.));
        w_2[i][1].y = w_2[i][0].y + (sin(w_r) * (nWing / 2.));

        w_25[i][0].x = x2 - u_x * (i - 1);
        w_25[i][0].y = y2 - u_y * (i - 1);
        w_25[i][1].x = x2 - u_x * i;
        w_25[i][1].y = y2 - u_y * i;
        w_25[i][2].x = w_25[i][1].x + (cos(w_r) * nWing);
        w_25[i][2].y = w_25[i][1].y + (sin(w_r) * nWing);
    }

    cnt_25 = floor(w.ws / 25.);
    cnt_25 += (w.ws - (cnt_25 * 25) >= 24) ? 1 : 0;
    r = w.ws - (cnt_25 * 25);

    if(r > 0)
    {
        cnt_5 = floor(r / 5.);
        cnt_5 += r - (cnt_5 * 5) >= 4 ? 1 : 0;
        r = r - ((cnt_25 * 25) + (cnt_5 * 5));
    }

    if(r >= 1.5)
    {
        flg_2 = 1;
    }

    // 25 m/s
    for(i = 0; i < cnt_25; i++)
    {
        gdImageFilledPolygon(pImg, w_25[i], 3, nLine_Color);
    }

    // 5 m/s
    for(i = cnt_25; i < cnt_5 + cnt_25; i++)
    {
        gdImageLine(pImg, w_5[i][0].x, w_5[i][0].y, w_5[i][1].x, w_5[i][1].y, nLine_Color);
    }

    // 2 m/s
    if(flg_2 == 1)
    {
        if(i == 0) i = 1;
        gdImageLine(pImg, w_2[i][0].x, w_2[i][0].y, w_2[i][1].x, w_2[i][1].y, nLine_Color);
    }

    return 1;

}

/* ================================================================================ */
