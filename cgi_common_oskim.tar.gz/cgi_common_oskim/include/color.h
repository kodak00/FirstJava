#ifndef COLOR_H_
#define COLOR_H_

/* ================================================================================ */
// DEFINE

#define  COLOR_INDEX_FILE         "/DATA/CONFIG/COL/kma_rn_comis.col" 
#define  COLOR_ETOP_INDEX_FILE    "/DATA/CONFIG/COL/kma_etop_comis.col"
#define  COLOR_VIL_INDEX_FILE     "/DATA/CONFIG/COL/kma_vil_comis.col"

#define  COLOR_TITLE_MAX_STR      1024
#define  SKIP_COLOR               (-99)
#define  COLOR_CNT                33
#define  COLOR_TABLE_RNG          256

/* ================================================================================ */
// STRUCT

typedef struct 
{	
	int     m_nColor_R;                //VARIABLE
	int     m_nColor_G;                //VARIABLE
	int     m_nColor_B;                //VARIABLE
	
    int     m_nNum;                    //VARIABLE
	float   m_fRain;                   //VARIABLE
	float   m_fDbz;                    //VARIABLE
} st_COLOR_DATA;

typedef struct 
{
	int             m_nCnt;            //VARIABLE
	int             m_nLegend_cnt;     //VARIABLE
	char            m_szTit[20];       //VARIABLE
	st_COLOR_DATA*  m_pstData;         //VARIABLE
} st_COLOR_INFO;

/* ================================================================================ */
// FUNCTION PROTO

st_COLOR_INFO  fnColor_table(char *szPath);
int            fnColor_table_read(gdImagePtr pImg, int rgnColor[], st_COLOR_INFO stColor_ini);
int            fnColor_table_read_gis(gdImagePtr pImg, int rgnColor[], st_COLOR_INFO stColor_ini);
void           fnFreeColorIndex(st_COLOR_INFO stColor_ini);

/* ================================================================================ */

#endif /* COLOR_H_ */
