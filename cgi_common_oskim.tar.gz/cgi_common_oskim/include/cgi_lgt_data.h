/* ================================================================================ */
//
// LGT Data Read Header
//
// 2016.09.26 SnK 
//
/* ================================================================================ */

#ifndef CGI_LGT_DATA_H
#define CGI_LGT_DATA_H

/* ================================================================================ */
// Define

#define CGI_LGT_MAX_STR_LEN             1024
#define CGI_LGT_ITEM_STR_LEN            64

// NX1
#define CGI_LGT_NX1_FILE_FORMAT         "/DATA/INPUT/LGT/%Y/KMA_LGT_NX1_%Y%m%d.asc"
#define CGI_LGT_NX1_FILE_READ_MAX       365

#define CGI_LGT_NX1_HASH_SCALE          1000
#define CGI_LGT_NX1_HASH_MAX            100

#define CGI_LGT_NX1_DATA_MAX            ((CGI_LGT_NX1_HASH_SCALE)*(CGI_LGT_NX1_HASH_MAX))
#define CGI_LGT_NX1_SENSOR_MAX          8
#define CGI_LGT_NX1_TYPE_EARTH          '1'
#define CGI_LGT_NX1_TYPE_CLOUD          '2'

// KMA
#define CGI_LGT_KMA_FILE_FORMAT         "/DATA/INPUT/LGT/%Y/LGT_KMA_%Y%m%d.asc"
#define CGI_LGT_KMA_FILE_READ_MAX       365

#define CGI_LGT_KMA_DATA_MAX            (CGI_LGT_NX1_DATA_MAX)
#define CGI_LGT_KMA_TYPE_EARTH          'G'
#define CGI_LGT_KMA_TYPE_CLOUD          'C'

// 문숫자 용 일,월,년 데이터
#define CGI_LGT_BASIN_DAY_FILE_FORMAT   "/DATA/OUTPUT/BIN/BASI/%Y%m/LGT_KMA_BASI_%Y%m%d.bin.gz"
#define CGI_LGT_BASIN_MONTH_FILE_FORMAT "/DATA/OUTPUT/BIN/BASI/%Y/LGT_KMA_BASI_%Y%m.bin.gz"
#define CGI_LGT_BASIN_YEAR_FILE_FORMAT  "/DATA/OUTPUT/BIN/BASI/%Y/LGT_KMA_BASI_%Y.bin.gz"

#define CGI_LGT_BASIN_MAX               999

/* ================================================================================ */
// Enum

// NX1
enum
{
    LGT_NX1_STRKES_ID     = 0,
    LGT_NX1_DATE,
    LGT_NX1_TIME,
    LGT_NX1_NSFRAC,
    LGT_NX1_WKT,
    LGT_NX1_LON,
    LGT_NX1_LAT,
    LGT_NX1_ALTITUDE,
    LGT_NX1_IMPACT,
    LGT_NX1_ERR_RADIUS,
    LGT_NX1_TYPE,
    LGT_NX1_N_SENSOR,
    LGT_NX1_SENOSR_NUM1,
    LGT_NX1_SENOSR_NUM2,
    LGT_NX1_SENOSR_NUM3,
    LGT_NX1_SENOSR_NUM4,
    LGT_NX1_SENOSR_NUM5,
    LGT_NX1_SENOSR_NUM6,
    LGT_NX1_SENOSR_NUM7,
    LGT_NX1_SENOSR_NUM8,
    LGT_NX1_QUALITY,
    LGT_NX1_FLASH_ID,
    LGT_NX1_DATA_MAX
};

enum
{
    LGT_KMA_DATE        = 0,
    LGT_KMA_TIME        = 1,
    LGT_KMA_LAT         = 2,
    LGT_KMA_LON         = 3,
    LGT_KMA_IMPACT      = 4,
    LGT_KMA_N_SENSOR    = 11,
    LGT_KMA_TYPE        = 12,
    LGT_KMA_DATA_MAX    = 13
};

// LGT BASIN TYPE
enum
{
    LGT_BASIN_TYPE_DO = 0,
    LGT_BASIN_TYPE_SIGU
};

/* ================================================================================ */
// Struct

typedef struct
{
    int     m_nStrkes_id;
    char    m_szDateTime[CGI_LGT_ITEM_STR_LEN]; // YYYYMMDDHHMI
    int     m_nNsfrac;
    char    m_szWKT_info[CGI_LGT_ITEM_STR_LEN];
    float   m_fLon;
    float   m_fLat;
    float   m_fAltitude;
    float   m_fImpact;
    float   m_fErrRadius;
    char    m_cType;
    int     m_nSensor;
    int     m_rgnSensorNum[CGI_LGT_NX1_SENSOR_MAX];
    int     m_nQuality;
    char    m_szFlash_id[CGI_LGT_ITEM_STR_LEN];
} LGT_NX1_DATA;

typedef struct
{
    char    m_szDateTime[CGI_LGT_ITEM_STR_LEN]; // YYYYMMDDHHMI
    float   m_fLon;
    float   m_fLat;
    float   m_fImpact;
    char    m_cType;
    int     m_nSensor;
} LGT_KMA_DATA;

// 낙뢰 문숫자
typedef struct
{
    char    m_szName[CGI_LGT_MAX_STR_LEN];
    int     m_nColor;
    int     m_nCode;
    int     m_nLgtCnt;
    double  m_dTot_impact;
    float   m_fMax_impact;
    float   m_fMin_impact;
} BASIN_DATA;


/* ================================================================================ */
// Function

// Read 한 LGT 데이터 개수 리턴
int fnReadLgtDataNX1(char *szStartTime, char *szEndTime, LGT_NX1_DATA *pBuf, int nBufMax);
int fnReadLgtDataKMA(char *szStartTime, char *szEndTime, LGT_KMA_DATA *pBuf, int nBufMax);

// Read 배열의 개수를 리턴
// nType == 0 : DO nType == 1 : SIGU
int fnInitLgtBasinData(char *szInfoFile, int nType, BASIN_DATA *pBuf, int nBufMax);
// cLgt_t_mode ( 'Y' == 년별, 'M' == 월별, 'D' == 일별 )
int fnReadLgtDataBasin(char *szEndTime, char cLgt_t_mode, int nLgt_intv, BASIN_DATA *pBuf, int nBufMax);

/* ================================================================================ */

#endif

