typedef struct
{
    float   m_fX_Point;
    float   m_fY_Point;
}POINT;

typedef struct
{
    float   m_rgfData[XYDIM_CROSS][ZDIM_CROSS];
    float   m_szBound[XYDIM_CROSS];
    int     m_nCenter_Idx;
    int     m_rgnAws_Idx[XYDIM_CROSS];
    int     m_rgnMap_High[XYDIM_CROSS];
    int     m_nMinValue;
    int     m_nMaxValue;
    POINT   m_stStart;
    POINT   m_stEnd;
    POINT   m_stPoint[XYDIM_CROSS];
}CROSS_SECTION;

int fnGetCross_Section_Point(CROSS_SECTION *stCross_Section, POINT stStartPoint, POINT stEndPoint, int nYdim, int nXdim, float fSiteLon, float fSiteLat, float fSiteGridKm);
