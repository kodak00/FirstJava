#ifndef CGI_COMP_IMG_DATA_H
#define CGI_COMP_IMG_DATA_H

/* ================================================================================ */
// DEFINE

#define VSRF_DATA_SIZE  100.0
#define CJ3_DATA_SIZE   100.0

/* ================================================================================ */
// STRUCT

typedef struct
{
    char    m_szP_type[32];
    char    m_szFileName[1024];
    int     m_nCompXdim;
    int     m_nCompYdim;
    int     m_nFcstTime;
    float   **m_ppGuidData;
} GUIDE_THR_ARG;

typedef struct
{
    char    m_szP_type[32];
    char    m_szFileName[1024];
    int     m_nCompXdim;
    int     m_nCompYdim;
    int     m_nFcstTime;
    float   **m_ppData;
} DATA_THR_ARG;


/* ================================================================================ */
// FUNCTION PROTO

void fnKmaPosToGisPos(float **pData, int nYdim, int nXdim, float fYGridM, float fXGridM, float fLU_lon, float fLU_lat, int nDiff_x, int nDiff_y, int nDiff_RL_x, int nDiff_RL_y);
float**     fnMakeCompImgData(float** pCompData, int nImgXdim, int nImgYdim, float fLU_lon, float fLU_lat, float fXDist, float fYDist, int nSmooth, int nCompXdim, int nCompYdim, float fCompGridKm, char szP_type[]);
float**     fnMakeCompMapImgData(float** pImgData, float** pCompData, int nImgXdim, int nImgYdim, int nCompXdim, int nCompYdim, float fCompGridKm);
float**     fnMakeComp480ImgData(float** pCompData, int nImgXdim, int nImgYdim, float fLU_lon, float fLU_lat, float fXDist, float fYDist, int nSmooth, int nCompXdim, int nCompYdim, float fCompGridKm);
float**     fnMakeCompVsrfEchoImgData(float** pImgData, float** pCompData, int nImgXdim, int nImgYdim, float fLU_lon, float fLU_lat, float fXDist, float fYDist, int nSmooth, int nCompXdim, int nCompYdim, float fCompGridKm);
float**     fnMakeCompVsrfConGuideImgData(float** pImgData, float** pCompData, int nImgXdim, int nImgYdim, float fLU_lon, float fLU_lat, float fXDist, float fYDist, int nCompXdim, int nCompYdim, float fCompGridKm);
float**     fnMakeCompCj3ImgData(float** pCompData, int nImgXdim, int nImgYdim, float fLU_lon, float fLU_lat, float fXDist, float fYDist, int nSmooth, int nCompXdim, int nCompYdim, float fCompGridKm);

/* ================================================================================ */

#endif /* CGI_COMP_IMG_DATA_H */
