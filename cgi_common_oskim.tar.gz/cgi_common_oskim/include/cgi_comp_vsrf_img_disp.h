#ifndef VSRF_DISP_IMG_H
#define VSRF_DISP_IMG_H

/* ================================================================================ */
// DEFINE

#define CONTOUR_SMOOTH  4
#define GUIDE_SMOOTH    4
#define CONTOUR_CNT     6

#ifndef MIN
#define MIN(x,y) (x < y ? (float)x : (float)y)
#endif
#ifndef MAX
#define MAX(x,y) (x > y ? (float)x : (float)y)
#endif

/* ================================================================================ */
// FUNCTION PROTO

int fnCreateCompVsrfImg(float** pImgData, char szP_type[], int nImgXdim, int nImgYdim, char szUnit[], int nTitan, int nContour, int nForeGuide, char szF_name[], int nCompXdim, int nCompYdim, float fLU_lon, float fLU_lat, float fXDist, float fYDist, int nSmooth, float fCompGridKm, char szDate[], char szForecastDate[]);

/* ================================================================================ */

#endif /* VSRF_DISP_IMG_H */

