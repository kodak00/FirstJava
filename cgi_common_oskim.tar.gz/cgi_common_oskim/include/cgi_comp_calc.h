#ifndef CGI_COMP_CALC_H
#define CGI_COMP_CALC_H

/* ================================================================================ */
// DEFINE

#define MEDIAN_BUF_SIZE           9

/* ================================================================================ */
// FUNCTION PROTO

float   fnCalcRadarValueSmooth480(float** pData, int nDataXdim, int nDataYdim, int nDiff_x, int nDiff_y, int nXpoint, int nYpoint, float fXGridScale, float fYGridScale);
float   fnCalcRadarValue(float** pData, int nDataXdim, int nDataYdim, int nDiff_x, int nDiff_y, int nXpoint, int nYpoint, float fXGridScale, float fYGridScale);
float   fnCalcRadarValueSmooth(float** pData, int nDataXdim, int nDataYdim, int nDiff_x, int nDiff_y, int nXpoint, int nYpoint, float fXGridScale, float fYGridScale);

/* ================================================================================ */

#endif /* CGI_COMP_CALC_H */
