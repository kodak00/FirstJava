/* ================================================================================ */
//
// 2016.07.29
// 
// SnK : Choi Hyun-Jun
//
/* ================================================================================ */
// INCLUDE
#ifndef CGI_WIND_COMMON_H
#define CGI_WIND_COMMON_H

#include <gd.h>
#include <gdfonts.h>
#include <gdfontl.h>
#include <gdfontt.h>
#include <gdfontg.h>
#include <gdfontmb.h>

#include "unp.h"

char *strptime(const char *s, const char *format, struct tm *tm);

/* ================================================================================ */
// DEFINE

#ifndef MULTI_WIND
#define MAX_STR         (1024)
#define BAD_VALUE_F     (-9999.0)
#define OUT_BOUND_F     (-9998.0)
#define MAP_RE          (6371.00877f)
#define GIS_MAP_RE      (6378.13729f)
#define ROOTPATH        "/srv/kres/cgi_project/resource/"
#endif

#ifndef PI_DFS
#define PI_DFS  (3.141592)
#endif

#define FONT_PATH                       "/srv/kres/cgi_project/resource/font/NanumGothic.ttf"
#define CGI_WIND_DF_NODISP_FONT_SIZE    16.0

#ifndef MULTI_WIND_PATH
//#define CGI_MULTI_WIND_NOQC_DATA_PATH     "/DATA/OUTPUT/BIN/3DNQ/%Y%m/%d/RDR_CNQCZ_3E40_%Y%m%d%H%M.bin.gz"
//#define CGI_MULTI_WIND_FUZZYQC_DATA_PATH  "/DATA/OUTPUT/BIN/3DFQ/%Y%m/%d/RDR_CFQCZ_3D40_%Y%m%d%H%M.bin.gz"
//#define CGI_MULTI_WIND_ORPGQC_DATA_PATH   "/DATA/OUTPUT/BIN/3DOQ/%Y%m/%d/RDR_COQCZ_3E40_%Y%m%d%H%M.bin.gz"
#define CGI_MULTI_WIND_FILE_PATH          "/DATA/OUTPUT/TXT/MWND/%Y%m/%d/RDR_COQVR_MW11_%Y%m%d%H%M.txt.gz"
#endif

typedef struct{
    float  lat;
    float  lon;
    float  x;
    float  y;
    float  z;
    float  ws;
    float  wd;
} WIND;

typedef struct
{
    float   u;
    float   v;
    float   w;
    float   ws;
    float   wd;
    float   sum_ws;
    int     sum_cnt;
    float   s[2];
} MULTIWIND;

#endif // CGI_WIND_COMMON_H

