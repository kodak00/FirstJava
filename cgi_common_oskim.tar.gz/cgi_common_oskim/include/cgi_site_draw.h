/* ================================================================================ */
//
// 2016.07.29
//
// SnK : Choi Hyun-Jun
//
/* ================================================================================ */
#ifndef CGI_SITE_DRAW_H
#define CGI_SITE_DRAW_H
typedef struct
{
    char*   m_szProductType;
    char*   m_szDataType;
    char   m_szColorFile[MAX_STR];
    char*   m_szDispFormat;
    int     m_nColorKind;
    float   m_fMinValue;
} st_ColorInfo;

void fnNoDataDisp_MAP(char *szQC_Type, char *szProductType, char *szDataType, float fProductArg, float fMaxRange, int nGateSize, int nBinCount, float fNyqVel, int nImgXdim, int nImgYdim);
void fnNoDataDisp(int nImgYdim, int nImgXdim);

int fnDrawMap(gdImagePtr pImg, float fSiteLon, float fSiteLat, float fXo, float fYo, float fImgGridKm, int nMapColor);
int fnGetColorInfo(char* szProductType, char* szDataType, st_ColorInfo *pBuf);
int fnDrawRangeRing(gdImagePtr pImg, int nLineColor, float fImgGridKm, int nDimCenter);
int fnDrawRangeDirection(gdImagePtr pImg, int nLineColor);
int fnWriteSiteColorIndx(gdImagePtr pImg, int nImgXdim, int nImgYdim, CGI_COLOR_TBL *pColor_ini, int rgnColor[], st_ColorInfo stColorInfo, char *szDataType);
int fnWriteBottomText(gdImagePtr pImg, char *szQC_Type, char *szProductType, char *szDataType, float fProductArg, float fMaxRange, int nGateSize, int nBinCount, float fNyqVel, int nImgXdim, int nImgYdim);

int fnSiteAws(gdImagePtr pImg, int nImgXdim, int nImgYdim, float fImgGridKm, float fSiteLon, float fSiteLat, float fXo, float fYo, int iAwsColor, int iFontColor);

int fnWritePointRain(float **pSiteData, char *szDataType, int nSiteXdim, int nSiteYdim, float fSiteGridKm, float fSiteLon, float fSiteLat, float fXo, float fYo, float fPointLon, float fPointLat, float fZr_A, float fZr_B);

gdImagePtr fnSiteImgComment(struct tm stFileTime,char *szSiteName, char *szProductType, char *szDataType, int nImgXdim);

int fnWindDraw(gdImagePtr pImg, WIND w, int nLine_Color, int nSize, int nWing, int nImgXdim, int nImgYdim); 
int fnWriteEchoInfo(gdImagePtr pImg, char *szProductType, char *szDataType, char *szSiteName, struct tm FileTime, int nBlack, int nImgXdim, int nFlag); // Flag == 1 대기수상체 / == 0 일반 Site 영상
int fnRainPointFileWrite(float **pImgData, char *szDataType, long lN_Date, int nSiteYdim, int nSiteXdim, float fZr_A, float fZr_B);
#endif
