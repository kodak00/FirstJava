#ifndef CGI_COMP_EXTRA_H
#define CGI_COMP_EXTRA_H

/* ================================================================================ */
// DEFINE

#define  FONT_PATH               "/srv/kres/cgi_project/resource/font"
#define  FONT_SIZE               137
#define  TEXT_SIZE               126
#define  BRECT_SIZE              8
#define  IMAGE_INDEX_RIGHT_SIZE  45
#define  FILE_SIZE               120
#define  MAP_TEMP_SIZE           2
#define  MAP_BUF_SIZE            2
#define  MAP_LINE_FILE           "/srv/kres/cgi_project/resource/map/map_data.bln"
#define  RAIN_POINT_WRITE_PATH   "/srv/kres/cgi_project/data/temp/load_rain"
#define  FILE_MAX_STR            1024

enum {MAP_VALUE_RANGE_OUT, MAP_VALUE_RANGE_IN, MAP_VALUE_RADAR_POSITION};

/* ================================================================================ */
// FUNCTION PROTO

int     fnMapLineDisp(int nImgYdim, gdImagePtr pImg, int nMap_color, float fXo, float fYo, int nMoveX, int nMoveY, float fZm);
int     fnMapLevelColorDisp(int nImgXdim, int nImgYdim, char szP_type[], char szUnit[], gdImagePtr pImg, int rgnColor[], CGI_COLOR_TBL* pColor_ini);
int     fnLevelColorDisp(int nImgYdim, char szP_type[], char szUnit[], gdImagePtr pImg, int rgnColor[], CGI_COLOR_TBL* pColor_ini);
int     fnBoundDisp(int nImgXdim, int nImgYdim, float** pImgData, gdImagePtr pImg, float fOutBoundValue);
int     fnNoCompDataDisp(int nImgXdim, int nImgYdim);
int     fnNoCompMapDataDisp(char szP_type[], int nImgXdim, int nImgYdim, char szUnit[]);
int     fnCreateLevelColorImg(char szP_type[], int nImgYdim, char szUnit[]);
int     fnVsrfMapleContentDisp(int nImgXdim, int nImgYdim, gdImagePtr pImg, char szDate[], char szForecastDate[]);
int     fnWritePointRain(float **pCompData, char szUnit[], int nCompXdim, int nCompYdim, float fCompGridKm, float fCompLon, float fCompLat, int nCompXo, int nCompYo, float fPointLon, float fPointLat, int nUnitFlag);
int     fnImgTopTextDisp(gdImagePtr pImg, char szP_type[], char szQ_type[], char szUnit[], char szDate[], int nImgXdim, int nFlag, char szForecastDate[]);
int     fnRainPointFileWrite(float **pCompData, char szUnit[], long lN_Date, int nCompXdim, int nCompYdim, int nUnitFlag, int nImgXdim, int nImgYdim, float fLU_lon, float fLU_lat, float fXDist, float fYDist, float fCompGridKm, float fCompLU_lon_Value, float fCompLU_lat_Value,  float fCompRL_lon_Value, float fCompRL_lat_Value);

/* ================================================================================ */

#endif /* CGI_COMP_EXTRA_H */
