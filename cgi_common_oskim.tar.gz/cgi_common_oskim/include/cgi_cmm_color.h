/* ================================================================================ */
//
// Radar Image Color Header
//
// 2016.08.30 SnK 
//
/* ================================================================================ */

#ifndef CGI_CMM_COLOR_H
#define CGI_CMM_COLOR_H

/* ================================================================================ */
// Define

#define CGI_DF_RN_COLOR_FILE        "/srv/kres/cgi_project/resource/color/kma_rn_comis.col"
#define CGI_DF_SW_COLOR_FILE        "/srv/kres/cgi_project/resource/color/kma_sw_comis.col"
#define CGI_DF_RH_COLOR_FILE        "/srv/kres/cgi_project/resource/color/kma_rh_comis.col"
#define CGI_DF_PH_COLOR_FILE        "/srv/kres/cgi_project/resource/color/kma_ph_comis.col"
#define CGI_DF_VR_COLOR_FILE        "/srv/kres/cgi_project/resource/color/kma_vr_comis.col"
#define CGI_DF_DR_COLOR_FILE        "/srv/kres/cgi_project/resource/color/kma_dr_comis.col"
#define CGI_DF_KD_COLOR_FILE        "/srv/kres/cgi_project/resource/color/kma_kd_comis.col"
#define CGI_DF_ETOP_COLOR_FILE      "/srv/kres/cgi_project/resource/color/kma_etop_comis.col"
#define CGI_DF_VIL_COLOR_FILE       "/srv/kres/cgi_project/resource/color/kma_vil_comis.col"
#define CGI_DF_HC_COLOR_FILE        "/srv/kres/cgi_project/resource/color/kma_hc_20120713.col"
#define CGI_DF_HC7_COLOR_FILE       "/srv/kres/cgi_project/resource/color/kma_hc7.col"
#define CGI_DF_SN_COLOR_FILE        "/srv/kres/cgi_project/resource/color/kma_sn_comis.col"


#define CGI_DF_STR_LENGTH_MAX       (1024)

// Not Use Color Value
#define CGI_DF_SKIP_COLOR           (-9999)
#define CGI_DF_LINE_COLOR           (-9998)
#define CGI_DF_FONT_COLOR           (-9997)
#define CGI_DF_IN_BOUND_COLOR       (-9996)
#define CGI_DF_OUT_BOUND_COLOR      (-9995)
#define CGI_DF_AWS_COLOR            (-9994)

#define CGI_DF_COLOR_MAX            (300)

/* ================================================================================ */
// Enum

typedef enum
{
    CGI_EN_COLOR_RAIN = 0,
    CGI_EN_COLOR_UNIT
} CGI_EN_COLOR_TYPE;

typedef enum
{
    CGI_EN_LINE_COLOR  = 0,
    CGI_EN_FONT_COLOR,
    CGI_EN_IN_BOUND_COLOR,
    CGI_EN_OUT_BOUND_COLOR,
    CGI_EN_AWS_COLOR,
    CGI_EN_DISP_COLOR_MAX
} CGI_EN_DISP_COLOR;

/* ================================================================================ */
// Struct

typedef struct
{
    int     m_iNum;
    int     m_iR;
    int     m_iG;
    int     m_iB;
    float   m_fRain;
    float   m_fUnit;
} CGI_COLOR_INFO;

typedef struct
{
    char            m_szRainTitle[20];
    char            m_szUnitTitle[20];
    int             m_iEchoColorCnt;
    CGI_COLOR_INFO  m_dispColorTbl[CGI_EN_DISP_COLOR_MAX];
    CGI_COLOR_INFO  m_echoColorTbl[CGI_DF_COLOR_MAX];
} CGI_COLOR_TBL;

/* ================================================================================ */
// Function

/* -----------------------------------------------------------------------------+
|	이미지 생산을 위한 Color File을 읽는다.                                     |
|   파라미터                                                                    |
|       char *szFile    : Color 파일의 이름                                     |
|   반환값                                                                      |
|       Color 정보 or NULL                                                      |
|       메모리를 할당하기 때문에 free 해야 한다.                                |
+----------------------------------------------------------------------------- */
CGI_COLOR_TBL *fnReadColorTable(char *szFile);

/* -----------------------------------------------------------------------------+
|	생상정보파일에서 읽은 R,G,B 값으로 색상표를 생성한다.                       |
|   파라미터                                                                    |
|       gdImagePtr pImg                         : gd 이미지 포인터              |
|       CGI_COLOR_TBL *pColorTbl                : 생성 정보 포인터              |
|       int echoColorBar[CGI_DF_COLOR_MAX]      : 에코 색상표 버퍼              |
|       int dispColorBar[CGI_EN_DISP_COLOR_MAX] : 기타 색상표 버퍼              |
|   반환값                                                                      |
|       0 or -1                                                           |
+----------------------------------------------------------------------------- */
int fnAllocColorTbl(gdImagePtr pImg, CGI_COLOR_TBL *pColorTbl, int echoColorBar[CGI_DF_COLOR_MAX], int dispColorBar[CGI_EN_DISP_COLOR_MAX]);

/* -----------------------------------------------------------------------------+
|	데이터 값으로 색상표 인덱스를 구한다.                                       |
|   파라미터                                                                    |
|       float fData                 : 데이터                                    |
|       CGI_COLOR_TBL *pColorTbl    : 색상 정보 포인터                          |
|       int iColorKind              : 색상의 종류                               |
|       float fMinValue             : 표출 최소값                               |
|       int nMinDiffType            : 최소값비교타입 0 or 1 (0:"<",1:"<=")      |
|       int nDiffType               : 에코값비교타입 0 or 1 (0:"<",1:"<=",2:>)  |
|   반환값                                                                      |
|       색상표 인덱스 or -1                                                     |
+----------------------------------------------------------------------------- */
int fnGetColorLevel(float fData, CGI_COLOR_TBL *pColorTbl, int iColorKind, float fMinValue, int nMinDiffType, int nDiffType);

/* ================================================================================ */

#endif



