/* ================================================================================ */
//
// 2016.07.29
// 
// SnK : Choi Hyun-Jun
//
/* ================================================================================ */
// INCLUDE
#ifndef CGI_SITE_COMMON_H
#define CGI_SITE_COMMON_H

#include <gd.h>
#include <gdfonts.h>
#include <gdfontl.h>
#include <gdfontt.h>
#include <gdfontg.h>
#include <gdfontmb.h>

#include "unp.h"

char *strptime(const char *s, const char *format, struct tm *tm);

/* ================================================================================ */
// DEFINE

#define MAX_STR         (1024)
#define BAD_VALUE_F     (-9999.0)
#define OUT_BOUND_F     (-9998.0)
#define DIM_CENTER      (256)
#define MAP_RE          (6371.00877f)
#define GIS_MAP_RE      (6378.13729f)
#define ROOTPATH        "/srv/kres/cgi_project/resource/"
#define F_OFFSET        (4)

#define XYDIM_CROSS (725)
#define ZDIM_CROSS (360)
#define IMG_XYDIM_CROSS_PLUS (37)
#define IMG_ZDIM_CROSS_PLUS (22)

#ifdef  USE_TWO_BYTE_PRECISION
#define USE_TWO_BYTE_PRECISION
#define F_FACTOR            (100.0)
#define F_DR_FACTOR         (1000.0)
#define F_DZ_RANGE_OFFSET   (50)
#else
#define F_FACTOR            (2.0)
#define F_DR_FACTOR         (10.0)
#define F_DZ_RANGE_OFFSET   (32)
#endif

#define ELEVATION_LIMIT         (2.0)
#define AZIMUTH_LIMIT           (1.0)
#define CROSS_ELEVATION_LIMIT   (3.0)
#define CROSS_AZIMUTH_LIMIT     (1.0)

#ifndef PI_DFS
#define PI_DFS  (3.141592)
#endif

#define RAIN_POINT_WRITE_PATH           "/srv/kres/cgi_project/data/temp/load_rain"

#define CGI_SITE_DF_NODISP_FONT_SIZE    16.0
#define NANUMGOTHIC_FONT_PATH           "/srv/kres/cgi_project/resource/font/NanumGothic.ttf"
#define FONT_PATH                       "/srv/kres/cgi_project/resource/font/arialbd.ttf"
#define MAP_FILE                        "/srv/kres/cgi_project/resource/map/fine_kr_binary.dat"
#define AWS_FILE                        "/srv/kres/cgi_project/resource/aws/aws_pos_han_1.txt"
#define CGI_DF_HC_SITE_INFO_PATH        "/srv/kres/cgi_project/resource/etc/HC_Site_Info.txt"
#define AWS_FONT                        "/srv/kres/cgi_project/resource/font/gulim.ttc"
#define CGI_DF_HC_ALT_FONT_FILE         "/srv/kres/cgi_project/resource/font/times.ttf"
#define CGI_DF_KOR_FONT_FILE            "/srv/kres/cgi_project/resource/font/gulim.ttc"
#define CGI_DF_INFO_FILE_PATH           "/srv/kres/cgi_project/data/temp/site"
#define CGI_CROSS_SRTM_FILE             "/srv/kres/cgi_project/resource/map/srtm_90m_sub.bin"
#define CGI_SITE_HDF5_DATA_PATH         "/DATA/OUTPUT/BIN"
#define CGI_DF_HC_FONT_SITE             8
#define CGI_DF_AWS_NAME_MV_POSITION_X   26
#define CGI_DF_AWS_NAME_MV_POSITION_Y   2
#define CGI_DF_AWS_FONT_SIZE            10

#ifndef DEFAULT_ZR_A
#define DEFAULT_ZR_A 200.
#endif
#ifndef DEFAULT_ZR_B
#define DEFAULT_ZR_B 1.6
#endif

#define CGI_SITE_DF_COLOR_BAR_WIDTH 10
#define CGI_SITE_DF_RIGHT_WIDTH     45
#define CGI_HC_DF_RIGHT_WIDTH       110
#define CGI_SITE_DF_BOTTOM_HEIGHT   20
#define CGI_SITE_DF_TOP_HEIGHT      25

#define CGI_HC_CROSS_FRAME_X 640
#define CGI_HC_CROSS_FRAME_Y 300
#define CGI_HC_CROSS_UNIT    100
#define CGI_HC_CROSS_TOP     40
#define CGI_HC_CROSS_LEFT    50
#define CGI_HC_CROSS_RIGHT   20

#define MVVP_WIND_FILE_FORMAT "/DATA/OUTPUT/TXT/SVVP/%%Y%%m/%%d/RDR_SOQVR_VVP_%s_%%Y%%m%%d%%H%%M.txt"

typedef struct{
    float  lat;
    float  lon;
    float  x;
    float  y;
    float  z;
    float  ws;
    float  wd;
} WIND;

typedef struct
{
    float   u;
    float   v;
    float   w;
    float   ws;
    float   wd;
    float   sum_ws;
    int     sum_cnt;
    float   s[2];
} MULTIWIND;

#endif // CGI_SITE_COMMON_H

