/* ================================================================================ */
//
// 2016.07.29
//
// SnK : Choi Hyun-Jun
//
/* ================================================================================ */
#ifndef CGI_SITE_SMOOTH_H
#define CGI_SITE_SMOOTH_H

int fnKmaSmooth(float** data, int nYdim, int nXdim);

#endif
