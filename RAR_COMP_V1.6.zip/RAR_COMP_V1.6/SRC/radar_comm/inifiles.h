/**
 * @file inifiles.h
 * @brief ���� ȯ�漳�������� �д� ���̺귯��
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */
 
int createIniFile(char* pfilename);
int destroyIniFile();
char* readIniString(char* psection, char* ptitle, char* pdefaultValue);
int readIniInt(char* psection, char* ptitle, int defaultValue);
float readIniFloat(char* psection, char* ptitle, float defaultValue);
COLOR readIniColor(char* ptitle);
