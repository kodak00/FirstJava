/**
 * @file check_uffile.c
 * @brief uf ������ �������� �����ϴ� �Լ�
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <zlib.h>
#include "radar_comm.h"

typedef unsigned short word;

int littleEndian(void);
void swap4Bytes(void* pword);
void swap2Bytes(void* pword);

/**
 * @brief uf ������ �������� �˰���(gzip �Ȱ� �� �ȵȰ� ��� �˻���).
 * @param pfilename ���ϸ�
 * @return ������ 0: ���� 0�̿��� ����: ����
 * @author �豤ȣ
 */
int checkUFFile(char* pfilename)
{
	int magickNumber;
	FILE* pfp;
	char UFBuffer[6];
	word buffer[163840];
	z_off_t  filePostion;
	word recordLength;
	int error;

	int readBytes;
	int expectReadBytes;

	if ((pfp = gzopen(pfilename,"r")) == NULL)
	{
		return -53001;
	}

	magickNumber = -1;
	if (gzread(pfp, UFBuffer, sizeof(char) * 6) <= 0)
	{
		return -53002;
	}

	if (strncmp("UF", UFBuffer, 2) == 0) magickNumber = 1;
	else if (strncmp("UF", &UFBuffer[2], 2) == 0) magickNumber = 2;
	else if (strncmp("UF", &UFBuffer[4], 2) == 0) magickNumber = 3;
	else
	{
		gzclose(pfp);
		fprintf(stderr,"It's not UF file\n");
		return -53003;
	}
	
	gzseek(pfp,0,SEEK_SET);
	filePostion = gztell(pfp);

	error = 0;

	while (gzeof(pfp) != 1)
	{
		readBytes = gzread(pfp,UFBuffer,magickNumber * sizeof(word) * 1);
		if (gzeof(pfp) == 1)
		{
			break;
		}
		if ((gzread(pfp,&recordLength,sizeof(recordLength)*1)) <= 0)
		{
			fprintf(stderr,"***ERROR gzread --- 1 wrong file : %s\n",pfilename);
			error = 1;
			break;
		}
		if (littleEndian()) swap2Bytes(&recordLength);

		expectReadBytes = recordLength * sizeof(word);
		readBytes = gzread(pfp,buffer,expectReadBytes);
		filePostion = gztell(pfp);
		if (expectReadBytes != readBytes)
		{
			error = 2;
			break;
		}
	}

	if (error)
	{
		gzclose(pfp);
		return -53004;
	}
	
	return 0;
}
