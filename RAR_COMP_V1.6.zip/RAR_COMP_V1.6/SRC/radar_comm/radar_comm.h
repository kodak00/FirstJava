/**
 * @file radar_comm.h
 * @brief ���̴� �ռ� ���α׷� �� �⺻ ���̺귯��
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <time.h>
#include "/usr/local/trmm/GVBOX/include/rsl.h"

#define BAD_VALUE_F  (-9999.)
#define OUT_VALUE_F  (-9998.)

#ifndef MAX_STRING_LENGTH
#define	MAX_STRING_LENGTH	(1024)	//�Ϲ��� ���ڿ��� �ִ밪(pathǥ����	���� ��� ������)
#endif

#ifndef COLOR_TYPE
#define COLOR_TYPE
typedef	struct
{
	unsigned char	R;	//Red
	unsigned char	G;	//Green
	unsigned char	B;	//Blue
}COLOR;
#endif

#define	MAP_RE	(6371.00877)			//�����п������� ����ϴ� ���� �ݰ�(km)
#define PI_DFS	(3.141592)

#ifndef _DEFINE_KRL_RADAR_
#define _DEFINE_KRL_RADAR_
typedef struct 
{
	char fileType[10];
	unsigned short version;
	char siteInitial[6];
	int xdim;
	int ydim;
	int range;
	int height;
	float lat;
	float lon;
	char dataType[2];
	char spareHeadByte[28];
}KRL_RADAR_HEAD;

typedef struct
{
	KRL_RADAR_HEAD head;
	float* pdata;
}KRL_RADAR;
#endif

typedef enum {REAL_CAPPI, PSEUDO_CAPPI} CAPPI_TYPE;

/*********************************************************************************
	dateutils.c
*********************************************************************************/
struct tm incMin(struct tm tmPtr,int addMin);
struct tm incHour(struct tm tmPtr,int addHour);
struct tm incDay(struct tm tmPtr,int addDay);
struct tm convStrToDateTime(char* pstr);
int datecmp(struct tm tm1, struct tm tm2);
struct tm now();

/*********************************************************************************
	inifiles.c
*********************************************************************************/
int createIniFile(char* pfilename);
int destroyIniFile();
char* readIniString(char* psection, char* ptitle, char* pdefaultValue);
int readIniInt(char* psection, char* ptitle, int defaultValue);
float readIniFloat(char* psection, char* ptitle, float defaultValue);
COLOR readIniColor(char* ptitle);

/*********************************************************************************
	utils.c
*********************************************************************************/
char* strnmcpy(char* pdest, const char* psrc, int index, int count);
int pos(char* sub_string,char* string);
int fileExists(char* pfileName);
char* extractFilename(char* pfilePathName);
int littleEndian(void);
void swap4Bytes(void* pword);
void swap2Bytes(void *word);
char toBigLetter(char c);
char toSmallLetter(char C);

/*********************************************************************************
	radar.c
*********************************************************************************/
int delIndenpentEcho(float* pimsiData, int xdim, int ydim);
double dBZToZeF(double dBZ);
double ZeToDBZF(double Ze);
double dBZToRF(double dBZ,float zrA,float zrB);
unsigned char RToDBZ(double R,float zrA,float zrB);
float deg60To1002(int deg, int min, int sec);

/*********************************************************************************
	cappi.c
*********************************************************************************/
float* KRLCAPPIAtHCart(Volume* pvolume, float height, int xdim, int ydim, int range, float gridSize, CAPPI_TYPE pseudoCAPPI, int isDBZ);
float getAzimuth(float x,float y);

/*********************************************************************************
	check_uffile.c
*********************************************************************************/
int checkUFFile(char* pfilename);

/*********************************************************************************
	KRL_radar.c
*********************************************************************************/
float* KRLVolumeToBASE(Volume* pvolume, int xdim, int ydim, int range);
KRL_RADAR* KRLReadRadar(char* pfileName);
void KRLFreeRadar(KRL_RADAR* pKRLRadar);
int KRLWriteRadar(char* pfileName, KRL_RADAR* pKRLRadar);
float* KRLSweepToCart(Sweep* ps, int xdim, int ydim, float range);

