/**
 * @file KRL_radar.c
 * @brief ���̴� 2���� ���δ�Ʈ ���� �Լ��� ��ϵ� ����
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>
#include <math.h>
#include "radar_comm.h"

/*******************************************
	KRL 10�� ���δ�Ʈ ���� ����
*******************************************/
/**
 * @brief ���� �ڷḦ BASE ���·� ��ȯ
 * @param Volume* pvolume ���̴� ���� �ڷ�
 * @param xdim
 * @param ydim
 * @param range
 * @return pBASEData BASE �ڷ�
 * @author �豤ȣ
 */
float* KRLVolumeToBASE(Volume* pvolume, int xdim, int ydim, int range)
{
	float** pimsiData;
	float* pBASEData;
	int i;
	int j;
	int k;
	int nsweeps;

	if (pvolume == NULL)
		return NULL;

	nsweeps = pvolume->h.nsweeps;
	pimsiData = malloc(nsweeps * sizeof(float *));
	for (j = 0; j < pvolume->h.nsweeps; j++ )
	{
		if (pvolume->sweep[j] == NULL) continue;
		pimsiData[j] = KRLSweepToCart(pvolume->sweep[j],xdim,ydim,range);
	}
	
	pBASEData = malloc(xdim * ydim * sizeof(float));
	for (i = 0 ; i < xdim * ydim ; i++ )
		pBASEData[i] = BAD_VALUE_F;

	for (i = 0 ; i < xdim * ydim ; i++ )
	{
		pBASEData[i] = BAD_VALUE_F;
		for (k = 0; k < nsweeps ; k++ )
		{
			if (pimsiData[k][i] != BAD_VALUE_F)
			{
				pBASEData[i] = pimsiData[k][i];
				break;
			}
		}
	}

	for (i=0; i<nsweeps;i++) {
		free(pimsiData[i]);
		pimsiData[i] = NULL;
	}
	free(pimsiData);
	pimsiData = NULL;

	return pBASEData;
}

/**
 * @brief sweep �ڷḦ ī�׽þ� ���·� ��ȯ
 * @param Sweep* s sweep �ڷ�
 * @param xdim
 * @param ydim
 * @param range
 * @return pcartImage ī�׽þ� �ڷ�
 * @author �豤ȣ
 */
float* KRLSweepToCart(Sweep* ps, int xdim, int ydim, float range)
{
	/* Range specifies the maximum range that to load points into the image. */

  	int x;
  	int y;
  	float azim;
  	float r;
  	float val;
  	int theIndex;
  	Ray* pray;
  	float beamWidth;
  	int i;

  	static float* pcartImage = NULL;

  	if (ps == NULL) return NULL;
  	if (xdim != ydim || ydim < 0 || xdim < 0)
  	{
		fprintf(stderr, "(xdim=%d) != (ydim=%d) or either negative.\n", xdim, ydim);
		return NULL;
  	}
  	pcartImage = (float*) calloc(xdim * ydim, sizeof(float));

  	for ( i = 0 ; i < xdim * ydim ; i++ )
  	{
	  	pcartImage[i] = BAD_VALUE_F;
  	}
  	beamWidth = ps->h.beam_width/2.0 * 1.2;
  	if (beamWidth == 0) beamWidth = 1.2;  /* Sane image generation. */

  	for (y=-ydim / 2 ; y < ydim / 2 ; y++)
		for (x=-xdim / 2; x < xdim / 2; x++) /* Find azimuth and range, then search Volume. */
		{
	  		if (x !=0 ) 
				azim = (float)atan((double)y / (double)x) * 180.0 / 3.14159;
	  		else
			if (y < 0) azim = -90.0;
			else azim = 90.0;
	  		if (y<0 && x<0) /* Quadrant 3 (math notation). */
			azim -= 180;
	  		else if (y>=0 && x<0) /* Quad: 2 */
			azim += 180;
	  
	 		/* Radar is clockwise increasing. */
	  		azim = -azim;
	  
	  		azim -= 90.0;
	  		if (azim < 0) azim += 360.0;

	  		r = (float)sqrt((double)x*x + (double)y*y);
	 		if (ydim < xdim) r *= range/(.5*ydim);
	  		else r *= range/(.5*xdim);
	  		if (r > range) val = BADVAL;
	  		else
	  		{
				pray = RSL_get_closest_ray_from_sweep(ps, azim, beamWidth);
				val = RSL_get_value_from_ray(pray, r);
	  		}
	  		theIndex =  (y+ydim/2)*ydim + (xdim-1)-(x+xdim/2);
	  		if (val == BADVAL || val == NOTFOUND_V || val == NOTFOUND_H)
	  		{
				pcartImage[theIndex] = BAD_VALUE_F;
	  		}
	  		else
	  		{
	    		pcartImage[theIndex] = val;
	  		}	
		}
  	return pcartImage;
}

/**
 * @brief ���δ�Ʈ ������ ��� �б�
 * @return  phead ���δ�Ʈ�� ���
 * @author �豤ȣ
 */
static KRL_RADAR_HEAD* KRLReadRadarHead(FILE* pfp)
{
	KRL_RADAR_HEAD* phead;
	if (pfp == NULL)
		return NULL;

	phead = malloc(sizeof(KRL_RADAR_HEAD));
	if (gzread(pfp, phead, sizeof(KRL_RADAR_HEAD)) < 0)
		return NULL;

	return phead;
}

/**
 * @brief ���δ�Ʈ ���� �б�
 * @param pfilename ���δ�Ʈ ���ϸ�
 * @return  pKRLRadar ���δ�Ʈ ����ü
 * @author �豤ȣ
 */
KRL_RADAR* KRLReadRadar(char* pfileName)
{
	KRL_RADAR* pKRLRadar;
	FILE* pfp;
	KRL_RADAR_HEAD* pKRLRadarHead;
	int readBytes;
	int expBytes;

	if ((pfp = gzopen(pfileName, "rb")) == NULL)
		return NULL;

	pKRLRadarHead = KRLReadRadarHead(pfp);
	if (pKRLRadarHead == NULL)
	{
		fclose(pfp);
		return NULL;
	}

	pKRLRadar = malloc(sizeof(KRL_RADAR));

	memcpy(&pKRLRadar->head, pKRLRadarHead, sizeof(KRL_RADAR_HEAD));
	free(pKRLRadarHead);
	pKRLRadarHead = NULL;

	pKRLRadar->pdata = malloc(pKRLRadar->head.xdim * pKRLRadar->head.ydim * sizeof(float));
	if (pKRLRadar->pdata == NULL)
	{
		fclose(pfp);
		return NULL;
	}

	expBytes = pKRLRadar->head.xdim * pKRLRadar->head.ydim * sizeof(float);
	readBytes = gzread(pfp,pKRLRadar->pdata,pKRLRadar->head.xdim * pKRLRadar->head.ydim * sizeof(float));

	if (readBytes != expBytes)
	{
		fprintf(stderr,"exp bytes : %d, readBytes : %d\n",expBytes, readBytes);
		free(pKRLRadar->pdata);
		free(pKRLRadar);
		return NULL;
	}
	if (readBytes < 0)
		return NULL;

	gzclose(pfp);

	return pKRLRadar;

}

/**
 * @brief ���δ�Ʈ ������ �޸� ����
 * @return  pKRLRadar
 * @author �豤ȣ
 */
void KRLFreeRadar(KRL_RADAR* pKRLRadar)
{
	free(pKRLRadar->pdata);
	pKRLRadar->pdata = NULL;
	free(pKRLRadar);
	pKRLRadar = NULL;
}

/**
 * @brief KRL ���̴� �ڷ� ���
 * @param ppfilename ���ϸ�
 * @param pKRLRadar KRL ���̴� �ڷ�
 * @return ������ 1: ����, -1: ����
 * @author �豤ȣ
 */
int KRLWriteRadar(char* pfileName, KRL_RADAR* pKRLRadar)
{
	FILE* pfp;

	if ((pfp = gzopen(pfileName,"wb")) == NULL)
		return -1;

	if (gzwrite(pfp,&pKRLRadar->head,sizeof(KRL_RADAR_HEAD)) < 0)
		return -1;

	if (gzwrite(pfp,pKRLRadar->pdata,pKRLRadar->head.xdim*pKRLRadar->head.ydim*sizeof(float)) < 0)
		return -1;

	gzclose(pfp);

	return 1;
}
