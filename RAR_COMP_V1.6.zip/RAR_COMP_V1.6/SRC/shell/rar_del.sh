#!/bin/sh

PROJECT_PATH=/home/khkim/MYCODE_DIR/18_FINAL_RAR/racos.qc

# delete filtion
if [ "$1" = "" ]; then
	  datetime=`/bin/date --date '10 minute ago' +%Y%m%d%H%M | /bin/cut -c1-11`0
else
	  datetime=$1
fi

rm -rf $PROJECT_PATH/DATA/BIN/SITE/*qped.bin.gz
find $PROJECT_PATH/DATA/BIN/COMP -type f -exec rm -f {} \;
find $PROJECT_PATH/DATA/IMG -type f -exec rm -f {} \;
find $PROJECT_PATH/DATA/TXT -type f -exec rm -f {} \;
find $PROJECT_PATH/LOG -type f -exec rm -f {} \;
#find $PROJECT_PATH/TEMP -type f -exec rm -f {} \;
#find $PROJECT_PATH/DATA -type f -exec rm -f {} \;
