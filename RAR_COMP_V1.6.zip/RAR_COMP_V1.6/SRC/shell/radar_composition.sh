#!/bin/bash

#define PATH
PATH=/usr/bin:/usr/local/bin:/usr/local/home/rainbow/bin:/usr/ccs/bin
export PATH
#define LD_LIBRARY_PATH
LD_LIBRARY_PATH=/usr/local/trmm/GVBOX/lib:/usr/local/lib:/usr/lib:/lib
export LD_LIBRARY_PATH
#define COMP_RADAR_ROOT_PATH
COMP_RADAR_ROOT_PATH=/home/khkim/MYCODE_DIR/18_FINAL_RAR/racos.qc/
export COMP_RADAR_ROOT_PATH

##############################################################################
#                         Unused radar site list                             #
##############################################################################
UNUSE_SITE='NO_SITE' #don't touch this line
#UNUSE_SITE="${UNUSE_SITE},BRI" #��ɵ�
#UNUSE_SITE="${UNUSE_SITE},GDK" #������
#UNUSE_SITE="${UNUSE_SITE},IIA" #��õ����
#UNUSE_SITE="${UNUSE_SITE},JNI" #����
#UNUSE_SITE="${UNUSE_SITE},KSN" #����(������)
#UNUSE_SITE="${UNUSE_SITE},KWK" #���ǻ�
#UNUSE_SITE="${UNUSE_SITE},PSN" #�λ�(������)
#UNUSE_SITE="${UNUSE_SITE},MYN" #�����
#UNUSE_SITE="${UNUSE_SITE},GSN" #����
#UNUSE_SITE="${UNUSE_SITE},SSP" #������
#UNUSE_SITE="${UNUSE_SITE},GNG" #����
#UNUSE_SITE="${UNUSE_SITE},DNH" #����
#���ѹα� ���� (ROKAF)
#UNUSE_SITE="${UNUSE_SITE},YCN" #��õ
#UNUSE_SITE="${UNUSE_SITE},WNJ" #����
#UNUSE_SITE="${UNUSE_SITE},SCN" #��õ
#UNUSE_SITE="${UNUSE_SITE},TAG" #�뱸
#UNUSE_SITE="${UNUSE_SITE},KWJ" #����
#UNUSE_SITE="${UNUSE_SITE},JWN" #�߿�
#UNUSE_SITE="${UNUSE_SITE},KAN" #����
#UNUSE_SITE="${UNUSE_SITE},SAN" #����
#UNUSE_SITE="${UNUSE_SITE},SWN" #����
#�� ���� (USAF)
#UNUSE_SITE="${UNUSE_SITE},RKJK" #����
#UNUSE_SITE="${UNUSE_SITE},RKSG" #����
#����� (MLTM)
#UNUSE_SITE="${UNUSE_SITE},BSL" #�񽽻�
#UNUSE_SITE="${UNUSE_SITE},IMJ" #������

##############################################################################
#                         Option List                                        #
##############################################################################
OPTION_LIST='' #don't touch this line
#OPTION_LIST="${OPTION_LIST} -p" #Unused radar_qpe program
#OPTION_LIST="${OPTION_LIST} -e" #Unused rar_verify program
OPTION_LIST="${OPTION_LIST} -r" #Unused realtime data(use pasttime)
OPTION_LIST="${OPTION_LIST} -t" #Unused run_transport

if [ `echo $UNUSE_SITE` = 'NO_SITE' ]
then
	echo ${COMP_RADAR_ROOT_PATH}BIN/rrc $OPTION_LIST $1
	${COMP_RADAR_ROOT_PATH}BIN/rrc $OPTION_LIST $1
else
	UNUSE_SITE=`echo $UNUSE_SITE | cut -b 9-`
	echo ============================================================
	echo =     UNUSE RADAR SITE = $UNUSE_SITE
	echo ============================================================
	echo ${COMP_RADAR_ROOT_PATH}BIN/rrc -u${UNUSE_SITE} $OPTION_LIST $1
	${COMP_RADAR_ROOT_PATH}BIN/rrc -u${UNUSE_SITE} $OPTION_LIST $1
fi
