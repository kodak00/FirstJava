#!/bin/sh

PROJECT_PATH=/home/khkim/MYCODE_DIR/18_FINAL_RAR/racos.qc/

for ((i=0;i<1440;i+=10))
do
dy=20090707
min=$((i%60))
hr=$((i/60))
dmin=$min
dhr=$hr

if [ $min -lt 10 ]
then
	  dmin=0$min
fi
if [ $hr -lt 10 ]
then
	   dhr=0$hr
fi

UF_day=$dy$dhr$dmin

# run radar_composition.sh
echo "$PROJECT_PATH/BIN/radar_composition.sh $UF_day"
$PROJECT_PATH/BIN/radar_composition.sh $UF_day

done
