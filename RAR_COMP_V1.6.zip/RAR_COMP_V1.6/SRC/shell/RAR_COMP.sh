#!/bin/sh

PROJECT_PATH=/home/RAR_COMP

# time calculation
if [ "$1" = "" ]; then
  datetime=`/bin/date --date '10 minute ago' +%Y%m%d%H%M | /bin/cut -c1-11`0
else
  datetime=$1
fi

# run radar_composition.sh
#echo "$PROJECT_PATH/bin/radar_composition.sh $datetime"
$PROJECT_PATH/BIN/radar_composition.sh $datetime

# delete file
DIR=$PROJECT_PATH/DATA
/bin/find $DIR -type f -cmin +360 -exec rm -f {} \;
