/**
 * @file verify.c
 * @brief ����Ʈ �� ���̴� ���췮 ������ ���� ����� ������ ��ϵ� �Լ�
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "rar_verify.h"

static int writeVerifyRainTableTextFile(char* pfileName);
static int writeVerifySpaceStatisticsTextFile(char* pfileName,float ACC,float bias,float POD,float FAR,float CSI,float ME,float MAE,float MSE,float RMSE,float corr,float AWSMean,float radarMean);
static int calSpaceStastics(float* pACC,float* pbias,float* pPOD,float* pFAR,float* pCSI,float* pME,float* pMAE,float* pMSE,float* pRMSE,float* pcorr,float* pAWSMean,float* pradarMean);
static float calACC(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//��Ȯ��(ACC, forecast accuracy)
static float calBias(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//BIAS(Bias score)
static float calPOD(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//POD(Probability of Detection)
static float calFAR(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//FAR(Fale Alarm Ratio)
static float calCSI(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//CSI(Critical Success Index)
static float calME(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//��տ���(ME, Mean Error)
static float calMAE(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//������տ���(MAE, Mean Absolute Error)
static float calMSE(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//�����������(MSE, Mean Square Error)
static float calRMSE(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//��������ٿ���(RMSE, Root Mean Square Error)
static float calCorr(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//������(Correlation Coefficient)
static int calAWSRadarMean(int count, int* puse, float* pAWSRainTable, float* pradarRainTable, float* pAWSMean, float* pradarMean);

/**
 * @brief AWS ���̴� ���췮 �� ��谪 ������ ���� ���� �Լ�
 * @return ������ 1: ����, -9999: ����
 * @author �豤ȣ
 */
int generateRadarDataInAWS()
{
	int i;

	char* pverificationTextFileName;

	float ACC;
	float bias;
	float POD;
	float FAR;
	float CSI;
	float ME;
	float MAE;
	float MSE;
	float RMSE;
	float corr;
	float AWSMean;
	float radarMean;

	//dBZ ���
	for (i = 0 ; i <  g_AWSCount ; i++)
	{
		g_AWS[i].dBZ = BAD_VALUE_F;
		if (!g_AWS[i].use) continue;

		if (g_AWS[i].radarRain > 0)
		{
			g_AWS[i].dBZ = RToDBZ(g_AWS[i].radarRain,g_site.zr.a,g_site.zr.b);
		}
	}

	//diff ���
	for (i = 0 ; i <  g_AWSCount ; i++)
	{
		if (!g_AWS[i].use) continue;

		if (g_AWS[i].rain60min < g_option.minAWSRainrate || g_AWS[i].rain60min > g_option.maxAWSRainrate) continue;
		if (g_AWS[i].radarRain < g_option.minRadarRainrate || g_AWS[i].radarRain > g_option.maxRadarRainrate) continue;

		g_AWS[i].diff = g_AWS[i].radarRain - g_AWS[i].rain60min;
	}

	g_availableAWSNum = 0;
	
	//AWS ���� �ľ�
	for (i = 0 ; i <  g_AWSCount ; i++)
	{
		if (!g_AWS[i].use) continue;

		if (g_AWS[i].rain60min < g_option.minAWSRainrate || g_AWS[i].rain60min > g_option.maxAWSRainrate) continue;

		g_availableAWSNum++;
	}

	//RAINTABLE TEXT
	pverificationTextFileName = generateVerificationFileName(3);
	printf("verification_raintable_text_filename = %s\n",pverificationTextFileName);
	if (writeVerifyRainTableTextFile(pverificationTextFileName) < 0)
	{
		return -9999;
	}

	//SPACE STATISTICS TEXT
	calSpaceStastics(&ACC,&bias,&POD,&FAR,&CSI,&ME,&MAE,&MSE,&RMSE,&corr,&AWSMean,&radarMean);
	pverificationTextFileName = generateVerificationFileName(5);
	printf("write_verify_space_statistics_text_file = %s\n",pverificationTextFileName);
	if (writeVerifySpaceStatisticsTextFile(pverificationTextFileName,ACC,bias,POD,FAR,CSI,ME,MAE,MSE,RMSE,corr,AWSMean,radarMean) < 0)
	{
		return -9999;
	}

	return 1;
}

/**
* @brief ���������� ������/������ ��� ����� �����ϴ� �Լ�
* @param pACC
* @param pbias
* @param pPOD
* @param pFAR
* @param pCSI
* @param pME
* @param pMAE
* @param pMSE
* @param pRMSE
* @param pcorr
* @param pAWSMean
* @param pradarMean
* @return ������ 1: ����
* @author �豤ȣ
*/
static int calSpaceStastics(float* pACC,float* pbias,float* pPOD,float* pFAR,float* pCSI,float* pME,float* pMAE,float* pMSE,float* pRMSE,float* pcorr,float* pAWSMean,float* pradarMean)
{
	int i;

	int count;
	int* puseTable;
	float* pspaceAWSRainTable;		//AWS ���췮
	float* pspaceRadarRainTable;	//���̴� ���췮

	puseTable = malloc(g_AWSCount * sizeof(int));
	pspaceAWSRainTable = malloc(g_AWSCount * sizeof(float));
	pspaceRadarRainTable = malloc(g_AWSCount * sizeof(float));

	for ( i = 0 ; i < g_AWSCount ; i++ )
	{
		puseTable[i] = g_AWS[i].use;
		pspaceAWSRainTable[i] = g_AWS[i].rain60min;
		pspaceRadarRainTable[i] = g_AWS[i].radarRain;
	}
	count = g_AWSCount;


	*pACC = calACC(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pbias = calBias(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pPOD = calPOD(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pFAR = calFAR(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pCSI = calCSI(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pME = calME(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pMAE = calMAE(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pMSE = calMSE(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pRMSE = calRMSE(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pcorr = calCorr(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	calAWSRadarMean(count, puseTable, pspaceAWSRainTable, pspaceRadarRainTable, pAWSMean, pradarMean);

	
	free(puseTable);
	free(pspaceAWSRainTable);
	free(pspaceRadarRainTable);

	return 1;
}

/**
* @brief ������ ���� �Լ�(��Ȯ��: ACC)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return ACC
* @author �豤ȣ
*/
static float calACC(int count, int* puse, float* pAWSRainTable, float* pradarRainTable)
{
	int Z;
	int F;
	int M;
	int H;
	int N;
	int i;
	float ACC;

	N = 0;
	Z = 0;
	F = 0;
	M = 0;
	H = 0;
	for (i = 0 ; i < count ; i++)
	{
		N++;
		if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate ) H++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate) F++;
		else if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate ) M++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate) Z++;

	}

	if (N <= 0)
	{
		return BAD_VALUE_F;
	}
	ACC = (Z+H)/(N*1.);
	if (isnormal(ACC))
	{
		return (float)ACC;
	}
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(Bias score)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return bias
* @author �豤ȣ
*/
static float calBias(int count, int* puse, float* pAWSRainTable, float* pradarRainTable)
{
	int Z;
	int F;
	int M;
	int H;
	int N;
	int i;
	float bias;

	N = 0;
	Z = 0;
	F = 0;
	M = 0;
	H = 0;
	for (i = 0 ; i < count ; i++)
	{
		N++;
		if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate ) H++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate) F++;
		else if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate ) M++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate) Z++;
	}

	if ((M+H) <= 0)
    {
		return BAD_VALUE_F;
	}
	bias = (F+H)/((M+H)*1.);

	if (isnormal(bias))
		return (float)bias;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(POD)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return POD
* @author �豤ȣ
*/
static float calPOD(int count, int* puse,float* pAWSRainTable, float* pradarRainTable)
{
	int Z;
	int F;
	int M;
	int H;
	int N;
	int i;
	float POD;

	N = 0;
	Z = 0;
	F = 0;
	M = 0;
	H = 0;
	for (i = 0 ; i < count ; i++)
	{
		N++;
		if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate ) H++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate) F++;
		else if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate ) M++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate) Z++;
	}

	if ((M+H) <= 0) 
	{
		return BAD_VALUE_F;
	}
	POD = (H)/((M+H)*1.);

	if (isnormal(POD))
		return (float)POD;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(FAR)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return FAR
* @author �豤ȣ
*/
static float calFAR(int count, int* puse, float* pAWSRainTable, float* pradarRainTable)
{
	int Z;
	int F;
	int M;
	int H;
	int N;
	int i;
	float FAR;

	N = 0;
	Z = 0;
	F = 0;
	M = 0;
	H = 0;
	for (i = 0 ; i < count ; i++)
	{
		N++;
		if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate ) H++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate) F++;
		else if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate ) M++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate) Z++;
	}

	if ((F+H) <= 0 ) 
	{
		return BAD_VALUE_F;
	}
	FAR = (F)/((F+H)*1.);

	if (isnormal(FAR))
		return (float)FAR;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(CSI)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return CSI
* @author �豤ȣ
*/
static float calCSI(int count, int* puse, float* pAWSRainTable, float* pradarRainTable)
{
	int Z;
	int F;
	int M;
	int H;
	int N;
	int i;
	float CSI;

	N = 0;
	Z = 0;
	F = 0;
	M = 0;
	H = 0;
	for (i = 0 ; i < count ; i++)
	{
	
		N++;
		if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate ) H++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate) F++;
		else if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate ) M++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate) Z++;
	}

	if ((H+M+F) <= 0)
	{
		return BAD_VALUE_F;
	}
	CSI = (H)/((H+M+F)*1.);

	if (isnormal(CSI))
		return (float)CSI;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(ME)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return ME
* @author �豤ȣ
*/
static float calME(int count, int* puse, float* pAWSRainTable, float* pradarRainTable)
{
	float ME;
	float sum = 0;
	int N = 0;
	int i;

	for (i = 0 ; i < count ; i++)
	{
		if (!puse[i]) continue;
		if (pradarRainTable[i] < g_option.minRadarRainrate || pradarRainTable[i] > g_option.maxAWSRainrate) continue;
		if (pAWSRainTable[i] < g_option.minAWSRainrate || pAWSRainTable[i] > g_option.maxAWSRainrate) continue;

		N++;
		sum += pradarRainTable[i] - pAWSRainTable[i];
	}

	if (N <= 0)
	{
		return BAD_VALUE_F;
	}
	ME = sum/(N*1.);

	if (isnormal(ME))
		return (float)ME;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(MAE)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return MAE
* @author �豤ȣ
*/
static float calMAE(int count, int* puse, float* pAWSRainTable, float* pradarRainTable)
{
	float MAE;
	float sum = 0;
	int N = 0;
	int i;

	for (i = 0 ; i < count ; i++)
	{
		if (!puse[i]) continue;
		if (pradarRainTable[i] < g_option.minRadarRainrate || pradarRainTable[i] > g_option.maxAWSRainrate) continue;
		if (pAWSRainTable[i] < g_option.minAWSRainrate || pAWSRainTable[i] > g_option.maxAWSRainrate) continue;

		N++;
		sum += fabs(pradarRainTable[i] - pAWSRainTable[i]);
	}

	if (N <= 0)
	{
		return BAD_VALUE_F;
	}
	MAE = sum/(N*1.);

	if (isnormal(MAE))
		return (float)MAE;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(MSE)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return MSE
* @author �豤ȣ
*/
static float calMSE(int count, int* puse, float* pAWSRainTable, float* pradarRainTable)
{
	float MSE;
	float sum = 0;
	int N = 0;
	int i;

	for (i = 0 ; i < count ; i++)
	{
		if (!puse[i]) continue;
		if (pradarRainTable[i] < g_option.minRadarRainrate || pradarRainTable[i] > g_option.maxAWSRainrate) continue;
		if (pAWSRainTable[i] < g_option.minAWSRainrate || pAWSRainTable[i] > g_option.maxAWSRainrate) continue;

		N++;
		sum += pow((pradarRainTable[i] - pAWSRainTable[i]),2);
	}

	if (N <= 0)
	{
		return BAD_VALUE_F;
	}
	MSE = sum/(N*1.);

	if (isnormal(MSE))
		return (float)MSE;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(RMSE)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return RMSE
* @author �豤ȣ
*/
static float calRMSE(int count, int* puse, float* pAWSRainTable, float* pradarRainTable)
{
	float RMSE;
	float sum = 0;
	int N = 0;
	int i;

	for (i = 0 ; i < count ; i++)
	{
		if (!puse[i]) continue;
		if (pradarRainTable[i] < g_option.minRadarRainrate || pradarRainTable[i] > g_option.maxAWSRainrate) continue;
		if (pAWSRainTable[i] < g_option.minAWSRainrate || pAWSRainTable[i] > g_option.maxAWSRainrate) continue;

		N++;
		sum += pow((pradarRainTable[i] - pAWSRainTable[i]),2);
	}

	if (N <= 0)
	{
		return BAD_VALUE_F;
	}
	RMSE = pow(sum/(N*1.),0.5);

	if (isnormal(RMSE))
		return (float)RMSE;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(corr)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return corr
* @author �豤ȣ
*/
static float calCorr(int count, int *puse,float *pAWSRainTable, float *pradarRainTable)
{
	double corr;
	int i;
	double numerator = 0;
	float denominator = 0;
	float sumNumerator = 0;
	float sumDenominator1 = 0;
	float sumDenominator2 = 0;
	float FMean = 0;
	float OMean = 0;
	float FSum = 0;
	float OSum = 0;
	int N = 0;
	float F;
	float O;


	for (i = 0 ; i < count ; i++)
	{
		if (!puse[i]) continue;
		if (pradarRainTable[i] < g_option.minRadarRainrate || pradarRainTable[i] > g_option.maxAWSRainrate) continue;
		if (pAWSRainTable[i] < g_option.minAWSRainrate || pAWSRainTable[i] > g_option.maxAWSRainrate) continue;

		N++;
		FSum += pradarRainTable[i];
		OSum += pAWSRainTable[i];
	}
	FMean = FSum/(N*1.);
	OMean = OSum/(N*1.);

	if (N <= 0)
	{
		return BAD_VALUE_F;
	}

	for (i = 0 ; i < count ; i++)
	{
		if (!puse[i]) continue;
		if (pradarRainTable[i] < g_option.minRadarRainrate || pradarRainTable[i] > g_option.maxAWSRainrate) continue;
		if (pAWSRainTable[i] < g_option.minAWSRainrate || pAWSRainTable[i] > g_option.maxAWSRainrate) continue;

		F = pradarRainTable[i];
		O = pAWSRainTable[i];

		sumNumerator += (F - FMean) * (O - OMean);

		sumDenominator1 += pow(F - FMean,2);
		sumDenominator2 += pow(O - OMean,2);
	}
	numerator = sumNumerator;

	if (sumDenominator1 < 0 || sumDenominator2 < 0)
	{
		return BAD_VALUE_F;
	}

	denominator = pow(sumDenominator1,0.5) * pow(sumDenominator2,0.5);

	if (denominator == 0)
	{
		return BAD_VALUE_F;
	}

	corr = numerator/denominator;

	if (isnormal(corr))
		return (float)corr;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(mean)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return pAWSMean, pradarMean 
* @author �豤ȣ
*/
static int calAWSRadarMean(int count, int* puse, float* pAWSRainTable, float* pradarRainTable, float* pAWSMean, float* pradarMean)
{
	int i;
	int availAWSCount = 0;
	int availRadarCount = 0;
	float sumAWS = 0;
	float sumRadar = 0;
	*pAWSMean = BAD_VALUE_F;
	*pradarMean = BAD_VALUE_F;

	for (i = 0 ; i < count ; i++ )
	{
		if (!puse[i]) continue;
		if (pAWSRainTable[i] < g_option.minAWSRainrate || pAWSRainTable[i] > g_option.maxAWSRainrate) continue;
		if (pradarRainTable[i] < g_option.minRadarRainrate || pradarRainTable[i] > g_option.maxRadarRainrate) continue;

		sumAWS += pAWSRainTable[i];
		availAWSCount++;

		sumRadar += pradarRainTable[i];
		availRadarCount++;
	}

	if (availAWSCount > 0)
	{
		*pAWSMean = sumAWS / (availAWSCount*1.);
	}

	if (availRadarCount > 0)
	{
		*pradarMean = sumRadar / (availRadarCount*1.);
	}

	return 0;
}

/**
* @brief ����� ����(Raintable)
* @param pfileName ���ϸ�
* @return ������ 1: ���� ����: ����
* @author �豤ȣ
*/
static int writeVerifyRainTableTextFile(char* pfileName)
{
	int i;
	FILE* pfp;
	float mpRain;

	if ((pfp = fopen(pfileName,"w"))== NULL)
	{ 
		return -9999;
	}

	for (i = 0 ; i < g_AWSCount ; i++ )
	{
		mpRain = dBZToRF(g_AWS[i].dBZ,DEFAULT_ZR_A,DEFAULT_ZR_B);
                if (g_AWS[i].dBZ >= 100.){
                    mpRain = BAD_VALUE_F;
                    g_AWS[i].radarRain = BAD_VALUE_F;
                    g_AWS[i].diff = BAD_VALUE_F;
                    g_AWS[i].dBZ = BAD_VALUE_F;
                }
		fprintf(pfp,"%d %6.2f %6.2f %6.2f %6.2f %6.2f\n",g_AWS[i].id,g_AWS[i].rain60min,g_AWS[i].radarRain,g_AWS[i].diff,mpRain,g_AWS[i].dBZ);
	}
	fclose(pfp);

	return 1;
}

/**
* @brief ����� ����(�����������ڷ�)
* @param pfileName ���ϸ�
* @param pACC
* @param pbias
* @param pPOD
* @param pFAR
* @param pCSI
* @param pME
* @param pMAE
* @param pMSE
* @param pRMSE
* @param pcorr
* @param pAWSMean
* @param pradarMean
* @return ������ 1: ���� ����: ����
* @author �豤ȣ
*/
static int writeVerifySpaceStatisticsTextFile(char* pfileName,float ACC,float bias,float POD,float FAR,float CSI,float ME,float MAE,float MSE,float RMSE,float corr,float AWSMean,float radarMean)
{
	FILE* pfp;

	if ((pfp = fopen(pfileName,"w"))== NULL)
	{
		return -9999;
	}
	
	fprintf(pfp,"ACC %f\n",ACC);
	fprintf(pfp,"BIAS %f\n",bias);
	fprintf(pfp,"POD %f\n",POD);
	fprintf(pfp,"FAR %f\n",FAR);
	fprintf(pfp,"CSI %f\n",CSI);
	fprintf(pfp,"ME %f\n",ME);
	fprintf(pfp,"MAE %f\n",MAE);
	fprintf(pfp,"MSE %f\n",MSE);
	fprintf(pfp,"RMSE %f\n",RMSE);
	fprintf(pfp,"CORR %f\n",corr);
	fprintf(pfp,"AWS_MEAN %f\n",AWSMean);
	fprintf(pfp,"RADAR_MEAN %f\n",radarMean);
	fprintf(pfp,"AVAILABLE_AWS %d %d\n",g_AWSCount,g_availableAWSNum);
	fclose(pfp);

	return 1;
}
