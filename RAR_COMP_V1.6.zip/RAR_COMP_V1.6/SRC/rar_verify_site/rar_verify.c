/**
 * @file rar_verify.c
 * @brief ����Ʈ �� ���̴� ���췮 ������ ���� ���� �Լ�.
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "rar_verify.h"

OPTION	g_option;				//ȯ�漳��
SITE	g_site;				//����Ʈ�� �ڷ�(init���� �ʱ�ȭ)
AWS*	g_AWS;
int		g_AWSCount;
int		g_availableAWSNum;

int main(int argc, char *argv[])
{
	int ERROR_CODE;
	int i;
	int p; //KKH
	char fileName[MAX_STRING_LENGTH];

	struct tm dateTimeTm;
	char tempTimeStr[MAX_STRING_LENGTH];
    struct tm tempTime;
	char tempString1[1];
	
	char fileNameHeader = ' '; //KKH
	char productTypeChar = ' '; //KKH
	char dataTypeChar=' '; //KKH
	
	g_option.pinputProductType = NULL; //KKH
	
	if (argc < 3)
	{
		fprintf(stderr,"Usage : rar_site_verify [SITE INITIAL] [YYYYMMDDHHmm]\n");
		return 1;
	}

	//�Էµ� �ð� string�ʱ�ȭ
	sprintf(g_option.datetimeString,"%s",argv[1]);
	dateTimeTm = convStrToDateTime(argv[1]);
	sprintf(g_site.name,"%s",argv[2]);

	/*******************************************
		ȯ�漳�� ���� �б�(setup.ini)
	*******************************************/
	if ((ERROR_CODE = readSetup()) < 0)
	{
		fprintf(stderr,"call readSetup Error No.%d\n",ERROR_CODE);
		return 4;
	}

	/*******************************************
		����Ʈ �ʱ�ȭ
	*******************************************/
	if ((ERROR_CODE = initSite(g_site.name)) < 0)
	{
		fprintf(stderr,"call init_radar Error No.%d\n",ERROR_CODE);
		return 4;
	}

	/*******************************************
		AWS ó��
	*******************************************/
	//AWS���� �̸� ����
	 printf("%s \n",g_option.datetimeString);
	 tempTime=convStrToDateTime(g_option.datetimeString);
	 tempTime=incMin(tempTime,0);
	 strftime(tempTimeStr,MAX_STRING_LENGTH,"%Y%m%d%H%M",&tempTime);
	 
    sprintf(g_option.AWSTRMMGSPFilePathName,"%s%s.g3min.txt",g_option.AWSTRMMGSPPath,tempTimeStr);
    printf("ccc: %s%s.g3min.txt \n",g_option.AWSTRMMGSPPath,tempTimeStr);

	g_AWS = readAWSPosFile();

	if ((ERROR_CODE = readAWSDataFile()) < 0)
	{
		fprintf(stderr,"call readAWSDataFile Error No.%d\n",ERROR_CODE);
		return 4;
	}


	for (p = 0 ; p < PRODUCT_TYPE_COUNT ; p++ ) //KKH product�� ������ for ��ƾ �߰�
	{
		//Product type�� �����ϵ��� �����Ǿ� �ִ��� �˻�
		if (!g_option.pinputProductType[p])
			continue;

		//���δ�Ʈ�� ���� �۾� ���� ���δ�Ʈ ����
		switch (p) //KKH
		{
			case PRODUCT_PPI	: g_option.productType = PRODUCT_PPI;	break;
			case PRODUCT_BASE	: g_option.productType = PRODUCT_BASE;	break;
			case PRODUCT_CAPPI	: g_option.productType = PRODUCT_CAPPI;	break;
		}

		switch (g_option.productType) //KKH
		{
			case PRODUCT_PPI	: productTypeChar = 'p';	break;
			case PRODUCT_BASE	: productTypeChar = 'b';	break;
			case PRODUCT_CAPPI	: productTypeChar = 'c';	break;
		}
		
		for (i = 0 ; i < strlen(g_option.fixRoute1) ; i++)
		{
			sprintf(tempString1,"%c",g_option.fixRoute1[i]);
			if (strstr(tempString1, "a") != NULL)
				g_option.fixRoute2 = 0;
			if (strstr(tempString1, "p") != NULL)
				g_option.fixRoute2 = 2;
			if (strstr(tempString1, "m") != NULL)
				g_option.fixRoute2 = 3;
	
			/*******************************************
				���� ZR �б�
			*******************************************/
			g_site.zr = readSiteZR(g_site.name,g_option.fixRoute2); //KKH g_option.fixRoute2
			
			fileNameHeader = 's'; //KKH
			dataTypeChar = 'r'; //KKH
			
			sprintf(fileName,"%s/%c%c%c%d_%s_%s_%s",g_option.site10minQPEDFilePath,fileNameHeader,productTypeChar,dataTypeChar,g_option.fixRoute2,g_site.name,g_option.datetimeString,FILE_EXT);
			printf("%s\n",fileName);
	
			g_site.pCAPPI = KRLReadRadar(fileName);

			makeRadarAWSPair();

			generateRadarDataInAWS();
		
			free(g_site.pCAPPI);
		}
	}

	return 0;
}
