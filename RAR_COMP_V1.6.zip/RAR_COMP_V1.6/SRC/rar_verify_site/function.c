/**
 * @file function.c
 * @brief ����Ʈ �� ���̴� ���췮 ������ ���� ȯ�漳���� �д� �Լ��� ��ϵ� ����
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rar_verify.h"

static char* generateZRLogFileName(int beforeMinutes, int fixRoute); //KKH add fixRoute

/**
 * @brief ȯ�漳������(setup.ini, rar_verify.ini)�� ������ �б� ���� �Լ�.
 * @return  ������ 1: ����, 1�̿��� ����: ����
 * @author �豤ȣ
 */
int readSetup()
{
	int ERROR_CODE;

	char iniFileName[MAX_STRING_LENGTH];

	char* ptempString;

	//ȯ�� ���� COMP_RADAR_ROOT_PATH �б�
	g_option.pprogramRootPath = getenv("COMP_RADAR_ROOT_PATH");
	if (g_option.pprogramRootPath == NULL)
		return -13001;

	//setup.ini
	sprintf(iniFileName,"%sRES/%s",g_option.pprogramRootPath,SETUP_INI_FILENAME);

	if ((ERROR_CODE = createIniFile(iniFileName)) < 0)
		return ERROR_CODE;

	//�ռ��ڷ� ����� ����ϴ� ����Ʈ�� QPED �ӽ� ���� �����ϴ� ���丮
	ptempString = readIniString("TEMP_DIRECTORY","SiteQped10Min","site/data/data/products/");
	sprintf(g_option.site10minQPEDFilePath,"%s%s",g_option.pprogramRootPath,ptempString);
	free(ptempString);

	//[AWS_TRMM_GSP]
	ptempString = readIniString("AWS_TRMM_GSP","LocalPath",NULL);
	sprintf(g_option.AWSTRMMGSPPath,"%s%s",g_option.pprogramRootPath,ptempString);
	free(ptempString);

	g_option.fixRoute1 = readIniString("RAR","Fix",NULL);

	destroyIniFile();

	//rar_verify.ini
	sprintf(iniFileName,"%sRES/%s",g_option.pprogramRootPath,SETUP_RAR_VERIFY_INI_FILENAME);

	if ((ERROR_CODE = createIniFile(iniFileName)) < 0)
		return ERROR_CODE;

	//���δ�Ʈ Ÿ��
	if (g_option.pinputProductType == NULL) //KKH
	{
		ptempString = readIniString("VERIFICATION","ProductType","c");
		g_option.pinputProductType = checkProductTypeOption(ptempString);
	}
	
	g_option.minAWSRainrate = readIniFloat("THRESHOLD_VALUE","MinAWSRainrate",0.1);
	g_option.maxAWSRainrate = readIniFloat("THRESHOLD_VALUE","MaxAWSRainrate",200.0);
	g_option.minRadarRainrate = readIniFloat("THRESHOLD_VALUE","MinRadarRainrate",0.1);
	g_option.maxRadarRainrate = readIniFloat("THRESHOLD_VALUE","MaxRadarRainrate",200.0);

	ptempString = readIniString("SITE_VERIFICATION_DIRECTORY","RaintableData","DATA/rar/verification/data/raintable_site/");
	sprintf(g_option.verificationRaintableDataPath,"%s%s",g_option.pprogramRootPath,ptempString);
	free(ptempString);
	
	ptempString = readIniString("SITE_VERIFICATION_DIRECTORY","SpaceStatisticsData","DATA/rar/verification/data/space_statistics_site/");
	sprintf(g_option.verificationSpaceStatticsDataPath,"%s%s",g_option.pprogramRootPath,ptempString);
	free(ptempString);

	//ȯ�漳�� ���� �̸� ����
	destroyIniFile();

	return 1;
}

/**
 * @brief ȯ�漳������(sites.ini)�� ������ �б� ���� �Լ�.
 * @param psiteName ���̴� ����Ʈ��
 * @return  ������ 1: ����
 * @author �豤ȣ
 */
int initSite(char* psiteName)
{
	char iniFileName[MAX_STRING_LENGTH];

	int ERROR_CODE;

	sprintf(iniFileName,"%sRES/%s",g_option.pprogramRootPath,SETUP_SITES_INI_FILENAME);

	if ((ERROR_CODE = createIniFile(iniFileName)) < 0)
		return ERROR_CODE;
	//[SITE]���� site�̸� ����
	g_site.xdim = readIniInt(g_site.name,"Xdim",480);
	g_site.ydim = readIniInt(g_site.name,"Ydim",480);
	g_site.useRAR = readIniInt(g_site.name,"UseRar",0);

	g_site.zr.a = BAD_VALUE_F;
	g_site.zr.b = BAD_VALUE_F;
	g_site.zr.route = -1;

	destroyIniFile();

	return 1;
}

/**
 * @brief ZR ��� ���� ���ϸ� ���� �Լ�
 * @param beforeMinutes ���� �ð�
 * @return pZRPathFilename ���ϰ�� �� ���ϸ�
 * @author �豤ȣ
 */
static char* generateZRLogFileName(int beforeMinutes, int fixRoute) //KKH add fixRoute
{
	char productTypeString[MAX_STRING_LENGTH];
	struct tm datetime;
	char fileDatetimeStr[MAX_STRING_LENGTH];
	char* pzrPathFileName;
	char productTypeChar = ' '; //KKH
	
	datetime = convStrToDateTime(g_option.datetimeString);

	datetime = incMin(datetime,beforeMinutes);

	strftime(fileDatetimeStr,MAX_STRING_LENGTH,"%Y%m%d%H%M",&datetime);

	switch (g_option.productType) //KKH
	{
		case PRODUCT_PPI	: 
			sprintf(productTypeString,"ppi");
			break;
		case PRODUCT_BASE	: 
			sprintf(productTypeString,"base");
			break;
		case PRODUCT_CAPPI	: 
			sprintf(productTypeString,"cappi");
			break;
		default :
			return NULL;
	}

	switch (g_option.productType) //KKH
	{
		case PRODUCT_PPI	: productTypeChar = 'P';	break;
		case PRODUCT_BASE	: productTypeChar = 'B';	break;
		case PRODUCT_CAPPI	: productTypeChar = 'C';	break;
	}

	pzrPathFileName = malloc(MAX_STRING_LENGTH * sizeof(char));
	
	sprintf(pzrPathFileName,"%sLOG/ZR/%s/%s.zr%c%d",g_option.pprogramRootPath,productTypeString,fileDatetimeStr,productTypeChar,fixRoute); //KKH zr%d

	return pzrPathFileName;
}

/**
 * @brief �� ����Ʈ�� Z-R ��� �д� �Լ�.
 * @param psiteInitial ����Ʈ �̴ϼ�
 * @return zrErr ����Ʈ�� Z-R ���
 * @author �豤ȣ
 */
ZR_VALUE readSiteZR(char* psiteInitial, int fixRoute) //KKH add fixRoute
{
	FILE* pfp;

	char datetimeStr[MAX_STRING_LENGTH];
	char buffer[MAX_STRING_LENGTH];
	char tempSiteInitial[MAX_STRING_LENGTH];
	char* pzrPathFileName;

	ZR_VALUE zr;

	ZR_VALUE zrErr;

	//�ʱ�ȭ
	zrErr.a = BAD_VALUE_F;
	zrErr.b = BAD_VALUE_F;
	zrErr.route = -1;

	//���� �̸� ����
	pzrPathFileName = generateZRLogFileName(0,fixRoute); //KKH add fixRoute
	printf(" - prev zr file name : %s\n",pzrPathFileName);
	if (pzrPathFileName == NULL) return zr;

	if ((pfp = fopen(pzrPathFileName,"r")) == NULL) return zr;
	free(pzrPathFileName);

	//����Ʈ �̸��� ��ġ�ϸ� ���
	while (fgets(buffer,MAX_STRING_LENGTH,pfp) != NULL)
	{
		sscanf(buffer,"%s %f %f %d\n",tempSiteInitial,&zr.a,&zr.b,&zr.route);
		//error check
		if (zr.a < 0.001 || zr.a > 9999. || zr.b < 0.001 || zr.b > 100. || 
				zr.route < 0 || zr.route > (ROUTE_COUNT))
		{
			printf("       * error in loading prevZR : %s %s a = %f b = %f route = %d \n",datetimeStr,tempSiteInitial,zr.a,zr.b,zr.route);
			continue;
		}

		if (strstr(tempSiteInitial,psiteInitial) == NULL)	continue;

		fclose(pfp);
		return zr;
	}
	fclose(pfp);

	return zrErr;
}

/**
 * @brief ���� ��� ���� �̸� ���� �Լ�.
 * @param type ���� ��� �ڷ� ����
 * @return pveri2kmPathFileName ���� ��� ���ϸ�
 * @author �豤ȣ
 */
char* generateVerificationFileName(int type)
//type : 3 : raintable Text
//type : 5 : Space static text
{
	char typeChar = ' ';
	char productTypeChar = ' ';
	char fileExt[MAX_STRING_LENGTH];
	char* veri2kmPathFileName;

	switch (g_option.productType) //KKH
		{
		case PRODUCT_PPI	: productTypeChar = 'p';	break;
		case PRODUCT_BASE	: productTypeChar = 'b';	break;
		case PRODUCT_CAPPI	: productTypeChar = 'c';	break;
		}

	//���� �̸�
	switch (type)
	{
		case 3 :
			veri2kmPathFileName = malloc(MAX_STRING_LENGTH*sizeof(char));
			typeChar = 't';
			sprintf(fileExt,"txt");
			sprintf(veri2kmPathFileName,"%s%c%c%c%d_%s_%s.%s",g_option.verificationRaintableDataPath
				,VERIFICATION_OUTPUT_FILE_HEADER,typeChar,productTypeChar,g_option.fixRoute2,g_site.name,g_option.datetimeString,fileExt);
			break;
		case 5 :
			veri2kmPathFileName = malloc(MAX_STRING_LENGTH*sizeof(char));
			typeChar = 's';
			sprintf(fileExt,"txt");
			sprintf(veri2kmPathFileName,"%s%c%c%c%d_%s_%s.%s",g_option.verificationSpaceStatticsDataPath
				,VERIFICATION_OUTPUT_FILE_HEADER,typeChar,productTypeChar,g_option.fixRoute2,g_site.name,g_option.datetimeString,fileExt);
			break;
		default : 
			return NULL;
	}

	return veri2kmPathFileName;
}

/**
 * @brief ����ڰ� �Է��� ���δ�Ʈ Ÿ���� �ؼ���.
 * @param pstr
 * @return pproductType ����ڰ� �Է��� ���δ�Ʈ Ÿ�Կ� �ش��ϴ� ��� '1', �ش����� �ʴ� ��� '0'�� ��ȯ
 * @author �豤ȣ
 */
int* checkProductTypeOption(char* pstr)
{
	int i;
	int* pproductType;

	pproductType = malloc(PRODUCT_TYPE_COUNT * sizeof(int));
	for (i = 0 ; i < PRODUCT_TYPE_COUNT ; i++ )
	{
		pproductType[i] = 0;
	}

	if (strstr(pstr,"p") != NULL)
		pproductType[PRODUCT_PPI] = 1;
	if (strstr(pstr,"b") != NULL)
		pproductType[PRODUCT_BASE] = 1;
	if (strstr(pstr,"c") != NULL)
		pproductType[PRODUCT_CAPPI] = 1;
	if (strstr(pstr,"e") != NULL)
	{
		for (i = 0 ; i < PRODUCT_TYPE_COUNT ; i++ )
		{
			pproductType[i] = 1;
		}
	}

	return pproductType;
}
