/**
 * @file log.c
 * @brief ������ �ռ��췮 ���� ���α׷��� �ǽð� ���� �α� ���� �Լ�.
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>

#include "rrc.h"
#include "log.h"

static FILE* fp = NULL;

static char logPathFileName[MAX_STRING_LENGTH];

char* extractFilename(char* filePathName);

int setLogPathFileName(char* pdateString, TIME_PARAMETER timeParameter)
{
	char* plogPath;

	plogPath = getenv("COMP_RADAR_ROOT_PATH");

	if (plogPath == NULL)
	{
		return -51001;
	}

	if (timeParameter == REALTIME)
	{
		sprintf(logPathFileName,"%sLOG/rrc/rrc_%s_r.log",plogPath,pdateString);
	}
	else if (timeParameter == PASTTIME)
	{
		sprintf(logPathFileName,"%sLOG/rrc/rrc_%s_p.log",plogPath,pdateString);
	}
	
	
	printf("logPathFileName = %s\n",logPathFileName);

	return 1;
}

int LogOpenFile()
{
	fp = fopen(logPathFileName,"wt");
	if (fp == NULL)
	{
		fprintf(stderr,"ERROR : Log file open : %s\n",logPathFileName);
		return 1;
	}

	return 0;
}

int LogWriteStart(char* program_name, char* process_name)
{
	return LogWrite("START", program_name, process_name, "START");
}

int LogWriteEnd(char* program_name, char* process_name)
{
	return LogWrite("END", program_name, process_name, "END");
}


int LogWriteRun(char* program_name, char* process_name, char* message)
{
	return LogWrite("RUN", program_name, process_name, message);
}

int LogWriteTime(char* program_name, char* process_name, char* message)
{
	return LogWrite("TIME", program_name, process_name, message);
}

int LogWriteInput(char* program_name, char* process_name, char* message)
{
	return LogWrite("INPUT", program_name, process_name, message);
}

int LogWriteOutput(char* program_name, char* process_name, char* message)
{
	return LogWrite("OUTPUT", program_name, process_name, message);
}


int LogWriteInformation(char* program_name, char* process_name, char* message)
{
	return LogWrite("INFORMATION", program_name, process_name, message);
}

int LogWriteError(char* program_name, char* process_name, char* message)
{
	return LogWrite("ERROR", program_name, process_name, message);
}

int LogWriteStatusSuccess(char* program_name, char* process_name)
{
	return LogWrite("STATUS", program_name, process_name, "SUCCESS");
}

int LogWriteStatusFail(char* program_name, char* process_name)
{
	return LogWrite("STATUS", program_name, process_name, "FAIL");
}



int LogWrite(char* type, char* program_name, char* process_name, char* message)
{
	time_t logTime;
	struct tm* now;
	char logTimeStr[20];
	if (fp == NULL)
	{
		fprintf(stderr,"ERROR : Log file was not open\n");
		return 1;
	}

	logTime = time((time_t*)0);
	now = localtime(&logTime);
	strftime(logTimeStr,20,"%Y/%m/%d %H:%M:%S",now);

	fprintf(fp,"%s | %s | %s | %s | %s\n", logTimeStr, program_name, process_name, type, message);
	fflush(fp);

	return 0;
}


void LogCloseFile()
{
	if (fp != NULL)
	{
		fclose(fp);
	}
}







