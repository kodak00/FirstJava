/**
 * @file function.h
 * @brief �ǽð� ������ ���� ȯ�ἳ���� �д� �Լ� ���̺귯��
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <time.h>
int readSetup();
int readDisplayServerIni();
struct tm initTime(struct tm datetime);
int initSite(int siteIndex);
int generateRadarFileName(struct tm datetime,int siteIndex);
int generateServerPathname(struct tm datetime);
int generateResultFileName(struct tm datetime);
int transmitFile(int runTime,struct tm fileTimeTm);
int generateAWSNameFromString(char* pdateString);
int getLocalUFFileName(int siteIndex);
int runRadarQPEProgram(struct tm datetime);
int runRARVerifyProgram(struct tm datetime);
int runRARSiteVerifyProgram(struct tm datetime,int siteIndex);
int runRadarRARSiteProgram(struct tm datetime,int siteIndex);

