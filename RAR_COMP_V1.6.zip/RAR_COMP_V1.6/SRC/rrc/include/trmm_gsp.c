/**
 * @file trmm_gsp.c
 * @brief ������ �ռ��췮 ���� ���α׷� �� TRMM-GSP ���α׷� ������ ���� �Լ�.
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <dirent.h>

#include "rrc.h"
#include "log.h"

/**
* @brief ���� ���� �ð��� ���� AWS ���ڷ��� ���� ���� �˻�
* @return fileCount ���� ����
* @author �豤ȣ
*/
int checkAWSRawFile()
{
	int i;
	int fileCount = 0;

	for (i = 0 ; i < 10 ; i++)
	{
		printf("%s\n",g_option.AWSLocalFilePathNameList[i]);
		if (fileExists(g_option.AWSLocalFilePathNameList[i]))
		{
			fileCount++;
		}
	}
	return fileCount;
}

/**
* @brief AWS QC ���α׷� ������ ���� �Լ�
* @return ERROR_CODE ����: ����
* @author �豤ȣ
*/
int runAWSQC(struct tm datetime)
{
	int result;
	int pid;
	int i;
	int count = 0;
	int parameterCount;
	char **p;
	int ERROR_CODE = -1;
	char datetimeString[MAX_STRING_LENGTH];

	parameterCount = 4;//program name, yyyymmddhhnn, programRootPath, NULL
	p = malloc(parameterCount * sizeof(char *));
	for (i = 0; i < parameterCount ; i++)
	{
		p[i] = malloc(MAX_STRING_LENGTH * sizeof(char));
	}
	
	sprintf(p[count++],"%s",g_option.AWSQCProgramPathName);
	//sprintf(p[count++],"%s",g_option.datetimeString);
	//sprintf(p[count++],"%s",g_option.realtimeString);

	strftime(datetimeString,MAX_STRING_LENGTH,"%Y%m%d%H%M",&datetime);

	sprintf(p[count++],"%s",datetimeString);

	sprintf(p[count++],"%s",g_option.programRootPath);

	p[count] = 0;

	if (count > parameterCount)
	{
		fprintf(stderr,"!!!!!!!!!! run_composition_radar_program error \n");
		
		// if error
		LogWriteError("COM_RAR", "runAWSQC", "Error runAWSQC argv[]");
		// log : process1 : fail
		LogWriteStatusFail("COM_RAR", "runAWSQC");
		exit(1);
	}
	
	
	pid = fork();
	if (pid < 0) //fork error
	{
		return -52023;
	}
	if (pid == 0)//CHILD
	{
		result = execv(g_option.AWSQCProgramPathName,p);
		return -52024;
	}
	else //parent
	{
		int statVal;

		waitpid(pid,&statVal,0);

		if(WIFEXITED(statVal)){
			switch WEXITSTATUS(statVal) {
				case 0 : ERROR_CODE = 1; break;
				default : ERROR_CODE = -9990; break;
			}
		}
		else if (WIFSIGNALED(statVal))
		{
			ERROR_CODE = -99999;
		}
		if (ERROR_CODE == 1)//���������̸�
		{
			//����.
		}
		//�޸� ����
		for (i = 0; i < parameterCount ; i++){
			free(p[i]);
		}
		free(p);
		return ERROR_CODE;
	}
}

/**
* @brief AWS QC ��ó�� ���α׷� ������ ���� �Լ�
* @return ERROR_CODE ����: ����
* @author �豤ȣ
*/
int runAWSQCIni(struct tm datetime)
{
	int result;
	int pid;
	int i;
	int count = 0;
	int parameterCount;
	char **p;
	int ERROR_CODE = -1;
	char datetimeString[MAX_STRING_LENGTH];
	
	parameterCount = 4;//program name, yyyymmddhhnn, programRootPath, NULL
	p = malloc(parameterCount * sizeof(char *));
	for (i = 0; i < parameterCount ; i++)
	{
		p[i] = malloc(MAX_STRING_LENGTH * sizeof(char));
	}
	
	sprintf(p[count++],"%s",g_option.AWSQCIniProgramPathName);
	
	strftime(datetimeString,MAX_STRING_LENGTH,"%Y%m%d%H%M",&datetime);

	sprintf(p[count++],"%s",datetimeString);

	sprintf(p[count++],"%s",g_option.programRootPath);

	p[count] = 0;

	if (count > parameterCount)
	{
		fprintf(stderr,"!!!!!!!!!! run_composition_radar_program error \n");
		
		// if error
		LogWriteError("COM_RAR", "runAWSQCIni", "Error runAWSQCIni argv[]");
		// log : process1 : fail
		LogWriteStatusFail("COM_RAR", "runAWSQCIni");
		exit(1);
	}
	
	pid = fork();
	if (pid < 0) //fork error
	{
		return -52023;
	}
	if (pid == 0)//CHILD
	{
		result = execv(g_option.AWSQCIniProgramPathName,p);
		return -52024;
	}
	else //parent
	{
		int statVal;

		waitpid(pid,&statVal,0);

		if(WIFEXITED(statVal)){
			switch WEXITSTATUS(statVal) {
				case 0 : ERROR_CODE = 1; break;
				default : ERROR_CODE = -9990; break;
			}
		}
		else if (WIFSIGNALED(statVal))
		{
			ERROR_CODE = -99999;
		}
		if (ERROR_CODE == 1)//���������̸�
		{
			//����.
		}
		//�޸� ����
		for (i = 0; i < parameterCount ; i++){
			free(p[i]);
		}
		free(p);
		return ERROR_CODE;
	}
}

/**
* @brief TRMM-GSP ��ó�� ���α׷� ������ ���� �Լ�
* @return ERROR_CODE ����: ����
* @author �豤ȣ
*/
int runAWSTRMMGSPInit()
{
	int result;
	int pid;
	int i;
	int count = 0;
	int parameterCount;
	char** p;
	int ERROR_CODE = -1;

	parameterCount = 4;//program name, yyyymmddhhnn, programRootPath, NULL
	p = malloc(parameterCount * sizeof(char *));
	for (i = 0; i < parameterCount ; i++)
	{
		p[i] = malloc(MAX_STRING_LENGTH * sizeof(char));
	}
	
	sprintf(p[count++],"%s",g_option.initTRMMGSPProgramPathName);
	sprintf(p[count++],"%s",g_option.datetimeString);

	sprintf(p[count++],"%s",g_option.programRootPath);

	p[count] = 0;

	if (count > parameterCount)
	{
		fprintf(stderr,"!!!!!!!!!! run_composition_radar_program error \n");
		
		// if error
		LogWriteError("COM_RAR", "runAWSTRMMGSPInit", "Error runAWSTRMMGSPInit argv[]");
		// log : process1 : fail
		LogWriteStatusFail("COM_RAR", "runAWSTRMMGSPInit");
		exit(1);
	}
		
	pid = fork();
	if (pid < 0) //fork error
	{
		return -52023;
	}
	if (pid == 0)//CHILD
	{
		result = execv(g_option.initTRMMGSPProgramPathName,p);
		return -52024;
	}
	else //parent
	{
		int statVal;

		waitpid(pid,&statVal,0);

		if(WIFEXITED(statVal)){
			switch WEXITSTATUS(statVal) {
				case 0 : ERROR_CODE = 1; break;
				default : ERROR_CODE = -9990; break;
			}
		}
		else if (WIFSIGNALED(statVal))
		{
			ERROR_CODE = -99999;
		}
		if (ERROR_CODE == 1)//���������̸�
		{
			//����.
		}
		//�޸� ����
		for (i = 0; i < parameterCount ; i++){
			free(p[i]);
		}
		free(p);
		return ERROR_CODE;
	}
}

/**
* @brief TRMM-GSP ���α׷� ������ ���� �Լ�
* @return ERROR_CODE ����: ����
* @author �豤ȣ
*/
int runAWSTRMMGSP()
{
	int result;
	int pid;
	int i;
	int count = 0;
	int parameterCount;
	char **p;
	int ERROR_CODE = -1;
	
	parameterCount = 5;//program name, yyyymmddhhnn, yyyymmddhhnn, programRootPath, NULL
	p = malloc(parameterCount * sizeof(char *));
	for (i = 0; i < parameterCount ; i++)
	{
		p[i] = malloc(MAX_STRING_LENGTH * sizeof(char));
	}
	
	sprintf(p[count++],"%s",g_option.mainTRMMGSPProgramPathName);
	sprintf(p[count++],"%s",g_option.datetimeString);
	sprintf(p[count++],"%s",g_option.datetimeString);

	sprintf(p[count++],"%s",g_option.programRootPath);

	p[count] = 0;

	if (count > parameterCount)
	{
		fprintf(stderr,"!!!!!!!!!! run_composition_radar_program error \n");
		
		// if error
		LogWriteError("COM_RAR", "runAWSTRMMGSP", "Error runAWSTRMMGSP argv[]");
		// log : process1 : fail
		LogWriteStatusFail("COM_RAR", "runAWSTRMMGSP");
		exit(1);
	}
	
	pid = fork();
	if (pid < 0) //fork error
	{
		return -52023;
	}
	if (pid == 0)//CHILD
	{
		result = execv(g_option.mainTRMMGSPProgramPathName,p);
		return -52024;
	}
	else //parent
	{
		int statVal;
		//�ǽð��϶��� ��ٸ��� �ʰ�, �����ڷ� ó���϶��� ��ٸ�
			
		waitpid(pid,&statVal,0);
		if(WIFEXITED(statVal))
		{
			switch WEXITSTATUS(statVal) 
			{
				case 0 : ERROR_CODE = 1; break;
				default : ERROR_CODE = -9990; break;
			}
		}
		else if (WIFSIGNALED(statVal))
		{
			ERROR_CODE = -99999;
		}
		if (ERROR_CODE == 1)//���������̸�
		{
			//����.
		}
		//�޸� ����
		for (i = 0; i < parameterCount ; i++)
		{
			free(p[i]);
		}
		free(p);
		return ERROR_CODE;
	}
}




