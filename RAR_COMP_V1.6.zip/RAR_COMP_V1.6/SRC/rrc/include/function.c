/**
 * @file function.c
 * @brief �ǽð� ������ ���� ȯ�ἳ���� �д� �Լ�.
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <dirent.h>

#include "rrc.h"
#include "function.h"
#include "log.h"
#include "network.h"


static char* TransmissionTime[]={"after_start","uf_down_done","site_done","comp_done","rar_done","digi_done","before_finish"};
static int generateAWSName(struct tm datetime);
#define ARGV0_NULL_COUNT 3	//���α׷� �����Ҷ� �߰��Ǵ� argv�� ��(argv[0],datestring,argv[last])

/**
 * @brief ȯ�漳������(setup.ini)�� ������ �б� ���� �Լ�.
 * @return  ������ 1: ����, 1�̿��� ����: ����
 * @author �豤ȣ
 */
int readSetup()
{
	int ERROR_CODE;
	int i;
	char tempString[MAX_STRING_LENGTH];
	
	
	//ȯ�� ���� COMP_RADAR_ROOT_PATH �б�
	g_option.programRootPath = getenv("COMP_RADAR_ROOT_PATH");
	if (g_option.programRootPath == NULL)
		return -51001;

	sprintf(g_option.iniSetupFileName,"%sRES/%s",g_option.programRootPath,SETUP_INI_FILENAME);

	sprintf(g_option.iniSitesFileName,"%sRES/%s",g_option.programRootPath,SITES_INI_FILENAME);

	sprintf(g_option.iniDisplayServerFileName,"%sRES/%s",g_option.programRootPath,SERVER_INI_FILENAME);

	sprintf(g_option.radarQPEProgramPathName,"%s%s%s",g_option.programRootPath,"BIN/",RAR_PROGRAM_NAME);

	sprintf(g_option.RARVerifyProgramPathName,"%s%s%s",g_option.programRootPath,"BIN/",RAR_VERIFY_PROGRAM_NAME);

	sprintf(g_option.RARSiteVerifyProgramPathName,"%s%s%s",g_option.programRootPath,"BIN/",RAR_SITE_VERIFY_PROGRAM_NAME);

	sprintf(g_option.RARSiteProgramPathName,"%s%s%s",g_option.programRootPath,"BIN/",RAR_SITE_PROGRAM_NAME);

	//setup.ini ȯ�漳�� ����
	if ((ERROR_CODE = createIniFile(g_option.iniSetupFileName)) < 0)
		return ERROR_CODE;

	//[RAR]
	g_option.routeCs = readIniString("RAR","CompositionType",NULL);
	printf("g_option.routeCs: %s", g_option.routeCs);
	g_option.routeDs = readIniString("RAR","ProductType",NULL);
	g_option.routeEs = readIniString("RAR","Fix",NULL);
	g_option.routeCompCount = strlen(g_option.routeCs) * strlen(g_option.routeDs) * strlen(g_option.routeEs);
	g_option.routeSiteCount = strlen(g_option.routeDs) * strlen(g_option.routeEs);
	
	g_option.routeCC = malloc(strlen(g_option.routeCs) * sizeof(DIS_CHAR));
	g_option.routeDD = malloc(strlen(g_option.routeDs) * sizeof(DIS_CHAR));
	g_option.routeEE = malloc(strlen(g_option.routeEs) * sizeof(DIS_CHAR));
	g_option.routeEss = malloc(strlen(g_option.routeEs) * sizeof(DIS_CHAR));
	
	for (i = 0 ; i < strlen(g_option.routeCs) ; i++)
	{
		sprintf(tempString,"%c",g_option.routeCs[i]);
		if (strstr(tempString, "m") != NULL)
			g_option.routeCC[i].name = "M";
		if (strstr(tempString, "a") != NULL)
			g_option.routeCC[i].name = "A";
		if (strstr(tempString, "n") != NULL)
			g_option.routeCC[i].name = "N";
		if (strstr(tempString, "w") != NULL)
			g_option.routeCC[i].name = "W";
	}
	
	for (i = 0 ; i < strlen(g_option.routeDs) ; i++)
	{
		sprintf(tempString,"%c",g_option.routeDs[i]);
		if (strstr(tempString, "p") != NULL)
			g_option.routeDD[i].name = "PP";
		if (strstr(tempString, "c") != NULL)
			g_option.routeDD[i].name = "CP";
		if (strstr(tempString, "b") != NULL)
			g_option.routeDD[i].name = "BA";
	}
	
	for (i = 0 ; i < strlen(g_option.routeEs) ; i++)
	{
		sprintf(tempString,"%c",g_option.routeEs[i]);
		if (strstr(tempString, "a") != NULL)
			g_option.routeEE[i].name = "A";
		if (strstr(tempString, "p") != NULL)
			g_option.routeEE[i].name = "P";
		if (strstr(tempString, "m") != NULL)
			g_option.routeEE[i].name = "M";
	}
	
	for (i = 0 ; i < strlen(g_option.routeEs) ; i++)
	{
		sprintf(tempString,"%c",g_option.routeEs[i]);
		if (strstr(tempString, "a") != NULL)
			g_option.routeEss[i].name = "0";
		if (strstr(tempString, "p") != NULL)
			g_option.routeEss[i].name = "2";
		if (strstr(tempString, "m") != NULL)
			g_option.routeEss[i].name = "3";
	}
			
	//[DIRECTORY]
	g_option.radarFileBasePath = readIniString("DIRECTORY","RadarFile",NULL);

	//[AWS_TRANSMISSION]
	g_option.AWSIP = readIniString("AWS_TRANSMISSION","ServerAddr",NULL);
	g_option.AWSID = readIniString("AWS_TRANSMISSION","ServerID",NULL);
	g_option.AWSPW = readIniString("AWS_TRANSMISSION","ServerPW",NULL);
	g_option.AWSServerPath = readIniString("AWS_TRANSMISSION","ServerPath",NULL);
	g_option.AWSFileHeader = readIniString("AWS_TRANSMISSION","ServerFileHeader",NULL);
	sprintf(g_option.AWSLocalPath,"%s%s",g_option.programRootPath,readIniString("AWS_TRANSMISSION","LocalPath",NULL));

	//[AWS_QC]
	g_option.AWSQCProgramPathName = readIniString("AWS_QC","QCAWSProgramPathName",NULL);
	g_option.AWSQCIniProgramPathName = readIniString("AWS_QC","QCAWSIniProgramPathName",NULL);
	
	//[AWS_TRMM_GSP]
	sprintf(g_option.AWSTRMMGSPPath,"%s%s",g_option.programRootPath,readIniString("AWS_TRMM_GSP","LocalPath",NULL));
	g_option.initTRMMGSPProgramPathName = readIniString("AWS_TRMM_GSP","InitProgramPathName",NULL);
	g_option.mainTRMMGSPProgramPathName = readIniString("AWS_TRMM_GSP","MainProgramPathName",NULL);

	//���� �̸� ����
	destroyIniFile();

	//sites.iniȯ�漳�� ����
	if ((ERROR_CODE = createIniFile(g_option.iniSitesFileName)) < 0)
		return ERROR_CODE;

	g_option.siteCount = readIniInt("SITE","count",0);

	//���� �̸� ����
	destroyIniFile();

	return 1;
}

/**
 * @brief ���α׷� ���� �ð��� ���̴� ���� �ð��� ����ȭ �ϴ� �Լ�.
 * @param datetime ���� �ð�
 * @return  ������ 1: ����, 1�̿��� ����: ����
 * @author �豤ȣ
 */
struct tm initTime(struct tm datetime)
{
	int targetMin;
	struct tm newDatetime;

	if (datetime.tm_min >= 5 && datetime.tm_min < 15){
		targetMin = 0;
	}else if (datetime.tm_min >= 15 && datetime.tm_min < 25){
		targetMin = 10;
	}else if (datetime.tm_min >= 25 && datetime.tm_min < 35){
		targetMin = 20;
	}else if (datetime.tm_min >= 35 && datetime.tm_min < 45){
		targetMin = 30;
	}else if (datetime.tm_min >= 45 && datetime.tm_min < 55){
		targetMin = 40;
	}else if (datetime.tm_min >= 55 || datetime.tm_min < 5){
		targetMin = 50;
	}else {
		targetMin = -1;
	}

	newDatetime = datetime;
	newDatetime = incMin(newDatetime,-1);
	while(targetMin != newDatetime.tm_min)
	{
		newDatetime = incMin(newDatetime,-1);
	}

	return newDatetime;
};

/**
 * @brief ȯ�漳������(sites.ini)�� ������ �б� ���� �Լ�.
 * @return  ������ 1: ����, 1�̿��� ����: ����
 * @author �豤ȣ
 */
int readSitesIni(int siteIndex)
{
	int ERROR_CODE;
	char titleHeader[MAX_STRING_LENGTH];
	char title[MAX_STRING_LENGTH];
	char* ptempString;

	//ȯ�漳�� ���� �̸� �ʱ�ȭ
	if ((ERROR_CODE = createIniFile(g_option.iniSitesFileName)) < 0)
		return ERROR_CODE;

	//[SITE]���� site�̸� ����
	sprintf(title,"site%d",siteIndex+1);
	g_site[siteIndex].name = readIniString("SITE",title,NULL);
		if (g_site[siteIndex].name == NULL) goto READ_SITES_INI_ERROR;

	//[site name]���� ����
	switch (g_option.timeType)
	{
		case REALTIME:	sprintf(titleHeader,"RealTimeServer"); break;
		case PASTTIME:	sprintf(titleHeader,"PastTimeServer"); break;
		default : return -9999;
	}

	
	if (g_option.timeType == REALTIME)
	{
		sprintf(title,"%s_Use",titleHeader);
		g_site[siteIndex].ftpUse = readIniInt(g_site[siteIndex].name,title,1);
	}
	else
	{
		g_site[siteIndex].ftpUse = 1;
	}

	sprintf(title,"%s_Addr",titleHeader);
	g_site[siteIndex].ip = readIniString(g_site[siteIndex].name,title,NULL);
		if (g_site[siteIndex].ip == NULL) goto READ_SITES_INI_ERROR;

	sprintf(title,"%s_ID",titleHeader);
	g_site[siteIndex].id = readIniString(g_site[siteIndex].name,title,NULL);
		if (g_site[siteIndex].id == NULL) goto READ_SITES_INI_ERROR;

	sprintf(title,"%s_PW",titleHeader);
	g_site[siteIndex].pw = readIniString(g_site[siteIndex].name,title,NULL);
		if (g_site[siteIndex].pw == NULL) goto READ_SITES_INI_ERROR;

	sprintf(title,"%s_Path",titleHeader);
	g_site[siteIndex].serverUFPathRule = readIniString(g_site[siteIndex].name,title,NULL);
		if (g_site[siteIndex].serverUFPathRule == NULL) goto READ_SITES_INI_ERROR;

	sprintf(title,"%s_Filename",titleHeader);
	g_site[siteIndex].serverUFFileNameRule = readIniString(g_site[siteIndex].name,title,NULL);
		if (g_site[siteIndex].serverUFFileNameRule == NULL) goto READ_SITES_INI_ERROR;

	ptempString = readIniString(g_site[siteIndex].name,"LocalRadarFileNameHead",NULL);
	if (ptempString == NULL) return -9999;
	sprintf(g_site[siteIndex].radarFileHeadRule,"%s",ptempString);

	g_site[siteIndex].obsTimeType = readIniInt(g_site[siteIndex].name,"Time",10);

	g_site[siteIndex].useComp = readIniInt(g_site[siteIndex].name,"UseComp",0);
	g_site[siteIndex].useSite = readIniInt(g_site[siteIndex].name,"UseSite",0);
	g_site[siteIndex].useRAR = readIniInt(g_site[siteIndex].name,"UseRar",0);
	g_site[siteIndex].timeRevision = readIniInt(g_site[siteIndex].name,"TimeRevision",0);

	//ȯ�漳�� ���� �̸� ����
	destroyIniFile();

	return 1;

READ_SITES_INI_ERROR:
	{
		g_site[siteIndex].useComp = 0;
		g_site[siteIndex].useSite = 0;
		g_site[siteIndex].useRAR = 0;
		return -9999;
 	}
};

/**
 * @brief �� ����Ʈ�� ȯ�漳�������� �ʱ�ȭ �� ����Ʈ�� ���� ������ ����.
 * @param siteIndex ����Ʈ �ε���
 * @return  ������ 1: ����, 1�̿��� ����: ����
 * @author �豤ȣ
 */
int initSite(int siteIndex)
{
	int ERROR_CODE;

	if ((ERROR_CODE=readSitesIni(siteIndex)) < 0)
	{
		return ERROR_CODE;
	}

	sprintf(g_site[siteIndex].localUFFilePath,"%s%s",g_option.programRootPath,g_option.radarFileBasePath);
	g_site[siteIndex].localUFFileName[0] = '\0';
	g_site[siteIndex].localUFPathFileName[0] = '\0';

	g_site[siteIndex].done = NONE;

	//ȯ�漳�� ���� �̸� ����
	destroyIniFile();

	return 1;
}

/**
 * @brief UF ���� �̸� ���� �Լ�.
 * @param datetime ���� �ð�
 * @param siteIndex ����Ʈ �ε���
 * @return  ������ 1: ����, 1�̿��� ����: ����
 * @author �豤ȣ
 */
int generateRadarFileName(struct tm datetime,int siteIndex)
{
	char pathname[MAX_STRING_LENGTH];
	char filename[MAX_STRING_LENGTH];
	int nPos;
	int min;
	char minStr[MAX_STRING_LENGTH];
	char tempStr[MAX_STRING_LENGTH];
	struct tm imsiTime;

	imsiTime = incMin(datetime,g_site[siteIndex].timeRevision);
	//10���̸� �д��� ���ڸ��� ?�� �ٲ۴�.
	if (g_site[siteIndex].obsTimeType == SITE_OBS_MIN_10)
	{
		strftime(filename,sizeof(filename),g_site[siteIndex].serverUFFileNameRule,&imsiTime);	//�����̸� ����
		strftime(pathname,sizeof(pathname),g_site[siteIndex].serverUFPathRule,&imsiTime);		//��� ����
	}
	//6���̸� �д��� ���ڸ��� ?�� �ٲ۴�.
	else if (g_site[siteIndex].obsTimeType == SITE_OBS_MIN_06)
	{
		//�����̸� ����(N?�� ����)
		nPos = pos("%N",g_site[siteIndex].serverUFFileNameRule);
		if (nPos > 0)
		{
			min = imsiTime.tm_min;
			sprintf(minStr,"%02d",min);
			g_site[siteIndex].serverUFFileNameRule[nPos] = minStr[0];
			g_site[siteIndex].serverUFFileNameRule[nPos+1] = '?';
			strftime(filename,sizeof(filename),g_site[siteIndex].serverUFFileNameRule,&imsiTime);
		}
		else
		{
			strftime(filename,sizeof(filename),g_site[siteIndex].serverUFFileNameRule,&imsiTime);
		}
		//��� ����(N?�� ����)
		sprintf(tempStr,"%s",g_site[siteIndex].serverUFPathRule);
		nPos = pos("%N",tempStr);
		if (nPos > 0)
		{
			tempStr[nPos+1] = 'M';
		}
		strftime(pathname,sizeof(pathname),tempStr,&imsiTime);		//��� ����

	}else
		return -51004;

	sprintf(g_site[siteIndex].radarFileNameIncompletion,"%s",filename);
	sprintf(g_site[siteIndex].serverPath,"%s",pathname);
	sprintf(g_site[siteIndex].serverFileName,"%s%s",g_site[siteIndex].serverPath,filename);

	//�̸� ������ ���� uf format ���� �̸� ����
	strftime(tempStr,sizeof(tempStr),g_site[siteIndex].radarFileHeadRule,&imsiTime);	//�����̸� ����
	sprintf(g_site[siteIndex].newUFFormatFileName,"%s.uf",tempStr);
	sprintf(g_site[siteIndex].newUFFormatFilePathName,"%s%s.uf",g_site[siteIndex].localUFFilePath,tempStr);
	
	return 1;
}

/**
 * @brief ǥ�� ���� �������� �б�(server.ini) �Լ�.
 * @return  ������ 1: ����
 * @author �豤ȣ
 */
int readDisplayServerIni()
{
	int i;
	int j;
	int k;
	int kk;
	int ERROR_CODE;
	char section[MAX_STRING_LENGTH];
	char* prunTimeString;
	char* ptransmissionTimeString;

	char siteMessage[MAX_STRING_LENGTH];

	int count;

	count=0;

	//ȯ�漳�� ���� �̸� �ʱ�ȭ
	if ((ERROR_CODE = createIniFile(g_option.iniDisplayServerFileName)) < 0)
		return ERROR_CODE;

	g_option.AWSServerCount = readIniInt("SERVER","AWSCount",0);

	g_AWSServer = malloc(g_option.AWSServerCount * sizeof(DISPLAY_SERVER));

	for (i = 0; i < g_option.AWSServerCount ; i++)
	{
		sprintf(section,"AWS%d",i+1);
		g_AWSServer[i].name = readIniString(section,"Name",NULL);
			if (g_AWSServer[i].name == NULL) goto READ_AWS_DISPLAY_SERVER_ERROR;
		g_AWSServer[i].ip = readIniString(section,"ServerAddr",NULL);
			if (g_AWSServer[i].ip == NULL) goto READ_AWS_DISPLAY_SERVER_ERROR;
		g_AWSServer[i].id = readIniString(section,"ServerID",NULL);
			if (g_AWSServer[i].id == NULL) goto READ_AWS_DISPLAY_SERVER_ERROR;
		g_AWSServer[i].pw = readIniString(section,"ServerPW",NULL);
			if (g_AWSServer[i].pw == NULL) goto READ_AWS_DISPLAY_SERVER_ERROR;
		g_AWSServer[i].remotePathFileNameIncompletion = readIniString(section,"ServerPathFileName",NULL);
			if (g_AWSServer[i].remotePathFileNameIncompletion == NULL) goto READ_AWS_DISPLAY_SERVER_ERROR;
		g_AWSServer[i].localPathFileNameIncompletion = readIniString(section,"LocalPathFileName",NULL);
			if (g_AWSServer[i].localPathFileNameIncompletion == NULL) goto READ_AWS_DISPLAY_SERVER_ERROR;

		g_AWSServer[i].rename = readIniInt(section,"Rename",1);

		ptransmissionTimeString = readIniString(section,"TransmissionTime","before_finish");
		for (j = 0 ; j < TRANS_RUN_TIME_COUNT ; j++ )
		{
			if (strncmp(ptransmissionTimeString,TransmissionTime[j],strlen(TransmissionTime[j])) == 0)
			{
				g_AWSServer[i].transRunTime = j;
				break;
			}
		}
		g_AWSServer[i].fileTimeRevision = readIniInt(section,"FileTimeRevision",0);
		g_AWSServer[i].use = readIniInt(section,"Use",0);
		g_AWSServer[i].dellocalfile = readIniInt(section,"DelAfterTransmission",0);
		g_AWSServer[i].transmissionOnlyRealTime = readIniInt(section,"TransmissionOnlyRealTimeProcess",0);

		g_AWSServer[i].transSuccess = 0;

		continue;
		READ_AWS_DISPLAY_SERVER_ERROR:
		{
			g_AWSServer[i].use = 0;
			fprintf(stderr,"Error read_aws_server_ini %s)\n",section);
		}
	}

	g_option.displayServerCount = readIniInt("SERVER","CompCount",0);
	
	g_displayServer = malloc(g_option.displayServerCount * g_option.routeCompCount * sizeof(DISPLAY_SERVER));

	count=0;
	//�ռ�
	for (i = 0; i < g_option.displayServerCount ; i++)
	{
		for (j = 0; j < g_option.routeCompCount ; j++)
		{
			sprintf(section,"Comp%d",i+1);
			g_displayServer[count].name = readIniString(section,"Name",NULL);
				if (g_displayServer[count].name == NULL) goto READ_COMP_DISPLAY_SERVER_ERROR;
			g_displayServer[count].ip = readIniString(section,"ServerAddr",NULL);
				if (g_displayServer[count].ip == NULL) goto READ_COMP_DISPLAY_SERVER_ERROR;
			g_displayServer[count].id = readIniString(section,"ServerID",NULL);
				if (g_displayServer[count].id == NULL) goto READ_COMP_DISPLAY_SERVER_ERROR;
			g_displayServer[count].pw = readIniString(section,"ServerPW",NULL);
				if (g_displayServer[count].pw == NULL) goto READ_COMP_DISPLAY_SERVER_ERROR;
			g_displayServer[count].remotePathFileNameIncompletion = readIniString(section,"ServerPathFileName",NULL);
				if (g_displayServer[count].remotePathFileNameIncompletion == NULL) goto READ_COMP_DISPLAY_SERVER_ERROR;
			g_displayServer[count].localPathFileNameIncompletion = readIniString(section,"LocalPathFileName",NULL);
				if (g_displayServer[count].localPathFileNameIncompletion == NULL) goto READ_COMP_DISPLAY_SERVER_ERROR;
        	
			g_displayServer[count].rename = readIniInt(section,"Rename",1);
        	
			ptransmissionTimeString = readIniString(section,"TransmissionTime","before_finish");
			for (k = 0 ; k < TRANS_RUN_TIME_COUNT ; k++ )
			{
				if (strncmp(ptransmissionTimeString,TransmissionTime[k],strlen(TransmissionTime[k])) == 0)
				{
					g_displayServer[count].transRunTime = k;
					break;
				}
			}
			
			g_displayServer[count].fileTimeRevision = readIniInt(section,"FileTimeRevision",0);
			g_displayServer[count].use = readIniInt(section,"Use",0);
			g_displayServer[count].dellocalfile = readIniInt(section,"DelAfterTransmission",0);
			g_displayServer[count].transmissionOnlyRealTime = readIniInt(section,"TransmissionOnlyRealTimeProcess",0);
			prunTimeString = readIniString(section,"RunMinutes","00,10,20,30,40,50");
			if (strstr(prunTimeString,"00") != NULL) g_displayServer[count].transMinutes[0] = 1; else g_displayServer[count].transMinutes[0] = 0;
			if (strstr(prunTimeString,"10") != NULL) g_displayServer[count].transMinutes[1] = 1; else g_displayServer[count].transMinutes[1] = 0;
			if (strstr(prunTimeString,"20") != NULL) g_displayServer[count].transMinutes[2] = 1; else g_displayServer[count].transMinutes[2] = 0;
			if (strstr(prunTimeString,"30") != NULL) g_displayServer[count].transMinutes[3] = 1; else g_displayServer[count].transMinutes[3] = 0;
			if (strstr(prunTimeString,"40") != NULL) g_displayServer[count].transMinutes[4] = 1; else g_displayServer[count].transMinutes[4] = 0;
			if (strstr(prunTimeString,"50") != NULL) g_displayServer[count].transMinutes[5] = 1; else g_displayServer[count].transMinutes[5] = 0;
			free(prunTimeString);
        	
			g_displayServer[count].transSuccess = 0;
        	
        	count++;
			continue;
			READ_COMP_DISPLAY_SERVER_ERROR:
			{
				g_displayServer[count].use = 0;
				fprintf(stderr,"Error readDisplayServerIni %s)\n",section);
				
				sprintf(siteMessage,"Error display_server_ini (section: %s)", section);
				// if error
				LogWriteError("COM_RAR", "readDisplayServerIni", siteMessage);
				
				count++;
			}
			
		}
	}

	//����Ʈ
	for (j = 0 ; j < g_option.siteCount ; j++)
	{
		g_site[j].serverCount = readIniInt("SERVER","SiteCount",0);

		g_site[j].siteServer = malloc(g_site[j].serverCount * g_option.routeSiteCount * sizeof(DISPLAY_SERVER));
		g_site[j].transSuccess = malloc(g_site[j].serverCount * g_option.routeSiteCount * sizeof(int));
		
		count=0;
		for (i = 0; i < g_site[j].serverCount ; i++)
		{
			for (k = 0; k < g_option.routeSiteCount ; k++)
			{
				sprintf(section,"Site%d",i+1);
				g_site[j].siteServer[count].name = readIniString(section,"Name",NULL);
					if (g_site[j].siteServer[count].name == NULL) goto READ_SITE_DISPLAY_SERVER_ERROR;
				g_site[j].siteServer[count].ip = readIniString(section,"ServerAddr",NULL);
					if (g_site[j].siteServer[count].ip == NULL) goto READ_SITE_DISPLAY_SERVER_ERROR;
				g_site[j].siteServer[count].id = readIniString(section,"ServerID",NULL);
					if (g_site[j].siteServer[count].id == NULL) goto READ_SITE_DISPLAY_SERVER_ERROR;
				g_site[j].siteServer[count].pw = readIniString(section,"ServerPW",NULL);
					if (g_site[j].siteServer[count].pw == NULL) goto READ_SITE_DISPLAY_SERVER_ERROR;
				g_site[j].siteServer[count].remotePathFileNameIncompletion = readIniString(section,"ServerPathFileName",NULL);
					if (g_site[j].siteServer[count].remotePathFileNameIncompletion == NULL) goto READ_SITE_DISPLAY_SERVER_ERROR;
				g_site[j].siteServer[count].localPathFileNameIncompletion = readIniString(section,"LocalPathFileName",NULL);
					if (g_site[j].siteServer[count].localPathFileNameIncompletion == NULL) goto READ_SITE_DISPLAY_SERVER_ERROR;
            	
				g_site[j].siteServer[count].rename = readIniInt(section,"Rename",1);
            	
				ptransmissionTimeString = readIniString(section,"TransmissionTime","before_finish");
				for (kk = 0 ; kk < TRANS_RUN_TIME_COUNT ; kk++ )
				{
					if (strncmp(ptransmissionTimeString,TransmissionTime[kk],strlen(TransmissionTime[kk])) == 0)
					{
						g_site[j].siteServer[count].transRunTime = kk;
						break;
					}
				}
				g_site[j].siteServer[count].fileTimeRevision = readIniInt(section,"FileTimeRevision",0);
				g_site[j].siteServer[count].use = readIniInt(section,"Use",0);
				g_site[j].siteServer[count].dellocalfile = readIniInt(section,"DelAfterTransmission",0);
				g_site[j].siteServer[count].transmissionOnlyRealTime = readIniInt(section,"TransmissionOnlyRealTimeProcess",0);
				prunTimeString = readIniString(section,"RunMinutes","00,10,20,30,40,50");
				//option1 : ���ۿ� ����� ����Ʈ �̸�
				g_site[j].siteServer[count].option1 = readIniString(section,"Option1",NULL);
            	
				if (strstr(prunTimeString,"00") != NULL) g_site[j].siteServer[count].transMinutes[0] = 1; else g_site[j].siteServer[count].transMinutes[0] = 0; 
				if (strstr(prunTimeString,"10") != NULL) g_site[j].siteServer[count].transMinutes[1] = 1; else g_site[j].siteServer[count].transMinutes[1] = 0; 
				if (strstr(prunTimeString,"20") != NULL) g_site[j].siteServer[count].transMinutes[2] = 1; else g_site[j].siteServer[count].transMinutes[2] = 0; 
				if (strstr(prunTimeString,"30") != NULL) g_site[j].siteServer[count].transMinutes[3] = 1; else g_site[j].siteServer[count].transMinutes[3] = 0; 
				if (strstr(prunTimeString,"40") != NULL) g_site[j].siteServer[count].transMinutes[4] = 1; else g_site[j].siteServer[count].transMinutes[4] = 0; 
				if (strstr(prunTimeString,"50") != NULL) g_site[j].siteServer[count].transMinutes[5] = 1; else g_site[j].siteServer[count].transMinutes[5] = 0; 
				free(prunTimeString);
            	
				g_site[j].transSuccess[count] = 0;

				count++;
							
				continue;
				READ_SITE_DISPLAY_SERVER_ERROR:
				{
					g_site[j].siteServer[count].use = 0;
					fprintf(stderr,"Error read_g_site[j].siteServer_ini %s)\n",section);
					
					sprintf(siteMessage,"Error site_server_ini (site: %s, section: %s)",g_site[j].name, section);
					// if error
					LogWriteError("COM_RAR", "readDisplayServerIni", siteMessage);
					
					count++;
				}
			}
		}
	}

	//ȯ�漳�� ���� �̸� ����
	destroyIniFile();

	return 1;

};

/**
 * @brief ǥ�� ������ ��� �̸��� ���� �ð� ������ ���� �����ϴ� �Լ�.
 * @return  ������ 1: ����
 * @author �豤ȣ
 */
int generateServerPathname(struct tm datetime)
{
	int i;
	int j;
	int k;
	int m;
	int ii;
	int jj;
	int kk;
	struct tm imsiTime;
	char tempString[MAX_STRING_LENGTH];
	char tempString2[MAX_STRING_LENGTH];
	char tempString3[MAX_STRING_LENGTH];
	char tempString4[MAX_STRING_LENGTH];
	int count;
	int countt;

	//AWS
	for (i = 0; i < g_option.AWSServerCount ; i++ )
	{
		if (pos("%",g_AWSServer[i].remotePathFileNameIncompletion) > 0)//����Ͻð� ��ȯ�Ǵ� �����̸�
		{
			imsiTime = incMin(datetime,g_AWSServer[i].fileTimeRevision);
			strftime(g_AWSServer[i].remotePathFileName,MAX_STRING_LENGTH,g_AWSServer[i].remotePathFileNameIncompletion,&imsiTime);
		}
		else
		{
			sprintf(g_AWSServer[i].remotePathFileName,"%s",g_AWSServer[i].remotePathFileNameIncompletion);
		}
	}


	//�ռ�
	countt=0;
	for (i = 0; i < g_option.displayServerCount ; i++ )
	{
		if (pos("%",g_displayServer[countt].remotePathFileNameIncompletion) > 0)//����Ͻð� ��ȯ�Ǵ� �����̸�
		{
			imsiTime = incMin(datetime,g_displayServer[countt].fileTimeRevision);
			strftime(tempString,MAX_STRING_LENGTH,g_displayServer[countt].remotePathFileNameIncompletion,&imsiTime);
		}
		else
		{
			sprintf(tempString,"%s",g_displayServer[countt].remotePathFileNameIncompletion);
		}
		
		//KKH ############################################
		for (kk = 0 ; kk < strlen(g_option.routeCs) ; kk++ )
		{
			if (pos("[C]",tempString) >= 0) 
			{
				count = 0;
				for (k = 0 ; k < strlen(tempString) ; k++ )
				{
					if (tempString[k] == '[' && tempString[k+1] == 'C' && tempString[k+2] == ']')
					{
						for (m = 0 ; m < strlen(g_option.routeCC[kk].name) ; m++ )
						{
							tempString2[count++] = toBigLetter(g_option.routeCC[kk].name[m]);
						}
						k += 2;
					}
					else
					{
						tempString2[count++] = tempString[k];
					}
				}
				tempString2[count] = '\0';
			}
			else
			{
				sprintf(tempString2,"%s",tempString);
			}
			
			for (ii = 0 ; ii < strlen(g_option.routeDs) ; ii++ )
			{			
				if (pos("[D]",tempString2) >= 0) 
				{
					count = 0;
					for (k = 0 ; k < strlen(tempString2) ; k++ )
					{
						if (tempString2[k] == '[' && tempString2[k+1] == 'D' && tempString2[k+2] == ']')
						{
							for (m = 0 ; m < strlen(g_option.routeDD[ii].name) ; m++ )
							{
								tempString3[count++] = toBigLetter(g_option.routeDD[ii].name[m]);
							}
							k += 2;
						}
						else
						{
							tempString3[count++] = tempString2[k];
						}
					}
					tempString3[count] = '\0';
				}
				else
				{
					sprintf(tempString3,"%s",tempString2);
				}
				
				for (jj = 0 ; jj < strlen(g_option.routeEs) ; jj++ )
				{
					if (pos("[E]",tempString3) >= 0) 
					{
						count = 0;
						for (k = 0 ; k < strlen(tempString3) ; k++ )
						{
							if (tempString3[k] == '[' && tempString3[k+1] == 'E' && tempString3[k+2] == ']')
							{
								for (m = 0 ; m < strlen(g_option.routeEE[jj].name) ; m++ )
								{
									tempString4[count++] = toBigLetter(g_option.routeEE[jj].name[m]);
								}
								k += 2;
							}
							else
							{
								tempString4[count++] = tempString3[k];
							}
						}
						tempString4[count] = '\0';
					}
					else
					{
						sprintf(tempString4,"%s",tempString3);
					}
					sprintf(g_displayServer[countt].remotePathFileName,"%s",tempString4);
					countt++;
				}
				//KKH ############################################
			}
		}
	}
	
	//����Ʈ
	
	for (j = 0 ; j < g_option.siteCount ; j++ )
	{
		countt=0;
		for (i = 0; i < g_site[j].serverCount ; i++ )
		{
			if (pos("%",g_site[j].siteServer[countt].remotePathFileNameIncompletion) > 0)//����Ͻð� ��ȯ�Ǵ� �����̸�
			{
				imsiTime = incMin(datetime,g_site[j].siteServer[countt].fileTimeRevision);
				strftime(tempString,MAX_STRING_LENGTH,g_site[j].siteServer[countt].remotePathFileNameIncompletion,&imsiTime);
			}
			else
			{
				sprintf(tempString,"%s",g_site[j].siteServer[countt].remotePathFileNameIncompletion);
			}
			
			if (pos("[S]",tempString) >= 0)
			{
				count = 0;
				for (k = 0 ; k < strlen(tempString) ; k++ )
				{
					if (tempString[k] == '[' && tempString[k+1] == 'S' && tempString[k+2] == ']')
					{
						for (m = 0 ; m < strlen(g_site[j].name) ; m++ )
						{
							tempString2[count++] = toBigLetter(g_site[j].name[m]);
						}
						k += 2;
					}
					else
					{
						tempString2[count++] = tempString[k];
					}
				}
				tempString2[count] = '\0';
			}
			else
			{
				sprintf(tempString2,"%s",tempString);
			}

			//KKH ############################################
			for (ii = 0 ; ii < strlen(g_option.routeDs) ; ii++ )
			{			
				if (pos("[D]",tempString2) >= 0) 
				{
					count = 0;
					for (k = 0 ; k < strlen(tempString2) ; k++ )
					{
						if (tempString2[k] == '[' && tempString2[k+1] == 'D' && tempString2[k+2] == ']')
						{
							for (m = 0 ; m < strlen(g_option.routeDD[ii].name) ; m++ )
							{
								tempString3[count++] = toBigLetter(g_option.routeDD[ii].name[m]);
							}
							k += 2;
						}
						else
						{
							tempString3[count++] = tempString2[k];
						}
					}
					tempString3[count] = '\0';
				}
				else
				{
					sprintf(tempString3,"%s",tempString2);
				}
				
				for (jj = 0 ; jj < strlen(g_option.routeEs) ; jj++ )
				{
					if (pos("[E]",tempString3) >= 0) 
					{
						count = 0;
						for (k = 0 ; k < strlen(tempString3) ; k++ )
						{
							if (tempString3[k] == '[' && tempString3[k+1] == 'E' && tempString3[k+2] == ']')
							{
								for (m = 0 ; m < strlen(g_option.routeEE[jj].name) ; m++ )
								{
									tempString4[count++] = toBigLetter(g_option.routeEE[jj].name[m]);
								}
								k += 2;
							}
							else
							{
								tempString4[count++] = tempString3[k];
							}
						}
						tempString4[count] = '\0';
					}
					else
					{
						sprintf(tempString4,"%s",tempString3);
					}
					sprintf(g_site[j].siteServer[countt].remotePathFileName,"%s",tempString4);
					countt++;
				}
				//KKH ############################################
			}
		}
	}

	return 1;
}

/**
 * @brief ������ �ռ��췮 ���� ���α׷��� ���� �����Ǵ� ������� ���ϸ��� ��θ� �����ϴ� �Լ�.
 * @return  ������ 1: ����
 * @author �豤ȣ
 */
int generateResultFileName(struct tm datetime)
{
	char tempString[MAX_STRING_LENGTH];
	int i;
	int j;
	int k;
	int m;
	int ii;
	int jj;
	int kk;
	struct tm imsiTime;
	char tempString2[MAX_STRING_LENGTH];
	char tempString3[MAX_STRING_LENGTH];
	char tempString4[MAX_STRING_LENGTH];
	int count;
	int countt;

	//AWS
	for (i = 0; i < g_option.AWSServerCount ; i++ )
	{
		if (pos("%",g_AWSServer[i].localPathFileNameIncompletion) > 0)//����Ͻð� ��ȯ�Ǵ� �����̸�
		{
			imsiTime = incMin(datetime,g_AWSServer[i].fileTimeRevision);
			strftime(tempString,MAX_STRING_LENGTH,g_AWSServer[i].localPathFileNameIncompletion,&imsiTime);
		}
		else
		{
			sprintf(tempString,"%s",g_AWSServer[i].localPathFileNameIncompletion);
		}
		sprintf(g_AWSServer[i].localPathFileName,"%s%s",g_option.programRootPath,tempString);
	}


	//�ռ�
	countt=0;
	for (i = 0; i < g_option.displayServerCount ; i++ )
	{
		if (pos("%",g_displayServer[countt].localPathFileNameIncompletion) > 0)//����Ͻð� ��ȯ�Ǵ� �����̸�
		{
			imsiTime = incMin(datetime,g_displayServer[countt].fileTimeRevision);
			strftime(tempString,MAX_STRING_LENGTH,g_displayServer[countt].localPathFileNameIncompletion,&imsiTime);
		}
		else
		{
			sprintf(tempString,"%s",g_displayServer[countt].localPathFileNameIncompletion);
		}

		//KKH ############################################
		for (kk = 0 ; kk < strlen(g_option.routeCs) ; kk++ )
		{
			if (pos("[c]",tempString) >= 0) 
			{
				count = 0;
				for (k = 0 ; k < strlen(tempString) ; k++ )
				{
					if (tempString[k] == '[' && tempString[k+1] == 'c' && tempString[k+2] == ']')
					{
						tempString2[count++] = g_option.routeCs[kk];
						
						k += 2;
					}
					else
					{
						tempString2[count++] = tempString[k];
					}
				}
				tempString2[count] = '\0';
			}
			else
			{
				sprintf(tempString2,"%s",tempString);
			}
			
			for (ii = 0 ; ii < strlen(g_option.routeDs) ; ii++ )
			{			
				if (pos("[d]",tempString2) >= 0) 
				{
					count = 0;
					for (k = 0 ; k < strlen(tempString2) ; k++ )
					{
						if (tempString2[k] == '[' && tempString2[k+1] == 'd' && tempString2[k+2] == ']')
						{
							tempString3[count++] = g_option.routeDs[ii];
							k += 2;
						}
						else
						{
							tempString3[count++] = tempString2[k];
						}
					}
					tempString3[count] = '\0';
				}
				else
				{
					sprintf(tempString3,"%s",tempString2);
				}
				
				for (jj = 0 ; jj < strlen(g_option.routeEs) ; jj++ )
				{
					if (pos("[e]",tempString3) >= 0) 
					{
						count = 0;
						for (k = 0 ; k < strlen(tempString3) ; k++ )
						{
							if (tempString3[k] == '[' && tempString3[k+1] == 'e' && tempString3[k+2] == ']')
							{
								tempString4[count++] = g_option.routeEss[jj].name[0];
								k += 2;
							}
							else
							{
								tempString4[count++] = tempString3[k];
							}
						}
						tempString4[count] = '\0';
					}
					else
					{
						sprintf(tempString4,"%s",tempString3);
					}
					sprintf(g_displayServer[countt].localPathFileName,"%s%s",g_option.programRootPath,tempString4);
					countt++;
				}
				//KKH ############################################
			}
		}
	}

	//����Ʈ
	for (j = 0 ; j < g_option.siteCount ; j++ )
	{
		countt=0;
		for (i = 0; i < g_site[j].serverCount ; i++ )
		{
			if (pos("%",g_site[j].siteServer[countt].localPathFileNameIncompletion) > 0)//����Ͻð� ��ȯ�Ǵ� �����̸�
			{
				imsiTime = incMin(datetime,g_site[j].siteServer[countt].fileTimeRevision);
				strftime(tempString,MAX_STRING_LENGTH,g_site[j].siteServer[countt].localPathFileNameIncompletion,&imsiTime);
			}
			else
			{
				sprintf(tempString,"%s",g_site[j].siteServer[countt].localPathFileNameIncompletion);
			}
						
			if (pos("[S]",tempString) >= 0)
			{
				count = 0;
				for (k = 0 ; k < strlen(tempString) ; k++ )
				{
					if (tempString[k] == '[' && tempString[k+1] == 'S' && tempString[k+2] == ']')
					{
						for (m = 0 ; m < strlen(g_site[j].name) ; m++ )
						{
							tempString2[count++] = toBigLetter(g_site[j].name[m]);
						}
						k += 2;
					}
					else
					{
						tempString2[count++] = tempString[k];
					}
				}
				tempString2[count] = '\0';
			}
			else
			{
				sprintf(tempString2,"%s",tempString);
			}

			for (ii = 0 ; ii < strlen(g_option.routeDs) ; ii++ )
			{			
				if (pos("[d]",tempString2) >= 0) 
				{
					count = 0;
					for (k = 0 ; k < strlen(tempString2) ; k++ )
					{
						if (tempString2[k] == '[' && tempString2[k+1] == 'd' && tempString2[k+2] == ']')
						{
							tempString3[count++] = g_option.routeDs[ii];
							k += 2;
						}
						else
						{
							tempString3[count++] = tempString2[k];
						}
					}
					tempString3[count] = '\0';
				}
				else
				{
					sprintf(tempString3,"%s",tempString2);
				}
				
				for (jj = 0 ; jj < strlen(g_option.routeEs) ; jj++ )
				{
					if (pos("[e]",tempString3) >= 0) 
					{
						count = 0;
						for (k = 0 ; k < strlen(tempString3) ; k++ )
						{
							if (tempString3[k] == '[' && tempString3[k+1] == 'e' && tempString3[k+2] == ']')
							{
								tempString4[count++] = g_option.routeEss[jj].name[0];
								k += 2;
							}
							else
							{
								tempString4[count++] = tempString3[k];
							}
						}
						tempString4[count] = '\0';
					}
					else
					{
						sprintf(tempString4,"%s",tempString3);
					}
					sprintf(g_site[j].siteServer[countt].localPathFileName,"%s%s",g_option.programRootPath,tempString4);
					countt++;
				}
				//KKH ############################################
			}
		}
	}

	return 1;
}

/**
 * @brief ������ �ռ��췮 ���� ���α׷��� ���� �����Ǵ� ������� ������ ������ �����ϴ� �Լ�.
 * @param runTime ���� Ÿ�̹�
 * @param fileTimeTm ������ �ð�
 * @return  ������ 1: ����
 * @author �豤ȣ
 */
int transmitFile(int runTime,struct tm fileTimeTm)
{
	int i;
	int j;
	int ERROR_CODE = 1;
	int runningTimeIndex;

	char siteMessage[MAX_STRING_LENGTH];

	//AWS
	for (i = 0; i < g_option.AWSServerCount ; i++ )
	{
		if (!g_AWSServer[i].use) continue;

		//����ó���ε�, �ǽð� �����ϋ��� �����ϰ� �Ǿ������� �������� ����
		if (g_option.timeType == PASTTIME && g_AWSServer[i].transmissionOnlyRealTime) continue;

		//���� �ϴ� �ð��� �������� ������
		if (g_AWSServer[i].transRunTime != runTime) continue;

		ERROR_CODE = putResultFile(g_AWSServer[i]);
		if (ERROR_CODE < 0)
		{
			sprintf(siteMessage,"%s(%s->%s) file transmit failed",g_AWSServer[i].name,
				g_AWSServer[i].localPathFileName,g_AWSServer[i].remotePathFileName);
			// if error
			//LogWriteError("COM_RAR", "transmitFile", siteMessage);
			// log : process1 : fail
			//LogWriteStatusFail("COM_RAR", "transmitFile");
			continue;
		}
		else
		{
			sprintf(siteMessage,"%s",g_AWSServer[i].remotePathFileName);
			// if information
			LogWriteOutput("COM_RAR", "main", siteMessage);
			// log : process1 : success
			//LogWriteStatusSuccess("COM_RAR", "transmitFile");
		}
	}
	
	runningTimeIndex = (int)(fileTimeTm.tm_min/10);
	
	//�ռ� ����/������
	for (i = 0; i < g_option.displayServerCount * g_option.routeCompCount ; i++ )
	{
		if (!g_displayServer[i].use) continue;
		
		//����ó���ε�, �ǽð� �����ϋ��� �����ϰ� �Ǿ������� �������� ����
		if (g_option.timeType == PASTTIME && g_displayServer[i].transmissionOnlyRealTime) continue;
		
		//���� �ϴ� �ð��� �������� ������
		if (g_displayServer[i].transRunTime != runTime) continue;
		
		if (!g_displayServer[i].transMinutes[runningTimeIndex]) continue;
		
		
		ERROR_CODE = putResultFile(g_displayServer[i]);
		if (ERROR_CODE < 0)
		{
			sprintf(siteMessage,"%s(%s->%s) file transmit failed",g_displayServer[i].name,
				g_displayServer[i].localPathFileName,g_displayServer[i].remotePathFileName);
			// if error
			//LogWriteError("COM_RAR", "transmitFile", siteMessage);
			// log : process1 : fail
			//LogWriteStatusFail("COM_RAR", "transmitFile");
			continue;
		}
		else
		{
			sprintf(siteMessage,"%s",g_displayServer[i].remotePathFileName);
			// if information
			LogWriteOutput("COM_RAR", "main", siteMessage);
			// log : process1 : success
			//LogWriteStatusSuccess("COM_RAR", "transmitFile");
		}
	}

	//����Ʈ�� ����/������
	for (j = 0 ; j < g_option.siteCount ; j++)
	{
		for (i = 0; i < g_site[j].serverCount * g_option.routeSiteCount ; i++ )
		{
			if (!g_site[j].siteServer[i].use) continue;
			
			//����ó���ε�, �ǽð� �����ϋ��� �����ϰ� �Ǿ������� �������� ����
			if (g_option.timeType == PASTTIME && g_site[j].siteServer[i].transmissionOnlyRealTime) continue;

			if (g_site[j].siteServer[i].transRunTime == AFTER_SITE_PROG && g_site[j].done < SITE_IMG_DONE) continue;

			//�̹� ���۵� ����Ʈ�� �������� ����.
			if (g_site[j].transSuccess[i]) continue;

			//���� �ϴ� �ð��� �������� ������
			if (g_site[j].siteServer[i].transRunTime != runTime) continue;

			//������ �п� �ش�Ǹ� ������
			if (!g_site[j].siteServer[i].transMinutes[runningTimeIndex]) continue;
			
			//������ ����Ʈ ���� ����(option1)
			if (strstr(g_site[j].siteServer[i].option1,g_site[j].name) == NULL) continue;

			ERROR_CODE = putResultFile(g_site[j].siteServer[i]);
			if (ERROR_CODE < 0)
			{
				sprintf(siteMessage," Sent failed : %s (%s@%s)", extractFilename(g_site[j].siteServer[i].localPathFileName)
				,g_site[j].siteServer[i].ip,g_site[j].siteServer[i].remotePathFileName);
				// if error
				//LogWriteError("COM_RAR", "transmitFile", siteMessage);
				// log : process1 : fail
				//LogWriteStatusFail("COM_RAR", "transmitFile");
				
				continue;
			}
			else
			{
				sprintf(siteMessage,"%s",g_site[j].siteServer[i].remotePathFileName);
				// if information
				LogWriteOutput("COM_RAR", "main", siteMessage);
				// log : process1 : success
				//LogWriteStatusSuccess("COM_RAR", "transmitFile");
			}
			
			g_site[j].transSuccess[i] = 1;
		}
	}
	return ERROR_CODE;
}

/*******************************************
	aws ���� �̸� ����
*******************************************/
/**
 * @brief �ð� ���ڿ��� ���ؼ� AWS ���� �̸��� �����ϴ� �Լ�
 * @param pdateString �ð� ���ڿ�
 * @return  ������ 1: ����
 * @author �豤ȣ
 */
int generateAWSNameFromString(char* pdateString)
{
	struct tm datetime;

	datetime = convStrToDateTime(pdateString);

	generateAWSName(datetime);

	return 1;

}

/**
 * @brief �ð� ���ڿ��� ���ؼ� AWS ���� �̸�(���ڷ��)�� �����ϴ� �Լ�
 * @param pdateString �ð� ���ڿ�
 * @return  ������ 1: ����
 * @author �豤ȣ
 */
static int generateAWSName(struct tm datetime)
{
	char serverFileNameRule[MAX_STRING_LENGTH];
	char localFileNameRule[MAX_STRING_LENGTH];
	struct tm datetimeTemp;
	int i;

	sprintf(serverFileNameRule,"%s%s%%Y%%m%%d%%H%%M",g_option.AWSServerPath,g_option.AWSFileHeader);
	sprintf(localFileNameRule,"%s%s%%Y%%m%%d%%H%%M",g_option.AWSLocalPath,g_option.AWSFileHeader);
	
	for (i = 0 ; i < 10 ; i++ )
	{
		//datetimeTemp = incMin(datetime,i * -1);
	    datetimeTemp = incMin(datetime,i + 1);
		if (strftime(g_option.AWSServerFilePathNameList[i],MAX_STRING_LENGTH,serverFileNameRule,&datetimeTemp) <= 0)
			return -74004;
		if (strftime(g_option.AWSLocalFilePathNameList[i],MAX_STRING_LENGTH,localFileNameRule,&datetimeTemp) <= 0)
			return -74004;
	}

	return 1;
}

/**
 * @brief ����Ʈ �� UF ���� �̸��� �����ϴ� �Լ�
 * @param siteIndex �ð� ���ڿ�
 * @return  ������ 1: ���� ����: ����
 * @author �豤ȣ
 */
int getLocalUFFileName(int siteIndex)
{
	char tempFileName[MAX_STRING_LENGTH];
	DIR* dp;				//�ý��ۿ��� ������ ���丮
	struct dirent* entry;	//�ý��ۿ��� ������ ���ϷϷ�
	int staticRadarFileNamePos;	//filename���� ?�� �ֱ� �������� ����

		tempFileName[0] = '\0';
		staticRadarFileNamePos = pos("?",g_site[siteIndex].radarFileNameIncompletion);
		if((dp = opendir(g_site[siteIndex].localUFFilePath)) != NULL){		//���丮 ����
			while((entry = readdir(dp))!=NULL){		//���ϸ���߿��� ���� ã��
				if((strncmp(g_site[siteIndex].radarFileNameIncompletion,entry->d_name,staticRadarFileNamePos)) == 0){	//�����߿��� ���� ���� ã��
					strcpy(tempFileName,entry->d_name);				//���� ���� �̸� ����
				}
			}
			closedir(dp);
		}else{
			return -51028;
		}
		if (tempFileName[0] == '\0')
		{
			return -51029;
		}

		//���� ���� �̸�(volume)����
		sprintf(g_site[siteIndex].localUFFileName,"%s",tempFileName);
		//���� ���� ���丮+�̸�(volume)����
		sprintf(g_site[siteIndex].localUFPathFileName,"%s%s",g_site[siteIndex].localUFFilePath,tempFileName);
		printf("localUFPathFileName : %s %d\n",g_site[siteIndex].localUFPathFileName,staticRadarFileNamePos);
		return 1;

	return -51030;
}


/**
* @brief ������ �ռ��췮 ���� ���α׷� ������ ���� �Լ�
* @return ERROR_CODE ����: ����
* @author �豤ȣ
*/
int runRadarQPEProgram(struct tm datetime)
{
	int result;
	int pid;
	int i;
	int count = 0;
	int getRadarSuccessCount;
	int parameterCount;
	char datetimeString[MAX_STRING_LENGTH];
	char** p;
	int ERROR_CODE = -1;

	getRadarSuccessCount = 0;
	for (i = 0; i < g_option.siteCount ; i++ )
	{
		if (!g_site[i].useRAR) continue;
		if (g_site[i].done >= CHK_UF_FILE)
			getRadarSuccessCount++;
	}

	parameterCount = getRadarSuccessCount + ARGV0_NULL_COUNT;
	p = malloc(parameterCount * sizeof(char *));
	for (i = 0; i < parameterCount ; i++)
	{
		p[i] = malloc(MAX_STRING_LENGTH * sizeof(char));
	}
	
	sprintf(p[count++],"%s",g_option.radarQPEProgramPathName);

	strftime(datetimeString,MAX_STRING_LENGTH,"%Y%m%d%H%M",&datetime);

	sprintf(p[count++],"%s",datetimeString);
	
	for (i = 0; i < g_option.siteCount ; i++ )
	{
		if (!g_site[i].useRAR) continue;
		if (g_site[i].done >= CHK_UF_FILE)
		{
			sprintf(p[count],"%s",g_site[i].localUFPathFileName);
			g_site[i].done = QPEING;
			count++;
		}
	}

	p[count++] = 0;

	if (count != parameterCount)
	{
		fprintf(stderr,"!!!!!!!!!! int runRadarQPEProgram error \n");
		// if error
		LogWriteError("COM_RAR", "runRadarQPEProgram", "runRadarQPEProgram argv[] error");
		// log : process1 : fail
		LogWriteStatusFail("COM_RAR", "runRadarQPEProgram");
		exit(1);
	}
	
	pid = fork();
	if (pid < 0) //fork error
	{
		return -52023;
	}
	if (pid == 0)//CHILD
	{
		result = execv(g_option.radarQPEProgramPathName,p);
		return -52024;
	}
	else //parent
	{
		int statVal;

		waitpid(pid,&statVal,0);

		if(WIFEXITED(statVal)){
			switch WEXITSTATUS(statVal) {
				case 0 : ERROR_CODE = 1; break;
				case 1 : ERROR_CODE = -51007; break;
				case 2 : ERROR_CODE = -51008; break;
				case 3 : ERROR_CODE = -51009; break;
				case 4 : ERROR_CODE = -51010; break;
				case 5 : ERROR_CODE = -51011; break;
				case 6 : ERROR_CODE = -51012; break;
				case 7 : ERROR_CODE = -51013; break;
				case 8 : ERROR_CODE = -51014; break;
				case 9 : ERROR_CODE = -51015; break;
				case 10 : ERROR_CODE = -51016; break;
				case 11 : ERROR_CODE = -51017; break;
				case 12 : ERROR_CODE = -51018; break;
				case 13 : ERROR_CODE = -51019; break;
				case 14 : ERROR_CODE = -51020; break;
				case 15 : ERROR_CODE = -51021; break;
				case 16 : ERROR_CODE = -51022; break;
				default : ERROR_CODE = -51022; break;
			}
		}
		else if (WIFSIGNALED(statVal))
		{
			ERROR_CODE = -99999;
		}
		if (ERROR_CODE == 1)//���������̸�
		{
			for (i = 0; i < g_option.siteCount ; i++ )
			{
				if (g_site[i].done == QPEING)
				{
					g_site[i].done = QPE_DONE;
				}
			}
		}
		//�޸� ����
		for (i = 0; i < parameterCount ; i++){
			free(p[i]);
		}
		free(p);
		return ERROR_CODE;
	}
}

/**
* @brief ������ �ռ��췮 ���� ���α׷� ������ ���� �Լ�
* @return ERROR_CODE ����: ����
* @author �豤ȣ
*/
int runRARVerifyProgram(struct tm datetime)
{
	int result;
	int pid;
	int i;
	int count = 0;
	int getRadarSuccessCount;
	int parameterCount;
	char datetimeString[MAX_STRING_LENGTH];
	char **p;
	int ERROR_CODE = -1;

	getRadarSuccessCount = 0;
	for (i = 0; i < g_option.siteCount ; i++ )
	{
		if (!g_site[i].useRAR) continue;
		if (g_site[i].done >= CHK_UF_FILE)
			getRadarSuccessCount++;
	}

	parameterCount = ARGV0_NULL_COUNT;
	p = malloc(parameterCount * sizeof(char *));
	for (i = 0; i < parameterCount ; i++)
	{
		p[i] = malloc(MAX_STRING_LENGTH * sizeof(char));
	}
	
	sprintf(p[count++],"%s",g_option.RARVerifyProgramPathName);

	strftime(datetimeString,MAX_STRING_LENGTH,"%Y%m%d%H%M",&datetime);

	sprintf(p[count++],"%s",datetimeString);
	
	p[count++] = 0;

	if (count != parameterCount)
	{
		fprintf(stderr,"!!!!!!!!!! int runRadarQPEProgram error \n");
		// if error
		LogWriteError("COM_RAR", "runRARVerifyProgram", "runRARVerifyProgram argv[] error");
		// log : process1 : fail
		LogWriteStatusFail("COM_RAR", "runRARVerifyProgram");
		exit(1);
	}
	
	pid = fork();
	if (pid < 0) //fork error
	{
		return -52023;
	}
	if (pid == 0)//CHILD
	{
		result = execv(g_option.RARVerifyProgramPathName,p);
		return -52024;
	}
	else //parent
	{
		int statVal;

		waitpid(pid,&statVal,0);

		if(WIFEXITED(statVal)){
			switch WEXITSTATUS(statVal) {
				case 0 : ERROR_CODE = 1; break;
				case 1 : ERROR_CODE = -51007; break;
				case 2 : ERROR_CODE = -51008; break;
				case 3 : ERROR_CODE = -51009; break;
				case 4 : ERROR_CODE = -51010; break;
				case 5 : ERROR_CODE = -51011; break;
				case 6 : ERROR_CODE = -51012; break;
				case 7 : ERROR_CODE = -51013; break;
				case 8 : ERROR_CODE = -51014; break;
				case 9 : ERROR_CODE = -51015; break;
				case 10 : ERROR_CODE = -51016; break;
				case 11 : ERROR_CODE = -51017; break;
				case 12 : ERROR_CODE = -51018; break;
				case 13 : ERROR_CODE = -51019; break;
				case 14 : ERROR_CODE = -51020; break;
				case 15 : ERROR_CODE = -51021; break;
				case 16 : ERROR_CODE = -51022; break;
				default : ERROR_CODE = -51022; break;
			}
		}
		else if (WIFSIGNALED(statVal))
		{
			ERROR_CODE = -99999;
		}
		if (ERROR_CODE == 1)//���������̸�
		{
			for (i = 0; i < g_option.siteCount ; i++ )
			{
				if (g_site[i].done == QPEING)
				{
					g_site[i].done = QPE_DONE;
				}
			}
		}
		//�޸� ����
		for (i = 0; i < parameterCount ; i++){
			free(p[i]);
		}
		free(p);
		return ERROR_CODE;
	}
}

/**
* @brief ����Ʈ �� ���췮 ���� ���� ���α׷� ������ ���� �Լ�
* @return ERROR_CODE ����: ����
* @author �豤ȣ
*/
int runRadarRARSiteProgram(struct tm datetime,int siteIndex)
{
	int result;
	int pid;
	int i;
	int count = 0;
	int parameterCount;
	char datetimeString[MAX_STRING_LENGTH];
	char** p;
	int ERROR_CODE = -1;


	strftime(datetimeString,MAX_STRING_LENGTH,"%Y%m%d%H%M",&datetime);

	parameterCount = 1 + ARGV0_NULL_COUNT;
	p = malloc(parameterCount * sizeof(char *));
	for (i = 0; i < parameterCount ; i++)
	{
		p[i] = malloc(MAX_STRING_LENGTH * sizeof(char));
	}
	
	sprintf(p[count++],"%s",g_option.RARSiteProgramPathName);

	sprintf(p[count++],"%s",datetimeString);

	sprintf(p[count++],"%s",g_site[siteIndex].name);

	p[count++] = 0;
	
	if (count != parameterCount)
	{
		fprintf(stderr,"!!!!!!!!!! int runRadarQPEProgram error \n");
		
		// if error
		LogWriteError("COM_RAR", "runRadarRARSiteProgram", "Error runRadarRARSiteProgram argv[]");
		// log : process1 : fail
		LogWriteStatusFail("COM_RAR", "runRadarRARSiteProgram");
		exit(1);
	}
	
	pid = fork();
	if (pid < 0) //fork error
	{
		return -52023;
	}
	if (pid == 0)//CHILD
	{
		result = execv(g_option.RARSiteProgramPathName,p);
		return -52024;
	}
	else //parent
	{
		int statVal;

		waitpid(pid,&statVal,0);

		if(WIFEXITED(statVal)){
			switch WEXITSTATUS(statVal) {
				case 0 : ERROR_CODE = 1; break;
				default : ERROR_CODE = -963256; break;
			}
		}
		else if (WIFSIGNALED(statVal))
		{
			ERROR_CODE = -999578;
		}
		if (ERROR_CODE == 1)//���������̸�
		{
			g_site[siteIndex].done = SITE_IMG_DONE;
		}
		//�޸� ����
		for (i = 0; i < parameterCount ; i++){
			free(p[i]);
		}
		free(p);
		return ERROR_CODE;
	}
}

/**
* @brief ����Ʈ �� ���췮 ���� ���α׷� ������ ���� �Լ�
* @return ERROR_CODE ����: ����
* @author �豤ȣ
*/
int runRARSiteVerifyProgram(struct tm datetime,int siteIndex)
{
	int result;
	int pid;
	int i;
	int count = 0;
	int parameterCount;
	char datetimeString[MAX_STRING_LENGTH];
	char** p;
	int ERROR_CODE = -1;

	strftime(datetimeString,MAX_STRING_LENGTH,"%Y%m%d%H%M",&datetime);

	parameterCount = 1 + ARGV0_NULL_COUNT;
	p = malloc(parameterCount * sizeof(char *));
	for (i = 0; i < parameterCount ; i++)
	{
		p[i] = malloc(MAX_STRING_LENGTH * sizeof(char));
	}
	
	sprintf(p[count++],"%s",g_option.RARSiteVerifyProgramPathName);

	sprintf(p[count++],"%s",datetimeString);

	sprintf(p[count++],"%s",g_site[siteIndex].name);

	p[count++] = 0;

	if (count != parameterCount)
	{
		fprintf(stderr,"!!!!!!!!!! int runRadarQPEProgram error \n");
		
		// if error
		LogWriteError("COM_RAR", "runRARSiteVerifyProgram", "Error runRARSiteVerifyProgram argv[]");
		// log : process1 : fail
		LogWriteStatusFail("COM_RAR", "runRARSiteVerifyProgram");
		exit(1);
	}
	
	pid = fork();
	if (pid < 0) //fork error
	{
		return -52023;
	}
	if (pid == 0)//CHILD
	{
		result = execv(g_option.RARSiteVerifyProgramPathName,p);
		return -52024;
	}
	else //parent
	{
		int statVal;

		waitpid(pid,&statVal,0);

		if(WIFEXITED(statVal)){
			switch WEXITSTATUS(statVal) {
				case 0 : ERROR_CODE = 1; break;
				default : ERROR_CODE = -963256; break;
			}
		}
		else if (WIFSIGNALED(statVal))
		{
			ERROR_CODE = -999578;
		}
		if (ERROR_CODE == 1)//���������̸�
		{
			g_site[siteIndex].done = SITE_IMG_DONE;
		}
		//�޸� ����
		for (i = 0; i < parameterCount ; i++){
			free(p[i]);
		}
		free(p);
		return ERROR_CODE;
	}
}

