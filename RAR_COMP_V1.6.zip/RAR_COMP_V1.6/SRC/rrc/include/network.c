/**
 * @file network.c
 * @brief ������ �ռ��췮 ���� ����� ������ ������ ��/���� �ϱ����� �Լ�.
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "rrc.h"
#include "log.h"

#define FTP_GET_PROGRAM_NAME "ncftpget"
#define FTP_PUT_PROGRAM_NAME "ncftpput"
#define ARGV0_NULL_COUNT 2	//���α׷� �����Ҷ� �߰��Ǵ� argv�� ��(argv[0],argv[last])
#define NCFTP_OPTION_COUNT 4	//-u -p remote-host  local-directory

/**
 * @brief ������ �����κ��� UF �ڷḦ �����ϴ� �Լ�.
 * @param siteIndex ����Ʈ �ε���
 * @return  ������ 1: ����, ����: ����
 * @author �豤ȣ
 */
int getRadarFile(int siteIndex)
{
	int result;
	int pid;
	int i;
	char** p;
	int parameterCount;
	int count = 0;
	char ftpGetProgramPathName[MAX_STRING_LENGTH];
	int ERROR_CODE = -1;
		
	sprintf(ftpGetProgramPathName,"%s%s%s",g_option.programRootPath,"BIN/",FTP_GET_PROGRAM_NAME);

	parameterCount = 10;
	p = malloc(parameterCount * sizeof(char *));
	for (i = 0; i < parameterCount ; i++)
	{
		p[i] = malloc(MAX_STRING_LENGTH * sizeof(char));
	}

	sprintf(p[count++],"%s",ftpGetProgramPathName);
	sprintf(p[count++],"-u%s",g_site[siteIndex].id);
	sprintf(p[count++],"-p%s",g_site[siteIndex].pw);
	sprintf(p[count++],"-V");
	sprintf(p[count++],"-r2");	//Redial a maximum of 1 times until connected to the remote FTP server.
	sprintf(p[count++],"-t10");	//Timeout after 10 seconds. 
	sprintf(p[count++],"%s",g_site[siteIndex].ip);
	sprintf(p[count++],"%s",g_site[siteIndex].localUFFilePath);
	sprintf(p[count++],"%s",g_site[siteIndex].serverFileName);
	p[count] = 0;

	pid = fork();
	if (pid < 0) //fork error
	{
		return -52012;
	}
	if (pid == 0)//CHILD
	{
		result = execv(ftpGetProgramPathName,p);
		return -52013;
	}
	else //parent
	{
		int statVal;

		waitpid(pid,&statVal,0);

		if(WIFEXITED(statVal)){
			switch WEXITSTATUS(statVal) {
				case 0 : ERROR_CODE = 1; break;
				case 1 : ERROR_CODE = -52001; break;
				case 2 : ERROR_CODE = -52002; break;
				case 3 : ERROR_CODE = -52003; break;
				case 4 : ERROR_CODE = -52004; break;
				case 5 : ERROR_CODE = -52005; break;
				case 6 : ERROR_CODE = -52006; break;
				case 7 : ERROR_CODE = -52007; break;
				case 8 : ERROR_CODE = -52008; break;
				case 9 : ERROR_CODE = -52009; break;
				case 10 : ERROR_CODE = -52010; break;
				case 11 : ERROR_CODE = -52011; break;
			}
		}
		else if (WIFSIGNALED(statVal))
		{
			ERROR_CODE = -99999;
		}

		for (i = 0 ; i < parameterCount ; i++ )
		{
			free(p[i]);
		}
		free(p);

		return ERROR_CODE;
	}

}

/**
 * @brief ���� ������ ������ ���⹰�� ������ ������ �����ϴ� �Լ�.
 * @param g_displayServer ���� ���� ���� ����ü
 * @return  ������ 1: ����, ����: ����
 * @author �豤ȣ
 */
int putResultFile(DISPLAY_SERVER g_displayServer)
{
	int result;
	int pid;
	int statVal;

	int i;
	char** p;
	int parameterCount;
	int count = 0;
	char ftpPutProgramPathName[MAX_STRING_LENGTH];
	char systemString[MAX_STRING_LENGTH];
	int ERROR_CODE = -1;

	sprintf(ftpPutProgramPathName,"%s%s%s",g_option.programRootPath,"BIN/",FTP_PUT_PROGRAM_NAME);

	parameterCount = 13;

	if (!g_displayServer.dellocalfile) parameterCount--;

	if (!g_displayServer.rename) parameterCount--;

	p = malloc(parameterCount * sizeof(char *));
	for (i = 0; i < parameterCount ; i++)
	{
		p[i] = malloc(MAX_STRING_LENGTH * sizeof(char));
	}

	sprintf(p[count++],"%s",ftpPutProgramPathName);
	sprintf(p[count++],"-u%s",g_displayServer.id);//-u XX   Use username XX instead of anonymous.
	sprintf(p[count++],"-p%s",g_displayServer.pw);//-p XX   Use password XX with the username.
	sprintf(p[count++],"-m");	//Attempt  to  make the remote destination directory before copying
	if (g_displayServer.dellocalfile)
		sprintf(p[count++],"%s","-DD");	//Delete local file after successfully uploading it.
	sprintf(p[count++],"-S.tmp");	//Upload into temporary files suffixed by ".tmp"
	sprintf(p[count++],"-r2");	//Redial a maximum of 1 times until connected to the remote FTP server.
	sprintf(p[count++],"-t10");	//Timeout after 10 seconds. 
	if (g_displayServer.rename)	//rename
	{
		sprintf(p[count++],"-C");
		sprintf(p[count++],"%s",g_displayServer.ip);
		sprintf(p[count++],"%s",g_displayServer.localPathFileName);
		sprintf(p[count++],"%s",g_displayServer.remotePathFileName);
	}
	else
	{
		sprintf(p[count++],"%s",g_displayServer.ip);
		sprintf(p[count++],"%s",g_displayServer.remotePathFileName);
		sprintf(p[count++],"%s",g_displayServer.localPathFileName);
	}
	p[count] = 0;

	//�����̸��� �ٲ㼭 �����ϴ°��� �ƴϸ� system���ɾ ����ؼ���
	//�׷��� ������ ?�� *�� �̿��� �� ����.
	if (!g_displayServer.rename)
	{
		systemString[0]='\0';
		for (i = 0 ; i < parameterCount-1 ; i++ )
		{
			strcat(systemString,p[i]);
			strcat(systemString," ");
		}
		ERROR_CODE = system(systemString);

		for (i = 0 ; i < parameterCount ; i++ )
		{
			free(p[i]);
		}
		free(p);

		if (ERROR_CODE == 0)
		{
			return 1;
		}
		else
		{
			return -98216;
		}
	}

	//rename�� �ƴϸ�
	pid = fork();

	switch (pid)
	{
	case -1 ://fork error
		return -52012;
	case 0 ://child
		result = execv(ftpPutProgramPathName,p);
		return -52013;
	default ://parent

		waitpid(pid,&statVal,0);

		if(WIFEXITED(statVal))
		{
			switch WEXITSTATUS(statVal)
			{
				case 0 : ERROR_CODE = 1; break;
				case 1 : ERROR_CODE = -52017; break;
				case 2 : ERROR_CODE = -52018; break;
				case 3 : ERROR_CODE = -52019; break;
				case 4 : ERROR_CODE = -52020; break;
				case 5 : ERROR_CODE = -52021; break;
				case 6 : ERROR_CODE = -52022; break;
				case 7 : ERROR_CODE = -52023; break;
				case 8 : ERROR_CODE = -52024; break;
				case 9 : ERROR_CODE = -52025; break;
				case 10 : ERROR_CODE = -52026; break;
				case 11 : ERROR_CODE = -52027; break;
			}
		}
		else if (WIFSIGNALED(statVal))
		{
			ERROR_CODE = -99999;
		}

		for (i = 0 ; i < parameterCount ; i++ )
		{
			free(p[i]);
		}
		free(p);

		return ERROR_CODE;
	}
}

/**
 * @brief ������ �����κ��� AWS �ڷ�(���ڷ�)�� �����ϴ� �Լ�.
 * @return  ������ 1: ����, ����: ����
 * @author �豤ȣ
 */
int getAWSFile()
{
	int result;
	int pid;
	int i;
	int count = 0;
	int parameterCount;
	char** p;
	char ftpGetProgramPathName[MAX_STRING_LENGTH];
	int ERROR_CODE = -1;

	sprintf(ftpGetProgramPathName,"%s%s%s",g_option.programRootPath,"BIN/",FTP_GET_PROGRAM_NAME);

	//��1�� �����͸� �޾Ƽ� �Ϸ� ���� ���췮�� ���� 1�� ���췮 ����
	//parameterCount = ARGV0_NULL_COUNT + NCFTP_OPTION_COUNT + AWS ���� ����;
	//60�� �̵� ���췮 ���
	parameterCount = ARGV0_NULL_COUNT + NCFTP_OPTION_COUNT + 10;

	p = malloc(parameterCount * sizeof(char *));
	for (i = 0; i < parameterCount ; i++)
	{
		p[i] = malloc(MAX_STRING_LENGTH * sizeof(char));
	}
	
	sprintf(p[count++],"%s",ftpGetProgramPathName);

	sprintf(p[count++],"-u%s",g_option.AWSID);

	sprintf(p[count++],"-p%s",g_option.AWSPW);

	sprintf(p[count++],"%s",g_option.AWSIP);

	sprintf(p[count++],"%s",g_option.AWSLocalPath);

	//��1�� �����͸� �޾Ƽ� �Ϸ� ���� ���췮�� ���� 1�� ���췮 ����
	for (i = 0 ; i < 10 ; i++ )
	{
		sprintf(p[count++],"%s",g_option.AWSServerFilePathNameList[i]);
	}

	p[count] = 0;

	if (count > parameterCount)
	{
		fprintf(stderr,"!!!!!!!!!! run_composition_radar_program error \n");
		// if error
		LogWriteError("COM_RAR", "getAWSFile", "getAWSFile argv[] error");
		// log : process1 : fail
		LogWriteStatusFail("COM_RAR", "getAWSFile");
		exit(1);
	}
	
	pid = fork();
	if (pid < 0) //fork error
	{
		return -72001;
	}
	if (pid == 0)//CHILD
	{
		result = execv(ftpGetProgramPathName,p);
		return -72002;
	}

	else //parent
	{
		int statVal;

		waitpid(pid,&statVal,0);

		if(WIFEXITED(statVal)){
			switch WEXITSTATUS(statVal) {
				case 0 : ERROR_CODE = 1; break;
				case 1 : ERROR_CODE = -72003; break;
				case 2 : ERROR_CODE = -72004; break;
				case 3 : ERROR_CODE = -72005; break;
				case 4 : ERROR_CODE = -72006; break;
				case 5 : ERROR_CODE = -72007; break;
				case 6 : ERROR_CODE = -72008; break;
				case 7 : ERROR_CODE = -72009; break;
				case 8 : ERROR_CODE = -72010; break;
				case 9 : ERROR_CODE = -72011; break;
				case 10 : ERROR_CODE = -72012; break;
				case 11 : ERROR_CODE = -72013; break;
			}
		}
		else if (WIFSIGNALED(statVal))
		{
			ERROR_CODE = -99999;
		}

		for (i = 0 ; i < parameterCount ; i++ )
		{
			free(p[i]);
		}
		free(p);

		return ERROR_CODE;
	}

}
