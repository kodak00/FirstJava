/**
 * @file rrc.c
 * @brief ������ �ռ��췮 ���� ���α׷��� �ǽð� ������ ���� ���� �Լ�.
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <curses.h>
#include "include/rrc.h"
#include "include/function.h"
#include "include/log.h"
#include "include/network.h"

/*******************************************
				��������
*******************************************/
OPTION	g_option;				//ȯ�漳��
SITE*	g_site;				//����Ʈ�� �ڷ�(init���� �ʱ�ȭ)
DISPLAY_SERVER* g_displayServer;	//ǥ�⼭��
DISPLAY_SERVER* g_AWSServer;

int main(int argc, char* argv[])
{
	int opt;
	int i;
	int ERROR_CODE;
	
	char siteMessage[MAX_STRING_LENGTH];
	char siteMessage2[MAX_STRING_LENGTH];
	char runProgram[MAX_STRING_LENGTH];
	
	char* plogPath;
	
	static char logPathFileName[MAX_STRING_LENGTH];
	
	struct tm startTimeTm;
	struct tm fileTimeTm;
	struct tm processTimeTm;
	struct tm finishTimeTm;
	
	struct tm datetimeTemp;
	char tempString1[MAX_STRING_LENGTH];
	char tempString2[MAX_STRING_LENGTH];
	
	int __runRadarQPE = 1;
	int __runRadarRARSite = 1;
	int __runRARVerify = 1;
	int __runTransport = 1;
	
	char usedSiteList[MAX_STRING_LENGTH];
	int noUseUsedSiteList = 0;
	
	int loopChkFlag;	//�ð� �˻� ������ ��� �������� �����.
	
	int totalRadarFileCount = 0;
	int newRadarFileCount = 0;
	
	int QPECount;
	int QPERun;	//QPE�� �ѹ��� ������ �ȵ����� ������ �ð��� QPE���α׷� ����
	
	/*******************************************
		�Է� �Ķ��Ÿ ó��
	*******************************************/
	g_option.timeType = 1;
	
	while((opt = getopt(argc,argv,"pertu:")) != -1)
	{
		switch (opt)
		{
			case 'p' : //QPE ���α׷� �������� ����
				__runRadarQPE = 0;
				__runRadarRARSite = 0;
				break;
			case 'e' : //RAR ����
				__runRARVerify = 0;
				break;	
			case 'u' : //����� ���̴� ����Ʈ ��� ,�� ����
				noUseUsedSiteList = 1;
				sprintf(usedSiteList,"%s",optarg);
				break;
			case 'r' : //�ǽð� or �����ڷ� ó��
				g_option.timeType = 2;
				break;
			case 't' : //������ ���� �������� ����
				__runTransport = 0;
				break;
		}
	}

	/*******************************************
		�ð� �ʱ�ȭ
	*******************************************/
	fprintf(stderr,"* set time start\n");
	sprintf(g_option.datetimeString,"%s",argv[optind]);
	startTimeTm = convStrToDateTime(g_option.datetimeString);
	processTimeTm = startTimeTm;
	finishTimeTm = startTimeTm;
	fileTimeTm = startTimeTm;
	printf("g_option.realtimeString = %s\n", g_option.datetimeString); //KKH

	/*******************************************
		�α����� ����
	*******************************************/
	if ((ERROR_CODE = setLogPathFileName(g_option.datetimeString,g_option.timeType)) < 0)
	{
		fprintf(stderr,"! setLogPathFileName Error No.%d\n",ERROR_CODE);
	}
	
	LogOpenFile();
	
	// get run program name
	strcpy(runProgram, argv[0]);
	
	// log : main : start
	LogWriteStart("COM_RAR", "main");
	
	// log : main : run (write run program name)
	LogWriteRun("COM_RAR", "main", runProgram);
	
	// log : main : time (write data time)
	LogWriteTime("COM_RAR", "main", g_option.datetimeString);

	/*******************************************
		ȯ�漳�� ���� �б�(setup.ini)
	*******************************************/
	fprintf(stderr,"* call readSetup\n");
	
	// log : process1 : start
	LogWriteStart("COM_RAR", "read setup.ini");
	if ((ERROR_CODE = readSetup()) < 0)
	{
		fprintf(stderr,"! read setup.ini Error No.%d\n",ERROR_CODE);
		sprintf(siteMessage,"Error don't read setup.ini");
		// if error
		LogWriteError("COM_RAR", "read setup.ini", siteMessage);
		
		exit(0);
	}
	else
	{
		// log : process1 : success
		LogWriteStatusSuccess("COM_RAR", "read setup.ini");
	}
		
	QPECount = 0;
	
	/*******************************************
		site�� �޸� ���� �� �ʱ�ȭ(site[x])
	*******************************************/
	fprintf(stderr,"* call initSite\n");
	g_site = malloc(g_option.siteCount * sizeof(SITE));
	
	// log : process1 : start
	LogWriteStart("COM_RAR", "read site.ini");
	for (i = 0 ; i < g_option.siteCount ; i++ )
	{
		sprintf(siteMessage,"initSite (%d's site)", i);
		
		if ((ERROR_CODE = initSite(i)) < 0)
		{
			fprintf(stderr,"initSite (%d's site) Error No.%d\n",i,ERROR_CODE);
			sprintf(siteMessage,"Error initSite (%d's site)",i);
			// if error
			LogWriteError("COM_RAR", "initSite", siteMessage);
			// log : process1 : fail
			LogWriteStatusFail("COM_RAR", "initSite");
		}
	}
	// log : process1 : end
	LogWriteEnd("COM_RAR", "read site.ini");

	/*******************************************
		����� ����Ʈ�� use�� 1�� �ٲ�
	*******************************************/
	if (noUseUsedSiteList)
	{
		for (i = 0 ; i < g_option.siteCount ; i++ )
		{
			if (strstr(usedSiteList,g_site[i].name) != NULL)
			{
				g_site[i].useComp = 0;
				g_site[i].useSite = 0;
				g_site[i].useRAR = 0;
			}
		}
	}
	printf("unused_site_list: %s\n", usedSiteList);
	
	/*******************************************
		site�� ���̴� ���� �̸� ����
	*******************************************/
	fprintf(stderr,"* call generateRadarFileName\n");
	for (i = 0 ; i < g_option.siteCount ; i++ )
	{
		if (g_site[i].useComp != 1 && g_site[i].useSite != 1 && g_site[i].useRAR != 1) continue;

		sprintf(siteMessage,"site: %s", g_site[i].name);
		ERROR_CODE = generateRadarFileName(fileTimeTm,i);
		if (ERROR_CODE < 0)
		{
			fprintf(stderr,"! Error generateRadarFileName (%d's site) Error No.%d\n",i,ERROR_CODE);
			sprintf(siteMessage,"Error generateRadarFileName (site: %s)",g_site[i].name);
		}
	}
	
	/*******************************************
		ǥ�� ������ ȯ�漳��
	*******************************************/
	fprintf(stderr,"* call readDisplayServerIni\n");
	// log : process1 : start
	LogWriteStart("COM_RAR", "read server.ini");
	
	if ((ERROR_CODE = readDisplayServerIni()) < 0)
	{
		fprintf(stderr,"! Error readDisplayServerIni Error No.%d\n",ERROR_CODE);
		sprintf(siteMessage,"Error don't read server.ini");
		// if error
		LogWriteError("COM_RAR", "read server.ini", siteMessage);
	}
	else
	{
		// log : process1 : success
		LogWriteStatusSuccess("COM_RAR", "read server.ini");
	}
	// log : process1 : end
	LogWriteEnd("COM_RAR", "read server.ini");
	
	/*******************************************
		ǥ�� ������ ��� �̸� ����
	*******************************************/
	fprintf(stderr,"* call generateServerPathname\n");
	
	ERROR_CODE = generateServerPathname(fileTimeTm);
	if (ERROR_CODE < 0)
	{
		fprintf(stderr,"! generateServerPathname error : %d\n",ERROR_CODE);
		exit(1);
	}
	
	/*******************************************
		��� ���� �̸� ����
	*******************************************/
	fprintf(stderr,"* call generateResultFileName\n");
	
	ERROR_CODE = generateResultFileName(fileTimeTm);
	if (ERROR_CODE < 0)
	{
		fprintf(stderr,"! generateResultFileName error : %d\n",ERROR_CODE);
		exit(1);
	}
	
	/*******************************************
		�ٿ�ε� ���� AWS ���� �̸� ����
	*******************************************/
	if ((ERROR_CODE = generateAWSNameFromString(g_option.datetimeString)) < 0)
	{
		fprintf(stderr,"generateAWSNameFromString Error No.%d\n",ERROR_CODE);
		sprintf(siteMessage,"Error generateAWSNameFromString");
		exit(2);
	}
	else
	{
		sprintf(siteMessage2,"%s%s.g3min.txt",g_option.AWSTRMMGSPPath,g_option.datetimeString);
	}
	
	datetimeTemp = incMin(fileTimeTm, 10);
	strftime(tempString1,MAX_STRING_LENGTH,"%Y%m%d%H%M",&datetimeTemp);
	sprintf(g_option.AWSTRMMGSPFilePathName,"%s%s.g3min.txt",g_option.AWSTRMMGSPPath,tempString1);

	/*******************************************
		�ݺ� �ð����� �˻�
	*******************************************/
	loopChkFlag = 1;
	while(loopChkFlag)
	{
		if (datecmp(processTimeTm,finishTimeTm) >= 0)
		{
			loopChkFlag = 0;
		}

		printf("  -processTimeTm = %s",asctime(&processTimeTm));
		totalRadarFileCount = 0;
		newRadarFileCount = 0;
		
		sprintf(g_option.AWSTRMMGSPFilePathName,"%s%s.g3min.txt",g_option.AWSTRMMGSPPath,g_option.datetimeString);
						
		/*******************************************
			AWS���� ��������
		*******************************************/
		if (!fileExists(g_option.AWSTRMMGSPFilePathName))
		{
			sprintf(siteMessage,"don't exist : %s", g_option.AWSTRMMGSPFilePathName);
			// if information
			LogWriteInformation("COM_RAR", "TRMM/GSP AWS file", siteMessage);
			// log : process1 : start
			LogWriteStart("COM_RAR", "checkAWSRawFile");
			if (checkAWSRawFile() < 10)
			{
				// if information
				LogWriteInformation("COM_RAR", "checkAWSRawFile", "AWS RAW DATA < 10");
				
				// log : process1 : start
				LogWriteStart("COM_RAR", "getAWSFile");
				if ((ERROR_CODE = getAWSFile()) < 0)
				{
					fprintf(stderr,"getAWSFile Error No.%d : %s\n",ERROR_CODE,g_option.AWSTRMMGSPFilePathName);
					
					sprintf(siteMessage,"Error getAWSFile : %s", g_option.AWSTRMMGSPFilePathName);
					// if error
					LogWriteError("COM_RAR", "getAWSFile", siteMessage);
					// log : process1 : fail
					LogWriteStatusFail("COM_RAR", "getAWSFile");
					
				}
				else
				{
					sprintf(siteMessage,"%s", g_option.AWSTRMMGSPFilePathName);
					// log : process1 : success
					LogWriteInput("COM_RAR","getAWSFile",siteMessage);
					LogWriteStatusSuccess("COM_RAR", "getAWSFile");
				}
				// log : process1 : end
				LogWriteEnd("COM_RAR", "getAWSFile");		
			}
			else
			{
				printf("skip aws file download\n");
				// if information
				LogWriteInformation("COM_RAR", "checkAWSRawFile", "AWS RAW DATA = 10: skip aws file download");
			}
			// log : process1 : end
			LogWriteEnd("COM_RAR", "checkAWSRawFile");
	
			//AWS QC ini ���α׷� ����
			// log : process1 : start
			LogWriteStart("COM_RAR", "runAWSQCIni");
			for (i = 0 ; i < 10 ; i++ )
			{
				datetimeTemp = incMin(fileTimeTm, i+1);
				strftime(tempString1,MAX_STRING_LENGTH,"%Y%m%d%H%M",&datetimeTemp);
				sprintf(tempString2,"%sAWS_TMP_%s",g_option.AWSTRMMGSPPath,tempString1);
					
				if (!fileExists(tempString2))
				{	
					if ((ERROR_CODE = runAWSQCIni(datetimeTemp)) < 0)
					{
						fprintf(stderr,"runAWSQCIni Error No.%d : %s\n",ERROR_CODE,tempString2);
				
						sprintf(siteMessage,"Error runAWSQCIni : %s", tempString2);
						// if error
						LogWriteError("COM_RAR", "runAWSQCIni", siteMessage);
						// log : process1 : fail
						LogWriteStatusFail("COM_RAR", "runAWSQCIni");
					}
					else
					{
						// log : process1 : success
						LogWriteStatusSuccess("COM_RAR", "runAWSQCIni");
					}
				}
			}
			// log : process1 : end
			LogWriteEnd("COM_RAR", "runAWSQCIni");

			//AWS QC ���α׷� ����
			// log : process1 : start
			LogWriteStart("COM_RAR", "runAWSQC");
				
			for (i = 0 ; i < 10 ; i++ )
			{
				datetimeTemp = incMin(fileTimeTm, i+1);
				strftime(tempString1,MAX_STRING_LENGTH,"%Y%m%d%H%M",&datetimeTemp);
				sprintf(tempString2,"%sAWS_QC_%s",g_option.programRootPath,tempString1);
				if (!fileExists(tempString2))
				{
					if ((ERROR_CODE = runAWSQC(datetimeTemp)) < 0)
					{
						fprintf(stderr,"runAWSQC Error No.%d : %s\n",ERROR_CODE,tempString2);
			
						sprintf(siteMessage,"Error runAWSQC : %s", tempString2);
						// if error
						LogWriteError("COM_RAR", "runAWSQC", siteMessage);
						// log : process1 : fail
						LogWriteStatusFail("COM_RAR", "runAWSQC");
					}
					else
					{
						// log : process1 : success
						LogWriteStatusSuccess("COM_RAR", "runAWSQC");
					}
				}
			}
			// log : process1 : end
			LogWriteEnd("COM_RAR", "runAWSQC");

			//TRMM GSP ���α׷� ����
			// log : process1 : start
			LogWriteStart("COM_RAR", "runAWSTRMMGSPInit");
			if ((ERROR_CODE = runAWSTRMMGSPInit()) < 0)
			{
				fprintf(stderr,"runAWSTRMMGSPInit Error No.%d : %s\n",ERROR_CODE,g_option.AWSTRMMGSPFilePathName);
					
				sprintf(siteMessage,"Error runAWSTRMMGSPInit : %s", g_option.AWSTRMMGSPFilePathName);
				// if error
				LogWriteError("COM_RAR", "runAWSTRMMGSPInit", siteMessage);
				// log : process1 : fail
				LogWriteStatusFail("COM_RAR", "runAWSTRMMGSPInit");
			}
			else
			{
				// log : process1 : success
				LogWriteStatusSuccess("COM_RAR", "runAWSTRMMGSPInit");
			}
			// log : process1 : end
			LogWriteEnd("COM_RAR", "runAWSTRMMGSPInit");
			
			//TRMM-GSP
			LogWriteStart("COM_RAR", "runAWSTRMMGSP");

			runAWSTRMMGSP();
			if (!fileExists(g_option.AWSTRMMGSPFilePathName))
			{
				fprintf(stderr,"runAWSTRMMGSP Error No.%d : %s\n",ERROR_CODE,g_option.AWSTRMMGSPFilePathName);
				
				sprintf(siteMessage,"Error runAWSTRMMGSP : %s", g_option.AWSTRMMGSPFilePathName);
				// if error
				LogWriteError("COM_RAR", "runAWSTRMMGSP", siteMessage);
				// log : process1 : fail
				LogWriteStatusFail("COM_RAR", "runAWSTRMMGSP");
			}
			else
			{
				// log : process1 : success
				LogWriteStatusSuccess("COM_RAR", "runAWSTRMMGSP");
			}
			// log : process1 : end
			LogWriteEnd("COM_RAR", "runAWSTRMMGSP");
		}
		else
		{
			sprintf(siteMessage,"already exist : %s", g_option.AWSTRMMGSPFilePathName);
			LogWriteInformation("COM_RAR", "TRMM/GSP AWS file", siteMessage);
		}
							
		/*******************************************
		 		ǥ�⼭���� ����
		*******************************************/
		if (__runTransport) transmitFile(AFTER_QC,fileTimeTm);
						
		/*******************************************
			����Ʈ�� ������ ó��
		*******************************************/
		for (i = 0 ; i < g_option.siteCount ; i++ )
		{
			if (g_site[i].done >= CHK_UF_FILE)
			{	
				totalRadarFileCount++;
				continue;
			}

			//������� �ʴ� ����Ʈ ���
			if (g_site[i].useComp != 1 && g_site[i].useSite != 1 && g_site[i].useRAR != 1) continue;

			if (g_site[i].done == NONE)
			{	
				if (g_site[i].ftpUse)
				{
					LogWriteStart("COM_RAR", "getRadarFile");
					if ( (ERROR_CODE = getRadarFile(i)) < 0)
					{
						fprintf(stderr,"getRadarFile Error No.%d\n",ERROR_CODE);
					
						sprintf(siteMessage,"Error getRadarFile [site: %s]", g_site[i].name);
						// if error
						LogWriteError("COM_RAR", "getRadarFile", siteMessage);
						// log : process1 : fail
						LogWriteStatusFail("COM_RAR", "getRadarFile");
					}
					else
					{
						// log : process1 : success
						LogWriteStatusSuccess("COM_RAR", "getRadarFile");
					}
					// log : process1 : end
					LogWriteEnd("COM_RAR", "getRadarFile");
				}
				
				LogWriteStart("COM_RAR", "getLocalUFFileName");
				ERROR_CODE = getLocalUFFileName(i);
				if (ERROR_CODE < 0)//���� �߻�
				{
					g_site[i].done = NONE;
					fprintf(stderr,"! getLocalUFFileName error : %d\n",ERROR_CODE);
					
					sprintf(siteMessage,"Error getLocalUFFileName [site: %s]", g_site[i].name);
					// if error
					LogWriteError("COM_RAR", "getLocalUFFileName", siteMessage);
					// log : process1 : fail
					LogWriteStatusFail("COM_RAR", "getLocalUFFileName");
				}
				else//��������
				{
					printf(" * %s file name : %s\n",g_site[i].name, g_site[i].localUFFileName);
					g_site[i].done = FOUND_LOCAL_FILE;//10�� ���� �� ���ο� 6�� ����
					// log : process1 : success
					sprintf(siteMessage2,"site: %s", g_site[i].name);
					LogWriteInformation("COM_RAR", "getLocalUFFileName", siteMessage2);
					LogWriteStatusSuccess("COM_RAR", "getLocalUFFileName");
				}
				
			}
		}	
		LogWriteEnd("COM_RAR", "getLocalUFFileName");
		
		LogWriteStart("COM_RAR", "checkUFFile");
		for (i = 0 ; i < g_option.siteCount ; i++ )
		{
			//�ٿ�ε� ���� UF���� �˻�
			if (g_site[i].done == FOUND_LOCAL_FILE)
			{	
				//����Ʈ ���� ���� ������ ã������
				fprintf(stderr," * call check_uffile : %s\n",g_site[i].name);
								
				ERROR_CODE = checkUFFile(g_site[i].localUFPathFileName);
				if (ERROR_CODE < 0)
				{//������ �ִ� �����̸� ����
					g_site[i].done = NONE;
					unlink(g_site[i].localUFPathFileName);
					fprintf(stderr,"! chk_gzip_file error : %d\n",ERROR_CODE);
					
					sprintf(siteMessage,"Error checkUFFile: %s]", g_site[i].localUFPathFileName);
					// if error
					LogWriteError("COM_RAR", "checkUFFile", siteMessage);
					// log : process1 : fail
					LogWriteStatusFail("COM_RAR", "checkUFFile");
				}
				else
				{
					g_site[i].done = CHK_UF_FILE;
					//�̸��� �ϳ��� �������� ���� ��Ű�� ���ؼ� �̸��� �����ϰ� �����ϸ� ���� �̸��� ���̸����� �����Ѵ�.
					if (rename(g_site[i].localUFPathFileName,g_site[i].newUFFormatFilePathName) == 0)
					{
						sprintf(siteMessage2,"%s",g_site[i].localUFPathFileName);
						sprintf(g_site[i].localUFPathFileName,"%s",g_site[i].newUFFormatFilePathName);
						sprintf(g_site[i].localUFFileName,"%s",g_site[i].newUFFormatFileName);
					}
					fprintf(stderr,"   chk_gzip_file ok\n");
					// log : process1 : success
					
					sprintf(siteMessage,"%s",g_site[i].newUFFormatFileName);
					
					LogWriteInput("COM_RAR", "checkUFFile",siteMessage2);
					LogWriteStatusSuccess("COM_RAR", "checkUFFile");
				}
				
			}
		
			if (g_site[i].done == CHK_UF_FILE)
			{
				newRadarFileCount++;
			}

			if (g_site[i].done >= CHK_UF_FILE)
			{
				totalRadarFileCount++;
			}
		}
		LogWriteEnd("COM_RAR", "checkUFFile");
		
		printf("  -newRadarFileCount = %d\n",newRadarFileCount);
		printf("  -totalRadarFileCount = %d\n",totalRadarFileCount);
		
		/*******************************************
			RAR ����
		*******************************************/
		//���� ���� �˻�
		QPERun = FALSE;

		if (!loopChkFlag)//������ �����̸�
		{
			if (QPECount < 1)//�ѹ��� ������ ��������
				QPERun = TRUE;
			if (newRadarFileCount > 0)//���ο� ������ ������
				QPERun = TRUE;
		}
		
		if (totalRadarFileCount < 1)
			QPERun = FALSE;
		
		if (QPERun == TRUE)
		{
			QPECount++;

			if (__runRadarQPE)
			{
				fprintf(stderr,"* call runRadarQPEProgram\n");
				LogWriteStart("COM_RAR", "runRadarQPEProgram");
				ERROR_CODE = runRadarQPEProgram(fileTimeTm);
				if (ERROR_CODE < 0)
				{
					fprintf(stderr,"! runRadarQPEProgram error : %d\n",ERROR_CODE);
			
					// if error
					LogWriteError("COM_RAR", "runRadarQPEProgram", "runRadarQPEProgram error");
					// log : process1 : fail
					LogWriteStatusFail("COM_RAR", "runRadarQPEProgram");
				}
				else
				{
					// log : process1 : success
					LogWriteStatusSuccess("COM_RAR", "runRadarQPEProgram");
				}
				LogWriteEnd("COM_RAR", "runRadarQPEProgram");
			}

			/*******************************************
				RAR ���� ����
			*******************************************/
			if (__runRARVerify)
			{							
				fprintf(stderr,"* call runRARVerifyProgram\n");
				LogWriteStart("COM_RAR", "runRARVerifyProgram");
				ERROR_CODE = runRARVerifyProgram(fileTimeTm);
				if (ERROR_CODE < 0)
				{
					fprintf(stderr,"! runRARVerifyProgram error : %d\n",ERROR_CODE);
				
					// if error
					LogWriteError("COM_RAR", "runRARVerifyProgram", "runRARVerifyProgram error");
					// log : process1 : fail
					LogWriteStatusFail("COM_RAR", "runRARVerifyProgram");
				}
				else
				{
					// log : process1 : success
					LogWriteStatusSuccess("COM_RAR", "runRARVerifyProgram");
				}
				LogWriteEnd("COM_RAR", "runRARVerifyProgram");
			}
			
			/*******************************************
				RAR site ����
			*******************************************/
			if (__runRadarRARSite)
			{
				LogWriteStart("COM_RAR", "runRadarRARSiteProgram");
				for (i = 0 ; i < g_option.siteCount ; i++ )
				{
					if (g_site[i].useRAR != 1) continue;
					if (g_site[i].done == QPE_DONE)
					{
						ERROR_CODE = runRadarRARSiteProgram(fileTimeTm,i);
						if (ERROR_CODE < 0)
						{
							fprintf(stderr,"! run_site_radar_program error : %d\n",ERROR_CODE);
							sprintf(siteMessage,"Error runRadarRARSiteProgram [site: %s]", g_site[i].name);
							// if error
							LogWriteError("COM_RAR", "runRadarRARSiteProgram", siteMessage);
							// log : process1 : fail
							LogWriteStatusFail("COM_RAR", "runRadarRARSiteProgram");
							continue;
						}
						else
						{
							// log : process1 : success
							sprintf(siteMessage2,"site: %s", g_site[i].name);
							LogWriteInformation("COM_RAR", "runRadarRARSiteProgram", siteMessage2);
							LogWriteStatusSuccess("COM_RAR", "runRadarRARSiteProgram");
						}
						g_site[i].done = RAR_SITE_DONE;
					}
				}
				LogWriteEnd("COM_RAR", "runRadarRARSiteProgram");
			}
			
			/*******************************************
				RAR stie ���� ����
			*******************************************/
			if (__runRARVerify)
			{
				LogWriteStart("COM_RAR", "runRARSiteVerifyProgram");	
				for (i = 0 ; i < g_option.siteCount ; i++ )
				{
					if (g_site[i].useRAR != 1) continue;
					if (g_site[i].done == RAR_SITE_DONE)
					{
						ERROR_CODE = runRARSiteVerifyProgram(fileTimeTm,i);
						if (ERROR_CODE < 0)
						{
							fprintf(stderr,"! runRARSiteVerifyProgram error : %d\n",ERROR_CODE);
						
							sprintf(siteMessage,"Error runRARSiteVerifyProgram [site: %s]", g_site[i].name);
							// if error
							LogWriteError("COM_RAR", "runRARSiteVerifyProgram", siteMessage);
							// log : process1 : fail
							LogWriteStatusFail("COM_RAR", "runRARSiteVerifyProgram");
							continue;
						}
						else
						{
							// log : process1 : success
							sprintf(siteMessage2,"site: %s", g_site[i].name);
							LogWriteInformation("COM_RAR", "runRARSiteVerifyProgram", siteMessage2);
							LogWriteStatusSuccess("COM_RAR", "runRARSiteVerifyProgram");
						}
						g_site[i].done = RAR_SITE_VERI_DONE;
					}
				}
				LogWriteEnd("COM_RAR", "runRARSiteVerifyProgram");
			}
		}
		/*******************************************
 			ǥ�⼭���� ����
		*******************************************/
		if (__runTransport)
		{
			LogWriteStart("COM_RAR", "transmitFile (AFTER_QPE_PROG: QPE_FILE)");
			transmitFile(AFTER_QPE_PROG,fileTimeTm);
			LogWriteEnd("COM_RAR", "transmitFile (AFTER_QPE_PROG: QPE_FILE)");
		}
		
		processTimeTm = now();
	}
			
	plogPath = getenv("COMP_RADAR_ROOT_PATH");
	
	if (g_option.timeType == REALTIME)
	{
		sprintf(logPathFileName,"%sLOG/rrc/rrc_%s_r.log",plogPath,g_option.datetimeString);
	}
	else if (g_option.timeType == PASTTIME)
	{
		sprintf(logPathFileName,"%sLOG/rrc/rrc_%s_p.log",plogPath,g_option.datetimeString);
	}
	
	printf("logPathFileName = %s\n",logPathFileName);
	
	sprintf(siteMessage2,"%s",logPathFileName);
	
	LogWriteOutput("COM_RAR","main",siteMessage2);
	// log : main : end
	LogWriteEnd("COM_RAR", "main");
	printf("rrc program done\n");
	// close log file
	LogCloseFile();
	return 0;
}
