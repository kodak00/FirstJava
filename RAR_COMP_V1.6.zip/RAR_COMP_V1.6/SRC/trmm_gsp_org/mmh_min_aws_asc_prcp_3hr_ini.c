/********************************************************************
 * Make 1-min prcp. data from AWS 1-min binary data                 * 
 ********************************************************************
 * INPUT: AWS 1-min binary data                                     * 
 *                                                                  *
 * PROCESS: Making the 1-min precipitation data about working AWS   *
 *                                                                  *
 * OUTPUT: 1-min asc data  from available AWS                       *
 *                                                                  *
 ********************************************************************
 * AUTHOR: Kyung-Yeub Nam (kynam@metri.re.kr)                       *
 *         - latest version completed 15 Sep. 2002                  *
 ********************************************************************
 * NOTICE: This version is working on the Linux machine             *
 *         (little_endian machine)                                  *
 ********************************************************************/

#include <locale.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define debug		1	/* 1 is for debug  for QC aws data*/
#define debug1		0	/* 1 is for debug1 for raws aqs data*/
#define awsdb_len	28
#define awsdb_num	1000
#define set_end_hxm     180     /* 60 min x 3 hour */
#define unit		5	/* one tip (0.5 mm)  */
#define acc_int		1	/* accumulated rainfoll interval */
#define missing		-99.0	/* missing value */

#define NUM_AWS         1000
#define AWS_DATA_dnum   29
#define set_end_hxm2    60      /* 60 min */

#define ERROR1        -999     /* �ڷ� ���� */
#define ERROR2        -998     /* ���� �̻� */
#define ERROR3        -997     /*   �̻�    */
#define ERROR4        -996     /*           */
#define ERROR5        -996     /*           */

struct TIMES
{ short YY;
  char  MM;
  char  DD;
  char  HH;
  char  MI;
};

struct AWS_DATA
{ short   aws_id;
  short   lau_id;
  struct  TIMES aws_tm;
  struct  TIMES lau_tm;
  struct  TIMES rec_tm;
  short   d[AWS_DATA_dnum];
  int     qc[4];
};


double time_calc(idate,int_hour,int_min)
     double idate;
     int    int_hour, int_min;
{
     double odate;
     int year,mon,day,hour,min;
     int ddate,i,leap,leap2,leap3;
     int month[13]={0, 31,28,31,30,31,30,31,31,30,31,30,31};



     year=idate/100000000.;
     mon=idate/1000000.;   mon=mon%100;
     day=idate/10000.;     day=day%100;
     hour=idate/100.;      hour=hour%100;
     ddate=idate/100.;     min=idate-(ddate)*100.;

     min=min+int_min;
     hour=min/60 + hour;

     if(min < 0 && min%60 != 0)
     {
        min = 60 + min%60;
        hour= hour -1;
     }
     else if( min < 0 && min%60 == 0) 
     {
        min = min %60;
     }
     else
     {
        min = min%60;
     }

     hour = hour + int_hour;
     day = hour/24 + day;

     if(hour < 0 && hour%24 != 0)
     {
        hour = 24 + hour%24;
        day  = day - 1;
     }
     else
     {
       hour = hour%24;
     }

     leap = year%4;
     leap2= year%100;
     leap3= year%400;
     
     if(leap == 0){
        month[2] = 29;
        if(leap2 == 0){
           month[2] = 28;
        }
        if(leap3 == 0){
           month[2] = 29;
        }
     }

     i = 0;
     while(i < 1000){
      if(day > month[mon]){
         day = day - month[mon-1];
         mon = mon + 1;
         if(mon > 12){
            mon   = mon - 12;
            year  = year + 1;
            leap  = year%4;
            leap2 = year%100;
            leap3 = year%400;
            if(leap == 0){
               month[2] = 29;
               if(leap2 == 0){
                  month[2] = 28;
               }
               if(leap3 == 0){
                  month[2] = 29;
               }
            }
         } 
      } else if(day <=0){
        mon = mon - 1;
        if(mon <= 0){
           mon   = 12;
           year  = year - 1;
           leap  = year%4;
           leap2 = year%100;
           leap3 = year%400;
           if(leap == 0){
              month[2] = 29;
              if(leap2 == 0){
                 month[2] = 28;
              }
              if(leap3 == 0){
                 month[2] = 29;
              }
           }
        }
        day = month[mon] + day;
      } 
      else{
           odate=year*100000000.+mon*1000000.+day*10000.+hour*100.+min;
           return odate;
      }
      i = i + 1;
    }
}       

//* ----------------------------------------------------------------------
main(argc,argv)
    int argc;
    char *argv[];
{
    struct AWS_DATA aws;

    int i,j,k,l,loop,ll,mm,jj,countt;
    int n,ns,ne,ze_int;
    int aws_id,ich,ihm,ifirst;
    int awsdb_rnum,max_prcp,min_prcp;
    int aws_prcp[set_end_hxm][1000],aws_sens[set_end_hxm][1000];
    int YY[set_end_hxm][1000],MM[set_end_hxm][1000],DD[set_end_hxm][1000];
    int HH[set_end_hxm][1000],MI[set_end_hxm][1000],AWS_IDD[set_end_hxm][1000];
    int old_prcp,new_prcp,diff_prcp;
    int old_int,new_int,diff_int,iacc_prcp,max_prcp_int;
    int ihr,imin,isec,iyear,imon,iday;
    int iihr,iimin,set_end_hxm3,iiday,ipday;
    int jm,imhr,immin,awss;

    int year,mon,day,hour,min,ddate;

    float aws_info[awsdb_num][3]; 
    float sum_prcp[set_end_hxm][1000];
    float aws_t1,aws_t2,aws_t3,fdate;
    float summ_prcp;

    double idate,odate;

    FILE *f,*f2,*f3, *f4;
    
    char file[120],file2[120],file3[120],file4[120];
    char aws_info_file[1024];

    if (argc < 3)
    {
	    printf("wrong parameter!!!\n");
	    return 1;
    }

    sprintf(aws_info_file,"%s%s",argv[2],"RES/aws_position/aws_info.new.txt");
    printf("%s\n",aws_info_file);

    f=fopen(aws_info_file,"r"); 

    for(i=0;i<awsdb_num;i++){
        aws_info[i][0]=-999;
        aws_info[i][1]=-999;
        aws_info[i][2]=-999;
    }
    i=0;
    while(fscanf(f,"%d %f %f %f",&aws_id,&aws_t1,&aws_t2,&aws_t3) != EOF){
        aws_info[i][0]=(float) aws_id;
        aws_info[i][1]=aws_t1;
        aws_info[i][2]=aws_t2;
        i+=1;
    }
    awsdb_rnum = i;
    fclose(f);

    printf("\n read aws information data\n");

    for(i=0;i<set_end_hxm;i++){
        for(j=0;j<1000;j++){
                aws_prcp[i][j]=-999;
                aws_sens[i][j]=-999;
        }
    }

//* ---------------------------------------------------------------------
    set_end_hxm3=iimin;     
    if((iihr*60+set_end_hxm3) > set_end_hxm) set_end_hxm3=60;
    if(set_end_hxm3>60) {iimin=set_end_hxm3%60;iihr=iihr+1;}
//*    printf("\n aa bb\n",set_end_hxm,set_end_hxm3);
//* ---------------------------------------------------------------------
    idate=atof(argv[1]);

    year=idate/100000000.;
    mon=idate/1000000.;   mon=mon%100;
    day=idate/10000.;     day=day%100;
    hour=idate/100.;      hour=hour%100;
    ddate=idate/100.;     min=idate-(ddate)*100.;

    printf("\n%f\n",idate);
    printf("\nDate(YYYY MM DD HH MM) : %d %d %d %d %d \n",year,mon,day,hour,min);

    sprintf(file,"%sDATA/AWS/org/AWS_RAW_%4.4d%2.2d%2.2d%2.2d%2.2d",argv[2],year,mon,day,hour,min);
    
    sprintf(file4,"%sDATA/AWS/trmm_gsp/AWS_TMP_%s",argv[2],argv[1]);
    printf(" write the temp aws data : %s \n",file4);
	f4=fopen(file4,"w");
    
    
    if ((f=fopen(file,"r"))!=NULL) {
        while (fscanf(f, "%d#%d#", &(aws.aws_id), &(aws.lau_id)) != EOF)
        {
        	   fprintf(f4, "%d,%d,", aws.aws_id, aws.lau_id);
        	   
               if( aws.aws_id == 229)break;
               fscanf(f, "%04d.%02d.%02d.%02d:%02d#", &(aws.aws_tm.YY), &(aws.aws_tm.MM), &(aws.aws_tm.DD), &(aws.aws_tm.HH), &(aws.aws_tm.MI));
               fscanf(f, "%04d.%02d.%02d.%02d:%02d#", &(aws.lau_tm.YY), &(aws.lau_tm.MM), &(aws.lau_tm.DD), &(aws.lau_tm.HH), &(aws.lau_tm.MI));
               fscanf(f, "%04d.%02d.%02d.%02d:%02d#", &(aws.rec_tm.YY), &(aws.rec_tm.MM), &(aws.rec_tm.DD), &(aws.rec_tm.HH), &(aws.rec_tm.MI));
			   
			   fprintf(f4, "%04d.%02d.%02d.%02d:%02d,", aws.aws_tm.YY, aws.aws_tm.MM, aws.aws_tm.DD, aws.aws_tm.HH, aws.aws_tm.MI);
        	   fprintf(f4, "%04d.%02d.%02d.%02d:%02d,", aws.lau_tm.YY, aws.lau_tm.MM, aws.lau_tm.DD, aws.lau_tm.HH, aws.lau_tm.MI);
        	   fprintf(f4, "%04d.%02d.%02d.%02d:%02d,", aws.rec_tm.YY, aws.rec_tm.MM, aws.rec_tm.DD, aws.rec_tm.HH, aws.rec_tm.MI);
			   	
               for (j = 0; j < AWS_DATA_dnum; j++){ fscanf(f, "%d#", &(aws.d[j]));}
               
               for (j = 0; j < AWS_DATA_dnum; j++){ fprintf(f4, "%d,", aws.d[j]);}
               
               for (j = 0; j < 3; j++){fscanf(f, "%d#", &(aws.qc[j]));}
               
               for (j = 0; j < 3; j++){fprintf(f4, "%d,", aws.qc[j]);}
               
               fscanf(f, "%d#=", &(aws.qc[3]));
               
               fprintf(f4, "%d\n", aws.qc[3]);

               j=(int) aws.aws_id;
               ihr=(int) aws.aws_tm.HH;
               imin=(int) aws.aws_tm.MI;
               aws_prcp[i][j]=(int) aws.d[12];
               aws_sens[i][j]=(int) aws.d[9];

               YY[i][j]=(int) aws.aws_tm.YY;
               MM[i][j]=(int) aws.aws_tm.MM;
               DD[i][j]=(int) aws.aws_tm.DD;
               HH[i][j]=(int) aws.aws_tm.HH;
               MI[i][j]=(int) aws.aws_tm.MI;
               AWS_IDD[i][j]=(int) aws.aws_id;
               
        }
        fclose(f);
        fclose(f4);
    }
}