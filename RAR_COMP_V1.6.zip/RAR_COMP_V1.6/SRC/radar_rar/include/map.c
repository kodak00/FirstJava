/**
 * @file map.c
 * @brief ���� ���� �б� �Լ��� ��ϵ� ����
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include <stdlib.h>
#include "radar_rar.h"

#define MAPPING_TABLE_FILE_EXT "kmt"

/**
 * @brief �� ����Ʈ�� ���� �ڷḦ ����.
 * @param site_index �� ����Ʈ�� �ε���
 * @return  ������ 1: ����, 1�̿��� ����: ����
 * @author �豤ȣ
 */
int readSiteMappingTable(int siteIndex)
{
	int xdim;
	int ydim;
	int i;
	int x;
	int y;
	char mappintTableFileName[MAX_STRING_LENGTH];
	
	FILE* pfp;

	sprintf(mappintTableFileName, "%sRES/mapping_table/%s.%s", g_option.pprogramRootPath, g_site[siteIndex].pname, MAPPING_TABLE_FILE_EXT);

	if ((pfp = fopen(mappintTableFileName, "r")) == NULL)
		return -15001;

	fread(&xdim, sizeof(int), 1, pfp);
	fread(&ydim, sizeof(int), 1, pfp);

	if (littleEndian())
	{
		swap4Bytes(&xdim);
		swap4Bytes(&ydim);
	}

	g_site[siteIndex].pmapTable = malloc(ydim * sizeof(MAP_TABLE *));
	
	for (i = 0 ; i < ydim ; i++ )
	{
		g_site[siteIndex].pmapTable[i] = malloc(ydim * sizeof(MAP_TABLE));
	}

	for (i = 0 ; i < ydim ; i++ )
	{
		fread(g_site[siteIndex].pmapTable[i], sizeof(MAP_TABLE), xdim, pfp);
	}

	if (littleEndian())
	{
		for (y = 0 ; y < ydim ; y++)
		{
			for (x = 0 ; x < xdim ; x++)
			{
				swap4Bytes(&(g_site[siteIndex].pmapTable[y][x].x));
				swap4Bytes(&(g_site[siteIndex].pmapTable[y][x].y));
				swap4Bytes(&(g_site[siteIndex].pmapTable[y][x].dist));
			}
		}
	}
	
	fclose(pfp);

	g_site[siteIndex].xdim = xdim;
	g_site[siteIndex].ydim = ydim;

	for (y = 0 ; y < g_site[siteIndex].ydim  ; y++)
	{
		for (x = 0 ; x < g_site[siteIndex].xdim  ; x++)
		{
			if (g_site[siteIndex].pmapTable[y][x].x < 0 || g_site[siteIndex].pmapTable[y][x].y < 0) continue;

			if (g_site[siteIndex].pmapTable[y][x].inBound == MAP_VALUE_RANGE_IN)
			{
				g_site[siteIndex].inBound[g_site[siteIndex].pmapTable[y][x].y][g_site[siteIndex].pmapTable[y][x].x] = MAP_VALUE_RANGE_IN;
			}
			if (g_site[siteIndex].pmapTable[y][x].inBound == MAP_VALUE_RADAR_POSITION)
			{
				g_site[siteIndex].inBound[g_site[siteIndex].pmapTable[y][x].y][g_site[siteIndex].pmapTable[y][x].x] = MAP_VALUE_RADAR_POSITION;
			}
			if (g_site[siteIndex].pmapTable[y][x].dist > 0)
			{
				g_site[siteIndex].dist[g_site[siteIndex].pmapTable[y][x].y][g_site[siteIndex].pmapTable[y][x].x] = g_site[siteIndex].pmapTable[y][x].dist;
			}
		}
	}
	
	return 1;
}

/**
 * @brief �ռ����� ������ ����
 * @return  ������ 1: ����, 1�̿��� ����: ����
 * @author �豤ȣ
 */
int readCompositionMapV4()
{
	FILE* pfp;
	int y;
	COMP_MAP_HEAD CMH;

	char compositionMapPathFileName[MAX_STRING_LENGTH];

	sprintf(compositionMapPathFileName, "%sRES/mapping_table/%s", g_option.pprogramRootPath, g_option.pcompositionMapFileName1km);
	if ((pfp = fopen(compositionMapPathFileName, "r")) == NULL)
		return -15002;

	//��� �б�
	fread(&CMH, sizeof(COMP_MAP_HEAD), 1, pfp);
	if (littleEndian())
	{
		swap4Bytes(&CMH.version);
		swap4Bytes(&CMH.xdim);
		swap4Bytes(&CMH.ydim);
		swap4Bytes(&CMH.xo);
		swap4Bytes(&CMH.yo);
		swap4Bytes(&CMH.grid);
	}

	if (CMH.version != (int)MAP_TABLE_VERSION)
	{
		fprintf(stderr, "composition map version and mapping taable version is not equal.\n");
		return -97348;
	}
	if (CMH.xdim != XDIM || CMH.ydim != YDIM || CMH.grid != 1)
	{
		fprintf(stderr, "wrong composition map file(%s) or wrong composition data file\n", compositionMapPathFileName);
		return -97349;
	}
	for (y = 0 ; y < YDIM ; y++)
	{
		fread(g_composition.inBound[y], sizeof(char), XDIM, pfp);
	}
	for (y = 0 ; y < YDIM ; y++)
	{
		fread(g_composition.mapData[y], sizeof(char), XDIM, pfp);
	}

	fclose(pfp);

	return 1;
}

/**
 * @brief �ռ� ���� ���� ����(COMPOSITION.mapData)-create_comp_map���� ����
 * @param pcomposition2km �ռ����� ����ü
 * @return  ������ 1: ����, 1�̿��� ����: ����
 * @author �豤ȣ
 */
int readCompositionMap2kmV4(COMPOSITION_2KM* pcomposition2km)
{
	FILE* pfp;
	int y;
	COMP_MAP_HEAD CMH;

	char compositionMapPathFileName[MAX_STRING_LENGTH];

	sprintf(compositionMapPathFileName,"%sRES/mapping_table/%s",g_option.pprogramRootPath,g_option.pcompositionMapFileName2km);
	if ((pfp = fopen(compositionMapPathFileName,"r")) == NULL)
		return -15002;

	//��� �б�
	fread(&CMH,sizeof(COMP_MAP_HEAD),1,pfp);
	if (littleEndian())
	{
		swap4Bytes(&CMH.version);
		swap4Bytes(&CMH.xdim);
		swap4Bytes(&CMH.ydim);
		swap4Bytes(&CMH.xo);
		swap4Bytes(&CMH.yo);
		swap4Bytes(&CMH.grid);
	}

	if (CMH.version != (int)MAP_TABLE_VERSION)
	{
		fprintf(stderr,"composition map version and mapping taable version is not equal.\n");
		return -97348;
	}
	if (CMH.xdim != XDIM_2 || CMH.ydim != YDIM_2 || CMH.grid != 2)
	{
		fprintf(stderr,"wrong composition map file(%s) or wrong composition data file\n",compositionMapPathFileName);
		return -97349;
	}
	for (y = 0 ; y < YDIM_2 ; y++)
	{
		fread(pcomposition2km->inBound[y],sizeof(char),XDIM_2,pfp);
	}
	for (y = 0 ; y < YDIM_2 ; y++)
	{
		fread(pcomposition2km->mapData[y],sizeof(char),XDIM_2,pfp);
	}

	fclose(pfp);

	return 1;
}

