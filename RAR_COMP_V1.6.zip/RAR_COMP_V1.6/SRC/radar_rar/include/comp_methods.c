/**
 * @file comp_methods.c
 * @brief ��ø������ �ռ� ����� ��ϵ� ����
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include "radar_rar.h"

/**
 * @brief ��ø������ �ִ� �ռ�
 * @return ������ 1: ����
 * @author �豤ȣ
 */
int maxCompQPE()
{
	int x;
	int y;
	int s;
	float maxValue;

	for (y = 0 ; y < YDIM ; y++ )
	{
		for (x = 0 ; x < XDIM ; x++ )
		{
			maxValue = BAD_VALUE_F;
			for (s = 0 ; s < g_option.siteCount ; s++ )
			{

				if (g_site[s].done < STATUS_MATRIX) continue;

				if (g_site[s].rainData[y][x] == BAD_VALUE_F) continue;

				if (g_site[s].inBound[y][x] == MAP_VALUE_RANGE_OUT) continue;

				if ((maxValue < g_site[s].rainData[y][x]))
				{
					maxValue = g_site[s].rainData[y][x];
				}
			}
			g_composition.data[y][x] = maxValue;
		}
	}

	return 1;
}

/**
 * @brief ��ø������ ��հ� �ռ�
 * @return ������ 1: ����
 * @author �豤ȣ
 */
int averageCompQPE()
{
	int x;
	int y;
	int s;
	double sumValueR;
	int count;
	FILE* pfv;
	float acc;
	float bias;
	float pod;
	float far;
	float csi;
	float me;
	float mae;
	float mse;
	float rmse;
	float corr;
	float AWSMean;
	float radarMean;
	float GR;
	float dd;
	int AWSCount;
	int availableAWSNum;
	char file[512];

	// +++ R/G correction ���� �б� +++++++++++
	sprintf(file,"%sDATA/TXT/VERI_SP/vsca0_%s.txt",g_option.pprogramRootPath,g_option.datetimeString); 
	printf("%sDATA/TXT/VERI_SP/vsca0_%s.txt\n",g_option.pprogramRootPath,g_option.datetimeString); 
	
	acc =-9999.;
	bias=-9999.;
	pod =-9999.;
	far =-9999.;
	csi =-9999.;
	me  =0.;
	mae =-9999.;
	mse =-9999.;
	rmse=-9999.;
	corr=-9999.;
	AWSMean  =-9999.;
	radarMean=-9999.;
	AWSCount=0;
	availableAWSNum=0;
	
	if((pfv=fopen(file,"r"))!=NULL)
	{
	     fscanf(pfv,"ACC %f\n",&acc);
	     fscanf(pfv,"BIAS %f\n",&bias);
	     fscanf(pfv,"POD %f\n",&pod);
	     fscanf(pfv,"FAR %f\n",&far);
	     fscanf(pfv,"CSI %f\n",&csi);
	     fscanf(pfv,"ME %f\n",&me);
	     fscanf(pfv,"MAE %f\n",&mae);
	     fscanf(pfv,"MSE %f\n",&mse);
	     fscanf(pfv,"RMSE %f\n",&rmse);
	     fscanf(pfv,"CORR %f\n",&corr);
	     fscanf(pfv,"AWS_MEAN %f\n",&AWSMean);
	     fscanf(pfv,"RADAR_MEAN %f\n",&radarMean);
	     fscanf(pfv,"AVAILABLE_AWS %d %d\n",&AWSCount,&availableAWSNum);
	     fclose(pfv);
	}
	
	GR = 1.;
	if((AWSMean > 0) && (radarMean > 1)){
	
	   	GR=AWSMean/radarMean;
	}
	
	if(me == -9999.)me=0.;
	printf("%f %f %f %f %f %f %f %f %f %f %f %f %f\n",acc,bias,pod,far,csi,me,mae,mse,rmse,corr,AWSMean,radarMean,GR);
	printf("%d %d \n",AWSCount,availableAWSNum);

	for (y = 0 ; y < YDIM ; y++ ){
		for (x = 0 ; x < XDIM ; x++ ){
			sumValueR = 0.;
			count = 0;
			for (s = 0 ; s < g_option.siteCount ; s++ ){

				if (g_site[s].done < STATUS_MATRIX) continue;

				if (g_site[s].rainData[y][x] == BAD_VALUE_F) continue;

				if (g_site[s].rainData[y][x] <= 0.1) continue;

				if (g_site[s].inBound[y][x] == MAP_VALUE_RANGE_OUT) continue;

				sumValueR += g_site[s].rainData[y][x];
				count ++;
			}
			if (count > 0)
			{
				g_composition.data[y][x] = (sumValueR/(count * 1.))*GR;
              dd=count%2;
			}else
			{
				g_composition.data[y][x] = BAD_VALUE_F;
			}
		}
	}

	return 1;
}

/**
 * @brief ��ø������ �ٰŸ� �ռ�
 * @return ������ 1: ����
 * @author �豤ȣ
 */
int nearCompQPE()
{
	int x;
	int y;
	int s;
	int dist;
	int siteIndex;

	for (y = 0 ; y < YDIM ; y++ ){
		for (x = 0 ; x < XDIM ; x++ ){
			dist = 999000;
			siteIndex = -1;
			for (s = 0 ; s < g_option.siteCount ; s++ ){

				if (g_site[s].done < STATUS_MATRIX) continue;

				if (g_site[s].rainData[y][x] == BAD_VALUE_F) continue;

				if (g_site[s].inBound[y][x] == MAP_VALUE_RANGE_OUT) continue;

				if (dist > g_site[s].dist[y][x])
				{
					dist = g_site[s].rainData[y][x];
					siteIndex = s;
				}
			}
			if (siteIndex >= 0)
			{
				g_composition.data[y][x] = g_site[siteIndex].rainData[y][x];
			}else
				g_composition.data[y][x] = BAD_VALUE_F;
		}
	}

	return 1;
}

/**
 * @brief ��ø������ �Ÿ����� �ռ�
 * @return ������ 1: ����
 * @author �豤ȣ
 */
int distWeightCompQPE()
{
	int x;
	int y;
	int s;
	int dist[MAX_RADAR_SITE_COUNT];
	float rainData[MAX_RADAR_SITE_COUNT];
	int siteCount;
	float tempFloat;
	float denominator;
	float numerator;

	for (y = 0 ; y < YDIM ; y++ ){
		for (x = 0 ; x < XDIM ; x++ ){
			siteCount = 0;
			for (s = 0 ; s < g_option.siteCount ; s++ )
			{

				if (g_site[s].done < STATUS_MATRIX) continue;

				if (g_site[s].rainData[y][x] == BAD_VALUE_F) continue;

				if (g_site[s].inBound[y][x] == MAP_VALUE_RANGE_OUT) continue;

				if (g_site[s].dist[y][x] < 0) continue;

				dist[siteCount] = g_site[s].dist[y][x];
				rainData[siteCount] = g_site[s].rainData[y][x];
				siteCount++;
			}
			
			if (siteCount == 1)
			{
				g_composition.data[y][x] = rainData[0];
			}else if (siteCount > 0)
			{
				tempFloat = 0.;
				for (s = 0 ; s < siteCount ; s++ ){
					tempFloat += 1 / (dist[s] * 1.);
				}
				denominator = tempFloat;

				tempFloat = 0.;
				for (s = 0 ; s < siteCount ; s++ ){
					tempFloat += rainData[s] / (dist[s] * 1.);
				}
				numerator = tempFloat;

				g_composition.data[y][x] = numerator/denominator;
			}else
				g_composition.data[y][x] = BAD_VALUE_F;
		}
	}

	return 1;
}
