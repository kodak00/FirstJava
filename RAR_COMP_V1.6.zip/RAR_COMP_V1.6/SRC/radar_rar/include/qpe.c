/**
 * @file qpe.c
 * @brief �������� �ռ��췮 �������� QPE�� �����ϴ� �Լ�.
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "radar_rar.h"
#include "function.h"
#include "aws.h"
#include "radar.h"

//#define PRINT_DEBUG //KKH
//#define PRINT_AWS_PAIR_LIST

#define LEAST_SQUARES_DEGREE 1	// ���Ϸ��� �Լ��� ����

#define MARSHALL_PALMER_ZR_A 200
#define MARSHALL_PALMER_ZR_B 1.6

//ROUTE_AUTO_ZR  route : 0
static int processAutoZR(int siteIndex);
//New_ZR
static int processNewZR(int siteIndex, ZR_VALUE* pzr);
//Prev_ZR  route : 1
static int processPrevZR(int siteIndex);
//Marshall-Palmer relationship (200,1.6)  route : 2
static int processMarshallPalmerZR(int siteIndex);
//radar aws pair����
static int makeRadarAWSPair(int siteIndex, float zrA, float zrB);
//radar 3x3 ���� ��� �� ����
static float getRadar3x3MinumumDiffDBZ(KRL_RADAR cappi, AWS aws, int xdim, int ydim, float zrA, float zrB,int obsTimeIndex);
//AWS QC
static int AWSQC(AWS* paws, int siteCount);
//least squares method
//static int  lstsq(double x[], double y[], int n, int number,double* pA, double* pB);
//Least Square Fit of Power Law Equation
static int lsplfit(int n, double* px, double* py, double* pa, double* pb);
//ǥ������ [standard deviation]
static double stdevValue(double value[], int number, double ave);
//���
static double aveValue(double value[], int number);
//������ [coefficient of correlation]
static double corrValue(double x[], double y[], int number);
//���� ZR�� �б�
static ZR_VALUE readPrevZR(char* psiteInitial, int usefulPrevZRPeriodMinutes, int fixRoute); //KKH add fixRoute
//���� ZR�� �б�
static ZR_VALUE readPastZR(char* psiteInitial, int beforeMinutes, int fixRoute); //KKH add fixRoute
//�� ZR ����
static int writeNowZR(char* psiteInitial, ZR_VALUE nowZR, int totalAWS, int rainAWS, int fixRoute); //KKH add fixRoute
//���� ZR����� ���찭�� ���
static int rainfallEstimation(int siteIndex, int fixRoute); //KKH add fixRoute
//��밡���� aws �� pair�� ���
static int checkAvailableAWS(AWS* paws, int AWSCount, int* pavailableAWSCount, int* pavailablePairCount);
//bubble sort
static int sort(double* parr, int count);
static int checkArealRadar(int siteIndex, int* totalRadarArealDBZ2, int* totalAWSRadarPairCount);
static int sumArealRadarDBZ(KRL_RADAR cappi, AWS aws, int xdim, int ydim, int obsTimeIndex);


/**
 * @brief AWS�� �����ϴ� ������ ���� RADAR�� QPE�� �����ϴ� �Լ�
 * @param siteIndex ���̴� ����Ʈ �ε���
 * @return ������ 1: ����
 * @author �豤ȣ
 */
int radarQPEWithAWS(int siteIndex)
{
	int i;
	int ERROR_CODE;

	int foundZR = 0;

	int fixRoute;	//parent site�� ���� ��� fixRoute�� �����ϱ� ���Ͽ� ���(g_optionQPE.fixRoute �����ϸ� �ٸ��� ������ ��ħ)

	if ((g_optionQPE.fixRoute == ROUTE_AUTO_ZR) && (g_site[siteIndex].ZRRouteInAutoZR != ROUTE_AUTO_ZR))
	{
		fixRoute = g_site[siteIndex].ZRRouteInAutoZR;
	}
	else
	{
		fixRoute = g_optionQPE.fixRoute;
	}

	printf("-------------------------%d %d %d\n",g_optionQPE.fixRoute,g_site[siteIndex].ZRRouteInAutoZR,fixRoute);

	if (g_site[siteIndex].done < STATUS_PRODUCT)
		return -9999;
		
	/*******************************************
		����Ʈ�� AWS ���� ���� �б�
	*******************************************/
	if ((ERROR_CODE = readAWSPosition(siteIndex)) < 0)
	{
		fprintf(stderr,"! readAWSPosition() Error No.%d\n",ERROR_CODE);
		return ERROR_CODE;
	}
	
#ifdef PRINT_DEBUG
fprintf(stderr,"AAAAA\n");
#endif

	/*******************************************
		AWS ���췮 ���� �б�
	*******************************************/
	if ((ERROR_CODE = readAWSDataFile(siteIndex)) < 0)
	{
		fprintf(stderr,"! readAWSDataFile() Error No.%d\n",ERROR_CODE);
	}
	
#ifdef PRINT_DEBUG
fprintf(stderr,"BBBB\n"); 
#endif

	/*******************************************
		10���� ZR�б�
	*******************************************/
	g_site[siteIndex].prevZR = readPrevZR(g_site[siteIndex].pname,g_optionQPE.minUsefulPrevZRPeriodMinutes,fixRoute); //KKH add fixRoute
	if (g_site[siteIndex].prevZR.route < 0)
	{
		fprintf(stderr,"could not search effective prev zr file\n");
		g_site[siteIndex].prevZR.a = DEFAULT_ZR_A;
		g_site[siteIndex].prevZR.b = DEFAULT_ZR_B;
		g_site[siteIndex].prevZR.route = -1;
	}
	printf("[prev zr a : %f b: %f route = %d]\n",g_site[siteIndex].prevZR.a,g_site[siteIndex].prevZR.b,g_site[siteIndex].prevZR.route);
	
#ifdef PRINT_DEBUG
fprintf(stderr,"CCCC\n"); 
#endif

	/*******************************************
		���� ZR�б�
	*******************************************/
	for (i = 0 ; i < RADAR_OBS_NUMBER ; i++ )//50�� �� �α׺��� 10�� �� �α� ���� ����
	{
		g_site[siteIndex].pastZR[RADAR_OBS_NUMBER-i-1] = readPastZR(g_site[siteIndex].pname,i*10,fixRoute); //KKH add fixRoute
		if (g_site[siteIndex].pastZR[RADAR_OBS_NUMBER-i-1].route < 0)
		{
			g_site[siteIndex].pastZR[RADAR_OBS_NUMBER-i-1].a = DEFAULT_ZR_A;
			g_site[siteIndex].pastZR[RADAR_OBS_NUMBER-i-1].b = DEFAULT_ZR_B;
			g_site[siteIndex].pastZR[RADAR_OBS_NUMBER-i-1].route = -1;
		}
	}
	
#ifdef PRINT_DEBUG
fprintf(stderr,"DDDD\n"); 
#endif

	/*******************************************
		route�� ���� QPE ����
	*******************************************/
	switch (fixRoute)
	{
		//Route 0 : auto
		case ROUTE_AUTO_ZR :
			foundZR = processAutoZR(siteIndex);
			break;

		case PREV_ZR :
			if (g_site[siteIndex].prevZR.route < 0) break;//PREV ZR ���� ���� ���н� �Ѿ
			foundZR = processPrevZR(siteIndex);
			g_site[siteIndex].nowZR.route = PREV_ZR; 
			foundZR = 1;
			break;

		case M_P_ZR :
			foundZR = processMarshallPalmerZR(siteIndex);
			g_site[siteIndex].nowZR.route = M_P_ZR; 
			foundZR = 1;
			break;
	}
	
	//if (g_optionQPE.fixRoute == ROUTE_AUTO_ZR) //KKH �ּ�ó��
	//{
		if (writeNowZR(g_site[siteIndex].pname,g_site[siteIndex].nowZR,g_site[siteIndex].AWSCount,g_site[siteIndex].rainAWSCount,g_optionQPE.fixRoute) < 0) //KKH add fixRoute
		{
			fprintf(stderr,"zr file write error\n");
		}
	//}

#ifdef PRINT_DEBUG
fprintf(stderr,"EEEE\n"); 
#endif

	if (!foundZR)
	{
		fprintf(stderr,"!foundZR\n");
		return -9999;
	}
	else
	{
		printf("[ZR : a : %f , b : %f]\n",g_site[siteIndex].nowZR.a,g_site[siteIndex].nowZR.b);
	}
	
#ifdef PRINT_DEBUG
fprintf(stderr,"FFFF\n"); 
#endif

	//Rainfall Estimation by new Z-R
	if (rainfallEstimation(siteIndex,fixRoute) > 0) //KKH add fixroute parm 
	{
		g_site[siteIndex].done = STATUS_QPE_DONE;
	}
	else
	{
		fprintf(stderr,"rainfallEstimation error\n");
		return -9999;
	}
	
#ifdef PRINT_DEBUG
fprintf(stderr,"GGGG\n"); 
#endif

	freeAWSDataFile(g_site[siteIndex].pAWS);	//AWS ���췮 ���� �޸� ����
	g_site[siteIndex].pAWS = NULL;
	
#ifdef PRINT_DEBUG
fprintf(stderr,"HHHH\n"); 
#endif

	printf("\n");
	return 1;
}

/**
 * @brief AWS�� �������� �ʴ� ������ ���� RADAR�� QPE�� �����ϴ� �Լ�
 * @param siteIndex ���̴� ����Ʈ �ε���
 * @return ������ 1: ����
 * @author �豤ȣ
 */
int radarQPEWithoutAWS(int siteIndex)
{
	int i;
	int ERROR_CODE;

	int foundZR = 0;

	int parentRadar = 1;

	int fixRoute;	//parent site�� ���� ��� fixRoute�� �����ϱ� ���Ͽ� ���(g_optionQPE.fixRoute �����ϸ� �ٸ��� ������ ��ħ)

	if ((g_optionQPE.fixRoute == ROUTE_AUTO_ZR) && (g_site[siteIndex].ZRRouteInAutoZR != ROUTE_AUTO_ZR))
	{
		fixRoute = g_site[siteIndex].ZRRouteInAutoZR;
	}
	else
	{
		fixRoute = g_optionQPE.fixRoute;
	}
	printf("-------------------------%d %d %d\n",g_optionQPE.fixRoute,g_site[siteIndex].ZRRouteInAutoZR,fixRoute);

	/*******************************************
		���� ZR�б�
	*******************************************/
	g_site[siteIndex].prevZR = readPrevZR(g_site[siteIndex].pname,g_optionQPE.minUsefulPrevZRPeriodMinutes,fixRoute); //KKH add fixRoute
	if (g_site[siteIndex].prevZR.route < 0)
	{
		fprintf(stderr,"could not search effective prev zr file\n");
		g_site[siteIndex].prevZR.a = DEFAULT_ZR_A;
		g_site[siteIndex].prevZR.b = DEFAULT_ZR_B;
		g_site[siteIndex].prevZR.route = -1;
	}
	
	printf("[prev zr a : %f b: %f]\n",g_site[siteIndex].prevZR.a,g_site[siteIndex].prevZR.b);
	
#ifdef PRINT_DEBUG
fprintf(stderr,"IIII\n"); 
#endif

	/*******************************************
		���� ZR�б�
	*******************************************/
	for (i = 0 ; i < RADAR_OBS_NUMBER ; i++ )//50�� �� �α׺��� 10�� �� �α� ���� ����
	{
		g_site[siteIndex].pastZR[RADAR_OBS_NUMBER-i-1] = readPastZR(g_site[siteIndex].pname,i*10,fixRoute); //KKH add fixRoute
		if (g_site[siteIndex].pastZR[RADAR_OBS_NUMBER-i-1].route < 0)
		{
			g_site[siteIndex].pastZR[RADAR_OBS_NUMBER-i-1].a = DEFAULT_ZR_A;
			g_site[siteIndex].pastZR[RADAR_OBS_NUMBER-i-1].b = DEFAULT_ZR_B;
			g_site[siteIndex].pastZR[RADAR_OBS_NUMBER-i-1].route = -1;
		}
	}
	
#ifdef PRINT_DEBUG
fprintf(stderr,"JJJJ\n"); 
#endif

	/*******************************************
		parent ���̴� �ڷᰡ �ִ��� �˻�
	*******************************************/
	if (fixRoute == ROUTE_AUTO_ZR)
	{
		fprintf(stderr,"g_site[g_site[siteIndex].QPEParentRadarIndex].done = %d < %d(sizeof : %d %d) \n",g_site[g_site[siteIndex].QPEParentRadarIndex].done,STATUS_QPE_DONE,sizeof(g_site[g_site[siteIndex].QPEParentRadarIndex].done),sizeof(STATUS_QPE_DONE));
		if (g_site[g_site[siteIndex].QPEParentRadarIndex].done < STATUS_QPE_DONE)// || g_site[g_site[siteIndex].QPEParentRadarIndex].pAWS == NULL)//Parent radar�� ������ ��θ� PREV_ZR�� �Ѵ�.
		{
			printf(" Fail to load parent radar(use PrevZR/200,1.6) ");
			parentRadar = 0;
			if (g_site[siteIndex].prevZR.route >= 0)
			{
				fixRoute = PREV_ZR;
			}
			else
			{
				fixRoute = M_P_ZR;
			}
		}
	}
	
#ifdef PRINT_DEBUG
fprintf(stderr,"KKKK\n"); 
#endif

	//parent site�� �ʿ��� �͸� ó����.
	if (fixRoute == ROUTE_AUTO_ZR)
	{
		/*******************************************
			����Ʈ�� �ߺ� ���̴� ���� ���� �б�
		*******************************************/
		if ((ERROR_CODE = readORPPosition(siteIndex)) < 0)
		{
			fprintf(stderr,"! readORPPosition() Error No.%d\n",ERROR_CODE);
		}

		/*******************************************
			����Ʈ�� �ߺ� ���̴� ������ �б�
		*******************************************/
		if ((ERROR_CODE = setSiteORPData(siteIndex)) < 0)
		{
			fprintf(stderr,"! setSiteORPData() Error No.%d\n",ERROR_CODE);
			return ERROR_CODE;
		}
	}
	
#ifdef PRINT_DEBUG
fprintf(stderr,"LLLL\n"); 
#endif
	/*******************************************
		route�� ���� QPE ����
	*******************************************/
	switch (fixRoute)
	{
		//Route 0 : auto
		case ROUTE_AUTO_ZR :
			foundZR = processAutoZR(siteIndex);
			break;

		case PREV_ZR :
			foundZR = processPrevZR(siteIndex);
			g_site[siteIndex].nowZR.route = PREV_ZR; 
			foundZR = 1;
			break;

		case M_P_ZR :
			foundZR = processMarshallPalmerZR(siteIndex);
			g_site[siteIndex].nowZR.route = M_P_ZR; 
			foundZR = 1;
			break;

	}
	
	//if (g_optionQPE.fixRoute == ROUTE_AUTO_ZR) //KKH �ּ�ó��
	//{
		if (writeNowZR(g_site[siteIndex].pname,g_site[siteIndex].nowZR,-9999,-9999,g_optionQPE.fixRoute) < 0) //KKH add fixRoute
		{
			fprintf(stderr,"zr file write error\n");
		}
	//}
	
	if (!foundZR)
	{
		fprintf(stderr,"!foundZR\n");
		return -9999;
	}else
	{
		printf("[ZR : a : %f , b : %f]\n",g_site[siteIndex].nowZR.a,g_site[siteIndex].nowZR.b);
	}
	
#ifdef PRINT_DEBUG
fprintf(stderr,"MMMM\n"); 
#endif

	//Rainfall Estimation by new Z-R
	if (rainfallEstimation(siteIndex,fixRoute) > 0) //KKH add fixRoute parm
	{
		g_site[siteIndex].done = STATUS_QPE_DONE;
	}
	else
	{
		fprintf(stderr,"rainfallEstimation error\n");
		return -9999;
	}
	
#ifdef PRINT_DEBUG
fprintf(stderr,"NNNN\n"); 
#endif

	freeAWSDataFile(g_site[siteIndex].pAWS);	//AWS ���췮 ���� �޸� ����
	g_site[siteIndex].pAWS = NULL;
	
#ifdef PRINT_DEBUG
fprintf(stderr,"OOOO\n"); 
#endif

	printf("\n");

	return 1;
}

/**
 * @brief rain �ڷḦ ����ȭ ��
 * @param siteIndex ���̴� ����Ʈ �ε���
 * @return ���� ��� 1: ����
 * @author �豤ȣ
 */
int createMatrixData(int siteIndex)
{
	int xx;
	int yy;	//����Ʈ ���������� x,y
	int index;
	int x;
	int y;	//�ռ� ���������� x,y

	index = 0;

	if (g_site[siteIndex].rainKRLRadar.pdata == NULL)
	{
		fprintf(stderr,"!!!!!!!!!!!!!!!!!!!!!!!!NULL\n");
		exit(0);
	}

	for (yy = 0 ; yy < g_site[siteIndex].ydim ; yy++ )
	{
		for (xx = 0 ; xx < g_site[siteIndex].xdim ; xx++ )
		{
			x = g_site[siteIndex].pmapTable[yy][xx].x;
			y = g_site[siteIndex].pmapTable[yy][xx].y;
			if (( x >= 0) && ( y >= 0 ))
			{
				g_site[siteIndex].rainData[y][x] = g_site[siteIndex].rainKRLRadar.pdata[index];	
			}
			index++;
		}
	}
	g_site[siteIndex].done = STATUS_MATRIX;

	return 1;
}

/**
 * @brief �������� QPE ����� ����Ҷ� �޸� �ʱ�ȭ(pKRLRadar.data �ʱ�ȭ)
 * @param siteIndex ���̴� ����Ʈ �ε���
 * @return ������ 1: ����
 * @author �豤ȣ
 */
int freeRainKRLRadar(int siteIndex)
{
	if (g_site[siteIndex].rainKRLRadar.pdata != NULL)
	{
		free(g_site[siteIndex].rainKRLRadar.pdata);
		g_site[siteIndex].rainKRLRadar.pdata = NULL;
	}

	return 1;
}

/**
 * @brief ���̴��� AWS �ڷ��� pair ����
 * @param siteIndex ���̴� ����Ʈ �ε���
 * @param ZRA ZR ��� a
 * @param ZRB ZR ��� b
 * @return foundZR ���� ��� 1: ZR ��� ����, 0: ���� �ȵ�.
 * @author �豤ȣ
 */
static int makeRadarAWSPair(int siteIndex, float zrA, float zrB)
{
	int i;
	int j;
	int k;
	int x;
	int y;
	int AWSIndex;

	if (g_site[siteIndex].pastKRLRadar == NULL)
		return -73003;
	for (i = 0; i < g_site[siteIndex].AWSCount ; i++)
	{
		if (g_site[siteIndex].pAWS[i].use == 0)//aws�� ������� �������� �Ǿ� ������ PASS
			continue;
		x = g_site[siteIndex].pAWS[i].x;
		y = g_site[siteIndex].pAWS[i].y;
		
		for (j = 0; j < RADAR_OBS_NUMBER ; j++ )
		{
			if (g_site[siteIndex].pastKRLRadar[j].pdata == NULL)	//cappi������ ���� �������� PASS
				continue;

			if (g_site[siteIndex].pmapTable[y][x].inBound <= MAP_VALUE_RANGE_OUT) continue;

			for (k = 0 ; k < 10 ; k++ )
			{
				AWSIndex = j*10 + k;
				if (g_site[siteIndex].pAWS[i].use1min[AWSIndex] == 0)//aws�� ������� �������� �Ǿ� ������ PASS
					continue;

				g_site[siteIndex].pAWS[i].radarDBZ[j*10 + k] = getRadar3x3MinumumDiffDBZ(
					g_site[siteIndex].pastKRLRadar[j],g_site[siteIndex].pAWS[i],
					g_site[siteIndex].xdim,g_site[siteIndex].ydim,zrA,zrB,AWSIndex);
			}
		}
	}

	return 1;
}

/**
 * @brief ���̴� 3*3 ���� �� AWS ���췮�� ���� ���� ���� ���� ���̴� ���ڰ��� ��ȯ�ϴ� �Լ�
 * @param RKL_RADAR cappi ���̴� �ڷ� ����ü
 * @param AWS aws AWS �ڷ� ����ü
 * @param xdim x�� ����
 * @param ydim y�� ����
 * @param ZRB ZR ��� a
 * @param ZRB ZR ��� b
 * @param obsTimeIndex AWS ���� Index
 * @return radarDBZ ���� ���� ���� ���� ���̴� ���ڰ�
 * @author �豤ȣ
 */
static float getRadar3x3MinumumDiffDBZ(KRL_RADAR cappi, AWS aws, int xdim, int ydim, float zrA, float zrB,int obsTimeIndex)
{
	int i;
	int j;
	float diffValue;
	float minDiff;
	int index;
	float radarDBZ;

	minDiff = 9999;

	radarDBZ = BAD_VALUE_F;

	for (i = -1 ; i <= 1 ; i++ )//y
	{
		for (j = -1 ; j <= 1 ; j++ )//x
		{
			index = (aws.y+i) * xdim + (aws.x+j);

			if (aws.x < 0 || aws.x >= xdim || aws.y < 0 || aws.y >= ydim) continue;
			if (cappi.pdata[index] == BAD_VALUE_F) continue;
			if (cappi.pdata[index] == OUT_VALUE_F) continue;
			diffValue = fabs(aws.rain1min[obsTimeIndex] - dBZToRF(cappi.pdata[index],zrA,zrB));
			if (minDiff > diffValue)
			{
				radarDBZ = cappi.pdata[index];
				minDiff = diffValue;
			}
		}
	}

	return radarDBZ;
}

/**
 * @brief �ִ�/�ּ� ������ ���� ���췮�� ���̴� �ݻ絵 ���͸�
 * @param aws paws ����ü
 * @param AWSCount AWS ����
 * @return ���� ��� 1: ����
 * @author �豤ȣ
 */
static int AWSQC(AWS* paws, int AWSCount)
{
	int i;
	int j;
	int foundRain;

	for (i = 0; i < AWSCount ; i++)
	{
		if (paws[i].use == 0)
			continue;

		foundRain = 0;
		for (j = 0 ; j < RADAR_PAIR_NUMBER ; j++ )
		{
			//AWS 10�� ���췮
			if (paws[i].rain1min[j] <= g_optionQPE.AWSMinThreshold)
			{
				paws[i].use1min[j] = 0;
				continue;
			}
			if (paws[i].rain1min[j] >= g_optionQPE.AWSMaxThreshold)
			{
				paws[i].use1min[j] = 0;
				continue;
			}

			//Radar dBZ
			if (paws[i].radarDBZ[j] <= g_optionQPE.dBZMinThreshold)
			{
				paws[i].use1min[j] = 0;
				continue;
			}
			if (paws[i].radarDBZ[j] >= g_optionQPE.dBZMaxThreshold)
			{
				paws[i].use1min[j] = 0;
				continue;
			}
			foundRain++;
		}
		if (foundRain == 0)
		{
			paws[i].use = 0;
		}
	}
	return 1;
}

/**
 * @brief �ڵ����� ZR ����� �����ϴ� �Լ�
 * @param siteIndex ���̴� ����Ʈ �ε���
 * @return foundZR ���� ��� 1: ZR ��� ����, 0 ����: ���� �ȵ�(����).
 * @author �豤ȣ
 */
static int processAutoZR(int siteIndex)
{
	int foundZR = 0;
	ZR_VALUE zr;
	int availableAWSCount;
	int availablePairCount;
	int i;
	int j;
	int k;
	int ERROR_CODE;
	
	int AWSRadarRatio;
	int totalAWSRadarPairCount; //KKH
	int totalRadarArealDBZ2; //KKH
	
	//#define PRINT_DEBUG
	
	zr.a = 200.;
	zr.b = 1.6;
	zr.a0 = 200.;
	zr.b0 = 1.6;
	zr.a1 = 200.;
	zr.b1 = 1.6;
	zr.route = -1;
	
#ifdef PRINT_DEBUG
fprintf(stderr,"ZZ1\n"); 
#endif

	//ù��°�� 200,1.6 �ι�°�� ù��° zr
	for (i = 0 ; i < MAX_FIND_NEW_ZR_NUMBER ; i++ )
	{
		//�ʱ�ȭ
		for (j = 0; j < g_site[siteIndex].AWSCount ; j++)
		{
			for (k = 0 ; k < RADAR_PAIR_NUMBER ; k++ )
			{
				g_site[siteIndex].pAWS[j].radarDBZ[k] = 0.;
				g_site[siteIndex].pAWS[j].use1min[k] = 1;
			}
			g_site[siteIndex].pAWS[j].use = 1;
		}
		
#ifdef PRINT_DEBUG
fprintf(stderr,"ZZ2\n"); 
#endif

		if ((ERROR_CODE = makeRadarAWSPair(siteIndex,zr.a,zr.b)) < 0)
		{
			fprintf(stderr,"! makeRadarAWSPair() Error No.%d\n",ERROR_CODE);
			return ERROR_CODE;
		}
		
#ifdef PRINT_DEBUG
fprintf(stderr,"ZZ3\n"); 
#endif
		//����Ʈ�� AWS QC
		if ((ERROR_CODE = AWSQC(g_site[siteIndex].pAWS,g_site[siteIndex].AWSCount)) < 0)
		{
			fprintf(stderr,"! AWSQC() Error No.%d\n",ERROR_CODE);
			return ERROR_CODE;
		}
		
#ifdef PRINT_DEBUG
fprintf(stderr,"ZZ4\n"); 
#endif

		//���� ������ AWS���� �ľ�
		checkAvailableAWS(g_site[siteIndex].pAWS, g_site[siteIndex].AWSCount, &availableAWSCount, &availablePairCount);
		checkArealRadar(siteIndex, &totalRadarArealDBZ2, &totalAWSRadarPairCount);

		if (totalAWSRadarPairCount == 0)
		{
			  AWSRadarRatio=0;
		}
		else AWSRadarRatio=totalRadarArealDBZ2/totalAWSRadarPairCount;
		
		g_site[siteIndex].AWSRadarRatio = AWSRadarRatio;
		g_site[siteIndex].totalARPairCount = totalAWSRadarPairCount;
		printf("print AWSRadarRatio = %d\n", AWSRadarRatio); //KKH

		#ifdef __MODIFY_RAR
		if ( AWSRadarRatio >= option.minRainDetectAWSNumberMOD)
		#else
		if (availableAWSCount >= g_site[siteIndex].minRainDetectAWSNumber)
		#endif
		{
			//New ZR
			if (processNewZR(siteIndex,&zr))
			{
				g_site[siteIndex].nowZR.a = zr.a;
				g_site[siteIndex].nowZR.b = zr.b;
				g_site[siteIndex].nowZR.a0 = zr.a0;
				g_site[siteIndex].nowZR.b0 = zr.b0;
				g_site[siteIndex].nowZR.a1 = zr.a1;
				g_site[siteIndex].nowZR.b1 = zr.b1;
				g_site[siteIndex].nowZR.thres = zr.thres;
				g_site[siteIndex].nowZR.route = zr.route;
				foundZR = 1;
				printf("ff %f %f %f %f %f %f %f %d\n",g_site[siteIndex].nowZR.a,g_site[siteIndex].nowZR.b,g_site[siteIndex].nowZR.a0,g_site[siteIndex].nowZR.b0, g_site[siteIndex].nowZR.a1,g_site[siteIndex].nowZR.b1,g_site[siteIndex].nowZR.thres,g_site[siteIndex].nowZR.route);
			}
			else
			{
				break;
			}
		}
		
#ifdef PRINT_DEBUG
fprintf(stderr,"ZZ5\n"); 
#endif

	}

	if (!foundZR)
	{
		//Prev ZR - route : 1
		
#ifdef PRINT_DEBUG
fprintf(stderr,"ZZ6\n"); 
#endif

		if (processPrevZR(siteIndex) > 0)
		{
			foundZR = 1;
			g_site[siteIndex].nowZR.route = PREV_ZR;
		}
		
#ifdef PRINT_DEBUG
fprintf(stderr,"ZZ7\n"); 
#endif

		//Marshall Palmer - route : 2
		if (foundZR < 1)
		{
			if (processMarshallPalmerZR(siteIndex) > 0)
			{
				foundZR = 1;
				g_site[siteIndex].nowZR.route = M_P_ZR;
			}
		}
		
#ifdef PRINT_DEBUG
fprintf(stderr,"ZZ7\n"); 
#endif

		if (foundZR < 1)
			return -73007;
	}

	return foundZR;
}

/**
 * @brief AWS - ���̴� �ڷḦ �̿��Ͽ� ���ο� ZR�� �����ϴ� �Լ�
 * @param siteIndex ���̴� ����Ʈ �ε���
 * @param zr ZR ��� ����ü
 * @return foundZR ���� ��� 1: ZR ��� ����, 0: ���� �ȵ�.
 * @author �豤ȣ
 */
static int processNewZR(int siteIndex, ZR_VALUE* pzr)
{
	int j;
	int k;
	int iterationCount;
	double*	pgoverR;
	double*	pgoverRdev;
	double* pdBR;
	double* px;
	double* py;
	double* px0;
	double* py0;
	double* px1;
	double* py1;
	double* pRMSE;
	double* pRMSE1;
	double stdev;
	double corr;
	double a;
	double b;//ZR���� a,b
	double a0;
	double a1;
	double b0;
	double b1;
	double ave;
	int foundZR = 0;
	int totalCount;
	int count;
	int availableAWS;
	int availablePair;
	int availablePosition;

	double* pxTemp;
	double* pyTemp;
    double* pxTempRMSE;
    double* pyTempRMSE;
	int availablePairTemp;
	char productTypeChar = ' '; //KKH
	
	#ifdef PRINT_AWS_PAIR_LIST
	FILE* pfp;
	char fileName[MAX_STRING_LENGTH];
	#endif

#ifdef PRINT_DEBUG
fprintf(stderr,"YY1\n"); 
#endif

	switch (g_option.productType) //KKH
	{
			case PRODUCT_PPI	: productTypeChar = 'P';	break;
			case PRODUCT_BASE	: productTypeChar = 'B';	break;
			case PRODUCT_CAPPI	: productTypeChar = 'C';	break;
	}

	totalCount = g_site[siteIndex].AWSCount;
	iterationCount = 1;
	checkAvailableAWS(g_site[siteIndex].pAWS, g_site[siteIndex].AWSCount,&availableAWS,&availablePairTemp);
	
	/*******************************************
		�ӽ� pair ����
	*******************************************/
	//�ӽ� �޸� �Ҵ�
	pxTemp = malloc(availablePairTemp * sizeof(double));
	pyTemp = malloc(availablePairTemp * sizeof(double));
    pxTempRMSE = malloc(availablePairTemp * sizeof(double));
    pyTempRMSE = malloc(availablePairTemp * sizeof(double));
	count = 0;
	
#ifdef PRINT_DEBUG
fprintf(stderr,"YY2\n"); 
#endif

	//�ӽ� pair ����
	#ifdef PRINT_AWS_PAIR_LIST
	sprintf(fileName,"%s/temp/rar_pair/%s_%s.nosort1.txt",g_option.pprogramRootPath,g_site[siteIndex].pname,g_option.datetimeString);
	pfp = fopen(fileName,"w");
	#endif
	
	for ( j = 0 ; j < g_site[siteIndex].AWSCount ; j++ )
	{
		if (!g_site[siteIndex].pAWS[j].use) continue;
		for (k = 0 ; k < RADAR_PAIR_NUMBER ; k++ )
		{
			if (!g_site[siteIndex].pAWS[j].use1min[k]) continue;

			pxTemp[count] = g_site[siteIndex].pAWS[j].rain1min[k];
			pyTemp[count] = g_site[siteIndex].pAWS[j].radarDBZ[k];

			pxTempRMSE[count] = g_site[siteIndex].pAWS[j].rain1min[k];
			pyTempRMSE[count] = g_site[siteIndex].pAWS[j].radarDBZ[k];
			
			#ifdef PRINT_AWS_PAIR_LIST
			fprintf(pfp," %03d %02d %f %f\n",g_site[siteIndex].pAWS[j].id,k,pxTemp[count],pyTemp[count]);
			#endif
			count++;
		}
	}
	
	#ifdef PRINT_AWS_PAIR_LIST
	fclose(pfp);
	#endif

#ifdef PRINT_DEBUG
fprintf(stderr,"YY3\n"); 
#endif
	/*******************************************
		sort
	*******************************************/
#ifdef PRINT_DEBUG
fprintf(stderr,"YY3-1\n"); 
#endif

	sort(pxTemp,availablePairTemp);
	sort(pyTemp,availablePairTemp);
	
#ifdef PRINT_DEBUG
fprintf(stderr,"YY4\n"); 
#endif

	#ifdef PRINT_AWS_PAIR_LIST
	sprintf(fileName,"%s/temp/rar_pair/%s_%s.sort1.txt",g_option.pprogramRootPath,g_site[siteIndex].pname,g_option.datetimeString);
	pfp = fopen(fileName,"w");
	for (j = 0 ; j < availablePairTemp ; j++)
	{
		fprintf(pfp," %f %f\n",pxTemp[j],pyTemp[j]);
	}
	fclose(pfp);
	#endif
	
	/*******************************************
		AWS�� x7mm���� pair���� ������ �ľ�
	*******************************************/
	//���� �ľ�
	availablePair = 0;
	availablePosition = -1;
	for (j = 0 ; j < availablePairTemp ; j++ )
	{
		if (pxTemp[j] >= g_optionQPE.minAWSRainrate )
		{
			if (availablePosition < 0)
			{
				availablePosition = j;
			}
			if (availablePosition >= 0)
			{
				availablePair++;
			}
		}
	}
	
#ifdef PRINT_DEBUG
fprintf(stderr,"YY5\n"); 
#endif

	printf("\n  | iteration | average | standard deviation | correlation |     a    |    b   | remind_aws | found |\n");
	while (iterationCount <= g_optionQPE.maxIterationNumber && availablePair >= g_optionQPE.minIterationAWSPairNumber)
	{
		//least squares�� ���� �迭 ����
		pgoverR = malloc(availablePair * sizeof(double));
		pgoverRdev = malloc(availablePair * sizeof(double));
		pdBR = malloc(availablePair * sizeof(double));
		px = malloc(availablePair * sizeof(double));
		py = malloc(availablePair * sizeof(double));
		px0 = malloc(availablePair * sizeof(double));
		py0 = malloc(availablePair * sizeof(double));
		px1 = malloc(availablePair * sizeof(double));
		py1 = malloc(availablePair * sizeof(double));
		pRMSE = malloc(9 * sizeof(double));
        pRMSE1 = malloc(9 * sizeof(double)); 

		//pair ����
		count = 0;
		for (j = availablePosition ; j < availablePairTemp ; j++ )
		{
			px[count] = log10(pxTemp[j]);
			py[count] = pyTemp[j];
			count++;
		}
		
#ifdef PRINT_DEBUG
fprintf(stderr,"YY6\n"); 
#endif

		#ifdef PRINT_AWS_PAIR_LIST
		sprintf(fileName,"%s/temp/rar_pair/%s_%s.sort2_%d.txt",g_option.pprogramRootPath,g_site[siteIndex].pname,g_option.datetimeString,iterationCount);
		pfp = fopen(fileName,"w");
		for (j = 0 ; j < availablePair ; j++)
		{
			fprintf(pfp," %f %f\n",pxTemp[j],pyTemp[j]);
		}
		fclose(pfp);
		#endif
		
		//�޸� ������ ���� �ӽ� px,py�޸� ����
		free(pxTemp);
		free(pyTemp);
		
#ifdef PRINT_DEBUG
fprintf(stderr,"YY7\n"); 
#endif

		//Least Square Fit of Power Law Equation
		#ifdef USE_LEAST_SQUARE_FIT_OF_POWER_LAW_EQUATION
		if (lsplfit(availablePair,px,py,&a,&b) == 1)
		{
			for (j = 0 ; j < availablePair ; j++)
			{
				pdBR[j] = a*pow(px[j],b);
				pgoverR[j] = pow(10.,0.1*(py[j]-pdBR[j]));
			}

			int i;
			int thresDBZ;
			
			for (i = 0 ; i <= 8 ; i++)
			{
				thresDBZ = 15. + (i * 5.);

				int count0 = 0;
				int count1 = 0;
				int k0 = 0;
				int k1 = 0;
				
				for (j = 0 ; j < availablePair ; j++)
				{
					if (py[j] < thresDBZ)
					{
						count0++;
					}
					if (py[j] >= thresDBZ)
					{
						count1++;
					}
				}
				
				if (count0 >= 40 && count1 >= 40)
				{
					for (j = 0 ; j < availablePair ; j++)
					{
						if (py[j] < thresDBZ)
						{
							px0[k0] = px[j];
							py0[k0] = py[j];
							k0++;
						}
					}
					lsplfit(count0,px0,py0,&a0,&b0);

					for (j = 0 ; j < availablePair ; j++)
					{
						if (py[j] >= thresDBZ)
						{
							px1[k1] = px[j];
							py1[k1] = py[j];
							k1++;
						}
					}
					lsplfit(count1,px1,py1,&a1,&b1);
				}
				else
				{
					a0 = -1.;
					b0 = -1.;
					a1 = -1.;
					b1 = -1.;
				}
				
				free(px0);
				free(py0);
				free(px1);
				free(py1);
				px0 = malloc(availablePair * sizeof(double));
				py0 = malloc(availablePair * sizeof(double));
				px1 = malloc(availablePair * sizeof(double));
				py1 = malloc(availablePair * sizeof(double));

				if (a0 > 10. && a0 < 500. && b0 > 1. && b0 < 5. && a1 > 1. && a1 < 500. && b1 > 1. && b1 < 5.)
				{
					int j;
					double dev=0.;
					double sum=0.;
					printf(" a b 00: %f %f %f %f:\n",a0,b0,a1,b1);
					
					for (j = 0 ; j < availablePair ; j++)
					{
						if (j <= count0)
						{
							dev = pow( ( (py[j]-10*log10(a0) )/b0 - 10*px[j]) , 2 );
						}
						if (j > count0)
						{
							dev = pow( ( (py[j]-10*log10(a1) )/b1 - 10*px[j]) , 2 );
						}
						
						sum += dev;
						
               		} 
               		
					pRMSE[i] = sqrt(sum/(j * 1.0));
				}
				else
				{
					pRMSE[i] = 9999.;
				} 
				continue;
			}						

			int thres=0;
			double refRMSE=9999.;
			
			for (i = 0 ; i <= 8 ; i++ )
			{
				if( pRMSE[i] < refRMSE )
				{
					refRMSE = pRMSE[i];
					thres = i;
				}
 			}

			thresDBZ = 15. + (thres * 5.);

			int count0 = 0;
			int count1 = 0;
			int k0 = 0;
			int k1 = 0;
			
			for (j = 0 ; j < availablePair ; j++)
			{
				if (py[j] < thresDBZ)
				{
					count0++;
				}
				
				if (py[j] >= thresDBZ)
				{
					count1++;
				}
			}

			if (pRMSE[thres] != 9999.)
			{
				for (j = 0 ; j < availablePair ; j++)
				{
					if (py[j] < thresDBZ)
					{
						px0[k0] = px[j];
						py0[k0] = py[j];
						k0++;
					}
				}
							
				lsplfit(count0,px0,py0,&a0,&b0);

				for (j = 0 ; j < availablePair ; j++)
				{
					if (py[j] >= thresDBZ)
					{
						px1[k1] = px[j];
						py1[k1] = py[j];
						k1++;
					}
				}
					
				lsplfit(count1,px1,py1,&a1,&b1);
			}
			else
			{
				a0 = -1.;
				b0 = -1.;
				a1 = -1.;
				b1 = -1.;
			} 
		#else
//		double	A,B;//y=Ax+B
		//least squares method
//		if (lstsq(px,py,LEAST_SQUARES_DEGREE,availablePair,&A,&B) == 1)
//		{
//			for (j = 0 ; j < availablePair ; j++)
//			{
//				pdBR[j] = A*px[j]+B;
//				pgoverR[j] = pow(10.,0.1*(py[j]-pdBR[j]));
//			}
			
//			a = pow(10.,(B/10.));
//			b = A/10.;
		#endif
		
#ifdef PRINT_DEBUG
fprintf(stderr,"YY8\n"); 
#endif
			//ǥ������ ���
			ave = aveValue(pgoverR, availablePair);
			stdev = stdevValue(pgoverR,availablePair,ave);

			//������ ���
			corr = corrValue(px,py,availablePair);
					
#ifdef PRINT_DEBUG
fprintf(stderr,"YY9\n"); 
#endif

			//���� �˻�
			if ((corr >= g_optionQPE.minCorrelation) && (a >= g_optionQPE.minZRA) && (a <= g_optionQPE.maxZRA) && (b >= g_optionQPE.minZRB) && (b <= g_optionQPE.maxZRB))
			{
				foundZR = 1;
					
#ifdef PRINT_DEBUG
fprintf(stderr,"YY10\n"); 
#endif
			}
			else
			{
					
#ifdef PRINT_DEBUG
fprintf(stderr,"YY11\n"); 
#endif

				//���ǿ� ���� �ʴ� aws ����
				//���� �ľ�
				availablePairTemp = 0;
				for (j = 0 ; j < availablePair ; j++)
				{
					pgoverRdev[j] = fabs(pgoverR[j]-ave);
					if (pgoverRdev[j] <= g_optionQPE.maxStddevp * stdev)
					{
						availablePairTemp++;
					}
				}
					
#ifdef PRINT_DEBUG
fprintf(stderr,"YY12\n"); 
#endif

				//�ӽ� �޸� �Ҵ�
				pxTemp = malloc(availablePairTemp * sizeof(double));
				pyTemp = malloc(availablePairTemp * sizeof(double));
				count = 0;
				//�ӽ� pair ����
				for ( j = 0 ; j < availablePair ; j++ )
				{
					pgoverRdev[j] = fabs(pgoverR[j]-ave);
					if (pgoverRdev[j] <= g_optionQPE.maxStddevp * stdev)
					{
						pxTemp[count] = pow(10,px[j]);
						pyTemp[count] = py[j];
						count++;
					}
				}
					
				availablePosition = 0;
				availablePair = count;
					
#ifdef PRINT_DEBUG
fprintf(stderr,"YY13\n"); 
#endif
			}

			//��� ���
			printf("  | %9d | %7.4f | %18.4f | %11.4f | %8.4f | %6.4f | %10d | %5d |\n",
					iterationCount,ave,stdev,corr,a,b,availablePair,foundZR);
		
			free(pgoverR);		pgoverR = NULL;
			free(pgoverRdev);	pgoverRdev = NULL;
			free(pdBR);			pdBR = NULL;
			free(px);			px = NULL;
			free(py);			py = NULL;
				
#ifdef PRINT_DEBUG
fprintf(stderr,"YY14\n"); 
#endif

			//����Ʈ�� ZR�� a,b�� ���
			if(foundZR)
			{
				(*pzr).a = a;
				(*pzr).b = b;
				(*pzr).a0 = a0;
				(*pzr).b0 = b0;
				(*pzr).a1 = a1;
				(*pzr).b1 = b1;
				(*pzr).thres = thresDBZ;
				(*pzr).route = NEW_ZR;
				break;
			}
				
#ifdef PRINT_DEBUG
fprintf(stderr,"YY15\n");
#endif

			iterationCount++;
		}
		else //least squares���� ���� �߻�
		{
			fprintf(stderr,"least squares error\n");
			return 0;
		}
	}

	return foundZR;
}

/**
 * @brief ���� ZR ����� ���� ZR ����� �����ϴ� �Լ�
 * @param siteIndex ���̴� ����Ʈ �ε���
 * @return ���� ��� 1: ����, 0: ����
 * @author �豤ȣ
 */
static int processPrevZR(int siteIndex)
{
	if (g_site[siteIndex].prevZR.route < 0 )	//prev_zr�б� �����ϸ� ���� ������.
		return 0;

	g_site[siteIndex].nowZR.a = g_site[siteIndex].prevZR.a;
	g_site[siteIndex].nowZR.b = g_site[siteIndex].prevZR.b;
	g_site[siteIndex].nowZR.route = PREV_ZR;

	return 1;
}

/**
 * @brief Marshall-Palmer relationship (200,1.6)�� ���� ZR ����� �����ϴ� �Լ�
 * @param siteIndex ���̴� ����Ʈ �ε���
 * @return ���� ��� 1: ����
 * @author �豤ȣ
 */
static int processMarshallPalmerZR(int siteIndex)
{
	g_site[siteIndex].nowZR.a = MARSHALL_PALMER_ZR_A;
	g_site[siteIndex].nowZR.b = MARSHALL_PALMER_ZR_B;
	g_site[siteIndex].nowZR.a0 = MARSHALL_PALMER_ZR_A; //KKH
	g_site[siteIndex].nowZR.b0 = MARSHALL_PALMER_ZR_B; //KKH
	g_site[siteIndex].nowZR.a1 = MARSHALL_PALMER_ZR_A; //KKH
	g_site[siteIndex].nowZR.b1 = MARSHALL_PALMER_ZR_B; //KKH
	g_site[siteIndex].nowZR.route = M_P_ZR;

	return 1;
}

/*******************************************
	//�ּ������� [method of least squares]
*******************************************/
//static int  lstsq(double x[], double y[], int n, int number, double* pA, double* pB)
//{
//	int  i;
//	int  j;
//	int  k;
//	int  l;
//	double  w1;
//	double  w2;
//	double  w3;
//	double  pivot;
//	double  aik;
//	double  a[21][22];
//	double  w[42];
//	
//	if(n >= number || n < 1 || n > 20) return(-1);
//	for(i = 0; i < n*2; i++)
//	{
//		w1 = 0.0;
//	   	for(j = 0; j < number; j++)
//	   	{
//	      	w2 = w3 = x[j];
//	 		for(k = 0; k < i; k++) w2 *= w3;
//	 		w1 += w2;
//	   	}
//	   	w[i] = w1;
//	}
//	
//	// matrix �Է�
//	for(i = 0; i < n+1; i++)
//	{
//		for(j = 0; j < n+1; j++)
//		{
//	    	l = i + j - 1;
//	      	a[i][j] = w[l];
//	   	}
//	}
//	
//	a[0][0] = number;
//	w1 = 0.0;
//	for(i = 0; i < number; i++) w1 += y[i];
//	a[0][n+1] = w1;
//	
//	// sigma(Yi Xi) ����ؼ� ����
//	for(i = 0; i < n; i++)
//	{
//		w1 = 0.0;
//	   	for(j = 0; j < number; j++)
//	   	{
//	    	w2 = w3 = x[j];
//	 		for(k = 0; k < i; k++) w2 *= w3;
//	 		w1 += y[j] * w2;
//	   	}
//	   	a[i+1][n+1] = w1;
//	}
//	
//	// matrix ���
//	for(k = 0; k < n+1; k++)
//	{
//		pivot = a[k][k];
//	   	for(j = k; j < n+2; j++) a[k][j] /= pivot;
//	   	for(i = 0; i < n+1; i++)
//	   	{
//	    	if(i != k)
//	    	{
//	        	aik = a[i][k];
//	    		for(j = k; j < n+2; j++) a[i][j] -= aik * a[k][j];
//	      	}
//	   	}
//	}
//	
//	*pA = a[1][n+1];
//	*pB = a[0][n+1];
//	
//	return 1;
//}

/*******************************************
	Least Square Fit of Power Law Equation
	http://mathworld.wolfram.com/LeastSquaresFittingPowerLaw.html
*******************************************/
/**
 * @brief Least Square Fit of Power Law Equation �Լ�
 * @param px AWS ���췮
 * @param py ���̴� dBZ
 * @param pa ZR ��� a
 * @param pb ZR ��� b
 * @return ���� ��� 1: ����
 * @author �豤ȣ
 */
static int lsplfit(int n, double* px, double* py, double* pa, double* pb)
{
	double slnx = 0.0;
	double slny = 0.0;
	double slnx2 = 0.0;
	double slnxlny = 0.0;
	double nF;
	double xx;
	double yy;
	int i;

	nF = (double)n;
	for (i = 0 ; i < n ; i++ )
	{
    	xx = pow(10.,(py[i]/10.));
        yy = pow(10.,px[i]);

		slnx = slnx + log(xx);
		slny = slny + log(yy);
		slnx2 = slnx2 + log(xx) * log(xx);
		slnxlny = slnxlny + log(xx) * log(yy);
	}

	*pb = (n*slnxlny - slnx*slny)/(nF*slnx2 - slnx*slnx);
	*pa = exp((slny - *pb*slnx)/nF);

	*pb = (1./(*pb));
	*pa = (1./(pow(*pa,*pb)));

	return 1;
}

/**
 * @brief ǥ������ ���ϴ� �Լ�
 * @param value �ڷ�
 * @param number �ڷ��
 * @param ave ��հ�
 * @return st ǥ������
 * @author �豤ȣ
 */
static double stdevValue(double value[], int number, double ave)
{
	int i;
	double st;
	double sum=0.;

	sum=0.;

	for(i = 0 ; i < number ; i++)
	{
		 sum +=(ave - value[i]) * (ave - value[i]);
	}
	st = sqrt(sum/(number * 1.0));

	return st;
}

/**
 * @brief ��� ���ϴ� �Լ�
 * @param value �ڷ�
 * @param number �ڷ��
 * @return ��հ�
 * @author �豤ȣ
 */
static double aveValue(double value[], int number)
{
	int i;
	double sum = 0;

	for (i = 0 ; i < number ; i++ )
	{
		sum += value[i];
	}
	return (sum/(number * 1.0));
}

/**
 * @brief ������ ���ϴ� �Լ�
 * @param x AWS ���췮
 * @param y ���̴� dBZ
 * @param number �ڷ��
 * @return corr ������
 * @author �豤ȣ
 */
static double corrValue(double x[], double y[], int number)
{
	double stdX;
	double stdY;
	double aveX;
	double aveY;
	double sum;
	int i;
	double corr;

	aveX = aveValue(x,number);
	aveY = aveValue(y,number);

	stdX = stdevValue(x,number,aveX);
	stdY = stdevValue(y,number,aveY);

	sum = 0;
	for (i = 0 ; i < number ; i++ )
	{
		sum += (x[i]-aveX)*(y[i]-aveY);
	}
	corr = ((1/(number*1.))*sum)/(stdX*stdY);

	return corr;
}

/**
 * @brief ���� 50�� �������� ZR ��� ����� �д� �Լ�
 * @param psiteInitial ���̴� ����Ʈ��
 * @param beforeMinutes ���� ZR ����� �̿��ϴ� �ð�
 * @return pastZR ���� ZR ��� ����ü
 * @author �豤ȣ
 */
static ZR_VALUE readPastZR(char* psiteInitial, int beforeMinutes, int fixRoute) //KKH add fixRoute
{
	FILE* pfp;

	char datetimeStr[MAX_STRING_LENGTH];
	char buffer[MAX_STRING_LENGTH];
	char tempSiteInitial[MAX_STRING_LENGTH];
	char* pZRPathFileName;

	ZR_VALUE pastZR;
	ZR_VALUE tempZR;

	//�ʱ�ȭ
	pastZR.a = DEFAULT_ZR_A;
	pastZR.b = DEFAULT_ZR_B;
	pastZR.route = -1;

	tempZR.a = DEFAULT_ZR_A;
	tempZR.b = DEFAULT_ZR_B;
	tempZR.route = -1;

	//������ �ð����� �˻�
	//���� �̸� ����
	pZRPathFileName = generateZRLogFileName(-1*beforeMinutes,fixRoute); //KKH add fixRoute
	if (pZRPathFileName == NULL) return pastZR;

	if ((pfp = fopen(pZRPathFileName,"r")) == NULL) return pastZR;
	free(pZRPathFileName);

	//����Ʈ �̸��� ��ġ�ϸ� ���
	while (fgets(buffer,sizeof(buffer),pfp) != NULL)
	{
		sscanf(buffer,"%s %f %f %d %*s %*s\n",tempSiteInitial,&tempZR.a,&tempZR.b,&tempZR.route);
		//error check
		if (tempZR.a < 0.001 || tempZR.a > 9999. || tempZR.b < 0.001 || tempZR.b > 100. || 
				tempZR.route < 0 || tempZR.route >= (ROUTE_COUNT))
		{
			printf("       * error in loading prevZR : %s %s a = %f b = %f route = %d \n",datetimeStr,tempSiteInitial,tempZR.a,tempZR.b,tempZR.route);
			continue;
		}

		if (strstr(tempSiteInitial,psiteInitial) == NULL)	continue;

		break;
	}
	fclose(pfp);
	if (tempZR.route >= 0)
	{
		pastZR = tempZR;
	}
	
	return pastZR;
}

/**
 * @brief ���� �ð��� ZR ��� ����� �д� �Լ�
 * @param psiteInitial ���̴� ����Ʈ��
 * @param usefulPrevZRPeriodMinutes ���� ZR ����� �̿��ϴ� ��ȿ �ð�
 * @return prevZR ���� ZR ��� ����ü
 * @author �豤ȣ
 */
static ZR_VALUE readPrevZR(char* psiteInitial, int usefulPrevZRPeriodMinutes, int fixRoute) //KKH add fixRoute
{
	FILE* pfp;

	char datetimeStr[MAX_STRING_LENGTH];
	char buffer[MAX_STRING_LENGTH];
	char tempSiteInitial[MAX_STRING_LENGTH];
	char* pZRPathFileName;
	int i;

	ZR_VALUE prevZR;
	ZR_VALUE fileZR;

	//�ʱ�ȭ
	prevZR.a = DEFAULT_ZR_A;
	prevZR.b = DEFAULT_ZR_B;
	prevZR.route = -1;

	//������ �ð����� �˻�
	for (i = 10 ; i <= usefulPrevZRPeriodMinutes ; i += 10)
	{
		//���� �̸� ����
		pZRPathFileName = generateZRLogFileName(-1*i,fixRoute); //KKH add fixRoute
		
		if (pZRPathFileName == NULL) continue;

		if ((pfp = fopen(pZRPathFileName,"r")) == NULL) continue;
		free(pZRPathFileName);

		//����Ʈ �̸��� ��ġ�ϸ� ���
		while (fgets(buffer,sizeof(buffer),pfp) != NULL)
		{
			sscanf(buffer,"%s %f %f %d %*s %*s\n",tempSiteInitial,&fileZR.a,&fileZR.b,&fileZR.route);

			//error check
			if (fileZR.a < 0.001 || fileZR.a > 9999. || fileZR.b < 0.001 || fileZR.b > 100. || 
					fileZR.route < 0 || fileZR.route >= (ROUTE_COUNT))
			{
				printf(" * error in loading prevZR : %s %s a = %f b = %f route = %d \n",datetimeStr,tempSiteInitial,fileZR.a,fileZR.b,fileZR.route);
				continue;
			}
			if (strstr(tempSiteInitial,psiteInitial) == NULL)	continue;
			if (fileZR.route != NEW_ZR) continue;

			fclose(pfp);

			prevZR = fileZR;

			return prevZR;

		}
		fclose(pfp);
		//Prev ZR ã������ ����
	}

	return prevZR;
}

/**
 * @brief ���ο� ZR ����� AWS ���� ����ϴ� �Լ�
 * @param psiteInitial ���̴� ����Ʈ��
 * @param nowZR ���� ZR ��� ����ü
 * @param totalAWS �� AWS ����
 * @param rainAWS AWS ������
 * @return ���� ��� 1: ����
 * @author �豤ȣ
 */
static int writeNowZR(char* psiteInitial, ZR_VALUE nowZR, int totalAWS, int rainAWS, int fixRoute) //KKH add fixRoute
{
	FILE* pfp;
	char** pbuffer;
	char* pZRPathFileName;
	int count;
	int foundSiteIndex;
	int i;

   
	//���� �̸� ����
	pZRPathFileName = generateZRLogFileName(0,fixRoute); //KKH
	
	if (pZRPathFileName == NULL) return -9999;
	

	//�ش� �ð� ZR������ ������
	if (!fileExists(pZRPathFileName))
	{
		if ((pfp = fopen(pZRPathFileName,"w")) == NULL)return -99998;
		free(pZRPathFileName);
		fprintf(pfp,"%s %f %f %d %d %d\n",psiteInitial,nowZR.a,nowZR.b,nowZR.route,totalAWS,rainAWS);
		fclose(pfp);
		return 1;
	}
	//�ش� �ð� ZR������ ������ �������� �״�� ���� ����Ǵ� �κи� ������
	else
	{
		//���� ���� �б�
		count = 0;
		foundSiteIndex = -1;	//�ش� ����Ʈ�� ������ ���� ������ �����.
		pbuffer = malloc(g_option.siteCount * sizeof(char*));
		for (i = 0; i < g_option.siteCount ; i++ )
		{
			pbuffer[i] = malloc(MAX_STRING_LENGTH * sizeof(char));
		}
		if ((pfp = fopen(pZRPathFileName,"r")) == NULL)return -73005;
		while (fgets(pbuffer[count],MAX_STRING_LENGTH,pfp) != NULL)
		{
			if (strstr(pbuffer[count],psiteInitial) != NULL)
			{
				foundSiteIndex = count;
			}
			count++;
		}
		fclose(pfp);

		//���� ����(���� ���Ͽ� �ִ������� �˻�)
		if ((pfp = fopen(pZRPathFileName,"w")) == NULL)return -73005;
		//������ ���������� ������
		if (foundSiteIndex >= 0)
		{
			for (i = 0 ; i < count ; i++ )
			{
				//�ش� ����Ʈ
				if (i == foundSiteIndex)
				{
					fprintf(pfp,"%s %f %f %d %d %d\n",psiteInitial,nowZR.a,nowZR.b,nowZR.route,totalAWS,rainAWS);
				}
				//��Ÿ ����Ʈ
				else
				{
					fprintf(pfp,"%s",pbuffer[i]);
				}
			}
		}
		//������ ���������� ������ 
		else
		{
			//��Ÿ ����Ʈ
			for (i = 0 ; i < count ; i++ )
			{
				fprintf(pfp,"%s",pbuffer[i]);
			}
			//�ش����Ʈ �߰�
			fprintf(pfp,"%s %f %f %d %d %d\n",psiteInitial,nowZR.a,nowZR.b,nowZR.route,totalAWS,rainAWS);
		}
		fclose(pfp);
		
		//memory free
		for (i = 0 ; i < count ; i++ )
			free(pbuffer[i]);
		free(pbuffer);
	}

	return 1;
}

/**
 * @brief ���� ZR ����� ���찭�� ���
 * @param siteIndex ���̴� ����Ʈ �ε���
 * @return ���� ��� 1: ����
 * @author �豤ȣ
 */
static int rainfallEstimation(int siteIndex, int fixRoute) //KKH
{
	FILE* pf;
	char fileDualZR[200];
    int i;
	FILE* pfv;
	float acc;
	float bias;
	float pod;
	float far;
	float csi;
	float me;
	float mae;
	float mse;
	float rmse;
	float corr;
	float AWSMean;
	float radarMean; //
	float GR; //
	int AWSCount;
	int availableAWSNum; //
	char file[512];
	//int beforeTime; //??

	char productTypeChar1=' '; //KKH
	char productTypeChar2=' '; //KKH

	g_site[siteIndex].rainKRLRadar.pdata = malloc(g_site[siteIndex].xdim * g_site[siteIndex].ydim * sizeof(float));
	if (g_site[siteIndex].rainKRLRadar.pdata == NULL)
		return 0;

  printf("Threshold dBZ : %f\n",g_site[siteIndex].nowZR.thres);
	printf("ZR : a : %f , b : %f\n",g_site[siteIndex].nowZR.a,g_site[siteIndex].nowZR.b);
	printf("ZR : a0 : %f , b0 : %f , a1 : %f , b1 : %f\n",g_site[siteIndex].nowZR.a0,g_site[siteIndex].nowZR.b0,g_site[siteIndex].nowZR.a1,g_site[siteIndex].nowZR.b1);

	switch (g_option.productType) //KKH
	{
			case PRODUCT_PPI	: productTypeChar2 = 'p';	break;
			case PRODUCT_BASE	: productTypeChar2 = 'b';	break;
			case PRODUCT_CAPPI	: productTypeChar2 = 'c';	break;
	}
	
  sprintf(file,"%sDATA/TXT/VERI_SP_SITE/vs%c%d_%s_%s.txt",g_option.pprogramRootPath,productTypeChar2,fixRoute,g_site[siteIndex].pname,g_option.datetimeString); //KKH vsc%d
  printf("%sDATA/TXT/VERI_SP_SITE/vs%c%d_%s_%s.txt\n",g_option.pprogramRootPath,productTypeChar2,fixRoute,g_site[siteIndex].pname,g_option.datetimeString); //KKH vsc%d

  acc =-9999.;
  bias=-9999.;
  pod =-9999.;
  far =-9999.;
  csi =-9999.;
  me  =-9999.;
  mae =-9999.;
  mse =-9999.;
  rmse=-9999.;
  corr=-9999.;
  AWSMean  =-9999.;
  radarMean=-9999.;
  AWSCount=0;
  availableAWSNum=0;

  if((pfv=fopen(file,"r"))!=NULL){
       fscanf(pfv,"ACC %f\n",&acc);
       fscanf(pfv,"BIAS %f\n",&bias);
       fscanf(pfv,"POD %f\n",&pod);
       fscanf(pfv,"FAR %f\n",&far);
       fscanf(pfv,"CSI %f\n",&csi);
       fscanf(pfv,"ME %f\n",&me);
       fscanf(pfv,"MAE %f\n",&mae);
       fscanf(pfv,"MSE %f\n",&mse);
       fscanf(pfv,"RMSE %f\n",&rmse);
       fscanf(pfv,"CORR %f\n",&corr);
       fscanf(pfv,"AWS_MEAN %f\n",&AWSMean);
       fscanf(pfv,"RADAR_MEAN %f\n",&radarMean);
       fscanf(pfv,"AVAILABLE_AWS %d %d\n",&AWSCount,&availableAWSNum);
       fclose(pfv);
  }
  GR = 1.;
  if((AWSMean > 0) && (radarMean > 1)){
	  GR=AWSMean/radarMean;
  }
  if (g_site[siteIndex].pname=="BRI" || g_site[siteIndex].pname=="DNH" || g_site[siteIndex].pname=="GNG" || g_site[siteIndex].pname=="SSP" || g_site[siteIndex].pname=="GSN")
  {
	  GR=1.;
  }

  printf("%f %f %f %f %f %f %f %f %f %f %f %f %f\n",acc,bias,pod,far,csi,me,mae,mse,rmse,corr,AWSMean,radarMean,GR);
  printf("%d %d \n",AWSCount,availableAWSNum); 

	switch (g_option.productType) //KKH
	{
		case PRODUCT_PPI	: productTypeChar1 = 'P';	break;
		case PRODUCT_BASE	: productTypeChar1 = 'B';	break;
		case PRODUCT_CAPPI	: productTypeChar1 = 'C';	break;
	}

	sprintf(fileDualZR,"%sLOG/ZR/%s_%s.bias%c%d",g_option.pprogramRootPath,g_site[siteIndex].pname,g_option.datetimeString,productTypeChar1,fixRoute); //KKH bias%d 
	pf=fopen(fileDualZR,"w");
		fprintf(pf,"%f\n",GR);
	fclose(pf);

	sprintf(fileDualZR,"%sLOG/ZR/%s.zr%c%d",g_option.pprogramRootPath,g_option.datetimeString,productTypeChar1,fixRoute); //KKH
	pf=fopen(fileDualZR,"w");
	for (i=0;i< g_option.siteCount ;i++ )
	{
		if(g_site[i].nowZR.a0==0.)g_site[i].nowZR.a0=200.;
		if(g_site[i].nowZR.b0==0.)g_site[i].nowZR.b0=1.6;
		if(g_site[i].nowZR.a1==0.)g_site[i].nowZR.a1=200.;
		if(g_site[i].nowZR.b1==0.)g_site[i].nowZR.b1=1.6;
		fprintf(pf,"%s %f %f %f %f %f %f %f %d\n",g_site[i].pname,g_site[i].nowZR.a,g_site[i].nowZR.b,g_site[i].nowZR.a0,g_site[i].nowZR.b0,g_site[i].nowZR.a1,g_site[i].nowZR.b1,g_site[i].nowZR.thres,g_site[siteIndex].nowZR.route);
	}
	fclose(pf);

	for (i = 0; i < g_site[siteIndex].xdim * g_site[siteIndex].ydim ; i++ )
	{
		//if (g_site[siteIndex].pastKRLRadar[RADAR_OBS_NUMBER-1].pdata[i] == BAD_VALUE_F)
		if (g_site[siteIndex].pastKRLRadar[RADAR_OBS_NUMBER-1].pdata== NULL || g_site[siteIndex].pastKRLRadar[RADAR_OBS_NUMBER-1].pdata[i] == BAD_VALUE_F)
		{
			g_site[siteIndex].rainKRLRadar.pdata[i] = BAD_VALUE_F;
		}
		else
		{
            if (g_site[siteIndex].nowZR.a0 < 10. || g_site[siteIndex].nowZR.a0 > 500. || g_site[siteIndex].nowZR.b0 < 1. || g_site[siteIndex].nowZR.b0 > 5. || g_site[siteIndex].nowZR.a1 < 1. || g_site[siteIndex].nowZR.a1 > 500. || g_site[siteIndex].nowZR.b1 < 1. || g_site[siteIndex].nowZR.b1 > 5.)
			{
				g_site[siteIndex].rainKRLRadar.pdata[i] = dBZToRF(g_site[siteIndex].pastKRLRadar[RADAR_OBS_NUMBER-1].pdata[i],g_site[siteIndex].nowZR.a,g_site[siteIndex].nowZR.b);
			}
			else
			{
				if (g_site[siteIndex].pastKRLRadar[RADAR_OBS_NUMBER-1].pdata[i] < g_site[siteIndex].nowZR.thres)
				{
					g_site[siteIndex].rainKRLRadar.pdata[i] = dBZToRF(g_site[siteIndex].pastKRLRadar[RADAR_OBS_NUMBER-1].pdata[i],g_site[siteIndex].nowZR.a0,g_site[siteIndex].nowZR.b0);
				}
				else
				{
					g_site[siteIndex].rainKRLRadar.pdata[i] = dBZToRF(g_site[siteIndex].pastKRLRadar[RADAR_OBS_NUMBER-1].pdata[i],g_site[siteIndex].nowZR.a1,g_site[siteIndex].nowZR.b1);
				}
                                
                    g_site[siteIndex].rainKRLRadar.pdata[i] = g_site[siteIndex].rainKRLRadar.pdata[i]*GR;
				
				if(g_site[siteIndex].rainKRLRadar.pdata[i] >= 80.)
				{ 
                  g_site[siteIndex].rainKRLRadar.pdata[i] = 0.2*(g_site[siteIndex].rainKRLRadar.pdata[i]-80.)+80.;
				}
			}
		}
	}
    
	return 1;
}

/**
 * @brief ��밡���� AWS-���̴� pair ���� ��ȯ
 * @param aws paws ����ü
 * @param AWSCount AWS ����
 * @param availableAWSCount �̿밡���� AWS ����
 * @param availablePairCount �̿밡���� AWS-���̴� pair ����
 * @return ���� ��� 1: ����
 * @author �豤ȣ
 */
static int checkAvailableAWS(AWS* paws, int AWSCount, int* pavailableAWSCount, int* pavailablePairCount)
{
	int j;
	int k;
	int avaAWSCount;
	int avaPairCount;
	int sumAvaPairCount;

	avaAWSCount = 0;
	sumAvaPairCount = 0;
	*pavailableAWSCount = 0;
	*pavailablePairCount = 0;
	for ( j = 0 ; j < AWSCount ; j++ )
	{
		if (!paws[j].use) continue;
		avaPairCount = 0;
		for (k = 0 ; k < RADAR_PAIR_NUMBER ; k++ )
		{
			if (!paws[j].use1min[k]) continue;

			avaPairCount++;
		}
		if (avaPairCount > 0)
		{
			avaAWSCount++;
			sumAvaPairCount += avaPairCount;
		}
	}
	*pavailableAWSCount = avaAWSCount;
	*pavailablePairCount = sumAvaPairCount;
	printf("aws : %d %d\n",avaAWSCount,sumAvaPairCount);

	return 1;
}

/**
 * @brief ��밡���� ���̴� ���� ���� �Լ�
 * @param siteIndex ���̴� ����Ʈ �ε���
 * @param totalRadarArealDBZ2 �� ���̴� ����
 * @param totalAWSRadarPairCount ���̴������� �����ϴ� AWS ��
 * @return ������ 1: ����
 * @author �豤ȣ
 */
static int checkArealRadar(int siteIndex, int* totalRadarArealDBZ2, int* totalAWSRadarPairCount) //KKH
{
	int i;
	int j;
	int k;
	int x;
	int y;
	int AWSIndex;
	
	int arealDBZ;
	int sumArealDBZ;
	int totalRadarArealDBZ1;
	
	int AWSRadarPairC;
	int AWSRadarPairCount;
 
	arealDBZ = 0;
	totalRadarArealDBZ1 = 0;
	*totalRadarArealDBZ2 = 0;
	
	AWSRadarPairCount = 0;
	*totalAWSRadarPairCount = 0;
	
	if (g_site[siteIndex].pastKRLRadar == NULL)
	return -73003;

	for (i = 0 ; i < g_site[siteIndex].AWSCount ; i++)
	{
		sumArealDBZ = 0;
		AWSRadarPairC = 0;
		
		if (g_site[siteIndex].pAWS[i].use == 0)//aws�� ������� �������� �Ǿ� ������ PASS
			continue;
		x = g_site[siteIndex].pAWS[i].x;
		y = g_site[siteIndex].pAWS[i].y;
		
		for (j = 0; j < RADAR_OBS_NUMBER ; j++ )
		{
			if (g_site[siteIndex].pastKRLRadar[j].pdata == NULL)	continue;
			if (g_site[siteIndex].pmapTable[y][x].inBound <= MAP_VALUE_RANGE_OUT) continue;

			for (k = 0 ; k < 10 ; k++ )
			{
				AWSIndex = j * 10 + k;
				if (g_site[siteIndex].pAWS[i].use1min[AWSIndex] == 0) continue;

				arealDBZ = sumArealRadarDBZ(g_site[siteIndex].pastKRLRadar[j], g_site[siteIndex].pAWS[i], g_site[siteIndex].xdim, g_site[siteIndex].ydim, AWSIndex);
				
				sumArealDBZ += arealDBZ;
				totalRadarArealDBZ1 += arealDBZ;
				AWSRadarPairC++;
			}
		}
		if (AWSRadarPairC > 0)
		{
			AWSRadarPairCount++;
		}
		//g_site[siteIndex].pAWS[i].AWSRadarArealDBZ = sumArealDBZ;
	}
	*totalRadarArealDBZ2 = totalRadarArealDBZ1;
	*totalAWSRadarPairCount = AWSRadarPairCount;
	
	return 1;
}
 
/**
 * @brief ���̴� 3*3 ���� �� AWS ���췮�� ���� ���� ���� ���� ���̴� ���ڰ��� ��ȯ�ϴ� �Լ�
 * @param RKL_RADAR cappi ���̴� �ڷ� ����ü
 * @param AWS aws AWS �ڷ� ����ü
 * @param xdim x�� ����
 * @param ydim y�� ����
 * @param ZRB ZR ��� a
 * @param ZRB ZR ��� b
 * @param obsTimeIndex AWS ���� Index
 * @return arealDBZ AWS �ֺ��� ���̴� ����
 * @author �豤ȣ
 */
static int sumArealRadarDBZ(KRL_RADAR cappi, AWS aws, int xdim, int ydim, int obsTimeIndex) //KKH
{
	int i;
	int j;
	int index;
	int sumArealDBZ; 
 	int arealDBZ;
 	int countt;
 	
 	sumArealDBZ = 0;
 	arealDBZ = 0;
 	countt = 0;
 	
 	for (i = -1 ; i <= 1; i++)
 	{
 		for (j = -1 ; j <= 1 ; j++)
 		{
 			countt++;
 			index = (aws.y + i) * xdim + (aws.x + j);
 			
 			if (aws.x < 0 || aws.x >= xdim || aws.y < 0 || aws.y >= ydim) continue;
 			if (cappi.pdata[index] == BAD_VALUE_F) continue;
 			if (cappi.pdata[index] == OUT_VALUE_F) continue;
 			
 			sumArealDBZ++;
 		}
 	}
 	arealDBZ = sumArealDBZ/countt;
 	
 	return arealDBZ;
}

/**
 * @brief �ڷ� ���� �Լ�
 * @param parr �ڷ�
 * @param count �ڷ� ��
 * @return ���� ��� 1: ����
 * @author �豤ȣ
 */
static int sort(double* parr, int count)
{
	int i;
	int j;
	double tmp;

	for (i = 1 ; i < count ; i++ )
	{
		for (j = 1 ; j < count ; j++ )
		{
			if( parr[j-1] > parr[j] )
			{
				tmp = parr[j-1]; //��ȯ
				parr[j-1] = parr[j];
				parr[j] = tmp;
			}
		}
	}

	return 1;
}
