/**
 * @file map.c
 * @brief ������������ �̿��� ������ǥ�� ��ȯ �Լ�
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "map.h"
#include "radar_rar_site.h"

/***************************************************************************
*
*  [ Azimuthal Equidistant Projection ]
*
*      o lon, lat : (longitude,latitude) at earth  [degree]
*      o x, y     : (x,y) cordinate in map  [grid]
*      o code = 0 : (lon,lat) --> (x,y)
*               1 : (x,y) --> (lon,lat)
*      o map      : map parameter
*
***************************************************************************/
/*             0 (�ѹݵ� �ؾȼ�, ���漱, ���ֵ�, �︪��, ����) 
               1 (������ ��) 
               2 (�����, ����ð��) 
               3 (��/�� ���, ����� �����) 
               4 (�ѹݵ��� ����) 
               5 (�ѹݵ� �̿� �ڷ�) 
               3000 (����) 
               4000 (����) 
*/

/**
 * @brief Azimuthal equidistant projection �ڷḦ x,y�ڷ�� ��ȯ�ϴ� �Լ�.
 * @param plon �浵
 * @param plat ����
 * @param px X��ǥ
 * @param py Y��ǥ
 * @param code 
 * @param map 
 * @param pmapv 
 * @return ������ 0: ����
 * @author �豤ȣ
 */
int  azedproj(float* plon, float* plat, float* px, float* py, int code, AZED_PARAMETER map, AZED_VAR* pmapv)
//float  *lon, *lat;         /* Longitude, Latitude [degree]  */
//float  *x, *y;             /* Coordinate in Map   [grid]    */
//int    code;               /* (0) lon,lat -> x,y  (1) x,y -> lon,lat */
//struct azed_parameter map
{
    double alon;
    double alat;
    double ak;
    double xn;
    double yn;
    double ra;
    double theta;
    double ac;
    double a1;
    double a2;

	if ((*pmapv).first == 0)
	{
		(*pmapv).PI = PI_DFS;//asin(1.0)*2.0;
        (*pmapv).DEGRAD = (*pmapv).PI/180.0;
        (*pmapv).RADDEG = 180.0/(*pmapv).PI;
        (*pmapv).re = map.Re/map.grid;
        (*pmapv).slon = map.slon * (*pmapv).DEGRAD;
        (*pmapv).slat = map.slat * (*pmapv).DEGRAD;
        (*pmapv).olon = map.olon * (*pmapv).DEGRAD;
        (*pmapv).olat = map.olat * (*pmapv).DEGRAD;
        ak = sin((*pmapv).slat)*sin((*pmapv).olat) + cos((*pmapv).slat)*cos((*pmapv).olat)*cos((*pmapv).olon-(*pmapv).slon);
        if (ak < -0.99999) return -1;
        if (ak > 0.99999) {
            ak = 1.0;
        } else {
            ak = acos(ak);
            ak = ak / sin(ak);
        }
        (*pmapv).xo = (*pmapv).re*ak*cos((*pmapv).olat)*sin((*pmapv).olon-(*pmapv).slon) - map.xo;
        (*pmapv).yo = (*pmapv).re*ak*(cos((*pmapv).slat)*sin((*pmapv).olat) - sin((*pmapv).slat)*cos((*pmapv).olat)*cos((*pmapv).olon-(*pmapv).slon)) - map.yo;
        (*pmapv).first = 1;
    }

    if (code == 0) {			//(lon,lat) --> (x,y)
        alat = (*plat)*(*pmapv).DEGRAD;
        alon = (*plon)*(*pmapv).DEGRAD - (*pmapv).slon;
        ak = sin((*pmapv).slat)*sin(alat) + cos((*pmapv).slat)*cos(alat)*cos(alon);
        if (ak < -0.99999) return -1;
        if (ak > 0.99999) {
            ak = 1.0;
        } else {
            ak = acos(ak);
            ak = ak / sin(ak);
        }
        *px = (*pmapv).re*ak*cos(alat)*sin(alon) - (*pmapv).xo;
        *py = (*pmapv).re*ak*(cos((*pmapv).slat)*sin(alat) - sin((*pmapv).slat)*cos(alat)*cos(alon)) - (*pmapv).yo;
    } else {					//(x,y) --> (lon,lat)
        xn = *px + (*pmapv).xo;
        yn = *py + (*pmapv).yo;
        ra = xn*xn + yn*yn;
        if (ra <= 0.0) {
            ac = 0.0;
            alat = (*pmapv).slat;
        } else {
            ra = sqrt(ra);
            ac = ra/(*pmapv).re;
            alat = cos(ac)*sin((*pmapv).slat) + yn*sin(ac)*cos((*pmapv).slat)/ra;
            alat = asin(alat);
        }
        *plat = alat*(*pmapv).RADDEG;
        a1 = xn*sin(ac);
        a2 = ra*cos((*pmapv).slat)*cos(ac) - yn*sin((*pmapv).slat)*sin(ac);
        if (fabs(a1) <= 0.0) {
            theta = 0.0;
        } else if (fabs(a2) <= 0.0) {
            theta = (*pmapv).PI*0.5;
            if (a2 < 0.0) theta = -theta;
        } else {
            theta = atan2(a1, a2);
        }
        *plon = (theta + (*pmapv).slon)*(*pmapv).RADDEG;
    }
    return 0;
}

/**
 * @brief AWS ��� �ڷḦ �д� �Լ�
 * @param pfileName ���ϸ�
 * @param pAWSCount AWS ������ 
 * @return pAWS AWS ������ ��� �ִ� ����ü ����
 * @author �豤ȣ
 */
static AWS_SITE* readAWSPosFile(char* pfileName, int* pAWSCount)
{
	FILE* pfp;
	int i;
	int numAWS;
	AWS_SITE* pAWS;
	
	if ((pfp = fopen(pfileName,"r")) == NULL){
		fprintf(stderr,"AWS position data file Open Error!(file name = %s)\n",pfileName);
		return NULL;
	}
	fscanf(pfp,"%d",&numAWS);
	pAWS = malloc(numAWS * sizeof(AWS_SITE));
	for (i = 0; i < numAWS ; i++){
		fscanf(pfp,"%s %f %f",pAWS[i].name,&pAWS[i].lat,&pAWS[i].lon);
	}
	fclose(pfp);
	*pAWSCount = numAWS;

	return pAWS;
}

/**
 * @brief AWS ��� �ڷḦ �а� ���̴� ����Ʈ�� �߽����� X,Y �·Ḧ ����ϴ� �Լ�.
 * @param pfileName ���ϸ�
 * @param pAWSCount AWS ������ 
 * @return pAWS AWS ������ ��� �ִ� ����ü ����
 * @author �豤ȣ
 */
AWS_SITE* readAWSPosFile2(char* pfileName, int* pAWSCount)
{
	int i;
	int AWSNum = 0;
	AWS_SITE* pAWS;
	AZED_PARAMETER azedParameter;
	AZED_VAR azedVar;
	float xf;
	float yf;

	//���� �ʱ�ȭ
	azedParameter.Re = MAP_RE;
	azedParameter.slon = g_site.lon;
	azedParameter.slat = g_site.lat;
	azedParameter.olon = g_site.lon;
	azedParameter.olat = g_site.lat;
	azedParameter.xo = (g_site.xdim -1)/2.;
	azedParameter.yo = (g_site.ydim -1)/2.;
	azedVar.first = 0;

	azedParameter.grid = 1.0;

	pAWS = readAWSPosFile(pfileName,&AWSNum);
	
	*pAWSCount = AWSNum;

	for (i = 0 ; i < AWSNum ; i++ )
	{
		azedproj(&pAWS[i].lon,&pAWS[i].lat,&xf,&yf,0,azedParameter,&azedVar);
		pAWS[i].x = (int)xf;
		pAWS[i].y = (int)yf;
	}

	return pAWS;
}
