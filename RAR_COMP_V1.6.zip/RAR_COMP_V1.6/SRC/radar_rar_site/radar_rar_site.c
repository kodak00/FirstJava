/**
 * @file radar_rar_site.c
 * @brief �������� ����Ʈ �� ���췮 ���� ������ ���� ���� �Լ�
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "include/radar_rar_site.h"
#include "include/function.h"

OPTION	g_option;				//ȯ�漳��
SITE	g_site;				//����Ʈ�� �ڷ�(init���� �ʱ�ȭ)

int main(int argc, char *argv[])
{
	int ERROR_CODE;

	char* poutFileName;

	struct tm fileTimeTm;

	int p; //KKH
	int i; //KKH
	char tempString1[1]; //KKH
	
	g_site.pname = NULL;
	g_option.imageFileType = -1;

	/*******************************************
		�Է� �Ķ��Ÿ ó��
	*******************************************/
	//�Էµ� �ð� string�ʱ�ȭ
	if (argc < 3)
	{
		fprintf(stderr,"Usage : radar_rar_site [YYYYMMDDHHNN] [SITE INITIAL]\n");
		return 1;
	}
	sprintf(g_option.datetimeString,"%s",argv[1]);
	g_site.pname = strdup(argv[2]);
	fileTimeTm = convStrToDateTime(g_option.datetimeString);
	g_site.year = 1900+fileTimeTm.tm_year;
	g_site.month = fileTimeTm.tm_mon+1;
	g_site.day = fileTimeTm.tm_mday;
	g_site.hour = fileTimeTm.tm_hour;
	g_site.minute = fileTimeTm.tm_min;
	/*******************************************
		ȯ�漳�� ���� �б�(setup.ini)
	*******************************************/
	if ((ERROR_CODE = readSetup()) < 0){
		fprintf(stderr,"call readSetup Error No.%d\n",ERROR_CODE);
		return 4;
	}

	/*******************************************
		site �޸� �ʱ�ȭ(site)
	*******************************************/
	if ((ERROR_CODE = initSite()) < 0){
		fprintf(stderr,"call initSite Error No.%d\n",ERROR_CODE);
		return 5;
	}

	for (p = 0 ; p < PRODUCT_TYPE_COUNT ; p++ ) //KKH product�� ������ for ��ƾ �߰�
	{
		//Product type�� �����ϵ��� �����Ǿ� �ִ��� �˻�
		if (!g_option.pinputProductType[p])
			continue;

		//���δ�Ʈ�� ���� �۾� ���� ���δ�Ʈ ����
		switch (p) //KKH
		{
			case PRODUCT_PPI	: g_option.productType = PRODUCT_PPI;	break;
			case PRODUCT_BASE	: g_option.productType = PRODUCT_BASE;	break;
			case PRODUCT_CAPPI	: g_option.productType = PRODUCT_CAPPI;	break;
		}

		for (i = 0 ; i < strlen(g_option.fixRoute1) ; i++)
		{
			sprintf(tempString1,"%c",g_option.fixRoute1[i]);
			if (strstr(tempString1, "a") != NULL)
				g_option.fixRoute2 = 0;
			if (strstr(tempString1, "p") != NULL)
				g_option.fixRoute2 = 2;
			if (strstr(tempString1, "m") != NULL)
				g_option.fixRoute2 = 3;


			g_site.pQPEDProductFileName = generateQPEDSitePathFileName();

			if ((ERROR_CODE = readNowZR(&g_site.zrA,&g_site.zrB,&g_site.totalAWS,&g_site.rainAWS)) < 0)
			{
				fprintf(stderr,"call readNowZR Error No.%d\n",ERROR_CODE);
				return 6;
			}

			if ((ERROR_CODE = readImsiSiteFile()) < 0)
			{
				fprintf(stderr,"call readImsiSiteFile Error No.%d\n",ERROR_CODE);
				return 7;
			}

			//���� ����
			poutFileName = generateSiteImageFileName(g_option.productType,DATA_RN);
			printf("poutFileName       =%s\n",poutFileName);
			writeRadarSite(poutFileName,DATA_RN,g_site,g_option.productType);
		}
	}

	return 0;
}
