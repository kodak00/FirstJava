/**
 * @file function.c
 * @brief �ռ��췮 ������ ���� ȯ�漳���� �д� �Լ��� ��ϵ� ����
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>
#include "rar_verify.h"

static int initSite(int site_index);
static int clearComposition();
static char* generateZRLogFileName(int beforeMinutes, int fixRoute); //KKH add fixRoute
//���� ZR�� �б�
static ZR_VALUE readSiteZR(char* psiteInitial, int fixRoute); //KKH add fixRoute

/**
 * @brief ȯ�漳������(setup.ini, rar_verify.ini)�� ������ �б� ���� �Լ�.
 * @return  ������ 1: ����, 1�̿��� ����: ����
 * @author �豤ȣ
 */
int readSetup()
{
	int ERROR_CODE;
	char iniFileName[MAX_STRING_LENGTH];
	char* ptempString;

	//ȯ�� ���� COMP_RADAR_ROOT_PATH �б�
	g_option.pprogramRootPath = getenv("COMP_RADAR_ROOT_PATH");
	if (g_option.pprogramRootPath == NULL)
		return -13001;

	//setup.ini
	sprintf(iniFileName,"%sRES/%s",g_option.pprogramRootPath,SETUP_INI_FILENAME);

	if ((ERROR_CODE = createIniFile(iniFileName)) < 0)
		return ERROR_CODE;

	//RAR��� ���� ��ϵ� ���丮 ����
	sprintf(g_option.compositionQPE1kmDataPath,"%s%s",g_option.pprogramRootPath,readIniString("RAR_DIRECTORY","1kmCompData","DATA/qpe/data/comp/"));

	//�ռ��ڷ� ����� ����ϴ� ����Ʈ�� QPED �ӽ� ���� �����ϴ� ���丮
	ptempString = readIniString("TEMP_DIRECTORY","SiteQped10Min","site/data/data/products/");
	sprintf(g_option.site10minQPEDFilePath,"%s%s",g_option.pprogramRootPath,ptempString);
	free(ptempString);

	//[AWS_TRMM_GSP]
	ptempString = readIniString("AWS_TRMM_GSP","LocalPath",NULL);
	sprintf(g_option.AWSTRMMGSPPath,"%s%s",g_option.pprogramRootPath,ptempString);
	free(ptempString);
	
	g_option.fixRoute1 = readIniString("RAR","Fix",NULL); //KKH g_option.fixRoute = RAR_AUTO_ZR

	destroyIniFile();

	//rar_verify.ini
	sprintf(iniFileName,"%sRES/%s",g_option.pprogramRootPath,SETUP_RAR_VERIFY_INI_FILENAME);

	if ((ERROR_CODE = createIniFile(iniFileName)) < 0)
		return ERROR_CODE;

	g_option.mapColor = readIniColor("MAP_LINE_COLOR");

	g_option.mapLatLonColor = readIniColor("LAT_LON_LINE_COLOR");

	g_option.rangeInColor = readIniColor("RANGE_IN_COLOR");

	g_option.rangeOutColor = readIniColor("RANGE_OUT_COLOR");

	g_option.drawRadarPositionColor = readIniColor("RADAR_POSITION_COLOR");

	g_option.mapDrawLine = readIniInt("MAP","DrawLine",1);

	g_option.mapDrawLatLon = readIniInt("MAP","DrawLatLon",1);

	g_option.drawRadarPosition = readIniInt("MAP","DrawRadarPosition",1);

	g_option.prnColorIndexFileName = readIniString("COLOR_INDEX_FILE","Rain",NULL);
	if (g_option.prnColorIndexFileName == NULL)
		return -9999;

	g_option.prnDiffColorIndexFileName = readIniString("COLOR_INDEX_FILE","RainDiff",NULL);
	if (g_option.prnDiffColorIndexFileName == NULL)
		return -9999;

	g_option.pcompositionMapFileName2km = readIniString("MAP_FILE","2KM",NULL);
	if (g_option.pcompositionMapFileName2km == NULL)
		return -9999;

	g_option.pfontFileName = readIniString("FONT","BasicFont","arialbd.ttf");

	g_option.pfontDfsFileName = readIniString("FONT","DFSFont","timesbd.ttf");
	
	g_option.pfontColorIndexSize = readIniFloat("FONT","Size",10.0);

	//���δ�Ʈ Ÿ��
	if (g_option.pinputProductType == NULL)
	{
		ptempString = readIniString("VERIFICATION","ProductType","c");
		g_option.pinputProductType = checkProductTypeOption(ptempString);
	}

	//�ռ� Ÿ��
	if (g_option.pinputCompositionType == NULL)
	{
		ptempString = readIniString("VERIFICATION","CompositionType","a");
		g_option.pinputCompositionType = checkCompositionTypeOption(ptempString);
	}

	//�׸����� Ÿ��
	if (g_option.imageFileType < 0)
	{
		g_option.imageFileType = readIniInt("IMAGE","Type",IMAGE_PNG);
	}

	g_option.pAWSCompFileName = readIniString("VERIFICATION","KoreaAwsAll","aws_comp.txt");

	g_option.AWSRadarInterpolationDist = readIniFloat("VERIFICATION","InterpolationDist",30.);

	g_option.minAWSRainrate = readIniFloat("THRESHOLD_VALUE","MinAWSRainrate",0.1);
	g_option.maxAWSRainrate = readIniFloat("THRESHOLD_VALUE","MaxAWSRainrate",200.0);
	g_option.minRadarRainrate = readIniFloat("THRESHOLD_VALUE","MinRadarRainrate",0.1);
	g_option.maxRadarRainrate = readIniFloat("THRESHOLD_VALUE","MaxRadarRainrate",200.0);

	//ptempString = readIniString("VERIFICATION_DIRECTORY","Aws2kmImage","DATA/rar/verification/image/aws-2km/");
	ptempString = readIniString("VERIFICATION_DIRECTORY","Aws2kmImage","DATA/IMG/VERI_AWS/");
	sprintf(g_option.verificationAWS2kmImagePath,"%s%s",g_option.pprogramRootPath,ptempString);
	free(ptempString);
	
	//ptempString = readIniString("VERIFICATION_DIRECTORY","Radar2kmImage","DATA/rar/verification/image/radar-2km/");
	ptempString = readIniString("VERIFICATION_DIRECTORY","Radar2kmImage","DATA/IMG/VERI_RDR/");
	sprintf(g_option.verificationRadar2kmImagePath,"%s%s",g_option.pprogramRootPath,ptempString);
	free(ptempString);

	//ptempString = readIniString("VERIFICATION_DIRECTORY","Diff2kmIage","DATA/rar/verification/image/diff-2km/");
	ptempString = readIniString("VERIFICATION_DIRECTORY","Diff2kmIage","DATA/IMG/VERI_DIF/");
	sprintf(g_option.verificationDiff2kmImagePath,"%s%s",g_option.pprogramRootPath,ptempString);
	free(ptempString);
	
    //ptempString = readIniString("VERIFICATION_DIRECTORY","RaintableData","DATA/rar/verification/data/raintable/");
	ptempString = readIniString("VERIFICATION_DIRECTORY","RaintableData","DATA/TXT/VERI_RN/");
	sprintf(g_option.verificationRainTableDataPath,"%s%s",g_option.pprogramRootPath,ptempString);
	free(ptempString);
	
	//ptempString = readIniString("VERIFICATION_DIRECTORY","ZRtableData","DATA/rar/verification/data/zrtable/");
	ptempString = readIniString("VERIFICATION_DIRECTORY","ZRtableData","DATA/TXT/VERI_ZR/");
	sprintf(g_option.verificationZRTableDataPath,"%s%s",g_option.pprogramRootPath,ptempString);
	free(ptempString);

	//ptempString = readIniString("VERIFICATION_DIRECTORY","SpaceStatisticsData","DATA/rar/verification/data/space_statistics/");	
	ptempString = readIniString("VERIFICATION_DIRECTORY","SpaceStatisticsData","DATA/TXT/VERI_SP/");
	sprintf(g_option.verificationSpaceStatticsDataPath,"%s%s",g_option.pprogramRootPath,ptempString);
	free(ptempString);

	//ptempString = readIniString("VERIFICATION_DIRECTORY","TimeStastisticsData","DATA/rar/verification/data/time_statistics/");	
	ptempString = readIniString("VERIFICATION_DIRECTORY","TimeStastisticsData","DATA/TXT/VERI_TI/");
	sprintf(g_option.verificationTimeStatticsDataPath,"%s%s",g_option.pprogramRootPath,ptempString);
	free(ptempString);

	//ȯ�漳�� ���� �̸� ����
	destroyIniFile();

	return 1;
}

/**
 * @brief ȯ�漳������(sites.ini)�κ��� �̿밡���� ���̴� ����Ʈ ������ ����.
 * @param g_site sites.ini�� ������ ����Ǵ� ��������.
 * @return  ������ 1: ����, 1�̿��� ����: ����
 * @author �豤ȣ
 */
int initRadar()
{
	char iniFileName[MAX_STRING_LENGTH];

	int i;
	int ERROR_CODE;
	int x;
	int y;

	for (y = 0; y < YDIM ; y++ )
	{
		for (x = 0; x < XDIM ; x++ )
		{
			g_composition.data[y][x] = BAD_VALUE_F;
			g_composition.inBound[y][x] = MAP_VALUE_RANGE_OUT;
		}
	}

	sprintf(iniFileName,"%sRES/%s",g_option.pprogramRootPath,SETUP_SITES_INI_FILENAME);

	//site_count
	if ((ERROR_CODE = createIniFile(iniFileName)) < 0)
		return ERROR_CODE;
	g_option.siteCount = readIniInt("SITE","count",0);
	destroyIniFile();

	g_site = malloc(g_option.siteCount * sizeof(SITE));
	if (g_site == NULL)
	{
		fprintf(stderr,"malloc error\n");	
		exit(0);
	}

	for (i = 0; i < g_option.siteCount ; i++ )
	{
		initSite(i);
	}

	return 1;
}

/**
 * @brief ȯ�漳������(sites.ini)�� ������ �б� ���� �Լ�.
 * @param siteIndex ���̴� ����Ʈ �ε���
 * @return  ������ 1: ����, -9999: ����
 * @author �豤ȣ
 */
static int initSite(int siteIndex)
{
	char iniFileName[MAX_STRING_LENGTH];

	int ERROR_CODE;
	char title[MAX_STRING_LENGTH];

	sprintf(iniFileName,"%sRES/%s",g_option.pprogramRootPath,SETUP_SITES_INI_FILENAME);

	if ((ERROR_CODE = createIniFile(iniFileName)) < 0)
		return ERROR_CODE;
	//[SITE]���� site�̸� ����
	sprintf(title,"site%d",siteIndex+1);
	g_site[siteIndex].pname = readIniString("SITE",title,NULL);
		if (g_site[siteIndex].pname == NULL) goto INIT_SITE_ERROR;
	g_site[siteIndex].xdim = readIniInt(g_site[siteIndex].pname,"Xdim",480);
	g_site[siteIndex].ydim = readIniInt(g_site[siteIndex].pname,"Ydim",480);
	g_site[siteIndex].useRAR = readIniInt(g_site[siteIndex].pname,"UseRar",0);
	g_site[siteIndex].use = g_site[siteIndex].useRAR;

	g_site[siteIndex].zr.a = BAD_VALUE_F;
	g_site[siteIndex].zr.b = BAD_VALUE_F;
	g_site[siteIndex].zr.route = -1;

	destroyIniFile();

	return 1;

INIT_SITE_ERROR:
	{
		g_site[siteIndex].use = 0;
		destroyIniFile();
		return -9999;
	}

	return 1;
}

/**
 * @brief ���̴� �ռ� �ڷ�� ����Ʈ�� �ڷ��� �ʱ�ȭ
 * @return  ������ 1: ����
 * @author �豤ȣ
 */
int clearRadar()
{
	int i;
	clearComposition();

	for (i = 0 ; i < g_option.siteCount ; i++ )
	{
		g_site[i].zr.a = BAD_VALUE_F;
		g_site[i].zr.b = BAD_VALUE_F;
		g_site[i].zr.route = -1;
	}
	return 1;
}

/**
 * @brief ���̴� �ռ� �ڷ��� �ʱ�ȭ
 * @return  ������ 1: ����
 * @author �豤ȣ
 */
static int clearComposition()
{
	int x;
	int y;
	for (y = 0; y < YDIM ; y++ )
	{
		for (x = 0; x < XDIM ; x++ )
		{
			g_composition.data[y][x] = BAD_VALUE_F;
			g_composition.inBound[y][x] = MAP_VALUE_RANGE_OUT;
		}
	}
	return 1;
}

/**
 * @brief ��� ���̳ʸ� ���� �̸� ���� - ��ü �޸� ����
 * @param resolution �ռ��ڷ��� �ػ�
 * @param flag Z-R ���� ��Ʈ
 * @return pfilename ���ϸ�
 * @author �豤ȣ
 */
static char* generateCompositionBinaryFileName(int resolution, int flag)
//reolution : �������� �ػ� : 1 or 5
{
	char productTypeChar = ' ';
	char compositionTypeChar = ' ';
	char fileExt[MAX_STRING_LENGTH];
	char routeChar = ' ';
	char* pfileName;

	switch (g_option.productType)
	{
		case PRODUCT_PPI	: productTypeChar = 'p';	break;
		case PRODUCT_BASE	: productTypeChar = 'b';	break;
		case PRODUCT_CAPPI	: productTypeChar = 'c';	break;
	}

	switch (g_option.compositionType)
	{
		case COMPTYPE_MAX		: compositionTypeChar = 'm'; break;
		case COMPTYPE_AVERAGE	: compositionTypeChar = 'a'; break;
		case COMPTYPE_NEAR		: compositionTypeChar = 'n'; break;
		case COMPTYPE_D_W		: compositionTypeChar = 'w'; break;
	}

	switch (flag)
	{
		case ROUTE_AUTO_ZR	: routeChar = '0'; break;
		case NEW_ZR			: routeChar = '1'; break;
		case PREV_ZR		: routeChar = '2'; break;
		case M_P_ZR			: routeChar = '3'; break;
		default				: return NULL;
	}
	//��� ���� �̸� ���
	sprintf(fileExt,"bin.gz");

	pfileName = malloc(MAX_STRING_LENGTH*sizeof(char));

	sprintf(pfileName,"%c%d%c%c%c_%s.%s",
		QPE_OUTPUT_FILE_HEADER,resolution,productTypeChar,compositionTypeChar,routeChar,g_option.datetimeString,fileExt);

	return pfileName;

}

/**
 * @brief QPE�� �ռ����� ���̳ʸ� �ڷḦ �д� �Լ�
 * @param flag Z-R ���� ��Ʈ
 * @param pcomp �ռ� ���� ����ü
 * @return ������ 1: ���� ����: ����
 * @author �豤ȣ
 */
int readCompositionDataBinaryGzip(int flag, COMPOSITION* pcomp)
{
	FILE* pfp;
	int lerrno;
	char* pfileName;
	char pathFileName[MAX_STRING_LENGTH];

	pfileName = generateCompositionBinaryFileName(1,flag);
	sprintf(pathFileName,"%s%s",g_option.compositionQPE1kmDataPath,pfileName);

	printf("composition_qpe_1km_data_path = %s\n",pathFileName);
	//write 1 byte char
	if ((pfp = gzopen(pathFileName,"r")) == NULL)
	{
		return -1;
	}
	if (gzread(pfp,pcomp->data,sizeof(g_composition.data)) < 0)
	{
		printf("%s\n",gzerror(pfp,&lerrno));
		return -9999;
	}
	if (gzread(pfp,pcomp->inBound,sizeof(g_composition.inBound)) < 0)
	{
		printf("%s\n",gzerror(pfp,&lerrno));
		return -9999;
	}
	if (gzread(pfp,pcomp->mapData,sizeof(g_composition.mapData)) < 0)
	{
		printf("%s\n",gzerror(pfp,&lerrno));
		return -9999;
	}

	gzclose(pfp);

	free(pfileName);
	
	return 1;
}

/**
 * @brief ����ڰ� �Է��� ���δ�Ʈ Ÿ���� �ؼ���.
 * @param pstr
 * @return pproductType ����ڰ� �Է��� ���δ�Ʈ Ÿ�Կ� �ش��ϴ� ��� '1', �ش����� �ʴ� ��� '0'�� ��ȯ
 * @author �豤ȣ
 */
int* checkProductTypeOption(char* pstr)
{
	int i;
	int* pproductType;

	pproductType = malloc(PRODUCT_TYPE_COUNT * sizeof(int));
	for (i = 0 ; i < PRODUCT_TYPE_COUNT ; i++ )
	{
		pproductType[i] = 0;
	}

	if (strstr(pstr,"p") != NULL)
		pproductType[PRODUCT_PPI] = 1;
	if (strstr(pstr,"b") != NULL)
		pproductType[PRODUCT_BASE] = 1;
	if (strstr(pstr,"c") != NULL)
		pproductType[PRODUCT_CAPPI] = 1;
	if (strstr(pstr,"e") != NULL)
	{
		for (i = 0 ; i < PRODUCT_TYPE_COUNT ; i++ )
		{
			pproductType[i] = 1;
		}
	}

	return pproductType;
}

/**
 * @brief ����ڰ� �Է��� �ռ���� Ÿ���� �ؼ���.
 * @param pstr
 * @return pcompositionType ����ڰ� �Է��� �ռ���� Ÿ�Կ� �ش��ϴ� ��� '1', �ش����� �ʴ� ��� '0'�� ��ȯ
 * @author �豤ȣ
 */
int* checkCompositionTypeOption(char* pstr)
{
	int i;
	int* pcompositionType;

	pcompositionType = malloc(COMPTYPE_COUNT * sizeof(int));
	for (i = 0 ; i < COMPTYPE_COUNT ; i++ )
	{
		pcompositionType[i] = 0;
	}

	if (strstr(pstr,"m") != NULL)
		pcompositionType[COMPTYPE_MAX] = 1;
	if (strstr(pstr,"a") != NULL)
		pcompositionType[COMPTYPE_AVERAGE] = 1;
	if (strstr(pstr,"n") != NULL)
		pcompositionType[COMPTYPE_NEAR] = 1;
	if (strstr(pstr,"w") != NULL)
		pcompositionType[COMPTYPE_D_W] = 1;
	if (strstr(pstr,"e") != NULL)
	{
		for (i = 0 ; i < COMPTYPE_COUNT ; i++ )
		{
			pcompositionType[i] = 1;
		}
	}

	return pcompositionType;
}

/**
 * @brief ZR ��� ���� ���ϸ� ���� �Լ�
 * @param beforeMinutes ���� �ð�
 * @return pZRPathFilename ���ϰ�� �� ���ϸ�
 * @author �豤ȣ
 */
static char* generateZRLogFileName(int beforeMinutes, int fixRoute) //KKH add fixRoute
{
	char productTypeString[MAX_STRING_LENGTH];
	struct tm datetime;
	char fileDatetimeStr[MAX_STRING_LENGTH];
	char* zrPathFileName;
	char productTypeChar=' '; //KKH

	datetime = convStrToDateTime(g_option.datetimeString);

	datetime = incMin(datetime,beforeMinutes);

	strftime(fileDatetimeStr,MAX_STRING_LENGTH,"%Y%m%d%H%M",&datetime);

	switch (g_option.productType)
	{
		case PRODUCT_PPI	: 
			sprintf(productTypeString,"ppi");
			break;
		case PRODUCT_BASE	: 
			sprintf(productTypeString,"base");
			break;
		case PRODUCT_CAPPI	: 
			sprintf(productTypeString,"cappi");
			break;
		default :
			return NULL;
	}
	
	switch (g_option.productType) //KKH
	{
		case PRODUCT_PPI	: productTypeChar = 'P';	break;
		case PRODUCT_BASE	: productTypeChar = 'B';	break;
		case PRODUCT_CAPPI	: productTypeChar = 'C';	break;
	}

	zrPathFileName = malloc(MAX_STRING_LENGTH * sizeof(char));

	sprintf(zrPathFileName,"%sLOG/ZR/%s/%s.zr%c%d",g_option.pprogramRootPath,productTypeString,fileDatetimeStr,productTypeChar,fixRoute); //KKH add fixRoute

	return zrPathFileName;
}

/**
 * @brief ��ü ����Ʈ�� Z-R ��� �д� �Լ�.
 * @return 1: ����
 * @author �豤ȣ
 */
int readZR(int fixRoute) //KKH add fixRoute
{
	int i;
	for (i = 0 ; i < g_option.siteCount ; i++ )
	{
		if (!g_site[i].use) continue;

		g_site[i].zr = readSiteZR(g_site[i].pname,fixRoute); //KKH add fixRoute
		if (g_site[i].zr.route >= 0)
		{
			g_site[i].use = 1;
		}
		else
		{
			g_site[i].use = 0;
		}
		printf("%s %f %f %d\n",g_site[i].pname,g_site[i].zr.a,g_site[i].zr.b,g_site[i].zr.route);
	}

	return 1;
}

/**
 * @brief �� ����Ʈ�� Z-R ��� �д� �Լ�.
 * @param psiteInitial ����Ʈ �̴ϼ�
 * @return zrErr ����Ʈ�� Z-R ���
 * @author �豤ȣ
 */
static ZR_VALUE readSiteZR(char* psiteInitial, int fixRoute) //KKH add fixRoute
{
	FILE* pfp;

	char datetimeStr[MAX_STRING_LENGTH];
	char buffer[MAX_STRING_LENGTH];
	char tempSiteInitial[MAX_STRING_LENGTH];
	char* zrPathFileName;

	ZR_VALUE zr;

	ZR_VALUE zrErr;

	//�ʱ�ȭ
	zrErr.a = BAD_VALUE_F;
	zrErr.b = BAD_VALUE_F;
	zrErr.route = -1;

	//���� �̸� ����
	zrPathFileName = generateZRLogFileName(0, fixRoute);
	if (zrPathFileName == NULL) return zr;

	if ((pfp = fopen(zrPathFileName,"r")) == NULL) return zr;
	free(zrPathFileName);

	//����Ʈ �̸��� ��ġ�ϸ� ���
	while (fgets(buffer,MAX_STRING_LENGTH,pfp) != NULL)
	{
		sscanf(buffer,"%s %f %f %d\n",tempSiteInitial,&zr.a,&zr.b,&zr.route);
		//error check
		if (zr.a < 0.001 || zr.a > 9999. || zr.b < 0.001 || zr.b > 100. || 
				zr.route < 0 || zr.route > (ROUTE_COUNT))
		{
			printf("       * error in loading prevZR : %s %s a = %f b = %f route = %d \n",datetimeStr,tempSiteInitial,zr.a,zr.b,zr.route);
			continue;
		}

		if (strstr(tempSiteInitial,psiteInitial) == NULL)	continue;

		fclose(pfp);
		return zr;
	}
	fclose(pfp);

	return zrErr;
}

/**
 * @brief 2km �ػ� ������ ����(1km�����͸� ������ ������).
 * @param pcomp2km 2km �ػ� �ڷ��� ����ü
 * @return ������ 1: ����
 * @author �豤ȣ
 */
int generate2kmDataQPE2(COMPOSITION_2KM* pcomp2km)
{
	int x2;
	int y2;

	//���̴� ���� ����
	for (y2 = 0 ; y2 < YDIM_2; y2++ )
		for (x2 = 0 ; x2 < XDIM_2 ; x2++ )
			pcomp2km->inBound[y2][x2] = MAP_VALUE_RANGE_OUT;
	for (y2 = 0; y2 < YDIM_2 ; y2++ )
	{
		for (x2 = 0; x2 < XDIM_2 ; x2++ )
		{
			if ((x2*2+1 > XDIM) || (y2*2+1 > YDIM))
			{
				pcomp2km->data[y2][x2] = BAD_VALUE_F;
				pcomp2km->inBound[y2][x2] = MAP_VALUE_RANGE_OUT;
				pcomp2km->mapData[y2][x2] = MAP_VALUE_MAP_NONE;
			}
			//���̴� ������
			pcomp2km->data[y2][x2] = maxFloat(	g_composition.data[y2*2][x2*2],	g_composition.data[y2*2+1][x2*2],
													g_composition.data[y2*2][x2*2+1],g_composition.data[y2*2+1][x2*2+1]);
			//���� ����
			if (g_composition.inBound[y2*2][x2*2] == MAP_VALUE_RANGE_IN || 	g_composition.inBound[y2*2+1][x2*2] == MAP_VALUE_RANGE_IN || 
				g_composition.inBound[y2*2][x2*2+1] == MAP_VALUE_RANGE_IN || g_composition.inBound[y2*2+1][x2*2+1] == MAP_VALUE_RANGE_IN)
				pcomp2km->inBound[y2][x2] = MAP_VALUE_RANGE_IN;
				
			//���̴��� �ִ� �߽� ������ ��ġ ã��
			if (g_composition.inBound[y2*2][x2*2]	==	MAP_VALUE_RADAR_POSITION || g_composition.inBound[y2*2+1][x2*2]	==	MAP_VALUE_RADAR_POSITION || 
				g_composition.inBound[y2*2][x2*2+1]	==	MAP_VALUE_RADAR_POSITION || g_composition.inBound[y2*2+1][x2*2+1]==	MAP_VALUE_RADAR_POSITION)
			{
					pcomp2km->inBound[y2][x2] =	MAP_VALUE_RADAR_POSITION;
			}
		}
	}

	return 1;
}

/**
 * @brief �ִ밪 ����(float)
 * @param data0
 * @param data1
 * @param data2
 * @param data3
 * @return max �ִ밪
 * @author �豤ȣ
 */
float maxFloat(float data0,float data1,float data2,float data3)
{
	float max = BAD_VALUE_F;
	if (max < data0) max = data0;
	if (max < data1) max = data1;
	if (max < data2) max = data2;
	if (max < data3) max = data3;

	return max;
}

/**
 * @brief ���� ��� ���� �̸� ���� �Լ�.
 * @param type ���� ��� �ڷ� ����
 * @return pveri2kmPathFileName ���� ��� ���ϸ�
 * @author �豤ȣ
 */
char* generateVerificationFileName(int type)
//type : 0 : Aws
//type : 1 : Radar
//type : 2 : Diff
//type : 3 : raintable Text
//type : 4 : Zrtable text
//type : 5 : Space static text
//type : 6 : time static text
{
	char typeChar = ' ';
	char productTypeChar = ' ';
	char compositionTypeChar = ' ';
	char fileExt[MAX_STRING_LENGTH];
	char* pveri2kmPathFileName;

	switch (g_option.productType)
	{
		case PRODUCT_PPI	: productTypeChar = 'p';	break;
		case PRODUCT_BASE	: productTypeChar = 'b';	break;
		case PRODUCT_CAPPI	: productTypeChar = 'c';	break;
	}

	switch (g_option.compositionType)
	{
		case COMPTYPE_MAX		: compositionTypeChar = 'm'; break;
		case COMPTYPE_AVERAGE	: compositionTypeChar = 'a'; break;
		case COMPTYPE_NEAR		: compositionTypeChar = 'n'; break;
		case COMPTYPE_D_W		: compositionTypeChar = 'w'; break;
	}

	pveri2kmPathFileName = malloc(MAX_STRING_LENGTH*sizeof(char));

	//���� �̸�
	switch (type)
	{
		case 0 :
			typeChar = 'a';
			if (g_option.imageFileType == IMAGE_PNG)		sprintf(fileExt,"png");
			else if (g_option.imageFileType == IMAGE_GIF)	sprintf(fileExt,"gif");
			sprintf(pveri2kmPathFileName,"%s%c%c%c%c%d_%s.%s",g_option.verificationAWS2kmImagePath
				,VERIFICATION_OUTPUT_FILE_HEADER,typeChar,productTypeChar,compositionTypeChar,g_option.fixRoute2,g_option.datetimeString,fileExt); //KKH g_option.fixRoute2
			break;
		case 1 :
			typeChar = 'r';
			if (g_option.imageFileType == IMAGE_PNG)		sprintf(fileExt,"png");
			else if (g_option.imageFileType == IMAGE_GIF)	sprintf(fileExt,"gif");
			sprintf(pveri2kmPathFileName,"%s%c%c%c%c%d_%s.%s",g_option.verificationRadar2kmImagePath
				,VERIFICATION_OUTPUT_FILE_HEADER,typeChar,productTypeChar,compositionTypeChar,g_option.fixRoute2,g_option.datetimeString,fileExt); //KKH g_option.fixRoute2
			break;
		case 2 :
			typeChar = 'd';
			if (g_option.imageFileType == IMAGE_PNG)		sprintf(fileExt,"png");
			else if (g_option.imageFileType == IMAGE_GIF)	sprintf(fileExt,"gif");
			sprintf(pveri2kmPathFileName,"%s%c%c%c%c%d_%s.%s",g_option.verificationDiff2kmImagePath
				,VERIFICATION_OUTPUT_FILE_HEADER,typeChar,productTypeChar,compositionTypeChar,g_option.fixRoute2,g_option.datetimeString,fileExt); //KKH g_option.fixRoute2
			break;
		case 3 :
			typeChar = 't';
			sprintf(fileExt,"txt");
			sprintf(pveri2kmPathFileName,"%s%c%c%c%c%d_%s.%s",g_option.verificationRainTableDataPath
				,VERIFICATION_OUTPUT_FILE_HEADER,typeChar,productTypeChar,compositionTypeChar,g_option.fixRoute2,g_option.datetimeString,fileExt); //KKH g_option.fixRoute2
			break;
		case 4 :
			typeChar = 'z';
			sprintf(fileExt,"txt");
			sprintf(pveri2kmPathFileName,"%s%c%c%c%c%d_%s.%s",g_option.verificationZRTableDataPath
				,VERIFICATION_OUTPUT_FILE_HEADER,typeChar,productTypeChar,compositionTypeChar,g_option.fixRoute2,g_option.datetimeString,fileExt); //KKH g_option.fixRoute2
			break;
		case 5 :
			typeChar = 's';
			sprintf(fileExt,"txt");
			sprintf(pveri2kmPathFileName,"%s%c%c%c%c%d_%s.%s",g_option.verificationSpaceStatticsDataPath
				,VERIFICATION_OUTPUT_FILE_HEADER,typeChar,productTypeChar,compositionTypeChar,g_option.fixRoute2,g_option.datetimeString,fileExt); //KKH g_option.fixRoute2
			break;
		case 6 :
			typeChar = 'i';
			sprintf(fileExt,"txt");
			sprintf(pveri2kmPathFileName,"%s%c%c%c%c%d_%s.%s",g_option.verificationTimeStatticsDataPath
				,VERIFICATION_OUTPUT_FILE_HEADER,typeChar,productTypeChar,compositionTypeChar,g_option.fixRoute2,g_option.datetimeString,fileExt); //KKH g_option.fixRoute2
			break;
		default : 
			return NULL;
	}

	return pveri2kmPathFileName;
}

/**
 * @brief 2km �ػ� �ռ� ���� ���� ����(COMPOSITION.mapData)-create_comp_map���� ����
 * @param pcomposition2km �ռ����� ����ü
 * @return  ������ 1: ����, 1�̿��� ����: ����
 * @author �豤ȣ
 */
int readCompositionMap2km(COMPOSITION_2KM* pcomposition2km)
{
	FILE* pfp;
	int y;
	COMP_MAP_HEAD CMH; //

	char compositionMapPathFileName[MAX_STRING_LENGTH];

	sprintf(compositionMapPathFileName,"%sRES/mapping_table/%s",g_option.pprogramRootPath,g_option.pcompositionMapFileName2km);
	if ((pfp = fopen(compositionMapPathFileName,"r")) == NULL)
		return -15002;

	//��� �б�
	fread(&CMH,sizeof(COMP_MAP_HEAD),1,pfp);
	if (littleEndian())
	{
		swap4Bytes(&CMH.version);
		swap4Bytes(&CMH.xdim);
		swap4Bytes(&CMH.ydim);
		swap4Bytes(&CMH.xo);
		swap4Bytes(&CMH.yo);
		swap4Bytes(&CMH.grid);
	}

	if (CMH.version != (int)MAP_TABLE_VERSION)
	{
		fprintf(stderr,"composition map version and mapping taable version is not equal.\n");
		return -97348;
	}
	if (CMH.xdim != XDIM_2 || CMH.ydim != YDIM_2 || CMH.grid != 2)
	{
		fprintf(stderr,"wrong composition map file(%s) or wrong composition data file\n",compositionMapPathFileName);
		return -97349;
	}

	for (y = 0 ; y < YDIM_2 ; y++)
	{
		fread(pcomposition2km->inBound[y],sizeof(char),XDIM_2,pfp);
	}
	for (y = 0 ; y < YDIM_2 ; y++)
	{
		fread(pcomposition2km->mapData[y],sizeof(char),XDIM_2,pfp);
	}

	fclose(pfp);

	return 1;
}
