/**
 * @file verify.c
 * @brief �ռ��췮 ������ ���� ����� ������ ��ϵ� �Լ�
 * @date 2011.09.15
 * @version 1.0
 * @author �豤ȣ
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "rar_verify.h"

int interpolationAWSBarnes(int ni, int nj, float rs, float r1, float r2);
int interpolationRadarBarnes(int ni, int nj, float rs, float r1, float r2);
int interpolationDiffBarnes(int ni, int nj, float rs, float r1, float r2);
static int writeVerifyRainTableTextFile(char* pfileName);
static int writeVerifyZRTableTextFile(char* pfileName);
static int writeVerifySpaceStatisticsTextFile(char* pfileName,float ACC,float bias,float POD,float FAR,float CSI,float ME,float MAE,float MSE,float RMSE,float corr,float AWSMean,float radarMean);
static int writeVerifyTimeStatisticsTextFile(char* pfileName,int *id,float *acc,float *bias,float *pod,float *far,float *csi,float *me,float *mae,float *mse,float *rmse,float *corr,float *aws_mean,float *radar_mean);
static int calSpaceStastics(float* pACC,float* pbias,float* pPOD,float* pFAR,float* pCSI,float* pME,float* pMAE,float* pMSE,float* pRMSE,float* pcorr,float* pAWSMean,float* pradarMean);
static int calTimeStastics();
static float calACC(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//��Ȯ��(ACC, forecast accuracy)
static float calBias(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//BIAS(Bias score)
static float calPOD(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//POD(Probability of Detection)
static float calFAR(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//FAR(Fale Alarm Ratio)
static float calCSI(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//CSI(Critical Success Index)
static float calME(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//��տ���(ME, Mean Error)
static float calMAE(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//������տ���(MAE, Mean Absolute Error)
static float calMSE(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//�����������(MSE, Mean Square Error)
static float calRMSE(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//��������ٿ���(RMSE, Root Mean Square Error)
static float calCorr(int count, int* puse, float* pAWSRainTable, float* pradarRainTable);//������(Correlation Coefficient)
static int calAWSRadarMean(int count, int* puse, float* pAWSRainTable, float* pradarRainTable, float* pAWSMean, float* pradarMean);
static int readVerifyRainTableALLTextFile();
static int* ppastIDTable;
static int** ppastUseTable;
static float** ppastAWSRainTable;
static float** ppastRadarRainTable;
static char** pbk;

/**
 * @brief AWS ���̴� ���췮 �� ��谪 ������ ���� ���� �Լ�
 * @return ������ 1: ����, -9999: ����
 * @author �豤ȣ
 */
int generateRadarDataInAWS()
{
	int i;
	int j;
	int k;
	int ERROR_CODE;
	char* pverificationAWS2kmImageFileName;
	char* pverificationRadar2kmImageFileName;
	char* pverificationDiff2kmImageFileName;
	char* pverificationTextFileName;

	COMPOSITION_2KM composition2km;	//�ռ��ڷ� 2km�ػ�

	float ACC;
	float bias;
	float POD;
	float FAR;
	float CSI;
	float ME;
	float MAE;
	float MSE;
	float RMSE;
	float corr;
	float AWSMean;
	float radarMean;

	float rs;
	float r1;
	float r2;

	int zb;	//�׸� �׸��� �簢���� ũ��
	int x1I;
	int x2I;
	int y1I;
	int y2I;
	int xo;
	int yo;

	g_availableAWSNum = 0;

	//2km�ռ� ���� ���� ����
	if ((ERROR_CODE = readCompositionMap2km(&composition2km)) < 0){
		fprintf(stderr,"call readCompositionMap2km Error No.%d\n",ERROR_CODE);
		return -9999;
	}

	pbk = malloc(YDIM * sizeof(char *));
	for (i = 0 ; i < YDIM ; i++ )
	{
		pbk[i] = malloc(XDIM * sizeof(char));
	}

	//dBZ ���
	for (i = 0 ; i <  g_AWSCount ; i++)
	{
		g_AWS[i].dBZ = BAD_VALUE_F;
		if (!g_AWS[i].use) continue;

		if (g_AWS[i].radarRain > 0)
		{
			g_AWS[i].dBZ = RToDBZ(g_AWS[i].radarRainMp,DEFAULT_ZR_A,DEFAULT_ZR_B);
		}
	}

	//AWS ���� �ľ�
	for (i = 0 ; i <  g_AWSCount ; i++)
	{
		if (!g_AWS[i].use) continue;

		if (g_AWS[i].rain60min < g_option.minAWSRainrate || g_AWS[i].rain60min > g_option.maxAWSRainrate) continue;

		g_availableAWSNum++;
	}

	//DIFFERENCE
	for (i = 0 ; i <  g_AWSCount ; i++)
	{
		if (!g_AWS[i].use) continue;

		if (g_AWS[i].rain60min < g_option.minAWSRainrate || g_AWS[i].rain60min > g_option.maxAWSRainrate) continue;
		if (g_AWS[i].radarRain < g_option.minRadarRainrate || g_AWS[i].radarRain > g_option.maxRadarRainrate) continue;

		g_AWS[i].diff = g_AWS[i].radarRain - g_AWS[i].rain60min;
	}
	//barnes analysis
	zb = g_option.AWSRadarInterpolationDist;
	for (j = 0; j < YDIM; j++)
    {
        for (i = 0; i < XDIM; i++) 
			pbk[j][i] = 0;
    }

	for (k = 0; k < g_AWSCount; k++)
    {
		if (!g_AWS[k].use) continue;

        xo = g_AWS[k].x;
        yo = g_AWS[k].y;
        x1I = xo - zb;
        x2I = xo + zb;
        y1I = yo - zb;
        y2I = yo + zb;
        if (x1I < 0 ) x1I = 0;
        if (x2I > XDIM) x2I = XDIM;
        if (y1I < 0 ) y1I = 0;
        if (y2I > XDIM) y2I = YDIM;

        for (j = y1I; j <= y2I; j++)
        {
            for (i = x1I; i <= x2I; i++)
            {
				if (g_composition.inBound[j][i] != MAP_VALUE_RANGE_OUT)
				{
	                pbk[j][i] = 1;
				}
            }
        }
	}

	// Weighting function
	rs = 1000.0;
	r1 = 1.0/160.0;
	r2 = 1.0/83.0;

	//AWS
	interpolationAWSBarnes(XDIM, YDIM, rs, r1, r2);
	generate2kmDataQPE2(&composition2km);
	pverificationAWS2kmImageFileName = generateVerificationFileName(0);
	printf("verification_aws_2km_image_filename = %s\n",pverificationAWS2kmImageFileName);
	writeComposition2km(pverificationAWS2kmImageFileName, OPERATION_MODE, &composition2km, 2);
	free(pverificationAWS2kmImageFileName);

	//RADAR
	interpolationRadarBarnes(XDIM, YDIM, rs, r1, r2);
	generate2kmDataQPE2(&composition2km);
	pverificationRadar2kmImageFileName = generateVerificationFileName(1);
	printf("verification_radar_2km_image_filename = %s\n",pverificationRadar2kmImageFileName);
	writeComposition2km(pverificationAWS2kmImageFileName, OPERATION_MODE, &composition2km, 1);
	free(pverificationRadar2kmImageFileName);

	//DIFFERENCE
	interpolationDiffBarnes(XDIM, YDIM, rs, r1, r2);
	generate2kmDataQPE2(&composition2km);
	pverificationDiff2kmImageFileName = generateVerificationFileName(2);
	printf("verification_diff_2km_image_filename = %s\n",pverificationDiff2kmImageFileName);
	writeComposition2km(pverificationAWS2kmImageFileName, OPERATION_MODE, &composition2km, 3);
	free(pverificationDiff2kmImageFileName);
	
	//RAINTABLE TEXT
	pverificationTextFileName = generateVerificationFileName(3);
	printf("verification_raintable_text_filename = %s\n",pverificationTextFileName);
	if (writeVerifyRainTableTextFile(pverificationTextFileName) < 0)
	{
		return -9999;
	}

	//ZRTABLE TEXT
	pverificationTextFileName = generateVerificationFileName(4);
	printf("verification_zrtable_text_filename = %s\n",pverificationTextFileName);
	if (writeVerifyZRTableTextFile(pverificationTextFileName) < 0)
	{
		return -9999;
	}

	//SPACE STATISTICS TEXT
	calSpaceStastics(&ACC,&bias,&POD,&FAR,&CSI,&ME,&MAE,&MSE,&RMSE,&corr,&AWSMean,&radarMean);
	pverificationTextFileName = generateVerificationFileName(5);
	printf("write_verify_space_statistics_text_file = %s\n",pverificationTextFileName);
	if (writeVerifySpaceStatisticsTextFile(pverificationTextFileName,ACC,bias,POD,FAR,CSI,ME,MAE,MSE,RMSE,corr,AWSMean,radarMean) < 0)
	{
		return -9999;
	}

	//TIME STATISTICS TEXT
	calTimeStastics();

	return 1;
}

/*********************************************************************
 *
 *  Barnes' objective analysis (2-pass)
 *
 *
 *  by  Lee, Jeung-Whan  (1997. 3. 15)
 *
 *********************************************************************/
/**
* @brief Barnes ����� �̿��� AWS ���� �ܻ��� �����ϴ� �Լ�.
* @param ni
* @param nj
* @param rs
* @param r1
* @param r2
* @return ������ 1: ����, -9999: ����
* @author �豤ȣ
*/
int interpolationAWSBarnes(ni, nj, rs, r1, r2)
    int ni;
    int nj;                  // (grid number-1) of x, y direction               
    float  rs;                      /* (search radius)**2  [grid unit]                  */
    float  r1;                      // 1.0/(smoothing radius)**2  in 1-pass [grid unit]
    float  r2;                      // 1.0/(smoothing radius)**2  in 2-pass [grid unit]
{

    float s1;
    float s2;
    float wt1;
    float wt2;
    float sumWt1;
    float sumWt2;
    float x1;
    float y1;
    float xg;
    float yg;
    float xd;
    float yd;
    float rr;
    int i;
    int j;
    int k;
    int n;
    int ks;

	// 1-pass 
    for(n = 0; n < g_AWSCount; n++)
    {
		if (!g_AWS[n].use) continue;
		if (g_AWS[n].rain60min < g_option.minAWSRainrate || g_AWS[n].rain60min > g_option.maxAWSRainrate) continue;

        x1 = g_AWS[n].x;
        y1 = g_AWS[n].y;

		s1 = 0.0;    sumWt1 = 0.0;

        for(k = 0; k < g_AWSCount; k++)
        {
			if (!g_AWS[k].use) continue;
			if (g_AWS[k].rain60min < g_option.minAWSRainrate || g_AWS[k].rain60min > g_option.maxAWSRainrate) continue;

			xd = x1 - g_AWS[k].x;
            yd = y1 - g_AWS[k].y;
            rr = xd*xd + yd*yd;
            wt1 = exp(-rr*r1);
            s1 += wt1 * g_AWS[k].rain60min;
            sumWt1 += wt1;
        }
        g_AWS[n].s = g_AWS[n].rain60min - s1/sumWt1;
    }

	// 2-pass
    for(j = 0; j < nj; j++)
    {
        yg = (float)j;

		for(i = 0; i < ni; i++)
		{
			xg = (float)i;

			if (pbk[j][i] != 1)
			{
				g_composition.data[j][i] = BAD_VALUE_F;
				continue;
			}

			s1 = 0.0;    sumWt1 = 0.0;
			s2 = 0.0;    sumWt2 = 0.0;

			for(ks = 0, n = 0; n < g_AWSCount; n++)
			{
				if (!g_AWS[n].use) continue;
				if (g_AWS[n].rain60min < g_option.minAWSRainrate || g_AWS[n].rain60min > g_option.maxAWSRainrate) continue;

			    xd = xg - g_AWS[n].x;
			    yd = yg - g_AWS[n].y;
			    rr = xd*xd + yd*yd;

			    if (rr < rs)
			    {
			        ks++;
			        wt1 = exp(-rr*r1);
			        wt2 = exp(-rr*r2);
			        s1 += wt1 * g_AWS[n].rain60min;
			        s2 += wt2 * g_AWS[n].s;
			        sumWt1 += wt1;
			        sumWt2 += wt2;
			    }
			}
			if (ks > 0) {
			    g_composition.data[j][i] = s1/sumWt1 + s2/sumWt2;
				if (g_composition.data[j][i] <= 0)
				{
				    g_composition.data[j][i] = BAD_VALUE_F;
				}
			}
			else {
			    g_composition.data[j][i] = BAD_VALUE_F;
			}
        }
    }
    return 0;
}

/**
* @brief Barnes ����� �̿��� ���̴� ���� �ܻ��� �����ϴ� �Լ�.
* @param ni
* @param nj
* @param rs
* @param r1
* @param r2
* @return ������ 1: ����, -9999: ����
* @author �豤ȣ
*/
int interpolationRadarBarnes(ni, nj, rs, r1, r2)
	int ni;
	int nj;                  // (grid number-1) of x, y direction               
    float  rs;                      /* (search radius)**2  [grid unit]                  */
    float  r1;                      // 1.0/(smoothing radius)**2  in 1-pass [grid unit]
    float  r2;                      // 1.0/(smoothing radius)**2  in 2-pass [grid unit]
{
    float s1;
    float s2;
    float wt1;
    float wt2;
    float sumWt1;
    float sumWt2;
    float x1;
    float y1;
    float xg;
    float yg;
    float xd;
    float yd;
    float rr;
    int i;
    int j;
    int k;
    int n;
    int ks;

    // 1-pass 
    for(n = 0; n < g_AWSCount; n++)
    {
		if (!g_AWS[n].use) continue;
		if (g_AWS[n].radarRain < g_option.minRadarRainrate || g_AWS[n].radarRain > g_option.maxRadarRainrate) continue;

        x1 = g_AWS[n].x;
        y1 = g_AWS[n].y;

		s1 = 0.0;    sumWt1 = 0.0;

        for(k = 0; k < g_AWSCount; k++)
        {
			if (!g_AWS[k].use) continue;
			if (g_AWS[k].radarRain < g_option.minRadarRainrate || g_AWS[k].radarRain > g_option.maxRadarRainrate) continue;

			xd = x1 - g_AWS[k].x;
            yd = y1 - g_AWS[k].y;
            rr = xd*xd + yd*yd;
            wt1 = exp(-rr*r1);
            s1 += wt1 * g_AWS[k].radarRain;
            sumWt1 += wt1;
        }
        g_AWS[n].s = g_AWS[n].radarRain - s1/sumWt1;
    }

	// 2-pass
    for(j = 0; j < nj; j++)
    {
        yg = (float)j;

        for(i = 0; i < ni; i++)
        {
            xg = (float)i;

			if (pbk[j][i] != 1)
			{
                g_composition.data[j][i] = BAD_VALUE_F;
				continue;
			}

			s1 = 0.0;    sumWt1 = 0.0;
			s2 = 0.0;    sumWt2 = 0.0;

			for(ks = 0, n = 0; n < g_AWSCount; n++)
			{
				if (!g_AWS[n].use) continue;
				if (g_AWS[n].radarRain < g_option.minRadarRainrate || g_AWS[n].radarRain > g_option.maxRadarRainrate) continue;

			    xd = xg - g_AWS[n].x;
			    yd = yg - g_AWS[n].y;
			    rr = xd*xd + yd*yd;

			    if (rr < rs)
			    {
			        ks++;
			        wt1 = exp(-rr*r1);
			        wt2 = exp(-rr*r2);
			        s1 += wt1 * g_AWS[n].radarRain;
			        s2 += wt2 * g_AWS[n].s;
			        sumWt1 += wt1;
			        sumWt2 += wt2;
			    }
			}
			if (ks > 0) {
			    g_composition.data[j][i] = s1/sumWt1 + s2/sumWt2;
				if (g_composition.data[j][i] <= 0)
				{
				    g_composition.data[j][i] = BAD_VALUE_F;
				}
			}
			else {
			    g_composition.data[j][i] = BAD_VALUE_F;
			}
        }
    }
    return 0;
}

/**
* @brief Barnes ����� �̿��� ���̴��� AWS�� ���̸� ���� �ܻ��ϴ� �Լ�.
* @param ni
* @param nj
* @param rs
* @param r1
* @param r2
* @return ������ 1: ����, -9999: ����
* @author �豤ȣ
*/
int interpolationDiffBarnes(ni, nj, rs, r1, r2)
	int ni;
	int nj;                  // (grid number-1) of x, y direction               
    float rs;                      /* (search radius)**2  [grid unit]                  */
    float r1;                      // 1.0/(smoothing radius)**2  in 1-pass [grid unit]
    float r2;                      // 1.0/(smoothing radius)**2  in 2-pass [grid unit]
{
    float s1;
    float s2;
    float wt1;
    float wt2;
    float sumWt1;
    float sumWt2;
    float x1;
    float y1;
    float xg;
    float yg;
    float xd;
    float yd;
    float rr;
    int i;
    int j;
    int k;
    int n;
    int ks;

    // 1-pass 
    for(n = 0; n < g_AWSCount; n++)
    {
		if (!g_AWS[n].use) continue;
		if (g_AWS[n].rain60min < g_option.minAWSRainrate || g_AWS[n].rain60min > g_option.maxAWSRainrate) continue;
		if (g_AWS[n].radarRain < g_option.minRadarRainrate || g_AWS[n].radarRain > g_option.maxRadarRainrate) continue;

        x1 = g_AWS[n].x;
        y1 = g_AWS[n].y;

		s1 = 0.0;    sumWt1 = 0.0;

        for(k = 0; k < g_AWSCount; k++)
        {
			if (!g_AWS[k].use) continue;
			if (g_AWS[k].rain60min < g_option.minAWSRainrate || g_AWS[k].rain60min > g_option.maxAWSRainrate) continue;
			if (g_AWS[k].radarRain < g_option.minRadarRainrate || g_AWS[k].radarRain > g_option.maxRadarRainrate) continue;

			xd = x1 - g_AWS[k].x;
            yd = y1 - g_AWS[k].y;
            rr = xd*xd + yd*yd;
            wt1 = exp(-rr*r1);
            s1 += wt1 * g_AWS[k].diff;
            sumWt1 += wt1;
        }
        g_AWS[n].s = g_AWS[n].diff - s1/sumWt1;
    }

	// 2-pass
    for(j = 0; j < nj; j++)
    {
        yg = (float)j;

        for(i = 0; i < ni; i++)
        {
            xg = (float)i;

			if (pbk[j][i] != 1)
			{
                g_composition.data[j][i] = BAD_VALUE_F;
				continue;
			}

			s1 = 0.0;    sumWt1 = 0.0;
			s2 = 0.0;    sumWt2 = 0.0;

			for(ks = 0, n = 0; n < g_AWSCount; n++)
			{
				if (!g_AWS[n].use) continue;
				if (g_AWS[n].rain60min < g_option.minAWSRainrate || g_AWS[n].rain60min > g_option.maxAWSRainrate) continue;
				if (g_AWS[n].radarRain < g_option.minRadarRainrate || g_AWS[n].radarRain > g_option.maxRadarRainrate) continue;

			    xd = xg - g_AWS[n].x;
			    yd = yg - g_AWS[n].y;
			    rr = xd*xd + yd*yd;

			    if (rr < rs)
			    {
			        ks++;
			        wt1 = exp(-rr*r1);
			        wt2 = exp(-rr*r2);
			        s1 += wt1 * g_AWS[n].diff;
			        s2 += wt2 * g_AWS[n].s;
			        sumWt1 += wt1;
			        sumWt2 += wt2;
			    }
			}
			if (ks > 0) {
			    g_composition.data[j][i] = s1/sumWt1 + s2/sumWt2;
			}
			else {
			    g_composition.data[j][i] = BAD_VALUE_F;
			}
        }
    }
    return 0;
}

/**
* @brief ���������� ������/������ ��� ����� �����ϴ� �Լ�
* @param pACC
* @param pbias
* @param pPOD
* @param pFAR
* @param pCSI
* @param pME
* @param pMAE
* @param pMSE
* @param pRMSE
* @param pcorr
* @param pAWSMean
* @param pradarMean
* @return ������ 1: ����
* @author �豤ȣ
*/
static int calSpaceStastics(float* pACC,float* pbias,float* pPOD,float* pFAR,float* pCSI,float* pME,float* pMAE,float* pMSE,float* pRMSE,float* pcorr,float* pAWSMean,float* pradarMean)
{
	int i;
	int count;
	int* puseTable;
	float* pspaceAWSRainTable;		//AWS ���췮
	float* pspaceRadarRainTable;	//���̴� ���췮

	puseTable = malloc(g_AWSCount * sizeof(int));
	pspaceAWSRainTable = malloc(g_AWSCount * sizeof(float));
	pspaceRadarRainTable = malloc(g_AWSCount * sizeof(float));

	for ( i = 0 ; i < g_AWSCount ; i++ )
	{
		puseTable[i] = g_AWS[i].use;
		pspaceAWSRainTable[i] = g_AWS[i].rain60min;
		pspaceRadarRainTable[i] = g_AWS[i].radarRain;
	}
	count = g_AWSCount;


	*pACC = calACC(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pbias = calBias(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pPOD = calPOD(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pFAR = calFAR(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pCSI = calCSI(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pME = calME(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pMAE = calMAE(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pMSE = calMSE(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pRMSE = calRMSE(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	*pcorr = calCorr(count, puseTable,pspaceAWSRainTable,pspaceRadarRainTable);

	calAWSRadarMean(count, puseTable, pspaceAWSRainTable, pspaceRadarRainTable, pAWSMean, pradarMean);
	
	free(puseTable);
	free(pspaceAWSRainTable);
	free(pspaceRadarRainTable);

	return 1;
}

/**
* @brief �ð������� ������/������ ��� ����� �����ϴ� �Լ�
* @return ������ 1: ���� ����: ����
* @author �豤ȣ
*/
static int calTimeStastics()
{
	int i,j;

	int count;

	float* pACC;
	float* pbias;
	float* pPOD;
	float* pFAR;
	float* pCSI;
	float* pME;
	float* pMAE;
	float* pMSE;
	float* pRMSE;
	float* pcorr;
	float* pAWSMean;
	float* pradarMean;

	char* pfileName;

	readVerifyRainTableALLTextFile();

	pACC = malloc(g_AWSCount * sizeof(float));
	pbias = malloc(g_AWSCount * sizeof(float));
	pPOD = malloc(g_AWSCount * sizeof(float));
	pFAR = malloc(g_AWSCount * sizeof(float));
	pCSI = malloc(g_AWSCount * sizeof(float));
	pME = malloc(g_AWSCount * sizeof(float));
	pMAE = malloc(g_AWSCount * sizeof(float));
	pMSE = malloc(g_AWSCount * sizeof(float));
	pRMSE = malloc(g_AWSCount * sizeof(float));
	pcorr = malloc(g_AWSCount * sizeof(float));
	pAWSMean = malloc(g_AWSCount * sizeof(float));
	pradarMean = malloc(g_AWSCount * sizeof(float));

	for (i = 0 ; i < g_AWSCount ; i++ )
	{
		for ( j = 0 ; j < 144 ; j++ )
		{
			if (ppastAWSRainTable[i][j] == BAD_VALUE_F || ppastRadarRainTable[i][j] == BAD_VALUE_F)
			{
				ppastUseTable[i][j] = 0;
			}
			else
			{
				ppastUseTable[i][j] = 1;
			}
		}
	}
	count = 144;
	for ( i = 0 ; i < g_AWSCount ; i++ )
	{
		pACC[i] = calACC(count, ppastUseTable[i],ppastAWSRainTable[i],ppastRadarRainTable[i]);

		pbias[i] = calBias(count, ppastUseTable[i],ppastAWSRainTable[i],ppastRadarRainTable[i]);

		pPOD[i] = calPOD(count, ppastUseTable[i],ppastAWSRainTable[i],ppastRadarRainTable[i]);

		pFAR[i] = calFAR(count, ppastUseTable[i],ppastAWSRainTable[i],ppastRadarRainTable[i]);

		pCSI[i] = calCSI(count, ppastUseTable[i],ppastAWSRainTable[i],ppastRadarRainTable[i]);

		pME[i] = calME(count, ppastUseTable[i],ppastAWSRainTable[i],ppastRadarRainTable[i]);

		pMAE[i] = calMAE(count, ppastUseTable[i],ppastAWSRainTable[i],ppastRadarRainTable[i]);

		pMSE[i] = calMSE(count, ppastUseTable[i],ppastAWSRainTable[i],ppastRadarRainTable[i]);

		pRMSE[i] = calRMSE(count, ppastUseTable[i],ppastAWSRainTable[i],ppastRadarRainTable[i]);

		pcorr[i] = calCorr(count, ppastUseTable[i],ppastAWSRainTable[i],ppastRadarRainTable[i]);

		calAWSRadarMean(count, ppastUseTable[i], ppastAWSRainTable[i], ppastRadarRainTable[i], &pAWSMean[i], &pradarMean[i]);
	}
	pfileName = generateVerificationFileName(6);
	printf("write_verify_time_statistics_text_file = %s\n",pfileName);
	if (writeVerifyTimeStatisticsTextFile(pfileName,ppastIDTable,pACC,pbias,pPOD,pFAR,pCSI,pME,pMAE,pMSE,pRMSE,pcorr,pAWSMean,pradarMean) < 0)
	{
		return -9999;
	}


	for (i = 0 ; i < g_AWSCount ; i++ )
	{
		free(ppastUseTable[i]);
		free(ppastAWSRainTable[i]);
		free(ppastRadarRainTable[i]);
	}
	free(ppastUseTable);
	free(ppastAWSRainTable);
	free(ppastRadarRainTable);

	free(ppastIDTable);

	return 1;
}

/**
* @brief ��� AWS ID�� ���ؼ� �Ϸ� ������ �а� ��� �����ϴ� �Լ�
* @return ������ 1: ����
* @author �豤ȣ
*/
static int readVerifyRainTableALLTextFile()
{
	int i;
	int j;
	FILE* pfp;
	char buffer[MAX_STRING_LENGTH];
	struct tm fileTime;
	int id;
	float rain60min;
	float radarRain;
	float radarRainMp;
	float diff;
	char filename[MAX_STRING_LENGTH];
	char datetimeString[MAX_STRING_LENGTH];
	char typeChar = ' ';
	char productTypeChar = ' ';
	char compositionTypeChar = ' ';
	char fileExt[MAX_STRING_LENGTH];

	ppastUseTable = malloc(g_AWSCount * sizeof(int *));
	ppastAWSRainTable = malloc(g_AWSCount * sizeof(float *));
	ppastRadarRainTable = malloc(g_AWSCount * sizeof(float *));

	for (i = 0 ; i < g_AWSCount ; i++ )
	{
		ppastUseTable[i] = malloc(144 * sizeof(int));
		ppastAWSRainTable[i] = malloc(144 * sizeof(float));
		ppastRadarRainTable[i] = malloc(144 * sizeof(float));
	}
	ppastIDTable = malloc(g_AWSCount * sizeof(int));

	typeChar = 't';
	sprintf(fileExt,"txt");
	switch (g_option.productType)
	{
		case PRODUCT_PPI	: productTypeChar = 'p';	break;
		case PRODUCT_BASE	: productTypeChar = 'b';	break;
		case PRODUCT_CAPPI	: productTypeChar = 'c';	break;
	}

	switch (g_option.compositionType)
	{
		case COMPTYPE_MAX		: compositionTypeChar = 'm'; break;
		case COMPTYPE_AVERAGE	: compositionTypeChar = 'a'; break;
		case COMPTYPE_NEAR		: compositionTypeChar = 'n'; break;
		case COMPTYPE_D_W		: compositionTypeChar = 'w'; break;
	}

	for (i = 0 ; i < g_AWSCount ; i++ )
	{
		for (j = 0 ; j < 144 ; j++ )
		{
			ppastUseTable[i][j] = 0;
			ppastAWSRainTable[i][j] = BAD_VALUE_F;
			ppastRadarRainTable[i][j] = BAD_VALUE_F;
		}
	}

	for (i = 0 ; i < g_AWSCount ; i++ )
	{
		ppastIDTable[i] = g_AWS[i].id;
	}

	fileTime = convStrToDateTime(g_option.datetimeString);
	//ù ������ [����ð� - 23h 50m���� ����]
	fileTime = incDay(fileTime,-1);
	fileTime = incMin(fileTime,10);
	for (i = 0 ; i < 144 ; i++ )
	{
		strftime(datetimeString,sizeof(datetimeString),"%Y%m%d%H%M",&fileTime);
		sprintf(filename,"%s%c%c%c%c%d_%s.%s",g_option.verificationRainTableDataPath
			,VERIFICATION_OUTPUT_FILE_HEADER,typeChar,productTypeChar,compositionTypeChar,g_option.fixRoute2,datetimeString,fileExt);
		//printf("%d : %s\n",i,filename);
		fileTime = incMin(fileTime,10);
		if ((pfp = fopen(filename,"r"))== NULL) continue;

		while (fgets(buffer,sizeof(buffer),pfp) != NULL)
		{
			sscanf(buffer,"%d %f %f %f %f",&id,&rain60min,&radarRain,&diff,&radarRainMp);
			for (j = 0 ; j < g_AWSCount ; j++ )
			{
				if (id == ppastIDTable[j])
				{
					ppastAWSRainTable[j][i] = rain60min;
					ppastRadarRainTable[j][i] = radarRain;
					break;
				}
			}
		}

		fclose(pfp);
	}
	
	return 1;
}

/**
* @brief ������ ���� �Լ�(��Ȯ��: ACC)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return ACC
* @author �豤ȣ
*/
static float calACC(int count, int* puse, float* pAWSRainTable, float* pradarRainTable)
{
	int Z;
	int F;
	int M;
	int H;
	int N;
	int i;
	float ACC;

	N = 0;
	Z = 0;
	F = 0;
	M = 0;
	H = 0;
	for (i = 0 ; i < count ; i++)
	{
		N++;
		if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate ) H++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate) F++;
		else if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate ) M++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate) Z++;

	}

	if (N <= 0)
	{
		return BAD_VALUE_F;
	}
	ACC = (Z+H)/(N*1.);
	if (isnormal(ACC))
	{
		return (float)ACC;
	}
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(Bias score)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return bias
* @author �豤ȣ
*/
static float calBias(int count, int* puse, float* pAWSRainTable, float* pradarRainTable)
{
	int Z;
	int F;
	int M;
	int H;
	int N;
	int i;
	float bias;

	N = 0;
	Z = 0;
	F = 0;
	M = 0;
	H = 0;
	for (i = 0 ; i < count ; i++)
	{
		N++;
		if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate ) H++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate) F++;
		else if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate ) M++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate) Z++;
	}

	if ((M+H) <= 0)
    {
		return BAD_VALUE_F;
	}
	bias = (F+H)/((M+H)*1.);

	if (isnormal(bias))
		return (float)bias;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(POD)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return POD
* @author �豤ȣ
*/
static float calPOD(int count, int* puse,float* pAWSRainTable, float* pradarRainTable)
{
	int Z;
	int F;
	int M;
	int H;
	int N;
	int i;
	float POD;

	N = 0;
	Z = 0;
	F = 0;
	M = 0;
	H = 0;
	for (i = 0 ; i < count ; i++)
	{
		N++;
		if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate ) H++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate) F++;
		else if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate ) M++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate) Z++;
	}

	if ((M+H) <= 0) 
	{
		return BAD_VALUE_F;
	}
	POD = (H)/((M+H)*1.);

	if (isnormal(POD))
		return (float)POD;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(FAR)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return FAR
* @author �豤ȣ
*/
static float calFAR(int count, int* puse, float* pAWSRainTable, float* pradarRainTable)
{
	int Z;
	int F;
	int M;
	int H;
	int N;
	int i;
	float FAR;

	N = 0;
	Z = 0;
	F = 0;
	M = 0;
	H = 0;
	for (i = 0 ; i < count ; i++)
	{
		N++;
		if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate ) H++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate) F++;
		else if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate ) M++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate) Z++;
	}

	if ((F+H) <= 0 )  
	{
		return BAD_VALUE_F;
	}
	FAR = (F)/((F+H)*1.);

	if (isnormal(FAR))
		return (float)FAR;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(CSI)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return CSI
* @author �豤ȣ
*/
static float calCSI(int count, int* puse, float* pAWSRainTable, float* pradarRainTable)
{
	int Z;
	int F;
	int M;
	int H;
	int N;
	int i;
	float CSI;

	N = 0;
	Z = 0;
	F = 0;
	M = 0;
	H = 0;
	for (i = 0 ; i < count ; i++)
	{
	
		N++;
		if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate ) H++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] >= g_option.minRadarRainrate) F++;
		else if (pAWSRainTable[i] >= g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate ) M++;
		else if (pAWSRainTable[i] < g_option.minAWSRainrate && pradarRainTable[i] < g_option.minRadarRainrate) Z++;
	}

	if ((H+M+F) <= 0)
	{
		return BAD_VALUE_F;
	}
	CSI = (H)/((H+M+F)*1.);

	if (isnormal(CSI))
		return (float)CSI;
	else
		return BAD_VALUE_F;
}


/**
* @brief ������ ���� �Լ�(ME)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return ME
* @author �豤ȣ
*/
static float calME(int count, int* puse, float* pAWSRainTable, float* pradarRainTable)
{
	float ME;
	float sum = 0;
	int N = 0;
	int i;

	for (i = 0 ; i < count ; i++)
	{
		if (!puse[i]) continue;
		if (pradarRainTable[i] < g_option.minRadarRainrate || pradarRainTable[i] > g_option.maxAWSRainrate) continue;
		if (pAWSRainTable[i] < g_option.minAWSRainrate || pAWSRainTable[i] > g_option.maxAWSRainrate) continue;

		N++;
		sum += pradarRainTable[i] - pAWSRainTable[i];
	}

	if (N <= 0)
	{
		return BAD_VALUE_F;
	}
	ME = sum/(N*1.);

	if (isnormal(ME))
		return (float)ME;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(MAE)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return MAE
* @author �豤ȣ
*/
static float calMAE(int count, int* puse, float* pAWSRainTable, float* pradarRainTable)
{
	float MAE;
	float sum = 0;
	int N = 0;
	int i;

	for (i = 0 ; i < count ; i++)
	{
		if (!puse[i]) continue;
		if (pradarRainTable[i] < g_option.minRadarRainrate || pradarRainTable[i] > g_option.maxAWSRainrate) continue;
		if (pAWSRainTable[i] < g_option.minAWSRainrate || pAWSRainTable[i] > g_option.maxAWSRainrate) continue;

		N++;
		sum += fabs(pradarRainTable[i] - pAWSRainTable[i]);
	}

	if (N <= 0)
	{
		return BAD_VALUE_F;
	}
	MAE = sum/(N*1.);

	if (isnormal(MAE))
		return (float)MAE;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(MSE)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return MSE
* @author �豤ȣ
*/
static float calMSE(int count, int* puse, float* pAWSRainTable, float* pradarRainTable)
{
	float MSE;
	float sum = 0;
	int N = 0;
	int i;

	for (i = 0 ; i < count ; i++)
	{
		if (!puse[i]) continue;
		if (pradarRainTable[i] < g_option.minRadarRainrate || pradarRainTable[i] > g_option.maxAWSRainrate) continue;
		if (pAWSRainTable[i] < g_option.minAWSRainrate || pAWSRainTable[i] > g_option.maxAWSRainrate) continue;

		N++;
		sum += pow((pradarRainTable[i] - pAWSRainTable[i]),2);
	}

	if (N <= 0)
	{
		return BAD_VALUE_F;
	}
	MSE = sum/(N*1.);

	if (isnormal(MSE))
		return (float)MSE;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(RMSE)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return RMSE
* @author �豤ȣ
*/
static float calRMSE(int count, int* puse, float* pAWSRainTable, float* pradarRainTable)
{
	float RMSE;
	float sum = 0;
	int N = 0;
	int i;

	for (i = 0 ; i < count ; i++)
	{
		if (!puse[i]) continue;
		if (pradarRainTable[i] < g_option.minRadarRainrate || pradarRainTable[i] > g_option.maxAWSRainrate) continue;
		if (pAWSRainTable[i] < g_option.minAWSRainrate || pAWSRainTable[i] > g_option.maxAWSRainrate) continue;

		N++;
		sum += pow((pradarRainTable[i] - pAWSRainTable[i]),2);
	}

	if (N <= 0)
	{
		return BAD_VALUE_F;
	}
	RMSE = pow(sum/(N*1.),0.5);

	if (isnormal(RMSE))
		return (float)RMSE;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(corr)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return corr
* @author �豤ȣ
*/
static float calCorr(int count, int *puse,float *pAWSRainTable, float *pradarRainTable)
{
	double corr;
	int i;
	double numerator = 0;
	float denominator = 0;
	float sumNumerator = 0;
	float sumDenominator1 = 0;
	float sumDenominator2 = 0;
	float FMean = 0;
	float OMean = 0;
	float FSum = 0;
	float OSum = 0;
	int N = 0;
	float F;
	float O;


	for (i = 0 ; i < count ; i++)
	{
		if (!puse[i]) continue;
		if (pradarRainTable[i] < g_option.minRadarRainrate || pradarRainTable[i] > g_option.maxAWSRainrate) continue;
		if (pAWSRainTable[i] < g_option.minAWSRainrate || pAWSRainTable[i] > g_option.maxAWSRainrate) continue;

		N++;
		FSum += pradarRainTable[i];
		OSum += pAWSRainTable[i];
	}
	FMean = FSum/(N*1.);
	OMean = OSum/(N*1.);

	if (N <= 0)
	{
		return BAD_VALUE_F;
	}

	for (i = 0 ; i < count ; i++)
	{
		if (!puse[i]) continue;
		if (pradarRainTable[i] < g_option.minRadarRainrate || pradarRainTable[i] > g_option.maxAWSRainrate) continue;
		if (pAWSRainTable[i] < g_option.minAWSRainrate || pAWSRainTable[i] > g_option.maxAWSRainrate) continue;

		F = pradarRainTable[i];
		O = pAWSRainTable[i];

		sumNumerator += (F - FMean) * (O - OMean);

		sumDenominator1 += pow(F - FMean,2);
		sumDenominator2 += pow(O - OMean,2);
	}
	numerator = sumNumerator;

	if (sumDenominator1 < 0 || sumDenominator2 < 0)
	{
		return BAD_VALUE_F;
	}

	denominator = pow(sumDenominator1,0.5) * pow(sumDenominator2,0.5);

	if (denominator == 0)
	{
		return BAD_VALUE_F;
	}

	corr = numerator/denominator;

	if (isnormal(corr))
		return (float)corr;
	else
		return BAD_VALUE_F;
}

/**
* @brief ������ ���� �Լ�(mean)
* @param count
* @param puse
* @param pAWSRainTable
* @param pradarRainTable
* @return pAWSMean, pradarMean 
* @author �豤ȣ
*/
static int calAWSRadarMean(int count, int* puse, float* pAWSRainTable, float* pradarRainTable, float* pAWSMean, float* pradarMean)
{
	int i;
	int availAWSCount = 0;
	int availRadarCount = 0;
	float sumAWS = 0;
	float sumRadar = 0;
	*pAWSMean = BAD_VALUE_F;
	*pradarMean = BAD_VALUE_F;

	for (i = 0 ; i < count ; i++ )
	{
		if (!puse[i]) continue;
		if (pAWSRainTable[i] < g_option.minAWSRainrate || pAWSRainTable[i] > g_option.maxAWSRainrate) continue;
		if (pradarRainTable[i] < g_option.minRadarRainrate || pradarRainTable[i] > g_option.maxRadarRainrate) continue;

		sumAWS += pAWSRainTable[i];
		availAWSCount++;

		sumRadar += pradarRainTable[i];
		availRadarCount++;
	}

	if (availAWSCount > 0)
	{
		*pAWSMean = sumAWS / (availAWSCount*1.);
	}

	if (availRadarCount > 0)
	{
		*pradarMean = sumRadar / (availRadarCount*1.);
	}

	return 0;
}

/**
* @brief ����� ����(Raintable)
* @param pfileName ���ϸ�
* @return ������ 1: ���� ����: ����
* @author �豤ȣ
*/
static int writeVerifyRainTableTextFile(char* pfileName)
{
	int i;
	FILE* pfp;

	if ((pfp = fopen(pfileName,"w"))== NULL)
	{ 
		return -9999;
	}

	for (i = 0 ; i < g_AWSCount ; i++ )
	{
		fprintf(pfp,"%d %6.2f %6.2f %6.2f %6.2f %6.2f\n",g_AWS[i].id,g_AWS[i].rain60min,g_AWS[i].radarRain,g_AWS[i].diff,g_AWS[i].radarRainMp,g_AWS[i].dBZ);
	}
	fclose(pfp);

	return 1;
}

/**
* @brief ����� ����(ZRtable)
* @param pfileName ���ϸ�
* @return ������ 1: ���� ����: ����
* @author �豤ȣ
*/
static int writeVerifyZRTableTextFile(char* pfileName)
{
	int i;
	FILE* pfp;

	if ((pfp = fopen(pfileName,"w"))== NULL)
	{
		return -9999;
	}

	for (i = 0 ; i < g_option.siteCount ; i++ )
	{
		if (g_site[i].useRAR > 0)
			fprintf(pfp,"%s %6.2f %6.2f %d\n",g_site[i].pname,g_site[i].zr.a,g_site[i].zr.b,g_site[i].zr.route);
	}
	fclose(pfp);

	return 1;
}

/**
* @brief ����� ����(�����������ڷ�)
* @param pfileName ���ϸ�
* @param pACC
* @param pbias
* @param pPOD
* @param pFAR
* @param pCSI
* @param pME
* @param pMAE
* @param pMSE
* @param pRMSE
* @param pcorr
* @param pAWSMean
* @param pradarMean
* @return ������ 1: ���� ����: ����
* @author �豤ȣ
*/
static int writeVerifySpaceStatisticsTextFile(char* pfileName,float ACC,float bias,float POD,float FAR,float CSI,float ME,float MAE,float MSE,float RMSE,float corr,float AWSMean,float radarMean)
{
	FILE* pfp;

	if ((pfp = fopen(pfileName,"w"))== NULL)
	{
		return -9999;
	}
	
	fprintf(pfp,"ACC %f\n",ACC);
	fprintf(pfp,"BIAS %f\n",bias);
	fprintf(pfp,"POD %f\n",POD);
	fprintf(pfp,"FAR %f\n",FAR);
	fprintf(pfp,"CSI %f\n",CSI);
	fprintf(pfp,"ME %f\n",ME);
	fprintf(pfp,"MAE %f\n",MAE);
	fprintf(pfp,"MSE %f\n",MSE);
	fprintf(pfp,"RMSE %f\n",RMSE);
	fprintf(pfp,"CORR %f\n",corr);
	fprintf(pfp,"AWS_MEAN %f\n",AWSMean);
	fprintf(pfp,"RADAR_MEAN %f\n",radarMean);
	fprintf(pfp,"AVAILABLE_AWS %d %d\n",g_AWSCount,g_availableAWSNum);
	printf(" aaa %f %f\n",AWSMean,radarMean);
	fclose(pfp);

	return 1;
}

/**
* @brief ����� ����(�ð��������ڷ�)
* @param pfileName ���ϸ�
* @param pID AWS ID
* @param pACC
* @param pbias
* @param pPOD
* @param pFAR
* @param pCSI
* @param pME
* @param pMAE
* @param pMSE
* @param pRMSE
* @param pcorr
* @param pAWSMean
* @param pradarMean
* @return ������ 1: ���� ����: ����
* @author �豤ȣ
*/
static int writeVerifyTimeStatisticsTextFile(char* pfileName,int* pID,float* pACC,float* pbias,float* pPOD,float* pFAR,float *pCSI,float *pME,float *pMAE,float *pMSE,float *pRMSE,float *pcorr,float *pAWSMean,float *pradarMean)
{
	int i;
	FILE *pfp;

	if ((pfp = fopen(pfileName,"w"))== NULL)
	{
		return -9999;
	}

	for (i = 0 ; i < g_AWSCount ; i++ )
	{
		fprintf(pfp,"%d ",pID[i]);
		fprintf(pfp,"%f ",pACC[i]);
		fprintf(pfp,"%f ",pbias[i]);
		fprintf(pfp,"%f ",pPOD[i]);
		fprintf(pfp,"%f ",pFAR[i]);
		fprintf(pfp,"%f ",pCSI[i]);
		fprintf(pfp,"%f ",pME[i]);
		fprintf(pfp,"%f ",pMAE[i]);
		fprintf(pfp,"%f ",pMSE[i]);
		fprintf(pfp,"%f ",pRMSE[i]);
		fprintf(pfp,"%f ",pcorr[i]);
		fprintf(pfp,"%f ",pAWSMean[i]);
		fprintf(pfp,"%f ",pradarMean[i]);
		fprintf(pfp,"\n");
	}

	fclose(pfp);

	return 1;
}
