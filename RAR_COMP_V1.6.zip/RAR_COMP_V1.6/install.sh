#!/bin/bash
#################################################
#	change below two lines						#
#	(ROOTDIR, REAL_OPERATOR)					#
#################################################
ROOTDIR=/home/khkim/MYCODE_DIR/18_FINAL_RAR/racos.qc/

#################################################
#	Don't edit below lines						#
#################################################
SOURCE_PATH=`pwd`
BIN_PATH={$ROOTDIR}/BIN

echo "========================================================================"
echo "                       make directory                                   "
echo "========================================================================"
if [ ! -d $ROOTDIR ]; then
	echo "create $ROOTDIR"
	mkdir $ROOTDIR
	if [ $? -ne 0 ]; then
		echo "mkdir $ROOTDIR ERROR"
		exit 1
	fi
fi
#make data,temp,log directory
for DIRLIST in `cat mkdir.txt`; do
	if [ ! -d $ROOTDIR$DIRLIST ]; then
		mkdir $ROOTDIR$DIRLIST
		if [ $? -ne 0 ]; then
			echo "mkdir $ROOTDIR$DIRLIST ERROR"
			exit 1
		fi
	fi
done

echo "========================================================================"
echo "                       main program install                             "
echo "========================================================================"
echo "--------------------------"
echo "--- installing program"
echo "--------------------------"
cd SRC/
make clean
make ROOTDIR=$ROOTDIR

if [ $? != 0 ]; then
	echo 'main program install ERROR!!!'
	exit 2
fi

cd $SOURCE_PATH

echo "========================================================================"
echo "                       copy shell program                               "
echo "========================================================================"
chmod 777 SRC/shell/*.sh
chmod 777 SRC/ftp_proc/ncftpget
chmod 777 SRC/ftp_proc/ncftpput

cp SRC/shell/*.sh $ROOTDIR/BIN/
cp SRC/ftp_proc/ncftpget $ROOTDIR/BIN/
cp SRC/ftp_proc/ncftpput $ROOTDIR/BIN/
cp -R SRC/* $ROOTDIR/SRC/

echo "========================================================================"
echo "                       copy resource directory                          "
echo "========================================================================"
cp -R RES/* $ROOTDIR/RES/

exit 0
