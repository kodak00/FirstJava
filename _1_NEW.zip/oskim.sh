#!/bin/sh

#export QUERY_STRING="&tm=201903151315&stn=KWK&rdr=RAW&vol=RN&cpi=PPI&cdf=1&sms=0&swpn=0&ht=1.5&map=&color=&area=2&ang=&size=880&zoom_level=0&zoom_x=0000000&zoom_y=0000000&ZRa=200&ZRb=1.6&aws=1&gov=KMA&rand=211733"

#/home/radar/temp/rdr/www/cgi-bin/rdr/nph-rdr_stn1_img > oskim.png
#cgdb /home/radar/temp/rdr/www/cgi-bin/rdr/nph-rdr_stn1_img

export QUERY_STRING="cmp=OTH&sat=wvp&rdr=oth&lgt=1&fog=1&tm=201905290830&map=H3&size=1036&zoom_level=0&zoom_x=0000000&zoom_y=0000000&ZRa=200&ZRb=1.6&color=C&gis=&sms=1&legend=1&aws=1&wind=0&gov=KMA&x1=-10&y1=-10&x2=-10&y2=-10"

if [[ $1 == 1 ]]; then
/home/radar/temp/rdr/www/cgi-bin/rdr/nph-rdr_sat_lgt_img > oskim.png
else
cgdb /home/radar/temp/rdr/www/cgi-bin/rdr/nph-rdr_sat_lgt_img
fi

#StartTime=$(date +%s%N)
#/home/radar/temp/rdr/www/cgi-bin/rdr/nph-rdr_stn1_img > oskim.png
#
#EndTime=$(date +%s%N)
#ElapsedTime=`echo "($EndTime - $StartTime) / 1000000" | bc`
#ElapsedSec=`echo  "scale=6;$ElapsedTime / 1000" | bc | awk '{printf "%.6f", $1}'`
#echo "TOTAL : $ElapsedSec sec"
