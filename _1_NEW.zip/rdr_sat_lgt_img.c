/*******************************************************************************
**
**  ���� + ���̴� + ���� �ռ� ����
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2019.3.27)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include <gd.h>
#include <gdfontt.h>
#include <gdfonts.h>
#include <gdfontmb.h>
#include <gdfontl.h>
#include <gdfontg.h>

#include "cgiutil.h"
#include "nrutil.h"
#include "stn_inf.h"
#include "aws3_data.h"
#include "map_ini.h"
#include "url_io.h"
#include "rdr_cmp_header.h"

#define  DEGRAD   0.01745329251994329576923690768489    // PI/180
#define  RADDEG   57.295779513082320876798154814105     // 180/PI

#define  COMS_CONV_FILE "/rdr/REF/INI/coms_conv.csv"
#define  COMS_BIN_DIR   "/DATA/SAT/COMS/BIN"   // õ�������� ���������
#define  HIMA_CONV_FILE "/rdr/REF/INI/hima_conv.csv"
#define  HIMA_BIN_DIR   "/DATA/SAT/HIMA/BIN"
#define  RDR_CMP_DIR    "/DATA/RDR/CMP"        // ���̴��ռ����� ���������
#define  RDR_OBS_DIR    "/DATA/RDR/OBS"        // ���̴� ����м� ���⺸����
#define  LGT_DIR        "/DATA/LGT/KMA"        // ����
#define  RDR_CMP_DIR    "/DATA/RDR/CMP"        // ���̴��ռ����� ���������
#define  RDR_PCP_DIR    "/DATA/RDR/PCP"        // ���������� ���������
#define  MAP_INI_FILE   "/rdr/REF/MAP/map.ini" // �������� ��������
#define  MAP_DIR1       "/DATA/GIS/MAP/dat"    // ��������(ASCII) ���丮
#define  MAP_DIR        "/DATA/GIS/MAP/bln"    // ��������(����) ���丮
#define  MAP_DIR3       "/rdr/REF/BLN/dat"     // ��������(ASCII) ���丮
#define  MAP_DIR4       "/rdr/REF/BLN"         // ��������(����) ���丮
#define  TOPO_HC1_FILE  "/DATA/GIS/TOPO/KMA/topo_mapC_1km.bin"    // HC-map������ 1km �ػ� ��������(��)
#define  TOPO_HC_FILE   "/DATA/GIS/TOPO/KMA/topo_mapHC_1km.bin"   // HC-map������ 1km �ػ� ��������(�����ػ�10km)
#define  TOPO_H1_FILE   "/DATA/GIS/TOPO/KMA/topo_mapH1_1km.bin"   // H1-map������ 1km �ػ� ��������(�����ػ�10km)
#define  TOPO_H2_FILE   "/DATA/GIS/TOPO/KMA/topo_mapH2_1km.bin"   // H2-map������ 1km �ػ� ��������(�����ػ�10km)
#define  TOPO_H3_FILE   "/DATA/GIS/TOPO/KMA/topo_mapH3_1km.bin"   // H3-map������ 1km �ػ� ��������(�����ػ�10km)
#define  COLOR_SET_DIR  "/rdr/REF/COLOR"       // ����ǥ ���� �ӽ������

// COMS���� (COMS_GRID ����)
#define  COMS_NX   1769
#define  COMS_NY   1559
//#define  COMS_SX   850
#define  COMS_SX   851
//#define  COMS_SY   1061
#define  COMS_SY   1059
#define  COMS_GRID 5

// �����͸� ���ڿ��� (2km ����ũ��)
#define  HIMA_NX   4599
#define  HIMA_NY   3999
#define  HIMA_SX   2299.5
#define  HIMA_SY   2717.16
#define  HIMA_GRID 2.0

// HR-map����(HR, km)
#define  HR_NX  1024
#define  HR_NY  1024
#define  HR_SX  440
#define  HR_SY  770

// HB-map(���̴�240km�ռ�) ����(km)
#define  HB_NX  1152
#define  HB_NY  1440
#define  HB_SX  560
#define  HB_SY  840

// HC-map(���̴�480km�ռ�) ����(km)
#define  HC_NX  1600
#define  HC_NY  1600
#define  HC_SX  800
#define  HC_SY  1000

// H3-map(���̴� ������) ����(km)
#define  H3_NX  3520
#define  H3_NY  3520
#define  H3_SX  2000
#define  H3_SY  2400

// �ռ��� �ڷῡ ����� �⺻��
#define  BLANK1  -30000     // No Area
#define  BLANK2  -25000     // No Data
#define  BLANK3  -20000     // Minimum Data

// �̹��� ������ �Ϻ� �⺻��
#define  LEG_pixel   35     // ����ǥ�ÿ���
#define  TITLE_pixel 20     // ����ǥ�ÿ���

// ����� �ѱ�TTF
#define  FONTTTF  "/rdr/REF/FONT/NanumGothic.ttf"
#define  FONTTTF1 "/usr/share/fonts/korean/TrueType/gulim.ttf"

//------------------------------------------------------------------------------
// ����� �Է� ����
struct INPUT_VAR {
  int   seq_now;      // ����ð� SEQ(��)
  int   seq;          // ���ؽð� or ����ð� SEQ(��)
  int   acc;          // seq-seq1(��)
  int   seq_sat;      // �����ð� SEQ(��)
  int   itv;          // ���� ǥ�Ⱓ��(��)
  char  cmp[8];       // 
  char  sat[8];       // ct, ir1, wvp
  char  rdr[8];       // hsr, lng, oth
  int   lgt;          // 1(ǥ��), 0(����)
  int   fog;          // 1(ǥ��), 0(����)
  char  kma[8];       // �ѱ� ������ �ڷ�(lng, hsr))
  int   num_stn;      // �Ʒ� stn_cd�� ��ϵ� ������
  unsigned char  **stn_cd;  // ������ ó����
  char  obs[8];       // ECHO, EBH, STN
  char  map[8];       // ����� �����ڵ�
  char  color[8];     // ��û�� ����ǥ
  float grid;         // ����ũ��(km)
  int   zoom_level;   // Ȯ��Ƚ��
  int   zoom_rate;    // Ȯ�����
  char  zoom_x[16];   // X���� Ȯ��
  char  zoom_y[16];   // Y���� Ȯ��
  char  auto_man;     // �ڵ�����
  float ZRa;          // Z-R������� ���(�⺻:200)  Z=aR^b
  float ZRb;          // Z-R������� ����(�⺻:1.6)

  // ȭ��ǥ���
  int   size;         // �̹���ũ��(�ȼ�) : NI�� �ش�
  int   legend;       // ����ǥ��(1) ����
  int   aws;          // �������� ����(0:����ǥ�����, 1:������, 2:������ȣ, 3:������)
  int   sms;          // ��Ȱȭ Ƚ��
  char  gis[8];       // �������� ǥ�⿩��(T:����)
  char  sat_ok;       // �����ڷ� ���翩��(1:����, 0:����)
  char  topo_ok;      // �����ڷ� ��������(1:�Ϸ�, 0:����)
  char  disp;         // A(ASCII), B(Binary)

  // ����� �ڷ�
  int   NX, NY;       // ���ڼ�, ���� ���������� ������ 1�� ���ϸ� ��
  int   SX, SY;       // ���� ������ ��ġ
  int   NI, NJ;       // �ڷ�ǥ���̹��� ����(�ȼ�)
  int   GI, GJ;       // ��ü �̹��� ����(�ȼ�)
  int   num_color;    // �����
  int   num_color_topo;   // ���������

  // ��������
  char  fname[120];   // ���ϸ�
} var;

//------------------------------------------------------------------------------
// ����
struct RDR_CMP_HEAD  rdr_cmp_head;              // �ռ��ڷ� Header
struct RDR_CMP_STN_LIST  rdr_cmp_stn_list[48];  // �ռ��� ���̴� ���
float  **g;
short  **topo;
int    TOPO_NX, TOPO_NY, TOPO_SX, TOPO_SY;

float  data_sat[200];
int    num_color_sat, color_sat[200], color_sat1[200], color_sat2[200], color_sat3[200];
float  data_rdr[40];
int    num_color_rdr, color_rdr[40];
int    color_fog, color_lgt;

//------------------------------------------------------------------------------
// �Լ�
int grid_smooth(float **, int, int, float);
int grid_short_filter(short **, int, int, short);

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main()
{
  int   err = 0;

  // 1. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(30);

  printf("HTTP/1.0 200 OK\n");
  //printf("Content-type: text/plain\n\n");

  // 2. ����� �Է� ���� �м�
  if ( user_input() < 0 ) err = 1;

  // 4. ���� ó��
  if (err > 0) {
    err_img(err);
    return 0;
  }

  // 7. �̹��� ���� �� ����
  img_disp();

  alarm(0);
  return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
  char *qs;
  char tmp[256], item[32], value[32], tm[30];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, i, j, k;

  // 1. ���� �ʱⰪ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "0");        // ����ð�
  strcpy(var.map, "HR");  // ���̴� ����
  strcpy(var.sat, "ir1"); // ����
  strcpy(var.rdr, "lng"); // HSR�ڷ�
  var.lgt = 1;            // ���� ����
  var.fog = 1;            // �Ȱ� ����
  var.num_stn = 0;        // ���� ���� ó���� ���� ����
  var.zoom_level = 0;     // ��ü����
  var.zoom_rate = 2;      // 2�� Ȯ�밡 �⺻
  strcpy(var.zoom_x,"0000000");
  strcpy(var.zoom_y,"0000000");
  var.itv = 5;    // ����ǥ�� ���� +-itv��
  var.sms = 1;
  var.legend = 1;
  var.ZRa = 200;
  var.ZRb = 1.6;

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');
    if (strlen(value) == 0) continue;

    if      ( !strcmp(item,"cmp")) strcpy(var.cmp, value);
    else if ( !strcmp(item,"sat")) strcpy(var.sat, value);
    else if ( !strcmp(item,"rdr")) strcpy(var.rdr, value);
    else if ( !strcmp(item,"lgt")) var.lgt = atoi(value);
    else if ( !strcmp(item,"fog")) var.fog = atoi(value);
    else if ( !strcmp(item,"map")) strcpy(var.map, value);
    else if ( !strcmp(item,"size")) var.size = atoi(value);
    else if ( !strcmp(item,"color")) strcpy(var.color, value);
    else if ( !strcmp(item,"tm"))  strcpy(tm, value);
    else if ( !strcmp(item,"acc")) var.acc = atoi(value);
    else if ( !strcmp(item,"itv")) var.itv = atoi(value);
    else if ( !strcmp(item,"auto_man")) var.auto_man = value[0];
    else if ( !strcmp(item,"aws")) var.aws = atoi(value);
    else if ( !strcmp(item,"sms")) var.sms = atoi(value);
    else if ( !strcmp(item,"gis")) strcpy(var.gis, value);
    else if ( !strcmp(item,"zoom_level")) var.zoom_level = atoi(value);
    else if ( !strcmp(item,"zoom_rate"))  var.zoom_rate = atoi(value);
    else if ( !strcmp(item,"zoom_x")) strcpy(var.zoom_x, value);
    else if ( !strcmp(item,"zoom_y")) strcpy(var.zoom_y, value);
    else if ( !strcmp(item,"legend")) var.legend = atoi(value);
    else if ( !strcmp(item,"stn")) {
      for (var.num_stn = 0, j = 0; j < strlen(value); j++) {
        if (value[j] == ':') {
          var.num_stn++;
        }
      }
      if (value[strlen(value)-1] != ':') var.num_stn++;

      if (var.num_stn > 0) {
        var.stn_cd = cmatrix(0,var.num_stn,0,7);
        for (k = 0, j = 0; value[0] != '\0'; j++) {
          getword (tmp, value, ':');
          if (strlen(tmp) >= 3) {
            strcpy(var.stn_cd[k], tmp);
            k++;
          }
        }
      }
    }
  }

  // 3. �⺻�� ����
  var.grid = 1.0;

  // 4. ����ð� �� ���� �����ð� ����
  get_time(&iYY, &iMM, &iDD, &iHH, &iMI, &iSS);
  iseq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  var.seq_now = iseq;

  // 5. ��û�ð� ����
  if (strlen(tm) < 10 || var.auto_man == 'a')
    var.seq = iseq;
  else {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
    var.seq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  }
  if (!strcmp(var.cmp,"OTH"))
    var.seq = 10*(var.seq/10);
  else
    var.seq = 5*(var.seq/5);
  return 0;
}

/*******************************************************************************
 *
 *  �ռ��� �̹��� ���� �� ����
 *
 *******************************************************************************/
int img_disp()
{
  gdImagePtr im;
  FILE  *fp;
  float data_lvl[256];
  int   color_lvl[256];

  // 1. �̹��� ���� ����
  grid_map_inf(var.map, &(var.NX), &(var.NY), &(var.SX), &(var.SY));
  var.NI = var.size;
  var.NJ = (int)((float)(var.NY)/(float)(var.NX)*var.NI);
  var.GI = var.NI;
  if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + TITLE_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreateTrueColor(var.GI, var.GJ);
  color_table(im, color_lvl, data_lvl);
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[250]);

  // 4. �������� �׸���
  topo_disp(im);

  // 5. �����ڷ� �׸���
  var.sat_ok = 0;

  if (!strcmp(var.sat,"ct"))
    sat_ct_disp(im);
  else if (!strcmp(var.sat,"ir1") || !strcmp(var.sat,"wvp"))
    sat_bin_disp(im);

  if (var.fog != 0) sat_fog_disp(im);

  // 6. ���̴��ڷ� �׸���
  if (!strcmp(var.rdr,"oth"))
    rdr_oth_disp(im);
  else if (!strcmp(var.rdr,"lng") || !strcmp(var.rdr,"hsr"))
    rdr_disp(im);

  // 7. �����ڷ� �׸���
  if (var.lgt) lgt_disp(im);

  // 8. ���� �׸���
  //if (var.zoom_level >= 2) map_disp(im, 1);
  map_disp(im, 4);

  // 9. ���� �׸�
  title_disp(im, color_lvl);

  // 10. ���� �׸���
  legend_disp(im, color_lvl);
  gdImageRectangle(im, 0, TITLE_pixel, var.NI-1, var.GJ-1, color_lvl[242]);

  // 12. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);
  return 0;
}

/*=============================================================================*
 *  ����ǥ
 *=============================================================================*/
int color_table(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  FILE  *fp;
  float v1;
  char  color_file[120];
  int   R, G, B;

  // 5. ��Ÿ ����ǥ ����
  color_lvl[240] = gdImageColorAllocate(im, 180, 180, 180);   // ����1
  color_lvl[241] = gdImageColorAllocate(im, 255, 255, 255);   // ����2
  color_lvl[242] = gdImageColorAllocate(im, 30, 30, 30);      // ������
  color_lvl[243] = gdImageColorAllocate(im, 12, 28, 236);     // ����
  color_lvl[244] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  color_lvl[245] = gdImageColorAllocate(im, 240, 240, 240);
  color_lvl[246] = gdImageColorAllocate(im, 255, 0, 0);
  color_lvl[247] = gdImageColorAllocate(im, 0, 0, 255);
  color_lvl[248] = gdImageColorAllocate(im, 160, 160, 160);   // ����3
  color_lvl[249] = gdImageColorAllocate(im, 110, 110, 110);   // �ñ����
  color_lvl[250] = gdImageColorAllocate(im, 80, 80, 80);      // ��������
  color_lvl[251] = gdImageColorAllocate(im, 255, 0, 172);     // �ܸ鼱

  return 0;
}

/*******************************************************************************
 *  �������� ǥ��
 *******************************************************************************/
int topo_disp(gdImagePtr im)
{
  FILE  *fp;
  char  fname[120];
  float dg = (float)var.NX/(float)(var.NI);
  float zm = 1.0, xo = 0.0, yo = 0.0, zx, zy, x1, y1, ht;
  float data_topo[40];
  int   num_color_topo;
  int   color_topo[40];
  int   ix, iy, color1;
  int   i, j, k;

  // 1. ���������ڷ� �б�
  var.topo_ok = 0;
  if (strcmp(var.map,"H2") == 0)
    strcpy(fname, TOPO_H2_FILE);
  else if (strcmp(var.map,"H3") == 0)
    strcpy(fname, TOPO_H3_FILE);
  else if (strcmp(var.map,"H1") == 0)
    strcpy(fname, TOPO_H1_FILE);
  else if (strcmp(var.map,"HC") == 0)
    strcpy(fname, TOPO_HC_FILE);
  else
    strcpy(fname, TOPO_HC1_FILE);

  if ((fp = fopen(fname, "rb")) == NULL) return -1;
  if (!strcmp(var.map,"H3") || !strcmp(var.map,"H2") ||
      !strcmp(var.map,"H1") || !strcmp(var.map,"HC")) {
    TOPO_NX = var.NX;  TOPO_NY = var.NY;
    TOPO_SX = var.SX;  TOPO_SY = var.SY;
    var.topo_ok = 2;
  }
  else {
    TOPO_NX = HC_NX;  TOPO_NY = HC_NY;
    TOPO_SX = HC_SX;  TOPO_SY = HC_SY;
    var.topo_ok = 1;
  }

  topo = smatrix(0, TOPO_NY, 0, TOPO_NX);
  fseek(fp, (long)64, SEEK_SET);    // �ش�(64byts) skip
  for (j = 0; j <= TOPO_NY; j++) {
    fread(topo[j], 2, TOPO_NX+1, fp);
    if (var.topo_ok == 1) {   // TOPO_HC1 �� 0.1m ������ 1m ������ ��ȯ
      for (i = 0; i <= TOPO_NX; i++) {
        topo[j][i] = (short)(0.1*topo[j][i] + 0.49);
      }
    }
  }
  fclose(fp);
  //if (strcmp(var.sat,"ct") != 0) return 0;

  // 2. ����
  //color_topo[0] = gdImageColorAllocate(im, 85, 142, 213);   data_topo[0] = 0.5;
  //color_topo[1] = gdImageColorAllocate(im, 230, 137,  0);   data_topo[1] = 5000;
  //num_color_topo = 2;

  // �������� ����ǥ (����)
  //color_lvl[150] = gdImageColorAllocate(im,  85,  142, 213);   data_lvl[150] = 1.0;
  //color_lvl[150] = gdImageColorAllocate(im,  31,  73, 125);   data_lvl[150] = 1.0;
  color_topo[0] = gdImageColorAllocate(im,   0,  39, 116);   data_topo[0] = 0.0;
  //color_lvl[150] = gdImageColorAllocate(im,  79, 129, 189);   data_lvl[150] = 1.0;
  //color_lvl[150] = gdImageColorAllocate(im,  95,  95,  95);   data_lvl[150] = 1.0;
  color_topo[1] = gdImageColorAllocate(im, 244, 183,   0);   data_topo[1] = 100;
  color_topo[2] = gdImageColorAllocate(im, 191, 138,   0);   data_topo[2] = 500;
  color_topo[3] = gdImageColorAllocate(im, 138, 100,   0);   data_topo[3] = 5000;
  //color_lvl[151] = gdImageColorAllocate(im, 230, 137,   0);   data_lvl[151] = 5000;
  num_color_topo = 4;
  //num_color_topo = 2;

  /* �������� ����ǥ (��鰣��)
  color_lvl[150] = gdImageColorAllocate(im, 206, 229, 241);   data_lvl[150] = 1.0;
  color_lvl[151] = gdImageColorAllocate(im, 240, 240, 225);   data_lvl[151] = 100;
  color_lvl[152] = gdImageColorAllocate(im, 170, 170, 170);   data_lvl[152] = 500;
  color_lvl[153] = gdImageColorAllocate(im, 120, 120, 120);   data_lvl[153] = 5000;

  /* ����������� (full����)
  color_lvl[150] = gdImageColorAllocate(im, 206, 229, 241);   data_lvl[150] = 1.0;   // �ٴٻ�
  color_lvl[151] = gdImageColorAllocate(im, 240, 240, 225);   data_lvl[151] = 50;    // - 50m
  color_lvl[152] = gdImageColorAllocate(im, 220, 220, 220);   data_lvl[152] = 100;   // -100m
  color_lvl[153] = gdImageColorAllocate(im, 210, 210, 210);   data_lvl[153] = 150;   // -150m
  color_lvl[154] = gdImageColorAllocate(im, 200, 200, 200);   data_lvl[154] = 200;   // -200m
  color_lvl[155] = gdImageColorAllocate(im, 190, 190, 190);   data_lvl[155] = 300;   // -300m
  color_lvl[156] = gdImageColorAllocate(im, 180, 180, 180);   data_lvl[156] = 400;   // -400m
  color_lvl[157] = gdImageColorAllocate(im, 170, 170, 170);   data_lvl[157] = 500;   // -500m
  color_lvl[158] = gdImageColorAllocate(im, 160, 160, 160);   data_lvl[158] = 600;   // -600m
  color_lvl[159] = gdImageColorAllocate(im, 150, 150, 150);   data_lvl[159] = 700;   // -700m
  color_lvl[160] = gdImageColorAllocate(im, 140, 140, 140);   data_lvl[160] = 800;   // -800m
  color_lvl[161] = gdImageColorAllocate(im, 130, 130, 130);   data_lvl[161] = 900;   // -900m
  color_lvl[162] = gdImageColorAllocate(im, 120, 120, 120);   data_lvl[162] = 1000;  // -1000m
  color_lvl[163] = gdImageColorAllocate(im, 110, 110, 110);   data_lvl[163] = 1500;  // -1500m
  color_lvl[164] = gdImageColorAllocate(im, 100, 100, 100);   data_lvl[164] = 5000;  // -2000m
  color_lvl[165] = gdImageColorAllocate(im, 109, 218, 109);
  var.num_color_topo = 15;
  */
  //color_lvl[171] = gdImageColorAllocate(im,  98, 169, 213);   // ��

  // 4. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_x[0] != '0') {
    for (i = 0; i < 7; i++, zm *= 2) {
      zx = var.zoom_x[i]-'0';
      zy = var.zoom_y[i]-'0';
      if (zx == 0 || zy == 0) break;

      xo += ((var.NX - 1)/8.0*(zx-1)/zm);
      yo += ((var.NY - 1)/8.0*(zy-1)/zm);
    }
  }
  xo += (TOPO_SX - var.SX);
  yo += (TOPO_SY - var.SY);
  dg /= zm;

  // 5. �̹��� �ȼ����� ���
  for (j = 1; j < var.NJ; j++) {
    y1 = dg*j + yo;
    iy = (int)(y1);
    if (iy < 0 || iy >= TOPO_NY) continue;

    for (i = 1; i < var.NI; i++) {
      x1 = dg*i + xo;
      ix = (int)(x1);
      if (ix < 0 || ix >= TOPO_NX) continue;

      ht = (float)topo[iy][ix];
      for (k = 0; k < num_color_topo; k++) {
        if (ht < data_topo[k]) {
          gdImageSetPixel(im, i, var.GJ-j, color_topo[k]);
          break;
        }
      }
    }
  }

  // ���������ڷ� ����
  //free_smatrix(topo, 0, HC_NY, 0, HC_NX);
  return 0;
}

/*******************************************************************************
 *  õ���� or �����͸� ���� ǥ�� (IR1,WVP)
 *******************************************************************************/
int sat_bin_disp(gdImagePtr im)
{
  struct stat st;
  char   fname[120], head[32];
  int    seq;
  int    YY, MM, DD, HH, MI;
  int    code;

  // ��û�ð����� ���ŷ� ���� ���� ����� �ڷḦ ���
  // �����͸�-õ����1ȣ ������ ã��
  var.seq_sat = -1;
  for (seq = var.seq; seq >= var.seq-60; seq--) {
    // UTC�ð�
    seq2time(seq-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

    // �����͸�
    if (!strcmp(var.sat,"ir1"))
      strcpy(head, "himawari8_ahi_le1b_ch13_nwpn");
    else
      strcpy(head, "himawari8_ahi_le1b_ch08_nwpn");

    sprintf(fname, "%s/%04d%02d/%02d/%s_%04d%02d%02d%02d%02d.bin.gz",
            HIMA_BIN_DIR, YY, MM, DD, head, YY, MM, DD, HH, MI);
    code = stat(fname, &st);
    if (code == 0 && st.st_size > 100) {
      var.seq_sat = seq;
      var.sat_ok = 2;
      break;
    }

    // õ����1ȣ
    if (!strcmp(var.sat,"ir1"))
      strcpy(head, "coms_le1b_ir1_ch1_nwpn");
    else
      strcpy(head, "coms_le1b_wv_ch3_nwpn");

    sprintf(fname, "%s/%04d%02d/%02d/%s_%04d%02d%02d%02d%02d.bin.gz",
            COMS_BIN_DIR, YY, MM, DD, head, YY, MM, DD, HH, MI);
    code = stat(fname, &st);
    if (code == 0 && st.st_size > 100) {
      var.seq_sat = seq;
      var.sat_ok = 1;
      break;
    }
  }

  // 2. �ش� ������ ǥ��
  if (var.sat_ok == 1) {
    if (coms_bin_disp(im, fname) < 0) var.sat_ok = 0;
  }
  else if (var.sat_ok == 2) {
    if (hima_bin_disp(im, fname) < 0) var.sat_ok = 0;
  }
  return 0;
}

/*******************************************************************************
 *  õ���� ���� ǥ�� (IR1,WVP)
 *******************************************************************************/
int coms_bin_disp(gdImagePtr im, char *fname)
{
  FILE  *fp;
  gzFile fg;
  struct stat st;
  char   head[32];
  char   buf[1024], tmp[1024];
  short  *com1;
  unsigned char *p1, b1;
  float  cnv[1024], g1;
  float  dg = (float)var.NX/(float)(var.NI);
  float  zm = 1.0, xo = 0.0, yo = 0.0, zx, zy, x1, y1, v1;
  float  xd, yd, xt, yt, avg, std;
  float  ta, ta_min, ta_max, t1;
  int    YY, MM, DD, HH, MI;
  int    H1, H2, S, L, R, G, B;
  int    ok = 0, seq, code, chn, c1;
  int    i, j, k, n, i1, j1, ix1, iy1, ix2, iy2;

  // 1. ��ȯǥ ���� �б�
  if (!strcmp(var.sat,"ir1"))
    chn = 1;  // IR1
  else
    chn = 5;  // WVP

  if ((fp = fopen(COMS_CONV_FILE,"r")) == NULL) return -1;
  while (fgets(buf, 1024, fp) != NULL) {
    if (buf[0] == '#') continue;
    getword(tmp, buf, ',');  n = atoi(tmp);
    for (i = 0; i < 10; i++) {
      getword(tmp, buf, ',');
      if (chn == i) {
        cnv[n] = atof(tmp) - 273.15;
        break;
      }
    }
  }
  fclose(fp);

  // 2. ���� Ȯ��
  /*
  if (!strcmp(var.sat,"ir1"))
    strcpy(head, "coms_le1b_ir1_ch1_nwpn");
  else
    strcpy(head, "coms_le1b_wv_ch3_nwpn");

  var.seq_sat = -1;
  for (seq = var.seq; seq >= var.seq-60; seq--) {
    seq2time(seq-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    sprintf(fname, "%s/%04d%02d/%02d/%s_%04d%02d%02d%02d%02d.bin.gz",
            COMS_BIN_DIR, YY, MM, DD, head, YY, MM, DD, HH, MI);
    code = stat(fname, &st);
    if (code == 0 && st.st_size > 100) {
      ok = 1;
      break;
    }
  }
  if (ok == 0) return -1;
  var.seq_sat = seq;
  */

  // 3. �ڷ� �б�
  if ((fg = gzopen(fname,"rb")) == NULL) return -1;
  gzbuffer(fg, 64*1024);
  g = matrix(0, COMS_NY, 0, COMS_NX);
  com1 = svector(0, COMS_NX);
  for (j = 0; j <= COMS_NY; j++) {
    j1 = COMS_NY - j;
    gzread(fg, com1, (COMS_NX+1)*2);
    for (p1 = &com1[0], i = 0; i < COMS_NX+1; i++, p1 += 2) {
      b1 = *p1;
      *p1 = *(p1+1);
      *(p1+1) = b1;

      if (com1[i] < 0 || com1[i] >= 1024)
        g[j1][i] = -999;
      else
        g[j1][i] = cnv[com1[i]];
    }
  }
  gzclose(fg);
  free_svector(com1, 0, COMS_NX);

  // 4. ����ǥ ���� �б�
  /*
  if (!strcmp(var.sat,"ir1"))
    sprintf(fname, "%s/color_rdr_ir1.rgb", COLOR_SET_DIR);
  else
    sprintf(fname, "%s/color_rdr_wvp.rgb", COLOR_SET_DIR);

  if ((fp = fopen(fname,"r")) == NULL) return -1;
  num_color_sat = 0;
  while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
    color_sat[num_color_sat] = gdImageColorAllocate(im, R, G, B);
    data_sat[num_color_sat] = v1;
    num_color_sat++;
    if (num_color_sat >= 120) break;
  }
  fclose(fp);
  */

  // 5. �ִ�,�ּҰ� ������� ���� ����
  yd = COMS_SY*COMS_GRID - var.SY;
  xd = COMS_SX*COMS_GRID - var.SX;

  ta_min = 999;
  ta_max = -999;
  for (n = 0, j = 1; j < var.NY; j++) {
    iy1 = (int)((j + yd)/COMS_GRID + 0.49);
    if (iy1 < 0 || iy1 >= COMS_NY) continue;

    for (i = 1; i < var.NX; i++) {
      ix1 = (int)((i + xd)/COMS_GRID + 0.49);
      if (ix1 < 0 || ix1 >= COMS_NX) continue;

      g1 = g[iy1][ix1];
      if (g1 > -990) {
        if (g1 < ta_min) ta_min = g1;
        if (g1 > ta_max) ta_max = g1;
        n++;
      }
    }
  }

  if (n < 10) {
    if (!strcmp(var.sat,"ir1")) {
      ta_min = -60;  ta_max = 40;
    }
    else {
      ta_min = -60;  ta_max = 0;
    }
  }

  // 6. ����ǥ ���� (��� or Į��)
  if (!strcmp(var.color,"B")) {
    for (num_color_sat = 0, ta = ta_min; ta <= ta_max; ta += 1, num_color_sat++) {
      data_sat[num_color_sat] = ta;

      L = (int)(240*(ta_max - ta)/(ta_max - ta_min) + 16);
      if (L < 0) L = 0;
      if (L > 255) L = 255;

      color_sat1[num_color_sat] = gdImageColorAllocate(im, L, L, L);
      color_sat2[num_color_sat] = gdImageColorAllocate(im, L, L, L);
    }
  }
  else {
    H1 = 42;  H2 = 160;
    for (num_color_sat = 0, ta = ta_min; ta <= ta_max; ta += 1, num_color_sat++) {
      data_sat[num_color_sat] = ta;

      S = (int)(255*(ta - ta_min)/(ta_max - ta_min));
      L = (int)(240*(ta_max - ta)/(ta_max - ta_min) + 16);
      if (L < 0) L = 0;
      if (L > 255) L = 255;

      HSL2RGB(H1,S,L,&R,&G,&B);
      color_sat1[num_color_sat] = gdImageColorAllocate(im, R, G, B);

      HSL2RGB(H2,S,L,&R,&G,&B);
      color_sat2[num_color_sat] = gdImageColorAllocate(im, R, G, B);
    }
  }

  // 7. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_x[0] != '0') {
    for (i = 0; i < 7; i++, zm *= 2) {
      zx = var.zoom_x[i]-'0';
      zy = var.zoom_y[i]-'0';
      if (zx == 0 || zy == 0) break;

      xo += ((var.NX - 1)/8.0*(zx-1)/zm);
      yo += ((var.NY - 1)/8.0*(zy-1)/zm);
    }
  }
  xt = xo + (TOPO_SX - var.SX);
  yt = yo + (TOPO_SY - var.SY);
  xo += (COMS_SX*COMS_GRID - var.SX);
  yo += (COMS_SY*COMS_GRID - var.SY);
  dg /= zm;

  // 8. �̹��� �ȼ����� ���
  for (j = 1; j < var.NJ; j++) {
    y1 = dg*j + yo;
    iy1 = (int)(y1/COMS_GRID + 0.49);
    if (iy1 < 0 || iy1 >= COMS_NY) continue;
    iy2 = (int)(dg*j + yt + 1.45);    // �������� ��ġ

    for (i = 1; i < var.NI; i++) {
      x1 = dg*i + xo;
      ix1 = (int)(x1/COMS_GRID + 0.49);
      if (ix1 < 0 || ix1 >= COMS_NX) continue;
      ix2 = (int)(dg*i + xt + 1.0);

      // �ش� ��ġ�� �������� 
      if (iy2 < 0 || iy2 >= TOPO_NY || ix2 < 0 || ix2 >= TOPO_NX)
        t1 = -1;
      else {
        if (var.topo_ok > 0)
          t1 = (float)topo[iy2][ix2];
        else
          t1 = -1;
      }

      // �������� ���������� ���� ����ǥ ����
      g1 = g[iy1][ix1];
      if (g1 > -990) {
        for (k = 0; k < num_color_sat; k++) {
          if (g1 < data_sat[k]) {
            if (t1 >= 0)
              gdImageSetPixel(im, i, var.GJ-j, color_sat1[k]);
            else
              gdImageSetPixel(im, i, var.GJ-j, color_sat2[k]);
            break;
          }
        }
        if (k >= num_color_sat) {
          if (t1 >= 0)
            gdImageSetPixel(im, i, var.GJ-j, color_sat1[num_color_sat-1]);
          else
            gdImageSetPixel(im, i, var.GJ-j, color_sat2[num_color_sat-1]);
        }
      }
    }
  }
  return 0;
}

/*******************************************************************************
 *  �����͸� ���� ǥ�� (IR1,WVP)
 *******************************************************************************/
int hima_bin_disp(gdImagePtr im, char *fname)
{
  FILE  *fp;
  gzFile fg;
  struct stat st;
  char   head[32];
  char   buf[1024], tmp[1024];
  short  *com1;
  unsigned char *p1, b1;
  float  cnv[18000], g1;
  float  dg = (float)var.NX/(float)(var.NI);
  float  zm = 1.0, xo = 0.0, yo = 0.0, zx, zy, x1, y1, v1;
  float  xd, yd, xt, yt, avg, std;
  float  ta, ta_min, ta_max, t1;
  int    YY, MM, DD, HH, MI;
  int    H1, H2, S, L, R, G, B;
  int    ok = 0, seq, code, chn, chn2, c1;
  int    i, j, k, n, i1, j1, ix1, iy1, ix2, iy2;

  // 1. ��ȯǥ ���� �б�
  if (!strcmp(var.sat,"ir1"))
    chn = 13;  // IR1
  else
    chn = 8;  // WVP
  chn2 = chn*2 - 1;

  if ((fp = fopen(HIMA_CONV_FILE,"r")) == NULL) return -1;
  while (fgets(buf, 1024, fp) != NULL) {
    if (buf[0] == '#') continue;
    getword(tmp, buf, ',');  n = atoi(tmp);
    for (i = 0; i < 32; i++) {
      getword(tmp, buf, ',');
      if (chn2 == i) {
        cnv[n] = atof(tmp) - 273.15;
        break;
      }
    }
  }
  fclose(fp);

  // 2. ���� Ȯ��
  /*
  if (!strcmp(var.sat,"ir1"))
    strcpy(head, "himawari8_ahi_le1b_ch13_nwpn");
  else
    strcpy(head, "himawari8_ahi_le1b_ch08_nwpn");

  var.seq_sat = -1;
  for (seq = var.seq; seq >= var.seq-60; seq--) {
    seq2time(seq-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    sprintf(fname, "%s/%04d%02d/%02d/%s_%04d%02d%02d%02d%02d.bin.gz",
            HIMA_BIN_DIR, YY, MM, DD, head, YY, MM, DD, HH, MI);
    code = stat(fname, &st);
    if (code == 0 && st.st_size > 100) {
      ok = 1;
      break;
    }
  }
  if (ok == 0) return -1;
  var.seq_sat = seq;
  */

  // 3. �ڷ� �б�
  if ((fg = gzopen(fname,"rb")) == NULL) return -1;
  gzbuffer(fg, 64*1024);
  g = matrix(0, HIMA_NY, 0, HIMA_NX);
  com1 = svector(0, HIMA_NX);
  for (j = 0; j <= HIMA_NY; j++) {
    j1 = HIMA_NY - j;
    gzread(fg, com1, (HIMA_NX+1)*2);
    for (p1 = &com1[0], i = 0; i < HIMA_NX+1; i++, p1 += 2) {
      if (com1[i] < 0 || com1[i] >= 18000)
        g[j1][i] = -999;
      else
        g[j1][i] = cnv[com1[i]];
    }
  }
  gzclose(fg);
  free_svector(com1, 0, HIMA_NX);

  // 4. ����ǥ ���� �б�
  /*
  if (!strcmp(var.sat,"ir1"))
    sprintf(fname, "%s/color_rdr_ir1.rgb", COLOR_SET_DIR);
  else
    sprintf(fname, "%s/color_rdr_wvp.rgb", COLOR_SET_DIR);

  if ((fp = fopen(fname,"r")) == NULL) return -1;
  num_color_sat = 0;
  while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
    color_sat[num_color_sat] = gdImageColorAllocate(im, R, G, B);
    data_sat[num_color_sat] = v1;
    num_color_sat++;
    if (num_color_sat >= 120) break;
  }
  fclose(fp);
  */

  // 5. �ִ�,�ּҰ� ������� ���� ����
  yd = HIMA_SY*HIMA_GRID - var.SY;
  xd = HIMA_SX*HIMA_GRID - var.SX;

  ta_min = 999;
  ta_max = -999;
  for (n = 0, j = 1; j < var.NY; j++) {
    iy1 = (int)((j + yd)/HIMA_GRID + 0.49);
    if (iy1 < 0 || iy1 >= HIMA_NY) continue;

    for (i = 1; i < var.NX; i++) {
      ix1 = (int)((i + xd)/HIMA_GRID + 0.49);
      if (ix1 < 0 || ix1 >= HIMA_NX) continue;

      g1 = g[iy1][ix1];
      if (g1 > -990) {
        if (g1 < ta_min) ta_min = g1;
        if (g1 > ta_max) ta_max = g1;
        n++;
      }
    }
  }

  if (n < 10) {
    if (!strcmp(var.sat,"ir1")) {
      ta_min = -60;  ta_max = 40;
    }
    else {
      ta_min = -60;  ta_max = 0;
    }
  }

  // 6. ����ǥ ���� (��� or Į��)
  if (!strcmp(var.color,"B")) {
    for (num_color_sat = 0, ta = ta_min; ta <= ta_max; ta += 1, num_color_sat++) {
      data_sat[num_color_sat] = ta;

      L = (int)(240*(ta_max - ta)/(ta_max - ta_min) + 16);
      if (L < 0) L = 0;
      if (L > 255) L = 255;

      color_sat1[num_color_sat] = gdImageColorAllocate(im, L, L, L);
      color_sat2[num_color_sat] = gdImageColorAllocate(im, L, L, L);
    }
  }
  else {
    H1 = 42;  H2 = 160;
    for (num_color_sat = 0, ta = ta_min; ta <= ta_max; ta += 1, num_color_sat++) {
      data_sat[num_color_sat] = ta;

      S = (int)(255*(ta - ta_min)/(ta_max - ta_min));
      L = (int)(240*(ta_max - ta)/(ta_max - ta_min) + 16);
      if (L < 0) L = 0;
      if (L > 255) L = 255;

      HSL2RGB(H1,S,L,&R,&G,&B);
      color_sat1[num_color_sat] = gdImageColorAllocate(im, R, G, B);

      HSL2RGB(H2,S,L,&R,&G,&B);
      color_sat2[num_color_sat] = gdImageColorAllocate(im, R, G, B);
    }
  }

  // 7. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_x[0] != '0') {
    for (i = 0; i < 7; i++, zm *= 2) {
      zx = var.zoom_x[i]-'0';
      zy = var.zoom_y[i]-'0';
      if (zx == 0 || zy == 0) break;

      xo += ((var.NX - 1)/8.0*(zx-1)/zm);
      yo += ((var.NY - 1)/8.0*(zy-1)/zm);
    }
  }
  xt = xo + (TOPO_SX - var.SX);
  yt = yo + (TOPO_SY - var.SY);
  xo += (HIMA_SX*HIMA_GRID - var.SX);
  yo += (HIMA_SY*HIMA_GRID - var.SY);
  dg /= zm;

  // 8. �̹��� �ȼ����� ���
  for (j = 1; j < var.NJ; j++) {
    y1 = dg*j + yo;
    iy1 = (int)(y1/HIMA_GRID + 0.49);
    if (iy1 < 0 || iy1 >= HIMA_NY) continue;
    iy2 = (int)(dg*j + yt + 1.45);    // �������� ��ġ

    for (i = 1; i < var.NI; i++) {
      x1 = dg*i + xo;
      ix1 = (int)(x1/HIMA_GRID + 0.49);
      if (ix1 < 0 || ix1 >= HIMA_NX) continue;
      ix2 = (int)(dg*i + xt + 1.0);

      // �ش� ��ġ�� �������� 
      if (iy2 < 0 || iy2 >= TOPO_NY || ix2 < 0 || ix2 >= TOPO_NX)
        t1 = -1;
      else {
        if (var.topo_ok > 0)
          t1 = (float)topo[iy2][ix2];
        else
          t1 = -1;
      }

      // �������� ���������� ���� ����ǥ ����
      g1 = g[iy1][ix1];
      if (g1 > -990) {
        for (k = 0; k < num_color_sat; k++) {
          if (g1 < data_sat[k]) {
            if (t1 >= 0)
              gdImageSetPixel(im, i, var.GJ-j, color_sat1[k]);
            else
              gdImageSetPixel(im, i, var.GJ-j, color_sat2[k]);
            break;
          }
        }
        if (k >= num_color_sat) {
          if (t1 >= 0)
            gdImageSetPixel(im, i, var.GJ-j, color_sat1[num_color_sat-1]);
          else
            gdImageSetPixel(im, i, var.GJ-j, color_sat2[num_color_sat-1]);
        }
      }
    }
  }
  return 0;
}

/*******************************************************************************
 *  õ���� ���� ǥ�� (����)
 *******************************************************************************/
int sat_ct_disp(gdImagePtr im)
{
  gzFile fp;
  struct stat st;
  char   fname[120];
  unsigned char *com1;
  float  dg = (float)var.NX/(float)(var.NI);
  float  zm = 1.0, xo = 0.0, yo = 0.0, zx, zy, x1, y1;
  int    YY, MM, DD, HH, MI;
  int    ok = 0, seq, code, c1;
  int    i, j, k, j1, ix, iy;

  // 1. ���� Ȯ��
  var.seq_sat = -1;
  for (seq = var.seq; seq >= var.seq-60; seq--) {
    seq2time(seq-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    sprintf(fname, "%s/%04d%02d/%02d/coms_mi_le2_ct_nwpn_%04d%02d%02d%02d%02d.bin.gz",
            COMS_BIN_DIR, YY, MM, DD, YY, MM, DD, HH, MI);
    code = stat(fname, &st);
    if (code == 0 && st.st_size > 100) {
      ok = 1;
      break;
    }
  }
  if (ok == 0) return -1;
  var.seq_sat = seq;

  // 2. �ڷ� �б�
  if ((fp = gzopen(fname,"rb")) == NULL) return -1;
  gzbuffer(fp, 64*1024);
  //com1 = cmatrix(0, COMS_NY, 0, COMS_NX);
  g = matrix(0, COMS_NY, 0, COMS_NX);
  com1 = cvector(0, COMS_NX);
  for (j = 0; j <= COMS_NY; j++) {
    j1 = COMS_NY - j;
    //gzread(fp, com1[j1], COMS_NX+1);
    gzread(fp, com1, COMS_NX+1);

    // �׷��ȣ�� ��ȯ
    for (i = 0; i <= COMS_NX; i++) {
      //switch (com1[j][i]) {
      switch (com1[i]) {
        case 0:  c1 = 0;  break;  // �������ų� ��
        case 1:  c1 = 0;  break;  // ���ڳ� �Ϻ� ����
        case 2:  c1 = 1;  break;  // �ſ� ���� ����
        case 3:  c1 = 2;  break;  // ������
        case 4:  c1 = 3;  break;  // ������
        case 5:  c1 = 4;  break;  // ������
        case 6:  c1 = 4;  break;  // �ſ� ���� ����
        case 7:  c1 = 2;  break;  // ���������� (�β���)
        case 8:  c1 = 2;  break;  // ����������
        case 9:  c1 = 2;  break;  // ���������� (����)
        case 10: c1 = 2;  break;  // ���������� (���� or ��)
        default: c1 = 0;
      }
      g[j1][i] = c1;
    }
  }
  gzclose(fp);

  grid_smooth(g, COMS_NX+1, COMS_NY+1, -0.5);   // ��Ȱȭ
  grid_smooth(g, COMS_NX+1, COMS_NY+1, -0.5);

  // 3. ���� ����ǥ
  color_sat[0] = gdImageColorAllocate(im,  51,  51,  51);   data_sat[0] = 0;
  color_sat[1] = gdImageColorAllocate(im, 128, 128, 128);   data_sat[1] = 1;
  color_sat[2] = gdImageColorAllocate(im, 150, 150, 150);   data_sat[2] = 2;
  color_sat[3] = gdImageColorAllocate(im, 192, 192, 192);   data_sat[3] = 3;
  color_sat[4] = gdImageColorAllocate(im, 234, 234, 234);   data_sat[4] = 4;
  color_sat[5] = gdImageColorAllocate(im, 248, 248, 248);   data_sat[5] = 5;
  num_color_sat = 5;

  // 4. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    for (i = 0; i < 7; i++) {
      zx = var.zoom_x[i]-'0';
      zy = var.zoom_y[i]-'0';
      if (zx == 0 || zy == 0) break;

      xo += ((var.NX - 1)/8.0*(zx-1)/zm);
      yo += ((var.NY - 1)/8.0*(zy-1)/zm);
      zm *= var.zoom_rate;
    }
  }

  // 5. �̹��� �ȼ����� ���
  for (j = 1; j < var.NJ; j++) {
    y1 = dg*j/zm + yo + (COMS_SY*COMS_GRID - var.SY);
    iy = (int)(y1/COMS_GRID + 0.49);
    if (iy < 0 || iy >= COMS_NY) continue;

    for (i = 1; i < var.NI; i++) {
      x1 = dg*i/zm + xo + (COMS_SX*COMS_GRID - var.SX);
      ix = (int)(x1/COMS_GRID + 0.49);
      if (ix < 0 || ix >= COMS_NX) continue;
      /* �ڷ� ó���ܰ�� �ű�
      switch (com1[iy][ix]) {
        case 0:  c1 = 0;  break;  // �������ų� ��
        case 1:  c1 = 0;  break;  // ���ڳ� �Ϻ� ����
        case 2:  c1 = 1;  break;  // �ſ� ���� ����
        case 3:  c1 = 2;  break;  // ������
        case 4:  c1 = 3;  break;  // ������
        case 5:  c1 = 4;  break;  // ������
        case 6:  c1 = 4;  break;  // �ſ� ���� ����
        case 7:  c1 = 2;  break;  // ���������� (�β���)
        case 8:  c1 = 2;  break;  // ����������
        case 9:  c1 = 2;  break;  // ���������� (����)
        case 10: c1 = 2;  break;  // ���������� (���� or ��)
        default: c1 = 0;
      }
      */

      //c1 = com1[iy][ix];
      c1 = (int)(g[iy][ix] + 0.49);
      if (c1 > 0 && c1 < 5) gdImageSetPixel(im, i, var.GJ-j, color_sat[c1]);
    }
  }
  var.sat_ok = 1;

  //free_cmatrix(com1, 0, COMS_NY, 0, COMS_NX);
  free_cvector(com1, 0, COMS_NX);
  return 0;
}

/*******************************************************************************
 *  õ���� ���� ǥ�� (�Ȱ�)
 *******************************************************************************/
int sat_fog_disp(gdImagePtr im)
{
  gzFile fp;
  struct stat st;
  char   fname[120];
  unsigned char **com1;
  float  dg = (float)var.NX/(float)(var.NI);
  float  zm = 1.0, xo = 0.0, yo = 0.0, zx, zy, x1, y1;
  int    YY, MM, DD, HH, MI;
  int    ok = 0, seq, code, c1;
  int    i, j, k, j1, ix, iy;

  // 1. ���� Ȯ��
  for (seq = var.seq; seq >= var.seq-60; seq--) {
    seq2time(seq-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    sprintf(fname, "%s/%04d%02d/%02d/coms_mi_le2_fog_nwpn_%04d%02d%02d%02d%02d.bin.gz",
            COMS_BIN_DIR, YY, MM, DD, YY, MM, DD, HH, MI);
    code = stat(fname, &st);
    if (code == 0 && st.st_size > 100) {
      ok = 1;
      break;
    }
  }
  if (ok == 0) return -1;

  // 2. �ڷ� �б�
  if ((fp = gzopen(fname,"rb")) == NULL) return -1;
  gzbuffer(fp, 64*1024);
  com1 = cmatrix(0, COMS_NY, 0, COMS_NX);
  for (j = 0; j <= COMS_NY; j++) {
    j1 = COMS_NY - j;
    gzread(fp, com1[j1], COMS_NX+1);
  }
  gzclose(fp);

  // 3. �Ȱ� ����ǥ
  //color_fog = gdImageColorAllocate(im, 255, 102, 255);
  //color_fog = gdImageColorAllocate(im, 226, 154, 226);
  color_fog = gdImageColorAllocate(im, 204, 102, 255);

  // 4. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_x[0] != '0') {
    for (i = 0; i < 7; i++, zm *= 2) {
      zx = var.zoom_x[i]-'0';
      zy = var.zoom_y[i]-'0';
      if (zx == 0 || zy == 0) break;

      xo += ((var.NX - 1)/8.0*(zx-1)/zm);
      yo += ((var.NY - 1)/8.0*(zy-1)/zm);
    }
  }

  // 5. �̹��� �ȼ����� ���
  for (j = 1; j < var.NJ; j++) {
    y1 = dg*j/zm + yo + (COMS_SY*COMS_GRID - var.SY);
    iy = (int)(y1/COMS_GRID + 0.49);
    if (iy < 0 || iy >= COMS_NY) continue;

    for (i = 1; i < var.NI; i++) {
      x1 = dg*i/zm + xo + (COMS_SX*COMS_GRID - var.SX);
      ix = (int)(x1/COMS_GRID + 0.49);
      if (ix < 0 || ix >= COMS_NX) continue;

      c1 = com1[iy][ix];
      if (c1 > 0 && c1 < 5) gdImageSetPixel(im, i, var.GJ-j, color_fog);
    }
  }

  free_cmatrix(com1, 0, COMS_NY, 0, COMS_NX);
  return 0;
}

/*******************************************************************************
 *  ���̴� ǥ��
 *******************************************************************************/
int rdr_oth_disp(gdImagePtr im)
{
  FILE *fp;
  gzFile fg;
  URL_FILE *fr;
  char   url[120];
  struct stat st;
  char   fname[120];
  short  **rdr1, r1;
  float  dg = (float)var.NX/(float)(var.NI);
  float  zm = 1.0, xo = 0.0, yo = 0.0, zx, zy, x1, y1, v1, rt;
  float  dxo = H3_SX - var.SX;
  float  dyo = H3_SY - var.SY;
  float  dbz1, data_min, data_max, grid_zoom = 1.0;
  float  data_lvl[120];
  int    color_rdr_area;
  int    nx, ny, ng;
  int    YY, MM, DD, HH, MI;
  int    R, G, B;
  int    ok = 0, seq, code, c1;
  int    i, j, k, j1, ix, iy, n;


  // 1. ���� �ռ��� ������ �ִ��� Ȯ���ϰ� ������ �װ��� ���� �����
  ok = 0;
  for (seq = var.seq; seq >= var.seq-30; seq -= 5) {
    seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    sprintf(fname, "%s/%04d%02d/%02d/RDR_CMP_OTH_%04d%02d%02d%02d%02d.bin.gz",
            RDR_CMP_DIR, YY, MM, DD, YY, MM, DD, HH, MI);
    code = stat(fname, &st);
    if (code == 0 && st.st_size > 100) {
      ok = 1;
      break;
    }
  }
  if (ok) {
    if ((fg = gzopen(fname,"rb")) != NULL) {
      gzbuffer(fg, 64*1024);
      gzread(fg, &rdr_cmp_head, sizeof(rdr_cmp_head));
      gzread(fg, rdr_cmp_stn_list, sizeof(rdr_cmp_stn_list));
      rdr1 = smatrix(0, rdr_cmp_head.ny-1, 0, rdr_cmp_head.nx-1);
      for (j = 0; j < rdr_cmp_head.ny; j++)
        gzread(fg, rdr1[j], rdr_cmp_head.nx*2);
      gzclose(fg);
    }
    else
      ok = 0;
  }

  // 2. ������ ������ URL ������� �ռ��ڷḦ ���� ��û
  if (ok == 0) {
    seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    sprintf(url, "http://rdr.kma.go.kr/cgi-bin/rdr/nph-rdr_cmp_oth_data?tm=%04d%02d%02d%02d%02d&disp=B", YY, MM, DD, HH, MI);
    //printf("%s\n", url);
    if ((fr = url_fopen(url, "r"))) {
      n = url_fread(&rdr_cmp_head, sizeof(struct RDR_CMP_HEAD), 1, fr);
      n = url_fread(rdr_cmp_stn_list, sizeof(struct RDR_CMP_STN_LIST), 48, fr);
      rdr1 = smatrix(0, (int)(rdr_cmp_head.ny-1), 0, (int)(rdr_cmp_head.nx-1));
      for (j = 0; j < rdr_cmp_head.ny; j++)
        n = url_fread(rdr1[j], 2, rdr_cmp_head.nx, fr);
      url_fclose(fr);
    }
    else
      return -1;
  }

  // 3. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_x[0] != '0') {
    for (i = 0; i < 7; i++, zm *= 2) {
      zx = var.zoom_x[i]-'0';
      zy = var.zoom_y[i]-'0';
      if (zx == 0 || zy == 0) break;

      xo += ((var.NX - 1)/8.0*(zx-1)/zm);
      yo += ((var.NY - 1)/8.0*(zy-1)/zm);
    }
  }

  // 4. �ִ밪���� ��ġ
  rt = rdr_cmp_head.nx/(var.NI*zm);
  if      (rt >= 6) ng = 8;
  else if (rt >= 3) ng = 4;
  else if (rt >= 1.5) ng = 2;
  else ng = 1;

  grid_short_filter(rdr1, (int)(rdr_cmp_head.nx), (int)(rdr_cmp_head.ny), BLANK3);
  //if (ng > 1) grid_short_max(rdr1, (int)(rdr_cmp_head.nx), (int)(rdr_cmp_head.ny), ng);

  //printf("rdr_cmp_head.nx = %d, rdr_cmp_head.ny = %d\n", rdr_cmp_head.nx, rdr_cmp_head.ny);
  //printf("%04d.%02d.%02d.%02d:%02d\n", rdr_cmp_head.tm.YY, rdr_cmp_head.tm.MM, rdr_cmp_head.tm.DD, rdr_cmp_head.tm.HH, rdr_cmp_head.tm.MI);
  //for (i = 0; i < 10; i++)
  //  printf("i = %d, %d\n", i, rdr_cmp_stn_list[i].tm.YY);

  // 5. ���̴� ����ǥ (mm/h)
  //sprintf(fname, "%s/color_rdr_noaa.rgb", COLOR_SET_DIR);   // �̱����û ����ǥ
  sprintf(fname, "%s/color_rdr_rn1.rgb", COLOR_SET_DIR);    // ���� ����ǥ
  if ((fp = fopen(fname,"r")) == NULL) return -1;
  num_color_rdr = 0;
  while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
    color_rdr[num_color_rdr] = gdImageColorAllocate(im, R, G, B);
    data_rdr[num_color_rdr] = v1;
    num_color_rdr++;
    if (num_color_rdr >= 120) break;
  }
  fclose(fp);
  color_rdr_area = gdImageColorAllocate(im, 0, 233, 233);   // ���̴����� �׵θ���

  // 6. ���ʰ� ���� �� ǥ����� ����
  for (k = 0; k < num_color_rdr; k++) {
    dbz_rain_conv(&dbz1, &data_rdr[k], 1);
    data_lvl[k] = dbz1*100;
  }
  data_min = 100;     // 1dBZ
  data_max = 20000;   // 200dBZ

  // 7. �̹��� �ȼ����� ���
  for (j = 1; j < var.NJ; j++) {
    // 7.1. �ڷ� Y���� �迭 ��ġ
    y1 = dg*j/zm + yo + dyo;
    iy = (int)(y1*grid_zoom + 0.49);
    if (iy < 1 || iy >= rdr_cmp_head.ny-1) continue;
    //printf("j = %d, %d, %d\n", j, iy, rdr1[j][1000]);

    // 7.2. X����
    for (i = 1; i < var.NI; i++) {
      // 7.2.1. �ڷ� X���� �迭 ��ġ
      x1 = dg*i/zm + xo + dxo;
      ix = (int)(x1*grid_zoom + 0.49);
      if (ix < 1 || ix >= rdr_cmp_head.nx-1) continue;

      // 7.2.2. ������ �̻��̸� ǥ��
      v1 = rdr1[iy][ix];
      if (v1 >= data_min && v1 < data_max) {
        for (k = 0; k < num_color_rdr; k++) {
          if (v1 < data_lvl[k]) {
            gdImageSetPixel(im, i, var.GJ-j, color_rdr[k]);
            break;
          }
        }
      }
    }

    // 7.3. ���̴� �������� ��輱 ǥ��(X����)
    for (ix = 1; ix < rdr_cmp_head.nx-1; ix++) {
      if (rdr1[iy][ix] == BLANK1) {
        if (rdr1[iy][ix-1] > BLANK1 || rdr1[iy][ix+1] > BLANK1) {
          i = ix/grid_zoom - dxo -  xo;
          i = (int)(i*zm/dg);
          gdImageSetPixel(im, i, var.GJ-j, color_rdr_area);
        }
      }
    }
  }

  // 8. ���̴� �������� ��輱 ǥ��(Y����)
  for (i = 1; i < var.NI; i++) {
    x1 = dg*i/zm + xo + dxo;
    ix = (int)(x1*grid_zoom + 0.49);
    if (ix < 1 || ix >= rdr_cmp_head.nx-1) continue;

    for (iy = 1; iy < rdr_cmp_head.ny-1; iy++) {
      if (rdr1[iy][ix] == BLANK1) {
        if (rdr1[iy-1][ix] > BLANK1 || rdr1[iy+1][ix] > BLANK1) {
          j = iy/grid_zoom - dyo -  yo;
          j = (int)(j*zm/dg);
          gdImageSetPixel(im, i, var.GJ-j, color_rdr_area);
        }
      }
    }
  }

  // 9. ǥ���� �ڷ� ����� �迭 ����
  free_smatrix(rdr1, 0, (int)(rdr_cmp_head.ny-1), 0, (int)(rdr_cmp_head.nx-1));
  return 0;
}

/*******************************************************************************
 *  ���̴� ǥ��
 *******************************************************************************/
int rdr_disp(gdImagePtr im)
{
  FILE  *fp;
  gzFile fg;
  struct stat st;
  char   fname[120];
  short  **rdr1, r1;
  float  dg = (float)var.NX/(float)(var.NI);
  float  zm = 1.0, xo = 0.0, yo = 0.0, zx, zy, x1, y1, v1, rt;
  float  dxo, dyo, dbz1, data_min, data_max, grid_zoom;
  float  data_lvl[120];
  int    color_rdr_area, ng;
  int    YY, MM, DD, HH, MI;
  int    R, G, B;
  int    ok = 0, seq, code, c1;
  int    i, j, k, j1, ix, iy;

  // 1. ���� Ȯ��
  if (!strcmp(var.rdr,"oth")) {
    for (seq = var.seq; seq >= var.seq-60; seq -= 5) {
      seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
      sprintf(fname, "%s/%04d%02d/%02d/RDR_CMP_OTH_%04d%02d%02d%02d%02d.bin.gz",
              RDR_CMP_DIR, YY, MM, DD, YY, MM, DD, HH, MI);
      code = stat(fname, &st);
      if (code == 0 && st.st_size > 100) {
        ok = 1;
        break;
      }
    }
    dxo = H3_SX - var.SX;
    dyo = H3_SY - var.SY;
    grid_zoom = 1.0;    // 1km �ػ� �ڷ�
  }
  else if (!strcmp(var.rdr,"lng")) {
    for (seq = var.seq; seq >= var.seq-60; seq -= 5) {
      seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
      sprintf(fname, "%s/%04d%02d/%02d/RDR_CMP_LNG_QCD_%04d%02d%02d%02d%02d.bin.gz",
              RDR_CMP_DIR, YY, MM, DD, YY, MM, DD, HH, MI);
      code = stat(fname, &st);
      if (code == 0 && st.st_size > 100) {
        ok = 1;
        break;
      }
    }
    dxo = HC_SX - var.SX;
    dyo = HC_SY - var.SY;
    grid_zoom = 1.0;    // 1km �ػ� �ڷ�
  }
  else {
    for (seq = var.seq; seq >= var.seq-60; seq -= 5) {
      seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
      sprintf(fname, "%s/%04d%02d/%02d/RDR_SFC_PTY_%04d%02d%02d%02d%02d.bin.gz",
              RDR_OBS_DIR, YY, MM, DD, YY, MM, DD, HH, MI);
      code = stat(fname, &st);
      if (code == 0 && st.st_size > 100) {
        ok = 1;
        break;
      }
    }
    dxo = HR_SX - var.SX;
    dyo = HR_SY - var.SY;
    grid_zoom = 2.0;    // 500m �ػ� �ڷ�
  }
  if (ok == 0) return -1;
  var.seq = seq;

  // 2. �ڷ� �б�
  if ((fg = gzopen(fname,"rb")) == NULL) return -1;
  gzbuffer(fg, 64*1024);
  gzread(fg, &rdr_cmp_head, sizeof(rdr_cmp_head));
  if (!strcmp(var.rdr,"oth"))
    gzread(fg, rdr_cmp_stn_list, sizeof(rdr_cmp_stn_list));
  else if (!strcmp(var.rdr,"lng"))
    gzread(fg, rdr_cmp_stn_list, sizeof(rdr_cmp_stn_list));
  else
    gzseek(fg, (long)(rdr_cmp_head.ny*rdr_cmp_head.nx*4), SEEK_CUR);
  rdr1 = smatrix(0, rdr_cmp_head.ny-1, 0, rdr_cmp_head.nx-1);
  for (j = 0; j < rdr_cmp_head.ny; j++)
    gzread(fg, rdr1[j], rdr_cmp_head.nx*2);
  gzclose(fg);

  // 3. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_x[0] != '0') {
    for (i = 0; i < 7; i++, zm *= 2) {
      zx = var.zoom_x[i]-'0';
      zy = var.zoom_y[i]-'0';
      if (zx == 0 || zy == 0) break;

      xo += ((var.NX - 1)/8.0*(zx-1)/zm);
      yo += ((var.NY - 1)/8.0*(zy-1)/zm);
    }
  }

  // 4. �ִ밪���� ��ġ
  rt = rdr_cmp_head.nx/(var.NI*zm);
  if      (rt >= 6) ng = 8;
  else if (rt >= 3) ng = 4;
  else if (rt >= 1.5) ng = 2;
  else ng = 1;

  grid_short_filter(rdr1, (int)(rdr_cmp_head.nx), (int)(rdr_cmp_head.ny), BLANK3);
  //if (ng > 1) grid_short_max(rdr1, (int)(rdr_cmp_head.nx), (int)(rdr_cmp_head.ny), ng);

  // 5. ���̴� ����ǥ (mm/h)
  //sprintf(fname, "%s/color_rdr_noaa.rgb", COLOR_SET_DIR);   // �̱����û ����ǥ
  sprintf(fname, "%s/color_rdr_rn1.rgb", COLOR_SET_DIR);    // ���� ����ǥ
  if ((fp = fopen(fname,"r")) == NULL) return -1;
  num_color_rdr = 0;
  while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
    color_rdr[num_color_rdr] = gdImageColorAllocate(im, R, G, B);
    data_rdr[num_color_rdr] = v1;
    num_color_rdr++;
    if (num_color_rdr >= 120) break;
  }
  fclose(fp);
  color_rdr_area = gdImageColorAllocate(im, 0, 233, 233);   // ���̴����� �׵θ���

  // 6. ���ʰ� ���� �� ǥ����� ����
  if (!strcmp(var.rdr,"oth")) {
    for (k = 0; k < num_color_rdr; k++) {
      dbz_rain_conv(&dbz1, &data_rdr[k], 1);
      data_lvl[k] = dbz1*100;
    }
    data_min = 100;     // 1dBZ
    data_max = 20000;   // 200dBZ
  }
  else if (!strcmp(var.rdr,"lng")) {
    for (k = 0; k < num_color_rdr; k++) {
      dbz_rain_conv(&dbz1, &data_rdr[k], 1);
      data_lvl[k] = dbz1*100;
    }
    data_min = 500;     // 5dBZ
    data_max = 20000;   // 200dBZ
  }
  else {
    for (k = 0; k < num_color_rdr; k++)
      data_lvl[k] = data_rdr[k]*100;
    data_min = 1;       // 0.01mm/h
    data_max = 30000;   // 300mm/h
  }

  // 7. �̹��� �ȼ����� ���
  for (j = 1; j < var.NJ; j++) {
    // 7.1. �ڷ� Y���� �迭 ��ġ
    y1 = dg*j/zm + yo + dyo;
    iy = (int)(y1*grid_zoom + 0.49);
    if (iy < 1 || iy >= rdr_cmp_head.ny-1) continue;

    // 7.2. X����
    for (i = 1; i < var.NI; i++) {
      // 7.2.1. �ڷ� X���� �迭 ��ġ
      x1 = dg*i/zm + xo + dxo;
      ix = (int)(x1*grid_zoom + 0.49);
      if (ix < 1 || ix >= rdr_cmp_head.nx-1) continue;

      // 7.2.2. ������ �̻��̸� ǥ��
      v1 = rdr1[iy][ix];
      if (v1 >= data_min && v1 < data_max) {
        for (k = 0; k < num_color_rdr; k++) {
          if (v1 < data_lvl[k]) {
            gdImageSetPixel(im, i, var.GJ-j, color_rdr[k]);
            break;
          }
        }
      }
    }

    // 7.3. ���̴� �������� ��輱 ǥ��(X����)
    for (ix = 1; ix < rdr_cmp_head.nx-1; ix++) {
      if (rdr1[iy][ix] == BLANK1) {
        if (rdr1[iy][ix-1] > BLANK1 || rdr1[iy][ix+1] > BLANK1) {
          i = ix/grid_zoom - dxo -  xo;
          i = (int)(i*zm/dg);
          gdImageSetPixel(im, i, var.GJ-j, color_rdr_area);
        }
      }
    }
  }

  // 8. ���̴� �������� ��輱 ǥ��(Y����)
  for (i = 1; i < var.NI; i++) {
    x1 = dg*i/zm + xo + dxo;
    ix = (int)(x1*grid_zoom + 0.49);
    if (ix < 1 || ix >= rdr_cmp_head.nx-1) continue;

    for (iy = 1; iy < rdr_cmp_head.ny-1; iy++) {
      if (rdr1[iy][ix] == BLANK1) {
        if (rdr1[iy-1][ix] > BLANK1 || rdr1[iy+1][ix] > BLANK1) {
          j = iy/grid_zoom - dyo -  yo;
          j = (int)(j*zm/dg);
          gdImageSetPixel(im, i, var.GJ-j, color_rdr_area);
        }
      }
    }
  }

  // 9. ǥ���� �ڷ� ����� �迭 ����
  free_smatrix(rdr1, 0, rdr_cmp_head.ny-1, 0, rdr_cmp_head.nx-1);
  return 0;
}

/*=============================================================================*
 *  Z-R �����
 *     - mode : 0(dBZ->������), 1(������->dBZ)
 *=============================================================================*/
int dbz_rain_conv(float *dbz1, float *rain1, int mode)
{
  static int first = 0;
  static float za, zb;

  if (first == 0) {
    za = 0.1/var.ZRb;
    zb = log10(var.ZRa)/var.ZRb;
    first = 1;
  }

  if (mode == 0) {
    //*rain1 = (*dbz1*0.1 - log10(var.ZRa) )/var.ZRb;
    *rain1 = *dbz1*za - zb;
    *rain1 = pow(10.0, *rain1);
  }
  else if (mode == 1) {
    *dbz1 = 10.0 * log10( var.ZRa * pow(*rain1, var.ZRb) );
  }
  return 0;
}

/*******************************************************************************
 *  ���� ǥ��
 *******************************************************************************/
int lgt_disp(gdImagePtr im)
{
  FILE   *fp;
  struct lamc_parameter map;
  char   fname[120], buf[1000], tmp[100], tp[8], gc, wkt[100];
  float  zm = 1.0, xo = 0.0, yo = 0.0, zx, zy, x1, y1;
  float  x, y, lat, lon, ht, power, nsf, errd, f1, f2, f3, f5;
  int    id, mt, gcd, d4, nscan, t1;
  int    YY, MM, DD, HH, MI, SS, nsec, seq;
  int    YY1, MM1, DD1, HH1, MI1;
  int    YY2, MM2, DD2, HH2, MI2;
  int    nday, iseq, diff, ix, iy, depth = 3;
  int    i, j, k, code;

  // 1. ���� ����ǥ
  //color_lgt = gdImageColorAllocate(im, 255, 255, 0);
  color_lgt = gdImageColorAllocate(im, 255, 0, 0);

  // 2. Ȯ�븦 �ݿ��� ������ȯ ����
  if (var.zoom_level > 0) {
    for (i = 0; i < 7; i++) {
      zx = var.zoom_x[i]-'0';
      zy = var.zoom_y[i]-'0';
      if (zx == 0 || zy == 0) break;

      xo += ((var.NX - 1)/8.0*(zx-1)/zm);
      yo += ((var.NY - 1)/8.0*(zy-1)/zm);
      zm *= var.zoom_rate;
    }
  }
  zm *= ((float)(var.NI)/(float)(var.NX));

  map.Re    = 6371.00877;
  map.grid  = var.grid/zm;
  map.slat1 = 30.0;    map.slat2 = 60.0;
  map.olon  = 126.0;   map.olat  = 38.0;
  map.xo = (float)var.SX/map.grid - xo*zm;
  map.yo = (float)var.SY/map.grid - yo*zm;
  map.first = 0;

  // 3. ���� ������ �� Ȯ��
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  seq2time(var.seq-var.itv, &YY1, &MM1, &DD1, &HH1, &MI1, 'm', 'n');
  if (DD1 == DD) nday = 0;
  else           nday = 1;

  if (var.zoom_level > 0) depth = 4;
  if (var.zoom_level >= 2) depth = 6;

  // 4. �ڷ� ������ ���������� �о ó��
  for (k = nday; k >= 0; k--) {
    seq2time(var.seq-k*24*60, &YY1, &MM1, &DD1, &HH1, &MI1, 'm', 'n');
    code = lgt_file(fname, YY1, MM1, DD1);
    if (code < 0) continue;
    if ((fp = fopen(fname, "r")) == NULL) continue;

    while (fgets(buf, 1024, fp) != NULL) {
      if (strstr(fname,"NX1")) {
        if (strlen(buf) < 80) continue;
        sscanf(buf, "%d %d-%d-%d %d:%d:%d.%d+%s %d %s %f %f %f %f %f %d %d",
               &id, &YY, &MM, &DD, &HH, &MI, &SS, &nsec, tmp, &nsf, wkt, &lon, &lat, &ht, &power, &errd, &gcd, &nscan);
        if (gcd != 1) continue;     // ��������(1)�� ǥ�� (2:��������)
        if (nscan < 4) continue;    // 4�� �̻� ������ ������ ��츸 ǥ��

        iseq = time2seq(YY, MM, DD, HH, MI, 'm');
        diff = abs(var.seq - iseq);
      }
      else {
        nscan = 3;  // ���� ���� ���Ͱ� 3�� �̻��� ��츸 ǥ�� (�ֱ� ���˿��� ����. ���Ŵ� �׳� ǥ��)
        if (code == 0) {
          if (strlen(buf) > 80) {
            sscanf(buf, "%d/%d/%d %d:%d:%f %f %f %f %d %f %f %f %d %f %d %c",
              &MM, &DD, &YY, &HH, &MI, &SS, &lat, &lon, &power, &mt, &f1, &f2, &f3, &d4, &f5, &nscan, &gc);
          }
          else {
            sscanf(buf, "%d/%d/%d %d:%d:%f %f %f %f %d", &MM, &DD, &YY, &HH, &MI, &SS, &lat, &lon, &power, &mt);
            gc = 'G';
          }
        }
        else if (code == 1) {
          YY = YY1;  MM = MM1;  DD = DD1;
          sscanf(buf, "%d:%d:%f %f %f %f %d", &HH, &MI, &SS, &lat, &lon, &power, &mt);
          gc = 'G';
        }
        else if (code == 2) {
          sscanf(buf, "%d/%d/%d %d:%d:%f %f %f %f %d", &MM, &DD, &YY, &HH, &MI, &SS, &lat, &lon, &power, &mt);
          gc = 'G';
        }
        else if (code == 3) {
          getword(tmp,buf,' ');
          getword(tp, buf,' ');
          if (strcmp(tp,"FG") == 0) gc = 'G';
          else                      gc = 'C';

          getword(tmp,buf,'/');  MM = atoi(tmp);
          getword(tmp,buf,'/');  DD = atoi(tmp);
          getword(tmp,buf,' ');  YY = atoi(tmp) + 2000;
          getword(tmp,buf,':');  HH = atoi(tmp);
          getword(tmp,buf,':');  MI = atoi(tmp);
          getword(tmp,buf,'.');  SS = atoi(tmp);
          getword(tmp,buf,' ');  nsec = atoi(tmp);

          getword(tmp,buf,'=');  lat = atof(buf);
          getword(tmp,buf,'=');  lon = atof(buf);
          getword(tmp,buf,'=');  power = atof(buf);
        }
        if (gc != 'G' || nscan < 3) continue;

        if (YY < 80) YY += 2000;
        else if (YY <= 99) YY += 1900;

        iseq = time2seq(YY, MM, DD, HH, MI, 'm');
        if (code == 3) iseq += 9*60;
        diff = abs(var.seq - iseq);
      }

      if (diff >= 0 && diff <= var.itv) {
        lamcproj_ellp(&lon, &lat, &x, &y, 0, &map);

        if (x > 2.0 && x < (float)(var.NI-2) && y > 2.0 && y < (float)(var.NJ-2)) {
          ix = (int)(x + 0.5);
          iy = var.GJ - (int)(y + 0.5);
          gdImageLine(im, ix-depth, iy, ix+depth, iy, color_lgt);
          gdImageLine(im, ix, iy-depth, ix, iy+depth, color_lgt);
          if (var.zoom_level >= 2) {
            gdImageLine(im, ix-depth, iy-1, ix+depth, iy-1, color_lgt);
            gdImageLine(im, ix+1, iy-depth, ix+1, iy+depth, color_lgt);
          }
        }
      }
      else if (diff < 0)
        break;
    }
    fclose(fp);
  }
  return 0;
}

/*=============================================================================*
 *  ���� ���ϸ��� ���� ���� (���û)
 *=============================================================================*/
int lgt_file(char *fname, int YY, int MM, int DD)
{
  struct stat st1, st2, st3;
  int    code = 0;

  if ((YY*100+MM)*100+DD >= 20150401) {
    sprintf(fname, "%s/%04d/LGT_KMA_NX1_%02d%02d%02d.asc", LGT_DIR, YY, YY, MM, DD);
    if (stat(fname, &st1) < 0)
      code = -3;
    else
      code = 0;
  }
  else {
    sprintf(fname, "%s/%04d/LGT_KMA_%02d%02d%02d.asc", LGT_DIR, YY, YY, MM, DD);
    if (stat(fname, &st1) < 0) {
      sprintf(fname, "%s/%04d/LGT_TDM_%04d%02d%02d.asc", LGT_DIR, YY, YY, MM, DD);
      if (stat(fname, &st2) < 0) {
        sprintf(fname, "%s/%04d/LGT_LVL_%04d%02d%02d.asc", LGT_DIR, YY, YY, MM, DD);
        if (stat(fname, &st3) < 0)
          code = -3;
        else
          code = 2;
      }
      else
        code = 1;
    }
    else if (st1.st_size < 10) {
      if (st1.st_size < 10)
        code = -2;
      else
        code = 0;
    }
  }
  return code;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int map_disp(gdImagePtr im, int kind)
{
  FILE  *fp;
  char  fname[120];
  float zm = 1.0, xo = 0.0, yo = 0.0, x1, y1, x2, y2;
  float rate = (float)(var.NI)/(float)(var.NX);
  float buf[2];
  int   ibuf[2];
  int   zx, zy, depth, mode;
  int   color_map;
  int   i, j, k, n;

  // 1. ���� �β�
  if (var.NI > 900)
    depth = 1;
  else if (var.NI > 650 && kind == 4)
    depth = 1;
  else
    depth = 0;

  // 2. ���� ����
  if (kind == 4)
//    color_map = gdImageColorAllocate(im, 0, 0, 255);
    color_map = gdImageColorAllocate(im, 1, 1, 1);
  else
    color_map = gdImageColorAllocate(im, 110, 110, 110);

  // 3. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_x[0] != '0') {
    for (i = 0; i < 7; i++, zm *= 2) {
      zx = var.zoom_x[i]-'0';
      zy = var.zoom_y[i]-'0';
      if (zx == 0 || zy == 0) break;

      xo += (float)(var.NX)/8.0*(zx-1)/zm;
      yo += (float)(var.NY)/8.0*(zy-1)/zm;
    }
  }

  // 4. �ؾȼ� ǥ��
  /* ASCII ���� ����
  sprintf(fname, "%s/AFS_%s_map%d.dat", MAP_DIR, var.map, kind);
  if ((fp = fopen(fname, "r")) != NULL) {
    while (fscanf(fp, "%d %d\n", &n, &mode) != EOF) {
      for (i = 0; i < n; i++) {
        fscanf(fp, "%f %f\n", &x2, &y2);
        if (var.zoom_x[0] != '0') {
          x2 = zm*(x2-xo);
          y2 = zm*(y2-yo);
        }
        x2 *= ((float)(var.NI)/(float)(var.NX));
        y2 *= ((float)(var.NI)/(float)(var.NX));
        if (i > 0) {
          gdImageLine(im, (int)x1, var.GJ-(int)y1, (int)x2, var.GJ-(int)y2, color_map);
          if (depth) gdImageLine(im, (int)x1, var.GJ-(int)y1-1, (int)x2, var.GJ-(int)y2-1, color_map);
        }
        x1 = x2;
        y1 = y2;
      }
    }
    fclose(fp);
  }
  */
  sprintf(fname, "%s/AFS_%s_map%d.bln", MAP_DIR, var.map, kind);
  if ((fp = fopen(fname, "rb")) != NULL) {
    while (fread(ibuf, sizeof(int), 2, fp) == 2) {
      for (i = 0; i < ibuf[0]; i++) {
        if (fread(buf, sizeof(float), 2, fp) != 2) break;
        x2 = buf[0]/var.grid;
        y2 = buf[1]/var.grid;
        if (var.zoom_x[0] != '0') {
          x2 = zm*(x2-xo);
          y2 = zm*(y2-yo);
        }
        x2 *= rate;
        y2 *= rate;
        if (i > 0) {
          gdImageLine(im, (int)x1, var.GJ-(int)y1, (int)x2, var.GJ-(int)y2, color_map);
          //if (depth) gdImageLine(im, (int)x1, var.GJ-(int)y1-1, (int)x2, var.GJ-(int)y2-1, color_map);
        }
        x1 = x2;
        y1 = y2;
      }
    }
    fclose(fp);
  }
  return 0;
}

/*=============================================================================*
 *  EUC-KR���ڿ��� UTF-8�� ��ȯ
 *=============================================================================*/
int euckr2utf(char *str, char *out)
{
  iconv_t convp;
  size_t  ileft = strlen(str), oleft = strlen(str)*2;
  int     err;

  convp = iconv_open("UTF-8", "euc-kr");
  err = iconv(convp, &str, &ileft, &out, &oleft);
  iconv_close(convp);
  return err;
}

/*=============================================================================*
 *  ���� ǥ��(�ѱ�ó��)
 *=============================================================================*/
int title_disp(gdImagePtr im, int color_lvl[])
{
  char   title[80], tmp[50], text[100], text_utf[100];
  double font_size = 11;
  int    brect[8];
  int    YY, MM, DD, HH, MI;
  int    x, y, i, k;

  // 1. ���񿵿��� ���� ó��
  gdImageFilledRectangle(im, 0, 0, var.GI, TITLE_pixel, color_lvl[241]);

  // 2. ������
  if (!strcmp(var.rdr,"oth"))
    strcpy(title, "���� ���̴�");
  else if (!strcmp(var.rdr,"lng"))
    strcpy(title, "���̴�(480km)");
  else if (!strcmp(var.rdr,"hsr"))
    strcpy(title, "���̴�");
  else
    title[0] = '\0';

  if (strlen(title) > 0) strcat(title,"+");
  if (!strcmp(var.sat,"ir1"))
    strcat(title, "����");
  else if (!strcmp(var.sat,"wvp"))
    strcat(title, "������");
  else if (!strcmp(var.sat,"ct"))
    strcat(title, "����");

  for (i = 0; i < 100; i++)
    text_utf[i] = 0;
  euckr2utf(title, text_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 5, (int)(font_size+5), text_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 6, (int)(font_size+5), text_utf);

  // 3. �ð� ���ڿ�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(text, "%04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, MI);

  x = strlen(title)*8.5 + 10;
  if (x < 130) x = 130;

  for (i = 0; i < 100; i++)
    text_utf[i] = 0;
  euckr2utf(text, text_utf);
  gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, x, (int)(font_size+5), text_utf);
  gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, x+1, (int)(font_size+5), text_utf);

  // 3. �����ð� ���ڿ�
  if (var.sat_ok > 0) {
    seq2time(var.seq_sat, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    sprintf(text, "�����ð� : %04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, MI);
    if (var.sat_ok == 1)
      strcat(text, " (C)");
    else if (var.sat_ok == 2)
      strcat(text, " (H)");
    for (i = 0; i < 100; i++) text_utf[i] = 0;
    euckr2utf(text, text_utf);

    x = 10;
    y = var.GJ - 15;
    gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, x, y, text_utf);
    gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, x+1, y, text_utf);
  }
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int legend_disp(gdImagePtr im, int color_lvl[])
{
  char   txt[20], txt2[20];
  char   txt_utf[30];
  double font_size = 8.0;
  int    brect[8], unit_ok = 0, color1;
  int    dy;
  int    YY, MM, DD, HH, MI;
  int    x, y, y2, i, j, k;

  if (var.legend != 1) return 0;
  gdImageFilledRectangle(im, var.NI, 0, var.GI-1, var.GJ, color_lvl[241]);

  // 1. ���� ����
  y = TITLE_pixel;
  dy = 25;
  if (var.sat_ok) {
    if (!strcmp(var.sat,"ct")) {
      for (k = 5; k >= 1; k--, y += dy) {
        gdImageFilledRectangle(im, var.NI, y, var.NI+8, y+dy, color_sat[k]);
        gdImageRectangle(im, var.NI-1, y, var.NI+8, y+dy, color_lvl[242]);

        if      (k == 5) strcpy(txt,"������");
        else if (k == 4) strcpy(txt,"������");
        else if (k == 3) strcpy(txt,"������");
        else if (k == 2) strcpy(txt,"������");
        else if (k == 1) strcpy(txt,"������");

        for (y2 = y+12, j = 0; j < strlen(txt); j += 4, y2 += 11) {
          strncpy(txt2, &txt[j], 4);
          for (i = 0; i < 30; i++) txt_utf[i] = 0;
          euckr2utf(txt2, txt_utf);
          gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, var.NI+11, y2, txt_utf);
        }
      }
    }
  }

  // 2. �Ȱ� ����
  if (var.fog) {
    gdImageFilledRectangle(im, var.NI, y, var.NI+8, y+dy, color_fog);
    gdImageRectangle(im, var.NI-1, y, var.NI+8, y+dy, color_lvl[242]);

    for (i = 0; i < 30; i++) txt_utf[i] = 0;
    euckr2utf("�Ȱ�", txt_utf);
    gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, var.NI+11, y+18, txt_utf);
  }

  // 3. ���̴� ����
  dy = 20;
  if (strcmp(var.rdr,"non") != 0) {
    y += (4*dy);
    for (i = 0; i < 30; i++) txt_utf[i] = 0;
    euckr2utf("���̴�", txt_utf);
    gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, 9.0, 0.0, var.NI+1, y-10, txt_utf);

    for (k = num_color_rdr-1; k >= 0; k--, y += dy) {
      gdImageFilledRectangle(im, var.NI, y, var.NI+8, y+dy, color_rdr[k]);
      gdImageRectangle(im, var.NI-1, y, var.NI+8, y+dy, color_lvl[242]);

      if (k < num_color_rdr && k >= 0) {
        if (k == num_color_rdr-1)
          strcpy(txt, "mm/h");
        else
          sprintf(txt, "%.0f", data_rdr[k]);

        gdImageString(im, gdFontSmall, var.NI+12, y-5, txt, color_lvl[244]);
      }
    }
  }

  // 4. ���� ����
  if (var.lgt) {
    y += dy;
    gdImageFilledRectangle(im, var.NI, y, var.NI+8, y+dy, color_lvl[249]);
    gdImageLine(im, var.NI+2, y+dy/2, var.NI+6, y+dy/2, color_lgt);
    gdImageLine(im, var.NI+4, y+dy/2-2, var.NI+4, y+dy/2+2, color_lgt);

    for (i = 0; i < 30; i++) txt_utf[i] = 0;
    euckr2utf("����", txt_utf);
    gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, 9.0, 0.0, var.NI+11, y+18, txt_utf);
  }
  return 0;
}

/*******************************************************************************
 *  Grid data Smoothing (by 1-2-1 Smoothing)
 *  by ����ȯ (1997. 3. 15)
 *******************************************************************************/
int grid_smooth (
  float **g,      // input -> output
  int   nx,       // ���� [0:nx-1,0:ny-1]
  int   ny,
  float missing   // ���ϴ� �ڷ� ����
)
{
  float  *e1, *e2, *e3, *e4;
  float  v1, v2, *v4;
  int    i, j;

  // 1. Y�� ��������, X�� �������� ��Ȱȭ�Ѵ�.
  for (j = 0; j < ny; j++) {
    e1 = &g[j][0];
    e2 = &g[j][1];
    e3 = &g[j][2];
    v1 = *e1;

    for (v1 = *e1, i = 1; i < nx-1; i++, e1++, e2++, e3++) {
      if (*e1 > missing && *e2 > missing && *e3 > missing)
        v2 = (*e1 + *e2 + *e2 + *e3) * 0.25;
      else if (*e1 > missing && *e2 <= missing && *e3 > missing)
        v2 = (*e1 + *e3) * 0.5;
      else
        v2 = *e2;

      (*e1) = v1;
      v1 = v2;
    }
    (*e1) = v1;
  }

  // 2. X�� ��������, Y�� �������� ��Ȱȭ�Ѵ�.
  v4 = vector(0, nx-1);    // �迭 �غ�
  for (j = 1; j < ny-1; j++) {
    e1 = &g[j-1][0];
    e2 = &g[j][0];
    e3 = &g[j+1][0];
    e4 = &v4[0];

    for (i = 0; i < nx; i++, e1++, e2++, e3++, e4++) {
      if (*e1 > missing && *e2 > missing && *e3 > missing)
        v2 = (*e1 + *e2 + *e2 + *e3) * 0.25;
      else if (*e1 > missing && *e2 <= missing && *e3 > missing)
        v2 = (*e1 + *e3) * 0.5;
      else
        v2 = *e2;

      if (j > 1) (*e1) = *e4;
      *e4 = v2;
    }
  }
  for (i = 0; i < nx; i++)
    (*e1) = *e4;

  // �迭 ����
  free_vector(v4, 0, nx-1);
  return 0;
}

/*******************************************************************************
 *  Grid data Smoothing (by 1-2-1 Smoothing)
 *  by ����ȯ (1997. 3. 15)
 *******************************************************************************/
int grid_short_filter (
  short **g,      // input -> output
  int   nx,       // ���� [0:nx-1,0:ny-1]
  int   ny,
  short missing   // ���ϴ� �ڷ� ����
)
{
  short  *e1, *e2, *e3, *e4;
  short  v1, v2, *v4;
  int    i, j;

  // 1. Y�� ��������, X�� �������� ��Ȱȭ�Ѵ�.
  for (j = 0; j < ny; j++) {
    e1 = &g[j][0];
    e2 = &g[j][1];
    e3 = &g[j][2];
    v1 = *e1;

    for (v1 = *e1, i = 1; i < nx-1; i++, e1++, e2++, e3++) {
      if (*e1 > missing && *e2 > missing && *e3 > missing)
        v2 = (*e1 + *e2 + *e2 + *e3) / 4;
      else if (*e1 > missing && *e2 <= missing && *e3 > missing)
        v2 = (*e1 + *e3) / 2;
      else
        v2 = *e2;

      (*e1) = v1;
      v1 = v2;
    }
    (*e1) = v1;
  }

  // 2. X�� ��������, Y�� �������� ��Ȱȭ�Ѵ�.
  v4 = svector(0, nx-1);    // �迭 �غ�
  for (j = 1; j < ny-1; j++) {
    e1 = &g[j-1][0];
    e2 = &g[j][0];
    e3 = &g[j+1][0];
    e4 = &v4[0];

    for (i = 0; i < nx; i++, e1++, e2++, e3++, e4++) {
      if (*e1 > missing && *e2 > missing && *e3 > missing)
        v2 = (*e1 + *e2 + *e2 + *e3) / 4;
      else if (*e1 > missing && *e2 <= missing && *e3 > missing)
        v2 = (*e1 + *e3) / 2;
      else
        v2 = *e2;

      if (j > 1) (*e1) = *e4;
      *e4 = v2;
    }
  }
  for (i = 0; i < nx; i++)
    (*e1) = *e4;

  // �迭 ����
  free_svector(v4, 0, nx-1);
  return 0;
}

/*******************************************************************************
 *  2*2 or 4*4 ������ �ִ밪���� ��ġ
 *******************************************************************************/
int grid_short_max (
  short **g,  // input -> output
  int   nx,   // ���� [0:nx-1,0:ny-1]
  int   ny,
  int   ng    // 2 or 4
)
{
  short  v1;
  int    i, j, i1, j1;

  for (j = 0; j < ny-ng; j += ng) {
    for (i = 0; i < nx-ng; i += ng) {

      // ng*ng ������ �ִ밪 Ȯ��
      v1 = g[j][i];
      for (j1 = j; j1 < j+ng; j1++) {
        for (i1 = i; i1 < i+ng; i1++) {
          if (v1 < g[j1][i1]) v1 = g[j1][i1];
        }
      }

      // �ִ밪���� ä���
      for (j1 = j; j1 < j+ng; j1++) {
        for (i1 = i; i1 < i+ng; i1++) {
          g[j1][i1] = v1;
        }
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  ��ȯ : {U,S,L} color  --> {R,G,B} color
 *=============================================================================*/
int USL2RGB(int U, int S, int L, int *R, int *G, int *B)
{
  float  L1;
  float  Max, Min;
  int    C[3];
  int    i, v;

  L1 = (255.0 - (float)L) * 0.5;

  if (S < 128) {
    Max = (255.0 - L1) / 127.0 * (float)S;
    Min = L1 / 127.0 * (float)S;
  }
  else {
    Min = 255.0 - (255.0 - L1) * (255.0 - (float)S) / 127.0;
    Max = 255.0 - L1 * (255.0 - (float)S) / 127.0;
  }

  for (i = 0; i < 3; i++) {
    if (i == 0)
      v = (U + 85) % 256;
    else if (i == 1)
      v = U;
    else
      v = (U + 170) % 256;

    if (v <= 42)
      C[i] = (int)( (Max - Min) * (float)v / 42.0 + Min );
    else if (v <= 127)
      C[i] = (int)Max;
    else if (v <= 170)
      C[i] = (int)( (Min - Max) * ((float)v - 127.0) / 43.0 + Max );
    else
      C[i] = (int)Min;
  }
  *R = C[0];
  *G = C[1];
  *B = C[2];
  return 0;
}

/*=============================================================================*
*  ��ȯ : {H,S,L} color  --> {R,G,B} color
 *=============================================================================*/
int HSL2RGB(int H, int S, int L, int *R, int *G, int *B)
{
  float S1;
  float Max, Min;
  int   C[3];
  int   i, v;

  S1 = (255.0 - (float)S) * 0.5;
  if (L < 128) {
    Max = (255.0 - S1) / 127.0 * (float)L;
    Min = S1 / 127.0 * (float)L;
  }
  else {
    Min = 255.0 - (255.0 - S1) * (255.0 - (float)L) / 127.0;
    Max = 255.0 - S1 * (255.0 - (float)L) / 127.0;
  }

  for (i = 0; i < 3; i++) {
    if (i == 0)
      v = (H + 85) % 256;
    else if (i == 1)
      v = H;
    else
      v = (H + 170) % 256;

    if (v <= 42)
      C[i] = (int)( (Max - Min) * (float)v / 42.0 + Min );
    else if (v <= 127)
      C[i] = (int)Max;
    else if (v <= 170)
      C[i] = (int)( (Min - Max) * ((float)v - 127.0) / 43.0 + Max );
    else
      C[i] = (int)Min;
  }
  *R = C[0];
  *G = C[1];
  *B = C[2];
  return 0;
} 

/*=============================================================================*
 *  ���� ���� ���� �б�
 *
 *      map : inp:������ ����
 *      nx  : out:�������� �������� (km)
 *      ny  : out:���Ϲ��� �������� (km)
 *      sx  : out:�������� ������ġ (km)
 *      sy  : out:���Ϲ��� ������ġ (km)
 *=============================================================================*/
int grid_map_inf(char *map, int *nx, int *ny, int *sx, int *sy)
{
  FILE  *fp;
  char  buf[1024], map_list[8], value[16];

  fp = fopen(MAP_INI_FILE,"r");
  if (fp == NULL) exit(-1);

  while (fgets(buf,1024,fp)) {
    if (buf[0] == '#') continue;
    getword(map_list, buf, ':');

    if ( !strcmp(map, map_list) ) {
      getword(value, buf, ':');  *nx = atoi(value);
      getword(value, buf, ':');  *ny = atoi(value);
      getword(value, buf, ':');  *sx = atoi(value);
      getword(value, buf, ':');  *sy = atoi(value);
      break;
    }
  }
  fclose(fp);
  return 0;
}

/*******************************************************************************
 *
 *  �ڷᰡ �̻��� �ִ� ���, ���� �̹��� ���
 *
 *******************************************************************************/
int err_img(int err)
{
  gdImagePtr im;
  char  text[120], tmp[120];
  int   YY, MM, DD, HH, MI;
  int   color_lvl[16];
  int   x, y, i, j, k, n;

  // 1. �̹��� ���� ����
  var.NI = var.size;
  var.NJ = var.NI;
  var.GI = var.NI;
  if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + TITLE_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_lvl[0] = gdImageColorAllocate(im, 240, 240, 240);   // ����
  color_lvl[1] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[0]);

  // 3. ���� �޽���
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(text, "TIME = %04d.%02d.%02d.%02d:%02d / err = %d", YY, MM, DD, HH, MI, err);
  gdImageString(im, gdFontLarge, 50, 50, text, color_lvl[1]);

  sprintf(text, "SAT = %s / RDR = %s", var.sat, var.rdr);
  gdImageString(im, gdFontLarge, 50, 70, text, color_lvl[1]);

  sprintf(text, "SIZE = %dpx", var.size);
  gdImageString(im, gdFontLarge, 50, 110, text, color_lvl[1]);

  if (err == 2)
    sprintf(text, "FILE = %s (file is not found)", var.fname);
  else
    sprintf(text, "FILE = %s", var.fname);
  gdImageString(im, gdFontLarge, 50, 130, text, color_lvl[1]);

  // 4. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);

  return 0;
}
