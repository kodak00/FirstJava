(function() {

    var db = {   	
        loadData: function(filter) {
            return $.ajax({
                type: "GET",
                url: "/cmmn/typhoonListGET.do",
                data: filter
            });
        },

        insertItem: function(insertingClient) {
            this.clients.push(insertingClient);
        },

        updateItem: function(updatingClient) { },

        deleteItem: function(deletingClient) {
            var clientIndex = $.inArray(deletingClient, this.clients);
            this.clients.splice(clientIndex, 1);
        }

    };

    window.db = db;
    
    db.clients = [
                  {
                      "Name": "Otto Clay",
                      "Age": 61,
                      "Country": 6,
                      "Address": "Ap #897-1459 Quam Avenue",
                      "Married": false
                  }
     ];

}());