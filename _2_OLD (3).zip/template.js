var map;
var lay;
//oskim 20190623 , 20190723
var source, source2, sourceArrow, sourceArrowOutline, sourceDash, sourceIconHigh, sourceIconLow;
var vector, vector2, vectorArrow, vectorArrowOutline, vectorDash, vectorIconHigh, vectorIconLow;
var lineStyleCode = 0;	//0:직선, 1:Dash
var selectedType = "None";

Proj4js.defs['EPSG:222222'] = "+proj=lcc +lat_1=30 +lat_2=60 +lat_0=0 +lon_0=126 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs";
var EPSG_222222 = new Proj4js.Proj('EPSG:222222');
var EPSG_4326 = new Proj4js.Proj('EPSG:4326');
var geoServerUrl = //'http://172.20.134.153:8030/geoserver/NECIS/wms';
	"http://172.20.134.146:8030/geoserver/NECIS/wms";
var format = 'image/png';

$(document).ready( function( evt ){
	
    // if this is just a coverage or a group of them, disable a few items,
    // and default to jpeg format
    var bounds = [-165165.88377218082, 4018295.8385748114,
                  552905.60080929, 5124990.831170289];

    var supportsFiltering = true;
    if (!supportsFiltering) {
      document.getElementById('filterType').disabled = true;
      document.getElementById('filter').disabled = true;
      document.getElementById('updateFilterButton').disabled = true;
      document.getElementById('resetFilterButton').disabled = true;
    }
    
    var projection = new ol.proj.Projection({
        code: 'EPSG:222222',
        units: 'm',
        axisOrientation: 'neu',
        global: false,
        getPointResolution: function(r) { return r; }
    });
    
    var scaleLineControl = new ol.control.ScaleLine({
    	units: 'metric',
    });
        
    //oskim 20190623
    var styleFunctionArrow = function(feature) {
        var geometry = feature.getGeometry();
        var styles = [
          // linestring
          new ol.style.Style({
            stroke: new ol.style.Stroke({
            	color: 'red',
            	width: 3
            })
          })
        ];

        geometry.forEachSegment(function(start, end) {
          var dx = end[0] - start[0];
          var dy = end[1] - start[1];
          var rotation = Math.atan2(dy, dx);
          // arrows
          styles.push(new ol.style.Style({
            geometry: new ol.geom.Point(end),
            image: new ol.style.Icon({
              src: '/images/us/img/arrow.png',
              anchor: [0.75, 0.5],
              rotateWithView: true,
              rotation: -rotation
            })
          }));
        });

        return styles;
    };
      
    //oskim 20190723
    var styleFunctionArrowOutline = function(feature) {
        var geometry = feature.getGeometry();
        var styles = [
          // linestring
          new ol.style.Style({
            stroke: new ol.style.Stroke({
            	color: [255,0,0,0],	//R,G,B,A
            	width: 3
            })
          })
        ];

        geometry.forEachSegment(function(start, end) {
          var dx = end[0] - start[0];
          var dy = end[1] - start[1];
          var rotation = Math.atan2(dy, dx);
          // arrows
          styles.push(new ol.style.Style({
            geometry: new ol.geom.Point(end),
            image: new ol.style.Icon({
              src: '/images/us/img/arrow-outline.png',
              anchor: [0.75, 0.5],
              rotateWithView: true,
              rotation: -rotation
            })
          }));
        });

        return styles;
    };
    
    var styleDash = new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: 'blue',
            width: 3,
            lineDash: [4,8]
          })
        });
    
    var styleDefault = new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: 'red',
            width: 3
          })
        });
    
    //oskim 20190723
    var styleIconLow = new ol.style.Style({
        image: new ol.style.Icon(/** @type {olx.style.IconOptions} */({
            anchor: [0,0],
            anchorXUnits: 'fraction',
            anchorYUnits: 'pixels',
            src: '/images/us/img/low.png'
        }))
    });
    
    var styleIconHigh = new ol.style.Style({
        image: new ol.style.Icon(/** @type {olx.style.IconOptions} */({
            anchor: [0,0],
            anchorXUnits: 'fraction',
            anchorYUnits: 'pixels',
            src: '/images/us/img/high.png'
        }))
    });    
    
    var iconFeature = new ol.Feature({
        geometry: new ol.geom.Point([0, 0]),
        name: 'ICON-HIGHLOW',
        population: 4000,
        rainfall: 500
    });    
    
    /* 지도위에 마우스로 도형을 생성하기 위한 레이어 */
    source = new ol.source.Vector({ wrapX: false });	    
    vector = new ol.layer.Vector({
        source: source,
        style: styleDefault	//oskim 20190623 ,
    });
    
    source2 = new ol.source.Vector({ wrapX: false });	
    vector2 = new ol.layer.Vector({
        source: source2,
        style: styleDefault	//oskim 20190623 ,
    });
    
    sourceDash = new ol.source.Vector({ wrapX: false });	
    vectorDash = new ol.layer.Vector({
        source: sourceDash,
        style: styleDash
    });

    sourceArrow = new ol.source.Vector({ wrapX: false });	
    vectorArrow = new ol.layer.Vector({
        source: sourceArrow,
        style: styleFunctionArrow
    });
    
    //oskim 20190723
    sourceArrowOutline = new ol.source.Vector({ wrapX: false });	
    vectorArrowOutline = new ol.layer.Vector({
        source: sourceArrowOutline,
        style: styleFunctionArrowOutline
    });
    
    sourceIconHigh = new ol.source.Vector({ features: [iconFeature] });
    vectorIconHigh = new ol.layer.Vector({
        source: sourceIconHigh,
        style: styleIconHigh
    });
    
    sourceIconLow = new ol.source.Vector({ features: [iconFeature] });
    vectorIconLow = new ol.layer.Vector({
        source: sourceIconLow,
        style: styleIconLow
    });
    
    
    map = new ol.Map({
      // 기본 이벤트 제어를 위한 바인딩
      interactions: [
                     //doubleClickEvent,
                     wheelZoomEvent,
                     dragPanEvent,
                     dragZoomEvent
      ],
      // 축적 표시를 위한 GIS컨트롤 호출
      controls: [ 
                  scaleLineControl 
      ],
      // GIS지도를 표시할 div태그 id
      target: 'map',
      // GIS지도상에 올라가는 초기 레이어
      layers: [
		baseMap,
		koreaLay,
		stlLay,
		emdSidoLay,
		emdSidoLabelLay,
		emdSigunguLay,
		emdSigunguLabelLay,
		emdDongLay,
		emdDongLabelLay,
		sriLay,
		roadLay,
		expressLay,
		generalLay,
		localLay,
		riverLay,
		riverAreaLay,
		gidLayer,
		gid1kLayer,
		cgiImageLayer[0],
		cgiImageLayer[1],
		cgiImageLayer[2],
		cgiImageLayer[3],
		drawCrossLayer,
		vector,
		vector2,
		vectorDash,
		vectorArrow,		//oskim 20190623
		vectorArrowOutline,	//oskim 20190723
		vectorIconHigh,		//oskim 20190723
		vectorIconLow		//oskim 20190723
      ],
      // 뷰 영역 설정
      view: new ol.View({
      	projection: projection,
      	zoom: 7,
      	minZoom: 4,
        maxZoom: 20
      })
    });
    
   
    
	// 메뉴가 사이트인 경우 사이트지점 이동 및 레벨 변경
	if($("#tabType").val() == "site") {
 		var lonlat = $(":radio[name='site']:checked").attr("title").split("_");
 		distMoveZoom(lonlat[0], lonlat[1], 520); 
 	}else{
 		var pType = $("input[name='P_TYPE1']:checked").val();
 		var lonlat = CGISIZE[pType].split(",");
 		distMoveZoom( Number(lonlat[0]),  Number(lonlat[1]),  Number(lonlat[2])); 
 	}
   
	// 초기 메뉴에 따른 옵션 불러오기
    for(var i=0; i<$("input[name=top]").length; i++) {
		var id = $("input[name=P_TYPE"+(i+1)+"]:checked").attr("id");
		var cno = $("input[name=P_TYPE"+(i+1)+"]:checked").attr("onchange");
		cno = String(cno).split(",")[0];
		cno = cno.split("(")[1];
		getMenuList(cno, id, 1);
	}
    
    // 좌표 출력
    map.on('pointermove',function(evt){
    	// 위경도 표출
		var extent = new Proj4js.Point(evt.coordinate);
		Proj4js.transform(EPSG_222222, EPSG_4326, extent);
		var latlon = " " + extent.y.toFixed(4) + ", " + extent.x.toFixed(4) + " ";
		$("#coordTxt").html(latlon);
		
		//고도 표출(사이트)
		if($("#altitudeTxt").length > 0){
			
			/*
			 * 위경도
			 * 거리 구하기 (km)
			 * */		
			//oskim 20180222, 20180724,  start -블럭 이동, 방위각 계산을 위해 , 다시 이동
			var lonlat = $("input[name='site']:checked").attr("title").split("_");
			var lat1 = lonlat[0];
			var lon1 = lonlat[1];
			
			var lat2 = extent.y.toFixed(4);
			var lon2 = extent.x.toFixed(4);
			
			var azimuth = calAzimuth(lon1,lat1,lon2,lat2);	
			var distance = cfGetDistance([lon1,lat1,lon2,lat2], 'EPSG:4326')	/ 1000;
			
			distance = Math.floor(distance*10)/10.0;	//소수 첫째자리 처리
			
			$("#dist_azim").text(distance + " / " + azimuth);
			//oskim 20180222 end
			
			var theta = lon1 - lon2;
	        var dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
	        dist = Math.acos(dist);
	        dist = rad2deg(dist);
	        dist = dist * 60 * 1.1515;
	        dist = dist * 1.609344;
			
			/*
			 * 고도 구하기
			 * h = ((double)RHeight/1000) + ke_a * ((cos(Elev) / cos( (Elev) + 평면거리 / ke_a))-1);
			 * h : 고도( km -> 100m단위 )
			 * Rheight : 레이더 고도 고정
			 * ke_a : 4. * 6371.1 / 3.; //[km]
			 * Elev : 고도각 라디안 ( elev * 3.14f / 180; )
			 *  
			 */
			
	        $("#altitudeTxt").text('');
	        
			//oskim 20180312
			var ptype = $("input[name='P_TYPE1']:checked").val();                
			var siteName = $("input[name='site']:checked").val();		
			if( $("#sweep_no_11 option:selected").val() != undefined || ptype == "SITE_DEP2_480KM" || ptype == "SITE_DEP1_PPI_LIVE" ){	//oskim 2018022, 20180312
				
				var rHeight = 0;	// 사이트 고도, oskim 20180907, 20190320 update
				switch(siteName) {
				case  "DJK":		rHeight = 132;		break;		// 덕적도	//oskim 20190402
				case  "SRI":		rHeight = 433;		break;		// 수리산
				case  "MIL":		rHeight = 291;		break;		// 망일산
				case  "PSN":		rHeight = 549;		break;		// 구덕산
				case  "KWK":		rHeight = 641;		break;		// 관악산
				case  "RKSG":		rHeight = 481;		break;		// 용인(미)
				case  "RKJK":		rHeight = 24;		break;		// 군산
				case  "KAR":		rHeight = 435;		break;		// 항우연
				case  "JWN":		rHeight = 117;		break;		// 중원
				case  "WNJ":		rHeight = 120;		break;		// 원주
				case  "YCN":		rHeight = 125;		break;		// 예천
				case  "SWN":		rHeight = 48;		break;		// 수원
				case  "SAN":		rHeight = 45;		break;		// 서산
				case  "SCN":		rHeight = 56;		break;		// 사천
				case  "TAG":		rHeight = 119;		break;		// 대구
				case  "KWJ":		rHeight = 67;		break;		// 광주
				case  "KAN":		rHeight = 27;		break;		// 강릉(A)
				case  "IMJ":		rHeight = 120;		break;		// 임진강
				case  "SBS":		rHeight = 1408;		break;		// 소백산
				case  "SDS":		rHeight = 922;		break;		// 서대산
				case  "BSL":		rHeight = 1085;		break;		// 비슬산
				case  "MHS":		rHeight = 958;		break;		// 모후산
				case  "GRS":		rHeight = 1055;		break;		// 가리산
				case  "JNI":		rHeight = 497;		break;		// 진도
				case  "IIA":		rHeight = 142;		break;		// 인천공항
				case  "YIT":		rHeight = 473;		break;		// 용인(테)
				case  "KSN":		rHeight = 231;		break;		// 오성산
				case  "SSP":		rHeight = 68;		break;		// 성산
				case  "BRI":		rHeight = 185;		break;		// 백령도
				case  "MYN":		rHeight = 1136;		break;		// 면봉산
				case  "GSN":		rHeight = 103;		break;		// 고산
				case  "GDK":		rHeight = 1066;		break;		// 광덕산
				case  "GNG":		rHeight = 99;		break;		// 강릉
				default:			rHeight = 0;		break;
				}
				
				var elev = 0; //oskim 20180222
				if($("#sweep_no_11 option:selected").val() != undefined)
				{
					elev = $("#sweep_no_11 option:selected").text();				
				}
				else
				{
					elev = $("#siteElevationZero").val();	//oskim 20180312				
				}
				
			    var RHeight = rHeight; //고정 
			    var ke_a = 4 * 6371.1 / 3;
				var Elev = deg2rad(elev);
			    var h = (RHeight/1000) + ke_a * ((Math.cos(Elev) / Math.cos( (Elev) + dist / ke_a))-1);
			    h = Math.floor(h*1000)/1000.0;	//oskim 20180209 , 20180222
			    
			    $("#altitudeTxt").text(h);				
			}		
		}
		
		// 강도표출
		if($("#dbz_val").val() == "on") {
			
			var mPixel = evt.pixel;
			
			//var dbzNUm = dbzVal[mPixel[0]][mPixel[1]];
			
			var dbzNUm = dbzVal[mPixel[1]][mPixel[0]];
			
            //oskim 20180724 ,20190319 
            if(dbzNUm == -9999 || dbzNUm == -9998)
                $("#dbzNum").text("NONE");
            else if($("#tabType").val() == "rainfall" && dbzNUm < 0)
                $("#dbzNum").text("0");
            else
                $("#dbzNum").text(Math.floor(dbzNUm*100)/100); 			
		}
	});
    
    // 줌 변동 이벤트
    map.getView().on('change:resolution', function(evt) { // 축적의 변동이 있으면
	      var resolution = evt.target.get('resolution');
	      var units = map.getView().getProjection().getUnits();
	      var dpi = 25.4 / 0.28;
	      var mpu = ol.proj.METERS_PER_UNIT[units];
	      /*var scale = resolution * mpu * 39.37 * dpi;
	      if (scale >= 9500 && scale <= 950000) {
	        scale = Math.round(scale / 1000) + "K";
	      } else if (scale >= 950000) {
	        scale = Math.round(scale / 1000000) + "M";
	      } else {
	        scale = Math.round(scale);
	      }
	      document.getElementById('scale').innerHTML = " 1 : " + scale;*/
	      
	      // 축적 변동시 지도 줌레벨도 함께 변경
	      var zoom = map.getView().getZoom();
	      document.getElementById('lvlTxt').innerHTML = "" + zoom;
	      
	      // 줌레벨 슬라이더 변경
	      $("#flat-slider-vertical-1").slider("value", zoom);
	      
	      /*if($("#fore_guide1").prop("checked") || $("#contour_disp1").prop("checked")){
	  		cfSetMapDragActivity(false); //드래그 비활성화
	  	  }*/
	  	
	      //oskim 20171220 줌인/아웃, 드래그시 강도표출 off!
	  	  dbzTxt_off();
	  	  
	  	  // AWS 표출
	      visibleAWS();
	  	  
	      // 행정구역 줌 레벨별 표출 레이어 변경
	      if($("#grp-chk").is(":checked")){
	    	  if($("#emd").is(":checked")){ // 경계+명칭
	    		  cfOneLayerVisibleOnOff(ObjectIndex.EML, true);
	    		  cfOneLayerVisibleOnOff(ObjectIndex.EMD, false);
	    	  }else if($("#txt").is(":checked")){//경계
	    		  cfOneLayerVisibleOnOff(ObjectIndex.EML, false);
	    		  cfOneLayerVisibleOnOff(ObjectIndex.EMD, true);	    		    
	    	  }
	      }
			  
	      // 위경도 줌 레벨별 표출 레이어 변경
	      if($("#gid").is(":checked")){
	    	  cfOneLayerVisibleOnOff(ObjectIndex.GID, true);
	      }
	      
	      echoLoad(getDataConversion());
	});
    
    
    // AWS 마우스 오버 이벤트 바인딩
	//map.on("pointermove", awsOverEvent);	//oskim 20190116 , 풍선도움말 전체 끄기
	
	// 지도 이동시 
	map.on("moveend", function(e){
		echoLoad(getDataConversion());
	});
	
 	// 마우스 우클릭
 	map.getViewport().addEventListener('contextmenu', function(evt){
 		evt.preventDefault();
 		if (location.pathname != "/site/site.do") { // 메뉴가 사이트인 경우 예외 처리
 			var extent = new Proj4js.Point(map.getCoordinateFromPixel([evt.layerX, evt.layerY]));
 			Proj4js.transform(EPSG_222222, EPSG_4326, extent);
 			loadSiteCgi(extent.y,extent.x);
 		}
 	});
 	
 	
    // 최초 로딩시 AWS지점 로드
	onPoint("AWS");
	
    var zoom = map.getView().getZoom();
    document.getElementById('lvlTxt').innerHTML = "" + zoom;
    
    // GIS-그리기 에코위에 올라오도록
	vector.setZIndex(ObjectIndex.DRAW);
	vector2.setZIndex(ObjectIndex.DRAW);
	//oskim 20190623
	vectorDash.setZIndex(ObjectIndex.DRAW);
	vectorArrow.setZIndex(ObjectIndex.DRAW);
	vectorArrowOutline.setZIndex(ObjectIndex.DRAW);
	//oskim 20190723
	vectorIconHigh.setZIndex(ObjectIndex.DRAW);
	vectorIconLow.setZIndex(ObjectIndex.DRAW);
	
	if(!$("#rod-chk").is(":checked")){
		$("#express").attr('disabled',true);
		$("#general").attr('disabled',true);
		$("#local").attr('disabled',true);
	}
	
	if(!$("#riv-chk").is(":checked")){
		$("#nationRiv").attr('disabled',true);
		$("#localRiv").attr('disabled',true);
	}
	
});

function deg2rad(deg){
	return (deg * Math.PI / 180);
}

function rad2deg(rad){
	return (rad * 180 / Math.PI);
}

//oskim 20180108 dbzTxt 함수 작성
function dbzTxt_off() {
	if($("#dbz_toggle").hasClass("cross-on")) {
		$("#dbz_val").val("off");
		$("#dbz_toggle").attr("class", "cross-off");
		$("#dbz_toggle").children("button").addClass("btn-default");
		$("#dbz_toggle").children("button").removeClass("btn-warning");
		$("#dbzTxt").hide();
	}	
}

//oskim 20180222
function calAzimuth(x1, y1, x2, y2){
	/*
	var deltaX = x2 - x1;
	var deltaY = y2 - y1;	
	var azimuth = Math.atan2(deltaY,deltaX) - Math.PI / 2 ;
	
	azimuth = rad2deg(azimuth);
	*/
	
	//oskim 20190117 , 방위각 오류 수정
	var azimuth = getBearing(x1, y1, x2, y2);
	
	if(azimuth < 0)
		azimuth = azimuth + 360;
	
	return Math.round(azimuth);	
}

//oskim 20190623
function setLineStyle(styleCode){
	lineStyleCode = styleCode;	
	drawing(selectedType);	//다시 설정해 주어야 함
}
