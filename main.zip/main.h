#ifndef MAIN_H
#define MAIN_H

/* ================================================================================ */
// DEFINE

#define COMP_ORIGIN_LON             126
#define COMP_ORIGIN_LAT             38

#define COMP_CJ3_XO                 354
#define COMP_CJ3_YO                 755
#define COMP_CJ3_XDIM               751
#define COMP_CJ3_YDIM               1101

#define COMP_2017_CJ3_XO            404
#define COMP_2017_CJ3_YO            755

//#define COMP_2017_CJ3_XDIM          801
//#define COMP_2017_CJ3_YDIM          1151
#define COMP_2017_CJ3_XDIM          951
#define COMP_2017_CJ3_YDIM          1101

#define COMP_PREV_CJ3_YDIM          801
#define COMP_RL_LON                 136.499435
#define COMP_RL_LAT                 17.259367

//oskim 20190529 ,
#define COMP_CJ3_OTH_XO             1521
#define COMP_CJ3_OTH_YO             1121
#define COMP_CJ3_OTH_XDIM           3521
#define COMP_CJ3_OTH_YDIM           3521

#define FILE_FORMAT_CJ3_OTH         "/C4N2_DATA/RDR/CMP/%%Y%%m/%%d/RDR_CMP_OTH_%%Y%%m%%d%%H%%M.bin.gz"

/*------------------------------------------------------------------------------------------------------*/
///cj3 - 240km & 480km HDF5

#define FILE_FORMAT_HDF5_CJ3_240KM  "/DATA/OUTPUT/BIN/CEAH/%%Y%%m/%%d/RDR_CFQSU_PP24_%%Y%%m%%d%%H%%M.h5"
#define FILE_FORMAT_HDF5_CJ3_480KM  "/DATA/OUTPUT/BIN/CEAH/%%Y%%m/%%d/RDR_CNQSU_PP48_%%Y%%m%%d%%H%%M.h5"

/*----------------------------------------------------------------------------------*/
//cj3 - 240km & 480km BIN

#define FILE_FORMAT_CJ3_240KM       "/DATA/OUTPUT/BIN/CKCJ/%%Y%%m/%%d/RDR_COQSU_PP24_%%Y%%m%%d%%H%%M.bin.gz"
#define FILE_FORMAT_CJ3_480KM       "/DATA/OUTPUT/BIN/CKCJ/%%Y%%m/%%d/RDR_CNQSU_PP48_%%Y%%m%%d%%H%%M.bin.gz"

/* ================================================================================ */
// FUNCTION PROTO


/* ================================================================================ */

extern st_Option   g_option;
extern float**     g_pImgData;
extern int         nPtypeFlag;
extern int         nFileTypeFlag;

#endif /* MAIN_H */
