/*******************************************************************************
**
**  ���� ���� ���� ǥ��
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2014.8.21)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iconv.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include <gd.h>
#include <gdfontt.h>
#include <gdfonts.h>
#include <gdfontmb.h>
#include <gdfontl.h>
#include <gdfontg.h>

#include "cgiutil.h"
#include "nrutil.h"
#include "stn_inf.h"
#include "map_ini.h"
#include "url_io.h"

#define  DEGRAD   3.1415927/180.0
#define  RADDEG   180.0/3.1415927

#define  LGT_DIR  "/DATA/LGT/KMA"
#define  MAP_INI_FILE  "/home/rdr/REF/MAP/map.ini"

#define  LEG_pixel   35     // ����ǥ�ÿ���
#define  TITLE_pixel 20     // ����ǥ�ÿ���

// ���׿��� ����
#define  DFS_NX   149   // ���������� �糡���� ���Ե� (5km����)
#define  DFS_NY   253
#define  DFS_SX   43    // 5km �������� �糡���� ���Ե�
#define  DFS_SY   136

// ����� �ѱ�TTF
char *fontttf = "/usr/share/fonts/korean/TrueType/gulim.ttf";   

// ����� �Է� ����
struct INPUT_VAR {
  char  system[8];    // NX1 (������ ����)
  int   seq;          // ���ؽð� SEQ(��)
  char  map[16];      // ����� �����ڵ�
  float grid;         // ����ũ��(km)
  int   itv;          // ǥ��ð�����(��), �⺻:30��
  int   zoom_level;   // Ȯ��Ƚ��
  int   zoom_rate;    // Ȯ�����
  char  zoom_x[16];   // X���� Ȯ��
  char  zoom_y[16];   // Y���� Ȯ��

  // ȭ��ǥ���
  int   size;         // �̹���ũ��(�ȼ�) : NI�� �ش�
  int   legend;       // ����ǥ��(1) ����
  int   sms;          // ��Ȱȭ ����

  // ����� �ڷ�
  int   NX, NY;       // ���ڼ�, ���� ���������� ������ 1�� ���ϸ� ��
  int   NI, NJ;       // �ڷ�ǥ���̹��� ����(�ȼ�)
  int   GI, GJ;       // ��ü �̹��� ����(�ȼ�)
  int   num_color;    // �����
};

struct INPUT_VAR var;           // ����� �Է� ����

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main()
{
  // 1. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(20);

  printf("HTTP/1.0 200 OK\n");
  printf("Server: Netscape-Enterprise/3.0\n");
  //printf("Content-type: text/plain\n\n");

  // 2. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    printf("Content-type: text/plain\n\n");
    printf("# input variable error<p>\n");
    return -1;
  }

  // 5. �̹��� ���� �� ����
  lgt_dst_img();

  alarm(0);
  return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
  char *qs;
  char tmp[256], item[32], value[32], tm[30];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, i;

  // 1. ���� �ʱⰪ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "0");        // ����ð�
  strcpy(var.map, "D3");  // D3����
  var.zoom_level = 0;     // ��ü����
  var.zoom_rate = 2;      // 2�� Ȯ�밡 �⺻

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if ( !strcmp(item,"system"))   strcpy(var.system, value);
    else if ( !strcmp(item,"map")) strcpy(var.map, value);
    else if ( !strcmp(item,"tm"))  strcpy(tm, value);
    else if ( !strcmp(item,"sms")) var.sms = atoi(value);
    else if ( !strcmp(item,"itv")) var.itv = atoi(value);
    else if ( !strcmp(item,"zoom_level")) var.zoom_level = atoi(value);
    else if ( !strcmp(item,"zoom_rate"))  var.zoom_rate = atoi(value);
    else if ( !strcmp(item,"zoom_x")) strcpy(var.zoom_x, value);
    else if ( !strcmp(item,"zoom_y")) strcpy(var.zoom_y, value);
    else if ( !strcmp(item,"size")) var.size = atoi(value);
    else if ( !strcmp(item,"legend")) var.legend = atoi(value);
  }
  if (var.grid < 0.001) var.grid = 2.0;
  if (var.itv < 0.001) var.itv = 30;

  // 3. ����ð� �� ���� �����ð� ����
  get_time(&iYY, &iMM, &iDD, &iHH, &iMI, &iSS);
  iseq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm') - 3;
  seq2time(iseq, &iYY, &iMM, &iDD, &iHH, &iMI, 'm', 'n');

  // 4. ��û�ð� ����
  if (strlen(tm) >= 10) {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
  }
  var.seq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  return 0;
}

/*******************************************************************************
 *
 *  ���� ���� �̹��� ���� �� ǥ��
 *
 *******************************************************************************/
int lgt_dst_img()
{
  gdImagePtr im;
  struct lamc_parameter map;
  int   color_lvl[256];
  float data_lvl[256];
  float ox = 0.0, oy = 0.0, zm = 1.0;
  int   GX, GY, SX, SY;
  int   zx, zy, i;

  // 1. �̹��� ���� ����
  grid_map_inf(var.map, &GX, &GY, &SX, &SY);
  var.NX = (int)(GX/var.grid);   var.NY = (int)(GY/var.grid);
  var.NI = var.size;
  var.NJ = (int)((float)(var.NY)/(float)(var.NX)*var.NI);
  var.GI = var.NI;
  if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + TITLE_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_table(im, color_lvl, data_lvl);
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[240]);

  // 3. ���� �����ڷ� �׸���
  for (i = 0; i < 7; i++) {
    zx = var.zoom_x[i]-'0';        zy = var.zoom_y[i]-'0';
    if (zx == 0 || zy == 0) break;
    ox += (var.NX/8.0*(zx-1)/zm);  oy += (var.NY/8.0*(zy-1)/zm);
    zm *= var.zoom_rate;
  }
  zm *= ((float)(var.NI)/(float)(var.NX));

  map.Re    = 6371.00877;
  map.grid  = var.grid/zm;
  map.slat1 = 30.0;    map.slat2 = 60.0;
  map.olon  = 126.0;   map.olat  = 38.0;
  map.xo = (float)SX/map.grid - ox*zm;
  map.yo = (float)SY/map.grid - oy*zm;
  map.first = 0;

  lgt_str_disp(im, color_lvl, data_lvl, map);

  // 4. ���� �׸���
  if (var.zoom_level >= 2) map_disp(im, color_lvl[249], 1);
  map_disp(im, color_lvl[242], 4);

  // 6. ���� �׸�
  title_disp(im, color_lvl);

  // 7. ���� �׸���
  legend_disp(im, color_lvl, data_lvl);
  gdImageRectangle(im, 0, TITLE_pixel, var.NI-1, var.GJ-1, color_lvl[242]);

  // 8. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);
  return 0;
}

/*=============================================================================*
 *  ����ǥ
 *=============================================================================*/
int color_table(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  FILE  *fp;
  char  color_file[120];
  int   num_color;
  int   R, G, B;
  float v1;

  // 1. ��󺯼��� ����ǥ ���� ����
  strcpy(color_file,"/home/rdr/REF/COLOR/");
  strcat(color_file,"color_lgt_str.rgb");

  // 2. ����ǥ ���ϰ� ������ �б�
  var.num_color = num_color = 0;
  if ((fp = fopen(color_file, "r")) != NULL) {
    while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
      color_lvl[num_color] = gdImageColorAllocate(im, R, G, B);
      data_lvl[num_color] = v1;
      num_color++;
      if (num_color > 119) break;
    }
    fclose(fp);
  }
  else {
    num_color = -1;
  }
  var.num_color = num_color;

  // 3. ��Ÿ ����ǥ ����
  color_lvl[240] = gdImageColorAllocate(im, 220, 220, 220);   // ����1
  color_lvl[241] = gdImageColorAllocate(im, 255, 255, 255);   // ����2
  color_lvl[242] = gdImageColorAllocate(im, 30, 30, 30);      // ������
  color_lvl[243] = gdImageColorAllocate(im, 12, 28, 236);     // ����
  color_lvl[244] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  color_lvl[245] = gdImageColorAllocate(im, 240, 240, 240);
  color_lvl[246] = gdImageColorAllocate(im, 255, 0, 0);
  color_lvl[247] = gdImageColorAllocate(im, 0, 0, 255);
  color_lvl[248] = gdImageColorAllocate(im, 160, 160, 160);   // ����3
  color_lvl[249] = gdImageColorAllocate(im, 90, 90, 90);      // �ñ����

  return num_color;
}

/*=============================================================================*
 *  ���� ���� �ڷ� ǥ��
 *=============================================================================*/
int lgt_str_disp(gdImagePtr im, int color_lvl[], float data_lvl[], struct lamc_parameter map)
{
  FILE  *fp;
  char  fname[120], buf[1000], tmp[100], tp[8], gc, wkt[100];
  float x, y, lat, lon, ht, power, nsf, errd, f1, f2, f3, f5;
  int   id, mt, gcd, d4, nscan, t1;
  int   YY, MM, DD, HH, MI, SS, nsec, seq;
  int   YY1, MM1, DD1, HH1, MI1;
  int   YY2, MM2, DD2, HH2, MI2;
  int   nday, iseq, diff, ix, iy, color1, depth = 3;
  int   i, j, k, code;

  // 0. ����ó��
  if (var.num_color <= 0) {
    gdImageString(im, gdFontLarge, 100, 100, "No Color Level", color_lvl[244]);
    return -1;
  }

  // 1. ���� ������ �� Ȯ��
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  seq2time(var.seq-var.itv, &YY1, &MM1, &DD1, &HH1, &MI1, 'm', 'n');
  if (DD1 == DD) nday = 0;
  else           nday = 1;

  if (var.zoom_level > 0) depth = 4;
  if (var.zoom_level > 2) depth = 5;

  // 2. �ڷ� ������ ���������� �о ó��
  for (k = nday; k >= 0; k--) {
    seq2time(var.seq-k*24*60, &YY1, &MM1, &DD1, &HH1, &MI1, 'm', 'n');
    code = lgt_file(fname, YY1, MM1, DD1);
    if (code < 0) continue;
    if ((fp = fopen(fname, "r")) == NULL) continue;

    while (fgets(buf, 1024, fp) != NULL) {
      if (strstr(fname,"NX1")) {
        if (strlen(buf) < 80) continue;
        sscanf(buf, "%d %d-%d-%d %d:%d:%d.%d+%s %d %s %f %f %f %f %f %d %d",
               &id, &YY, &MM, &DD, &HH, &MI, &SS, &nsec, tmp, &nsf, wkt, &lon, &lat, &ht, &power, &errd, &gcd, &nscan);
        if (gcd != 1) continue;     // ��������(1)�� ǥ�� (2:��������)
        if (nscan < 3) continue;    // 3�� �̻� ������ ������ ��츸 ǥ��

        iseq = time2seq(YY, MM, DD, HH, MI, 'm');
        diff = var.seq - iseq;
      }
      else {
        nscan = 3;  // ���� ���� ���Ͱ� 3�� �̻��� ��츸 ǥ�� (�ֱ� ���˿��� ����. ���Ŵ� �׳� ǥ��)
        if (code == 0) {
          if (strlen(buf) > 80) {
            sscanf(buf, "%d/%d/%d %d:%d:%f %f %f %f %d %f %f %f %d %f %d %c",
              &MM, &DD, &YY, &HH, &MI, &SS, &lat, &lon, &power, &mt, &f1, &f2, &f3, &d4, &f5, &nscan, &gc);
          }
          else {
            sscanf(buf, "%d/%d/%d %d:%d:%f %f %f %f %d", &MM, &DD, &YY, &HH, &MI, &SS, &lat, &lon, &power, &mt);
            gc = 'G';
          }
        }
        else if (code == 1) {
          YY = YY1;  MM = MM1;  DD = DD1;
          sscanf(buf, "%d:%d:%f %f %f %f %d", &HH, &MI, &SS, &lat, &lon, &power, &mt);
          gc = 'G';
        }
        else if (code == 2) {
          sscanf(buf, "%d/%d/%d %d:%d:%f %f %f %f %d", &MM, &DD, &YY, &HH, &MI, &SS, &lat, &lon, &power, &mt);
          gc = 'G';
        }
        else if (code == 3) {
          getword(tmp,buf,' ');
          getword(tp, buf,' ');
          if (strcmp(tp,"FG") == 0) gc = 'G';
          else                      gc = 'C';

          getword(tmp,buf,'/');  MM = atoi(tmp);
          getword(tmp,buf,'/');  DD = atoi(tmp);
          getword(tmp,buf,' ');  YY = atoi(tmp) + 2000;
          getword(tmp,buf,':');  HH = atoi(tmp);
          getword(tmp,buf,':');  MI = atoi(tmp);
          getword(tmp,buf,'.');  SS = atoi(tmp);
          getword(tmp,buf,' ');  nsec = atoi(tmp);

          getword(tmp,buf,'=');  lat = atof(buf);
          getword(tmp,buf,'=');  lon = atof(buf);
          getword(tmp,buf,'=');  power = atof(buf);
        }
        if (gc != 'G' || nscan < 3) continue;

        if (YY < 80) YY += 2000;
        else if (YY <= 99) YY += 1900;

        iseq = time2seq(YY, MM, DD, HH, MI, 'm');
        if (code == 3) iseq += 9*60;
        diff = var.seq - iseq;
      }

      if (diff >= 0 && diff < var.itv) {
        for (j = 0; j < var.num_color; j++) {
          if (power < data_lvl[j]) {
            color1 = color_lvl[j];
            break;
          }
        }

        lamcproj_ellp(&lon, &lat, &x, &y, 0, &map);
        if (x > 2.0 && x < (float)(var.NI-2) && y > 2.0 && y < (float)(var.NJ-2)) {
          ix = (int)(x + 0.5);
          iy = var.GJ - (int)(y + 0.5);
          gdImageLine(im, ix-depth, iy, ix+depth, iy, color1);
          gdImageLine(im, ix, iy-depth, ix, iy+depth, color1);
        }
      }
      else if (diff < 0)
        break;
    }
    fclose(fp);
  }
  return 0;
}

/*=============================================================================*
 *  ���� ���ϸ��� ���� ���� (���û)
 *=============================================================================*/
int lgt_file(char *fname, int YY, int MM, int DD)
{
  struct stat st1, st2, st3;
  int    code = 0;

  if ((YY*100+MM)*100+DD >= 20150401) {
    sprintf(fname, "%s/%04d/LGT_KMA_NX1_%02d%02d%02d.asc", LGT_DIR, YY, YY, MM, DD);
    if (stat(fname, &st1) < 0)
      code = -3;
    else
      code = 0;
  }
  else {
    sprintf(fname, "%s/%04d/LGT_KMA_%02d%02d%02d.asc", LGT_DIR, YY, YY, MM, DD);
    if (stat(fname, &st1) < 0) {
      sprintf(fname, "%s/%04d/LGT_TDM_%04d%02d%02d.asc", LGT_DIR, YY, YY, MM, DD);
      if (stat(fname, &st2) < 0) {
        sprintf(fname, "%s/%04d/LGT_LVL_%04d%02d%02d.asc", LGT_DIR, YY, YY, MM, DD);
        if (stat(fname, &st3) < 0)
          code = -3;
        else
          code = 2;
      }
      else
        code = 1;
    }
    else if (st1.st_size < 10) {
      if (st1.st_size < 10)
        code = -2;
      else
        code = 0;
    }
  }
  return code;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int map_disp(gdImagePtr im, int color_map, int kind)
{
  FILE  *fp;
  char  fname[120];
  float zm = 1.0, xo = 0.0, yo = 0.0, x1, y1, x2, y2;
  int   zx, zy, mode;
  int   i, j, k, n;

  // 1. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    if (var.zoom_rate == 3) {
      for (i = 0; i < 2; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/9.0*(zx-1)/zm;
        yo += (float)(var.NY)/9.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
    else if (var.zoom_rate == 2) {
      for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/8.0*(zx-1)/zm;
        yo += (float)(var.NY)/8.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
  }

  // 2. �ؾȼ� ǥ��
  sprintf(fname, "/DATA/GIS/MAP/dat/AFS_%s_map%d.dat", var.map, kind);
  if ((fp = fopen(fname, "r")) != NULL) {
    while (fscanf(fp, "%d %d\n", &n, &mode) != EOF) {
      for (i = 0; i < n; i++) {
        fscanf(fp, "%f %f\n", &x2, &y2);
        x2 /= var.grid;
        y2 /= var.grid;

        if (var.zoom_level > 0) {
          x2 = zm*(x2-xo);
          y2 = zm*(y2-yo);
        }
        x2 *= ((float)(var.NI)/(float)(var.NX));
        y2 *= ((float)(var.NI)/(float)(var.NX));
        if (i > 0) {
          gdImageLine(im, (int)x1, var.GJ-(int)y1, (int)x2, var.GJ-(int)y2, color_map);
          if (kind == 4 && var.zoom_level >= 2) gdImageLine(im, (int)x1, var.GJ-(int)y1-1, (int)x2, var.GJ-(int)y2-1, color_map);
        }
        x1 = x2;
        y1 = y2;
      }
    }
    fclose(fp);
  }

  return 0;
}

/*=============================================================================*
 *  EUC-KR���ڿ��� UTF-8�� ��ȯ
 *=============================================================================*/
int euckr2utf(char *str, char *out)
{
    iconv_t convp;
    size_t  ileft, oleft;
    int     err, len = strlen(str);

    ileft = len;
    oleft = len * 2;

    convp = iconv_open("UTF-8", "euc-kr");
    err = iconv(convp, &str, &ileft, &out, &oleft);
    iconv_close(convp);

    return err;
}

/*=============================================================================*
 *  ���� ǥ��(�ѱ�ó��)
 *=============================================================================*/
int title_disp(gdImagePtr im, int color_lvl[])
{
  char   title[80], tm_fc_str[100], num_stn_str[10], tmp[50];
  char   title_utf[100], tm_fc_utf[100];
  double font_size = 11.5;
  int    brect[8];
  int    YY, MM, DD, HH, MI;
  int    x, y, i, k;

  // 1. ���񿵿��� ���� ó��
  gdImageFilledRectangle(im, 0, 0, var.GI, TITLE_pixel, color_lvl[241]);

  // 2. ������
  strcpy(title,"����(������)");

  for (i = 0; i < 100; i++)
    title_utf[i] = 0;
  euckr2utf(title, title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, font_size, 0.0, 5, (int)(font_size+5), title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, font_size, 0.0, 6, (int)(font_size+5), title_utf);

  // 3. �ð� ���ڿ�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(tm_fc_str, "%04d.%02d.%02d.%02d:%02d(%02d��)", YY, MM, DD, HH, MI, var.itv);

  for (i = 0; i < 100; i++)
    tm_fc_utf[i] = 0;
  euckr2utf(tm_fc_str, tm_fc_utf);
  gdImageStringFT(im, &brect[0], color_lvl[244], fontttf, font_size, 0.0, 125, (int)(font_size+5), tm_fc_utf);
  gdImageStringFT(im, &brect[0], color_lvl[244], fontttf, font_size, 0.0, 126, (int)(font_size+5), tm_fc_utf);

  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int legend_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  char   txt[20];
  float  dy = (float)(var.NJ)/(float)(var.num_color);
  int    YY, MM, DD, HH, MI;
  int    x, y, k;

  if (var.legend != 1) return 0;
  if (var.num_color <= 0) return -1;

  // 1. ���� ���� ǥ��
  for (k = 0; k < var.num_color; k++) {
    y = var.GJ - dy*k;
    gdImageFilledRectangle(im, var.NI, y-dy, var.NI+8, y, color_lvl[k]);
  }
  gdImageRectangle(im, var.NI-1, TITLE_pixel, var.NI+8, var.GJ-1, color_lvl[242]);

  // 2. ���ʰ� ǥ��
  gdImageFilledRectangle(im, var.NI+9, 0, var.GI-1, var.GJ, color_lvl[241]);
  for (k = 0; k < var.num_color; k++) {
    y = var.GJ - (k+1)*dy - 5;
    sprintf(txt, "%.0f", data_lvl[k]);
    gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
  }

  // 3. ���� ���� ǥ��
  strcpy(txt,"KA");
  x = var.NI + 3;
  gdImageString(im, gdFontSmall, x, 4, txt, color_lvl[244]);

  return 0;
}

/*=============================================================================*
 *  ���� ���� ���� �б�
 *
 *      map : inp:������ ����
 *      nx  : out:�������� �������� (km)
 *      ny  : out:���Ϲ��� �������� (km)
 *      sx  : out:�������� ������ġ (km)
 *      sy  : out:���Ϲ��� ������ġ (km)
 *=============================================================================*/
int grid_map_inf(char *map, int *nx, int *ny, int *sx, int *sy)
{
    FILE  *fp;
    char  buf[1024], map_list[8], value[16];

    fp = fopen(MAP_INI_FILE,"r");
    if (fp == NULL) exit(-1);

    while (fgets(buf,1024,fp)) {
        if (buf[0] == '#') continue;
        getword(map_list, buf, ':');

        if ( !strcmp(map, map_list) ) {
            getword(value, buf, ':');  *nx = atoi(value);
            getword(value, buf, ':');  *ny = atoi(value);
            getword(value, buf, ':');  *sx = atoi(value);
            getword(value, buf, ':');  *sy = atoi(value);
            break;
        }
    }
    fclose(fp);

    return 0;
}
