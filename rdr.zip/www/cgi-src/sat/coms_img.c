/*******************************************************************************
**
**  õ���� �������� ǥ��
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2014.8.27)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include <gd.h>
#include <gdfontt.h>
#include <gdfonts.h>
#include <gdfontmb.h>
#include <gdfontl.h>
#include <gdfontg.h>

#include "cgiutil.h"
#include "nrutil.h"
#include "aws_data.h"
#include "aws2_data.h"
#include "stn_inf.h"
#include "map_ini.h"
#include "url_io.h"

#define  DEGRAD   3.1415927/180.0
#define  RADDEG   180.0/3.1415927

#define  COMS_BIN_DIR   "/DATA/SAT/COMS/BIN"
#define  COMS_CONV_FILE "/rdr/REF/INI/coms_conv.csv"
#define  MAP_INI_FILE   "/rdr/REF/MAP/map.ini" // �������� ��������
#define  MAP_DIR        "/DATA/GIS/MAP/dat"    // ���������� �ִ� �������
#define  COLOR_SET_DIR  "/rdr/REF/COLOR/"      // ����ǥ ���� �ӽ������

// COMS���� (COMS_GRID ����)
#define  COMS_NX   1769
#define  COMS_NY   1559
#define  COMS_SX   850
#define  COMS_SY   1061
#define  COMS_GRID  5.0

// �̹��� ������ �Ϻ� �⺻��
#define  LEG_pixel   35     // ����ǥ�ÿ���
#define  TITLE_pixel 20     // ����ǥ�ÿ���

// ����� �ѱ�TTF
#define  FONTTTF  "/usr/share/fonts/korean/TrueType/gulim.ttf"

// ����� �Է� ����
struct INPUT_VAR {
  int   seq;          // ���ؽð� SEQ(��)
  char  obs[16];      // ���� ���� (��: ta)
  char  map[16];      // ����� �����ڵ�
  float grid;         // ����ũ��(km)
  int   zoom_level;   // Ȯ��Ƚ��
  int   zoom_rate;    // Ȯ�����
  char  zoom_x[16];   // X���� Ȯ��
  char  zoom_y[16];   // Y���� Ȯ��

  // ȭ��ǥ���
  int   size;         // �̹���ũ��(�ȼ�) : NI�� �ش�
  int   legend;       // ����ǥ��(1) ����
  int   sms;          // ��Ȱȭ ����

  // ����� �ڷ�
  int   NX, NY;       // ���ڼ�, ���� ���������� ������ 1�� ���ϸ� ��
  int   NI, NJ;       // �ڷ�ǥ���̹��� ����(�ȼ�)
  int   GI, GJ;       // ��ü �̹��� ����(�ȼ�)
  int   num_color;    // �����

  // ��������
  char  fname[120];   // ���ϸ�
  int   ox;           // ���� ���� �� ����ó�� ����
};

struct INPUT_VAR var;           // ����� �Է� ����
float  **g;                     // �����м����

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main()
{
  float km_px;
  int   num_sm, i;
  int   err = 0;

  // 1. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(20);

  printf("HTTP/1.0 200 OK\n");
  //printf("Content-type: text/plain\n\n");

  // 2. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    err = 1;
  }

  // 3. �ڷ� ����
  if (!strncmp(var.obs,"coms_ca",7) || !strcmp(var.obs,"coms_sky"))
    err = coms_ca_get();
  else
    err = coms_get();

  // 4. ���� ó��
  if (err > 0) {
    err_img(err);
    return 0;
  }

  // 4. ��Ȱȭ �� Ȯ��
  /*
  km_px = (float)(var.NX)*var.grid/(var.size*(var.zoom_level+1));
  if      (km_px <=  2) num_sm = 1;
  else if (km_px <=  4) num_sm = 2;
  else if (km_px <=  6) num_sm = 3;
  else if (km_px <=  8) num_sm = 4;
  else if (km_px <= 10) num_sm = 5;
  else if (km_px <= 12) num_sm = 6;
  else num_sm = 7;

  for (i = 0; i < num_sm; i++)
    grid_smooth(g, var.NX, var.NY, -90);
  */

  // 5. �̹��� ���� �� ����
  coms_img();

  // 7. �޸� �ݳ�
  free_matrix(g, 0, var.NY, 0, var.NX);

  alarm(0);
  return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
  char *qs;
  char tmp[256], item[32], value[32], tm[30], obs1[16];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, i;

  // 1. ���� �ʱⰪ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "0");        // ����ð�
  strcpy(var.map, "D3");  // D3����
  var.zoom_level = 0;     // ��ü����
  var.zoom_rate = 2;      // 2�� Ȯ�밡 �⺻

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"map")) strcpy(var.map, value);
    else if ( !strcmp(item,"tm"))  strcpy(tm, value);
    else if ( !strcmp(item,"obs")) strcpy(var.obs, value);
    else if ( !strcmp(item,"grid")) var.grid = atof(value);
    else if ( !strcmp(item,"sms")) var.sms = atoi(value);
    else if ( !strcmp(item,"zoom_level")) var.zoom_level = atoi(value);
    else if ( !strcmp(item,"zoom_rate"))  var.zoom_rate = atoi(value);
    else if ( !strcmp(item,"zoom_x")) strcpy(var.zoom_x, value);
    else if ( !strcmp(item,"zoom_y")) strcpy(var.zoom_y, value);
    else if ( !strcmp(item,"size")) var.size = atoi(value);
    else if ( !strcmp(item,"legend")) var.legend = atoi(value);
  }
  if (var.grid < 0.001) var.grid = 2.0;

  // 3. ����ð� �� ���� �����ð� ����
  get_time(&iYY, &iMM, &iDD, &iHH, &iMI, &iSS);
  iseq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm') - 6;
  seq2time(iseq, &iYY, &iMM, &iDD, &iHH, &iMI, 'm', 'n');

  // 4. ��û�ð� ����
  if (strlen(tm) >= 10) {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
  }
  var.seq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  var.seq = 15*(var.seq/15);

  // 5. ���� ���翩�� Ȯ��
  strcpy(obs1, var.obs);
  if (strstr(var.obs,"coms_d")) strcpy(var.obs,"coms_ir1");
  for (i = 0; i < 10; i++, var.seq -= 15) {
    if (coms_file() >= 0) break;
  }
  strcpy(var.obs, obs1);

  return 0;
}

/*******************************************************************************
 *
 *  COMS 1�ð�/3�ð� ��� � ����
 *
 *******************************************************************************/
int coms_ca_get()
{
  FILE   *fp;
  short  com1[COMS_NY+1][COMS_NX+1], com2[COMS_NY+1][COMS_NX+1], c1, c2;
  unsigned char buf[(COMS_NX+1)*2];
  char   obs1[16];
  float  cnv1[1024], cnv2[1024];
  float  z1, z2, data_rate, data_min;
  int    seq, seq_org, dtm, dtm_max, num_ca;
  int    dbz_max, data1, nskip;
  int    GX, GY, SX, SY;
  int    i, j, k, n, ii, jj, i1, i2, j1, j2;

  // 1. ������ ���� ���� �� �ʱ�ȭ
  grid_map_inf(var.map, &GX, &GY, &SX, &SY);
  var.NX = (int)(GX/var.grid);   var.NY = (int)(GY/var.grid);
  g = matrix(0, var.NY, 0, var.NX);
  for (j = 0; j <= var.NY; j++) {
    for (i = 0; i <= var.NX; i++)
      g[j][i] = -99.9;
  }
  var.ox = 0;

  // 2. 1�ð� �Ǵ� 3�ð� ��� � ���
  if      (!strcmp(var.obs,"coms_ca1")) dtm_max = 60;
  else if (!strcmp(var.obs,"coms_ca3")) dtm_max = 60*3;
  else if (!strcmp(var.obs,"coms_sky")) dtm_max = 60;
  else dtm_max = 15;

  seq_org = var.seq;

  for (num_ca = 0, dtm = 0; dtm < dtm_max; dtm += 15) {
    var.seq = seq_org - dtm;

    // 2.1. ���� ���� ���� Ȯ�� �� �ڷ� �б�
    if (coms_file() < 0) continue;
    num_ca++;

    fp = gzopen(var.fname, "rb");
    for (j = 0; j <= COMS_NY; j++) {
      j1 = COMS_NY - j;
      n = gzread(fp, buf, COMS_NX+1);
      for (i = 0; i <= COMS_NX; i++)
        com1[j1][i] = buf[i];
    }
    gzclose(fp);

    // 2.2. ��ȯ
    for (jj = 0, j = 0; j <= GY; j += var.grid, jj++) {
      j1 = (j + COMS_SY*COMS_GRID - SY)/COMS_GRID;
      if (j1 < 1 || j1 > COMS_NY-1) continue;

      for (ii = 0, i = 0; i <= GX; i += var.grid, ii++) {
        i1 = (i + COMS_SX*COMS_GRID - SX)/COMS_GRID;
        if (i1 < 1 || i1 > COMS_NX-1) continue;

        if (num_ca == 1)
          g[jj][ii] = com1[j1][i1]*0.1;
        else
          g[jj][ii] += com1[j1][i1]*0.1;
      }
    }
  }

  // 3. ��տ
  if (num_ca > 1) {
    for (j = 0; j <= var.NY; j++) {
      for (i = 0; i <= var.NX; i++)
        g[j][i] = (int)(g[j][i]/(float)num_ca + 0.5);
    }
  }
  var.seq = seq_org;
  if (num_ca > 0) var.ox = 1;
  return 0;
}

/*******************************************************************************
 *
 *  �ڷ� ���� ����
 *
 *******************************************************************************/
int coms_get()
{
  FILE   *fp;
  short  com1[COMS_NY+1][COMS_NX+1], com2[COMS_NY+1][COMS_NX+1], c1, c2;
  unsigned char buf[(COMS_NX+1)*2], *p1, b1;
  char   obs1[16];
  float  cnv1[1024], cnv2[1024];
  float  z1, z2, data_rate, data_min, v1;
  int    dbz_max, data1, nskip;
  int    GX, GY, SX, SY;
  int    i, j, k, n, ii, jj, i1, i2, j1, j2;

  // 1. ������ ���� ���� �� �ʱ�ȭ
  grid_map_inf(var.map, &GX, &GY, &SX, &SY);
  var.NX = (int)(GX/var.grid);   var.NY = (int)(GY/var.grid);
  g = matrix(0, var.NY, 0, var.NX);
  for (j = 0; j <= var.NY; j++) {
    for (i = 0; i <= var.NX; i++)
      g[j][i] = -99.9;
  }
  var.ox = 0;

  // 2. ���� ���� ���� Ȯ�� �� �ڷ� �б�
  strcpy(obs1, var.obs);
  if (strstr(var.obs,"d12") || strstr(var.obs,"d13") || strstr(var.obs,"d1w")) strcpy(var.obs, "coms_ir1");

  if (coms_file() < 0) return -1;
  if (coms_conv_read(cnv1) < 0) return -2;

  fp = gzopen(var.fname, "rb");
  if (!strcmp(var.obs, "coms_fog") || !strcmp(var.obs, "coms_ca") || !strcmp(var.obs, "coms_cld") || !strcmp(var.obs, "coms_ct")) {
    for (j = 0; j <= COMS_NY; j++) {
      j1 = COMS_NY - j;
      n = gzread(fp, buf, COMS_NX+1);
      for (i = 0; i <= COMS_NX; i++)
        com1[j1][i] = buf[i];
    }
  }
  else {
    for (j = 0; j <= COMS_NY; j++) {
      j1 = COMS_NY - j;
      n = gzread(fp, &com1[j1][0], (COMS_NX+1)*2);
      for (p1 = &com1[j1][0], i = 0; i < (COMS_NX+1)*2; i += 2, p1 += 2) {
        b1 = *p1;
        *p1 = *(p1+1);
        *(p1+1) = b1;
      }
    }
  }
  gzclose(fp);
  strcpy(var.obs, obs1);

  // 3. ���� ������ ���
  if (strstr(var.obs,"d12") || strstr(var.obs,"d13") || strstr(var.obs,"d1w")) {
    strcpy(obs1, var.obs);
    if      (strstr(var.obs,"d12")) strcpy(var.obs, "coms_ir2");
    else if (strstr(var.obs,"d13")) strcpy(var.obs, "coms_ir3");
    else if (strstr(var.obs,"d1w")) strcpy(var.obs, "coms_wvp");

    if (coms_file() < 0) return -1;
    if (coms_conv_read(cnv2) < 0) return -2;

    fp = gzopen(var.fname, "rb");
    for (j = 0; j <= COMS_NY; j++) {
      j1 = COMS_NY - j;
      n = gzread(fp, &com2[j1][0], (COMS_NX+1)*2);
      for (p1 = &com2[j1][0], i = 0; i < (COMS_NX+1)*2; i += 2, p1 += 2) {
        b1 = *p1;
        *p1 = *(p1+1);
        *(p1+1) = b1;
      }
    }
    gzclose(fp);
    strcpy(var.obs, obs1);
  }

  // 4. ��ȯ
  for (jj = 0, j = 0; j <= GY; j += var.grid, jj++) {
    j1 = (j + COMS_SY*COMS_GRID - SY)/COMS_GRID;
    if (j1 < 1 || j1 > COMS_NY-1) continue;

    for (ii = 0, i = 0; i <= GX; i += var.grid, ii++) {
      i1 = (i + COMS_SX*COMS_GRID - SX)/COMS_GRID;
      if (i1 < 1 || i1 > COMS_NX-1) continue;

      c1 = com1[j1][i1];
      if (!strcmp(var.obs, "coms_fog"))
        g[jj][ii] = c1;
      else if (!strcmp(var.obs, "coms_ai")) {
        if (c1 > 32760)
          g[jj][ii] = -999;
        else
          g[jj][ii] = c1*0.0107527 - 10.0;
      }
      else if (!strcmp(var.obs, "coms_sst") || !strcmp(var.obs, "coms_s01") || !strcmp(var.obs, "coms_s05") || !strcmp(var.obs, "coms_s10")) {
        if (c1 > 32760)
          g[jj][ii] = -999;
        else
          g[jj][ii] = c1*0.0410557 - 5.0;
      }
      else if (!strcmp(var.obs, "coms_lst")) {
        if (c1 > 32760)
          g[jj][ii] = -999;
        else
          g[jj][ii] = c1*0.127077 + 220.0 - 273.15;
      }
      else if (!strcmp(var.obs, "coms_cth")) {
        if (c1 > 32760)
          g[jj][ii] = -999;
        else
          g[jj][ii] = c1*15.640274*0.001;
      }
      else if (!strcmp(var.obs, "coms_ca")) {
        g[jj][ii] = (int)(c1*0.1 + 0.5);
      }
      else if (!strcmp(var.obs, "coms_ct")) {
        if (c1 == 127)
          c1 = 0;
        else if (c1 < 0 || c1 > 10)
          c1 = -999;
        g[jj][ii] = c1;
      }
      else if (!strcmp(var.obs, "coms_cld"))
        g[jj][ii] = c1;
      else if (!strcmp(var.obs, "coms_ins")) {
        v1 = c1*1.2707;
        if (v1 <= 0 || v1 > 1300) v1 = -999;
        g[jj][ii] = v1;
      }
      else {
        if (c1 >= 0 && c1 < 1024) {
          g[jj][ii] = cnv1[c1];

          if (strstr(var.obs,"d12") || strstr(var.obs,"d13") || strstr(var.obs,"d1w")) {
            c2 = com2[j1][i1];
            if (c2 >= 0 && c2 < 1024)
              g[jj][ii] -= cnv2[c2];
            else
              g[jj][ii] = -99.9;
          }
        }
        else
          g[jj][ii] = -99.9;
      }
    }
  }
  var.ox = 1;
  return 0;
}

/*=============================================================================*
 *  õ���� �����ڷ� ��ȯǥ �б�
 *=============================================================================*/
int coms_conv_read(float cnv[])
{
  FILE  *fp;
  char  buf[1024], tmp[1024];
  int   chn;
  int   i, j, k, n;

  // 1. ��ȯǥ ä�� Ȯ��
  if      (!strcmp(var.obs,"coms_ir1")) chn = 1;
  else if (!strcmp(var.obs,"coms_ir2")) chn = 3;
  else if (!strcmp(var.obs,"coms_ir3")) chn = 7;
  else if (!strcmp(var.obs,"coms_vis")) chn = 9;
  else if (!strcmp(var.obs,"coms_wvp")) chn = 5;
  else if (!strcmp(var.obs,"coms-ta")) chn = 1;
  else if (!strcmp(var.obs,"coms-ts")) chn = 1;
  else if (!strcmp(var.obs,"coms_ins")) chn = 1; // ǥ�鵵���ϻ緮 �߰� by �߼��� (2016. 9. 22.)
  else return 1;

  // 2. �ش��� �� ���, ��ȯ ���� �б�
  if ((fp = fopen(COMS_CONV_FILE,"r")) == NULL) return -1;
  while (fgets(buf, 1024, fp) != NULL) {
    if (buf[0] == '#') continue;
    getword(tmp, buf, ',');  n = atoi(tmp);
    for (i = 0; i < 10; i++) {
      getword(tmp, buf, ',');
      if (chn == i) {
        cnv[n] = atof(tmp);
        break;
      }
    }
  }
  fclose(fp);

  // 3. ���ð� �ƴ� ���� �����µ��� ��ȯ
  if (strcmp(var.obs,"coms_vis")) {
    for (i = 0; i < 1024; i++)
      cnv[i] -= 273.15;
  }
  return 0;
}

/*=============================================================================*
 *  õ���� �����ڷ� ���� ���� Ȯ�� (���ϸ��� UTC)
 *=============================================================================*/
int coms_file()
{
  struct stat st;
  char   coms_file[60];
  int    YY, MM, DD, HH, MI;
  int    code;

  seq2time(var.seq-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  if      (!strcmp(var.obs,"coms_ir1")) strcpy(coms_file,"coms_le1b_ir1_ch1_nwpn");
  else if (!strcmp(var.obs,"coms_ir2")) strcpy(coms_file,"coms_le1b_ir2_ch2_nwpn");
  else if (!strcmp(var.obs,"coms_ir3")) strcpy(coms_file,"coms_le1b_swir_ch4_nwpn");
  else if (!strcmp(var.obs,"coms_vis")) strcpy(coms_file,"coms_le1b_vis_ch5_nwpn");
  else if (!strcmp(var.obs,"coms_wvp")) strcpy(coms_file,"coms_le1b_wv_ch3_nwpn");
  else if (!strcmp(var.obs,"coms-ta"))  strcpy(coms_file,"coms_le1b_ir1_ch1_nwpn");
  else if (!strcmp(var.obs,"coms-ts"))  strcpy(coms_file,"coms_le1b_ir1_ch1_nwpn");
  else if (!strcmp(var.obs,"coms_cld")) strcpy(coms_file,"coms_mi_le2_cld_nwpn");
  else if (!strcmp(var.obs,"coms_ct"))  strcpy(coms_file,"coms_mi_le2_ct_nwpn");
  else if (!strcmp(var.obs,"coms_ca"))  strcpy(coms_file,"coms_mi_le2_ca_nwpn");
  else if (!strcmp(var.obs,"coms_ca1")) strcpy(coms_file,"coms_mi_le2_ca_nwpn");
  else if (!strcmp(var.obs,"coms_ca3")) strcpy(coms_file,"coms_mi_le2_ca_nwpn");
  else if (!strcmp(var.obs,"coms_sky")) strcpy(coms_file,"coms_mi_le2_ca_nwpn");
  else if (!strcmp(var.obs,"coms_cth")) strcpy(coms_file,"coms_mi_le2_cth_nwpn");
  else if (!strcmp(var.obs,"coms_fog")) strcpy(coms_file,"coms_mi_le2_fog_nwpn");
  else if (!strcmp(var.obs,"coms_ai"))  strcpy(coms_file,"coms_mi_le2_ai_nwpn");
  else if (!strcmp(var.obs,"coms_lst")) strcpy(coms_file,"coms_mi_le2_lst_nwpn");
  else if (!strcmp(var.obs,"coms_sst")) strcpy(coms_file,"coms_mi_le2_sst_nwpn");
  else if (!strcmp(var.obs,"coms_s01")) strcpy(coms_file,"coms_mi_le2_sst_1dm_nwpn");
  else if (!strcmp(var.obs,"coms_s05")) strcpy(coms_file,"coms_mi_le2_sst_5dm_nwpn");
  else if (!strcmp(var.obs,"coms_s10")) strcpy(coms_file,"coms_mi_le2_sst_10dm_nwpn");
  else if (!strcmp(var.obs,"coms_ins")) strcpy(coms_file,"coms_mi_le2_ins_nwpn");// ǥ�鵵���ϻ緮 �߰� by �߼��� (2016. 9. 22.)

  if (!strcmp(var.obs,"coms_s01") || !strcmp(var.obs,"coms_s05") || !strcmp(var.obs,"coms_s10"))
    sprintf(var.fname, "%s/%04d%02d/%02d/%s_%04d%02d%02d.bin.gz",
            COMS_BIN_DIR, YY, MM, DD, coms_file, YY, MM, DD);
  else
    sprintf(var.fname, "%s/%04d%02d/%02d/%s_%04d%02d%02d%02d%02d.bin.gz",
            COMS_BIN_DIR, YY, MM, DD, coms_file, YY, MM, DD, HH, MI);
  code = stat(var.fname, &st);
  if (code < 0 || st.st_size <= 100) return -1;
  return 0;
}

/*******************************************************************************
 *
 *  ������ �̹��� ���� �� ����
 *
 *******************************************************************************/
int coms_img()
{
  gdImagePtr im;
  FILE  *fp;
  int   color_lvl[256];
  float data_lvl[256];

  // 1. �̹��� ���� ����
  var.NI = var.size;
  var.NJ = (int)((float)(var.NY)/(float)(var.NX)*var.NI);
  var.GI = var.NI;
  if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + TITLE_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_table(im, color_lvl, data_lvl);
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[240]);

  // 3. �����ڷ� �׸���
  grid_disp(im, color_lvl, data_lvl);

  // 4. ���� �׸���
  //if (var.zoom_level >= 2) map_disp(im, color_lvl[249], 1);
  if (!strcmp(var.obs,"coms_ir1"))
    map_disp(im, color_lvl[250], 4);
  else
    map_disp(im, color_lvl[242], 4);

  // 6. ���� �׸�
  title_disp(im, color_lvl);

  // 7. ���� �׸���
  legend_disp(im, color_lvl, data_lvl);
  gdImageRectangle(im, 0, TITLE_pixel, var.NI-1, var.GJ-1, color_lvl[242]);

  // 8. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);
  return 0;
}

/*=============================================================================*
 *  ����ǥ
 *=============================================================================*/
int color_table(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  FILE  *fp;
  char  color_file[120];
  float data_min, data_itv, v1;
  int   num_color;
  int   R, G, B;
  int   i;

  // 1. ��󺯼��� ����ǥ ���� ����
  strcpy(color_file,COLOR_SET_DIR);
  if      (!strcmp(var.obs,"coms_ir1")) strcat(color_file,"color_sat_ir1.rgb");
  else if (!strcmp(var.obs,"coms_ir2")) strcat(color_file,"color_sat_ir2.rgb");
  else if (!strcmp(var.obs,"coms_ir3")) strcat(color_file,"color_sat_ir3.rgb");
  else if (!strcmp(var.obs,"coms_vis")) strcat(color_file,"color_sat_vis.rgb");
  else if (!strcmp(var.obs,"coms_wvp")) strcat(color_file,"color_sat_wvp.rgb");
  else if (!strcmp(var.obs,"coms_d12")) strcat(color_file,"color_sat_d12.rgb");
  else if (!strcmp(var.obs,"coms_d13")) strcat(color_file,"color_sat_d13.rgb");
  else if (!strcmp(var.obs,"coms_d1w")) strcat(color_file,"color_sat_d1w.rgb");
  else if (!strcmp(var.obs,"coms-ta"))  strcat(color_file,"color_sat_dta.rgb");
  else if (!strcmp(var.obs,"coms-ts"))  strcat(color_file,"color_sat_dta.rgb");
  else if (!strcmp(var.obs,"coms_cld")) strcat(color_file,"color_sat_cld.rgb");
  else if (!strcmp(var.obs,"coms_ct"))  strcat(color_file,"color_sat_ct.rgb");
  else if (!strcmp(var.obs,"coms_ca"))  strcat(color_file,"color_sat_ca1.rgb");
  else if (!strcmp(var.obs,"coms_ca1")) strcat(color_file,"color_sat_ca1.rgb");
  else if (!strcmp(var.obs,"coms_ca3")) strcat(color_file,"color_sat_ca1.rgb");
  else if (!strcmp(var.obs,"coms_cth")) strcat(color_file,"color_sat_cth.rgb");
  else if (!strcmp(var.obs,"coms_fog")) strcat(color_file,"color_sat_fog.rgb");
  else if (!strcmp(var.obs,"coms_ai"))  strcat(color_file,"color_sat_ai.rgb");
  else if (!strcmp(var.obs,"coms_lst")) strcat(color_file,"color_sat_lst.rgb");
  else if (!strcmp(var.obs,"coms_sst")) strcat(color_file,"color_sat_sst.rgb");
  else if (!strcmp(var.obs,"coms_s01")) strcat(color_file,"color_sat_sst.rgb");
  else if (!strcmp(var.obs,"coms_s05")) strcat(color_file,"color_sat_sst.rgb");
  else if (!strcmp(var.obs,"coms_s10")) strcat(color_file,"color_sat_sst.rgb");
  else if (!strcmp(var.obs,"coms_ins")) strcat(color_file,"color_sat_ins.rgb"); //ǥ�鵵���ϻ緮 �߰� by �߼��� (2016. 9. 22.)
  else return -1;

  // 2. ����ǥ ���ϰ� ������ �б�
  var.num_color = num_color = 0;
  if (!strcmp(var.obs,"coms_sky")) {
    color_lvl[0] = gdImageColorAllocate(im, 128, 128, 128);  data_lvl[0] = -1.0;
    color_lvl[1] = gdImageColorAllocate(im, 250, 250, 250);  data_lvl[1] = 2.5;
    color_lvl[2] = gdImageColorAllocate(im, 181, 210, 226);  data_lvl[2] = 5.5;
    color_lvl[3] = gdImageColorAllocate(im, 111, 162, 189);  data_lvl[3] = 8.5;
    color_lvl[4] = gdImageColorAllocate(im,  62, 122, 154);  data_lvl[4] = 10.5;
    num_color = 5;
  }
  else {
    if ((fp = fopen(color_file, "r")) != NULL) {
      while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
        color_lvl[num_color] = gdImageColorAllocate(im, R, G, B);
        data_lvl[num_color] = v1;
        num_color++;
        if (num_color > 119) break;
      }
      fclose(fp);
    }
    else
      num_color = -1;
  }
  var.num_color = num_color;

  // 3. ������ �����ϱ�
  /*
  if      (strstr(var.obs,"ir1")) { data_min = -80;  data_itv = 2.0; }
  else if (strstr(var.obs,"ir2")) { data_min = -80;  data_itv = 2.0; }
  else if (strstr(var.obs,"ir3")) { data_min = -80;  data_itv = 2.0; }
  else if (strstr(var.obs,"vis")) { data_min = 0;    data_itv = 2.0; }
  else if (strstr(var.obs,"wvp")) { data_min = -70;  data_itv = 1.0; }
  else if (strstr(var.obs,"d12")) { data_min = -2.0; data_itv = 0.2; }
  else if (strstr(var.obs,"d13")) { data_min = -50;  data_itv = 1.0; }
  else if (strstr(var.obs,"d1w")) { data_min = 0.0;  data_itv = 1.0; }

  for (i = 0; i < var.num_color; i++)
    data_lvl[i] = data_min + data_itv*i;
  */

  // 3. ��Ÿ ����ǥ ����
  color_lvl[240] = gdImageColorAllocate(im, 220, 220, 220);   // ����1
  color_lvl[241] = gdImageColorAllocate(im, 255, 255, 255);   // ����2
  color_lvl[242] = gdImageColorAllocate(im, 30, 30, 30);      // ������
  color_lvl[243] = gdImageColorAllocate(im, 12, 28, 236);     // ����
  color_lvl[244] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  color_lvl[245] = gdImageColorAllocate(im, 240, 240, 240);
  color_lvl[246] = gdImageColorAllocate(im, 255, 0, 0);
  color_lvl[247] = gdImageColorAllocate(im, 0, 0, 255);
  color_lvl[248] = gdImageColorAllocate(im, 160, 160, 160);   // ����3
  color_lvl[249] = gdImageColorAllocate(im, 90, 90, 90);      // �ñ����
  color_lvl[250] = gdImageColorAllocate(im, 255, 239, 0);     // ���� ����
  color_lvl[251] = gdImageColorAllocate(im, 0, 255, 255);     // �ϴû� ����

  return num_color;
}

/*=============================================================================*
 *  �����ڷ� ǥ��
 *=============================================================================*/
int grid_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  float x, y, dx, dy, d1, d2, dd;
  int   i, j, k, ix, iy, color1;

  // 0. ����ó��
  if (var.ox <= 0) {
    gdImageString(im, gdFontLarge, 100, 100, "No Data File", color_lvl[244]);
    return -1;
  }
  if (var.num_color <= 0) {
    gdImageString(im, gdFontLarge, 100, 100, "No Color Level", color_lvl[244]);
    return -1;
  }

  // 1. Y�� ����
  for (j = 1; j < var.NJ; j++) {
    y = (float)j*(float)(var.NY)/(float)(var.NJ);
    iy = (int)y;
    dy = y - iy;
    if (iy < 0 || iy > var.NY-1) continue;

    // 2. X������ ����
    for (i = 1; i < var.NI; i++) {
      x = (float)i*(float)(var.NX)/(float)(var.NI);
      ix = (int)x;
      dx = x - ix;
      if (ix < 0 || ix > var.NX-1) continue;

      // 3. �ش� �̹��� �ȼ� ��ġ�� ���� ���
      //if (g[iy][ix] > -90 && g[iy][ix+1] > -90 && g[iy+1][ix] > -90 && g[iy+1][ix+1] > -90) {
      //  d1 = (1.0-dx)*g[iy][ix] + dx*g[iy][ix+1];
      //  d2 = (1.0-dx)*g[iy+1][ix] + dx*g[iy+1][ix+1];
      //  dd = (1.0-dy)*d1 + dy*d2;
      //}
      //else {
      //  dd = g[iy][ix];
      //}
      // �������� �ʰ� ó��
      dd = g[iy][ix];

      // 4. �ڷᰡ �������� ������ ǥ��
      if (dd > -90) {
        color1 = color_lvl[240];
        for (k = 0; k < var.num_color; k++) {
          if (dd <= data_lvl[k]) {
            color1 = color_lvl[k];
            break;
          }
        }
        gdImageSetPixel(im, i, var.GJ-j, color1);
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int map_disp(gdImagePtr im, int color_map, int kind)
{
  FILE  *fp;
  char  fname[120];
  float zm = 1.0, xo = 0.0, yo = 0.0, x1, y1, x2, y2;
  int   zx, zy, mode;
  int   i, j, k, n;

  // 1. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    if (var.zoom_rate == 3) {
      for (i = 0; i < 2; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/9.0*(zx-1)/zm;
        yo += (float)(var.NY)/9.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
    else if (var.zoom_rate == 2) {
      for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/8.0*(zx-1)/zm;
        yo += (float)(var.NY)/8.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
  }

  // 2. �ؾȼ� ǥ��
  sprintf(fname, "%s/AFS_%s_map%d.dat", MAP_DIR, var.map, kind);
  if ((fp = fopen(fname, "r")) != NULL) {
    while (fscanf(fp, "%d %d\n", &n, &mode) != EOF) {
      for (i = 0; i < n; i++) {
        fscanf(fp, "%f %f\n", &x2, &y2);
        x2 /= var.grid;
        y2 /= var.grid;

        if (var.zoom_level > 0) {
          x2 = zm*(x2-xo);
          y2 = zm*(y2-yo);
        }
        x2 *= ((float)(var.NI)/(float)(var.NX));
        y2 *= ((float)(var.NI)/(float)(var.NX));
        if (i > 0) {
          gdImageLine(im, (int)x1, var.GJ-(int)y1, (int)x2, var.GJ-(int)y2, color_map);
          if (kind == 4 && var.zoom_level >= 0) gdImageLine(im, (int)x1, var.GJ-(int)y1-1, (int)x2, var.GJ-(int)y2-1, color_map);
        }
        x1 = x2;
        y1 = y2;
      }
    }
    fclose(fp);
  }

  return 0;
}

/*=============================================================================*
 *  EUC-KR���ڿ��� UTF-8�� ��ȯ
 *=============================================================================*/
int euckr2utf(char *str, char *out)
{
    iconv_t convp;
    size_t  ileft, oleft;
    int     err, len = strlen(str);

    ileft = len;
    oleft = len * 2;

    convp = iconv_open("UTF-8", "euc-kr");
    err = iconv(convp, &str, &ileft, &out, &oleft);
    iconv_close(convp);

    return err;
}

/*=============================================================================*
 *  ���� ǥ��(�ѱ�ó��)
 *=============================================================================*/
int title_disp(gdImagePtr im, int color_lvl[])
{
  char   title[80], tm_fc_str[100], num_stn_str[10], tmp[50];
  char   title_utf[100];
  double font_size = 11.5;
  int    brect[8];
  int    YY, MM, DD, HH, MI;
  int    x, i, k;

  // 1. ���񿵿��� ���� ó��
  gdImageFilledRectangle(im, 0, 0, var.GI, TITLE_pixel, color_lvl[241]);

  // 2. ������
  if      (!strcmp(var.obs,"coms_ir1")) strcpy(title,"COMS IR1");
  else if (!strcmp(var.obs,"coms_ir2")) strcpy(title,"COMS IR2");
  else if (!strcmp(var.obs,"coms_ir3")) strcpy(title,"COMS SW");
  else if (!strcmp(var.obs,"coms_vis")) strcpy(title,"COMS VIS");
  else if (!strcmp(var.obs,"coms_wvp")) strcpy(title,"COMS WV");
  else if (!strcmp(var.obs,"coms_d12")) strcpy(title,"COMS IR1-IR2");
  else if (!strcmp(var.obs,"coms_d13")) strcpy(title,"COMS IR1-IR3");
  else if (!strcmp(var.obs,"coms_d1w")) strcpy(title,"COMS IR1-WV");
  else if (!strcmp(var.obs,"coms-ta"))  strcpy(title,"COMS IR1-���");
  else if (!strcmp(var.obs,"coms-ts"))  strcpy(title,"COMS IR1-����µ�");
  else if (!strcmp(var.obs,"coms_cld")) strcpy(title,"COMS ��������");
  else if (!strcmp(var.obs,"coms_ct"))  strcpy(title,"COMS ����");
  else if (!strcmp(var.obs,"coms_ca"))  strcpy(title,"COMS �");
  else if (!strcmp(var.obs,"coms_ca1")) strcpy(title,"COMS �(1H)");
  else if (!strcmp(var.obs,"coms_ca3")) strcpy(title,"COMS �(3H)");
  else if (!strcmp(var.obs,"coms_sky")) strcpy(title,"COMS �ϴû���");
  else if (!strcmp(var.obs,"coms_cth")) strcpy(title,"COMS ��������");
  else if (!strcmp(var.obs,"coms_fog")) strcpy(title,"COMS �Ȱ�");
  else if (!strcmp(var.obs,"coms_ai"))  strcpy(title,"COMS Ȳ������");
  else if (!strcmp(var.obs,"coms_lst")) strcpy(title,"COMS ����µ�");
  else if (!strcmp(var.obs,"coms_sst")) strcpy(title,"COMS SST");
  else if (!strcmp(var.obs,"coms_s01")) strcpy(title,"COMS SST(1��)");
  else if (!strcmp(var.obs,"coms_s05")) strcpy(title,"COMS SST(5��)");
  else if (!strcmp(var.obs,"coms_s10")) strcpy(title,"COMS SST(10��)");
  else if (!strcmp(var.obs,"coms_ins")) strcpy(title,"COMS SI"); //ǥ�鵵���ϻ緮 �߰� by �߼��� (2016. 9. 22.)
  else                                  strcpy(title,var.obs);

  for (i = 0; i < 100; i++)
    title_utf[i] = 0;
  euckr2utf(title, title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 5, (int)(font_size+5), title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 6, (int)(font_size+5), title_utf);

  // 3. �ð� ���ڿ�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'y');
  if (!strcmp(var.obs,"coms_s01") || !strcmp(var.obs,"coms_s05") || !strcmp(var.obs,"coms_s10")) 
    sprintf(tm_fc_str, "   %04d.%02d.%02d.", YY, MM, DD);
  else
    sprintf(tm_fc_str, "%04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, MI);

  gdImageString(im, gdFontLarge, 125, 1, tm_fc_str, color_lvl[244]);
  gdImageString(im, gdFontLarge, 126, 1, tm_fc_str, color_lvl[244]);

  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int legend_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  char   txt[20], txt_utf[40];
  float  dy;
  double font_size = 10.0;
  int    brect[8];
  int    YY, MM, DD, HH, MI;
  int    x, y, i, j, k, n;

  if (var.legend != 1) return 0;
  if (var.num_color <= 0) return -1;

  // 1. ���� ���� ǥ��
  if (!strcmp(var.obs,"coms_sky")) {
    dy = (float)(var.NJ)/(float)(var.num_color-1);
    for (k = 1; k < var.num_color; k++) {
      y = var.GJ - dy*(k-1);
      gdImageFilledRectangle(im, var.NI, y-dy, var.NI+8, y, color_lvl[k]);
    }
  }
  else {
    dy = (float)(var.NJ)/(float)(var.num_color);
    for (k = 0; k < var.num_color; k++) {
      y = var.GJ - dy*k;
      gdImageFilledRectangle(im, var.NI, y-dy, var.NI+8, y, color_lvl[k]);
    }
  }
  gdImageRectangle(im, var.NI-1, TITLE_pixel, var.NI+8, var.GJ-1, color_lvl[242]);

  // 2. ���ʰ� ǥ��
  gdImageFilledRectangle(im, var.NI+9, 0, var.GI-1, var.GJ, color_lvl[241]);
  if (!strcmp(var.obs,"coms_d12")) {
    for (k = 0; k < var.num_color-1; k += 2) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.1f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (!strncmp(var.obs,"coms_ca",7)) {
    for (k = 0; k < var.num_color; k++) {
      y = var.GJ - (k+0.5)*dy - 5;
      sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (!strcmp(var.obs,"coms_ct")) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy + 5;
      sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (!strcmp(var.obs,"coms_cth")) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.1f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (!strcmp(var.obs,"coms_fog")) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (!strcmp(var.obs,"coms_sky")) {
    for (i = 0; i < 40; i++)
      txt_utf[i] = 0;

    for (k = 1; k < var.num_color; k++) {
      if (k == 1 || k == 4)
        n = 2;
      else
        n = 4;

      for (j = 0; j < n; j++) {
        if (k == 1) {
          if (j == 0)
            strcpy(txt,"��");
          else
            strcpy(txt,"��");
        }
        else if (k == 2) {
          if (j == 0)
            strcpy(txt,"��");
          else if (j == 1)
            strcpy(txt,"��");
          else if (j == 2)
            strcpy(txt,"��");
          else
            strcpy(txt,"��");
        }
        else if (k == 3) {
          if (j == 0)
            strcpy(txt,"��");
          else if (j == 1)
            strcpy(txt,"��");
          else if (j == 2)
            strcpy(txt,"��");
          else
            strcpy(txt,"��");
        }
        else if (k == 4) {
          if (j == 0)
            strcpy(txt,"��");
          else
            strcpy(txt,"��");
        }
        euckr2utf(txt, txt_utf);

        y = TITLE_pixel + var.GJ/8*(2*k-1) + (font_size+5)*j - var.GJ/16;
        gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, var.NI+12, y, txt_utf);
        gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, var.NI+13, y, txt_utf);
      }
    }
  }
  else {
    for (k = 0; k < var.num_color-1; k += 2) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }

  // 3. ���� ���� ǥ��
  if      (!strcmp(var.obs,"coms_ir1")) strcpy(txt,"C");
  else if (!strcmp(var.obs,"coms_ir2")) strcpy(txt,"C");
  else if (!strcmp(var.obs,"coms_ir3")) strcpy(txt,"C");
  else if (!strcmp(var.obs,"coms_vis")) strcpy(txt," ");
  else if (!strcmp(var.obs,"coms_wvp")) strcpy(txt,"C");
  else if (!strcmp(var.obs,"coms_d12")) strcpy(txt,"C");
  else if (!strcmp(var.obs,"coms_d13")) strcpy(txt,"C");
  else if (!strcmp(var.obs,"coms_d1w")) strcpy(txt,"C");
  else if (!strcmp(var.obs,"coms-ta"))  strcpy(txt,"C");
  else if (!strcmp(var.obs,"coms-ts"))  strcpy(txt,"C");
  else if (!strcmp(var.obs,"coms_fog")) strcpy(txt," ");
  else if (!strcmp(var.obs,"coms_cld")) strcpy(txt," ");
  else if (!strcmp(var.obs,"coms_ct"))  strcpy(txt," ");
  else if (!strcmp(var.obs,"coms_ca"))  strcpy(txt,"1/10");
  else if (!strcmp(var.obs,"coms_ca1")) strcpy(txt,"1/10");
  else if (!strcmp(var.obs,"coms_ca3")) strcpy(txt,"1/10");
  else if (!strcmp(var.obs,"coms_sky")) strcpy(txt," ");
  else if (!strcmp(var.obs,"coms_cth")) strcpy(txt,"km");
  else if (!strcmp(var.obs,"coms_ai"))  strcpy(txt," ");
  else if (!strcmp(var.obs,"coms_lst")) strcpy(txt,"C");
  else if (!strcmp(var.obs,"coms_sst")) strcpy(txt,"C");
  else if (!strcmp(var.obs,"coms_s01")) strcpy(txt,"C");
  else if (!strcmp(var.obs,"coms_s05")) strcpy(txt,"C");
  else if (!strcmp(var.obs,"coms_s10")) strcpy(txt,"C");
  else if (!strcmp(var.obs,"coms_ins")) strcpy(txt,"W/m2"); //ǥ�鵵���ϻ緮 �߰� by �߼��� (2016. 9. 22.)

  x = var.NI + 3;
  gdImageString(im, gdFontLarge, x, 4, txt, color_lvl[244]);
  return 0;
}

/*=============================================================================*
 *  zd�� Ȯ�� ��ƾ (���밡��: �ݵ�� ������ X,Y ���� zd���� ������ �������� ��)
 *      Ȯ��� �������� sub 4-point ����� �⺻���� ���
 *  by ����ȯ (2006. 5. 22)
 *=============================================================================*/
int grid_zoom (
    float **g,      /* input -> output */
    int   nx,       /* [0:nx,0:ny] zd�� ������ �������� ��. */
    int   ny,
    int   zd,       /* Ȯ���� (2��,3�� ... ) */
    int   ox,       /* ���� �Ʒ� ������ X-��ǥ */
    int   oy,       /* ���� �Ʒ� ������ Y-��ǥ */
    float missing,  /* ���ϴ� �ڷ� ���� */
    int   mode      /* 0:����(X), 1:��������, 2:4������ */
)
{
    float x;
    int   i, j, k;

    // 1. Y ���� Ȯ��
    for (i = ox; i <= ox+nx/zd; i++) {
        for (k = 0, j = oy; j < oy*zd/(zd-1); j++, k += zd) g[k][i] = g[j][i];
        for (k = ny, j = oy+ny/zd; j >= oy*zd/(zd-1); j--, k -= zd) g[k][i] = g[j][i];
    }

    // 2. X ���� Ȯ��
    for (j = 0; j <= ny; j += zd) {
        for (k = 0, i = ox; i < ox*zd/(zd-1); i++, k += zd) g[j][k] = g[j][i];
        for (k = nx, i = ox+nx/zd; i >= ox*zd/(zd-1); i--, k -= zd) g[j][k] = g[j][i];
    }

    // 3. Y ���� ����
    for (i = 0; i <= nx; i += zd) {
        // 3.1. (0, zd) ���� ������ ��� : �������� ���
        if (mode > 0 && g[0][i] > missing && g[zd][i] > missing) {
            for (k = 1; k < zd; k++)
                g[k][i] = (g[0][i]*(float)(zd - k) + g[zd][i]*(float)k) / (float)zd;
        }
        else {
            for (k = 1; k < zd; k++) {
                if (k <= zd/2) g[k][i] = g[0][i];
                else           g[k][i] = g[zd][i];
            }
        }

        // 3.2. (ny-zd, ny) ���� ������ ��� : �������� ���
        if (mode > 0 && g[ny-zd][i] > missing && g[ny][i] > missing) {
            for (k = 1; k < zd; k++)
                g[ny-k][i] = (g[ny-zd][i]*(float)k + g[ny][i]*(float)(zd-k)) / (float)zd;
        }
        else {
            for (k = 1; k < zd; k++) {
                if (k < zd/2) g[ny-k][i] = g[ny][i];
                else          g[ny-k][i] = g[ny-zd][i];
            }
        }

        // 3.3. ������ (zd,ny-zd) ���� ������ ��� : �ؼ������� ��� (4-point)
        for (j = zd; j < ny-zd; j += zd) {
            for (k = 1; k < zd; k++) {
                if (mode > 0 && g[j][i] > missing && g[j+zd][i] > missing) {
                    x = (float)k / (float)zd;

                    if (mode == 2 && g[j-zd][i] > missing && g[j+zd*2][i] > missing)
                        g[j+k][i] = g[j][i] + x*(g[j+zd][i] - g[j][i] + (x-1.0)*0.25*(g[j-zd][i] - g[j][i] - g[j+zd][i] + g[j+zd*2][i]));
                    else
                        g[j+k][i] = g[j][i]*(1.0-x) + g[j+zd][i]*x;
                }
                else {
                    if (k <= zd/2) g[j+k][i] = g[j][i];
                    else           g[j+k][i] = g[j+zd][i];
                }
            }
        }
    }

    // 4. X ���� ����
    for (j = 0; j <= ny; j++) {
        // 4.1. (0, zd) ���� ������ ��� : �������� ���
        if (mode > 0 && g[j][0] > missing && g[j][zd] > missing) {
            for (k = 1; k < zd; k++)
                g[j][k] = (g[j][0]*(float)(zd - k) + g[j][zd]*(float)k) / (float)zd;
        }
        else {
            for (k = 1; k < zd; k++) {
                if (k <= zd/2) g[j][k] = g[j][0];
                else           g[j][k] = g[j][zd];
            }
        }

        // 4.2. (nx-zd, nx) ���� ������ ��� : �������� ���
        if (mode > 0 && g[j][nx-zd] > missing && g[j][nx] > missing) {
            for (k = 1; k < zd; k++)
                g[j][nx-k] = (g[j][nx-zd]*(float)k + g[j][nx]*(float)(zd-k)) / (float)zd;
        }
        else {
            for (k = 1; k < zd; k++) {
                if (k < zd/2) g[j][nx-k] = g[j][nx];
                else          g[j][nx-k] = g[j][nx-zd];
            }
        }

        // 4.3. ������ (zd,ny-zd) ���� ������ ��� : �ؼ������� ��� (4-point)
        for (i = zd; i < nx-zd; i += zd) {
            for (k = 1; k < zd; k++) {
                if (mode > 0 && g[j][i] > missing && g[j][i+zd] > missing) {
                    x = (float)k / (float)zd;

                    if (mode == 2 && g[j][i-zd] > missing && g[j][i+zd*2] > missing)
                        g[j][i+k] = g[j][i] + x*(g[j][i+zd] - g[j][i] + (x-1.0)*0.25*(g[j][i-zd] - g[j][i] - g[j][i+zd] + g[j][i+zd*2]));
                    else
                        g[j][i+k] = g[j][i]*(1.0-x) + g[j][i+zd]*x;
                }
                else {
                    if (k <= zd/2) g[j][i+k] = g[j][i];
                    else           g[j][i+k] = g[j][i+zd];
                }
            }
        }
    }
    return 0;
}

/*=============================================================================*
 *  Grid data Smoothing (by 1-2-1 Smoothing)
 *  by ����ȯ (1997. 3. 15)
 *=============================================================================*/
int grid_smooth (
    float **g,      /* input -> output  */
    int   nx,       /* ���� [0:nx,0:ny] */
    int   ny,
    int   missing   /* ���ϴ� �ڷ� ���� */
)
{
    float  e[4], e1, e2;
    int    i, j;

    for (j = 0; j <= ny; j++) {
        e1 = g[j][0];
        e[0] = g[j][0];
        e[1] = g[j][1];

        for (i = 1; i < nx; i++) {
            e[2] = g[j][i+1];

            if (e[0] > missing && e[1] > missing && e[2] > missing)
                e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
            else if (e[0] > missing && e[1] <= missing && e[2] > missing)
                e2 = (e[0] + e[2]) * 0.5;
            else
                e2 = e[1];

            g[j][i-1] = e1;
            e1 = e2;
            e[0] = e[1];
            e[1] = e[2];
        }
        g[j][i-1] = e1;
    }

    for (i = 0; i <= nx; i++) {
        e1 = g[0][i];
        e[0] = g[0][i];
        e[1] = g[1][i];

        for (j = 1; j < ny; j++) {
            e[2] = g[j+1][i];

            if (e[0] > missing && e[1] > missing && e[2] > missing)
                e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
            else if (e[0] > missing && e[1] <= missing && e[2] > missing)
                e2 = (e[0] + e[2]) * 0.5;
            else
                e2 = e[1];

            g[j-1][i] = e1;
            e1 = e2;
            e[0] = e[1];
            e[1] = e[2];
        }
        g[j-1][i] = e1;
    }
    return 0;
}

/*******************************************************************************
 *
 *  ���� Ȯ�� (2�� Ȯ�븸 ����)
 *
 *******************************************************************************/
int grid_zooming(float **grid) {
    int  zx, zy, zm = 1, ox = 0, oy = 0, code, i, k;

    // 1. Ȯ��ø� ó��
    if (var.zoom_level == 0) return 0;

    // 2. ������ �ڷ� Ȯ��
    for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        ox = (zx-1)*var.NX/8;
        oy = (zy-1)*var.NY/8;
        code = grid_zoom(grid, var.NX, var.NY, var.zoom_rate, ox, oy, -90.0, 2);
    }
    return 0;
}

/*=============================================================================*
 *  ���� ���� ���� �б�
 *
 *      map : inp:������ ����
 *      nx  : out:�������� �������� (km)
 *      ny  : out:���Ϲ��� �������� (km)
 *      sx  : out:�������� ������ġ (km)
 *      sy  : out:���Ϲ��� ������ġ (km)
 *=============================================================================*/
int grid_map_inf(char *map, int *nx, int *ny, int *sx, int *sy)
{
    FILE  *fp;
    char  buf[1024], map_list[8], value[16];

    fp = fopen(MAP_INI_FILE,"r");
    if (fp == NULL) exit(-1);

    while (fgets(buf,1024,fp)) {
        if (buf[0] == '#') continue;
        getword(map_list, buf, ':');

        if ( !strcmp(map, map_list) ) {
            getword(value, buf, ':');  *nx = atoi(value);
            getword(value, buf, ':');  *ny = atoi(value);
            getword(value, buf, ':');  *sx = atoi(value);
            getword(value, buf, ':');  *sy = atoi(value);
            break;
        }
    }
    fclose(fp);

    return 0;
}

/*******************************************************************************
 *
 *  �ڷᰡ �̻��� �ִ� ���, ���� �̹��� ���
 *
 *******************************************************************************/
int err_img(int err)
{
  gdImagePtr im;
  char  text[120], tmp[120];
  int   YY, MM, DD, HH, MI;
  int   color_lvl[16];
  int   x, y, i, j, k, n;

  // 1. �̹��� ���� ����
  var.NI = var.size;
  var.NJ = var.NI;
  var.GI = var.NI;
  if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + TITLE_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_lvl[0] = gdImageColorAllocate(im, 240, 240, 240);   // ����
  color_lvl[1] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[0]);

  // 3. ���� �޽���
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(text, "TIME = %04d.%02d.%02d.%02d:%02d / err = %d", YY, MM, DD, HH, MI, err);
  gdImageString(im, gdFontLarge, 50, 50, text, color_lvl[1]);

  sprintf(text, "OBS = %s / MAP = %s", var.obs, var.map);
  gdImageString(im, gdFontLarge, 50, 70, text, color_lvl[1]);

  sprintf(text, "SIZE = %dpx", var.size);
  gdImageString(im, gdFontLarge, 50, 110, text, color_lvl[1]);

  if (err == 2)
    sprintf(text, "FILE = %s (file is not found)", var.fname);
  else
    sprintf(text, "FILE = %s", var.fname);
  gdImageString(im, gdFontLarge, 50, 130, text, color_lvl[1]);

  // 4. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);

  return 0;
}
