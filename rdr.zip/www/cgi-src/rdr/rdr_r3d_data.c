#include "rdr_r3d_img.h"

extern struct INPUT_VAR  var;

extern struct RDR_R3D_HEAD  rdr_r3d_head;              // �ռ��ڷ� HEAD
extern struct RDR_CMP_STN_LIST  rdr_r3d_stn_list[48];  // �ռ��� ���̴� ���
extern unsigned short  **echo;

//int grid_smooth(float **g, int nx, int ny, float missing);
int rdr_cmp_lng_mask(char *, float);
int rdr_cmp_num_mask(int, int, float);

/*******************************************************************************
 *
 *  ���̴� 3���� �ռ��ڷ� ���� ����
 *
 *******************************************************************************/
int rdr_r3d_get()
{
  FILE   *fp;
  unsigned char *nb, *ne;
  int    io_ok = 0;
  int    i, j, k, n;

  // 1. ���� ���� ���� Ȯ��
  if (rdr_r3d_file() < 0) return -1;
  grid_map_inf(var.map, &(var.NX), &(var.NY), &(var.SX), &(var.SY));

  // 2. ���̴� �ռ��ڷ� �б�
  fp = gzopen(var.fname, "rb");
  if (fp != NULL) {
    // 2.1. ������� �б�
    gzread(fp, &rdr_r3d_head, sizeof(rdr_r3d_head));
    gzread(fp, rdr_r3d_stn_list, sizeof(rdr_r3d_stn_list));
    var.num_rdr_stn = rdr_r3d_head.num_stn;
    var.grid = (rdr_r3d_head.dxy)*0.001;

    // 2.3. ���ϵ� �б�
    k = (int)(var.ht/rdr_r3d_head.dz);
    if (k >= 0 && k < rdr_r3d_head.nz) {
      if (k > 0) gzseek(fp, (long)(2*rdr_r3d_head.ny*rdr_r3d_head.nx*(k-1)), SEEK_CUR);
      echo = smatrix2(0, (int)(rdr_r3d_head.ny-1), 0, (int)(rdr_r3d_head.nx-1));
      for (j = 0; j < rdr_r3d_head.ny; j++)
        gzread(fp, echo[j], (rdr_r3d_head.nx)*2);
    }
    else {
      io_ok = -1;
    }
    gzclose(fp);
  }
  else {
    io_ok = -1;
  }

  // 3. �б� ������ ���
  if (io_ok < 0) return io_ok;

  return 0;
}

/*=============================================================================*
 *  Z-R �����
 *     - mode : 0(dBZ->������), 1(������->dBZ)
 *=============================================================================*/
int dbz_rain_conv(float *dbz1, float *rain1, int mode)
{
  static int first = 0;
  static float za, zb;

  if (first == 0) {
    za = 0.1/var.ZRb;
    zb = log10(var.ZRa)/var.ZRb;
    first = 1;
  }

  if (mode == 0) {
    //*rain1 = (*dbz1*0.1 - log10(var.ZRa) )/var.ZRb;
    *rain1 = *dbz1*za - zb;
    *rain1 = pow(10.0, *rain1);
  }
  else if (mode == 1) {
    *dbz1 = 10.0 * log10( var.ZRa * pow(*rain1, var.ZRb) );
  }
  return 0;
}

/*******************************************************************************
 *  Grid data Smoothing (by 1-2-1 Smoothing)
 *  by ����ȯ (1997. 3. 15)
 *******************************************************************************/
int grid_smooth (
  short **g,      // input -> output
  int   nx,       // ���� [0:nx-1,0:ny-1]
  int   ny,
  float missing   // ���ϴ� �ڷ� ����
)
{
  short  *e1, *e2, *e3, *e4;
  short  v1, v2, *v4;
  int    i, j;

  // 1. Y�� ��������, X�� �������� ��Ȱȭ�Ѵ�.
  for (j = 0; j < ny; j++) {
    e1 = &g[j][0];
    e2 = &g[j][1];
    e3 = &g[j][2];
    v1 = *e1;

    for (v1 = *e1, i = 1; i < nx-1; i++, e1++, e2++, e3++) {
      if (*e1 > missing && *e2 > missing && *e3 > missing)
        v2 = (*e1 + 2*(*e2) + *e3) / 4;
      else if (*e1 > missing && *e2 <= missing && *e3 > missing)
        v2 = (*e1 + *e3) / 2;
      else
        v2 = *e2;

      (*e1) = v1;
      v1 = v2;
    }
    (*e1) = v1;
  }

  // 2. X�� ��������, Y�� �������� ��Ȱȭ�Ѵ�.
  v4 = svector(0, nx-1);    // �迭 �غ�
  for (j = 1; j < ny-1; j++) {
    e1 = &g[j-1][0];
    e2 = &g[j][0];
    e3 = &g[j+1][0];
    e4 = &v4[0];

    for (i = 0; i < nx; i++, e1++, e2++, e3++, e4++) {
      if (*e1 > missing && *e2 > missing && *e3 > missing)
        v2 = (*e1 + 2*(*e2) + *e3) / 4;
      else if (*e1 > missing && *e2 <= missing && *e3 > missing)
        v2 = (*e1 + *e3) / 2;
      else
        v2 = *e2;

      if (j > 1) (*e1) = *e4;
      *e4 = v2;
    }
  }
  for (i = 0; i < nx; i++)
    (*e1) = *e4;

  // �迭 ����
  free_svector(v4, 0, nx-1);
  return 0;
}

/*=============================================================================*
 *  3���� �ռ� ���ϸ�
 *=============================================================================*/
int rdr_r3d_file()
{
  FILE   *fp;
  struct stat st;
  char   qcd[8], vol[8];
  int    YY, MM, DD, HH, MI;
  int    code;

  // 1. �ռ� ���ϸ�
  if (strcmp(var.vol,"RN") == 0|| strcmp(var.vol,"SN") == 0)
    strcpy(vol, "CZ");
  else
    strcpy(vol, var.vol);

  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_%s_%s_%04d%02d%02d%02d%02d.bin.gz",
          RDR_R3D_DIR, YY, MM, DD, var.cmp, var.qcd, vol, YY, MM, DD, HH, MI);

  // 2. ���翩�� Ȯ��
  code = stat(var.fname, &st);
  if (code < 0 || st.st_size <= 0) return -1;
  return 0;
}

/*=============================================================================*
 *  ���̴� �ռ��ڷ� ���� ���� Ȯ��
 *=============================================================================*/
int rdr_cmp_file(
  int  seq,
  char *cmp,
  char *qcd,
  int  dir_mode,
  char *dname
)
{
  struct stat st;
  char   sname[120];
  int    YY, MM, DD, HH, MI;
  int    data, code, rtn;

  // 1. �ڷ� �ð�
  seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  // 2. ���ϸ�
  if (strstr(cmp,"HSR") != NULL) {
    if (strcmp(qcd,"NQC") == 0)
      sprintf(sname, "RDR_CMP_HSR_KMA_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    else
      sprintf(sname, "RDR_CMP_HSR_EXT_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    if (dir_mode == 1)
      sprintf(dname, "%s/%s", RDR_FTP_HSR, sname);
    else
      sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }
  else if (strstr(cmp,"LNG") != NULL) {
    sprintf(sname, "RDR_CMP_%s_%s_%04d%02d%02d%02d%02d.bin.gz", cmp, qcd, YY, MM, DD, HH, MI);
    if (dir_mode == 1)
      sprintf(dname, "%s/%s", RDR_FTP_LNG, sname);
    else
      sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }
  else if (strstr(cmp,"HCI") != NULL) {
    if (strcmp(qcd,"NQC") == 0)
      sprintf(sname, "RDR_CMP_HCI_KMA_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    else
      sprintf(sname, "RDR_CMP_HCI_EXT_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    if (dir_mode == 1)
      sprintf(dname, "%s/%s", RDR_FTP_HCI, sname);
    else
      sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }
  else if (strstr(cmp,"HAIL") != NULL) {
    if (strcmp(qcd,"EXT") == 0)
      sprintf(sname, "RDR_CMP_HAIL_EXT_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    else
      sprintf(sname, "RDR_CMP_HAIL_KMA_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    if (dir_mode == 1)
      sprintf(dname, "%s/%s", RDR_FTP_HCI, sname);
    else
      sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }
  else if (strstr(cmp,"NUM") != NULL) {
    sprintf(sname, "RDR_CMP_%s_%s_%04d%02d%02d%02d%02d.bin.gz", cmp, qcd, YY, MM, DD, HH, MI);
    if (dir_mode == 1)
      sprintf(dname, "%s/%s", RDR_FTP_NUM, sname);
    else
      sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }
  else if (strstr(cmp,"PCP") != NULL) {
    if (strcmp(cmp,"PCPH") == 0) {        // HSR ����
      if (strcmp(qcd,"EXT") == 0)
        sprintf(sname, "RDR_PCP_HSR_EXT_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
      else if (strcmp(qcd,"KMA") == 0 || strcmp(qcd,"NQC") == 0)
        sprintf(sname, "RDR_PCP_HSR_KMA_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
      else if (strcmp(qcd,"MSK") == 0 || strcmp(qcd,"QCD") == 0)
        sprintf(sname, "RDR_PCP_HSR_MSK_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    }
    else if (strcmp(cmp,"PCPP") == 0) {   // PPI ����
      if (strcmp(qcd,"EXT") == 0)
        sprintf(sname, "RDR_PCP_PPI_EXT_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
      else if (strcmp(qcd,"KMA") == 0 || strcmp(qcd,"NQC") == 0)
        sprintf(sname, "RDR_PCP_PPI_NQC_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
      else if (strcmp(qcd,"MSK") == 0 || strcmp(qcd,"QCD") == 0)
        sprintf(sname, "RDR_PCP_PPI_QCD_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    }
    if (dir_mode == 1)
      sprintf(dname, "%s/%s", RDR_FTP_PCP, sname);
    else
      sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_PCP_DIR, YY, MM, DD, sname);
  }
  else {
    sprintf(sname, "RDR_CMP_%s_%s_%04d%02d%02d%02d%02d.bin.gz", cmp, qcd, YY, MM, DD, HH, MI);
    if (dir_mode == 1)
      sprintf(dname, "%s/%s", RDR_FTP_WRC, sname);
    else
      sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }

  // 3. ���� ���� ���� Ȯ��
  code = stat(dname, &st);
  if (code < 0 || st.st_size <= 100)
    rtn = -1;
  else
    rtn = 0;
  return rtn;
}

/*=============================================================================*
 *  ���� ���� ���� �б�
 *
 *      map : inp:������ ����
 *      nx  : out:�������� �������� (km)
 *      ny  : out:���Ϲ��� �������� (km)
 *      sx  : out:�������� ������ġ (km)
 *      sy  : out:���Ϲ��� ������ġ (km)
 *=============================================================================*/
int grid_map_inf(char *map, int *nx, int *ny, int *sx, int *sy)
{
  FILE  *fp;
  char  buf[1024], map_list[8], value[16];

  fp = fopen(MAP_INI_FILE,"r");
  if (fp == NULL) exit(-1);

  while (fgets(buf,1024,fp)) {
    if (buf[0] == '#') continue;
    getword(map_list, buf, ':');

    if ( !strcmp(map, map_list) ) {
      getword(value, buf, ':');  *nx = atoi(value);
      getword(value, buf, ':');  *ny = atoi(value);
      getword(value, buf, ':');  *sx = atoi(value);
      getword(value, buf, ':');  *sy = atoi(value);
      break;
    }
  }
  fclose(fp);
  return 0;
}
