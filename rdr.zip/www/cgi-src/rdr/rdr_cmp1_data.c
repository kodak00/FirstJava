#include "rdr_cmp1_img.h"

extern struct INPUT_VAR  var;

extern struct RDR_PCP_HEAD  rdr_pcp_head;      // PCP�ռ� Header
extern struct RDR_CMP_HEAD  rdr_cmp_head;              // �ռ��ڷ� HEAD
extern struct RDR_CMP_STN_LIST  rdr_cmp_stn_list[48];  // �ռ��� ���̴� ���
extern short  **echo;
extern unsigned char  **num_echo, **num_base;
extern float  **rain;

//int grid_smooth(float **g, int nx, int ny, float missing);
int rdr_cmp_lng_mask(char *, float);
int rdr_cmp_num_mask(int, int, float);

/*******************************************************************************
 *
 *  �ռ��ڷ� ���������� �ڷ� �б�
 *
 *******************************************************************************/
int rdr_cmp_pcp_get()
{
  FILE   *fp;
  float  rain1, *q;
  short  **pcp, *p;
  int    seq;
  int    code, i, j;

  // 1. �������� ����
  grid_map_inf(var.map, &(var.NX), &(var.NY), &(var.SX), &(var.SY));

  // 3. 60�� �������� ����
  for (var.num_pcp_file = 0, seq = var.seq; seq > var.seq1; seq -= 60) {
    // 3.1. ���� ���翩�� �� ���ϸ� Ȯ��
    code = rdr_cmp_file(seq, var.cmp, var.qcd, var.dir_mode, var.fname);
    if (code < 0 && var.num_pcp_file == 0) continue;   // �߰��� ���� ���� ������ ������ ä��ٴ� �ǹ�

    // 3.2. ���ڰ� �б�
    fp = gzopen(var.fname, "rb");
    if (fp != NULL) {
      gzread(fp, &rdr_pcp_head, sizeof(rdr_pcp_head));

      // ó���� ���, �ʱ�ȭ
      if (var.num_pcp_file == 0) {
        rain = matrix(0, (int)(rdr_pcp_head.ny-1), 0, (int)(rdr_pcp_head.nx-1));
        pcp = smatrix(0, (int)(rdr_pcp_head.ny-1), 0, (int)(rdr_pcp_head.nx-1));

        for (j = 0; j < rdr_pcp_head.ny; j++) {
          for (q = &rain[j][0], i = 0; i < rdr_pcp_head.nx; i++, q++) {
            (*q) = BLANK1;
          }
        }
      }

      // ������(*0.01) �б�
      gzseek(fp, (long)(2*rdr_pcp_head.ny*rdr_pcp_head.nx), SEEK_CUR);  // ���ں� �ڷ�� skip
      for (j = 0; j < rdr_pcp_head.ny; j++)
        gzread(fp, pcp[j], rdr_pcp_head.nx*2);
      gzclose(fp);

      var.num_pcp_file++;
    }

    // 3.4. ���������� ��ȯ �� ����
    for (j = 0; j < rdr_pcp_head.ny; j++) {
      q  = &rain[j][0];
      p  = &pcp[j][0];

      for (i = 0; i < rdr_pcp_head.nx; i++, p++, q++) {
        if ((*p) < BLANK2) continue;  // �����������̸� ó������ �ʴ´�.

        if ((*p) >= 0) {
          rain1 = 0.01*(float)(*p);
          if ((*q) < 0)
            (*q) = rain1;
          else
            (*q) += rain1;
        }
        else {
          if ((*p) > BLANK1 && *q < 0) (*q) = (float)(*p);
        }
      }
    }
  }

  // 4. �޸� �ݳ�
  if (var.num_pcp_file > 0)
    free_smatrix(pcp, 0, (int)(rdr_pcp_head.ny-1), 0, (int)(rdr_pcp_head.nx-1));
  else
    return -1;
  return 0;
}

/*******************************************************************************
 *
 *  ���̴� �ռ��ڷ� ���� ����
 *
 *******************************************************************************/
int rdr_cmp_get()
{
  FILE   *fp;
  unsigned char *nb, *ne;
  int    io_ok = 0;
  int    i, j, k, n;

  // 1. ���� ���� ���� Ȯ��
  if (rdr_cmp_file(var.seq, var.cmp, var.qcd, var.dir_mode, var.fname) < 0) return -1;
  var.HSR_mask = 0;
  grid_map_inf(var.map, &(var.NX), &(var.NY), &(var.SX), &(var.SY));

  // 2. ���̴� �ռ��ڷ� �б�
  fp = gzopen(var.fname, "rb");
  if (fp != NULL) {
    // 2.1. ������� �б�
    gzread(fp, &rdr_cmp_head, sizeof(rdr_cmp_head));
    gzread(fp, rdr_cmp_stn_list, sizeof(rdr_cmp_stn_list));
    var.num_rdr_stn = rdr_cmp_head.num_stn;
    var.grid = (rdr_cmp_head.dxy)*0.001;

    // 2.2. ����Ž���� ���� �б�
    if (strcmp(var.cmp,"NUM") == 0) {
      // 2.2.1. �ش� dbz������ ����� ��ġ Ȯ��
      for (n = -1, i = 0; i < 15; i++) {
        if (var.dbz == rdr_cmp_head.etc[i]) {
          n = i;
          break;
        }
      }

      // 2.2.2. base ���ý�
      if (n == 0) {
        // �ڷ� ���� ����
        num_echo = cmatrix(0, (int)(rdr_cmp_head.ny-1), 0, (int)(rdr_cmp_head.nx-1));

        // �⺻ ���� �б�
        for (j = 0; j < rdr_cmp_head.ny; j++)
          gzread(fp, num_echo[j], (rdr_cmp_head.nx));

        // ������ ��� ���� ���
        if (var.rate == 'R') {
          for (j = 0; j < rdr_cmp_head.ny; j++) {
            ne = &num_echo[j][0];
            for (i = 0; i < rdr_cmp_head.nx; i++, ne++) {
              if (*ne > 0 && *ne < 200)
                *ne = 100;
              else
                *ne = 0;
            }
          }
        }
      }

      // 2.2.3. ����Ž���� ���ý�
      else if (n > 0) {
        // �ڷ� ���� ����
        num_base = cmatrix(0, (int)(rdr_cmp_head.ny-1), 0, (int)(rdr_cmp_head.nx-1));
        num_echo = cmatrix(0, (int)(rdr_cmp_head.ny-1), 0, (int)(rdr_cmp_head.nx-1));

        // �⺻ ���� �б�
        for (j = 0; j < rdr_cmp_head.ny; j++)
          gzread(fp, num_base[j], (rdr_cmp_head.nx));

        // �ش� ���� �б�
        if (n > 1) gzseek(fp, (long)(rdr_cmp_head.ny*rdr_cmp_head.nx*(n-1)), SEEK_CUR);
        for (j = 0; j < rdr_cmp_head.ny; j++)
          gzread(fp, num_echo[j], (rdr_cmp_head.nx));

        // ������ ��� ���� ���
        if (var.rate == 'R') {
          for (j = 0; j < rdr_cmp_head.ny; j++) {
            nb = &num_base[j][0];
            ne = &num_echo[j][0];
            for (i = 0; i < rdr_cmp_head.nx; i++, nb++, ne++) {
              if (*nb > 0 && *nb < 200) {
                if (*ne >= 0 && *ne < 200)
                  *ne = (unsigned char)(100.0*(float)(*ne)/(float)(*nb));
                else
                  *ne = 0;
              }
              else
                *ne = 250;
            }
          }
        }

        // base ����
        free_cmatrix(num_base, 0, (int)(rdr_cmp_head.ny-1), 0, (int)(rdr_cmp_head.nx-1));
      }

      // 2.2.4. ���õ� ���� ������
      else {
        io_ok = -1;
      }
    }

    // 2.3. ����Ž���� �̿� ���ϵ� �б�
    else {
      if      (strcmp(var.obs,"EBH")  == 0) n = 2;
      else if (strcmp(var.obs,"STN")  == 0) n = 3;
      else n = 1;
      if (n > 1) gzseek(fp, (long)(2*rdr_cmp_head.ny*rdr_cmp_head.nx*(n-1)), SEEK_CUR);

      echo = smatrix(0, (int)(rdr_cmp_head.ny-1), 0, (int)(rdr_cmp_head.nx-1));
      for (j = 0; j < rdr_cmp_head.ny; j++)
        gzread(fp, echo[j], (rdr_cmp_head.nx)*2);
    }
    gzclose(fp);
  }
  else {
    io_ok = -1;
  }

  // 3. �б� ������ ���
  if (io_ok < 0) return io_ok;

  // 4. ����� ���, �������� ��ȯ
  if (strcmp(var.cmp,"HAIL") == 0 && strcmp(var.obs,"ECHO") == 0) {
    rdr_cmp_hail_conv();
  }

  // 5. ����ŷ ó��
  if (strcmp(var.obs,"ECHO") == 0) {
    if (strcmp(var.cmp,"HSR")  == 0 || strcmp(var.cmp,"HCI") == 0 ||
        strcmp(var.cmp,"HCI2") == 0 || strcmp(var.cmp,"HAIL") == 0) {
      if (strcmp(var.qcd,"QCD") == 0) {
        rdr_cmp_num_mask(2, 6, 40.0);
        if (var.HSR_mask == 0) rdr_cmp_lng_mask("EXT", 0.0);
        if (var.HSR_mask == 0) rdr_cmp_hsr_mask();
      }
      else if (strcmp(var.qcd,"HSR") == 0) {
        rdr_cmp_hsr_mask();
      }
      else if (strcmp(var.qcd,"LNG") == 0) {
        rdr_cmp_lng_mask("QCD", 0.0);
      }
      else if (strcmp(var.qcd,"NUM") == 0) {
        rdr_cmp_num_mask(2, 6, 40.0);
      }
      else if (strcmp(var.qcd,"QPE") == 0) {
        rdr_cmp_num_mask(2, 6, 40.0);
        rdr_cmp_lng_mask("EXT", 0.0);
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  Z-R �����
 *     - mode : 0(dBZ->������), 1(������->dBZ)
 *=============================================================================*/
int dbz_rain_conv(float *dbz1, float *rain1, int mode)
{
  static int first = 0;
  static float za, zb;

  if (first == 0) {
    za = 0.1/var.ZRb;
    zb = log10(var.ZRa)/var.ZRb;
    first = 1;
  }

  if (mode == 0) {
    //*rain1 = (*dbz1*0.1 - log10(var.ZRa) )/var.ZRb;
    *rain1 = *dbz1*za - zb;
    *rain1 = pow(10.0, *rain1);
  }
  else if (mode == 1) {
    *dbz1 = 10.0 * log10( var.ZRa * pow(*rain1, var.ZRb) );
  }
  return 0;
}

/*******************************************************************************
 *  HSR_KMA ���� �ռ��ڷ�� ����ŷ ó��
 *******************************************************************************/
int rdr_cmp_hail_conv()
{
  FILE   *fp;
  short  **hail_ht, *ec, *ht;
  int    i, j;

  // 1. ���� �����ڷ� ����
  hail_ht = smatrix(0, (int)(rdr_cmp_head.ny-1), 0, (int)(rdr_cmp_head.nx-1));
  fp = gzopen(var.fname, "rb");
  gzseek(fp, (long)(sizeof(rdr_cmp_head)+sizeof(rdr_cmp_stn_list)+(rdr_cmp_head.ny*rdr_cmp_head.nx*2)), SEEK_SET);
  for (j = 0; j < rdr_cmp_head.ny; j++)
    gzread(fp, hail_ht[j], (rdr_cmp_head.nx)*2);
  gzclose(fp);

  // 2. ����� ���������� ��ü
  for (j = 0; j < rdr_cmp_head.ny; j++) {
    ec = &echo[j][0];
    ht = &hail_ht[j][0];

    for (i = 0; i < rdr_cmp_head.nx; i++, ec++, ht++) {
      // 2.1. ����̸� ������ �ڵ�(km)�� ��ü
      if (*ec >= 6 && *ec <= 9) {
        if (*ht > 0)
          *ec = (int)(*ht*0.001) + 1;
        else
          *ec = 0;
      }
      // 2.2. ����� �ƴ� ����ü�� ǥ������ ����
      else if (*ec > 0) {
        *ec = 0;
      }
    }
  }

  // 9. �迭 ����
  free_smatrix(hail_ht, 0, (int)(rdr_cmp_head.ny-1), 0, (int)(rdr_cmp_head.nx-1));

  return 0;
}

/*******************************************************************************
 *  HSR_KMA ���� �ռ��ڷ�� ����ŷ ó��
 *******************************************************************************/
int rdr_cmp_hsr_mask()
{
  FILE   *fp;
  char   dname[120];
  struct RDR_CMP_HEAD  cmp_head;              // �ռ��ڷ� HEAD
  struct RDR_CMP_STN_LIST  cmp_stn_list[48];  // �ռ��� ���̴� ���
  short  **dbz1, *ec, *dz;
  int    YY, MM, DD, HH, MI;
  int    i, j;

  // 2. HSR_KMA �ռ��ڷ� �б�
  if (rdr_cmp_file(var.seq, "HSR", "NQC", var.dir_mode, dname) < 0) return -1;

  fp = gzopen(dname, "rb");
  if (fp != NULL) {
    gzread(fp, &cmp_head, sizeof(cmp_head));
    gzread(fp, cmp_stn_list, sizeof(cmp_stn_list));
    dbz1 = smatrix(0, (int)(cmp_head.ny-1), 0, (int)(cmp_head.nx-1));
    for (j = 0; j < cmp_head.ny; j++)
      gzread(fp, dbz1[j], (cmp_head.nx)*2);
    gzclose(fp);
    var.HSR_mask = 1;
  }
  else
    var.HSR_mask = 0;

  // 4. ��ȯ �� �迭 ����
  if (var.HSR_mask) {
    // 4.1. ��ȯ
    for (j = 0; j < cmp_head.ny; j++) {
      ec = &echo[j][0];
      dz = &dbz1[j][0];
      for (i = 0; i < cmp_head.nx; i++, ec++, dz++) {
        if (*ec > BLANK3) {
          if (*dz > BLANK1 && *dz <= BLANK3) *ec = BLANK3;
        }
      }
    }

    // 4.2. �迭 ����
    free_smatrix(dbz1, 0, (int)(cmp_head.ny-1), 0, (int)(cmp_head.nx-1));
  }
  return 0;
}

/*******************************************************************************
 *  480km ���� �ռ��ڷ�� 240km ����ŷ ó��
 *******************************************************************************/
int rdr_cmp_lng_mask(
  char  *qcd,
  float dbz_inp
)
{
  FILE   *fp;
  char   dname[2][120];
  struct stat st;
  struct RDR_CMP_HEAD  cmp_head;              // �ռ��ڷ� HEAD
  struct RDR_CMP_STN_LIST  cmp_stn_list[48];  // �ռ��� ���̴� ���
  short  dbz_base = (short)(dbz_inp*100);     // ���� DBZ��(*100)
  short  **dbz1, *dbz2, *ec, *dz1, *dz2, *dz;
  int    com_DX, com_DY, lng_ok;
  int    seq, YY, MM, DD, HH, MI;
  int    i, j, i1, j1, k, code;

  // 1. var.seq�������� ���� 2���� LNG ������ ���ļ� �����
  var.HSR_mask = 0;   // �ʱ�ȭ
  lng_ok = 0;
  seq = var.seq;
  if (rdr_cmp_file(seq, "LNG", qcd, var.dir_mode, dname[0]) >= 0) {
    lng_ok = 1;
    if (rdr_cmp_file(seq+10, "LNG", qcd, var.dir_mode, dname[1]) >= 0) lng_ok += 10;
  }
  else if (rdr_cmp_file(seq+5, "LNG", qcd, var.dir_mode, dname[0]) >= 0) {
    lng_ok = 1;
    if (rdr_cmp_file(seq-5, "LNG", qcd, var.dir_mode, dname[1]) >= 0) lng_ok += 10;
  }
  else if (rdr_cmp_file(seq-5, "LNG", qcd, var.dir_mode, dname[0]) >= 0) {
    lng_ok = 1;
  }
  if (lng_ok == 0) return -1;

  // 2. LNG ���� �а�, ��ġ��
  fp = gzopen(dname[0],"rb");
  if ((fp = gzopen(dname[0],"rb")) != NULL) {
    gzread(fp, &cmp_head, sizeof(cmp_head));
    gzread(fp, cmp_stn_list, sizeof(cmp_stn_list));
    dbz1 = smatrix(0, (int)(cmp_head.ny-1), 0, (int)(cmp_head.nx-1));
    for (j = 0; j < cmp_head.ny; j++)
      gzread(fp, dbz1[j], (cmp_head.nx)*2);
    gzclose(fp);
  }
  else
    return -2;

  if (lng_ok > 1) {
    if ((fp = gzopen(dname[0],"rb")) != NULL) {
      gzread(fp, &cmp_head, sizeof(cmp_head));
      gzread(fp, cmp_stn_list, sizeof(cmp_stn_list));
      dbz2 = svector(0, (int)(cmp_head.nx-1));
      for (j = 0; j < cmp_head.ny; j++) {
        gzread(fp, dbz2, (cmp_head.nx)*2);

        dz1 = &dbz1[j][0];
        dz2 = &dbz2[0];
        for (i = 0; i < cmp_head.nx; i++, dz1++, dz2++) {
          if (*dz1 < *dz2) *dz1 = *dz2;
        }
      }
      gzclose(fp);
      free_svector(dbz2, 0, (int)(cmp_head.nx-1));
    }
  }
  var.HSR_mask = 1;

  // 4. ��ȯ �� �迭 ����
  if (var.HSR_mask) {
    // 4.1. ��ȯ
    com_DX = (HC_SX - HB_SX);
    com_DY = (HC_SY - HB_SY);

    for (j = 0; j < rdr_cmp_head.ny; j++) {
      j1 = j/2 + com_DY;
      ec = &echo[j][0];
      dz = &dbz1[j1][com_DX];

      for (i = 0; i < rdr_cmp_head.nx; i++, ec++) {
        //i1 = i/2 + com_DX;

        if (*ec > BLANK3) {
          if (*dz < dbz_base && *dz > BLANK1) *ec = BLANK3;
        }
        if (i%2 == 1) dz++;
      }
    }

    // 4.2. �迭 ����
    free_smatrix(dbz1, 0, (int)(cmp_head.ny-1), 0, (int)(cmp_head.nx-1));
  }
  return 0;
}

/*******************************************************************************
 *  NUM ���� �����ڷ�� 240km ����ŷ ó��
 *******************************************************************************/
int rdr_cmp_num_mask(
  int    DBZ_NUM,   // ����dBZ (1=-5dBZ, 2=0dBZ(default), 3=5dBZ, 4=10dBZ, 5=15dBZ, 6=20dBZ)
  int    GRID_WN,   // +-���ڼ�(default=4)
  float  RATE_BASE  // ���� ����(�� ���ڿ��������� �ִ밪, default=50))
)
{
  FILE   *fp;
  char   dname[120];
  struct stat st;
  struct RDR_CMP_HEAD  cmp_head;              // �ռ��ڷ� HEAD
  struct RDR_CMP_STN_LIST  cmp_stn_list[48];  // �ռ��� ���̴� ���
  unsigned char  **num_echo, **num_base, *ne, *nb;
  short  *ec;
  float  rate_num, r1;
  float  blank;
  int    seq, YY, MM, DD, HH, MI;
  int    i, j, k, i1, j1, n1, n2, code;

  // 1. �ڷ������ ó��
  blank = BLANK3;
  if (strcmp(var.cmp,"HCI") == 0 || strcmp(var.cmp,"HCI2") == 0 || strcmp(var.cmp,"HAIL") == 0) blank = 0;

  // 2. ����Ȯ�� �ռ��ڷ� �б�
  var.HSR_mask = 0;   // �ʱ�ȭ
  for (k = 0; k < 3; k++) {
    // 2.1. ���� ã��(����: ����, 5����, 5����)
    if      (k == 0) seq = var.seq;
    else if (k == 1) seq = var.seq + 5;
    else if (k == 2) seq = var.seq - 5;

    // 2.2. ���� ���� ���� Ȯ��
    if (rdr_cmp_file(seq, "NUM", "EXT", var.dir_mode, dname) < 0) continue;

    // 2.3. ������ ������ ����
    fp = gzopen(dname, "rb");
    if (fp != NULL) {
      gzread(fp, &cmp_head, sizeof(cmp_head));
      gzread(fp, cmp_stn_list, sizeof(cmp_stn_list));
      num_base = cmatrix(0, (int)(cmp_head.ny-1), 0, (int)(cmp_head.nx-1));
      num_echo = cmatrix(0, (int)(cmp_head.ny-1), 0, (int)(cmp_head.nx-1));

      for (j = 0; j < cmp_head.ny; j++)
        gzread(fp, num_base[j], cmp_head.nx);

      if (DBZ_NUM > 1) gzseek(fp, (long)(cmp_head.ny*cmp_head.nx*(DBZ_NUM-1)), SEEK_CUR);
      for (j = 0; j < cmp_head.ny; j++)
          gzread(fp, num_echo[j], (cmp_head.nx));
      gzclose(fp);
      var.HSR_mask = 1;
    }
    if (var.HSR_mask) break;  // ������ ��������
  }

  // 4. ��ȯ �� �Ǵ�
  if (var.HSR_mask) {
    // 4.1. ���� ���
    for (j = 0; j < cmp_head.ny; j++) {
      nb = &num_base[j][0];
      ne = &num_echo[j][0];
      for (i = 0; i < cmp_head.nx; i++, nb++, ne++) {
        if (*nb > 1 && *nb < 200) {
          if (*ne >= 0 && *ne < 200)
            r1 =  100.0*(float)(*ne)/(float)(*nb);
          else
            r1 = 0;
        }
        else
          r1 = 230;
        *ne = (int)(r1);
      }
    }

    // 4.2. Ȯ��
    if (GRID_WN > 0) grid_max_change1(num_echo, cmp_head.nx, cmp_head.ny, GRID_WN);

    // 4.3. �Ǵ�
    for (j = 0; j < cmp_head.ny; j++) {
      ne = &num_echo[j][0];
      ec = &echo[j][0];
      for (i = 0; i < cmp_head.nx; i++, ne++, ec++) {
        if (*ec > blank) {
          if (*ne >= 0 && *ne < 200 && *ne < RATE_BASE) *ec = blank;
        }
      }
    }

    // 4.4. �迭 ����
    free_cmatrix(num_echo, 0, (int)(cmp_head.ny-1), 0, (int)(cmp_head.nx-1));
    free_cmatrix(num_base, 0, (int)(cmp_head.ny-1), 0, (int)(cmp_head.nx-1));
  }
  return 0;
}

/*=============================================================================*
 *  �ڷ� �ִ밪���� ġȯ.Ȯ��
 *=============================================================================*/
int grid_max_change1(
  unsigned char  **g,   // ��������Ȯ��
  int nx,   // X�� ���ڼ�
  int ny,   // Y�� ���ڼ�
  int wn    // Ȯ����ڼ�
)
{
  unsigned char *g1, *g2;
  int  i, j, k;
  if (wn <= 0) return 0;

  // wn�� �ݺ�
  for (k = 0; k < wn; k++) {
    // y�ະ��, x�� �������� Ȯ��
    for (j = 0; j < ny; j++) {
      // ���� -> ������
      for (g1 = &(g[j][0]), g2 = &(g[j][1]), i = 0; i < nx-1; i++, g1++, g2++) {
        if (*g1 < *g2) *g1 = *g2;
      }
      // ������ -> ����
      for (g1 = &(g[j][nx-1]), g2 = &(g[j][nx-2]), i = nx-1; i >= 1; i--, g1--, g2--) {
        if (*g1 < *g2) *g1 = *g2;
      }
    }

    // x�ະ��, y�� �������� Ȯ�� (�Ʒ� -> ��)
    for (j = 0; j < ny-1; j++) {
      for (g1 = &(g[j][0]), g2 = &(g[j+1][0]), i = 0; i < nx; i++, g1++, g2++) {
        if (*g1 < *g2) *g1 = *g2;
      }
    }
    // x�ະ��, y�� �������� Ȯ�� (�� -> �Ʒ�)
    for (j = ny-1; j >= 1; j--) {
      for (g1 = &(g[j][0]), g2 = &(g[j-1][0]), i = 0; i < nx; i++, g1++, g2++) {
        if (*g1 < *g2) *g1 = *g2;
      }
    }
  }
  return 0;
}

/*******************************************************************************
 *  Grid data Smoothing (by 1-2-1 Smoothing)
 *  by ����ȯ (1997. 3. 15)
 *******************************************************************************/
int grid_smooth (
  short **g,      // input -> output
  int   nx,       // ���� [0:nx-1,0:ny-1]
  int   ny,
  float missing   // ���ϴ� �ڷ� ����
)
{
  short  *e1, *e2, *e3, *e4;
  short  v1, v2, *v4;
  int    i, j;

  // 1. Y�� ��������, X�� �������� ��Ȱȭ�Ѵ�.
  for (j = 0; j < ny; j++) {
    e1 = &g[j][0];
    e2 = &g[j][1];
    e3 = &g[j][2];
    v1 = *e1;

    for (v1 = *e1, i = 1; i < nx-1; i++, e1++, e2++, e3++) {
      if (*e1 > missing && *e2 > missing && *e3 > missing)
        v2 = (*e1 + 2*(*e2) + *e3) / 4;
      else if (*e1 > missing && *e2 <= missing && *e3 > missing)
        v2 = (*e1 + *e3) / 2;
      else
        v2 = *e2;

      (*e1) = v1;
      v1 = v2;
    }
    (*e1) = v1;
  }

  // 2. X�� ��������, Y�� �������� ��Ȱȭ�Ѵ�.
  v4 = svector(0, nx-1);    // �迭 �غ�
  for (j = 1; j < ny-1; j++) {
    e1 = &g[j-1][0];
    e2 = &g[j][0];
    e3 = &g[j+1][0];
    e4 = &v4[0];

    for (i = 0; i < nx; i++, e1++, e2++, e3++, e4++) {
      if (*e1 > missing && *e2 > missing && *e3 > missing)
        v2 = (*e1 + 2*(*e2) + *e3) / 4;
      else if (*e1 > missing && *e2 <= missing && *e3 > missing)
        v2 = (*e1 + *e3) / 2;
      else
        v2 = *e2;

      if (j > 1) (*e1) = *e4;
      *e4 = v2;
    }
  }
  for (i = 0; i < nx; i++)
    (*e1) = *e4;

  // �迭 ����
  free_svector(v4, 0, nx-1);
  return 0;
}

/*=============================================================================*
 *  ���̴� �ռ��ڷ� ���� ���� Ȯ��
 *=============================================================================*/
int rdr_cmp_file(
  int  seq,
  char *cmp,
  char *qcd,
  int  dir_mode,
  char *dname
)
{
  struct stat st;
  char   sname[120];
  int    YY, MM, DD, HH, MI;
  int    data, code, rtn;

  // 1. �ڷ� �ð�
  seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  // 2. ���ϸ�
  if (strstr(cmp,"HSR") != NULL) {
    if (strcmp(qcd,"NQC") == 0)
      sprintf(sname, "RDR_CMP_HSR_KMA_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    else
      sprintf(sname, "RDR_CMP_HSR_EXT_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    if (dir_mode == 1)
      sprintf(dname, "%s/%s", RDR_FTP_HSR, sname);
    else
      sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }
  else if (strstr(cmp,"LNG") != NULL) {
    sprintf(sname, "RDR_CMP_%s_%s_%04d%02d%02d%02d%02d.bin.gz", cmp, qcd, YY, MM, DD, HH, MI);
    if (dir_mode == 1)
      sprintf(dname, "%s/%s", RDR_FTP_LNG, sname);
    else
      sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }
  else if (strstr(cmp,"HCI") != NULL) {
    if (strcmp(qcd,"NQC") == 0)
      sprintf(sname, "RDR_CMP_HCI_KMA_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    else
      sprintf(sname, "RDR_CMP_HCI_EXT_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    if (dir_mode == 1)
      sprintf(dname, "%s/%s", RDR_FTP_HCI, sname);
    else
      sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }
  else if (strstr(cmp,"HAIL") != NULL) {
    if (strcmp(qcd,"EXT") == 0)
      sprintf(sname, "RDR_CMP_HAIL_EXT_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    else
      sprintf(sname, "RDR_CMP_HAIL_KMA_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    if (dir_mode == 1)
      sprintf(dname, "%s/%s", RDR_FTP_HCI, sname);
    else
      sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }
  else if (strstr(cmp,"NUM") != NULL) {
    sprintf(sname, "RDR_CMP_%s_%s_%04d%02d%02d%02d%02d.bin.gz", cmp, qcd, YY, MM, DD, HH, MI);
    if (dir_mode == 1)
      sprintf(dname, "%s/%s", RDR_FTP_NUM, sname);
    else
      sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }
  else if (strstr(cmp,"PCP") != NULL) {
    if (strcmp(cmp,"PCPH") == 0) {        // HSR ����
      if (strcmp(qcd,"EXT") == 0)
        sprintf(sname, "RDR_PCP_HSR_EXT_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
      else if (strcmp(qcd,"KMA") == 0 || strcmp(qcd,"NQC") == 0)
        sprintf(sname, "RDR_PCP_HSR_KMA_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
      else if (strcmp(qcd,"MSK") == 0 || strcmp(qcd,"QCD") == 0)
        sprintf(sname, "RDR_PCP_HSR_MSK_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    }
    else if (strcmp(cmp,"PCPP") == 0) {   // PPI ����
      if (strcmp(qcd,"EXT") == 0)
        sprintf(sname, "RDR_PCP_PPI_EXT_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
      else if (strcmp(qcd,"KMA") == 0 || strcmp(qcd,"NQC") == 0)
        sprintf(sname, "RDR_PCP_PPI_NQC_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
      else if (strcmp(qcd,"MSK") == 0 || strcmp(qcd,"QCD") == 0)
        sprintf(sname, "RDR_PCP_PPI_QCD_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    }
    if (dir_mode == 1)
      sprintf(dname, "%s/%s", RDR_FTP_PCP, sname);
    else
      sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_PCP_DIR, YY, MM, DD, sname);
  }
  else {
    sprintf(sname, "RDR_CMP_%s_%s_%04d%02d%02d%02d%02d.bin.gz", cmp, qcd, YY, MM, DD, HH, MI);
    if (dir_mode == 1)
      sprintf(dname, "%s/%s", RDR_FTP_WRC, sname);
    else
      sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }

  // 3. ���� ���� ���� Ȯ��
  code = stat(dname, &st);
  if (code < 0 || st.st_size <= 100)
    rtn = -1;
  else
    rtn = 0;
  return rtn;
}

/*=============================================================================*
 *  ���� ���� ���� �б�
 *
 *      map : inp:������ ����
 *      nx  : out:�������� �������� (km)
 *      ny  : out:���Ϲ��� �������� (km)
 *      sx  : out:�������� ������ġ (km)
 *      sy  : out:���Ϲ��� ������ġ (km)
 *=============================================================================*/
int grid_map_inf(char *map, int *nx, int *ny, int *sx, int *sy)
{
  FILE  *fp;
  char  buf[1024], map_list[8], value[16];

  fp = fopen(MAP_INI_FILE,"r");
  if (fp == NULL) exit(-1);

  while (fgets(buf,1024,fp)) {
    if (buf[0] == '#') continue;
    getword(map_list, buf, ':');

    if ( !strcmp(map, map_list) ) {
      getword(value, buf, ':');  *nx = atoi(value);
      getword(value, buf, ':');  *ny = atoi(value);
      getword(value, buf, ':');  *sx = atoi(value);
      getword(value, buf, ':');  *sy = atoi(value);
      break;
    }
  }
  fclose(fp);
  return 0;
}
