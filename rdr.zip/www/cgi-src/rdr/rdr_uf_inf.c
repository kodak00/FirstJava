/******************************************************************************
**
**  UF RADAR �ڷ� Header ���� ��ȸ�� CGI ���α׷�
**
**============================================================================*
**
**     o �ۼ��� : ����ȯ (2006. 3. 9)
**
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "/ncomis/src/include/cgiutil.h"
#include "/usr/local/trmm/include/rsl.h"

#define  RDR_UF_DIR  "/ncomis/rdr/raw"

struct INPUT_VAR
{
    char stn_cd[16];
    int  YY;
    int  MM;
    int  DD;
    int  HH;
    int  MI;
    int  volume;
    int  sweep;
} var;

/******************************************************************************
 *
 *  MAIN
 *
 ******************************************************************************/
int main()
{
    int  code;

    /*
    �ʱ�ȭ
    */

    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(120);

    printf("HTTP/1.0 200 OK\n");
    printf("Server: Netscape-Enterprise/3.0\n");

    /*
    ����� ��û�ڷ�
    */

    if ((code = Input()) < 0)
    {
        printf("Content-type: text/html\n\n");
        printf(" input variable error (%d)<p>\n", code);
        return -1;
    }

    /*
    ��� ǥ��
    */

    disp_html();
 
    alarm(0);
    return 0;
}

/******************************************************************************
 *
 *  ����� ��û�ڷ� �м�
 *
 ******************************************************************************/
int Input()
{
    char *qs;
    char value[32][120];
    char times[32], tmp[32];
    int  time1, time2, dtime;
    int  iYY, iMM, iDD, iHH, imin, sec;
    int  iseq, i;

    /*
    ȯ�溯������ �а�, �׸� �и�
    */

    qs = getenv("QUERY_STRING");
    if (qs == NULL) return -1;

    for (i = 0; qs[0] != '\0'; i++)
        getword(value[i], qs, '&');

    /*
    ���� �Ҵ�
    */

    strcpy(var.stn_cd, value[0]);
    strcpy(times, value[1]);
    var.volume = atoi(value[2]);
    var.sweep  = atoi(value[3]);

    /*
    �ð� ����
    */

    strncpy(tmp, &times[0], 4);  tmp[4] = '\0';  var.YY = atoi(tmp);
    strncpy(tmp, &times[4], 2);  tmp[2] = '\0';  var.MM = atoi(tmp);
    strncpy(tmp, &times[6], 2);  tmp[2] = '\0';  var.DD = atoi(tmp);
    strncpy(tmp, &times[8], 2);  tmp[2] = '\0';  var.HH = atoi(tmp);
    strncpy(tmp, &times[10],2);  tmp[2] = '\0';  var.MI = atoi(tmp);

    return 0;
}

/******************************************************************************
 *
 *  HTML mode
 *
 ******************************************************************************/
int disp_html()
{
    struct stat st;
    char   fname[120];
    Radar  *radar;

    printf("Content-type: text/html\n\n");

    /*
    Head Part
    */

    printf("<HTML>\n");
    printf("<HEAD>\n");

    printf("<style type=\"text/css\">\n");
    printf("<!--\n");
    printf(":link    {text-decoration:none}\n");
    printf(":active  {text-decoration:none}\n");
    printf(":visited {text-decoration:none; color=#0000ff;}\n");
    printf(".head    {font-family:gulim,Verdana; font-size:12pt; color:#000000; font-weight:bold;}\n");
    printf(".name    {font-family:gulim,Verdana; font-size:11pt; color:#000000; font-weight:bold;}\n");
    printf(".text    {font-family:����ü,Verdana; font-size:9pt; color:#000000;}\n");
    printf(".textr   {font-family:����ü,Verdana; font-size: 9pt; color:#0000ff;}\n");
    printf("-->\n");
    printf("</style>\n");

    printf("<SCRIPT LANGUAGE='JavaScript'>\n");
    printf("<!--\n");
    printf("function rdr_info(stn_cd, tm, volume, sweep) \n");
    printf("{\n");
    printf("  url = \"/cgi-bin/RDR/nph-rdr_uf_inf?\" + stn_cd + \"&\" + tm + \"&\" + volume + \"&\" + sweep; \n");
    printf("  target = stn_cd + \"_\" + tm + \"_\" + volume + \"_\" + sweep; \n");
    printf("  stat = \"toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=400,height=500,alwaysRaised=yes\"; \n");
    printf("  remote = window.open(url, target, stat); \n");
    printf("}\n");

    printf("// -->\n");
    printf("</SCRIPT>\n");
    printf("</HEAD>\n");

    /*
    Body Part
    */

    printf("<BODY bgcolor=#ffffff topmargin=3 leftmargin=3 marginwidth=3 marginheight=3 class=text>\n");

    sprintf(fname, "%s/%04d%02d/%02d/RDR_%s_%04d%02d%02d%02d%02d.uf",
            RDR_UF_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);

    printf("<span class=name>RDR_%s_%04d%02d%02d%02d%02d.uf</span>",
            var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);

    if (stat(fname, &st) != 0)
    {
        printf(" : ������ �����ϴ�.\n");
        printf("</BODY></HTML>\n");
        return -1;
    }
    else
    {
        printf(" (%d bytes)<br>\n", st.st_size);
    }

    /*
    ���� ����
    */

    radar = RSL_uf_to_radar(fname);
    if (radar == NULL)
    {
        printf("radar error\n");
        printf("</BODY></HTML>\n");
        return -1;
    }


    if (var.volume < 0)
    {
        disp_total(radar);
    }
    else
    {
        disp_sweep(radar);
    }

    /*
    ���� �ݱ�
    */

    RSL_free_radar(radar);

    printf("</BODY></HTML>\n");

    return 0;
}

/*============================================================================*
 *
 *  ��ü
 *
 *============================================================================*/
int disp_total(Radar  *radar)
{
    Volume *volume;
    Sweep  *sweep;
    Ray    *ray;
    int    nbins, nbins_min, nbins_max, gate_size;
    int    i, j, k;

    printf("<pre class=text>\n");

    /*
    radar header
    */

    Radar_info(radar);

    /*
    volume header
    */

    printf("+------+--------------------+------------+\n");
    printf("| Vol. | Sweep / elev/ nray | gate/ nbin |\n");
    printf("+------+--------------------+------------+\n");

//    for (k = 0; k < radar->h.nvolumes; k++)
    for (k = 0; k < 4; k++)
    {
        printf("| %2d ", k);

        volume = radar->v[k];

        if (volume == NULL)
        {
            printf("  |                    |            |\n");
            printf("+------+--------------------+------------+\n");
            continue;
        }
        else
        {
            printf("* | %2d                 |            |\n", volume->h.nsweeps);
        }

        for (j = 0; j < volume->h.nsweeps; j++)
        {
            /*
            printf("|      |<a href='/cgi-bin/RDR/nph-rdr_uf_inf?%s&%04d%02d%02d%02d%02d&%d&%d' target='%s_%04d%02d%02d%02d%02d_%d_%d'> %2d </a>",
                    var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI, k, j,
                    var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI, k, j, j);
            */
            printf("|      |<a href='javascript:rdr_info(\"%s\",\"%04d%02d%02d%02d%02d\", \"%d\", \"%d\");'> %2d </a>",
                    var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI, k, j, j);

            sweep = volume->sweep[j];
            if (sweep == NULL)
            {
                printf("         |");
                continue;
            }
            else
            {
                printf("* %8.4f %4d |", sweep->h.elev, sweep->h.nrays);
            }

            nbins_max = -1;
            nbins_min = 999999;

            for (i = 0; i < sweep->h.nrays; i++)
            {
                ray = sweep->ray[i];
                if (ray != NULL)
                {
                    nbins = ray->h.nbins;
                    gate_size = ray->h.gate_size;
                    break;
                }
            }
            printf(" %5d %4d |\n", gate_size, nbins);
        }
        printf("+------+--------------------+------------+\n");
    }

    printf("</pre>\n");

    return 0;
}

int Radar_info(Radar *radar)
{
    printf(" o time = %04d.%02d.%02d.%02d.%02d(%f)\n",
                      radar->h.year, radar->h.month, radar->h.day, radar->h.hour,
                      radar->h.minute, radar->h.sec);
    printf(" o radar_type = %s\n", radar->h.radar_type);
    printf(" o nvolumes = %d\n", radar->h.nvolumes);
    printf(" o number = %d\n", radar->h.number);
    printf(" o name = %s\n", radar->h.name);
    printf(" o radar_name = %s\n", radar->h.radar_name);
    printf(" o project = %s\n", radar->h.project);
    printf(" o city = %s\n", radar->h.city);
    printf(" o state = %s\n", radar->h.state);
    printf(" o latitude = %3d.%02d.%02d\n", radar->h.latd, radar->h.latm, radar->h.lats);
    printf(" o longitude = %3d.%02d.%02d\n", radar->h.lond, radar->h.lonm, radar->h.lons);
    printf(" o height = %d\n", radar->h.height);
    printf(" o spulse = %d\n", radar->h.spulse);
    printf(" o lpulse = %d\n", radar->h.lpulse);
    return 0;
}

/*============================================================================*
 *
 *  1�� ����
 *
 *============================================================================*/
int disp_sweep(Radar *radar)
{
    Volume *volume;
    Sweep  *sweep;
    Ray    *ray;
    int    i;

    printf("<pre class=text>\n");

    volume = radar->v[var.volume];
    sweep = volume->sweep[var.sweep];

    printf(" o volume = %d\n", var.volume);
    printf(" o sweep  = %d\n", var. sweep);

    printf("+-----+---------+-----+------+------+-------+--------+\n");
    printf("| num | Azimuth |nbins| bin1 | gate | width | nyq_vel|\n");
    printf("|     |  (deg.) |   # |  (m) |  (m) | (deg) |  (m/s) |\n");
    printf("+-----+---------+-----+------+------+-------+--------+\n");

    for (i = 0; i < sweep->h.nrays; i++)
    {
        if ((ray = sweep->ray[i]) != NULL)
        {
            printf("|%4d ", ray->h.ray_num);
            printf("|%8.3f ", ray->h.azimuth);
            printf("|%4d ", ray->h.nbins);
            printf("|%5d ", ray->h.range_bin1);
            printf("|%5d ", ray->h.gate_size);
            printf("|%6.3f ", ray->h.beam_width);
            printf("|%7.3f ", ray->h.nyq_vel);
            printf("|\n");
        }
    }
    printf("+-----+---------+-----+------+------+-------+--------+\n");
    printf("</pre>\n");

    return 0;
} 