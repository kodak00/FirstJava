/*******************************************************************************
**
**  ���̴� �ռ��ڷ� ǥ��
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.7.18)
**
********************************************************************************/
#include "rdr_cmp1_img.h"

//------------------------------------------------------------------------------
// ����ü�� ����ǥ
// ����ü ����
#define  NUM_HCI_COLOR  7
#define  NUM_HCI_DETAIL_COLOR  16

// ����ü �׷캰 ����ǥ
struct RDR_HCI_COLOR {
  int  hci;
  char hci_ko[10];
  int  color;
  int  R;
  int  G;
  int  B;
} hci_color[NUM_HCI_COLOR] = {
  {0,"����",    0,255,255,255},
  //{1,"�񰭼�",  0,102,255,102},
  {1,"�񰭼�",  0,210,210,210},
  {2,"����",    0,245,255,102},
  {3,"��",      0,255,102,255},
  {4,"����",    0,102,255,255},
  {5,"��",      0, 51,102,255},
  {6,"���",    0,255, 51,  0},
};

// ����ü �󼼺з���(NCAR) ����ǥ
struct RDR_HCI_DETAIL_COLOR {
  int  hci;
  char hci_ko[40];
  int  color;
  int  R;
  int  G;
  int  B;
} hci_detail_color[NUM_HCI_DETAIL_COLOR] = {
  { 0,"����",     0,255,255,255},
  { 1,"����",     0,204,255,204},
  { 2,"�̽���",   0,153,204,255},
  { 3,"���Ѻ�",   0,102,153,255},
  { 4,"�߰���",   0, 51,102,255},
  { 5,"���Ѻ�",   0, 51, 51,204},
  { 6,"���",     0,255,  0,  0},
  { 8,"��ڽζ�", 0,255,102,  0},
  { 7,"���/ ��", 0,255,153,153},
  { 9,"�ζ�/ ��", 0,255,204,204},
  {10,"�Ǽ�",     0,255,153,255},
  {11,"����",     0,102,255,255},
  {14,"���ð�",   0, 51,204,204},
  {12,"������", 0,245,255,  0},
  {13,"����",   0,255,204,  0},
  {50,"�񰭼�",   0,210,210,210},
};

/* ����
  { 0,"����",     0,255,255,255},
  { 1,"����",     0,204,255,204},
  { 2,"�̽���",   0,153,204,255},
  { 3,"���Ѻ�",   0,102,153,255},
  { 4,"�߰���",   0, 51,102,255},
  { 5,"���Ѻ�",   0, 51, 51,204},
  { 6,"���",     0,255, 51,  0},
  { 7,"���/ ��", 0,255,102,  0},
  { 8,"��ڽζ�", 0,255,153,153},
  { 9,"�ζ�/ ��", 0,255,204,204},
  {10,"�Ǽ�",     0,255,102,255},
  {11,"����",     0,102,255,255},
  {14,"���ð�",   0, 51,204,204},
  {12,"������", 0,245,255,102},
  {13,"����",   0,255,204,102},
  {50,"�񰭼�",   0,210,210,210},
*/

//------------------------------------------------------------------------------
// ��� ������ ����ǥ
// ��� ���� ����
#define  NUM_HAIL_COLOR  7

// ��� ������ ����ǥ
struct RDR_HAIL_COLOR {
  int  hail;
  char hail_ko[10];
  int  color;
  int  R;
  int  G;
  int  B;
} hail_color[NUM_HAIL_COLOR] = {
  {0,"����",0,255,255,255},
  {1,"1km", 0,255, 51,  0},
  {2,"2km", 0,255,153, 51},
  {3,"3km", 0,  0,128,  0},
  {4,"4km", 0, 51,204, 51},
  {5,"5km", 0,102,255,102},
  {6,"5km", 0,153,255,204},
};

//------------------------------------------------------------------------------
// ������ ����ǥ
// ������
#define  NUM_STN_COLOR  18

// ����ǥ
struct RDR_STN_COLOR {
  char stn_cd[8];
  char stn_ko[20];
  int  color;
  int  R;
  int  G;
  int  B;
} stn_color[NUM_STN_COLOR] = {
  {"BRI","��ɵ�",  0, 255, 82,  0},
  {"IIA","��õ����",0,   0,255,255},
  {"KWK","���ǻ�",  0, 173,  7,255},
  {"GDK","������",  0,   0,213,  0},
  {"GNG","����",    0, 255,165,  0},
  {"KSN","������",  0, 238,238, 73},
  {"JNI","����",    0,  73,238,238},
  {"MYN","�����",  0,   0,172,255},
  {"PSN","������",  0, 105,252,105},
  {"GSN","����",    0, 218,135,255},
  {"SSP","����",    0, 204,170,  0},
  {"RKSG","����U",  0, 233,147,106},
  {"RKJK","����U",  0,   0,102,255},
  {"GRS","������",  0, 249,205,  0},
  {"SBS","�ҹ��",  0,  76, 78,177},
  {"SDS","�����",  0,   0,128,  0},
  {"MHS","���Ļ�",  0,  31, 33,157},
  {"BSL","�񽽻�",  0, 250,133,133}
};

//------------------------------------------------------------------------------
// ������ �������̵��� ������ ����ǥ
// ������
#define  NUM_STN_SR1_COLOR  10

// ����ǥ
struct RDR_STN_SR1_COLOR {
  char stn_cd[8];
  char stn_ko[20];
  int  color;
  int  R;
  int  G;
  int  B;
} stn_sr1_color[NUM_STN_SR1_COLOR] = {
  {"DJK","������",  0,  31, 33,157},
  {"SRI","������",  0, 255,165,  0},
  {"MIL","���ϻ�",  0,   0,128,  0},
  {"BRI","��ɵ�",  0, 255, 82,  0},
  {"IIA","��õ����",0,   0,255,255},
  {"KWK","���ǻ�",  0, 173,  7,255},
  {"GDK","������",  0,   0,213,  0},
  {"KSN","������",  0, 238,238, 73},
  {"RKSG","����U",  0, 233,147,106},
  {"RKJK","����U",  0,   0,102,255},
};

struct INPUT_VAR  var;
struct STN_VAL  stn_data[MAX_STN];

struct RDR_PCP_HEAD  rdr_pcp_head;      // PCP�ռ� Header
struct RDR_CMP_HEAD  rdr_cmp_head;              // �ռ��ڷ� Header
struct RDR_CMP_STN_LIST  rdr_cmp_stn_list[48];  // �ռ��� ���̴� ���
short  **echo;
unsigned char  **num_echo, **num_base;
float  **rain;

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main()
{
  int   err = 0;
  float km_px;
  int   num_sm, i;

  // 1. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(20);

  printf("HTTP/1.0 200 OK\n");
  //printf("Content-type: text/plain\n\n");

  // 2. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    err = 1;
  }

  // 3. ���̴��ڷḦ ���� (HSR,QCD�ΰ�� ����ŷ�� ������ ����)
  if (strstr(var.cmp,"PCP") != NULL) {
    if (rdr_cmp_pcp_get() < 0) err = 2;
  }
  else {
    if (rdr_cmp_get() < 0) err = 2;
  }

  // 4. ���� ó��
  if (err > 0) {
    rdr_cmp_err_img(err);
    return 0;
  }

  // 5. �������� �ϰ�, Ȯ�� ó��
  if (var.aws > 0 && var.zoom_level > 0) {
    aws_info_get();
    aws_data_get();
    aws_zooming();
  }

  // 6. ��Ȱȭ
  if ((!strcmp(var.cmp,"HSR") || !strcmp(var.cmp,"PPI") || !strcmp(var.cmp,"CPP") ||
       !strcmp(var.cmp,"CMX") || !strcmp(var.cmp,"LNG") || !strcmp(var.cmp,"LQC"))
       && !strcmp(var.obs,"ECHO")) {
    km_px = ((float)var.NX/var.grid) / (float)(var.size*(var.zoom_level+1)); // Pixel�� ���ڼ�

    if (km_px >= 1.0)
      var.sms += (int)(km_px + 0.5);
    else if (km_px >= 0.5)
      var.sms += 1;

    if (var.sms > 3) var.sms = 3;  // ���ϰ氨����

    for (i = 0; i < var.sms; i++)
      grid_smooth(echo, (int)(rdr_cmp_head.nx), (int)(rdr_cmp_head.ny), BLANK3);
  }


  // 7. �̹��� ���� �� ����
  rdr_cmp_img();

  // 8. �޸� �ݳ�
  if (strstr(var.cmp,"PCP") != NULL)
    free_matrix(rain, 0, (int)(rdr_pcp_head.ny-1), 0, (int)(rdr_pcp_head.nx-1));
  else if (strcmp(var.cmp,"NUM") == 0)
    free_cmatrix(num_echo, 0, (int)(rdr_cmp_head.ny-1), 0, (int)(rdr_cmp_head.nx-1));
  else
    free_smatrix(echo, 0, (int)(rdr_cmp_head.ny-1), 0, (int)(rdr_cmp_head.nx-1));

  alarm(0);
  return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
  char *qs;
  char tmp[256], item[32], value[32], tm[30];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, i, j;

  // 1. ���� �ʱⰪ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "0");        // ����ð�
  strcpy(var.map, "HR");  // ���̴� ����
  var.zoom_level = 0;     // ��ü����
  var.zoom_rate = 2;      // 2�� Ȯ�밡 �⺻
  var.ZRa = 200;
  var.ZRb = 1.6;
  var.num_gov = 0;
  var.aws = 0;
  var.sms = 1;
  var.legend = 1;
  var.dir_mode = 0;

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"cmp")) strcpy(var.cmp, value);
    else if ( !strcmp(item,"obs")) strcpy(var.obs, value);
    else if ( !strcmp(item,"qcd")) strcpy(var.qcd, value);
    else if ( !strcmp(item,"map")) strcpy(var.map, value);
    else if ( !strcmp(item,"size")) var.size = atoi(value);
    else if ( !strcmp(item,"color")) strcpy(var.color, value);
    else if ( !strcmp(item,"tm"))  strcpy(tm, value);
    else if ( !strcmp(item,"acc")) var.acc = atoi(value);
    else if ( !strcmp(item,"auto_man")) var.auto_man = value[0];
    else if ( !strcmp(item,"x1")) var.x1 = atoi(value);
    else if ( !strcmp(item,"y1")) var.y1 = atoi(value);
    else if ( !strcmp(item,"x2")) var.x2 = atoi(value);
    else if ( !strcmp(item,"y2")) var.y2 = atoi(value);
    else if ( !strcmp(item,"gov")) {
      for (var.num_gov = 0, j = 0; value[0] != '\0'; j++) {
        getword (tmp, value, ':');
        if (strlen(tmp) >= 3) {
          strcpy(var.gov_cd[var.num_gov], tmp);
          var.num_gov++;
        }
      }
    }
    else if ( !strcmp(item,"rate")) var.rate = value[0];
    else if ( !strcmp(item,"aws")) var.aws = atoi(value);
    else if ( !strcmp(item,"sms")) var.sms = atoi(value);
    else if ( !strcmp(item,"gis")) strcpy(var.gis, value);
    else if ( !strcmp(item,"ZRa")) var.ZRa = atof(value);
    else if ( !strcmp(item,"ZRb")) var.ZRb = atof(value);
    else if ( !strcmp(item,"zoom_level")) var.zoom_level = atoi(value);
    else if ( !strcmp(item,"zoom_rate"))  var.zoom_rate = atoi(value);
    else if ( !strcmp(item,"zoom_x")) strcpy(var.zoom_x, value);
    else if ( !strcmp(item,"zoom_y")) strcpy(var.zoom_y, value);
    else if ( !strcmp(item,"legend")) var.legend = atoi(value);
    else if ( !strcmp(item,"dir")) var.dir_mode = atoi(value);
  }

  // 3. �⺻�� ����
  if (strcmp(var.cmp,"NUM") == 0) var.dbz = atoi(var.obs);
  var.grid = 0.5;
  if (var.num_gov == 0) {
    var.num_gov = 1;
    strcpy(var.gov_cd[0],"KMA");
  }
  if (strcmp(var.color,"C7") == 0) {    // �����϶��� ���� ZR ��������� ������ȯ
    var.ZRa = 2000;
    var.ZRb = 2.0;
  }

  // 4. ����ð� �� ���� �����ð� ����
  get_time(&iYY, &iMM, &iDD, &iHH, &iMI, &iSS);
  iseq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  var.seq_now = iseq;

  // 5. ��û�ð� ����
  if (strlen(tm) < 10 || var.auto_man == 'a')
    var.seq = 5*(iseq/5);
  else {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
    var.seq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  }
  //var.seq = 5*(var.seq/5);

  // 6. ���� ���翩�� Ȯ��
  for (i = 0; i < 10; i++, var.seq -= 1) {
    if (rdr_cmp_file(var.seq, var.cmp, var.qcd, var.dir_mode, var.fname) >= 0) {
      break;
    }
  }

  // 7. PCP�� ��� �ð��ð� ����
  if (strstr(var.cmp,"PCP") != NULL) var.seq1 = var.seq - var.acc;

  return 0;
}

/*******************************************************************************
 *
 *  ���̴� �ռ��� �̹��� ���� �� ����
 *
 *******************************************************************************/
int rdr_cmp_img()
{
  gdImagePtr im;
  FILE  *fp;
  float data_lvl[256];
  int   color_lvl[256];

  // 1. �̹��� ���� ����
  var.NI = var.size;
  var.NJ = (int)((float)(var.NY)/(float)(var.NX)*var.NI);
  var.GI = var.NI;
  if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + TITLE_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_table(im, color_lvl, data_lvl);
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[240]);

  // 3. �����ڷ� �׸���
  grid_disp(im, color_lvl, data_lvl);

  // 4. �������� �׸���
  if (strstr(var.gis,"T")) topo_disp(im, color_lvl, data_lvl);

  // 5. ���� �׸���
  if (var.zoom_level >= 2) map_disp(im, color_lvl[249], 1);
  map_disp(im, color_lvl[244], 4);

  // 6. ���� ǥ��
  if (var.aws > 0 && var.zoom_level > 0) aws_disp(im, color_lvl);

  // 7. ���� �׸�
  title_disp(im, color_lvl);

  // 8. ���� �׸���
  legend_disp(im, color_lvl, data_lvl);
  gdImageRectangle(im, 0, TITLE_pixel, var.NI-1, var.GJ-1, color_lvl[242]);

  // 9. �ܸ鵵 �� �׸���
  cross_line_disp(im, color_lvl);

  // 10. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);
  return 0;
}

/*=============================================================================*
 *  ����ǥ
 *=============================================================================*/
int color_table(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  FILE  *fp;
  float v1;
  char  color_file[120];
  int   R, G, B;

  // 1. ��󺯼��� ����ǥ ���� ����
  strcpy(color_file,COLOR_SET_DIR);

  // 1.1. ����Ž������ ��� (����,������ ����)
  if (strcmp(var.cmp,"NUM") == 0) {
    if (var.rate == 'R')
      strcat(color_file,"color_rdr_rate.rgb");
    else
      strcat(color_file,"color_rdr_num.rgb");
  }
  else if (strstr(var.cmp,"PCP") != NULL) {
    if (var.acc <= 3*60) {
      if      (!strcmp(var.color,"C1")) strcat(color_file,"color_rn.rgb");
      else if (!strcmp(var.color,"C2")) strcat(color_file,"color_rn_yell.rgb");
      else if (!strcmp(var.color,"C3")) strcat(color_file,"color_rn_blue.rgb");
      else 
        strcat(color_file,"color_rn_echo.rgb");
    }
    else if (var.acc <= 6*60) {
      if      (!strcmp(var.color,"C1")) strcat(color_file,"color_rn_03h.rgb");
      else if (!strcmp(var.color,"C2")) strcat(color_file,"color_rn_03h_yell.rgb");
      else if (!strcmp(var.color,"C3")) strcat(color_file,"color_rn_03h_blue.rgb");
      else
        strcat(color_file,"color_rn_03h_echo.rgb");
    }
    else {
      if      (!strcmp(var.color,"C1")) strcat(color_file,"color_rn_12h.rgb");
      else if (!strcmp(var.color,"C2")) strcat(color_file,"color_rn_12h_yell.rgb");
      else if (!strcmp(var.color,"C3")) strcat(color_file,"color_rn_12h_blue.rgb");
      else
        strcat(color_file,"color_rn_12h_echo.rgb");
    }
  }
  else {
    if (strcmp(var.obs,"EBH") == 0)
      strcat(color_file,"color_rdr_ebh.rgb");
    else if (strcmp(var.obs,"ECHO") == 0) {
      if      (strcmp(var.color,"C1") == 0) strcat(color_file,"color_rn.rgb");
      else if (strcmp(var.color,"C2") == 0) strcat(color_file,"color_rdr.rgb");
      else if (strcmp(var.color,"C3") == 0) strcat(color_file,"color_rdr_blue.rgb");
      else if (strcmp(var.color,"C7") == 0) strcat(color_file,"color_rdr_snow.rgb");  // ����
      else
        strcat(color_file,"color_rdr_echo.rgb");
    }
  }

  // 2. ����ǥ ���ϰ� ������ �б�
  if (strstr(var.cmp,"PCP") != NULL) {
    var.num_color = 0;
    if ((fp = fopen(color_file, "r")) != NULL) {
      while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
        color_lvl[var.num_color] = gdImageColorAllocate(im, R, G, B);
        data_lvl[var.num_color] = v1;
        var.num_color++;
        if (var.num_color > 119) break;
      }
      fclose(fp);
    }
  }
  else if (strcmp(var.obs,"STN") == 0) {
    if (strcmp(var.qcd,"NQ1") == 0 || strcmp(var.qcd,"QC1") == 0) {
      for (var.num_color = 0; var.num_color < 3; var.num_color++) {
        R = stn_sr1_color[var.num_color].R;
        G = stn_sr1_color[var.num_color].G;
        B = stn_sr1_color[var.num_color].B;
        stn_sr1_color[var.num_color].color = gdImageColorAllocate(im, R, G, B);
      }
    }
    else if (strcmp(var.qcd,"EX1") == 0) {
      for (var.num_color = 0; var.num_color < NUM_STN_SR1_COLOR; var.num_color++) {
        R = stn_sr1_color[var.num_color].R;
        G = stn_sr1_color[var.num_color].G;
        B = stn_sr1_color[var.num_color].B;
        stn_sr1_color[var.num_color].color = gdImageColorAllocate(im, R, G, B);
      }
    }
    else {
      for (var.num_color = 0; var.num_color < NUM_STN_COLOR; var.num_color++) {
        R = stn_color[var.num_color].R;
        G = stn_color[var.num_color].G;
        B = stn_color[var.num_color].B;
        stn_color[var.num_color].color = gdImageColorAllocate(im, R, G, B);
      }
    }
  }
  else if (strcmp(var.obs,"EBH") == 0) {
    var.num_color = 0;
    if ((fp = fopen(color_file, "r")) != NULL) {
      while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
        color_lvl[var.num_color] = gdImageColorAllocate(im, R, G, B);
        data_lvl[var.num_color] = v1;
        var.num_color++;
        if (var.num_color > 119) break;
      }
      fclose(fp);
    }
  }
  else if (strcmp(var.cmp,"HAIL") == 0) {
    for (var.num_color = 0; var.num_color < NUM_HAIL_COLOR; var.num_color++) {
      R = hail_color[var.num_color].R;
      G = hail_color[var.num_color].G;
      B = hail_color[var.num_color].B;
      hail_color[var.num_color].color = gdImageColorAllocate(im, R, G, B);
    }
  }
  else if (strcmp(var.cmp,"HCI2") == 0) {
    for (var.num_color = 0; var.num_color < NUM_HCI_DETAIL_COLOR; var.num_color++) {
      R = hci_detail_color[var.num_color].R;
      G = hci_detail_color[var.num_color].G;
      B = hci_detail_color[var.num_color].B;
      hci_detail_color[var.num_color].color = gdImageColorAllocate(im, R, G, B);
    }
  }
  else if (strcmp(var.cmp,"HCI") == 0) {
    for (var.num_color = 0; var.num_color < NUM_HCI_COLOR; var.num_color++) {
      R = hci_color[var.num_color].R;
      G = hci_color[var.num_color].G;
      B = hci_color[var.num_color].B;
      hci_color[var.num_color].color = gdImageColorAllocate(im, R, G, B);
    }
  }
  else {
    var.num_color = 0;
    if ((fp = fopen(color_file, "r")) != NULL) {
      while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
        color_lvl[var.num_color] = gdImageColorAllocate(im, R, G, B);
        data_lvl[var.num_color] = v1;
        var.num_color++;
        if (var.num_color > 119) break;
      }
      fclose(fp);
    }
  }

  // 3. �������� ����ǥ (����)
  color_lvl[150] = gdImageColorAllocate(im, 206, 229, 241);   data_lvl[150] = 1.0;
  color_lvl[151] = gdImageColorAllocate(im, 240, 240, 225);   data_lvl[151] = 100;
  color_lvl[152] = gdImageColorAllocate(im, 170, 170, 170);   data_lvl[152] = 500;
  color_lvl[153] = gdImageColorAllocate(im, 120, 120, 120);   data_lvl[153] = 5000;
  var.num_color_topo = 3;

  /* ����������� (full����)
  color_lvl[150] = gdImageColorAllocate(im, 206, 229, 241);   data_lvl[150] = 1.0;   // �ٴٻ�
  color_lvl[151] = gdImageColorAllocate(im, 240, 240, 225);   data_lvl[151] = 50;    // - 50m
  color_lvl[152] = gdImageColorAllocate(im, 220, 220, 220);   data_lvl[152] = 100;   // -100m
  color_lvl[153] = gdImageColorAllocate(im, 210, 210, 210);   data_lvl[153] = 150;   // -150m
  color_lvl[154] = gdImageColorAllocate(im, 200, 200, 200);   data_lvl[154] = 200;   // -200m
  color_lvl[155] = gdImageColorAllocate(im, 190, 190, 190);   data_lvl[155] = 300;   // -300m
  color_lvl[156] = gdImageColorAllocate(im, 180, 180, 180);   data_lvl[156] = 400;   // -400m
  color_lvl[157] = gdImageColorAllocate(im, 170, 170, 170);   data_lvl[157] = 500;   // -500m
  color_lvl[158] = gdImageColorAllocate(im, 160, 160, 160);   data_lvl[158] = 600;   // -600m
  color_lvl[159] = gdImageColorAllocate(im, 150, 150, 150);   data_lvl[159] = 700;   // -700m
  color_lvl[160] = gdImageColorAllocate(im, 140, 140, 140);   data_lvl[160] = 800;   // -800m
  color_lvl[161] = gdImageColorAllocate(im, 130, 130, 130);   data_lvl[161] = 900;   // -900m
  color_lvl[162] = gdImageColorAllocate(im, 120, 120, 120);   data_lvl[162] = 1000;  // -1000m
  color_lvl[163] = gdImageColorAllocate(im, 110, 110, 110);   data_lvl[163] = 1500;  // -1500m
  color_lvl[164] = gdImageColorAllocate(im, 100, 100, 100);   data_lvl[164] = 5000;  // -2000m
  color_lvl[165] = gdImageColorAllocate(im, 109, 218, 109);
  var.num_color_topo = 15;
  */
  color_lvl[171] = gdImageColorAllocate(im,  98, 169, 213);   // ��

  // 4. ��Ÿ ����ǥ ����
  color_lvl[240] = gdImageColorAllocate(im, 180, 180, 180);   // ����1
  color_lvl[241] = gdImageColorAllocate(im, 255, 255, 255);   // ����2
  color_lvl[242] = gdImageColorAllocate(im, 30, 30, 30);      // ������
  color_lvl[243] = gdImageColorAllocate(im, 12, 28, 236);     // ����
  color_lvl[244] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  color_lvl[245] = gdImageColorAllocate(im, 240, 240, 240);
  color_lvl[246] = gdImageColorAllocate(im, 255, 0, 0);
  color_lvl[247] = gdImageColorAllocate(im, 0, 0, 255);
  color_lvl[248] = gdImageColorAllocate(im, 160, 160, 160);   // ����3
  color_lvl[249] = gdImageColorAllocate(im, 110, 110, 110);   // �ñ����
  color_lvl[250] = gdImageColorAllocate(im, 80, 80, 80);      // ��������
  color_lvl[251] = gdImageColorAllocate(im, 255, 0, 172);     // �ܸ鼱

  return 0;
}

/*=============================================================================*
 *  ����ü ����� ����ü ������ �߿䵵�� ���� ��з�
 *=============================================================================*/
short rdr_hci_num(short ec)
{
  short hci;

  switch (ec) {
    case 0:  hci = 0;  break;   // ������
    case 50: hci = 1;  break;   // �񰭼�
    case 12: hci = 2;  break;   // ����(���)
    case 13: hci = 2;  break;   // ����(����)
    case 10: hci = 3;  break;   // ��(�Ǽ�)
    case 14: hci = 4;  break;   // ��������(���ð�����)
    case 11: hci = 4;  break;   // ��������(����)
    case 9:  hci = 4;  break;   // ��������(�ζ���/��)
    case 1:  hci = 5;  break;   // ��(����)
    case 2:  hci = 5;  break;   // ��(�̽���)
    case 3:  hci = 5;  break;   // ��(���Ѻ�)
    case 4:  hci = 5;  break;   // ��(�߰���)
    case 5:  hci = 5;  break;   // ��(���Ѻ�)
    case 8:  hci = 6;  break;   // ���(�ζ���+�������)
    case 7:  hci = 6;  break;   // ���(��+���)
    case 6:  hci = 6;  break;   // ���
    default: hci = -1;
  }
  return hci;
}

/*=============================================================================*
 *  �����ڷ� ǥ��
 *=============================================================================*/
int grid_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  unsigned char *n1, *n2;
  short *e1, *e2;
  float *r1, *r2;

  float lvl[256], dbz1, rain1;
  float x1, y1, x, y, dd, d1, d2, dd1, dd2;
  float zm = 1.0, xo = 0.0, yo = 0.0;
  float grid_nx, grid_ny, zx, zy, rate, wy1, wy2, wx1, wx2;
  short blank = BLANK1+10;
  int   dxy, nx, ny, map_code;
  int   list_num[NUM_STN_COLOR];
  int   stn_ok = 0, num_ok = 0, pcp_ok = 0, hci_ok = 0, hci2_ok = 0, hail_ok = 0;
  int   nd, ix, iy, color1;
  int   i, j, k;

  // 1. ����ó��
  if (var.num_color <= 0) {
    gdImageString(im, gdFontLarge, 100, 100, "No Color Level", color_lvl[244]);
    return -1;
  }

  // 2. �⺻ ����
  if (strstr(var.cmp,"PCP") != NULL) {
    dxy = rdr_pcp_head.dxy;
    nx  = rdr_pcp_head.nx;
    ny  = rdr_pcp_head.ny;
    map_code = rdr_pcp_head.map_code;
  }
  else {
    dxy = rdr_cmp_head.dxy;
    nx  = rdr_cmp_head.nx;
    ny  = rdr_cmp_head.ny;
    map_code = rdr_cmp_head.map_code;
  }

  grid_ny = 1000.0*(float)(var.NY)/(float)dxy;
  grid_nx = 1000.0*(float)(var.NX)/(float)dxy;
  if (map_code == 1) {
    yo = 1000.0*(float)(HB_SY-var.SY)/(float)dxy;
    xo = 1000.0*(float)(HB_SX-var.SX)/(float)dxy;
  }
  else if (map_code == 2) {
    yo = 1000.0*(float)(HC_SY-var.SY)/(float)dxy;
    xo = 1000.0*(float)(HC_SX-var.SX)/(float)dxy;
  }
  else if (map_code == 3) {
    yo = 1000.0*(float)(HR_SY-var.SY)/(float)dxy;
    xo = 1000.0*(float)(HR_SX-var.SX)/(float)dxy;
  }
  else if (map_code == 5) {
    yo = 1000.0*(float)(HL_SY-var.SY)/(float)dxy;
    xo = 1000.0*(float)(HL_SX-var.SX)/(float)dxy;
  }
  rate = grid_nx/(float)(var.NI);    // �̹��� �ȼ��� ���ڼ�

  if (strcmp(var.cmp,"NUM") == 0) {
    num_ok = 1;  blank = -1;
  }
  else if (strstr(var.cmp,"PCP") != NULL) {
    pcp_ok = 1;  blank = BLANK1;
  }
  else {
    if (strcmp(var.obs,"ECHO") == 0) {
      if (strcmp(var.cmp,"HCI")  == 0) { hci_ok  = 1;  blank = 0; }
      if (strcmp(var.cmp,"HCI2") == 0) { hci2_ok = 1;  blank = 0; }
      if (strcmp(var.cmp,"HAIL") == 0) { hail_ok = 1;  blank = 0; }
    }
  }

  // 3. ��ϰ� ����
  if (pcp_ok) {
    for (k = 0; k < var.num_color; k++)
      lvl[k] = data_lvl[k];
  }
  else if (num_ok) {
    for (k = 0; k < var.num_color; k++)
      lvl[k] = data_lvl[k];
  }
  else if (strcmp(var.obs,"STN") == 0) {
    if (strcmp(var.qcd,"NQ1") == 0 || strcmp(var.qcd,"QC1") == 0) {
      for (k = 0; k < rdr_cmp_head.num_stn; k++) {
        list_num[k] = -1;
        for (i = 0; i < 3; i++) {
          if (strstr(rdr_cmp_stn_list[k].stn_cd, stn_sr1_color[i].stn_cd) != NULL) {
            list_num[k] = i;
            break;
          }
        }
      }
      stn_ok = 2;
    }
    else if (strcmp(var.qcd,"EX1") == 0) {
      for (k = 0; k < rdr_cmp_head.num_stn; k++) {
        list_num[k] = -1;
        for (i = 0; i < NUM_STN_SR1_COLOR; i++) {
          if (strstr(rdr_cmp_stn_list[k].stn_cd, stn_sr1_color[i].stn_cd) != NULL) {
            list_num[k] = i;
            break;
          }
        }
      }
      stn_ok = 3;
    }
    else {
      for (k = 0; k < rdr_cmp_head.num_stn; k++) {
        list_num[k] = -1;
        for (i = 0; i < NUM_STN_COLOR; i++) {
          if (strstr(rdr_cmp_stn_list[k].stn_cd, stn_color[i].stn_cd) != NULL) {
            list_num[k] = i;
            break;
          }
       }
      }
      stn_ok = 1;
    }
    blank = 0;
  }
  else if (strcmp(var.obs,"ECHO") == 0) {
    for (k = 0; k < var.num_color; k++) {
      rain1 = data_lvl[k];
      dbz_rain_conv(&dbz1, &rain1, 1);
      lvl[k] = dbz1*100;
    }
    stn_ok = 0;
    blank = BLANK1;
  }
  else if (strcmp(var.obs,"EBH") == 0 && strstr(var.obs,"HCI") == NULL) {
    for (k = 0; k < var.num_color; k++)
      lvl[k] = data_lvl[k]*1000;
    stn_ok = 0;
    blank = BLANK1;
  }
  else {
    for (k = 0; k < var.num_color; k++)
      lvl[k] = data_lvl[k];
    stn_ok = 0;
    blank = BLANK1;
  }

  // 4. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    if (var.zoom_rate == 3) {
      for (i = 0; i < 2; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (grid_nx/9.0*(zx-1)/zm);
        yo += (grid_ny/9.0*(zy-1)/zm);
        zm *= var.zoom_rate;
      }
    }
    else if (var.zoom_rate == 2) {
      for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (grid_nx/8.0*(zx-1)/zm);
        yo += (grid_ny/8.0*(zy-1)/zm);
        zm *= var.zoom_rate;
      }
    }
  }

  // 5. �̹��� �ȼ����� ���
  for (j = 1; j < var.NJ; j++) {
    y1 = rate*j/zm + yo;
    iy = (int)(y1);
    if (iy < 1 || iy >= ny-1) continue;
    wy2 = y1 - iy;
    wy1 = 1.0 - wy2;

    if      (num_ok) { n1 = num_echo[iy];  n2 = num_echo[iy+1]; }
    else if (pcp_ok) { r1 = rain[iy];  r2 = rain[iy+1]; }
    else             { e1 = echo[iy];  e2 = echo[iy+1]; }

    for (i = 1; i < var.NI; i++) {
      // 5.1. �ȼ��� �ش��ϴ� ��ǥ Ȯ��
      x1 = rate*i/zm + xo;
      ix = (int)(x1);
      if (ix < 1 || ix >= nx-1) continue;
      wx2 = x1 - ix;
      wx1 = 1.0 - wx2;

      // 5.2. ����Ž������ ���
      if (num_ok) {
        d1 = *(n1+ix);  d2 = *(n1+ix+1);  dd1 = d1*wx1 + d2*wx2;
        d1 = *(n2+ix);  d2 = *(n2+ix+1);  dd2 = d1*wx1 + d2*wx2;
        dd = dd1*wy1 + dd2*wy2;

        if (dd >= 0 && dd <= 100) {
          color1 = color_lvl[var.num_color-1];
          for (k = 0; k < var.num_color; k++) {
            if (dd <= lvl[k]) {
              color1 = color_lvl[k];
              break;
            }
          }
          gdImageSetPixel(im, i, var.GJ-j, color1);
        }
      }

      // 5.3. ������������ ���
      else if (pcp_ok) {
        d1 = *(r1+ix);  d2 = *(r1+ix+1);  dd1 = d1*wx1 + d2*wx2;
        d1 = *(r2+ix);  d2 = *(r2+ix+1);  dd2 = d1*wx1 + d2*wx2;
        dd = dd1*wy1 + dd2*wy2;

        if (dd > blank) {
          color1 = color_lvl[var.num_color-1];
          for (k = 0; k < var.num_color; k++) {
            if (dd < lvl[k]) {
              color1 = color_lvl[k];
              break;
            }
          }
          gdImageSetPixel(im, i, var.GJ-j, color1);
        }
      }

      // 5.4. �ٸ� �ڷ��� ���, �ڷᰡ �������� ������ ǥ��
      else if (echo[iy][ix] > blank) {
        if (stn_ok > 0) {
          nd = (int)(*(e1 + ix) + 0.1) - 1;
          if (stn_ok == 1) {
            if (nd >= 0 && nd < NUM_STN_COLOR) {
              if (list_num[nd] >= 0) gdImageSetPixel(im, i, var.GJ-j, stn_color[list_num[nd]].color);
            }
          }
          else if (stn_ok == 2) {
            if (nd >= 0 && nd < 3) {
              if (list_num[nd] >= 0) gdImageSetPixel(im, i, var.GJ-j, stn_sr1_color[list_num[nd]].color);
            }
          }
          else if (stn_ok == 3) {
            if (nd >= 0 && nd < NUM_STN_SR1_COLOR) {
              if (list_num[nd] >= 0) gdImageSetPixel(im, i, var.GJ-j, stn_sr1_color[list_num[nd]].color);
            }
          }
        }
        else if (hci2_ok) {
          nd = (int)(*(e1 + ix) + 0.1);
          for (k = 0; k < NUM_HCI_DETAIL_COLOR; k++) {
            if (nd == hci_detail_color[k].hci) {
              gdImageSetPixel(im, i, var.GJ-j, hci_detail_color[k].color);
              break;
            }
          }
        }
        else if (hci_ok) {
          if ((nd = rdr_hci_num(*(e1 + ix))) >= 0) {
            for (k = 0; k < NUM_HCI_COLOR; k++) {
              if (nd == hci_color[k].hci) {
                gdImageSetPixel(im, i, var.GJ-j, hci_color[k].color);
                break;
              }
            }
          }
        }
        else if (hail_ok) {
          nd = (int)(*(e1 + ix) + 0.1);
          for (k = 0; k < NUM_HAIL_COLOR; k++) {
            if (nd == hail_color[k].hail) {
              gdImageSetPixel(im, i, var.GJ-j, hail_color[k].color);
              break;
            }
          }
        }
        else {
          d1 = *(e1+ix);  d2 = *(e1+ix+1);  dd1 = d1*wx1 + d2*wx2;
          d1 = *(e2+ix);  d2 = *(e2+ix+1);  dd2 = d1*wx1 + d2*wx2;
          dd = dd1*wy1 + dd2*wy2;

          color1 = color_lvl[var.num_color-1];
          for (k = 0; k < var.num_color; k++) {
            if (dd <= lvl[k]) {
              color1 = color_lvl[k];
              break;
            }
          }
          gdImageSetPixel(im, i, var.GJ-j, color1);
        }
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  �������� ǥ��
 *=============================================================================*/
int topo_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  FILE  *fp;
  short **topo;
  float dg = (float)var.NX/(float)(var.NI);
  float zm = 1.0, xo = 0.0, yo = 0.0, zx, zy, x1, y1, ht;
  int   ix, iy, color1;
  int   i, j, k;

  // 1. ���������ڷ� �б�
  if ((fp = fopen(TOPO_FILE, "rb")) == NULL) return -1;
  topo = smatrix(0, HB_NY, 0, HB_NX);
  fseek(fp, (long)64, SEEK_SET);    // �ش�(64byts) skip
  for (j = 0; j <= HB_NY; j++)
    fread(topo[j], 2, HB_NX+1, fp);  // ���� 0.1m
  fclose(fp);

  // 4. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    if (var.zoom_rate == 3) {
      for (i = 0; i < 2; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += ((var.NX - 1)/9.0*(zx-1)/zm);
        yo += ((var.NY - 1)/9.0*(zy-1)/zm);
        zm *= var.zoom_rate;
      }
    }
    else if (var.zoom_rate == 2) {
      for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += ((var.NX - 1)/8.0*(zx-1)/zm);
        yo += ((var.NY - 1)/8.0*(zy-1)/zm);
        zm *= var.zoom_rate;
      }
    }
  }

  // 5. �̹��� �ȼ����� ��� (���ڰ� ���� �κи� ǥ��)
  for (j = 1; j < var.NJ; j++) {
    y1 = dg*j/zm + yo + (HB_SY - var.SY);
    iy = (int)(y1);
    if (iy < 0 || iy >= HB_NY) continue;

    for (i = 1; i < var.NI; i++) {
      x1 = dg*i/zm + xo + (HB_SX - var.SX);
      ix = (int)(x1);
      if (ix < 0 || ix >= HB_NX) continue;

      ht = (float)topo[iy][ix]*0.1;
      if (ht > 1) {
        color1 = gdImageGetPixel(im, i, var.GJ-j);
        if (color1 == 0) {
          color1 = color_lvl[165];
          for (k = 151; k < 151+var.num_color_topo; k++) {
            if (ht < data_lvl[k]) {
              color1 = color_lvl[k];
              break;
            }
          }
          gdImageSetPixel(im, i, var.GJ-j, color1);
        }
      }
    }
  }

  // ���������ڷ� ����
  free_smatrix(topo, 0, HB_NY, 0, HB_NX);
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int map_disp(gdImagePtr im, int color_map, int kind)
{
  FILE  *fp;
  char  fname[120];
  float zm = 1.0, xo = 0.0, yo = 0.0, x1, y1, x2, y2;
  int   zx, zy, depth, mode;
  int   i, j, k, n;

  // 0. �ʱ� ����
  if (var.NI > 600)
    depth = 1;
  else if (var.NI > 450 && kind == 4)
    depth = 1;
  else
    depth = 0;

  // 1. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    if (var.zoom_rate == 3) {
      for (i = 0; i < 2; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/9.0*(zx-1)/zm;
        yo += (float)(var.NY)/9.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
    else if (var.zoom_rate == 2) {
      for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/8.0*(zx-1)/zm;
        yo += (float)(var.NY)/8.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
  }

  // 2. �ؾȼ� ǥ��
  sprintf(fname, "%s/AFS_%s_map%d.dat", MAP_DIR, var.map, kind);
  if ((fp = fopen(fname, "r")) != NULL) {
    while (fscanf(fp, "%d %d\n", &n, &mode) != EOF) {
      for (i = 0; i < n; i++) {
        fscanf(fp, "%f %f\n", &x2, &y2);
        if (var.zoom_level > 0) {
          x2 = zm*(x2-xo);
          y2 = zm*(y2-yo);
        }
        x2 *= ((float)(var.NI)/(float)(var.NX));
        y2 *= ((float)(var.NI)/(float)(var.NX));
        if (i > 0) {
          gdImageLine(im, (int)x1, var.GJ-(int)y1, (int)x2, var.GJ-(int)y2, color_map);
          if (depth) gdImageLine(im, (int)x1, var.GJ-(int)y1-1, (int)x2, var.GJ-(int)y2-1, color_map);
        }
        x1 = x2;
        y1 = y2;
      }
    }
    fclose(fp);
  }

  return 0;
}

/*=============================================================================*
 *  EUC-KR���ڿ��� UTF-8�� ��ȯ
 *=============================================================================*/
int euckr2utf(char *str, char *out)
{
    iconv_t convp;
    size_t  ileft, oleft;
    int     err, len = strlen(str);

    ileft = len;
    oleft = len * 2;

    convp = iconv_open("UTF-8", "euc-kr");
    err = iconv(convp, &str, &ileft, &out, &oleft);
    iconv_close(convp);

    return err;
}

/*=============================================================================*
 *  ���� ǥ��(�ѱ�ó��)
 *=============================================================================*/
int title_disp(gdImagePtr im, int color_lvl[])
{
  char   title[80], tm_fc_str[100], num_stn_str[10], text[100], tmp[50];
  char   title_utf[100], str_utf[100];
  double font_size = 11.5;
  int    brect[8];
  int    YY, MM, DD, HH, MI;
  int    x, y, i, k;

  // 1. ���񿵿��� ���� ó��
  gdImageFilledRectangle(im, 0, 0, var.GI, TITLE_pixel, color_lvl[241]);

  // 2. ������
  if (strcmp(var.cmp,"HSR") == 0) {
    strcpy(title, "���̴� HSR");
    if      (strcmp(var.qcd,"QCD") == 0) strcat(title, "(����M)");
    else if (strcmp(var.qcd,"EXT") == 0) strcat(title, "(����)");
    else if (strcmp(var.qcd,"HSR") == 0) strcat(title, "(����K)");
    else if (strcmp(var.qcd,"LNG") == 0) strcat(title, "(����L)");
    else if (strcmp(var.qcd,"NUM") == 0) strcat(title, "(����N)");
    else if (strcmp(var.qcd,"QPE") == 0) strcat(title, "(����Q)");

    if (strstr(var.cmp,"HSR") && !strcmp(var.qcd,"QCD") && var.HSR_mask == 0) strcat(title,"-");
  }
  else if (strcmp(var.cmp,"LNG") == 0) {
    strcpy(title, "���̴� 480km ");
    strcat(title, var.qcd);
  }
  else if (strcmp(var.cmp,"HCI") == 0 || strcmp(var.cmp,"HCI2") == 0 || strcmp(var.cmp,"HAIL") == 0) {
    if      (strcmp(var.cmp,"HCI")  == 0) strcpy(title, "���̴� ����ü");
    else if (strcmp(var.cmp,"HCI2") == 0) strcpy(title, "���̴� HCI");
    else if (strcmp(var.cmp,"HAIL") == 0) strcpy(title, "���̴� ���");

    if      (strcmp(var.qcd,"NQC") == 0) strcat(title, "(���û)");
    else if (strcmp(var.qcd,"QCD") == 0) strcat(title, "(����M)");
    else if (strcmp(var.qcd,"EXT") == 0) strcat(title, "(����)");
  }
  else if (strcmp(var.cmp,"NUM") == 0) {
    strcpy(title, "���̴�");
    if (var.rate == 'N') strcat(title, " Ž������");
    else                 strcat(title, " Ž����");

    if      (strcmp(var.qcd,"NQC") == 0) strcat(title, "(NoQC)");
    else if (strcmp(var.qcd,"QCD") == 0) strcat(title, "(QC)");
    else if (strcmp(var.qcd,"EXT") == 0) strcat(title, "(����)");

    sprintf(tmp, " %d dBz", var.dbz);
    strcat(title, tmp);
  }
  else if (strstr(var.cmp,"PCP") != NULL) {
    if (var.acc%60 == 0)
      sprintf(title, "���̴� ��������(%dH)", (int)(var.acc/60));
    else
      sprintf(title, "���̴� ��������(%d��)", var.acc);
  }
  else {
    if      (strcmp(var.cmp,"PPI") == 0) strcpy(title, "���̴� PPI0");
    else if (strcmp(var.cmp,"CPP") == 0) strcpy(title, "���̴� CAPPI");
    else if (strcmp(var.cmp,"CMX") == 0) strcpy(title, "���̴� CMAX");

    if      (strcmp(var.qcd,"NQC") == 0) strcat(title, "(NoQC)");
    else if (strcmp(var.qcd,"QCD") == 0) strcat(title, "(QC)");
    else if (strcmp(var.qcd,"EXT") == 0) strcat(title, "(����)");
    else if (strcmp(var.qcd,"GFC") == 0) strcat(title, "(ȫ��������)");
    else if (strcmp(var.qcd,"NQ1") == 0) strcat(title, "(����NQC)");
    else if (strcmp(var.qcd,"QC1") == 0) strcat(title, "(����QCD)");
    else if (strcmp(var.qcd,"EX1") == 0) strcat(title, "(��+����)");
  }

  if (strstr(var.cmp,"PCP") == NULL) {
    if      (strcmp(var.obs,"EBH") == 0) strcat(title, " ECHO����");
    else if (strcmp(var.obs,"STN") == 0) strcat(title, " ����Ʈ");
  }
  if (strcmp(var.color,"C7") == 0 && strcmp(var.obs,"EBH") != 0 && strcmp(var.obs,"STN") != 0) strcat(title, " ����");

  for (i = 0; i < 100; i++)
    title_utf[i] = 0;
  euckr2utf(title, title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 5, (int)(font_size+5), title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 6, (int)(font_size+5), title_utf);

  // 3. �ð� ���ڿ�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(tm_fc_str, "%04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, MI);

  x = strlen(title)*8.5 + 10;
  if (x < 130) x = 130;
  gdImageString(im, gdFontLarge, x, 1, tm_fc_str, color_lvl[244]);
  gdImageString(im, gdFontLarge, x+1, 1, tm_fc_str, color_lvl[244]);

  // 4. ���������� ���, ����� �ڷ�� ����
  if (strstr(var.cmp,"PCP") != NULL) {    // PCPH, PCPP
    if (strcmp(var.cmp,"PCPH") == 0)
      sprintf(text, "HSR %s", var.qcd);
    else
      sprintf(text, "PPI %s", var.qcd);
    gdImageFilledRectangle(im, 0, TITLE_pixel+1, strlen(text)*11, TITLE_pixel*2-3, color_lvl[241]);

    for (i = 0; i < 100; i++)
      str_utf[i] = 0;
    euckr2utf(text, str_utf);
    gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 5, (int)(font_size+5)+TITLE_pixel, str_utf);
    gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 6, (int)(font_size+5)+TITLE_pixel, str_utf);
  }

  // 5. ǥ�⿵���� ������ ǥ��
  if (strstr(var.cmp,"PCP") != NULL) 
    sprintf(num_stn_str, "#%d", var.num_pcp_file);
  else
    sprintf(num_stn_str, "#%d", var.num_rdr_stn);
  gdImageFilledRectangle(im, var.NI-38, var.GJ-18, var.NI-2, var.GJ-2, color_lvl[241]);
  gdImageString(im, gdFontLarge, var.NI-35, var.GJ-17, num_stn_str, color_lvl[244]);

  // 6. Z/R ��� ǥ��
  if (strcmp(var.obs,"ECHO") == 0 && var.size > 350 &&
      strcmp(var.cmp,"NUM") != 0 && strstr(var.cmp,"PCP") == NULL &&
      strstr(var.cmp,"HCI") == NULL && strstr(var.cmp,"HAIL") == NULL) {
    if (var.ZRa != 200 && var.ZRb != 1.6) {
      sprintf(text, "%.1f / %.1f", var.ZRa, var.ZRb);
      gdImageFilledRectangle(im, 1, var.GJ-18, strlen(text)*9, var.GJ-1, color_lvl[241]);
      gdImageString(im, gdFontLarge, 5, var.GJ-17, text, color_lvl[244]);
    }
  }
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int legend_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  char   txt[20];
  char   txt_utf[30];
  double font_size = 9.0;
  int    brect[8], unit_ok = 0, color1;
  float  dy = (float)(var.NJ)/(float)(var.num_color);
  int    YY, MM, DD, HH, MI;
  int    x, y, i, j, k;

  if (var.legend != 1) return 0;
  if (var.num_color <= 0) return -1;

  // 1. ���� ���� ǥ��
  if (strstr(var.cmp,"PCP") != NULL) {
    for (k = 0; k < var.num_color; k++) {
      y = var.GJ - dy*k;
      gdImageFilledRectangle(im, var.NI, y-dy, var.NI+8, y, color_lvl[k]);
    }
  }
  else if (strcmp(var.obs,"STN") == 0) {
    if (strcmp(var.qcd,"NQ1") == 0 || strcmp(var.qcd,"QC1") == 0 || strcmp(var.qcd,"EX1") == 0) {
      for (k = 0; k < var.num_color; k++) {
        y = TITLE_pixel + dy*k;
        gdImageFilledRectangle(im, var.NI, y, var.NI+8, y+dy, stn_sr1_color[k].color);
      }
    }
    else {
      for (k = 0; k < var.num_color; k++) {
        y = TITLE_pixel + dy*k;
        gdImageFilledRectangle(im, var.NI, y, var.NI+8, y+dy, stn_color[k].color);
      }
    }
  }
  else if (strcmp(var.obs,"EBH") == 0) {
    for (k = 0; k < var.num_color; k++) {
      y = var.GJ - dy*k;
      gdImageFilledRectangle(im, var.NI, y-dy, var.NI+8, y, color_lvl[k]);
    }
  }
  else {
    if (strcmp(var.cmp,"HAIL") == 0) {
      for (k = var.num_color-1; k >= 0; k--) {
        y = TITLE_pixel + dy*(var.num_color-k-1);
        gdImageFilledRectangle(im, var.NI, y, var.NI+8, y+dy, hail_color[k].color);
      }
    }
    else if (strcmp(var.cmp,"HCI2") == 0) {
      for (k = 0; k <= var.num_color-1; k++) {
        y = TITLE_pixel + dy*k;
        gdImageFilledRectangle(im, var.NI, y, var.NI+8, y+dy, hci_detail_color[k].color);
      }
    }
    else if (strcmp(var.cmp,"HCI") == 0) {
      for (k = var.num_color-1; k >= 0; k--) {
        y = TITLE_pixel + dy*(var.num_color-k-1);
        gdImageFilledRectangle(im, var.NI, y, var.NI+8, y+dy, hci_color[k].color);
      }
    }
    else {
      for (k = 0; k < var.num_color; k++) {
        y = var.GJ - dy*k;
        gdImageFilledRectangle(im, var.NI, y-dy, var.NI+8, y, color_lvl[k]);
      }
    }
  }
  gdImageRectangle(im, var.NI-1, TITLE_pixel, var.NI+8, var.GJ-1, color_lvl[242]);

  // 2. ���ʰ� ǥ��
  gdImageFilledRectangle(im, var.NI+9, 0, var.GI-1, var.GJ, color_lvl[241]);
  if (strstr(var.cmp,"PCP") != NULL) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      if (data_lvl[k] < 2)
        sprintf(txt, "%.1f", data_lvl[k]);
      else
        sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (strcmp(var.obs,"EBH") == 0) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.1f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (strcmp(var.obs,"STN") == 0) {
    if (strcmp(var.qcd,"NQ1") == 0 || strcmp(var.qcd,"QC1") == 0 || strcmp(var.qcd,"EX1") == 0) {
      for (k = 0; k < var.num_color; k++) {
        for (j = 0; j <= 4; j += 4) {
          y = TITLE_pixel + k*dy + j/4*14 + 15;
          strncpy(txt, &(stn_sr1_color[k].stn_ko[j]), 4);

          for (i = 0; i < 30; i++) txt_utf[i] = 0;
          euckr2utf(txt, txt_utf);

          color1 = color_lvl[244];
          for (i = 0; i < rdr_cmp_head.num_stn; i++) {
            if (!strcmp(rdr_cmp_stn_list[i].stn_cd, stn_sr1_color[k].stn_cd)) {
              color1 = color_lvl[247];
              break;
            }
          }
          gdImageStringFT(im, &brect[0], color1, FONTTTF, font_size, 0.0, var.NI+11, y, txt_utf);
        }
      }
    }
    else {
      for (k = 0; k < var.num_color; k++) {
        for (j = 0; j <= 4; j += 4) {
          y = TITLE_pixel + k*dy + j/4*14 + 15;
          strncpy(txt, &(stn_color[k].stn_ko[j]), 4);

          for (i = 0; i < 30; i++) txt_utf[i] = 0;
          euckr2utf(txt, txt_utf);

          color1 = color_lvl[244];
          for (i = 0; i < rdr_cmp_head.num_stn; i++) {
            if (!strcmp(rdr_cmp_stn_list[i].stn_cd,stn_color[k].stn_cd)) {
              color1 = color_lvl[247];
              break;
            }
          }
          gdImageStringFT(im, &brect[0], color1, FONTTTF, font_size, 0.0, var.NI+11, y, txt_utf);
        }
      }
    }
  }
  else if (strcmp(var.color,"C7") == 0) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      if (data_lvl[k] < 0.1)
        sprintf(txt, "%.2f", data_lvl[k]);
      else if (data_lvl[k] < 2)
        sprintf(txt, "%.1f", data_lvl[k]);
      else
        sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else {
    if (strcmp(var.cmp,"HAIL") == 0) {
      font_size = 9.5;
      for (k = NUM_HAIL_COLOR-1; k >= 0; k--) {
        y = TITLE_pixel + dy*(var.num_color-1-k) + dy/8 + 5;
        strcpy(txt, hail_color[k].hail_ko);
        for (i = 0; i < 30; i++) txt_utf[i] = 0;
        euckr2utf(txt, txt_utf);
        gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, var.NI+11, y, txt_utf);
        if (k == NUM_HAIL_COLOR-1) {
          strcpy(txt,"�̻�");
          for (i = 0; i < 30; i++) txt_utf[i] = 0;
          euckr2utf(txt, txt_utf);
          gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, var.NI+11, y+14, txt_utf);
        }
        //else if (k > 0) {
        //  strcpy(txt,"����");
        //  for (i = 0; i < 30; i++) txt_utf[i] = 0;
        //  euckr2utf(txt, txt_utf);
        //  gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, var.NI+11, y+14, txt_utf);
        //}
      }
    }
    else if (strcmp(var.cmp,"HCI2") == 0) {
      font_size = 8.5;
      for (k = 0; k <= var.num_color-1; k++) {
        for (j = 0; j < strlen(hci_detail_color[k].hci_ko)-1; j += 4) {
          y = TITLE_pixel + dy*k + dy/4 + j*3 + 5;
          strncpy(txt, &(hci_detail_color[k].hci_ko[j]), 4);
          txt[4] = '\0';
          for (i = 0; i < 30; i++) txt_utf[i] = 0;
          euckr2utf(txt, txt_utf);
          gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, var.NI+11, y, txt_utf);
        }
      }
    }
    else if (strcmp(var.cmp,"HCI") == 0) {
      font_size = 10.5;
      for (k = NUM_HCI_COLOR-1; k >= 0; k--) {
        for (j = 0; j < strlen(hci_color[k].hci_ko)-1; j += 2) {
          y = TITLE_pixel + dy*(var.num_color-1-k) + dy/4 + j*9;
          strncpy(txt, &(hci_color[k].hci_ko[j]), 2);
          txt[2] = '\0';
          for (i = 0; i < 30; i++) txt_utf[i] = 0;
          euckr2utf(txt, txt_utf);
          gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, var.NI+11, y, txt_utf);
          gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, var.NI+12, y, txt_utf);
        }
      }
    }
    else {
      for (k = 0; k < var.num_color-1; k++) {
        y = var.GJ - (k+1)*dy - 5;
        if (data_lvl[k] < 2)
          sprintf(txt, "%.1f", data_lvl[k]);
        else
          sprintf(txt, "%.0f", data_lvl[k]);
        gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
      }
    }
  }

  // 3. ���� ���� ǥ��
  // 3.1. ���� ǥ�� ����
  if (strstr(var.cmp,"PCP") != NULL)
    unit_ok = 1;
  else if (strcmp(var.obs,"EBH") == 0)
    unit_ok = 1;
  else if (strcmp(var.obs,"STN") == 0)
    unit_ok = 0;
  else {
    if (strcmp(var.cmp,"HCI") == 0 || strcmp(var.cmp,"HCI2") == 0 || strcmp(var.cmp,"EBH") == 0)
      unit_ok = 0;
    else
      unit_ok = 1;
  }

  // 3.2. ���� ǥ��
  if (unit_ok) {
    if (strstr(var.cmp,"PCP") != NULL)
      strcpy(txt,"mm/h");
    else if (strcmp(var.obs,"EBH") == 0)
      strcpy(txt,"km");
    else if (strcmp(var.color,"C7") == 0)
      strcpy(txt,"cm/h");
    else
      strcpy(txt,"mm/h");

    x = var.NI + 3;
    gdImageString(im, gdFontLarge, x, 4, txt, color_lvl[244]);
  }
  return 0;
}

/*=============================================================================*
 *  �ܸ鼱 ǥ��
 *=============================================================================*/
int cross_line_disp(gdImagePtr im, int color_lvl[])
{
  float zm = 1.0, xo = 0.0, yo = 0.0, zx, zy;
  float grid_nx, grid_ny, dxy;
  int   map_code;
  int   x1, y1, x2, y2;
  int   i;

  // 1. �ܸ鼱�� �ִ��� �Ǵ�
  if (var.x1 <= 0) return;

  // 2. 2�� Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    for (i = 0; i < 7; i++) {
      zx = var.zoom_x[i]-'0';
      zy = var.zoom_y[i]-'0';
      if (zx == 0 || zy == 0) break;

      xo += (var.NX/8.0*(zx-1)/zm);
      yo += (var.NY/8.0*(zy-1)/zm);
      zm *= 2;
    }
  }

  // 4. Ȯ�븦 �����Ͽ� �ܸ鼱�� �ȼ� ��ġ �ľ�
  x1 = (var.x1 - xo)*zm*(float)var.NI/(float)var.NX;
  x2 = (var.x2 - xo)*zm*(float)var.NI/(float)var.NX;
  y1 = var.GJ - (var.y1 - yo)*zm*(float)var.NJ/(float)var.NY;
  y2 = var.GJ - (var.y2 - yo)*zm*(float)var.NJ/(float)var.NY;

  // 5. �ܸ鼱 ǥ��
  gdImageLine(im, x1, y1, x2, y2, color_lvl[251]);
  gdImageLine(im, x1, y1-1, x2, y2-1, color_lvl[251]);
  gdImageFilledArc(im, x1, y1, 5, 5, 0, 360, color_lvl[251], gdArc);
  gdImageFilledArc(im, x2, y2, 5, 5, 0, 360, color_lvl[251], gdArc);
  return 0;
}

/*******************************************************************************
 *
 *  �ڷᰡ �̻��� �ִ� ���, ���� �̹��� ���
 *
 *******************************************************************************/
int rdr_cmp_err_img(int err)
{
  gdImagePtr im;
  char  text[120], tmp[120];
  int   YY, MM, DD, HH, MI;
  int   color_lvl[16];
  int   x, y, i, j, k, n;

  // 1. �̹��� ���� ����
  var.NI = var.size;
  var.NJ = var.NI;
  var.GI = var.NI;
  if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + TITLE_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_lvl[0] = gdImageColorAllocate(im, 240, 240, 240);   // ����
  color_lvl[1] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[0]);

  // 3. ���� �޽���
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(text, "TIME = %04d.%02d.%02d.%02d:%02d / err = %d", YY, MM, DD, HH, MI, err);
  gdImageString(im, gdFontLarge, 50, 50, text, color_lvl[1]);

  sprintf(text, "CMP = %s / QCD = %s / OBS = %s", var.cmp, var.qcd, var.obs);
  gdImageString(im, gdFontLarge, 50, 70, text, color_lvl[1]);

  sprintf(text, "SIZE = %dpx / ZRa = %.1f / ZRb = %.2f", var.size, var.ZRa, var.ZRb);
  gdImageString(im, gdFontLarge, 50, 110, text, color_lvl[1]);

  if (err == 2)
    sprintf(text, "FILE = %s (file is not found)", var.fname);
  else
    sprintf(text, "FILE = %s", var.fname);
  gdImageString(im, gdFontLarge, 50, 130, text, color_lvl[1]);

  // 4. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);

  return 0;
}
