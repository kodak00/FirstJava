/*******************************************************************************
**
**  ǥ������ ������ ���̴� �������ڷ� ǥ��
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.8.19)
**
********************************************************************************/
#include "rdr_stn2_img.h"

// Volume ���
struct VOL_LIST vol_inf[47] = {
  { 0, "DZ"},{ 1, "VR"},{ 2, "SW"},{ 3, "CZ"},{ 4, "ZT"},
  { 5, "DR"},{ 6, "LR"},{ 7, "ZD"},{ 8, "DM"},{ 9, "RH"},
  {10, "PH"},{11, "XZ"},{12, "CD"},{13, "MZ"},{14, "MD"},
  {15, "ZE"},{16, "VE"},{17, "KD"},{18, "TI"},{19, "DX"},
  {20, "CH"},{21, "AH"},{22, "CV"},{23, "AV"},{24, "SQ"},
  {25, "VS"},{26, "VL"},{27, "VG"},{28, "VT"},{29, "NP"},
  {30, "HC"},{31, "VC"},{32, "V2"},{33, "S2"},{34, "V3"},
  {35, "S3"},{36, "CR"},{37, "CC"},{38, "PR"},{39, "SD"},
  {40, "ZZ"},{41, "RD"},{42, "ET"},{43, "EZ"},{44, "TV"},
  {45, "ZV"},{46, "SN"}
};

// ����ü �󼼺з���(NCAR) ����ǥ
#define  NUM_HCI_DETAIL_COLOR  16
struct RDR_HCI_DETAIL_COLOR {
  int  hci;
  char hci_ko[40];
  int  color;
  int  R;
  int  G;
  int  B;
} hci_detail_color[NUM_HCI_DETAIL_COLOR] = {
  { 0,"����",     0,255,255,255},
  { 1,"����",     0,204,255,204},
  { 2,"�̽���",   0,153,204,255},
  { 3,"���Ѻ�",   0,102,153,255},
  { 4,"�߰���",   0, 51,102,255},
  { 5,"���Ѻ�",   0, 51, 51,204},
  { 6,"���",     0,255, 51,  0},
  { 7,"���/ ��", 0,255,102,  0},
  { 8,"���S/�ζ���", 0,255,153,153},
  { 9,"�ζ��� /��",0,255,204,204},
  {10,"�Ǽ�",     0,255,102,255},
  {11,"����",     0,102,255,255},
  {14,"���ð�",   0, 51,204,204},
  {12,"������", 0,245,255,102},
  {13,"����",   0,255,204,102},
  {50,"�񰭼�",   0,210,210,210},
};

//------------------------------------------------------------------------------
// ������
struct INPUT_VAR  var;
struct STN_VAL  stn_data[MAX_STN];
short  **rdr_cmp_echo;  // �ռ� �����ڷ�

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main()
{
  float km_px;
  int   num_sm, i;
  int   err = 0;

  // 1. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(20);

  printf("HTTP/1.0 200 OK\n");
  //printf("Content-type: text/plain\n\n");

  // 2. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    rdr_stn_err_img(-1);
    return 0;
  }

  // 3. ���� �� ���� ���� ���� Ȯ�� (UF������ ����)
  if ((err = rdr_cmp_stn()) < 0) {
    rdr_stn_err_img(err);
    return 0;
  }
  grid_map_inf(var.map, &(var.NX), &(var.NY), &(var.SX), &(var.SY));

  // 4. �������� �ϰ�, Ȯ�� ó��
  if (var.aws > 0 && var.zoom_level > 0) {
    aws_info_get();
    aws_data_get();
    aws_zooming();
  }

  // 5. ���̴� ������ �ڷ� ǥ��
  rdr_stn2_img();

  // 6. �޸� �ݳ�
  free_smatrix(rdr_cmp_echo, 0, CMP_NY, 0, CMP_NX);

  alarm(0);
  return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
  char *qs;
  char tmp[256], item[32], value[32], tm[30];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, i, j;

  // 1. ���� �ʱⰪ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "0");        // ����ð�
  strcpy(var.map, "HR");  // ���̴� ����
  var.zoom_level = 0;     // ��ü����
  var.zoom_rate = 2;      // 2�� Ȯ�밡 �⺻
  var.ZRa = 200;
  var.ZRb = 1.6;
  var.num_gov = 0;
  var.aws = 0;
  var.sms = 1;
  var.legend = 1;
  var.dir_mode = 0;
  var.maxavg = 'M';

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"stn")) strcpy(var.stn, value);
    else if ( !strcmp(item,"cmp")) strcpy(var.cmp, value);
    else if ( !strcmp(item,"obs")) strcpy(var.obs, value);
    else if ( !strcmp(item,"cpi")) strcpy(var.cpi, value);
    else if ( !strcmp(item,"swpn")) var.swpn = atoi(value);
    else if ( !strcmp(item,"ht")) var.cappi_ht = atof(value)*1000;
    else if ( !strcmp(item,"area")) var.area = atoi(value);
    else if ( !strcmp(item,"ang")) var.ang = atof(value);
    else if ( !strcmp(item,"map")) strcpy(var.map, value);
    else if ( !strcmp(item,"color")) strcpy(var.color, value);
    else if ( !strcmp(item,"tm"))  strcpy(tm, value);
    else if ( !strcmp(item,"auto_man")) var.auto_man = value[0];
    else if ( !strcmp(item,"aws")) var.aws = atoi(value);
    else if ( !strcmp(item,"gov")) {
      for (var.num_gov = 0, j = 0; value[0] != '\0'; j++) {
        getword (tmp, value, ':');
        if (strlen(tmp) >= 3) {
          strcpy(var.gov_cd[var.num_gov], tmp);
          var.num_gov++;
        }
      }
    }
    else if ( !strcmp(item,"sms")) var.sms = atoi(value);
    else if ( !strcmp(item,"ZRa")) var.ZRa = atof(value);
    else if ( !strcmp(item,"ZRb")) var.ZRb = atof(value);
    else if ( !strcmp(item,"zoom_level")) var.zoom_level = atoi(value);
    else if ( !strcmp(item,"zoom_rate"))  var.zoom_rate = atoi(value);
    else if ( !strcmp(item,"zoom_x")) strcpy(var.zoom_x, value);
    else if ( !strcmp(item,"zoom_y")) strcpy(var.zoom_y, value);
    else if ( !strcmp(item,"size")) var.size = atoi(value);
    else if ( !strcmp(item,"legend")) var.legend = atoi(value);
    else if ( !strcmp(item,"dir")) var.dir_mode = atoi(value);
  }

  // 3. �⺻�� ����
  // 3.1. �������� �ϳ��� ���
  if (strcmp(var.cmp,"HSR") == 0 || strcmp(var.cmp,"VER") == 0 ||
      strcmp(var.cmp,"LNG") == 0 || strcmp(var.cmp,"LQC") == 0) {
    var.swpn = 0;
    strcpy(var.cpi,"PPI");
  }

  // 3.3. �ݰ�
  if (var.area == 2)
    var.range = 250;
  else if (var.area == 4)
    var.range = 480;
  else
    var.range = 250;
  var.range *= 1000;  // km->m

  // 3.4. ������
  if (var.num_gov == 0) {
    var.num_gov = 1;
    strcpy(var.gov_cd[0],"KMA");
  }

  // 3.5. ������ ���, ZR ����� ����
  if (strcmp(var.obs, "SN") == 0) {
    var.ZRa = 2000;
    var.ZRb = 2.0;
  }
  else {
    if (var.ZRa == 0) var.ZRa = 200;
    if (var.ZRb == 0) var.ZRa = 1.6;
  }

  // 4. ����ð� �� ���� �����ð� ����
  get_time(&iYY, &iMM, &iDD, &iHH, &iMI, &iSS);
  iseq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  var.seq_now = iseq;

  // 5. ��û�ð� ����
  if (strlen(tm) < 10 || var.auto_man == 'a')
    var.seq = iseq;
  else {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
    var.seq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  }

  // 6. ���� ã��
  for (i = 0; i < 30; i++, var.seq--) {
    if (rdr_stn_file() >= 0) break;
  }
  return 0;
}

/*******************************************************************************
 *
 *  �ڷᰡ �̻��� �ִ� ���, ���� �̹��� ���
 *
 *******************************************************************************/
int rdr_stn_err_img(int err)
{
  Radar  *radar;
  Volume *volume;
  gdImagePtr im;
  char  text[120], tmp[120];
  int   YY, MM, DD, HH, MI;
  int   color_lvl[16];
  int   x = 20, y = 30, i, j, k, n;

  // 1. �̹��� ���� ����
  var.NI = var.size;
  var.NJ = var.NI;
  var.GI = var.NI;
  if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + TITLE_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_lvl[0] = gdImageColorAllocate(im, 240, 240, 240);   // ����
  color_lvl[1] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[0]);

  // 3. ���� �޽���
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(text, "TIME = %04d.%02d.%02d.%02d:%02d / err = %d", YY, MM, DD, HH, MI, err);
  gdImageString(im, gdFontLarge, x, y, text, color_lvl[1]);

  sprintf(text, "SITE = %s / %s / %s", var.stn, var.cmp, var.obs);
  gdImageString(im, gdFontLarge, x, (y += 20), text, color_lvl[1]);

  sprintf(text, "MODE = %s / swpn = %d / cappi = %.2fkm", var.cpi, var.swpn, var.cappi_ht);
  gdImageString(im, gdFontLarge, x, (y += 20), text, color_lvl[1]);

  sprintf(text, "SIZE = %dpx / ZRa = %.1f / ZRb = %.2f", var.size, var.ZRa, var.ZRb);
  gdImageString(im, gdFontLarge, x, (y += 20), text, color_lvl[1]);

  if (err == -10)
    sprintf(text, "FILE = %s (file is not found)", var.fname);
  else
    sprintf(text, "FILE = %s", var.fname);
  gdImageString(im, gdFontLarge, x, (y += 20), text, color_lvl[1]);

  if (err < -11) {
    sprintf(text, "Vol.(%s:%d) is not exist", var.obs, var.voln);
    gdImageString(im, gdFontLarge, x, (y += 20), text, color_lvl[1]);

    gdImageString(im, gdFontLarge, x, (y += 20), "Vols : ", color_lvl[1]);
    if ((radar = RSL_uf_to_radar(var.fname)) != NULL) {
      for (n = 0, k = 0; k < radar->h.nvolumes; k++) {
        if ((volume = radar->v[k]) == NULL) continue;
        for (i = 0; i < 14; i++) {
          if (k == vol_inf[k].voln) {
            x = 110 + n*25;
            gdImageString(im, gdFontLarge, x, y, vol_inf[k].vol_cd, color_lvl[1]);
            n++;
            break;
          }
        }
      }
      RSL_free_radar(radar);
    }
  }

  // 4. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);

  return 0;
}

/*******************************************************************************
 *
 *  ���̴� ������ �̹��� ���� �� ǥ��
 *
 *******************************************************************************/
int rdr_stn2_img()
{
  gdImagePtr im;
  FILE  *fp;
  int   color_lvl[256];
  float data_lvl[256];

  // 1. �̹��� ���� ����
  var.NI = var.size;
  var.NJ = (int)((float)(var.NY)/(float)(var.NX)*var.NI);
  var.GI = var.NI;
  if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + TITLE_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_table(im, color_lvl, data_lvl);
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[240]);

  // 3. �����ڷ� �׸���
  grid_disp(im, color_lvl, data_lvl);

  // 4. ���� �׸���
  if (var.zoom_level >= 1) map_disp(im, color_lvl[249], 1);
  map_disp(im, color_lvl[242], 4);

  // 6. ���� ǥ��
  if (var.aws > 0 && var.zoom_level > 0) aws_disp(im, color_lvl);

  // 7. ���� ǥ��
  title_disp(im, color_lvl);

  // 8. ���� �׸���
  legend_disp(im, color_lvl, data_lvl);
  gdImageRectangle(im, 0, TITLE_pixel, var.NI-1, var.GJ-1, color_lvl[242]);

  // 9. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);
  return 0;
}

/*=============================================================================*
 *  ����ǥ
 *=============================================================================*/
int color_table(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  FILE  *fp;
  char  color_file[120];
  int   num_color;
  int   R, G, B;
  float v1;

  // 1. HCI ����ǥ ����
  if (strcmp(var.cmp,"HCI") == 0) {
    var.num_color = NUM_HCI_DETAIL_COLOR;
    for (num_color = 0; num_color < NUM_HCI_DETAIL_COLOR; num_color++) {
      R = hci_detail_color[num_color].R;
      G = hci_detail_color[num_color].G;
      B = hci_detail_color[num_color].B;
      hci_detail_color[num_color].color = gdImageColorAllocate(im, R, G, B);
    }
  }

  // 2. ��Ÿ �����鿡 ���� ����ǥ �ڷ� �б�
  else {
    strcpy(color_file,COLOR_SET_DIR);
    if (strcmp(var.obs,"ET") == 0)
      strcat(color_file,"color_rdr_ebh.rgb");
    else if (strcmp(var.obs,"EZ") == 0)
      strcat(color_file,"color_rdr_ebh.rgb");
    else {
      strcat(color_file,"color_rdr_");
      strcat(color_file,var.obs);
      strcat(color_file,".rgb");
    }

    var.num_color = 0;
    if ((fp = fopen(color_file, "r")) != NULL) {
      while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
        color_lvl[var.num_color] = gdImageColorAllocate(im, R, G, B);
        data_lvl[var.num_color] = v1;
        var.num_color++;
        if (var.num_color > 119) break;
      }
      fclose(fp);
    }
  }

  // 3. ��Ÿ ����ǥ ����
  color_lvl[240] = gdImageColorAllocate(im, 180, 180, 180);   // ����1
  color_lvl[241] = gdImageColorAllocate(im, 255, 255, 255);   // ����2
  color_lvl[242] = gdImageColorAllocate(im, 30, 30, 30);      // ������
  color_lvl[243] = gdImageColorAllocate(im, 12, 28, 236);     // ����
  color_lvl[244] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  color_lvl[245] = gdImageColorAllocate(im, 240, 240, 240);
  color_lvl[246] = gdImageColorAllocate(im, 255, 0, 0);
  color_lvl[247] = gdImageColorAllocate(im, 0, 0, 255);
  color_lvl[248] = gdImageColorAllocate(im, 160, 160, 160);   // ����3
  color_lvl[249] = gdImageColorAllocate(im, 110, 110, 110);   // �ñ����
  return 0;
}

/*=============================================================================*
 *  �����ڷ� ǥ��
 *=============================================================================*/
int grid_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  unsigned char *n1, *n2;
  short *e1, *e2;
  float *r1, *r2;
  short blank = BLANK1;

  float lvl[256], dbz1, rain1;
  float x1, y1, x, y, dd, d1, d2, dd1, dd2;
  float zm = 1.0, xo = 0.0, yo = 0.0;
  float grid_nx, grid_ny, zx, zy, rate, wy1, wy2, wx1, wx2;
  int   dxy, nx, ny, map_code;
  int   nd, ix, iy, color1, intp = 0;
  int   hci_ok = 0, dn;
  int   i, j, k;
  char  txt[100];

  // 1. ����ó��
  if (var.num_color <= 0) {
    gdImageString(im, gdFontLarge, 100, 100, "No Color Level", color_lvl[244]);
    return -1;
  }

  // 2. �⺻ ����
  dxy = 500;
  grid_ny = 1000.0*(float)(var.NY)/(float)dxy;
  grid_nx = 1000.0*(float)(var.NX)/(float)dxy;
  yo = 1000.0*(float)(SY_B-var.SY)/(float)dxy;
  xo = 1000.0*(float)(SX_B-var.SX)/(float)dxy;
  rate = grid_nx/(float)(var.NI);    // �̹��� �ȼ��� ���ڼ�
  if (strcmp(var.cmp,"HCI") == 0)
    hci_ok = 1;
  else
    hci_ok = 0;

  // 3. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    if (var.zoom_rate == 3) {
      for (i = 0; i < 2; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (grid_nx/9.0*(zx-1)/zm);
        yo += (grid_ny/9.0*(zy-1)/zm);
        zm *= var.zoom_rate;
      }
    }
    else if (var.zoom_rate == 2) {
      for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (grid_nx/8.0*(zx-1)/zm);
        yo += (grid_ny/8.0*(zy-1)/zm);
        zm *= var.zoom_rate;
      }
    }
  }

  // 4. ���� ����
  if (strcmp(var.obs,"RN") == 0 || strcmp(var.obs,"SN") == 0) {
    for (k = 0; k < var.num_color; k++) {
      rain1 = data_lvl[k];
      dbz_rain_conv(&dbz1, &rain1, 1);
      lvl[k] = dbz1*100;
    }
  }
  else {
    for (k = 0; k < var.num_color; k++)
      lvl[k] = data_lvl[k]*100;
  }

  // 5. �̹��� �ȼ����� ���
  for (j = 1; j < var.NJ; j++) {
    y1 = rate*j/zm + yo;
    iy = (int)(y1);
    if (iy < 1 || iy >= CMP_NY-1) continue;
    wy2 = y1 - iy;
    wy1 = 1.0 - wy2;

    e1 = rdr_cmp_echo[iy];
    e2 = rdr_cmp_echo[iy+1];

    for (i = 1; i < var.NI; i++) {
      x1 = rate*i/zm + xo;
      ix = (int)(x1);
      if (ix < 1 || ix >= CMP_NX-1) continue;
      wx2 = x1 - ix;
      wx1 = 1.0 - wx2;

      // ����ü�� ���
      if (hci_ok) {
        dn = (int)(*(e1+ix)*0.01 + 0.1);
        for (k = 0; k < NUM_HCI_DETAIL_COLOR; k++) {
          if (dn == hci_detail_color[k].hci) {
            gdImageSetPixel(im, i, var.GJ-j, hci_detail_color[k].color);
            break;
          }
        }
      }
      else {
        // �����Ͽ� ���
        if (intp) {
          d1 = *(e1+ix);
          d2 = *(e1+ix+1);
          if (d1 > BLANK3) {
            if (d2 > BLANK3)
              dd1 = d1*wx1 + d2*wx2;
            else
              dd1 = d1;
          }
          else
            dd1 = d2;

          d1 = *(e2+ix);
          d2 = *(e2+ix+1);
          if (d1 > BLANK3) {
            if (d2 > BLANK3)
              dd2 = d1*wx1 + d2*wx2;
            else
              dd2 = d1;
          }
          else
            dd2 = d2;

          if (dd1 > BLANK3) {
            if (dd2 > BLANK3)
              dd = dd1*wy1 + dd2*wy2;
            else
              dd = dd1;
          }
          else
            dd = dd2;
        }
        else {
          dd = *(e1+ix);
        }

        // ���� ����
        if (dd > BLANK1) {
          color1 = color_lvl[var.num_color-1];
          for (k = 0; k < var.num_color; k++) {
            if (dd <= lvl[k]) {
              color1 = color_lvl[k];
              break;
            }
          }
          gdImageSetPixel(im, i, var.GJ-j, color1);
        }
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  Z-R �����
 *     - mode : 0(dBZ->������), 1(������->dBZ)
 *=============================================================================*/
int dbz_rain_conv(float *dbz, float *rain, int mode)
{
  static int first = 0;
  static float za, zb;

  if (first == 0) {
    za = 0.1/var.ZRb;
    zb = log10(var.ZRa)/var.ZRb;
    first = 1;
  }

  if (mode == 0) {
    //*rain = (*dbz*0.1 - log10(var.ZRa) )/var.ZRb;
    *rain = *dbz*za - zb;
    *rain = pow(10.0, *rain);
  }
  else if (mode == 1) {
    *dbz = 10.0 * log10( var.ZRa * pow(*rain, var.ZRb) );
  }
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int map_disp(gdImagePtr im, int color_map, int kind)
{
  FILE  *fp;
  char  fname[120];
  float zm = 1.0, xo = 0.0, yo = 0.0, x1, y1, x2, y2;
  int   zx, zy, depth, mode;
  int   i, j, k, n;

  // 0. �ʱ� ����
  if (var.NI > 600)
    depth = 1;
  else if (var.NI > 300 && kind == 4)
    depth = 1;
  else
    depth = 0;

  // 1. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    if (var.zoom_rate == 3) {
      for (i = 0; i < 2; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/9.0*(zx-1)/zm;
        yo += (float)(var.NY)/9.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
    else if (var.zoom_rate == 2) {
      for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/8.0*(zx-1)/zm;
        yo += (float)(var.NY)/8.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
  }

  // 2. �ؾȼ� ǥ��
  sprintf(fname, "%s/AFS_%s_map%d.dat", MAP_DIR, var.map, kind);
  if ((fp = fopen(fname, "r")) != NULL) {
    while (fscanf(fp, "%d %d\n", &n, &mode) != EOF) {
      for (i = 0; i < n; i++) {
        fscanf(fp, "%f %f\n", &x2, &y2);
        if (var.zoom_level > 0) {
          x2 = zm*(x2-xo);
          y2 = zm*(y2-yo);
        }
        x2 *= ((float)(var.NI)/(float)(var.NX));
        y2 *= ((float)(var.NI)/(float)(var.NX));
        if (i > 0) {
          gdImageLine(im, (int)x1, var.GJ-(int)y1, (int)x2, var.GJ-(int)y2, color_map);
          if (depth) gdImageLine(im, (int)x1, var.GJ-(int)y1-1, (int)x2, var.GJ-(int)y2-1, color_map);
        }
        x1 = x2;
        y1 = y2;
      }
    }
    fclose(fp);
  }

  return 0;
}

/*=============================================================================*
 *  EUC-KR���ڿ��� UTF-8�� ��ȯ
 *=============================================================================*/
int euckr2utf(char *str, char *out)
{
    iconv_t convp;
    size_t  ileft, oleft;
    int     err, len = strlen(str);

    ileft = len;
    oleft = len * 2;

    convp = iconv_open("UTF-8", "euc-kr");
    err = iconv(convp, &str, &ileft, &out, &oleft);
    iconv_close(convp);

    return err;
}

/*=============================================================================*
 *  ���� ǥ��(�ѱ�ó��)
 *=============================================================================*/
int title_disp(gdImagePtr im, int color_lvl[])
{
  char   title[80], tm_fc_str[100], num_stn_str[10], tmp[50];
  char   title_utf[100];
  double font_size = 11.5;
  int    brect[8];
  int    YY, MM, DD, HH, MI;
  int    x, y, i, k;

  // 1. ���񿵿��� ���� ó��
  gdImageFilledRectangle(im, 0, 0, var.GI, TITLE_pixel, color_lvl[241]);

  // 2. ���� ǥ��
  // 2.1 ������
  if      (strcmp(var.stn,"BRI") == 0) strcpy(title,"��ɵ�");
  else if (strcmp(var.stn,"KWK") == 0) strcpy(title,"���ǻ�");
  else if (strcmp(var.stn,"GDK") == 0) strcpy(title,"������");
  else if (strcmp(var.stn,"GNG") == 0) strcpy(title,"����");
  else if (strcmp(var.stn,"KSN") == 0) strcpy(title,"������");
  else if (strcmp(var.stn,"JNI") == 0) strcpy(title,"����");
  else if (strcmp(var.stn,"MYN") == 0) strcpy(title,"�����");
  else if (strcmp(var.stn,"PSN") == 0) strcpy(title,"������");
  else if (strcmp(var.stn,"GSN") == 0) strcpy(title,"����");
  else if (strcmp(var.stn,"SSP") == 0) strcpy(title,"����");
  else if (strcmp(var.stn,"IMJ") == 0) strcpy(title,"������");
  else if (strcmp(var.stn,"GRS") == 0) strcpy(title,"������");
  else if (strcmp(var.stn,"SBS") == 0) strcpy(title,"�ҹ��");
  else if (strcmp(var.stn,"SDS") == 0) strcpy(title,"�����");
  else if (strcmp(var.stn,"MHS") == 0) strcpy(title,"���Ļ�");
  else if (strcmp(var.stn,"BSL") == 0) strcpy(title,"�񽽻�");
  else if (strcmp(var.stn,"MIL") == 0) strcpy(title,"���ϻ�");
  else if (strcmp(var.stn,"SRI") == 0) strcpy(title,"������");
  else if (strcmp(var.stn,"DJK") == 0) strcpy(title,"������");
  else if (strcmp(var.stn,"K03") == 0) strcpy(title,"Ȳ����");
  else if (strcmp(var.stn,"K02") == 0) strcpy(title,"����");
  else if (strcmp(var.stn,"K01") == 0) strcpy(title,"����");
  else if (strcmp(var.stn,"RKSG") == 0) strcpy(title,"����(��)");
  else if (strcmp(var.stn,"RKJK") == 0) strcpy(title,"����(��)");
  else if (strcmp(var.stn,"KAN") == 0) strcpy(title,"����A");
  else if (strcmp(var.stn,"KWJ") == 0) strcpy(title,"����A");
  else if (strcmp(var.stn,"TAG") == 0) strcpy(title,"�뱸A");
  else if (strcmp(var.stn,"SCN") == 0) strcpy(title,"��õA");
  else if (strcmp(var.stn,"SAN") == 0) strcpy(title,"����A");
  else if (strcmp(var.stn,"SWN") == 0) strcpy(title,"����A");
  else if (strcmp(var.stn,"YCN") == 0) strcpy(title,"��õA");
  else if (strcmp(var.stn,"WNJ") == 0) strcpy(title,"����A");
  else if (strcmp(var.stn,"JWN") == 0) strcpy(title,"�߿�A");
  else  strcpy(title,var.stn);
  strcat(title," ");

  // 2.2. �ڷ�����
  strcat(title, var.cmp);

  // 2.3. ������
  if (strcmp(var.cmp,"HCI") != 0) {
    strcat(title, " ");
    if (strcmp(var.obs,"RN") == 0)
      strcat(title, "����");
    else if (strcmp(var.obs,"SN") == 0)
      strcat(title, "����");
    else
      strcat(title, var.obs);
  }

  // 2.4. ǥ����
  if (strcmp(var.cmp,"HSR") == 0 || strcmp(var.cmp,"VER") == 0) {
    sprintf(tmp, " %s", var.cmp);
  }
  else {
    if (strcmp(var.cpi,"CPP") == 0)
      sprintf(tmp, " CAPPI(%.0fm)", var.cappi_ht);
    else
      sprintf(tmp, " PPI(%.1f��)", var.swp_deg);
  }
  strcat(title,tmp);

  // 2.5. ���� ǥ��
  for (i = 0; i < 100; i++)
    title_utf[i] = 0;
  euckr2utf(title, title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 5, (int)(font_size+5), title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 6, (int)(font_size+5), title_utf);

  // 3. �ð� ���ڿ�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(tm_fc_str, "%04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, MI);

  x = strlen(title)*8.5 + 10;
  gdImageString(im, gdFontLarge, x, 1, tm_fc_str, color_lvl[244]);
  gdImageString(im, gdFontLarge, x+1, 1, tm_fc_str, color_lvl[244]);

  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int legend_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  char   txt[20], txt_utf[30];
  double font_size = 9.0;
  int    brect[8];
  float  dy = (float)(var.NJ)/(float)(var.num_color);
  int    YY, MM, DD, HH, MI;
  int    x, y, i, j, k;

  if (var.legend != 1) return 0;
  if (var.num_color <= 0) return -1;

  // 1. ���� ���� ǥ��
  if (strcmp(var.cmp,"HCI") == 0) {
    for (k = 0; k <= var.num_color-1; k++) {
      y = TITLE_pixel + dy*k;
      gdImageFilledRectangle(im, var.NI, y, var.NI+8, y+dy, hci_detail_color[k].color);
    }
  }
  else {
    for (k = 0; k < var.num_color; k++) {
      y = var.GJ - dy*k;
      gdImageFilledRectangle(im, var.NI, y-dy, var.NI+8, y, color_lvl[k]);
    }
  }
  gdImageRectangle(im, var.NI-1, TITLE_pixel, var.NI+8, var.GJ-1, color_lvl[242]);

  // 2. ���ʰ� ǥ��
  gdImageFilledRectangle(im, var.NI+9, 0, var.GI-1, var.GJ, color_lvl[241]);
  if (strcmp(var.cmp,"HCI") == 0) {
    font_size = 9.0;
    for (k = 0; k <= var.num_color-1; k++) {
      for (j = 0; j < strlen(hci_detail_color[k].hci_ko)-1; j += 4) {
        y = TITLE_pixel + dy*k + dy/4 + j*4;
        strncpy(txt, &(hci_detail_color[k].hci_ko[j]), 4);
        txt[4] = '\0';
        for (i = 0; i < 30; i++) txt_utf[i] = 0;
        euckr2utf(txt, txt_utf);
        gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, var.NI+11, y, txt_utf);
      }
    }
  }
  else if (strcmp(var.obs,"RH") == 0) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.2f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (strcmp(var.obs,"RN") == 0 || strcmp(var.obs,"SN") == 0) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      if (data_lvl[k] >= 5)
        sprintf(txt, "%.0f", data_lvl[k]);
      else
        sprintf(txt, "%.1f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (strcmp(var.obs,"DZ") == 0 || strcmp(var.obs,"CZ") == 0 ||
           strcmp(var.obs,"VR") == 0 || strcmp(var.obs,"PH") == 0 ) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.1f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }

  // 3. ���� ���� ǥ��
  if      (strcmp(var.obs,"RN") == 0) strcpy(txt,"mm/h");
  else if (strcmp(var.obs,"SD") == 0) strcpy(txt,"cm/h");
  else if (strcmp(var.obs,"DZ") == 0) strcpy(txt,"dBZ");
  else if (strcmp(var.obs,"VR") == 0) strcpy(txt,"m/s");
  else if (strcmp(var.obs,"SW") == 0) strcpy(txt,"m/s");
  else if (strcmp(var.obs,"CZ") == 0) strcpy(txt,"dBZ");
  else if (strcmp(var.obs,"DR") == 0) strcpy(txt,"dB");
  else if (strcmp(var.obs,"RH") == 0) strcpy(txt,"");
  else if (strcmp(var.obs,"PH") == 0) strcpy(txt,"deg");
  else if (strcmp(var.obs,"KD") == 0) strcpy(txt,"deg/km");
  else if (strcmp(var.obs,"HC") == 0) strcpy(txt,"");
  else if (strcmp(var.obs,"ET") == 0) strcpy(txt,"deg");
  else if (strcmp(var.obs,"EZ") == 0) strcpy(txt,"km");

  x = var.NI - 3;
  gdImageString(im, gdFontLarge, x, 4, txt, color_lvl[244]);
  return 0;
}

/*=============================================================================*
 *  ���� ���� ���� �б�
 *
 *      map : inp:������ ����
 *      nx  : out:�������� �������� (km)
 *      ny  : out:���Ϲ��� �������� (km)
 *      sx  : out:�������� ������ġ (km)
 *      sy  : out:���Ϲ��� ������ġ (km)
 *=============================================================================*/
int grid_map_inf(char *map, int *nx, int *ny, int *sx, int *sy)
{
  FILE  *fp;
  char  buf[1024], map_list[8], value[16];

  fp = fopen(MAP_INI_FILE,"r");
  if (fp == NULL) exit(-1);

  while (fgets(buf,1024,fp)) {
    if (buf[0] == '#') continue;
    getword(map_list, buf, ':');

    if ( !strcmp(map, map_list) ) {
      getword(value, buf, ':');  *nx = atoi(value);
      getword(value, buf, ':');  *ny = atoi(value);
      getword(value, buf, ':');  *sx = atoi(value);
      getword(value, buf, ':');  *sy = atoi(value);
      break;
    }
  }
  fclose(fp);
  return 0;
}
