#include "rdr_r3d_img.h"

extern struct INPUT_VAR  var;
extern struct STN_VAL  stn_data[];
FILE   *fp_log;

/*******************************************************************************
 *  AWS �ڷ� ǥ��
 *******************************************************************************/
int aws_disp(gdImagePtr im, int color_lvl[])
{
  float  wr, ang, ws, ang_s, wr_s;
  float  rate = (float)(var.NI)/(float)(var.NX), d1;
  char   txt[30];
  char   txt_utf[30];
  double font_size = 10.0;
  int    brect[8];
  int    x, y, x1, y1, x2, y2;
  int    stn_min = -1, stn_max = -1;
  int    color_dot, maxmin;
  int    i, j, k;

  // 1. ���� ǥ�⿩�� Ȯ��
  if (var.num_aws_stn <= 0 || var.num_aws_stn <= 0 || var.aws == 0 || var.zoom_level <= 0) return 0;

  for (k = 0; k < var.num_aws_stn; k++) {
    // 2.0. 1�ܰ迡���� ����/�����ұ޸� ǥ��
    if (var.zoom_level <= 2 && (stn_data[k].stn_id < 90 || stn_data[k].stn_id >= 300)) continue;

    // 2.1. �������� �ִ��� Ȯ��
    if (stn_data[k].x <= 0 || stn_data[k].x >= var.NX || stn_data[k].y <= 0 || stn_data[k].y >= var.NY) continue;

    // 2.2. �̹��� ���� ��ġ Ȯ��
    x = (int)(stn_data[k].x*rate);
    y = var.GJ - (int)(stn_data[k].y*rate);

    // 2.3. ǳ��� ǥ��
    if (var.aws >= 6) {
      // 2.3.1. ǳ��� ǥ��
      wr = 30;
      if (stn_data[k].wd >= 0 && stn_data[k].ws > 0.2) {
        ang = stn_data[k].wd*DEGRAD;
        x1 = x + wr*sin(ang);
        y1 = y - wr*cos(ang);
        gdImageLine(im, x, y, x1,   y1,   color_lvl[244]);
      }

      // 2.3.2. ǳ�ӱ� ǥ��
      if (stn_data[k].wd >= 0 && stn_data[k].ws > 0.2) {
        ws = stn_data[k].ws;
        ang_s = (stn_data[k].wd + 60.0)*DEGRAD;

        while (ws > 0.0) {
          if (ws >= 5.0) wr_s = 20.0;
          else           wr_s = 4.0*ws;

          x2 = x1 + wr_s*sin(ang_s);
          y2 = y1 - wr_s*cos(ang_s);
          gdImageLine(im, x1, y1, x2,   y2,   color_lvl[244]);

          ws -= 5.0;
          wr -= 5.0;
          x1 = x + wr*sin(ang);
          y1 = y - wr*cos(ang);
        }
      }
    }

    // 2.4. �������� ǥ��
    color_dot = color_lvl[246];
    if (stn_data[k].re == 1) color_dot = color_lvl[247];
    gdImageFilledArc(im, x, y, 8, 8, 0, 360, color_lvl[245], gdArc);
    gdImageFilledArc(im, x, y, 5, 5, 0, 360, color_dot, gdArc);

    // 2.5. ������ ǥ��
    if (var.aws == 1 || var.aws == 6) {
      sprintf(txt, "%s", stn_data[k].stn_ko);
      for (i = 0; i < 30; i++)
        txt_utf[i] = 0;
      euckr2utf(txt, txt_utf);
      x -= 10;  y += 15;
      gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, x,   y, txt_utf);
    }

    // 2.6. ����ID ǥ��
    else if (var.aws == 2 || var.aws == 7) {
      sprintf(txt, "%d", stn_data[k].stn_id);
      x -= 10;  y += 3;
      gdImageString(im, gdFontLarge, x,   y,   txt, color_lvl[244]);
   }

    // 2.6. ������ ǥ��
    else if ((var.aws >- 3 && var.aws <= 5) || (var.aws >= 8 && var.aws <= 10)) {
      if (stn_data[k].d >= 0) {
        x -= 10;  y += 3;
        if (stn_data[k].d > 0)
          sprintf(txt, "%.1f", stn_data[k].d);
        else {
          sprintf(txt, "0");
          x += 7;
        }
        gdImageString(im, gdFontLarge, x,   y,   txt, color_lvl[244]);
      }
    }
  }
  return 0;
}

/*******************************************************************************
 *  AWS �ڷ� �б�
 *******************************************************************************/
int aws_data_get() {
  FILE     *fp;
  URL_FILE *fr; 
  struct AWS3_DATA aws[1];
  int    seq, YY, MM, DD, HH, MI;
  int    code, qc, i, j, k;

  // 0. �ð� ����(���̴� �ð����� +10������ ��. ���� ����ð����� ũ�� ����ð� ���)
  seq = var.seq + 10;
  if (seq >= var.seq_now - 3) seq = var.seq;
  seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  // 1. ������ ������ �б�
  for (k = 0; k < var.num_aws_stn; k++) {
    // 1.1. �ڷ� �б�
    code = AWS3_DATA_READ(YY, MM, DD, HH, MI, stn_data[k].stn_id, aws, 'r');
    if (code != 0) continue;

    // 1.2. 15�� ������*4
    if (var.aws == 3 || var.aws == 8) {
      if (aws[0].d[67] >= 0)
        stn_data[k].d = aws[0].d[67]*0.4;
      else
        stn_data[k].d = -999;
    }

    // 1.3. 60�� ������
    if (var.aws == 4 || var.aws == 9) {
      if (aws[0].d[68] >= 0)
        stn_data[k].d = aws[0].d[68]*0.1;
      else
        stn_data[k].d = -999;
    }

    // 1.4. 3�ð� ������
    if (var.aws == 5 || var.aws == 10) {
      if (aws[0].d[69] >= 0)
        stn_data[k].d = aws[0].d[69]*0.1;
      else
        stn_data[k].d = -999;
    }

    // 1.8. ��������
    if (aws[0].d[7] >= 0 && aws[0].d[67] >= 0) {
      if (aws[0].d[7] > 0 || aws[0].d[67] > 0)
        stn_data[k].re = 1;
      else
        stn_data[k].re = 0;
    }
    else
      stn_data[k].re = -999;

    // 1.9. ǳ��,ǳ��
    if (aws[0].d[65] >= 0 && aws[0].d[66] >= 0) {
      stn_data[k].wd = aws[0].d[65]*0.1;
      stn_data[k].ws = aws[0].d[66]*0.1;
    }
    else {
      stn_data[k].wd = -999;
      stn_data[k].ws = -999;
    }
  }
  return 0;
}

/*******************************************************************************
 *  Ȯ���, ���� ��ǥ�� Ȯ��
 *******************************************************************************/
int aws_zooming()
{
  float ox = 0.0, oy = 0.0, zm = 1.0;
  int   zx, zy, i, k;

  // 1. Ȯ��ø�, �׸��� �ڷᰡ ��������
  var.num_area_stn = var.num_aws_stn;
  if (var.zoom_level == 0) return 0;
  if (var.num_aws_stn <= 0) return 0;

  // 2. ���� ��ġ Ȯ�� ���� ���� ����
  if (var.zoom_rate == 3) {
    for (i = 0; i < 2; i++) {
      zx = var.zoom_x[i]-'0';
      zy = var.zoom_y[i]-'0';
      if (zx == 0 || zy == 0) break;
      ox += (var.NX/9.0*(zx-1)/zm);
      oy += (var.NY/9.0*(zy-1)/zm);
      zm *= var.zoom_rate;
    }
  }
  else if (var.zoom_rate == 2) {
    for (i = 0; i < 7; i++) {
      zx = var.zoom_x[i]-'0';
      zy = var.zoom_y[i]-'0';
      if (zx == 0 || zy == 0) break;
      ox += (var.NX/8.0*(zx-1)/zm);
      oy += (var.NY/8.0*(zy-1)/zm);
      zm *= var.zoom_rate;
    }
  }

  // 3. Ȯ��� ���� ���� ��ġ
  for (k = 0; k < var.num_aws_stn; k++) {
    stn_data[k].x = zm*(stn_data[k].x - ox);
    stn_data[k].y = zm*(stn_data[k].y - oy);
  }

  // 4. ǥ�⿵���� ������
  for (var.num_area_stn = 0, k = 0; k < var.num_aws_stn; k++) {
    if (stn_data[k].x > 0 && stn_data[k].x < var.NX && stn_data[k].y > 0 && stn_data[k].y < var.NY)
      var.num_area_stn++;
  }
  return 0;
}

/*******************************************************************************
 *  �������� �б�
 *******************************************************************************/
int aws_info_get()
{
  URL_FILE *fr; 
  struct lamc_parameter map;
  char   buf[1000], url[1000], tmp[500], stn_ko[32], stn_sp[16], gov_lst[1000], obs[8];
  float  lon, lat, xx, yy, ht;
  int    GX, GY, SX, SY;
  int    stn_id, seq;
  int    YY, MM, DD, HH, MI;
  int    i, j, k;

  // 1. MAP parameter
  //grid_map_inf(var.map, &GX, &GY, &SX, &SY);
  map.Re  = 6371.00877;
  map.grid  = 1.0;
  map.slat1 = 30.0;    map.slat2 = 60.0;
  map.olon  = 126.0;   map.olat  = 38.0;
  map.xo = (float)(var.SX)/map.grid;   map.yo = (float)(var.SY)/map.grid;
  map.first = 0;

  // 2. ������ ��ġ��
  for (strcpy(gov_lst,""), i = 0; i < var.num_gov; i++) {
    strcat(gov_lst, var.gov_cd[i]);
    if (i < var.num_gov-1) strcat(gov_lst, ":");
  }

  // 3. �������� �б�� URL-API �ۼ�
  seq2time((int)(var.seq/10)*10, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  strcpy(obs, "RN");
  sprintf(url, "http://172.20.134.147/url/stn_obs_inf.php?mode=3&gov=%s&obs=%s&tm=%04d%02d%02d%02d%02d&disp=0",
          gov_lst, obs, YY, MM, DD, HH, MI);

  // 4. �������� ����
  var.num_aws_stn = 0;
  if ((fr = url_fopen(url, "r"))) {
    while (!url_feof(fr)) {
      url_fgets(buf, sizeof(buf), fr);
      if (buf[0] == '#') continue;

      // �ص�
      getword(tmp, buf, ',');  stn_id = atoi(tmp);  // ������ȣ
      getword(tmp, buf, ',');  strcpy(stn_ko, tmp);   // ������
      getword(tmp, buf, ',');
      getword(tmp, buf, ',');  strcpy(stn_sp, tmp);   // �������
      getword(tmp, buf, ',');
      getword(tmp, buf, ',');
      getword(tmp, buf, ',');
      getword(tmp, buf, ',');  lon = atof(tmp);   // �浵
      getword(tmp, buf, ',');  lat = atof(tmp);   // ����
      getword(tmp, buf, ',');
      if (strlen(tmp) <= 0)   // �ع߰��� ��
        ht = -999;
      else
        ht = atof(tmp);

      // NUM_AWS3 ���� ū ������ ����
      if (stn_id < 0 || stn_id >= NUM_AWS3) continue;

      // ���浵�� ���� ������ ����
      if (lon < 120 || lon > 135 || lat < 30 || lat > 45) continue;

      // �������� ���ų�, �̻��� ���� ����
      if (ht < 0 || ht > 4000) continue;

      // ���� ����
      if (strcmp(stn_sp,"SZ") == 0) continue;   // �ӽ����� ����
      if (strcmp(stn_sp,"PA") == 0) continue;   // ��âAWS ����
      if (strcmp(stn_sp,"PB") == 0) continue;   // ��â���ռ��� ����
      if (strcmp(stn_sp,"SO") == 0) continue;   // ����� ����
      if (strcmp(stn_sp,"AM") == 0) continue;   // AMOS ����

      // ���������� ��Ī
      stn_data[var.num_aws_stn].stn_id = stn_id;
      strcpy(stn_data[var.num_aws_stn].stn_ko, stn_ko);
      strcpy(stn_data[var.num_aws_stn].stn_sp, stn_sp);

      lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);
      stn_data[var.num_aws_stn].x = xx;
      stn_data[var.num_aws_stn].y = yy;
      stn_data[var.num_aws_stn].ht = ht;
      stn_data[var.num_aws_stn].d = -999;
      var.num_aws_stn++;
    }
    url_fclose(fr);
  }
  return 0;
}
