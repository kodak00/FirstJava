#!/bin/sh

export QUERY_STRING="?&cmp=SFC&qcd=PTY&obs=AREA&tm=201812201050&aws=1&map=HR&color=&gis=&griddisp=0&rnexdisp=2&legend=1&size=382&zoom_level=0&zoom_x=0000000&zoom_y=0000000&x1=-10&y1=-10&x2=-10&y2=-10"

#/home/radar/temp/rdr/www/cgi-bin/rdr/nph-rdr_sfc_pty_img > test.png
cgdb /home/radar/temp/rdr/www/cgi-bin/rdr/nph-rdr_sfc_pty_img

