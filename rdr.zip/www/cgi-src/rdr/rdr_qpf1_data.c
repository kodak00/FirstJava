#include "rdr_qpf1_img.h"

extern struct INPUT_VAR var;           // ����� �Է� ����
extern struct MAPLE_HEAD maple_head;
extern struct MAPLE_INFO maple_info;
extern float **qpf;

/*******************************************************************************
 *
 *  QPF ���������� �ڷ� �б�
 *
 *******************************************************************************/
int rdr_qpf_pcp_10m_get()
{
  FILE   *fp;
  char   fname[120];
  unsigned char **num, *n1;
  float  **qpf2, *q1, *q2;
  long   offset;
  int    seq, seq1, first = 0;
  int    i, j;

  // 1. �迭 ����
  qpf = matrix(0, RDR_MAPLE_NY, 0, RDR_MAPLE_NX);
  qpf2 = matrix(0, RDR_MAPLE_NY, 0, RDR_MAPLE_NX);
  num = cmatrix(0, RDR_MAPLE_NY, 0, RDR_MAPLE_NX);
  offset = sizeof(maple_head) + sizeof(maple_info) + (RDR_MAPLE_NY+1)*(RDR_MAPLE_NX+1)*36*4;

  // 2. QPE ����(���ؽð� ����)
  seq1 = var.seq_ef - var.acc + 10;
  for (seq = seq1; seq <= var.seq; seq += 10) {
    if (rdr_qpf_file(seq, var.qpe, fname) < 0) continue;
    if ((fp = gzopen(fname,"rb")) == NULL) continue;

    gzseek(fp, offset, SEEK_SET);
    if (first == 0) {
      for (j = 0; j <= RDR_MAPLE_NY; j++) {
        gzread(fp, qpf[j], (RDR_MAPLE_NX+1)*4);
        for (q1 = qpf[j], n1 = num[j], i = 0; i <= RDR_MAPLE_NX; i++, q1++, n1++) {
          if (*q1 > BLANK1)
            *n1 = 1;
          else
            *n1 = 0;
        }
      }
      first = 1;
    }
    else {
      for (j = 0; j <= RDR_MAPLE_NY; j++) {
        gzread(fp, qpf2[j], (RDR_MAPLE_NX+1)*4);
        for (q1 = qpf[j], q2 = qpf2[j], n1 = num[j], i = 0; i <= RDR_MAPLE_NX; i++, q1++, q2++, n1++) {
          if (*q2 >= 0) {
            if (*q1 > 0)
              *q1 += *q2;
            else
              *q1 = *q2;
          }
          if (*q2 > BLANK1) *n1 += 1;
        }
      }
    }
    gzclose(fp);
  }

  // 3. QPF ����
  if (var.seq < var.seq_ef) {
    if (rdr_qpf_file(var.seq, var.qpe, fname) >= 0) {
      if ((fp = gzopen(fname,"rb")) != NULL) {
        offset = sizeof(maple_head) + sizeof(maple_info);
        gzseek(fp, offset, SEEK_SET);

        for (seq = var.seq+10; seq <= var.seq_ef; seq += 10) {
          if (first == 0) {
            for (j = 0; j <= RDR_MAPLE_NY; j++) {
              gzread(fp, qpf[j], (RDR_MAPLE_NX+1)*4);
              for (q1 = qpf[j], n1 = num[j], i = 0; i <= RDR_MAPLE_NX; i++, q1++, n1++) {
                if (*q1 > BLANK1)
                  *n1 = 1;
                else
                  *n1 = 0;
              }
            }
            first = 1;
          }
          else {
            for (j = 0; j <= RDR_MAPLE_NY; j++) {
              gzread(fp, qpf2[j], (RDR_MAPLE_NX+1)*4);
              for (q1 = qpf[j], q2 = qpf2[j], n1 = num[j], i = 0; i <= RDR_MAPLE_NX; i++, q1++, q2++, n1++) {
                if (*q2 >= 0) {
                  if (*q1 > 0)
                    *q1 += *q2;
                  else
                    *q1 = *q2;
                }
                if (*q2 > BLANK1) *n1 += 1;
              }
            }
          }
        }
      }
      gzclose(fp);
    }
  }

  // 4. �հ� ���� ���� �� �޸� �ݳ�
  if (first > 0) {
    for (j = 0; j <= RDR_MAPLE_NY; j++) {
      for (q1 = qpf[j], n1 = num[j], i = 0; i <= RDR_MAPLE_NX; i++, q1++, n1++) {
        if (*q1 > 0) *(q1) *= (0.01/6.0);
        if (*n1 < var.acc/10) *q1 = BLANK1;
      }
    }
  }
  free_cmatrix(num, 0, RDR_MAPLE_NY, 0, RDR_MAPLE_NX);
  free_matrix(qpf2, 0, RDR_MAPLE_NY, 0, RDR_MAPLE_NX);
  return 0;
}

/*******************************************************************************
 *
 *  QPF ���������� �ڷ� �б�
 *
 *******************************************************************************/
int rdr_qpf_pcp_60m_get()
{
  FILE   *fp;
  char   fname[120];
  unsigned char **num, *n1;
  float  **qpf2, *q1, *q2;
  long   offset;
  int    seq, seq1, first = 0, ox;
  int    i, j;

  // 1. �迭 ����
  qpf = matrix(0, RDR_MAPLE_NY, 0, RDR_MAPLE_NX);
  qpf2 = matrix(0, RDR_MAPLE_NY, 0, RDR_MAPLE_NX);
  num = cmatrix(0, RDR_MAPLE_NY, 0, RDR_MAPLE_NX);

  // 2. ����
  for (seq = var.seq_ef; seq > var.seq_ef-170; seq -= 60) {
    // 2.1. �ش� ������ �ִ��� Ȯ�� (QPF, QPE ����)
    ox = -1;
    if (seq >= var.seq)
      ox = rdr_qpf_file(var.seq, var.qpe, fname);
    else
      ox = rdr_qpf_file(seq, var.qpe, fname);
    if (ox < 0) continue;

    // 2.2. ���� ����
    if ((fp = gzopen(fname,"rb")) == NULL) continue;

    // 2.3. �ڷ� ��ġ Ȯ��
    if (seq > var.seq)
      offset = sizeof(maple_head) + sizeof(maple_info) + (RDR_MAPLE_NY+1)*(RDR_MAPLE_NX+1)*4*(seq-var.seq-10)/10;
    else
      offset = sizeof(maple_head) + sizeof(maple_info) + (RDR_MAPLE_NY+1)*(RDR_MAPLE_NX+1)*4*36;
    gzseek(fp, offset, SEEK_SET);

    // 2.4. �ڷ� �а� ��ġ��
    if (first == 0) {
      for (j = 0; j <= RDR_MAPLE_NY; j++) {
        gzread(fp, qpf[j], (RDR_MAPLE_NX+1)*4);
        for (q1 = qpf[j], n1 = num[j], i = 0; i <= RDR_MAPLE_NX; i++, q1++, n1++) {
          if (*q1 > BLANK1)
            *n1 = 1;
          else
            *n1 = 0;
        }
      }
      first = 1;
    }
    else {
      for (j = 0; j <= RDR_MAPLE_NY; j++) {
        gzread(fp, qpf2[j], (RDR_MAPLE_NX+1)*4);
        for (q1 = qpf[j], q2 = qpf2[j], n1 = num[j], i = 0; i <= RDR_MAPLE_NX; i++, q1++, q2++, n1++) {
          if (*q2 >= 0) {
            if (*q1 > 0)
              *q1 += *q2;
            else
              *q1 = *q2;
          }

          if (*q2 > BLANK1) *n1 += 1;
        }
      }
    }
    gzclose(fp);
  }

  // 4. �հ� ���� ���� �� �޸� �ݳ�
  if (first > 0) {
    for (j = 0; j <= RDR_MAPLE_NY; j++) {
      for (q1 = qpf[j], n1 = num[j], i = 0; i <= RDR_MAPLE_NX; i++, q1++, n1++) {
        if (*q1 > 0) *(q1) *= 0.01;
        if (*n1 < var.acc/60) *q1 = BLANK1;
      }
    }
  }
  free_cmatrix(num, 0, RDR_MAPLE_NY, 0, RDR_MAPLE_NX);
  free_matrix(qpf2, 0, RDR_MAPLE_NY, 0, RDR_MAPLE_NX);
  return 0;
}

/*******************************************************************************
 *
 *  QPF �������� �ڷ� �б�
 *
 *******************************************************************************/
int rdr_qpf_get()
{
  FILE   *fp;
  float  *q1;
  int    df;
  int    i, j, k, n;

  // 1. ���� ���� ���� Ȯ��
  if (rdr_qpf_file(var.seq, var.qpe, var.fname) < 0) return -1;

  // 2. �ش� �����ð��� �ڷ� �б�
  fp = gzopen(var.fname,"rb");
  if (fp != NULL) {
    gzread(fp, &maple_head, sizeof(maple_head));
    gzread(fp, &maple_info, sizeof(maple_info));

    df = (int)((var.seq_ef - var.seq)/10) - 1;
    if (df < 0) df = 36;
    if (df > 0) gzseek(fp, (long)(maple_info.ny*maple_info.nx*df*4), SEEK_CUR);

    qpf = matrix(0, (int)(maple_info.ny-1), 0, (int)(maple_info.nx-1));
    for (j = 0; j < maple_info.ny; j++) {
      gzread(fp, qpf[j], (maple_info.nx)*4);

      for (q1 = &qpf[j][0], i = 0; i < maple_info.nx; i++, q1++) {
        if (*q1 > 0) *(q1) *= 0.01;
      }
    }
    gzclose(fp);
  }
  else
    return -2;

  return 0;
}

/*=============================================================================*
 *  QPF ���� ���� ���� Ȯ��
 *=============================================================================*/
int rdr_qpf_file(
  int  seq,     // ���Ͻð�(KST)
  int  qpe,     // QPE�Ⱓ(��)
  char *fname   // [���] ���ϸ�
)
{
  struct stat st;
  char   file_head[60];
  int    YY, MM, DD, HH, MI;
  int    code;

  seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  if (qpe == 60)
    strcpy(file_head,"qpf_ram_60m_maple");
  else
    strcpy(file_head,"qpf_ram_10m_maple");
  sprintf(fname, "%s/%04d%02d/%02d/%s_%04d%02d%02d%02d%02d.bin.gz",
          RDR_MAPLE_DIR, YY, MM, DD, file_head, YY, MM, DD, HH, MI);
  code = stat(fname, &st);
  if (code < 0 || st.st_size <= 100) return -1;
  return 0;
}
