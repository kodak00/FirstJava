/*******************************************************************************
**
**  ���̴� �������� �ռ����� ǥ��� CGI ���α׷�
**
**=============================================================================*
**
**     o �� �� �� : ����ȯ (2005.8.11)
**
********************************************************************************/
#include "input_head.h"
#include "stn_inf.h"

#define  STN_RDR_FILE  "/www/mis/cgi-bin/REF/STN/stn_rdr.csv"

struct INPUT_VAR
{
    int   seq;
    int   num_stn;
    int   stn_id[32];
    int   mode;
    int   size;
    int   R, G, B;
    int   NI, NJ;
    int   GI, GJ;
    float rate;
} var;

struct STN_RDR_RANGE
{
    int   stn_id;
    float lon;
    float lat;
    int   range;
    char  stn_sp[16];
} rdr_range[32];
int num_rdr_stn;

int main()
{
    int j, code;

    /*-------------------------------------------------------------------------*/
    /* initial */

    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(60);

    printf("HTTP/1.0 200 OK\n");
    printf("Server: Netscape-Enterprise/3.0\n");

    /*-------------------------------------------------------------------------*/
    /* user input decode */

    if ( (code = Input()) < 0 )
    {
        printf("Content-type: text/html\n\n");
        printf(" input variable error (%d)<p>\n", code);
        return -1;
    }

    /*-------------------------------------------------------------------------*/
    /* display */

    num_rdr_stn = rdr_stn_list();

    disp_img();

    alarm(0);
    return 0;
}

/*******************************************************************************
 *
 *  ����� ��û�ڷ� �м�
 *
 *******************************************************************************/
int Input()
{
    char *qs;
    char value[32][120], tmp[32];
    int  i;

    qs = getenv("QUERY_STRING");
    if (qs == NULL) return -1;

    for(i=0; qs[0] != '\0'; i++)
        getword(value[i], qs, '&');

    var.seq  = atoi(value[0]);

    for(i=0; value[1][0] != '\0'; i++)
    {
        getword(tmp, value[1], '_');
        var.stn_id[i] = atoi(tmp);
        if (var.stn_id[i] <= 0) break;
    }
    var.num_stn = i;

    var.mode = atoi(value[2]);
    var.size = atoi(value[3]);

    return 0;
}

/*******************************************************************************
 *
 *  IMAGE mode
 *
 *******************************************************************************/
int disp_img()
{
    gdImagePtr im;
    gdPoint  p[361];
    struct lamc_parameter  map;
    char   gname[120], buf[8192], text[120];
    float  DEG2RAD, r, lon, lat, x, y;
    int    r1, MI, MJ, xo, yo, x1, y1, color[16], color1;
    int    code = -1, n, i, j, k;

    DEG2RAD = asin(1.0)/90.0;

    /* Area */

    MI = 1024;
    MJ = 1024;
    xo = 440;
    yo = 770;

    var.NI = var.size;
    var.rate = (float)MI / (float)var.NI;
    var.NJ = (int)((float)MJ / var.rate);

    var.GI = var.NI;
    var.GJ = var.NJ;

    /* Map Projection Parameter */
/*
    map.Re    = 6371.00877;
    map.slat1 = 30.0;
    map.slat2 = 60.0;
    map.olon  = 126.0;
    map.olat  = 38.0;
    map.grid  = 1.0 * var.rate;
    map.xo    = xo / map.grid;
    map.yo    = yo / map.grid;
    map.first = 0;
*/
    map.Re    = 6371.00877;
    map.slat1 = 30.0;
    map.slat2 = 60.0;
    map.olon  = 126.0;
    map.olat  = 38.0;
    map.grid  = 1.0 * var.rate;
    map.xo    = xo / map.grid;
    map.yo    = yo / map.grid +200;
    map.first = 0;

    /* Gd Alloc. & Color Table  */

    im = gdImageCreate(var.GI+1, var.GJ+1);

    color[0] = gdImageColorAllocate(im,   0,   0,   0);   /* ������   */
    color[1] = gdImageColorAllocate(im, 255, 255, 255);   /* white    */
    color[3] = gdImageColorAllocate(im,  51,  51,  51);   /* �ؾȼ�   */
    color[4] = gdImageColorAllocate(im, 119, 119, 119);   /* ���浵�� */
    color[5] = gdImageColorAllocate(im, 255,   0,   0);   /* ��ġ     */
    color[6] = gdImageColorAllocate(im, 255,   0, 255);   /* S-band   */
    color[7] = gdImageColorAllocate(im, 128,  64,   0);   /* ����     */
    color[8] = gdImageColorAllocate(im,   0,   0, 255);   /* C-band   */
    color[9] = gdImageColorAllocate(im, 192, 192, 192);   /* ����   */
    if (var.mode == 2)
        color[10] = gdImageColorAllocate(im, var.R, var.G, var.B);
    else
        color[10] = gdImageColorAllocate(im, 0, 0, 250);

    gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color[9]);

    /* ������ ���� */

    for (k = 0; k < var.num_stn; k++)
    {
        for (r = 0, i = 0; i < num_rdr_stn; i++)
        {
            if (var.stn_id[k] == rdr_range[i].stn_id)
            {
                r = rdr_range[i].range / var.rate - 2;
                lon = rdr_range[i].lon;
                lat = rdr_range[i].lat;
                break;
            }
        }
        if (i >= num_rdr_stn) continue;

        lamcproj(&lon, &lat, &x, &y, 0, map);
        y = var.GJ - y;

        for (i = 0; i <= 360; i++)
        {
            p[i].x = (int)(r*cos(DEG2RAD*i) + x);
            p[i].y = (int)(r*sin(DEG2RAD*i) + y + 1.0);
        }
        gdImageFilledPolygon(im, p, 361, color[1]);
    }
    for (k = 0; k < var.num_stn; k++)
    {
        for (r = 0, i = 0; i < num_rdr_stn; i++)
        {
            if (var.stn_id[k] == rdr_range[i].stn_id)
            {
                r = rdr_range[i].range / var.rate;
                lon = rdr_range[i].lon;
                lat = rdr_range[i].lat;
                break;
            }
        }
        if (i >= num_rdr_stn) continue;

        lamcproj(&lon, &lat, &x, &y, 0, map);
        y = (int)(var.GJ - y);

        if (rdr_range[i].stn_sp[1] == 'S')
            color1 = color[6];
        else
            color1 = color[8];

        gdImageArc(im, (int)x, (int)y, (int)(r*2), (int)(r*2), 0, 360, color1);
        gdImageArc(im, (int)x, (int)y, (int)(r*2-2), (int)(r*2-2), 0, 360, color1);
        gdImageFilledRectangle(im, (int)x-3, (int)y-3, (int)x+3, (int)y+3, color[5]);
    }

    /* ����, ���浵�� */

    map_draw(im, var.NI, 'R', "00000000_00000000", 4, 0, color[0]);
    latlon_lamc(im, var.NI, 'R', "00000000_00000000", color[4]);
    if (var.mode == 2)
    {
        gdImageRectangle(im, 2, 2, var.GI-2, var.GJ-2, color[10]);
        gdImageRectangle(im, 1, 1, var.GI-1, var.GJ-1, color[10]);
        gdImageRectangle(im, 0, 0, var.GI, var.GJ, color[10]);
    }
    else
        gdImageRectangle(im, 0, 0, var.GI, var.GJ, color[0]);


    //gdImageColorTransparent(im, color[1]);

    /* Image send */

    printf("Content-type: image/png\n\n");

    gdImagePng(im, stdout);
    gdImageDestroy(im);

    return 0;
}

/*******************************************************************************
 *
 *  ���̴� �������� ���� (���û, ����, �̰���)
 *
 *******************************************************************************/
int rdr_stn_list()
{
    FILE   *fd;
    struct stat st;
    struct STN_RDR  stn_rdr;
    char   buf[1000];
    int    i = 0, j = 0, code;

    fd = fopen(STN_RDR_FILE, "r");
    if (fd == NULL)
    {
        printf("station infomation file not opened (%s)\n", STN_RDR_FILE);
        return -2;
    }

    while (fgets(buf,1000,fd) != NULL)
    {
        str2stn_rdr(buf, &stn_rdr);
        if (stn_rdr.stn_sp[0] == '9') continue;

        for (j = 0; j < i; j++)
        {
            if (rdr_range[j].stn_id == stn_rdr.stn_id) break;
        }
        rdr_range[j].stn_id = stn_rdr.stn_id;
        rdr_range[j].lon    = stn_rdr.lon;
        rdr_range[j].lat    = stn_rdr.lat;
        rdr_range[j].range  = stn_rdr.range;
        strcpy(rdr_range[j].stn_sp, stn_rdr.stn_sp);

        if (j == i) i++;
    }
    fclose(fd);

    return i;
}
