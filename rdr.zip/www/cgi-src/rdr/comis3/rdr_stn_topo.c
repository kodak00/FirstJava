/************************************************************************/
/*                                                                      */
/*  Radar ������ ����� TOPO image                                      */
/*                                                                      */
/*======================================================================*/
/*                                                                      */
/*     o �ۼ��� : ����ȯ (2000. 3. 7)                                   */
/*     o ������ : �̱�� (2008.7.21)                                    */
/*                                                                      */
/************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gd.h>
#include <gdfontt.h>
#include <gdfonts.h>
#include <gdfontmb.h>
#include <gdfontl.h>
#include <gdfontg.h>
#include "/www/mis/cgi-src/gis/program/map_ini.h"
#include "/www/mis/cgi-src/include/disp.h"

#define TX  4800
#define TY  6000
#define NZ  15
#define MJ  1200
#define MI  1200

short  topo[MJ+1][MI+1];
float  Z[NZ] = {0.5, 50, 100, 150, 200, 300, 400, 500,
                600, 700, 800, 900, 1000, 1500, 2000};

struct INPUT_VAR {
    char  stn_code[16];
    int   range;
    int   size;
    char  color;
    char  mode;
    int   NI;
    int   NJ;
    int   GI;
    int   GJ;
} var;
struct azed_parameter rdr;
struct lamc_parameter map;

short  DEM[TY][TX];


int main(argc, argv)

int  argc;
char *argv[];
{
    int  i, j;

    /* input decode */
    if (argc != 6) {
        printf("[ Usage ] rdr_stn_topo {���� �ڵ�} {�ݰ�km} {ǥ��ũ��} {����} {mode}\n");
        return 0;
    }

    strcpy(var.stn_code, argv[1]);
    var.range = atoi(argv[2]);
    var.size  = atoi(argv[3]);
    var.color = argv[4][0];
    var.mode  = argv[5][0];

    var.NI = var.size;
    var.NJ = var.size;
    var.GI = var.NI + LEG_pixel + LVL_pixel;
    var.GJ = var.NJ + TTL_pixel + END_pixel;

    rdr_stn_map_info();

    rdr_stn_topo_make();

    for(j = 0; j < MJ; j++) {
        printf(" %d : %d\n", j, topo[j][MI/2]);
    }

    rdr_stn_topo_img();

    return 0;
}

int rdr_stn_map_info()
{
    rdr.Re    = 6370.19584;
    rdr.grid  = 1.0;				/* 1 km */
    if (strcmp(var.stn_code, "KWK") == 0) {
        rdr.slon = 126.0 + (57.0 + 58.0/60.0) / 60.0;
        rdr.slat =  37.0 + (26.0 + 31.0/60.0) / 60.0;
    } else if (strcmp(var.stn_code, "KSN") == 0) {
        rdr.slon = 126.0 + (47.0 + 12.0/60.0) / 60.0;
        rdr.slat =  36.0 + ( 0.0 + 38.0/60.0) / 60.0;
    } else if (strcmp(var.stn_code, "PSN") == 0) {
        rdr.slon = 129.0 + ( 0.0 +  8.0/60.0) / 60.0;
        rdr.slat =  35.0 + ( 6.0 + 54.0/60.0) / 60.0;
    } else if (strcmp(var.stn_code, "CJU") == 0) {
        rdr.slon = 126.0 + ( 9.0 + 54.0/60.0) / 60.0;
        rdr.slat =  33.0 + (17.0 + 30.0/60.0) / 60.0;
    } else if (strcmp(var.stn_code, "DNH") == 0) {
        rdr.slon = 129.0 + ( 7.0 + 32.0/60.0) / 60.0;
        rdr.slat =  37.0 + (30.0 +  0.0/60.0) / 60.0;
    } else if (strcmp(var.stn_code, "BRI") == 0) {
        rdr.slon = 124.0 + (38.0 + 20.0/60.0) / 60.0;
        rdr.slat =  37.0 + (57.0 + 31.0/60.0) / 60.0;
    } else if (strcmp(var.stn_code, "IIA") == 0) {
        rdr.slon = 126.0 + (21.0 + 48.0/60.0) / 60.0;
        rdr.slat =  37.0 + (27.0 + 53.0/60.0) / 60.0;
    } else if (strcmp(var.stn_code, "JNI") == 0) {
        rdr.slon = 126.0 + (19.0 + 41.0/60.0) / 60.0;
        rdr.slat =  34.0 + (28.0 + 15.0/60.0) / 60.0;
    } else {
        return -1;
    }
    rdr.olon = rdr.slon;
    rdr.olat = rdr.slat;
    rdr.xo = (float)MI * 0.5;
    rdr.yo = (float)MJ * 0.5;
    rdr.first = 0;
    return 0;
}

int rdr_stn_topo_make()
{
    float  x1, y1, x2, y2, alon, alat;
    float  lon_min, lon_max, lat_min, lat_max;
    float  dx, dy, h1, h2, ht;
    float  lon, lat, x, y;
    int    id, lon1, lon2, lat1, lat2;
    char   fname[120], dname[240], tmp[16];
    int    inside;
    int    i, j, k, i1, j1, num;
    FILE   *fd;

    if (var.mode == 'r') {
        fd = fopen("TOPO.bin", "rb");
        fread(topo, 2, (MJ+1)*(MI+1), fd);
        fclose(fd);
        return 0;
    }

    /*----------------------------------------------------------------*/
    /* lon / lat ���� */

    x1 = 0.0;
    y1 = 0.0;
    azedproj(&alon, &alat, &x1, &y1, 1, rdr);
    lon_min = alon;
    lon_max = alon;
    lat_min = alat;
    lat_max = alat;

    x1 = (float)MI;
    y1 = 0.0;
    azedproj(&alon, &alat, &x1, &y1, 1, rdr);
    if (lon_min > alon) lon_min = alon;
    if (lon_max < alon) lon_max = alon;
    if (lat_min > alat) lat_min = alat;
    if (lat_max < alat) lat_max = alat;

    x1 = (float)MI;
    y1 = (float)MJ;
    azedproj(&alon, &alat, &x1, &y1, 1, rdr);
    if (lon_min > alon) lon_min = alon;
    if (lon_max < alon) lon_max = alon;
    if (lat_min > alat) lat_min = alat;
    if (lat_max < alat) lat_max = alat;

    x1 = 0.0;
    y1 = (float)MJ;
    azedproj(&alon, &alat, &x1, &y1, 1, rdr);
    if (lon_min > alon) lon_min = alon;
    if (lon_max < alon) lon_max = alon;
    if (lat_min > alat) lat_min = alat;
    if (lat_max < alat) lat_max = alat;

    printf("lon[%f:%f] lat[%f:%f]\n", lon_min, lon_max, lat_min, lat_max);

    /*----------------------------------------------------------------*/
    /* �������� ��� */

    for(j = 0; j <= MJ; j++) {
        for(i = 0; i <= MI; i++) topo[j][i] = -9999;
    }

// --> ���ڷḦ ã�� �� ���� : mis2  ����
    fd = fopen("/ncomis/FTP/TOPO/gtopo/area.dat", "r");
    if (fd == NULL) return -1;

    while( fscanf(fd, "%s", fname) != EOF )
    {
        strncpy(tmp, &fname[1], 3);   tmp[3] = '\0';
        alon = atoi(tmp);
        if (fname[0] == 'W') alon = -alon;
        strncpy(tmp, &fname[5], 2);   tmp[2] = '\0';
        alat = atoi(tmp);
        if (fname[4] == 'S') alat = -alat;

        inside = 1;
        if (lon_max < alon - 1)  inside = 0;
        if (lon_min > alon + 41) inside = 0;
        if (lat_min > alat - 1)  inside = 0;
        if (lat_max < alat - 51) inside = 0;

        if (inside == 1) {
            sprintf(dname, "/DATA/GIS/TOPO/gtopo/%s.DEM", fname);
            printf("%s--\n", dname);
            DEM_TOPO(dname, alon, alat);
        }
    }
    fclose(fd);

    /*----------------------------------------------------------------*/
    /* ���� �����ڷ� ���Ϸ� ���� */

    fd = fopen("TOPO.bin", "wb");
    fwrite(topo, 2, (MJ+1)*(MI+1), fd);
    fclose(fd);

    return 0;
}

int DEM_TOPO(dname, olon, olat)

char   *dname;
float  olon, olat;
{
    FILE   *fd;
    unsigned char   buf[TX*2];
    float  x, y, lon, lat;
    int    v;
    int    ix, iy;
    int    i, j, k;
            printf("%s\n", dname);

    /*----------------------------------------------------------------*/
    /* TOPO file open & data read */

    fd = fopen(dname, "rb");
    if (fd == NULL) return -1;

    for(j = 0; j < TY; j++)
    {
        fread(buf, 1, TX*2, fd);

        for(i = 0; i < TX*2; i += 2)
        {
            k = i/2;
            v = buf[i]*256 + buf[i+1];
            DEM[j][k] = (short)v;
        }
    }
    fclose(fd);

    /*----------------------------------------------------------------*/
    /* TOPO file open & data read */

    for(j = 0; j <= MJ; j++)
    {
        for(i = 0; i <= MI; i++)
        {
            x = i;
            y = j;
            azedproj(&lon, &lat, &x, &y, 1, rdr);
            if (lon >= 180.0) lon -= 360.0;

            ix = (lon - olon)*120;
            iy = (olat - lat)*120;
            if (ix < 0 || ix > TX-1) continue;
            if (iy < 0 || iy > TY-1) continue;

            v = (int)DEM[iy][ix];
            topo[j][i] = (float)v;
        }
    }
    return 0;
}

int rdr_stn_topo_img()
{
    FILE   *fd;
    gdImagePtr im;
    int    color[256];
    char   fname[120];
    float  rate, xo, yo;
    int    g0, num;
    int    ix, iy;
    int    i, j, k;

    /* gd Alloc. & color table */
    im = gdImageCreate(var.GI+1, var.GJ+1);

    if      (var.color == 'C') color_table_C(im, color);
    else if (var.color == 'E') color_table_E(im, color);
    else                       color_table_U(im, color);

    gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color[0]);

    /* topo image */

    rate = (float)(2.0*var.range) / (float)var.size;
    yo = (float)MJ*0.5 - var.range - (float)END_pixel*rate;
    xo = (float)MI*0.5 - var.range;

    for(j = 0; j <= var.GJ; j++)
    {
        iy = yo + rate * j;
        printf("j = %d : iy = %d (%f)\n", j, iy, rate);

        for(i = 0; i <= var.GI; i++)
        {
            ix = xo + rate * i;

            if (ix > 0 && ix < MI && iy > 0 && iy < MJ) {
                g0 = topo[iy][ix];
            } else {
                g0 = -1;
            }

            num = NZ-1;
            for(k = 0; k < NZ; k++) {
                if( g0 < Z[k] ) {
                    num = k;
                    break;
                }
            }
            gdImageSetPixel(im, i, var.GJ-j, color[num]);
        }
    }

    /* ���� */
    if (var.color != 'U') {
        rdr.grid = 2.0 * var.range / var.size;
        rdr.xo = var.size / 2;
        rdr.yo = var.size / 2 + END_pixel;
        rdr.first = 0;

        gd_bln_azed(im, color[103], 0, rdr, (float)(var.GI), (float)(var.GJ), "/DATA/GIS/MAP/river_map.dat");
    }

    /* Image file make */
    sprintf(fname, "/www/mis/cgi-bin/ref/TOPO/RDR/rdr_stn_topo_%s_%d_%c_%d.png",
                    var.stn_code, var.range, var.color, var.size);
    fd = fopen(fname, "wb");
    if (fd != NULL) {
        gdImagePng(im, fd);
        fclose(fd);
        printf("Make Image = %s\n", fname);
    }
    gdImageDestroy(im);

    return 0;
}

int color_table_E(im, color)

gdImagePtr im;
int color[];
{
    color[0] = gdImageColorAllocate(im, 206, 229, 241);     /* �ٴٻ� */
    color[1] = gdImageColorAllocate(im,  85, 211,  94);
    color[2] = gdImageColorAllocate(im, 121, 223, 128);
    color[3] = gdImageColorAllocate(im, 151, 231, 157);
    color[4] = gdImageColorAllocate(im, 189, 239, 192);
    color[5] = gdImageColorAllocate(im, 225, 241, 182);
    color[6] = gdImageColorAllocate(im, 239, 241, 182);
    color[7] = gdImageColorAllocate(im, 255, 255, 170);
    color[8] = gdImageColorAllocate(im, 255, 244, 170);
    color[9] = gdImageColorAllocate(im, 255, 230, 170);
    color[10] = gdImageColorAllocate(im, 255, 216, 123);
    color[11] = gdImageColorAllocate(im, 255, 206, 87);
    color[12] = gdImageColorAllocate(im, 255, 196, 58);
    color[13] = gdImageColorAllocate(im, 255, 188, 30);
    color[14] = gdImageColorAllocate(im, 255, 180,  0);
    color[15] = gdImageColorAllocate(im, 236, 167,  0);
    color[16] = gdImageColorAllocate(im, 216, 153,  0);
    color[17] = gdImageColorAllocate(im, 195, 138,  0);
    color[100] = gdImageColorAllocate(im, 109, 218, 109);
    color[101] = gdImageColorAllocate(im, 255,   0,   0);
    color[102] = gdImageColorAllocate(im,  98, 169, 213);   /* �� */
    color[103] = gdImageColorAllocate(im, 255, 255, 255);
    return 0;
}

int color_table_C(im, color)

gdImagePtr im;
int color[];
{
    color[0] = gdImageColorAllocate(im, 200, 200, 200);     /* �ٴٻ� */
    color[1] = gdImageColorAllocate(im, 240, 240, 225);     /* - 50m */
    color[2] = gdImageColorAllocate(im, 220, 220, 220);     /* -100m */
    color[3] = gdImageColorAllocate(im, 210, 210, 210);     /* -150m */
    color[4] = gdImageColorAllocate(im, 200, 200, 200);     /* -200m */
    color[5] = gdImageColorAllocate(im, 190, 190, 190);     /* -300m */
    color[6] = gdImageColorAllocate(im, 180, 180, 180);     /* -400m */
    color[7] = gdImageColorAllocate(im, 170, 170, 170);     /* -500m */
    color[8] = gdImageColorAllocate(im, 160, 160, 160);     /* -600m */
    color[9] = gdImageColorAllocate(im, 150, 150, 150);     /* -700m */
    color[10] = gdImageColorAllocate(im, 140, 140, 140);    /* -800m */
    color[11] = gdImageColorAllocate(im, 130, 130, 130);    /* -900m */
    color[12] = gdImageColorAllocate(im, 120, 120, 120);    /* -1000m */
    color[13] = gdImageColorAllocate(im, 110, 110, 110);    /* -1500m */
    color[14] = gdImageColorAllocate(im, 100, 100, 100);    /* -2000m */
    color[100] = gdImageColorAllocate(im, 109, 218, 109);
    color[101] = gdImageColorAllocate(im, 255,   0,   0);
    color[102] = gdImageColorAllocate(im,  98, 169, 213);   /* �� */
    color[103] = gdImageColorAllocate(im, 255, 255, 255);
    return 0;
}

int color_table_U(im, color)

gdImagePtr im;
int color[];
{
    int  i;

    color[0] = gdImageColorAllocate(im, 125, 187, 255);     /* �ٴٻ� */
    for(i = 1; i <= 14; i++)
        color[i] = gdImageColorAllocate(im, 255, 218, 125); /* ���� */

    color[100] = gdImageColorAllocate(im, 109, 218, 109);
    color[101] = gdImageColorAllocate(im, 255,   0,   0);
    color[102] = gdImageColorAllocate(im,  98, 169, 213);   /* �� */
    color[103] = gdImageColorAllocate(im, 255, 255, 255);
    return 0;
}

