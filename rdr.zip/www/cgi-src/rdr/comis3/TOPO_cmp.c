/**********************************************************************************/
/*                                                                                */
/*  Radar �ռ����� TOPO image                                                     */
/*                                                                                */
/*================================================================================*/
/*                                                                                */
/*     o �ۼ��� : ����ȯ (2000. 3. 7)                                             */
/*                                                                                */
/**********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gd/gd.h>
#include <gd/gdfontt.h>
#include <gd/gdfonts.h>
#include <gd/gdfontmb.h>
#include <gd/gdfontl.h>
#include <gd/gdfontg.h>
#include "/www/htdocs/MAP/program/map_ini.h"
#include "/cookji/src/include/view.h"

#define TX  4800
#define TY  6000

#define NI  560
#define NJ  680
#define GI  NI + LEVEL_pixel
#define GJ  NJ + TITLE_pixel

#define NZ  15

short  topo[GJ+1][GI+1];
float  Z[NZ] = {0.5, 50, 100, 150, 200, 300, 400, 500,
                600, 700, 800, 900, 1000, 1500, 2000};
char   map_area;


int main(argc, argv)

int  argc;
char *argv[];
{
    struct lamc_parameter map;
    float  x1, y1, x2, y2, alon, alat;
    float  lon_min, lon_max, lat_min, lat_max;
    float  dx, dy, h1, h2, ht;
    float  lon, lat, x, y;
    int    id, lon1, lon2, lat1, lat2;
    char   fname[120], dname[240], tmp[16];
    int    inside;
    int    i, j, k, i1, j1, num;
    FILE   *fd;

    map_area = argv[1][0];

    /*----------------------------------------------------------------*/
    /* MAP parameter & Image size */

    map.Re    = 6370.19584;
    map.slat1 = 30.0;
    map.slat2 = 60.0;
    map.olon  = 125.0;
    map.olat  = 35.0;
    if (map_area == 'A') {
        map.grid  = 1.0;
        map.xo    = 40.0 / map.grid;
        map.yo    = 240.0 / map.grid;
    } else {
        map.grid  = 2.0;
        map.xo    = 480.0 / map.grid;
        map.yo    = 440.0 / map.grid;
    }
    map.first = 0;

    /*----------------------------------------------------------------*/
    /* lon / lat ���� */

    x1 = 0.0;
    y1 = 0.0;
    lamcproj(&alon, &alat, &x1, &y1, 1, map);
    lon_min = alon;
    lon_max = alon;
    lat_min = alat;
    lat_max = alat;

    x1 = (float)GI;
    y1 = 0.0;
    lamcproj(&alon, &alat, &x1, &y1, 1, map);
    if (lon_min > alon) lon_min = alon;
    if (lon_max < alon) lon_max = alon;
    if (lat_min > alat) lat_min = alat;
    if (lat_max < alat) lat_max = alat;

    x1 = (float)GI;
    y1 = (float)GJ;
    lamcproj(&alon, &alat, &x1, &y1, 1, map);
    if (lon_min > alon) lon_min = alon;
    if (lon_max < alon) lon_max = alon;
    if (lat_min > alat) lat_min = alat;
    if (lat_max < alat) lat_max = alat;

    x1 = 0.0;
    y1 = (float)GJ;
    lamcproj(&alon, &alat, &x1, &y1, 1, map);
    if (lon_min > alon) lon_min = alon;
    if (lon_max < alon) lon_max = alon;
    if (lat_min > alat) lat_min = alat;
    if (lat_max < alat) lat_max = alat;

    printf("lon[%f:%f] lat[%f:%f]\n", lon_min, lon_max, lat_min, lat_max);

    /*----------------------------------------------------------------*/
    /* �������� ��� */

    for(j = 0; j <= GJ; j++) {
        for(i = 0; i <= GI; i++) topo[j][i] = -9999;
    }

    fd = fopen("/usr7/GTOPO/area.dat", "r");
    if (fd == NULL) return -1;

    while( fscanf(fd, "%s", fname) != EOF )
    {
        strncpy(tmp, &fname[1], 3);   tmp[3] = '\0';
        alon = atoi(tmp);
        if (fname[0] == 'W') alon = -alon;
        strncpy(tmp, &fname[5], 2);   tmp[2] = '\0';
        alat = atoi(tmp);
        if (fname[4] == 'S') alat = -alat;

        inside = 1;
        if (lon_max < alon - 1)  inside = 0;
        if (lon_min > alon + 41) inside = 0;
        if (lat_min > alat - 1)  inside = 0;
        if (lat_max < alat - 51) inside = 0;

        if (inside == 1) {
            sprintf(dname, "/usr7/GTOPO/%s.DEM", fname);
            printf("%s\n", dname);
            DEM_TOPO(dname, alon, alat, map);
        }
    }
    fclose(fd);

    /*----------------------------------------------------------------*/
    /* �����̹��� ���� */

    fd = fopen("/www/htdocs/TOPO.bin", "wb");
    fwrite(topo, 2, (GI+1)*(GJ+1), fd);
    fclose(fd);
/*
    if (argv[1][0] == '1') {
        fd = fopen("/www/htdocs/TOPO.bin", "rb");
        fread(topo, 2, (GI+1)*(GJ+1), fd);
        fclose(fd);
    }
*/
    topo_gif(map);

    return 0;
}

int DEM_TOPO(dname, olon, olat, map)

char   *dname;
float  olon, olat;
struct lamc_parameter map;
{
    FILE   *fd;
    short  DEM[TY][TX], buf[TX];
    float  x, y, lon, lat;
    int    ix, iy;
    int    i, j, k;

    /*----------------------------------------------------------------*/
    /* TOPO file open & data read */

    fd = fopen(dname, "rb");
    if (fd == NULL) return -1;

    for(j = 0; j < TY; j++) {
        fread(buf, 2, TX, fd);
        for(i = 0; i < TX; i++) DEM[j][i] = buf[i];
    }
    fclose(fd);

    /*----------------------------------------------------------------*/
    /* TOPO file open & data read */

    for(j = 0; j <= GJ; j++) {
        for(i = 0; i <= GI; i++) {
            x = i;
            y = j;
            lamcproj(&lon, &lat, &x, &y, 1, map);
            if (lon >= 180.0) lon -= 360.0;

            ix = (lon - olon)*120;
            iy = (olat - lat)*120;
            if (ix < 0 || ix > TX-1) continue;
            if (iy < 0 || iy > TY-1) continue;

            topo[j][i] = DEM[iy][ix];
        }
    }
    return 0;
}

int topo_gif(map)

struct lamc_parameter map;
{
    FILE   *fd;
    gdImagePtr im;
    int    color[256];
    char   fname[120];
    int    g0, num;
    int    i, j, k;

    /* gd Alloc. & color table */
    im = gdImageCreate(GI+1, GJ+1);
    color_table4(im, color);
    gdImageFilledRectangle(im, 0, 0, GI, GJ, color[0]);

    /* topo image */
    for(j = 0; j <= GJ; j++)
    {
        printf("%4d %4d %4d %4d %4d %4d\n",
               j, topo[j][0], topo[j][GI/4], topo[j][GI/2], topo[j][GI*3/4], topo[j][GI]);
        for(i = 0; i <= GI; i++)
        {
            g0 = topo[j][i];

            num = NZ-1;
            for(k = 0; k < NZ; k++) {
                if( g0 < Z[k] ) {
                    num = k;
                    break;
                }
            }
            gdImageSetPixel(im, i, GJ-j, color[num]);
        }
    }

    gd_bln_lamc(im, color[103], 0, map, (float)GI, (float)GJ, "/usr5/ftp/pub/MAP/river_map.dat");

    /* GIF file make */
    sprintf(fname, "/www/htdocs/RDR/TOPO_cmp_%c.gif", map_area);
    fd = fopen(fname, "wb");
    if (fd != NULL) {
        gdImageGif(im, fd);
        fclose(fd);
        printf("Make GIF = %s\n", fname);
    }
    gdImageDestroy(im);

    return 0;
}

int color_table3(im, color)

gdImagePtr im;
int color[];
{
    color[0] = gdImageColorAllocate(im, 206, 229, 241);     /* �ٴٻ� */
    color[1] = gdImageColorAllocate(im,  85, 211,  94);
    color[2] = gdImageColorAllocate(im, 121, 223, 128);
    color[3] = gdImageColorAllocate(im, 151, 231, 157);
    color[4] = gdImageColorAllocate(im, 189, 239, 192);
    color[5] = gdImageColorAllocate(im, 225, 241, 182);
    color[6] = gdImageColorAllocate(im, 239, 241, 182);
    color[7] = gdImageColorAllocate(im, 255, 255, 170);
    color[8] = gdImageColorAllocate(im, 255, 244, 170);
    color[9] = gdImageColorAllocate(im, 255, 230, 170);
    color[10] = gdImageColorAllocate(im, 255, 216, 123);
    color[11] = gdImageColorAllocate(im, 255, 206, 87);
    color[12] = gdImageColorAllocate(im, 255, 196, 58);
    color[13] = gdImageColorAllocate(im, 255, 188, 30);
    color[14] = gdImageColorAllocate(im, 255, 180,  0);
    color[15] = gdImageColorAllocate(im, 236, 167,  0);
    color[16] = gdImageColorAllocate(im, 216, 153,  0);
    color[17] = gdImageColorAllocate(im, 195, 138,  0);
    color[100] = gdImageColorAllocate(im, 109, 218, 109);
    color[101] = gdImageColorAllocate(im, 255,   0,   0);
    return 0;
}

int color_table4(im, color)

gdImagePtr im;
int color[];
{
    color[0] = gdImageColorAllocate(im, 200, 200, 200);     /* �ٴٻ� */
    color[1] = gdImageColorAllocate(im, 240, 240, 225);     /* - 50m */
    color[2] = gdImageColorAllocate(im, 220, 220, 220);     /* -100m */
    color[3] = gdImageColorAllocate(im, 210, 210, 210);     /* -150m */
    color[4] = gdImageColorAllocate(im, 200, 200, 200);     /* -200m */
    color[5] = gdImageColorAllocate(im, 190, 190, 190);     /* -300m */
    color[6] = gdImageColorAllocate(im, 180, 180, 180);     /* -400m */
    color[7] = gdImageColorAllocate(im, 170, 170, 170);     /* -500m */
    color[8] = gdImageColorAllocate(im, 160, 160, 160);     /* -600m */
    color[9] = gdImageColorAllocate(im, 150, 150, 150);     /* -700m */
    color[10] = gdImageColorAllocate(im, 140, 140, 140);    /* -800m */
    color[11] = gdImageColorAllocate(im, 130, 130, 130);    /* -900m */
    color[12] = gdImageColorAllocate(im, 120, 120, 120);    /* -1000m */
    color[13] = gdImageColorAllocate(im, 110, 110, 110);    /* -1500m */
    color[14] = gdImageColorAllocate(im, 100, 100, 100);    /* -2000m */
    color[100] = gdImageColorAllocate(im, 109, 218, 109);
    color[101] = gdImageColorAllocate(im, 255,   0,   0);
    color[102] = gdImageColorAllocate(im,  98, 169, 213);   /* �� */
    color[103] = gdImageColorAllocate(im, 255, 255, 255);
    return 0;
}
