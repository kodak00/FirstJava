#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <math.h>
#include <gd.h>
#include <gdfontt.h>
#include <gdfonts.h>
#include <gdfontmb.h>
#include <gdfontl.h>
#include <gdfontg.h>
#include "cgiutil.h"
#include "map_ini.h"
#include "AWS.h"
#include "disp.h"

#define NUM_SITE 7
#define NX  100
#define NY  100
#define ZR  4           /* �����ڷ� Ȯ���� (4��Ȯ��) */

struct INPUT_VAR {
    int   seq;
    int   stn;
    int   sweep;
    char  color;
    char  level;
    char  auto_man;
    int   an_itv;
    int   an_frn;
    char  html_gif;
};

struct RADAR_SITE {
    int   stn_id;
    char  cccc[6];
    char  name[32];
    float lat;
    float lon;
    float height;
};
