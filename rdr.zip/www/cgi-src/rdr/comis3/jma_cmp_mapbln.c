/***************************************************************************/
/*                                                                         */
/*  �Ϻ� ���̴� �ռ��̹��� ó���� ���� �����ڷ� ���� ���α׷�              */
/*                                                                         */
/*     o ������� : /www/cgi-bin/ref/JMA_CMP.bln                           */
/*                                                                         */
/*=========================================================================*/
/*                                                                         */
/*     o �ۼ��� : ����ȯ (1999. 8. 17)                                     */
/*                                                                         */
/***************************************************************************/
#include "radar_jma.h"
#include "radar_jma_site.h"
#include "/usr/local/include/nrutil.h"

main()
{
    FILE  *fd;
    char   fname[120], gname[120];
    struct lamc_parameter  map;
    float  xm, ym;

    /* MAP output file */
    strcpy(gname, "/www/cgi-bin/ref/JMA_CMP.bln");
    fd = fopen(gname, "w");

    /* Input MAP */
    strcpy(fname, "/usr5/ftp/pub/MAP/global_map.dat");

    /* MAP parameter */
    map.Re    = 6370.19584;
    map.grid  = 2.5;
    map.slat1 = 30.0;
    map.slat2 = 60.0;
    map.olon  = 125.0;
    map.olat  = 35.0;
    map.xo    = 180.0;
    map.yo    = 590.0;
    map.first = 0;
    xm = 700;
    ym = 800;

    /* map file make */
    bln_file(fd, fname, map, xm, ym);
    fclose(fd);
    printf("map file maked\n");

    /* gif file make */
    bln_gif(gname, map, xm, ym);
    printf("gif file maked\n");

    exit(0);
}

/*********************************************************************
*
*  �����ڷ� ����
*
*********************************************************************/
int bln_file(fd, fname, map, xm, ym)

FILE   *fd;                     /* output file pointer */
char   *fname;                  /* input map file name */
struct lamc_parameter  map;     /* map parameter       */
float  xm, ym;                  /* maximum area        */
{
    FILE   *fg;
    int    n, num, code;
    char   scode[16];
    float  *vx, *vy;
    float  lon, lat, x1, y1, x2, y2, x, y;
    float  buf[2];
    int    ibuf[2];
    int    i, j, k;
    int    now = 0;
    int    tn = 0;

    fg = fopen(fname, "r");
    if (fg == NULL) return -1;

    while( fscanf(fg, "%d %s", &num, &scode) != EOF ) {
        code = atoi(scode);

        tn += num + 1;
        printf(" --- %d %d %d\n", num, code, tn);
        if (num <= 0) break;
        vx = vector(0, num);
        vy = vector(0, num);
        k = 0;

        fscanf(fg, "%f %f", &lon, &lat);
        lamcproj(&lon, &lat, &x1, &y1, 0, map);
        if( x1 >= 0.0 && x1 <= xm && y1 >= 0.0 && y1 <= ym ) {
            vx[0] = x1;
            vy[0] = y1;
            k++;
            now = 1;
        } else {
            now = 0;
        }

        for(j = 1; j < num; j++) {
            fscanf(fg, "%f %f", &lon, &lat);
            if (code == 3) continue;
            lamcproj(&lon, &lat, &x2, &y2, 0, map);
            if( x2 >= 0.0 && x2 <= xm && y2 >= 0.0 && y2 <= ym ) {
                if( now == 0 ) {
                    CrossPoint(x1, y1, x2, y2, xm, ym, &x, &y);
                    x1 = x;
                    y1 = y;
                    vx[0] = x1;
                    vy[0] = y1;
                    k = 1;
                    now = 1;
                }
                vx[k] = x2;
                vy[k] = y2;
                k++;
            } else {
                if( now == 1 ) {
                    CrossPoint(x1, y1, x2, y2, xm, ym, &x, &y);
                    vx[k] = x2;
                    vy[k] = y2;
                    k++;
                    ibuf[0] = k;
                    ibuf[1] = code;
                    fwrite(ibuf, sizeof(int), 2, fd);
                    for(i = 0; i < k; i++) {
                        buf[0] = vx[i];
                        buf[1] = vy[i];
                        fwrite(buf, sizeof(float), 2, fd);
                    }
                    k = 0;
                    now = 0;
                }
            }
            x1 = x2;
            y1 = y2;
        }
        if ( k > 1 ) {
            ibuf[0] = k;
            ibuf[1] = code;
            fwrite(ibuf, sizeof(int), 2, fd);
            for(i = 0; i < k; i++) {
                buf[0] = vx[i];
                buf[1] = vy[i];
                fwrite(buf, sizeof(float), 2, fd);
            }
            k = 0;
        }
        free_vector(vy, 0, num);
        free_vector(vx, 0, num);
    }
    fclose(fg);
    return 0;
}

/******************************************************************
*
*  BOX �Ȱ� ���� ������ �մ� ���� ��輱�� ������ ���� ��ǥ ���
*
******************************************************************/
int  CrossPoint(x1, y1, x2, y2, xm, ym, x, y)

float  x1, y1, x2, y2;  /* �Ȱ� �ۿ� �ִ� ������ ��ǥ */
float  xm, ym;          /* BOX�� ũ�� [0:xm,0:ym]     */
float  *x, *y;          /* ��輱�� ������ ���� ��ǥ  */
{
    *y = -1.0;
    if( x1 < 0.0 || x2 < 0.0 ) {
        *y = -x1*(y2-y1)/(x2-x1) + y1;
        *x = 0.0;
    }
    else if( x1 > xm || x2 > xm ) {
        *y = (xm-x1)*(y2-y1)/(x2-x1) + y1;
        *x = xm;
    }

    if( *y < 0.0 || *y > ym ) {
        if( y1 < 0.0 || y2 < 0.0 ) {
            *x = -y1*(x2-x1)/(y2-y1) + x1;
            *y = 0.0;
        }
        else if( y1 > ym || y2 > ym ) {
            *x = (ym-y1)*(x2-x1)/(y2-y1) + x1;
            *y = ym;
        }
    }
}

/*********************************************************************
*
*  �����ڷḦ �̹����� ����
*
*********************************************************************/
int bln_gif(fname, map, xm, ym)

char   *fname;
struct lamc_parameter  map;
float  xm, ym;
{
    FILE   *fd;
    gdImagePtr  im;
    int    color[16];
    int    ibuf[2], num, code;
    float  buf[2], lon, lat;
    int    ix1, ix2, iy1, iy2;
    float  x1, x2, y1, y2, ac;
    float  zm = 1.5;
    int    i;

    /* initial */
    map.grid *= zm;
    map.xo /= zm;
    map.yo /= zm;
    xm /= zm;
    ym /= zm;
    ac = 250.0 / map.grid;
    fd = fopen(fname, "rb");

    /* gd Image alloc. */
    im = gdImageCreate((int)xm+1, (int)ym+1);

    color[0] = gdImageColorAllocate(im, 0, 0, 0);
    color[1] = gdImageColorAllocate(im, 255, 255, 255);
    color[2] = gdImageColorAllocate(im, 255, 0, 0);
    color[3] = gdImageColorAllocate(im, 0, 0, 255);
    color[4] = gdImageColorAllocate(im, 200, 200, 200);

    gdImageFilledRectangle(im, 0, 0, (int)xm, (int)ym, color[1]);

    /* RADAR area */
    for(i = 0; i < NUM_SITE; i++) {
        lat = site[i].lat;
        lon = site[i].lon;
        lamcproj(&lon, &lat, &x2, &y2, 0, map);
        y2 = ym - y2;
        gdImageFilledRectangle(im, (int)(x2-ac), (int)(y2-ac), (int)(x2+ac), (int)(y2+ac), color[4]);
    }

    /* MAP */
    while( fread(ibuf, sizeof(int), 2, fd) > 0 )
    {
        num  = ibuf[0];
        code = ibuf[1];

        fread(buf, sizeof(float), 2, fd);
        ix1 = (int)(buf[0]/zm + 0.5);
        iy1 = ym - (int)(buf[1]/zm + 0.5);

        for(i = 1; i < num; i++)
        {
            fread(buf, sizeof(float), 2, fd);

            ix2 = (int)(buf[0]/zm + 0.5);
            iy2 = ym - (int)(buf[1]/zm + 0.5);
            gdImageLine(im, ix1, iy1, ix2, iy2, color[0]);

            ix1 = ix2;
            iy1 = iy2;
        }
    }
    fclose(fd);

    /* RADAR site */
    for(i = 0; i < NUM_SITE; i++) {
        lat = site[i].lat;
        lon = site[i].lon;
        lamcproj(&lon, &lat, &x2, &y2, 0, map);
        y2 = ym - y2;
        gdImageFilledRectangle(im, (int)x2-3, (int)y2-3, (int)x2+3, (int)y2+3, color[2]);
        gdImageString(im, gdFontGiant, x2+2, y2, site[i].name, color[3]);
    }

    gdImageRectangle(im, 0, 0, (int)xm, (int)ym, color[0]);

    /* GIF IMage file */
    fd = fopen("/www/htdocs/RDR/jma_cmp_mapbln.gif", "wb");
    gdImageGif(im, fd);
    fclose(fd);

    gdImageDestroy(im);
    return 0;
}
