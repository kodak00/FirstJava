/******************************************************************************
**
**  ���û ���̴��� 1�ð� ���������� �м��� CGI ���α׷�
**
**============================================================================*
**
**     o �ۼ��� : ����ȯ (2004. 6. 25)
* *    o 1������: �������Ϸ� ���� (����ȯ, 2000.1.2)
**
*******************************************************************************/
#include "rdr_kma_stn_pcp.h"
#include "/www/mis/cgi-src/include/rdr_stn.h"
#include "/www/mis/cgi-src/include/disp_htm.h"

struct INPUT_VAR  var;
char   IMG_DIR[64];

char   buf[512][512];           /* data */
float  rain1[33] = {0.04,  0.1,  0.2,  0.4,  0.6,  0.8,  1.0,  1.5,  2.0,  3.0,  4.0,
                     5.0,  6.0,  7.0,  8.0,  9.0, 10.0, 12.0, 14.0, 16.0, 18.0, 20.0,
                    25.0, 30.0, 35.0, 40.0, 50.0, 60.0, 70.0, 80.0, 90.0,100.0,110.0};
int level_color(float);


/******************************************************************************
 *
 *  MAIN
 *
 ******************************************************************************/
int main()
{
    int code;
    IPAGE_TM itm;

    /*------------------------------------------------------------------------*/
    /* initial */

    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(60);

    printf("HTTP/1.0 200 OK\n");
    printf("Server: Netscape-Enterprise/3.0\n");

    /*------------------------------------------------------------------------*/
    /* user input decode */

    var.move  = 60;
    var.fmove = 17;

    if ( (code = Input()) < 0 ) {
        /** ������������ ��ü�� : 2007.07.10
        printf("Content-type: text/html\n\n");
        printf("<!-- input variable error (%d)<p> --> \n", code);
        ***/
        seq2time(var.seq, &itm.year, &itm.mon, &itm.day, &itm.hour, &itm.min, 'm', 'n');
        disp_ipage(&itm, "�ش� �ڷᰡ �������� �ʽ��ϴ�.");
        return -1;
    }

    if (var.mode == 'F')
        strcpy(IMG_DIR, IMG_DIR2);
    else
        strcpy(IMG_DIR, IMG_DIR1);

    /*------------------------------------------------------------------------*/
    /* display */

    if      (var.mode == 'H') disp_html();
    else if (var.mode == 'I') disp_img();

    alarm(0);
    return 0;
}

/******************************************************************************
 *
 *  ����� ��û�� Ȯ��
 *
 ******************************************************************************/
int Input()
{
    #include INC_DEC

    /*------------------------------------------------------------------------*/
    /* Error check (+) */

    if (strcmp(var.data0, "ALL") != 0)
    {
        for(i = 0; i < RDR_KMA_STN_NUM; i++)
        {
            if (strcmp(var.data0, rdr_stn[i].head) == 0 && rdr_stn[i].mode == 0) break;
        }
        if (i >= RDR_KMA_STN_NUM) return -2;
    }
    else
    {
        var.an_frn = 1;
        var.mode = 'H';
    }

    /*------------------------------------------------------------------------*/
    /* �ֱ��ڷᰡ ���� ���, ���� �ֱ��ڷḦ ã�� */

    if (var.auto_man == 'a' && var.mode == 'H' && strcmp(var.data0, "ALL") != 0)
    {
        i = 1;
        while( rdr_kma_stn_pcp_file(0) != 0 && i <= 48 )
        {
            var.seq -= var.move;
            seq2time(var.seq, &var.YY, &var.MM, &var.DD, &var.HH, &var.min, 'm', 'n');
            i++;
        }
    }
    if (i > 48) return -3;
    return 0;
}

/******************************************************************************
 *
 *  IMAGE mode
 *
 ******************************************************************************/
int disp_img()
{
    FILE  *fd;
    char   gname[120];
    int    code, len, c;

    if ( rdr_kma_stn_pcp_img_file(gname) < 0 )
        rdr_kma_stn_pcp_img();

    printf("Content-type: image/png\n\n");

    rdr_kma_stn_pcp_img_file(gname);
    if ( (fd = fopen(gname, "rb")) != NULL )
    {
        c = getc(fd);
        while(c != EOF)
        {
            putchar(c);
            c = getc(fd);
        }
        fclose(fd);
    }
    return 0;
}

/******************************************************************************
 *
 *  HTML mode
 *
 ******************************************************************************/
int disp_html()
{
    char  gname[48][120];
    int   n, i, j, k;

    printf("Content-type: text/html\n\n");

    /*------------------------------------------------------------------------*/
    /* head part */

    disp_html_head();

    /*------------------------------------------------------------------------*/
    /* Image file make for all data */

    if (strcmp(var.data0, "ALL")== 0)
    {
        for(n = 0, k = 0; k < RDR_KMA_STN_NUM; k++)
        {
            if (rdr_stn[k].mode == 0)
            {
                strcpy(var.data0, rdr_stn[k].head);

                if ( rdr_kma_stn_pcp_img_file(gname[n]) < 0 )
                {
                    if ( rdr_kma_stn_pcp_file(1) == 0 )
                    {
                        if ( rdr_kma_stn_pcp_img() == 0 ) n++;
                    }
                }
                else
                {
                    n++;
                }
            }
        }
        strcpy(var.data0, "ALL");
    }

    /*------------------------------------------------------------------------*/
    /* Image file make for animation */

    else
    {
        if (var.an_frn > 1) var.seq = var.seq - (var.an_frn-1) * var.an_itv;

        for (n = 0, i = 0; i < var.an_frn; i++)
        {
            seq2time(var.seq, &(var.YY), &(var.MM), &(var.DD), &(var.HH), &(var.min), 'm', 'n');

            if ( rdr_kma_stn_pcp_img_file(gname[n]) < 0 )
            {
                if ( rdr_kma_stn_pcp_file(1) == 0 )
                {
                    if ( rdr_kma_stn_pcp_img() == 0 ) n++;
                }
            }
            else
            {
                n++;
            }
            if (var.an_frn > 1 && i < var.an_frn-1) var.seq += var.an_itv;
        }
    }

    /*------------------------------------------------------------------------*/
    /* body part */

    disp_html_body(n, gname);

    return 0;
}

/*============================================================================*
 *  HEAD ������ ���
 *============================================================================*/
int disp_html_head()
{
    printf("<HTML>\n");
    printf("<HEAD>\n");

    /*------------------------------------------------------------------------*/
    /* for auto reload */

    if (var.auto_man == 'a') printf("<META http-equiv='Refresh' content=600>\n");

    /*------------------------------------------------------------------------*/
    /* Time sync. & animation */

    printf("<SCRIPT LANGUAGE='JavaScript'>\n");
    printf("<!--\n");
    //printf("  parent.menu.frm.tm1.value = '%04d.%02d.%02d.%02d:%02d';\n", var.YY, var.MM, var.DD, var.HH, var.min);
    //printf("  parent.menu.frm.tm.value = '%04d%02d%02d%02d%02d';\n", var.YY, var.MM, var.DD, var.HH, var.min);
    printf("  parent.menu.resetTime( '%04d.%02d.%02d.%02d:%02d' );\n", var.YY, var.MM, var.DD, var.HH, var.min);
    printf("// -->\n");
    printf("</SCRIPT>\n");
    printf("</HEAD>\n");

    return 0;
}

/*============================================================================*
 *  BODY ��� ���
 *============================================================================*/
int disp_html_body(n, gname)
    int   n;
    char  gname[][120];
{
    char  name[16], fname[120];
    int   seq, seq1, seq2;
    int   len = strlen(WEB_DIR), time_auto;
    int   i, j, k;
    IPAGE_TM itm;

    /*------------------------------------------------------------------------*/
    /* for animation */

    if (var.an_frn > 1 && n > 1)
    {
        printf("<BODY bgcolor=#ffffff onload='animate()' TOPMARGIN=0 LEFTMARGIN=0 marginwidth=0 marginheight=0 class=text>\n");
    }
    else
    {
        /* for NO data */
        if (n <= 0)
        {
            /***
            printf(" �ڷᰡ �����ϴ�. (�ð�: %04d.%02d.%02d.%02d:%02d(LST))<p>\n",
                     var.YY, var.MM, var.DD, var.HH, var.min);
            printf("</BODY></HTML>\n");
            ***/
            seq2time(var.seq, &itm.year, &itm.mon, &itm.day, &itm.hour, &itm.min, 'm', 'n');
            return -1;
        }
        printf("<BODY bgcolor=#ffffff TOPMARGIN=0 LEFTMARGIN=10 marginwidth=0 marginheight=0 class=text>\n");
    }

    /*------------------------------------------------------------------------*/
    /* JavaScript for animation */

    if (var.an_frn > 1 && n > 1)
    {
        printf("<SCRIPT LANGUAGE='JavaScript'>\n");
        printf("<!--\n");
        printf("var counter = 0\n");
        printf("var animation = 1\n");
        printf("var timer\n");
        printf("var i, j\n");
        printf("var imgs = new Array()\n");
        printf("for(i = 0; i < %d; i++) {\n", n);
        printf("  imgs[i] = new Image()\n");
        printf("}\n\n");

        for (i = 0; i < n; i++)
        {
            printf("imgs[%d].src = '%s'\n", i, &gname[i][len]);
        }
        printf("\n");
        printf("function animate()\n");
        printf("{\n");
        printf("  if (animation == 1) {\n");
        printf("    counter = (counter + 1) %% %d\n", n);
        printf("    document.anim.src = imgs[counter].src\n");
        printf("    timer = setTimeout('animate()', 1000)\n");
        printf("  }\n");
        printf("}\n\n");
        printf("function play()\n");
        printf("{\n");
        printf("  animation = 1\n");
        printf("  animate()\n");
        printf("}\n\n");
        printf("function stop()\n");
        printf("{\n");
        printf("  animation = 0\n");
        printf("}\n\n");
        printf("function first()\n");
        printf("{\n");
        printf("  counter = 0\n");
        printf("  document.anim.src = imgs[counter].src\n");
        printf("}\n\n");
        printf("function end()\n");
        printf("{\n");
        printf("  counter = %d\n", n-1);
        printf("  document.anim.src = imgs[counter].src\n");
        printf("}\n\n");
        printf("function moving(bf)\n");
        printf("{\n");
        printf("  counter = (counter + bf + %d) %% %d\n", n, n);
        printf("  document.anim.src = imgs[counter].src\n");
        printf("}\n\n");
        printf("// -->\n");
        printf("</SCRIPT>\n");
    }

    /*------------------------------------------------------------------------*/
    /* image */

    //printf("<center>\n");

    if (strcmp(var.data0, "ALL") == 0)
    {
        printf("<TABLE border=0 cellspacing=3 cellpadding=0>");
        for(k = 0; k < RDR_KMA_STN_NUM; k++)
        {
            if (rdr_stn[k].mode == 0)
            {
                strcpy(var.data0, rdr_stn[k].head);

                if (k % 2 == 0) printf("<TR>\n");
                if (rdr_kma_stn_pcp_img_file(fname) == 0) {
                    printf("<TD><img src='%s'></TD>\n", fname);
                } else {
                    printf("<TD>&nbsp;</TD>");
                }
                if (k % 2 == 1) printf("</TR>\n");
            }
        }
        strcpy(var.data0, "ALL");
        printf("<TD>&nbsp;</TD></TR>\n");
        printf("</TABLE>\n");
    }
    else 
    {
        printf("<DIV id=img1 style='position:relative; top:0px;'>\n");
        printf("  <img name='anim' src='%s' border=0>\n", &gname[0][len]);
        if (n > 1 && var.an_frn > 1)
        {
            printf("  <DIV ID=anim_bt STYLE='position:absolute; left:%dpx; top:15px; visibility:visible;'>\n", var.size-120);
            printf("    <img src='/images/anim.png' border=0 usemap=#anim_map>\n");
            printf("  </DIV>\n");
        }
        printf("</DIV>\n");
    }

    if (n > 1 && var.an_frn > 1 && strcmp(var.data0, "ALL") != 0)
    {
        printf("<MAP name=anim_map>\n");
        printf("<area shape=rect coords=0,0,20,14 href='javascript:play()'>\n");
        printf("<area shape=rect coords=21,0,40,14 href='javascript:stop()'>\n");
        printf("<area shape=rect coords=41,0,60,14 href='javascript:first()'>\n");
        printf("<area shape=rect coords=61,0,80,14 href='javascript:moving(-1)'>\n");
        printf("<area shape=rect coords=81,0,100,14 href='javascript:moving(1)'>\n");
        printf("<area shape=rect coords=101,0,120,14 href='javascript:end()'>\n");
        printf("</MAP>\n");
    }

    //printf("</center>\n");
    printf("</BODY></HTML>\n");
    return 0;
}

/******************************************************************************
 *
 *  1�ð� ������ ���� �̹��� ���� (������)
 *
 ******************************************************************************/
int rdr_kma_stn_pcp_img()
{
    FILE   *fd;
    char   gname[120];
    struct lamc_parameter  map;
    gdImagePtr  im;
    int    color[256], c, x, y;
    int    len, i, j, k;

    /* area */
    var.NI = var.size;
    var.NJ = var.size;
    var.GI = var.NI + LEG_pixel + LVL_pixel;
    var.GJ = var.NJ + TTL_pixel;

    /* gd alloc. */
    im = gdImageCreate(var.GI+1, var.GJ+1);

    /* color table */
    color_table(im, color);

    /* blank area fill */
    gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color[254]);

    /* data display */
    rdr_kma_stn_pcp_disp(im, color);

    /* map draw */
    map_draw(im, color, 1000, 256.0, (float)var.size/512.0);

    /* boundary line */
    gdImageArc(im, var.NI/2, var.NI/2+TTL_pixel, var.NI, var.NI, 0, 360, color[255]);

    /* title display */
    title_disp(im, color);

    /* level table display */
    level_disp(im, color);

    /* station position */
    x = var.NJ/2;
    y = var.NJ/2 + TTL_pixel;
    gdImageFilledRectangle(im, x-2, y-2, x+2, y+2, color[249]);

    /* file write */
    if ( rdr_kma_stn_pcp_img_file(gname) < 0 )
    {
        if ( (fd = fopen(gname, "wb")) == NULL )
        {
            gdImageDestroy(im);
            return -1;
        }
        else
        {
            gdImagePng(im, fd);
            fclose(fd);
        }
    }
    gdImageDestroy(im);
    return 0;
}

/*============================================================================*
 *  Color Table
 *============================================================================*/
int color_table(im, color)
    gdImagePtr im;
    int    color[];
{
    FILE  *fd;
    char  fname[120];
    int   num_colors;
    int   R, G, B, i;

    /*------------------------------------------------------------------------*/

    if      (var.color == 'E') sprintf(fname,"%s/color_rain_E.rgb", COLOR_DIR);
    else if (var.color == 'C') sprintf(fname,"%s/color_rain_C.rgb", COLOR_DIR);
    else                       sprintf(fname,"%s/color_rain_R.rgb", COLOR_DIR);

    fd = fopen(fname,"r");
    if (fd == NULL) return -1;

    fscanf(fd, "%d", &num_colors);

    for (i = 0; i < num_colors; i++)
    {
        fscanf(fd, "%d %d %d", &R, &G, &B);
        color[i] = gdImageColorAllocate(im, R, G, B);
    }
    fclose(fd);

    /*------------------------------------------------------------------------*/
    /* other color */

    color[240] = gdImageColorAllocate(im,   0,   0,   0);   /* ������   */
    color[241] = gdImageColorAllocate(im,  66,  66,  66);   /* �ؾȼ�   */
    color[245] = gdImageColorAllocate(im, 255,   0,   0);   /* ������   */
    color[246] = gdImageColorAllocate(im,   0,   0, 255);   /* �Ķ���   */
    color[247] = gdImageColorAllocate(im, 255, 255,   0);   /* �����   */
    color[248] = gdImageColorAllocate(im,   1,   1,   1);   /* �������� */
    color[249] = gdImageColorAllocate(im, 255,   0,   0);   /* AWS      */
    color[250] = gdImageColorAllocate(im, 128,  64,   0);   /* ����     */
    color[251] = gdImageColorAllocate(im,   0,   0, 128);   /* ����     */
    color[252] = gdImageColorAllocate(im, 128, 128, 128);   /* ������� */
    color[253] = gdImageColorAllocate(im, 200, 200, 200);   /* NO area  */
    color[254] = gdImageColorAllocate(im, 230, 230, 230);   /* NO data  */
    color[255] = gdImageColorAllocate(im, 255, 255, 255);   /* white    */

    return 0;
}

/*============================================================================*
 *
 *  PCP data display
 *
 *============================================================================*/
int rdr_kma_stn_pcp_disp(im, color)
    gdImagePtr  im;
    int    color[];
{
    float  slp, c1, x, y;
    int    b, c;
    int    i, j, k, ix, iy;

    slp = 512.0/var.size;

    for(j = 0; j < var.size; j++)
    {
        y = (float)j * slp;
        iy = (int)y;

        for(i = 0; i < var.size; i++)
        {
            x = (float)i * slp;
            ix = (int)x;

            b = buf[iy][ix];
            if (b < 40) c1 = 0.25 * (float)b;
            else        c1 = (float)(b - 30);
            c = level_color(c1);
            gdImageSetPixel(im, i, var.GJ-j, color[c]);
        }
    }
    return 0;
}

/*============================================================================*
 *  data --> level color
 *============================================================================*/
int level_color(float data)
{
    int  v = 31, i;

    for (i = 0; i <= 30; i++)
    {
        if (data < rain1[i])
        {
            v = i;
            break;
        }
    }
    if (data > 224.0) v = 252;
    return v;
}

/*============================================================================*
 *  GIS data display
 *============================================================================*/
int map_draw(im, color, mode, range, zoom_rate)
    gdImagePtr im;
    int    color[];
    int    mode;
    float  range;
    float  zoom_rate;
{
    FILE   *fd;
    char   fname[120];
    int    num, code, ibuf[2];
    float  buf[2];
    float  xo = 500.0 - range, yo = 500.0 - range;
    float  x1, y1, x2, y2, x, y;
    int    map_color;
    int    ix1, iy1, ix2, iy2;
    int    i, j, k = 0;

    for(j = 1; j <= 4; j++)
    {
        if (mode % 10 == 1)
        {
            if      (j == 1) map_color = color[252];    /* ������� */
            else if (j == 2) map_color = color[251];    /* ����     */
            else if (j == 3) map_color = color[250];    /* ����     */
            else if (j == 4) map_color = color[240];    /* �ؾȼ�   */

            sprintf(fname, "%s/RDR_%s_%d.bln", MAP_DIR, var.data0, j);
            if ( (fd = fopen(fname, "rb")) == NULL ) continue;

            while( fread(ibuf, sizeof(int), 2, fd) > 0 )
            {
                num  = ibuf[0];
                code = ibuf[1];

                fread(buf, sizeof(float), 2, fd);
                ix1 = (int)(zoom_rate * ( buf[0] - xo ));
                iy1 = var.NJ + TTL_pixel - (int)(zoom_rate * ( buf[1] - yo ));

                for(i = 1; i < num; i++)
                {
                    fread(buf, sizeof(float), 2, fd);

                    ix2 = (int)(zoom_rate * ( buf[0] - xo ));
                    iy2 = var.NJ + TTL_pixel - (int)(zoom_rate * ( buf[1] - yo ));
                    gdImageLine(im, ix1, iy1, ix2, iy2, map_color);

                    ix1 = ix2;
                    iy1 = iy2;
                }
            }
            fclose(fd);
        }
        mode /= 10;
    }

    return 0;
}

/*============================================================================*
 *  TITLE display
 *============================================================================*/
int title_disp(im, color)
    gdImagePtr im;
    int color[];
{
    char  text[120];

    gdImageFilledRectangle(im, 0, 0, var.NI+LEG_pixel, TTL_pixel, color[255]);

    sprintf(text, "RADAR PCP  %s %04d.%02d.%02d.%02dh  <1h rain>",
                   var.data0, var.YY, var.MM, var.DD, var.HH);

    if (var.NI < 290)
        gdImageString(im, gdFontSmall, 5, 1, (unsigned char *)text, color[240]);
    else
        gdImageString(im, gdFontLarge, 5, 0, (unsigned char *)text, color[240]);

    return 0;
}

/*============================================================================*
 *  LEVEL display
 *============================================================================*/
int level_disp(im, color)
    gdImagePtr im;
    int color[];
{
    char  level_text[16];
    float dy, y1, y2;
    int   j;

    dy = (float)(var.NJ) / 32.0;

    /*------------------------------------------------------------------------*/
    /* ����ǥ */

    y2 = var.GJ;
    for(j = 0; j <= 31; j++)
    {
        y1 = y2 - dy;
        gdImageFilledRectangle(im, var.NI, (int)y1, var.NI+LEG_pixel, (int)y2, color[j]);
        y2 = y1;
    }
    gdImageFilledRectangle(im, var.NI+LEG_pixel+1, 0, var.GI, var.GJ, color[255]);
    gdImageRectangle(im, 0, TTL_pixel, var.NI, var.GJ, color[240]);
    gdImageRectangle(im, 0, TTL_pixel, var.NI+LEG_pixel, var.GJ, color[240]);

    /*------------------------------------------------------------------------*/
    /* ���� */

    for(j = 0; j < 31; j++)
    {
        if (rain1[j+1] < 10) sprintf(level_text, "%.1f", rain1[j+1]);
        else                 sprintf(level_text, "%d", (int)rain1[j+1]);

        y1 = var.GJ - (int)(dy * (float)(j+1.5));
        gdImageString(im, gdFontSmall, var.NI+LEG_pixel+2, (int)y1, (unsigned char *)level_text, color[240]);
    }

    /*------------------------------------------------------------------------*/
    /* ���� */

    gdImageString(im, gdFontSmall, var.NI+LEG_pixel+2, 1, (unsigned char *)"mm", color[240]);

    return 0;
}

/******************************************************************************
 *  �̹��� ���� ���翩�� �� �����̸� ��ȯ
 ******************************************************************************/
int rdr_kma_stn_pcp_img_file(char *fname)
{
    struct stat st;
    int    code = 0;

    sprintf(fname, "%s/RDR_PCP_%s_%04d%02d%02d%02d%02d_%c%s_%s_%d.png",
                    IMG_DIR, var.data0, var.YY, var.MM, var.DD, var.HH, var.min,
                    var.color, var.level, var.overlay, var.size);

    if  (stat(fname, &st) < 0) code = -1;
    else if (st.st_size < 512) code = -2;

    return code;
}

/******************************************************************************
 *  �ڷ����� ���翩�� �� �����̸� ��ȯ
 ******************************************************************************/
int rdr_kma_stn_pcp_file(int mode)
{
    FILE   *fd;
    struct stat st;
    int    code = 0;

    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_%04d%02d%02d%02d00.pcp.gz",
                        RDR_DIR, var.YY, var.MM, var.DD,
                        var.data0, var.YY, var.MM, var.DD, var.HH);

    if      (stat(var.fname, &st) < 0) code = -1;
    else if (st.st_size < 32) code = -2;

    if (code == 0 && mode == 1)
    {
        fd = gzopen(var.fname, "rb");
        if (fd != NULL) {
            gzread(fd, buf, 512*512);
            gzclose(fd);
        } else {
            code = -3;
        }
    }
    return code;
}

