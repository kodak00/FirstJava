/******************************************************************************
**
**  UF RADAR �ڷ� CAPPI / PPI �м��� CGI ���α׷�
**
**============================================================================*
**
**     o �ۼ��� : ����ȯ (2004. 6. 25)
**
*******************************************************************************/
#include "rdr_stn_ppi_img.h"
#include "/www/mis/cgi-src/include/disp_htm.h"

struct INPUT_VAR  var;
char   IMG_DIR[64];

void print_time();

/******************************************************************************
 *
 *  MAIN
 *
 ******************************************************************************/
int main()
{
    int  code;
    IPAGE_TM itm;

    /*------------------------------------------------------------------------*/
    /* initial */

    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(240);

    printf("HTTP/1.0 200 OK\n");
    printf("Server: Netscape-Enterprise/3.0\n");

    /*------------------------------------------------------------------------*/
    /* user input decode */

    var.move  = 10;
    var.fmove = 5;

    if ((code = Input()) < 0)
    {
        if (var.mode != 'I')
        {
            /** ������������ ��ü�� : 2007.07.10
            printf("Content-type: text/html\n\n");
            printf("<!-- input variable error (%d)<p> --> \n", code);
            ***/
            seq2time(var.seq, &itm.year, &itm.mon, &itm.day, &itm.hour, &itm.min, 'm', 'n');
            disp_ipage(&itm, "�ش� �ڷᰡ �������� �ʽ��ϴ�.");
        }
        return -1;
    }

    if (var.mode == 'F')
        strcpy(IMG_DIR, IMG_DIR2);
    else
        strcpy(IMG_DIR, IMG_DIR1);

    /*------------------------------------------------------------------------*/
    /* display */

    if (var.mode == 'I')
        disp_img();
    else
        disp_html();

    alarm(0);
    return 0;
}

/******************************************************************************
 *
 *  ����� ��û�ڷ� �м�
 *
 ******************************************************************************/
int Input()
{
    #include INC_DEC

    var.winnum += 250;   /* ���ý���� ���̸� �ֱ� ���� */

    /*------------------------------------------------------------------------*/
    /* �ֱ��ڷᰡ ���� ���, ���� �ֱ��ڷḦ ã�� */

    i = 1;
    while (rdr_uf_file() != 0 && i <= 60)
    {
        var.seq -= var.move;
        seq2time(var.seq, &var.YY, &var.MM, &var.DD, &var.HH, &var.min, 'm', 'n');
        i++;
    }
    if (i > 60) return -3;
    return 0;
}

/******************************************************************************
 *
 *  IMAGE mode
 *
 ******************************************************************************/
int disp_img()
{
    FILE  *fd;
    char  gname[48][120], buf[8192];
    int   code = -1, c, n;

    /*------------------------------------------------------------------------*/

    if (rdr_stn_ppi_img_file(gname[0]) < 0)
    {
        if (rdr_uf_file() == 0)
            code = rdr_stn_ppi_img();
    }
    else
    {
        code = 1;
    }

    /*------------------------------------------------------------------------*/

    if (code >= 0)
    {
        if ((fd = fopen(gname[0], "rb")) != NULL)
        {
            printf("Content-type: image/png\n\n");

            while ((n = fread(buf, 1, 8192, fd)) == 8192)
            {
                fwrite(buf, 1, n, stdout);
            }
            if (n > 0) fwrite(buf, 1, n, stdout);
            fclose(fd);
        }
    }
    return 0;
}

/******************************************************************************
 *
 *  HTML mode
 *
 ******************************************************************************/
int disp_html()
{
    char   gname[48][120];
    int    seq, code;
    int    i, j, n = 0;

    printf("Content-type: text/html\n\n");

    /*------------------------------------------------------------------------*/
    /* head part */

    disp_html_head();

    /*------------------------------------------------------------------------*/
    /* time setting (with animation) */

    seq = var.seq;
    if (var.an_frn > 1) seq -= (var.an_frn - 1) * var.an_itv;

    /*------------------------------------------------------------------------*/
    /* Image make */

    printf("<DIV ID=log_rdr STYLE='position:absolute; left:50px; top:20px; visibility:visible;'>\n");

    for (n = 0, i = 0; i < var.an_frn; i++)
    {
        if (var.an_frn > 1) seq2time(seq, &var.YY, &var.MM, &var.DD, &var.HH, &var.min, 'm', 'n');

        if (rdr_stn_ppi_img_file(gname[n]) < 0)
        {
            if (rdr_uf_file() == 0)
            {
                code = rdr_stn_ppi_img();
                if (code >= 0) n++;
            }
        }
        else
        {
            n++;
        }
        seq += var.an_itv;
    }
    printf("</DIV>\n");

    printf("<SCRIPT LANGUAGE='JavaScript'>\n");
    printf("document.all[\"log_rdr\"].style.visibility = 'hidden'\n");
    printf("</SCRIPT>\n");

    /*------------------------------------------------------------------------*/
    /* body part */

    disp_html_body(n, gname);

    return 0;
}

/*============================================================================*
 *  HEAD ������ ���
 *============================================================================*/
int disp_html_head()
{
    printf("<HTML>\n");
    printf("<HEAD>\n");
    if (var.auto_man == 'a') printf("<META http-equiv='Refresh' content=300>\n");

    /*------------------------------------------------------------------------*/

    printf("<style type=\"text/css\">\n");
    printf("<!--\n");
    printf(":link    {text-decoration:none}\n");
    printf(":active  {text-decoration:none}\n");
    printf(":visited {text-decoration:none; color=#0000ff;}\n");
    printf(".head    {font-family:gulim,Verdana; font-size:12pt; color:#000000; font-weight:bold;}\n");
    printf(".name    {font-family:gulim,Verdana; font-size:10pt; color:#000000; font-weight:bold;}\n");
    printf(".text    {font-family:����ü,Verdana; font-size:8pt; color:#000000;}\n");
    printf(".textr   {font-family:����ü,Verdana; font-size: 9pt; color:#0000ff;}\n");
    printf("-->\n");
    printf("</style>\n");

    /*------------------------------------------------------------------------*/

    printf("<SCRIPT LANGUAGE='JavaScript'>\n");
    printf("<!--\n");

    //printf("  parent.menu.frm.tm1.value = '%04d.%02d.%02d.%02d:%02d';\n", var.YY, var.MM, var.DD, var.HH, var.min);
    //printf("  parent.menu.frm.tm.value = '%04d%02d%02d%02d%02d';\n", var.YY, var.MM, var.DD, var.HH, var.min);
    printf(" parent.menu.resetTime( '%04d.%02d.%02d.%02d:%02d' );\n", var.YY, var.MM, var.DD, var.HH, var.min);
    printf("// -->\n");
    printf("</SCRIPT>\n");

    printf("</HEAD>\n");
    return 0;
}

/*============================================================================*
 *  BODY ��� ���
 *============================================================================*/
int disp_html_body(n, gname)
    int   n;
    char  gname[][120];
{
    int   len = strlen(WEB_DIR);
    int   i, j, k;

    /*------------------------------------------------------------------------*/
    /* for animation */

    if (var.an_frn > 1 && n > 1)
    {
        printf("<BODY bgcolor=#ffffff onload='animate()' TOPMARGIN=0 LEFTMARGIN=0 marginwidth=0 marginheight=0 class=text>\n");
    }
    else
    {
        /* for NO data */
        if (n <= 0)
        {
            printf(" �ڷᰡ �����ϴ�. (�ð�: %04d.%02d.%02d.%02d:%02d(LST))<p>\n",
                     var.YY, var.MM, var.DD, var.HH, var.min);
            printf("</BODY></HTML>\n");
            return -1;
        }
        printf("<BODY bgcolor=#ffffff TOPMARGIN=0 LEFTMARGIN=0 marginwidth=0 marginheight=0 class=text>\n");
    }

    /*------------------------------------------------------------------------*/
    /* JavaScript for animation */

    if (var.an_frn > 1 && n > 1)
    {
        printf("<SCRIPT LANGUAGE='JavaScript'>\n");
        printf("<!--\n");
        printf("var counter = 0\n");
        printf("var animation = 1\n");
        printf("var timer\n");
        printf("var i, j\n");
        printf("var imgs = new Array()\n");
        printf("for(i = 0; i < %d; i++) {\n", n);
        printf("  imgs[i] = new Image()\n");
        printf("}\n\n");

        for (i = 0; i < n; i++)
        {
            printf("imgs[%d].src = '%s'\n", i, &gname[i][len]);
        }
        printf("\n");
        printf("function animate()\n");
        printf("{\n");
        printf("  if (animation == 1) {\n");
        printf("    counter = (counter + 1) %% %d\n", n);
        printf("    document.anim.src = imgs[counter].src\n");
        printf("    timer = setTimeout('animate()', 1000)\n");
        printf("  }\n");
        printf("}\n\n");
        printf("function play()\n");
        printf("{\n");
        printf("  animation = 1\n");
        printf("  animate()\n");
        printf("}\n\n");
        printf("function stop()\n");
        printf("{\n");
        printf("  animation = 0\n");
        printf("}\n\n");
        printf("function first()\n");
        printf("{\n");
        printf("  counter = 0\n");
        printf("  document.anim.src = imgs[counter].src\n");
        printf("}\n\n");
        printf("function end()\n");
        printf("{\n");
        printf("  counter = %d\n", n-1);
        printf("  document.anim.src = imgs[counter].src\n");
        printf("}\n\n");
        printf("function moving(bf)\n");
        printf("{\n");
        printf("  counter = (counter + bf + %d) %% %d\n", n, n);
        printf("  document.anim.src = imgs[counter].src\n");
        printf("}\n\n");
        printf("// -->\n");
        printf("</SCRIPT>\n");
    }

    /*------------------------------------------------------------------------*/
    /* for HTML */

    printf("<center>\n");

    printf("<DIV id=img1 style='position:relative; top:0px;'>\n");
    printf("   <img name='anim' src='%s' border=0>\n", &gname[0][len]);

    if (n > 1 && var.an_frn > 1)
    {
        printf("  <DIV ID=anim_bt STYLE='position:absolute; left:%dpx; top:15px; visibility:visible;'>\n", var.size-120);
        printf("    <img src='/images/anim.png' border=0 usemap=#anim_map>\n");
        printf("  </DIV>\n");
    }
    printf("</DIV>\n");

    if (n > 1 && var.an_frn > 1)
    {
        printf("<MAP name=anim_map>\n");
        printf("<area shape=rect coords=0,0,20,14 href='javascript:play()'>\n");
        printf("<area shape=rect coords=21,0,40,14 href='javascript:stop()'>\n");
        printf("<area shape=rect coords=41,0,60,14 href='javascript:first()'>\n");
        printf("<area shape=rect coords=61,0,80,14 href='javascript:moving(-1)'>\n");
        printf("<area shape=rect coords=81,0,100,14 href='javascript:moving(1)'>\n");
        printf("<area shape=rect coords=101,0,120,14 href='javascript:end()'>\n");
        printf("</MAP>\n");
    }

    printf("</center>\n");
    printf("</BODY></HTML>\n");
    return 0;
}

/******************************************************************************
 *  �̹��� ���� ���翩�� �� ���� �̸� ��ȯ
 ******************************************************************************/
int rdr_stn_ppi_img_file(char *fname)
{
    struct stat st;
    int    code = 0;

    sprintf(fname, "%s/RDR_PPI_%s_%04d%02d%02d%02d%02d_%d_%d_%c%s%c_%d.png",
            IMG_DIR, var.data0, var.YY, var.MM, var.DD, var.HH, var.min, var.ds1, var.ds2,
            var.color, var.overlay, var.effect, var.size);

    if (stat(fname, &st) < 0) code = -1;
    else if (st.st_size == 0) code = -2;

    return code;
}

/******************************************************************************
 *  UF ���� ���翩�� �� �����̸� ��ȯ
 ******************************************************************************/
int rdr_uf_file()
{
    struct stat st;
    int    seq, YY, MM, DD, HH, min;
    int    code = 0;
    int    i, j;

    seq = time2seq(var.YY, var.MM, var.DD, var.HH, var.min, 'm');
    for (i = 0; i < 10; i++)
    {
        seq2time(seq-i, &YY, &MM, &DD, &HH, &min, 'm', 'n');
        sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_%04d%02d%02d%02d%02d.uf",
                RDR_DIR, YY, MM, DD, var.data0, YY, MM, DD, HH, min);
        code = stat(var.fname, &st);
        if (st.st_size == 0) code = -2;
        if (code == 0) break;
    }
    return code;
}

/******************************************************************************
 *  TOPO �̹��� �ڷ� ���翩�� Ȯ��
 ******************************************************************************/
int rdr_stn_topo_img_file(char *fname)
{
    struct stat st;
    int    code = 0;

    sprintf(fname, "%s/RDR/TOPO/rdr_stn_topo_%s_%d_%s_%d.png",
            WEB_DIR, var.data0, (int)(0.001*var.range), var.overlay, var.size);

    if (stat(fname, &st) < 0) code = -1;
    else if (st.st_size == 0) code = -2;

    return code;
}

void print_time(char *head)
{
    int  YY, MM, DD, HH, min, sec;

    get_time(&YY, &MM, &DD, &HH, &min, &sec);
    printf(" %s : time = %04d.%02d.%02d.%02d:%02d (%02d)<br>\n",
            head, YY, MM, DD, HH, min, sec);
}
