#include "rdr_maple.h"

/*******************************************************************************
 *
 *  �̹��� ����
 *
 *******************************************************************************/
int rdr_maple_img_make
(
    struct INPUT_VAR  *var,     /* ����� ��û���� */
    struct DATA_LEVEL lvl,      /* �̹��� �������� */
    char   *gname               /* �̹������ϸ�    */
)
{
    FILE   *fp;
    gdImagePtr im;
    float  **g;
    int    zx, zy, ox, oy, x1, y1, x2, y2;
    int    img_make, pixel_km, code, mode = 1;
    int    i, j, k;

    /* �̹��� �������� ���� */
    if ((img_make = rdr_maple_img_check(var, gname)) <= 0)
        return img_make;

    /* �ڷ� ���� */
    g = matrix(0, lvl.ny, 0, lvl.nx);

    for (j = 0; j <= lvl.ny; j++)
    {
        for (i = 0; i <= lvl.nx; i++) g[j][i] = lvl.missing;
    }

//    if (var.mode == 'H' || var.mode == 'A') printf("..Reading");
    code = rdr_maple_rain_file_read(g, var);
    if (code < 0) return -88;

    /* ��Ȱȭ */
    pixel_km = (int)((float)1024/(float)lvl.nx) + 3;

    for (k = 0; k <= pixel_km; k++)
        grid_smooth(g, lvl.nx, lvl.ny, lvl.missing);

    /* ������ Ȯ�� */
    if (lvl.contour == 'G')
        mode = 0;
    else
        mode = 1;

    for (i = 0; i < 7; i++)
    {
        zx = (*var).zoom_x[i] - '0';
        zy = (*var).zoom_y[i] - '0';
        if (zx == 0 || zy == 0) break;

        ox = (zx - 1) * lvl.nx / 8;
        oy = (zy - 1) * lvl.ny / 8;
        grid_zoom(g, lvl.nx, lvl.ny, 2, ox, oy, lvl.missing, mode);
    }

    /* ������ �̹��� ���� */
//    if (var.mode == 'H' || var.mode == 'A') printf("..Imaging<br>\n");

    rdr_maple_img_set_level(*var, &lvl);             /* ����ܰ� ���� */
    im = gdImageCreate(lvl.gi, lvl.gj);             /* �̹������� ���� */
    rdr_maple_img_set_color(im, *var, &lvl);         /* ���� ���� */

    /* ������ �̹��� ���� */
    gdImageFilledRectangle(im, 0, 0, lvl.gi-1, lvl.gj-1, lvl.missing_color);

    rdr_maple_img(im, g, lvl);
    free_matrix(g, 0, lvl.ny, 0, lvl.nx);

    /* ���� ǥ�� */
    rdr_maple_map(im, *var, lvl);

    /* ����,����ǥ ǥ�� */
    rdr_maple_img_title(im, *var, lvl);            /* ���� ǥ�� */
    rdr_maple_img_level(im, *var, lvl);            /* ����ǥ ǥ�� */
    rdr_maple_img_tail(im, lvl);                  /* ��ȸ�ð� */
    gdImageRectangle(im, 0, lvl.title_pixel, lvl.ni, lvl.nj+lvl.title_pixel, lvl.bgline_color);

    /* �̹��� ���� ���� */
    if (img_file(var, gname) < 0 || img_make > 0)
    {
        if ( (fp = fopen(gname, "wb")) == NULL )
        {
            gdImageDestroy(im);
            return -99;
        }
        else
        {
            gdImagePng(im, fp);
            fclose(fp);
        }
    }
    gdImageDestroy(im);

    return 0;
}

/*******************************************************************************
 *
 *  �����ڷῡ�� ������ �̹��� �ۼ�
 *
 *******************************************************************************/
int
rdr_maple_img
(
    gdImagePtr im,          /* out:�̹��� */
    float  **g,             /* inp:������ �ڷ� */
    struct DATA_LEVEL lvl   /* inp:�̹��� ���� */
)
{
    /*
    ��ġ�� �� ��ġ��
    */

    switch (lvl.contour)
    {
    case 'N':
        grid_img_fill(im, g, lvl);
        break;
    case 'C':
        grid_img_fill(im, g, lvl);
        grid_img_contour(im, g, lvl);
        break;
    case 'L':
        grid_img_contour(im, g, lvl);
        break;
    case 'G':
        grid_img_box(im, g, lvl);
        break;
    }
    return 0;
}

/*============================================================================*
 *  data --> level
 *============================================================================*/
int
data_color_level
(
    float  data,            /* inp:�ܰ� �Ǵܴ�� �ڷ� */
    struct DATA_LEVEL lvl   /* inp:�̹��� ���� */
)
{
    int  v = lvl.num_level-1;
    int  i;

    for (i = 0; i < lvl.num_level-1; i++)
    {
        if (data < lvl.level[i])
        {
            v = i;
            break;
        }
    }
    return v;
}

/*=============================================================================*
 *  minimum & maximum of level
 *=============================================================================*/
int
level_max_min
(
    int *v,         /* inp:�Է� �ڷ�� */
    int n,          /* inp:�ڷ��� �� */
    int *imax,      /* out:�ڷ��� �ִ밪 */
    int *imin       /* out:�ڷ��� �ּҰ� */
)
{
    int i;

    *imax = v[0];
    *imin = v[0];

    for (i = 1; i < n; i++)
    {
        if (v[i] > *imax) *imax = v[i];
        if (v[i] < *imin) *imin = v[i];
    }
    return 0;
}

/*=============================================================================*
 *
 *  Grided data fill (��ġ����)
 *
 *  by ����ȯ (1997. 3. 1)
 *
 *=============================================================================*/
int
grid_img_fill
(
    gdImagePtr im,          /* out:�̹��� */
    float  **g,             /* inp:������ �ڷ� */
    struct DATA_LEVEL lvl   /* inp:�̹��� ���� */
)
{
    float  grid_img_rate = (float)(lvl.nx) / (float)(lvl.ni);
    float  q1, q2, q3, q4;
    float  d, d1, d2;
    float  x, y, dx, dy;
    int    i, j, i1, j1, j2;
    int    v;

    for (j = 0; j < lvl.nj; j++)
    {
        y  = (float)j * grid_img_rate;
        j1 = (int)y;
        dy = y - (float)j1;

        if (j1 < 0 || j1 > lvl.ny-1) continue;
        j2 = lvl.title_pixel + lvl.nj - j;

        for (i = 0; i < lvl.ni; i++)
        {
            x  = (float)i * grid_img_rate;
            i1 = (int)x;
            dx = x - (float)i1;

            if (i1 < 0 || i1 > lvl.nx-1) continue;

            q1 = g[j1][i1];
            q2 = g[j1][i1+1];
            q3 = g[j1+1][i1];
            q4 = g[j1+1][i1+1];

            if (q1 > lvl.missing && q2 > lvl.missing && q3 > lvl.missing && q4 > lvl.missing)
            {
                d1 = q1*(1.0 - dx) + q2*dx;
                d2 = q3*(1.0 - dx) + q4*dx;
                d  = d1*(1.0 - dy) + d2*dy;
                v  = data_color_level(d, lvl);
                gdImageSetPixel(im, i, j2, lvl.color[v]);
            }
        }
    }
    return 0;
}

/*=============================================================================*
 *
 *  Grided data fill (�ڽ���)
 *
 *  by ����ȯ (1997. 3. 1)
 *
 *=============================================================================*/
int
grid_img_box
(
    gdImagePtr im,          /* out:�̹��� */
    float  **g,             /* inp:������ �ڷ� */
    struct DATA_LEVEL lvl   /* inp:�̹��� ���� */
)
{
    float  grid_img_rate = (float)(lvl.nx) / (float)(lvl.ni);
    float  x, y, d;
    int    i, j, i1, j1, j2;
    int    v;

    for (j = 0; j < lvl.nj; j++)
    {
        y  = (float)j * grid_img_rate;
        j1 = (int)(y+0.5);

        if (j1 < 0 || j1 > lvl.ny) continue;
        j2 = lvl.title_pixel + lvl.nj - j;

        for (i = 0; i < lvl.ni; i++)
        {
            x  = (float)i * grid_img_rate;
            i1 = (int)(x+0.5);

            if (i1 < 0 || i1 > lvl.nx) continue;

            d = g[j1][i1];

            if (d > lvl.missing)
            {
                v = data_color_level(d, lvl);
                gdImageSetPixel(im, i, j2, lvl.color[v]);
            }
        }
    }
    return 0;
}

/*=============================================================================*
 *
 *  contour line
 *
 *  by ����ȯ (1997. 3. 1)
 *
 *=============================================================================*/
int
grid_img_contour
(
    gdImagePtr im,          /* out:�̹��� */
    float  **g,             /* inp:������ �ڷ� */
    struct DATA_LEVEL lvl   /* inp:�̹��� ���� */
)
{
    float  grid_img_rate = (float)(lvl.nx) / (float)(lvl.ni);
    float  *p1, *p2, q1, q2, q3, q4;
    float  x, y, f;
    int    v[5], vmax, vmin, v1;
    int    x1, y1, x2, y2;
    int    i, j, i1, j1, n, m;

    for (j = 0; j < lvl.ny; j++)
    {
        p1 = &g[j][0];
        p2 = &g[j+1][0];

        for (i = 0; i < lvl.nx; i++, p1++, p2++)
        {
            q1 = *p1;
            q2 = *(p1+1);
            q3 = *(p2+1);
            q4 = *p2;

            if (q1 > lvl.missing && q2 > lvl.missing && q3 > lvl.missing && q4 > lvl.missing)
            {
                v[0] = data_color_level(q1, lvl);
                v[1] = data_color_level(q2, lvl);
                v[2] = data_color_level(q3, lvl);
                v[3] = data_color_level(q4, lvl);
                v[4] = v[0];
                level_max_min(v, 4, &vmax, &vmin);

                if (vmax != vmin)
                {
                    for (v1 = vmin; v1 < vmax; v1++)
                    {
                        f = lvl.level[v1];
                        m = 0;

                        for (n = 0; n < 4; n++)
                        {
                            if (v[n] != v[n+1])
                            {
                                switch (n)
                                {
                                case 0:  x = (f-q1)/(q2-q1);  y = 0.0;             break;
                                case 1:  x = 1.0;             y = (f-q2)/(q3-q2);  break;
                                case 2:  x = (f-q4)/(q3-q4);  y = 1.0;             break;
                                case 3:  x = 0.0;             y = (f-q1)/(q4-q1);  break;
                                }

                                if (x >= 0.0 && x <= 1.0 && y >= 0.0 && y <= 1.0)
                                {
                                    m++;
                                    if (m == 1)
                                    {
                                        x1 = (int)((x + i)/grid_img_rate + 0.5);
                                        y1 = lvl.title_pixel + lvl.nj - (int)((y + j)/grid_img_rate + 0.5);
                                    }
                                    else
                                    {
                                        x2 = (int)((x + i)/grid_img_rate + 0.5);
                                        y2 = lvl.title_pixel + lvl.nj - (int)((y + j)/grid_img_rate + 0.5);
                                    }
                                }
                            }
                        }

                        if (m >= 2)
                        {
                            if (lvl.contour == 'L')
                            {
                                gdImageLine(im, x1, y1, x2, y2, lvl.color[v1+1]);
                                gdImageLine(im, x1+1, y1, x2+1, y2, lvl.color[v1+1]);
                                gdImageLine(im, x1, y1+1, x2, y2+1, lvl.color[v1+1]);
                            }
                            else
                            {
                                gdImageLine(im, x1, y1, x2, y2, lvl.contour_color);
                            }
                        }
                    }
                }
            }
        }
    }
    return 0;
}

/*=============================================================================*
 *
 *  ���������� �ٶ� ȭ��ǥ (5m/s ����)
 *
 *  by ����ȯ (2006. 5. 22)
 *
 *=============================================================================*/
float THETA0 = 170.0 * 3.1415927 / 180.0;

int
wind_arrow
(
    gdImagePtr im,          /* out:�̹��� */
    float  x,               /* inp:�̹����� X ��ġ */
    float  y,               /* inp:�̹����� Y ��ġ */
    float  u,               /* inp:U ǳ�� [m/s] */
    float  v,               /* inp:V ǳ�� [m/s] */
    float  ws,              /* inp:ǳ�� [m/s] */
    int    wind_color,      /* inp:���� */
    float  img_grid_rate    /* inp:�̹����� ������ ũ�� ���� */
)
{
    float  x1, y1, x2, y2, x3, y3;
    float  theta, theta1, a, b, hs;
    float  zm = img_grid_rate/4.0;
    float  Vs = 2.0, As = 1.8;             /* 10m/sec�� ������ *0.5 */

    /*
    ǳ��
    */

    x1 = x - (Vs * u)*zm;
    y1 = y + (Vs * v)*zm;
    x2 = x + (Vs * u)*zm;
    y2 = y - (Vs * v)*zm;
    gdImageLine(im, (int)x1, (int)y1, (int)x2, (int)y2, wind_color);

    /*
    ȭ����
    */

    if (ws > 0.2)
    {
        theta1 = atan2(v, u);
        theta  = theta1 + THETA0;
        hs = As * ws;
        a  = hs * cos(theta);
        b  = hs * sin(theta);
        x3 = x2 + a*zm;
        y3 = y2 - b*zm;
        gdImageLine(im, (int)x2, (int)y2, (int)x3, (int)y3, wind_color);

        theta = theta1 - THETA0;
        hs = As * ws;
        a  = hs * cos(theta);
        b  = hs * sin(theta);
        x3 = x2 + a*zm;
        y3 = y2 - b*zm;
        gdImageLine(im, (int)x2, (int)y2, (int)x3, (int)y3, wind_color);
    }
    return 0;
}

/*******************************************************************************
 *
 *  �����ڷῡ�� �ٶ����� �̹��� �ۼ�
 *
 *  by ����ȯ (2006. 5. 22)
 *
 *******************************************************************************/
int
grid_img_wind
(
    gdImagePtr im,          /* out:�̹��� */
    float  **u,             /* inp:U �ٶ��� ������ */
    float  **v,             /* inp:V �ٶ��� ������ */
    struct DATA_LEVEL lvl   /* inp:�̹��� ���� */
)
{
    float  img_grid_rate = (float)(lvl.ni) / (float)(lvl.nx);
    float  x, y, ws, u1, v1, dx, dy;
    int    i1, j1;
    int    c, i, j;

    for (j = 0; j < lvl.ny; j += lvl.wind_itv)
    {
        y = lvl.nj + lvl.title_pixel - (float)j * img_grid_rate;

        for (i = 0; i < lvl.nx; i += lvl.wind_itv)
        {
            x = (float)i * img_grid_rate;

            if (u[j][i] > lvl.missing + 5)
            {
                ws = u[j][i]*u[j][i] + v[j][i]*v[j][i];
                if (ws > 0.0)
                    ws = sqrt(ws);
                else
                    ws = 0.0;

                c = data_color_level(ws, lvl);
                wind_arrow(im, x, y, u[j][i], v[j][i], ws, lvl.color[c], img_grid_rate);
            }
        }
    }
    return 0;
}

/*=============================================================================*
 *  ������ ������ ���� ���� : ����ǥ�� ���� �ڷẰ �ܰ谪
 *=============================================================================*/
int
rdr_maple_img_set_level
(
    struct INPUT_VAR   var,     /* ����� ��û���� */
    struct DATA_LEVEL *lvl      /* �̹��� �������� */
)
{
    float rain_hour[31]=
            {0.1,  0.2,  0.4,  0.6,  0.8,  1.0,  1.5,  2.0,  3.0,  4.0,
             5.0,  6.0,  7.0,  8.0,  9.0, 10.0, 12.0, 14.0, 16.0, 18.0, 20.0,
            25.0, 30.0, 35.0, 40.0, 50.0, 60.0, 70.0, 80.0, 90.0,100.0};
    float rain_day[31]=
            { 1.0,  2.0,  4.0,  6.0,  8.0, 10.0, 12.0, 15.0, 20.0, 25.0,
             30.0, 40.0, 50.0, 60.0, 70.0, 80.0, 90.0,100.0,110.0,130.0,150.0,
            200.0,250.0,300.0,350.0,400.0,500.0,600.0,700.0,800.0,900.0};
    float rain_diff[31]=
            {-20.0,-18.0,-16.0,-14.0,-12.0,-10.0, -9.0, -8.0, -7.0, -6.0,
              -5.0, -4.0, -3.0, -2.0, -1.0,  0.0,  1.0,  2.0,  3.0,  4.0,  5.0,
               6.0,  7.0,  8.0,  9.0, 10.0, 12.0, 14.0, 16.0, 18.0, 20.0};
    float wind_sp[31]=
            {0.1,  0.2,  0.4,  0.6,  0.8,  1.0,  1.5,  2.0,  2.5,  3.0,
             3.5,  4.0,  4.5,  5.0,  5.5,  6.0,  6.5,  7.0,  8.0,  9.0, 10.0,
            15.0, 20.0, 25.0, 30.0, 35.0, 40.0, 45.0, 50.0, 55.0, 60.0};
    float ta_min[12] = {-15, -15, -10, -5, 0, 5, 10, 10, 0, -5, -10, -15};
    float ave, v_itv, v_min;
    int   YY, MM, DD, HH, min;
    int   i;

        (*lvl).num_level = 32;

        for (i = 0; i < (*lvl).num_level-1; i++)
            (*lvl).level[i] = rain_hour[i];

    return 0;
}

/*=============================================================================*
 *  �̹����� ���� / ���� ǥ��
 *=============================================================================*/
int
rdr_maple_img_title
(
    gdImagePtr im,          /* out:�̹��� */
    struct INPUT_VAR  var,  /* ����� ��û���� */
    struct DATA_LEVEL lvl   /* inp:�̹��� ���� */
)
{
    char   text[60], tm_fc[25], tm_ef[25];
    int    YY, MM, DD, HH, MI;
    int    seq, font;

    if (lvl.title_pixel <= 0) return 0;

    font = 4;       /* ���� ���� ũ�� (1-5: 5�� ���� ŭ) */
    if (var.size < 330) font = 2;

    /*
    ����
    */

    gdImageFilledRectangle(im, 0, 0, lvl.gi-1, lvl.title_pixel, lvl.bg_color);
    sprintf(text, "RDR MAPLE [%s][%smin]", var.data0, var.data1);
    switch (font)
    {
    case 1: gdImageString(im, gdFontTiny,       5, 1, (unsigned char *)text, lvl.title_color);  break;
    case 2: gdImageString(im, gdFontSmall,      5, 1, (unsigned char *)text, lvl.title_color);  break;
    case 3: gdImageString(im, gdFontMediumBold, 5, 1, (unsigned char *)text, lvl.title_color);  break;
    case 4: gdImageString(im, gdFontLarge,      5, 0, (unsigned char *)text, lvl.title_color);  break;
    case 5: gdImageString(im, gdFontGiant,      5, 0, (unsigned char *)text, lvl.title_color);  break;
    }

    /*
    ��ǥ�ð� -> ��ǥ�ð�
    */

    seq2time(var.seq_fc, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    sprintf(tm_fc, "%04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, MI);

    seq2time(var.seq_ef, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    sprintf(tm_ef, "%04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, MI);

    sprintf(text, "%s -> %s", tm_fc, tm_ef);

    switch (font)
    {
    case 1: gdImageString(im, gdFontTiny,       40,15, (unsigned char *)text, lvl.title_color);  break;
    case 2: gdImageString(im, gdFontSmall,      40,15, (unsigned char *)text, lvl.title_color);  break;
    case 3: gdImageString(im, gdFontMediumBold, 40,15, (unsigned char *)text, lvl.title_color);  break;
    case 4: gdImageString(im, gdFontLarge,      40,15, (unsigned char *)text, lvl.title_color);  break;
    case 5: gdImageString(im, gdFontGiant,      40,15, (unsigned char *)text, lvl.title_color);  break;
    }

    /*
    ����
    */

    sprintf(text, "mm/h");

    font = 4;
    switch (font)
    {
    case 1: gdImageString(im, gdFontTiny,       lvl.ni,15, (unsigned char *)text, lvl.title_color);  break;
    case 2: gdImageString(im, gdFontSmall,      lvl.ni,15, (unsigned char *)text, lvl.title_color);  break;
    case 3: gdImageString(im, gdFontMediumBold, lvl.ni,15, (unsigned char *)text, lvl.title_color);  break;
    case 4: gdImageString(im, gdFontLarge,      lvl.ni,15, (unsigned char *)text, lvl.title_color);  break;
    case 5: gdImageString(im, gdFontGiant,      lvl.ni,15, (unsigned char *)text, lvl.title_color);  break;
    }
    return 0;
}

/*=============================================================================*
 *  �̹����� ����ǥ�� ���� ǥ��
 *=============================================================================*/
int
rdr_maple_img_level
(
    gdImagePtr im,          /* out:�̹��� */
    struct INPUT_VAR  var,  /* ����� ��û���� */
    struct DATA_LEVEL lvl   /* inp:�̹��� ���� */
)
{
    double dy = (float)(lvl.nj) / (float)(lvl.num_level);
    double y, h;
    char   text[8];
    int    font, level_start = 0, level_unit, level_itv;
    int    x, i;

    gdImageFilledRectangle(im, lvl.ni, lvl.title_pixel, lvl.gi-1, lvl.gj-1, lvl.bg_color);

    /*
    ���� ǥ�� ����(1:����, 2:��ĭ �ǳ�)
    */

    level_itv = 1;
    if (lvl.num_level > 45 && var.size < 400) level_itv = 2;

    /*
    ���� ǥ�� ����(0:����, 1:�Ҽ���ù��°, 2:�Ҽ����ι�°, 9:0��1�� ȥ��
    */

    level_unit = 9;

    /*
    ����ǥ
    */

    for (i = 0; i < lvl.num_level; i++)
    {
        y = lvl.nj + lvl.title_pixel - dy*i;
        gdImageFilledRectangle(im, lvl.ni, (int)(y-dy+1), lvl.ni+lvl.color_pixel, (int)y, lvl.color[i]);
    }
    gdImageRectangle(im, lvl.ni, lvl.title_pixel, lvl.ni+lvl.color_pixel, lvl.nj+lvl.title_pixel, lvl.bgline_color);

    /*
    ����
    */

    font = 2;
    if (var.size < 400) font = 1;

    switch (font)
    {
    case 1: h = 4;  break;
    case 2: h = 5;  break;
    case 3: h = 6;  break;
    case 4: h = 7;  break;
    case 5: h = 8;  break;
    }

    x = lvl.ni + lvl.color_pixel + 2;

    for (i = level_start; i < lvl.num_level-1; i += level_itv)
    {
        switch (level_unit)
        {
        case 0: sprintf(text, "%d", (int)(lvl.level[i]));  break;
        case 1: sprintf(text, "%.1f", lvl.level[i]);  break;
        case 2: sprintf(text, "%.2f", lvl.level[i]);  break;
        case 9:
            if (fabs(lvl.level[i]) < 10)
                sprintf(text, "%.1f", lvl.level[i]);
            else
                sprintf(text, "%d", (int)(lvl.level[i]));
            break;
        }

        y = lvl.nj + lvl.title_pixel - dy*(i+1) - h;

        switch (font)
        {
        case 1: gdImageString(im, gdFontTiny,       x, (int)y, (unsigned char *)text, lvl.bgline_color);  break;
        case 2: gdImageString(im, gdFontSmall,      x, (int)y, (unsigned char *)text, lvl.bgline_color);  break;
        case 3: gdImageString(im, gdFontMediumBold, x, (int)y, (unsigned char *)text, lvl.bgline_color);  break;
        case 4: gdImageString(im, gdFontLarge,      x, (int)y, (unsigned char *)text, lvl.bgline_color);  break;
        case 5: gdImageString(im, gdFontGiant,      x, (int)y, (unsigned char *)text, lvl.bgline_color);  break;
        }
    }
    return 0;
}

/*=============================================================================*
 *  �̹����� ������ ǥ��
 *=============================================================================*/
int
rdr_maple_img_tail
(
    gdImagePtr im,          /* out:�̹��� */
    struct DATA_LEVEL lvl   /* inp:�̹��� ���� */
)
{
    char   text[60];
    int    YY, MM, DD, HH, MI, SS;
    int    font, x, y;

    if (lvl.tail_pixel <= 0) return 0;

    gdImageFilledRectangle(im, 0, lvl.nj+lvl.title_pixel, lvl.ni+lvl.color_pixel, lvl.gj-1, lvl.bg_color);
    gdImageRectangle(im, 0, lvl.nj+lvl.title_pixel, lvl.ni+lvl.color_pixel, lvl.gj-1, lvl.bgline_color);

    get_time(&YY, &MM, &DD, &HH, &MI, &SS);
    sprintf(text, "(%04d.%02d.%02d.%02d:%02d:%02d)", YY, MM, DD, HH, MI, SS);

    x = lvl.ni - strlen(text)*6;
    y = lvl.nj + lvl.title_pixel + 1;

    font = 2;
    switch (font)
    {
    case 1: gdImageString(im, gdFontTiny,       x, y, (unsigned char *)text, lvl.tail_color);  break;
    case 2: gdImageString(im, gdFontSmall,      x, y, (unsigned char *)text, lvl.tail_color);  break;
    case 3: gdImageString(im, gdFontMediumBold, x, y, (unsigned char *)text, lvl.tail_color);  break;
    case 4: gdImageString(im, gdFontLarge,      x, y, (unsigned char *)text, lvl.tail_color);  break;
    case 5: gdImageString(im, gdFontGiant,      x, y, (unsigned char *)text, lvl.tail_color);  break;
    }
    return 0;
}

/*******************************************************************************
 *  2, 3�辿 Ȯ���ϴ� ����� �������� �̹��� ����
 *******************************************************************************/
int
grid_img_map
(
    gdImagePtr im,          /* �̹��� */
    char   *map_file,       /* ����� ���� ���ϸ� */
    float  mi,              /* �������� �������� [km] */
    float  mj,              /* ���Ϲ��� �������� [km] */
    int    zoom_rate,       /* Ȯ���� (2:2��, 3:3��) */
    char   *zoom_x,         /* �������� Ȯ�� ���� */
    char   *zoom_y,         /* ���Ϲ��� Ȯ�� ���� */
    int    ni,              /* �������� �̹��� ũ�� [pixel] */
    int    nj,              /* ���Ϲ��� �̹��� ũ�� [pixel] */
    int    line_color,      /* ���� */
    int    line_depth       /* ������ (0:�Ǽ�, 1+:�� ����) */
)
{
    FILE   *fd;
    float  map_rate = (float)ni / (float)mi;
    float  zm = 1, xo = 0, yo = 0, zx, zy;
    float  buf[2];
    float  x1, y1, x2, y2, x, y;
    int    num, code, ibuf[2];
    int    ix1, iy1, ix2, iy2;
    int    i, j, k = 0;

    /*
    Ȯ����
    */

    if (zoom_rate == 3)
    {
        for (i = 0; i < 2; i++)
        {
            zx = zoom_x[i] - '0';
            zy = zoom_y[i] - '0';
            if (zx == 0 || zy == 0) break;

            xo += (int)((float)mi/9.0*(zx-1)/(float)zm);
            yo += (int)((float)mj/9.0*(zy-1)/(float)zm);
            zm *= zoom_rate;
        }
    }
    else if (zoom_rate == 2)
    {
        for (i = 0; i < 7; i++)
        {
            zx = zoom_x[i] - '0';
            zy = zoom_y[i] - '0';
            if (zx == 0 || zy == 0) break;

            xo += (int)((float)mi/8.0*(zx-1)/(float)zm);
            yo += (int)((float)mj/8.0*(zy-1)/(float)zm);
            zm *= zoom_rate;
        }
    }
    zm *= map_rate;

    /*
    �������� ���
    */

    if ( (fd = fopen(map_file, "rb")) == NULL) return -1;

    while (fread(ibuf, sizeof(int), 2, fd) > 0)
    {
        num  = ibuf[0];
        code = ibuf[1];

        fread(buf, sizeof(float), 2, fd);
        ix1 = (int)(zm * (buf[0] - xo) + 0.5);
        iy1 = nj - (int)(zm * (buf[1] - yo) + 0.5);

        for (i = 1; i < num; i++)
        {
            fread(buf, sizeof(float), 2, fd);
            ix2 = (int)(zm * (buf[0] - xo) + 0.5);
            iy2 = nj - (int)(zm * (buf[1] - yo) + 0.5);

            gdImageLine(im, ix1, iy1, ix2, iy2, line_color);
            if (line_depth > 0) gdImageLine(im, ix1+1, iy1, ix2+1, iy2, line_color);

            ix1 = ix2;
            iy1 = iy2;
        }
    }
    fclose(fd);

    return 0;
}

/*******************************************************************************
 *
 *  ���� �̹��� ����
 *
 *******************************************************************************/
int
rdr_maple_map
(
    gdImagePtr im,              /* out:�̹��� */
    struct INPUT_VAR  var,      /* inp:����� ��û���� */
    struct DATA_LEVEL lvl       /* inp:�̹��� �������� */
)
{
    FILE   *fd;
    char   map_file[120], text[16];
    int    w, x, i;

    /*
    ���� : �ñ��� ���
    */

    if (strchr(var.overlay,'C') != NULL)
    {
        sprintf(map_file, "%s/D%s_map1.bln", MAP_DIR, var.map);
        grid_img_map(im, map_file, (float)(lvl.nx*lvl.grid), (float)(lvl.ny*lvl.grid), var.zoom_rate, var.zoom_x, var.zoom_y, lvl.ni, lvl.nj+lvl.title_pixel, lvl.line2_color, lvl.line2_depth);
    }

    /*
    ���� : ����
    */

    if (strchr(var.overlay,'R') != NULL)
    {
        sprintf(map_file, "%s/D%s_map2.bln", MAP_DIR, var.map);
        grid_img_map(im, map_file, (float)(lvl.nx*lvl.grid), (float)(lvl.ny*lvl.grid), var.zoom_rate, var.zoom_x, var.zoom_y, lvl.ni, lvl.nj+lvl.title_pixel, lvl.river_color, lvl.river_depth);
    }

    /*
    ���� : ����
    */

    if (strchr(var.overlay,'H') != NULL)
    {
        sprintf(map_file, "%s/D%s_map3.bln", MAP_DIR, var.map);
        grid_img_map(im, map_file, (float)(lvl.nx*lvl.grid), (float)(lvl.ny*lvl.grid), var.zoom_rate, var.zoom_x, var.zoom_y, lvl.ni, lvl.nj+lvl.title_pixel, lvl.road_color, lvl.road_depth);
    }

    /*
    ���� : �ؾȼ� �� �����
    */

    if (strchr(var.overlay,'S') != NULL)
    {
        sprintf(map_file, "%s/D%s_map4.bln", MAP_DIR, var.map);
        grid_img_map(im, map_file, (float)(lvl.nx*lvl.grid), (float)(lvl.ny*lvl.grid), var.zoom_rate, var.zoom_x, var.zoom_y, lvl.ni, lvl.nj+lvl.title_pixel, lvl.line1_color, lvl.line1_depth);
    }

    /*
    ���� ǥ��
    */

    switch (var.map[0])
    {
    case 'D':  case 'R':  case 'E':  case 'F':
        if      (var.zoom_level == 0) w = 200;
        else if (var.zoom_level == 1) w = 80;
        else                          w = 20;
        break;
    }

    x = 0.5 * w * lvl.ni / (lvl.nx * lvl.grid);

    for (i = 0; i < var.zoom_level; i++)
        x *= (var.map[1] - '0');
/*
    gdImageFilledRectangle(im, 0, lvl.title_pixel+lvl.nj-5, x, lvl.title_pixel+lvl.nj, lvl.bg_color);
    gdImageFilledRectangle(im, x, lvl.title_pixel+lvl.nj-5, 2*x, lvl.title_pixel+lvl.nj, lvl.bgline_color);
    gdImageRectangle(im, 0, lvl.title_pixel+lvl.nj-5, x, lvl.title_pixel+lvl.nj, lvl.bgline_color);

    sprintf(text, "%dkm", w/2);
//    gdImageFilledRectangle(im, x-3*strlen(text), lvl.title_pixel+lvl.nj-18, x+3*strlen(text), lvl.title_pixel+lvl.nj-7, lvl.bg_color);
    gdImageString(im, gdFontSmall, x-3*strlen(text), lvl.title_pixel+lvl.nj-18, (unsigned char *)text, lvl.bgline_color);

    sprintf(text, "%dkm", w);
//    gdImageFilledRectangle(im, 2*x-3*strlen(text), lvl.title_pixel+lvl.nj-18, 2*x+4*strlen(text), lvl.title_pixel+lvl.nj-7, lvl.bg_color);
    gdImageString(im, gdFontSmall, 2*x-3*strlen(text), lvl.title_pixel+lvl.nj-18, (unsigned char *)text, lvl.bgline_color);
*/
    return 0;
}

/*******************************************************************************
 *
 *  ������ ������ ���� ���� : ����ǥ
 *
 *******************************************************************************/
int
rdr_maple_img_set_color
(
    gdImagePtr im,              /* �̹��� */
    struct INPUT_VAR   var,     /* ����� ��û���� */
    struct DATA_LEVEL *lvl      /* �̹��� �������� */
)
{
    FILE  *fp;
    char  fname[120], buf[100];
    int   file_color = 1, num_colors;
    int   R, G, B, i;

    /*
    RGB ������ ���Ͽ��� ����
    */

    if (!strcmp(var.color,"E"))
        sprintf(fname, "%s/color_E30N.rgb", COLOR_DIR);
    else if (!strcmp(var.color,"R"))
        sprintf(fname, "%s/color_E30R.rgb", COLOR_DIR);
    else if (!strcmp(var.color,"N"))
        sprintf(fname, "%s/color_S30N.rgb", COLOR_DIR);
    else
        sprintf(fname, "%s/color_%s.rgb", COLOR_DIR, var.color);

    if (file_color)
    {
        fp = fopen(fname,"r");
        if (fp == NULL) return -1;

        i = 0;

        while (fgets(buf,100,fp) != NULL)
        {
            if (strlen(buf) >= 5)
            {
                if ( sscanf(buf, "%d %d %d", &R, &G, &B) > 0 )
                {
                    (*lvl).color[i] = gdImageColorAllocate(im, R, G, B);
                    i++;
                }
            }
        }
        fclose(fp);
    }
//    (*lvl).num_level = i;

    /*
    ��Ÿ ����
    */

    (*lvl).contour_color = gdImageColorAllocate(im,  51,  51,  51);     /* ��ġ�� ���� */
    (*lvl).line1_color   = gdImageColorAllocate(im,  10,  10,  10);     /* �ؾȼ� �� ����� ���� */
    (*lvl).line2_color   = gdImageColorAllocate(im, 128, 128, 128);     /* ������� ���� */
    (*lvl).river_color   = gdImageColorAllocate(im,   0,   0, 128);     /* �� ���� */
    (*lvl).road_color    = gdImageColorAllocate(im, 128,  64,   0);     /* ���� ���� */
    (*lvl).latlon_color  = gdImageColorAllocate(im, 129, 129, 129);     /* ���浵�� ���� */
    (*lvl).missing_color = gdImageColorAllocate(im, 210, 210, 210);     /* �ڷ���� �Ǵ� �����ݰ�� ���� */
    (*lvl).bg_color      = gdImageColorAllocate(im, 255, 255, 255);     /* ��� ����(���)   */
    (*lvl).bgline_color  = gdImageColorAllocate(im,   0,   0,   0);     /* ��漱 ����(����) */
    (*lvl).bgwind_color  = gdImageColorAllocate(im, 160, 160, 160);     /* ��� ����(�ٶ�����) */
    (*lvl).stn1_color    = gdImageColorAllocate(im, 250, 250, 250);     /* �ٶ���,���� �ٱ� ���� */
    (*lvl).stn2_color    = gdImageColorAllocate(im, 255,   0,   0);     /* �������� ���� (���� ����) */
    (*lvl).stn3_color    = gdImageColorAllocate(im,   0,   0, 255);     /* �������� ���� (���� ����) */
    (*lvl).stn4_color    = gdImageColorAllocate(im,   0, 255,   0);     /* �������� ���� (���� �˼�����) */
    (*lvl).title_color   = gdImageColorAllocate(im,  30,  30,  30);     /* ����   ���ڻ� */
    (*lvl).level_color   = gdImageColorAllocate(im,  31,  31,  31);     /* ���� ���ڻ� */
    (*lvl).tail_color    = gdImageColorAllocate(im,  32,  32,  32);     /* ������ ���ڻ� */

    return 0;
}
