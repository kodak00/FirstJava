#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <gd.h>
#include <gdfontt.h>
#include <gdfonts.h>
#include <gdfontmb.h>
#include <gdfontl.h>
#include <gdfontg.h>
#include <zlib.h>
#include <zconf.h>

#include <cgiutil.h>
#include <nrutil.h>
#include <aws_data.h>
#include <stn_inf.h>
#include <map_ini.h>
#include <grid_img.h>

#define  IMG_DIR1      "/www/mis/web/tmp/rdr"
#define  IMG_DIR2      IMG_DIR1
#define  CGI_DIR       "/cgi-bin/rdr"
#define  CMP_DIR       "/DATA/RDR/CMP"

#define  BLANK1  -30000     /* No Area */
#define  BLANK2  -25000     /* No Data */
#define  BLANK3  -20000     /* Minimum Data */
