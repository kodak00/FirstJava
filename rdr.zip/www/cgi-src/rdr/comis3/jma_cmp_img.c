/***************************************************************************/
/*                                                                         */
/*  �Ϻ����̴� �ռ��� ���� ���α׷�                                        */
/*                                                                         */
/*=========================================================================*/
/*                                                                         */
/*     o �ۼ��� : ����ȯ (1999. 8. 21)                                     */
/*                                                                         */
/***************************************************************************/
#include "radar_jma.h"
#include "radar_jma_site.h"
#include "/usr/local/include/nrutil.h"

#define  NI  680
#define  NJ  800
int      GI, GJ;
float    rain[33] = { 0.0, 0.05, 0.1, 0.2, 0.4, 0.6, 0.8, 1.0, 1.5, 2.0, 3.0, 4.0, 5.0,
                      6.0, 7.0, 8.0, 9.0, 10.0, 12.0, 14.0, 16.0, 18.0, 20.0,
                     25.0, 30.0, 35.0, 40.0, 50.0, 60.0, 70.0, 80.0, 90.0, 100.0 };

struct COLOR HSL2RGB();
struct INPUT {
    int   seq;
    char  auto_man;
    int   an_itv;
    int   an_frn;
    char  html_gif;
};
char  g[NJ][NI];


int main(argc, argv)

int  argc;
char *argv[];
{
    struct INPUT  var;
    int    YY, MM, DD, HH, min, sec;

    if (strcmp( argv[1], "auto" ) == 0) {
        get_time( &YY, &MM, &DD, &HH, &min, &sec );
        var.seq = time2seq( YY, MM, DD, HH, min, 'm' ) - 8;
        var.seq = (var.seq/60)*60;
        GIF_make(var, 1);
    } else if (strcmp( argv[1], "man" ) == 0 ) {
        if (argc > 4) {
            YY = atoi( argv[2] );
            MM = atoi( argv[3] );
            DD = atoi( argv[4] );
            HH = atoi( argv[5] );
            var.seq = time2seq(YY, MM, DD, HH, 0, 'm');
            GIF_make(var, 1);
        } else {
            printf(" Usage : jma_cmp_img auto             \n");
            printf("         jma_cmp_img man YYYY MM DD HH\n");
            printf("    (ex. jma_cmp_img man 1999 8 20 12)\n");
            return -1;
        }
    } else {
        printf("HTTP/1.0 200 OK\n");
        printf("Server: Netscape-Enterprise/3.0\n");

        Input(&var);
        if      (var.html_gif == 'h') disp_html(var);
        else if (var.html_gif == 'g') disp_gif(var);
    }
    return 0;
}

/*********************************************************************
*
*  ����� ��û�� Ȯ��
*
*********************************************************************/
int Input(var)

struct INPUT *var;
{
    char *qs;
    char value[16][256];
    int  i, time1, time2, dtime;
    int  iYY, iMM, iDD, iHH, imin, sec;
    int  seq, iseq;

    /* input from env */
    qs = getenv("QUERY_STRING");
    if (qs == NULL) return -1;

    for(i=0; qs[0] != '\0'; i++)
        getword(value[i], qs, '_');

    /* Now time */
    get_time(&iYY, &iMM, &iDD, &iHH, &imin, &sec);
    iseq = time2seq(iYY, iMM, iDD, iHH, imin, 'm');

    /* user input time */
    time1 = atoi(value[0]);
    time2 = atoi(value[1]);
    dtime = atoi(value[2]);

    /* auto & man */
    (*var).auto_man = value[3][0];

    /* animation */
    (*var).an_itv = atoi(value[4]);
    (*var).an_frn = atoi(value[5]);
    if ((*var).an_frn > 48) (*var).an_frn = 48;

    /* html, gif & list */
    (*var).html_gif = value[6][0];

    /* time decoding */
    iseq = ((iseq - 17) / 60)*60;

    if ((*var).auto_man == 'a') {
        (*var).seq = iseq;
    } else {
        iDD = time1 % 100;
        iMM = ( time1 /= 100 ) % 100;
        iYY = time1 / 100;
        iHH = time2 / 100;
        (*var).seq = time2seq(iYY, iMM, iDD, iHH, 0, 'm') + dtime;
        if ((*var).seq > iseq) (*var).seq = iseq;
    }
    return 0;
}

/*********************************************************************
*
*  GIF mode
*
*********************************************************************/
int disp_gif(var)

struct INPUT var;
{
    FILE  *fd;
    char   gname[120];
    int    code, len, c;

    if (GIF_file(var, gname) < 0) {
        GIF_make(var, 0);
    }

    printf("Content-type: image/gif\n\n");

    strcpy(gname, "/www/htdocs");
    len = strlen(gname);
    GIF_file(&gname[len]);
    if ( (fd = fopen(gname, "rb")) != NULL ) {
        c = getc(fd);
        while(c != EOF) {
            putchar(c);
            c = getc(fd);
        }
        fclose(fd);
    }
    return 0;
}

/*********************************************************************
*
*  HTML mode
*
*********************************************************************/
int disp_html(var)

struct INPUT var;
{
    char  gname[48][120];
    int   n, i;

    printf("Content-type: text/html\n\n");

    /* for animation */
    if (var.an_frn > 1) {
        var.seq = var.seq - (var.an_frn-1) * var.an_itv;
    }

    n = 0;
    for(i = 0; i < var.an_frn; i++)
    {
        if (GIF_file(var, gname[n]) < 0) {
            GIF_make(var, 0);
        }
        n++;
        if (var.an_frn > 1) var.seq += var.an_itv;
    }

    /* HEAD �ۼ� */
    HEAD_print(var, n, gname);

    /* HTML �ۼ� */
    HTML_print(var, n, gname);

    return 0;
}

/*====================================================================
*
*  HEAD ������ ���
*
*===================================================================*/
int HEAD_print(var, n, gname)

struct INPUT var;
int   n;
char  gname[][120];
{
    int  YY, MM, DD, HH, min;
    int  i;

    seq2time(var.seq, &YY, &MM, &DD, &HH, &min, 'm', 'y');

    printf("<HTML>\n");
    printf("<HEAD>\n");
    printf("<SCRIPT LANGUAGE='JavaScript'>\n");
    printf("<!--\n");
    printf("parent.menu.time1 = %d\n", (YY*100 + MM)*100 + DD);
    printf("parent.menu.time2 = %d\n", HH*100);

    if (n > 1 && var.html_gif == 'h') {
        printf("var counter = 0\n");
        printf("var animation = 1\n");
        printf("var timer\n");
        printf("var i, j\n");
        printf("var imgs = new Array()\n");
        printf("for(i = 0; i < %d; i++) {\n", n);
        printf("  imgs[i] = new Image()\n");
        printf("}\n\n");
        for(i = 0; i < n; i++) {
            printf("imgs[%d].src = '%s'\n", i, gname[i]);
        }
        printf("\n");
        printf("function animate() {\n");
        printf("  if (animation == 1) {\n");
        printf("    counter = (counter + 1) %% %d\n", n);
        printf("    document.anim.src = imgs[counter].src\n");
        printf("    timer = setTimeout('animate()', 1000)\n");
        printf("  }\n");
        printf("}\n\n");
        printf("function play() {\n");
        printf("  animation = 1\n");
        printf("  animate()\n");
        printf("}\n\n");
        printf("function stop() {\n");
        printf("  animation = 0\n");
        printf("}\n\n");
        printf("function moving(bf) {\n");
        printf("  counter = (counter + bf + %d) %% %d\n", n, n);
        printf("    document.anim.src = imgs[counter].src\n");
        printf("}\n\n");
    }
    printf("// -->\n");
    printf("</SCRIPT>\n");
    printf("</HEAD>\n");

    return 0;
}

/*====================================================================
*
*  BODY ������ ���
*
*===================================================================*/
int HTML_print(var, n, gname)

struct INPUT var;
int   n;
char  gname[][120];
{
    char  name[16];
    int   seq, seq1, seq2;
    int   YY, MM, DD, HH, min;
    int   time_auto;
    int   i;

    /* for animation */
    if (n > 1) {
        printf("<BODY bgcolor=#ffffff onload='animate()' TOPMARGIN=0 LEFTMARGIN=0 marginwidth=0 marginheight=0>\n");
        printf("<a href='javascript:play()'><img src='/images/play.gif' border=0></a>\n");
        printf("<a href='javascript:stop()'><img src='/images/stop.gif' border=0></a>\n");
        printf("<a href='javascript:moving(-1)'><img src='/images/back.gif' border=0></a>\n");
        printf("<a href='javascript:moving(1)'><img src='/images/for.gif' border=0></a><br>\n");
    } else {
        printf("<BODY bgcolor=#ffffff TOPMARGIN=0 LEFTMARGIN=0 marginwidth=0 marginheight=0>\n");
    }

    /* for auto & man (per 10mmin) */
    if (var.auto_man == 'a') {
        time_auto = 1000 * 60 * 10;
        printf("<SCRIPT LANGUAGE='JavaScript'>\n");
        printf("<!--\n");
        printf("  window.setTimeout('parent.menu.make_cmd();', %d)\n", time_auto);
        printf("// -->\n");
        printf("</SCRIPT>\n");
    }

    /* image */
    printf("<img name='anim' src='%s' border=0>\n", gname[0]);

    printf("</BODY></HTML>\n");
    return 0;
}
    
/*********************************************************************
*
*  �Ϻ� ���̴� �ռ��� ���� ����
*
*********************************************************************/
int GIF_make(var, mode)

struct INPUT var;
int    mode;
{
    FILE   *fd;
    char   gname[120];
    int    YY, MM, DD, HH, min;
    struct lamc_parameter  map;
    gdImagePtr  im;
    int    color[256], c;
    int    len, i, j, k;

    if (mode) {
        seq2time(var.seq, &YY, &MM, &DD, &HH, &min, 'm', 'n');

        printf("----------------------------------------------------\n");
        printf("[ jma_cmp_img ] %04d.%02d.%02d.%02d:%02d(LST)\n", YY,MM,DD,HH,min);
        printf("----------------------------------------------------\n");
    }

    /*--------------------------------------------------------*/
    /* �ռ��� MAP parameter */
    /*--------------------------------------------------------*/
    map.Re    = 6370.19584;
    map.grid  = 2.5;
    map.slat1 = 30.0;
    map.slat2 = 60.0;
    map.olon  = 125.0;
    map.olat  = 35.0;
    map.xo    = 400.0 / map.grid;
    map.yo    = 1460.0 / map.grid;
    map.first = 0;

    /*--------------------------------------------------------*/
    /* �ռ��ڷ� ��� */
    /*--------------------------------------------------------*/
    if (mode) printf(" initialized ...\n");

    /* cmp data initialize */
    for(j = 0; j < NJ; j++) {
    for(i = 0; i < NI; i++) {
        g[j][i] = 255;
    }
    }

    /* Per radar site */
    if (mode) printf(" radar composition ...\n");
    for(k = 0; k < NUM_SITE; k++) {
        if (mode) printf("    site : %d\n", site[k].stn_id);
        radar_cmp(g, map, var.seq, k);
    }

    /* composed data smoothing */
    cmp_sm(g);

    /*--------------------------------------------------------*/
    /* �ռ��̹��� ���� */
    /*--------------------------------------------------------*/
    GI = NI + LEVEL_pixel;
    GJ = NJ + TITLE_pixel;

    /* gd Image alloc. & color table */
    im = gdImageCreate(GI+1, GJ+1);

    /* color table */
    color_table(im, color);

    gdImageFilledRectangle(im, 0, 0, GI, GJ, color[255]);

    /* cmp image make */
    if (mode) printf(" composed data imaging ..\n");
    cmp_disp(im, color, g, var.seq, map);

    /*--------------------------------------------------------*/
    /* GIF ���Ϸ� ���� */
    /*--------------------------------------------------------*/
    strcpy(gname, "/www/htdocs");
    len = strlen(gname);
    GIF_file(var, &gname[len]);
    if (mode) printf(" Gif file = %s\n", gname);

    if ( (fd = fopen(gname, "wb")) == NULL ) {
        gdImageDestroy(im);
        return -1;
    } else {
        gdImageGif(im, fd);
        fclose(fd);
    }
    gdImageDestroy(im);

    return 0;
}

/*====================================================================
*
*  Color Table �ۼ�
*
*===================================================================*/
int color_table(im, color)

gdImagePtr im;
int color[];
{
    struct COLOR rgb;
    int    H, S = 255, L = 127;
    float  center;
    int    cj[6] = {4,3,2,1,6,5};
    int    i, j, k;

    /* data level color */
    color[0] = gdImageColorAllocate(im, 0, 0, 0);
    color[1] = gdImageColorAllocate(im, 230, 230, 230);
    color[2] = gdImageColorAllocate(im, 160, 160, 160);

    for(k = 3, j = 0; j < 6; j++)
    {
        H = (int)(256.0/6.0 * (float)(j + 1));
        if (j == 3) center = 2.0;
        else        center = 1.7;

        for(i = 0; i < 5; i++, k++)
        {
            L = (int)(127.0 + (center - (float)i)*30.0);
            if (i == 3)      L -= 10;
            else if (i == 2) L -= 15;
            else if (i == 1) L += 20;
            else if (i == 0) L += 30;
            rgb = HSL2RGB(H, S, L);
            color[k] = gdImageColorAllocate(im, rgb.R, rgb.G, rgb.B);
        }
    }

    /* other color */
    color[245] = gdImageColorAllocate(im, 128, 128, 128);   /* ���浵�� */
    color[246] = gdImageColorAllocate(im, 0, 0, 255);       /* �Ķ���   */
    color[247] = gdImageColorAllocate(im, 255, 255, 0);     /* �����   */
    color[248] = gdImageColorAllocate(im, 1, 1, 1);         /* �������� */
    color[249] = gdImageColorAllocate(im, 255, 0, 0);       /* stn      */
    color[250] = gdImageColorAllocate(im, 128, 64, 0);      /* ����     */
    color[251] = gdImageColorAllocate(im, 0, 0, 128);       /* ����     */
    color[252] = gdImageColorAllocate(im, 128, 128, 128);   /* ������� */
    color[253] = gdImageColorAllocate(im, 200, 200, 200);   /* blank    */
    color[254] = gdImageColorAllocate(im, 200, 200, 200);   /* shade line */
    color[255] = gdImageColorAllocate(im, 255, 255, 255);   /* white    */

    return 0;
}

/*********************************************************************
*
*  ���ŵ� ���̴��ڷ� �ռ�
*
*********************************************************************/
int radar_cmp(g, map, seq, k)

char   g[NJ][NI];
struct lamc_parameter  map;
int    seq;
int    k;
{
    FILE   *fd;
    char   fname[120];
    struct azed_parameter  jdr;
    float  lon, lat, x1, y1, x2, y2;
    int    ix2, iy2;
    int    v;
    int    i, j, i1, j1;

    /* Map parameter */
    jdr.Re    = 6370.19584 + site[k].height * 0.001;
    jdr.grid  = 5.0;
    jdr.slon  = site[k].lon;
    jdr.slat  = site[k].lat;
    jdr.olon  = jdr.slon;
    jdr.olat  = jdr.slat;
    jdr.xo    = 250.0/jdr.grid;
    jdr.yo    = 250.0/jdr.grid;
    jdr.first = 0;

    /* data file open */
    if ( DATA_file(seq, site[k].stn_id, fname) < 0 ) return -1;
    fd = fopen(fname, "rb");
    for(i = 0; i < 4; i++) v = fgetc(fd);

    /* map conversion */
    for(j = 0; j < NY; j++) {
    for(i = 0; i < NX; i++) {
        v = fgetc(fd);

        y1 = (float)(NY - j) - 0.5;
        x1 = (float)i + 0.5;
        azedproj(&lon, &lat, &x1, &y1, 1, jdr);
        lamcproj(&lon, &lat, &x2, &y2, 0, map);
        ix2 = (int)x2;
        iy2 = (int)y2;

        for(j1 = iy2-1; j1 <= iy2+1; j1++) {
        for(i1 = ix2-1; i1 <= ix2+1; i1++) {
            if (g[j1][i1] == 255 || v > g[j1][i1]) g[j1][i1] = v;
        }
        }
    }
    }
    fclose(fd);

    return 0;
}

/*====================================================================
*
*  �ռ��� ���̴��ڷ� Smoothing
*
*===================================================================*/
int cmp_sm(g)

char g[NJ][NI];
{
    int    g1, g2, g3;
    float  d1, d2;
    int    i, j;

    for(j = 0; j < NJ; j++) {
        d1 = 255.0001;
        for(i = 1; i < NI-1; i++) {
            g1 = g[j][i-1];
            g2 = g[j][i];
            g3 = g[j][i+1];
            if (g1 < 255 && g2 < 255 && g3 < 255) {
                d2 = (float)(g1 + 2*g2 + g3) * 0.25;
            } else {
                d2 = (float)g2;
            }
            g[j][i-1] = (int)d1;
            d1 = d2;
        }
    }

    for(i = 0; i < NI; i++) {
        d1 = 255.0001;
        for(j = 1; j < NJ-1; j++) {
            g1 = g[j-1][i];
            g2 = g[j][i];
            g3 = g[j+1][i];
            if (g1 < 255 && g2 < 255 && g3 < 255) {
                d2 = (float)(g1 + 2*g2 + g3) * 0.25;
            } else {
                d2 = (float)g2;
            }
            g[j-1][i] = (int)d1;
            d1 = d2;
        }
    }
    return 0;
}

/*********************************************************************
*
*  �ռ��ڷ� �̹��� ó��
*
*********************************************************************/
int cmp_disp(im, color, g, seq, map)

gdImagePtr im;
int    color[];
char   g[NJ][NI];
int    seq;
struct lamc_parameter  map;
{
    FILE   *fd;
    char   fname[120];
    struct azed_parameter  jdr;
    float  lon, lat, x1, y1, x2, y2;
    int    ix1, iy1, ix2, iy2;
    int    ibuf[2], num, code;
    float  buf[2];
    float  v;
    int    c;
    int    i, j, k, i1;

    /* data display */
    /*printf("    data drow ...\n");*/
    for(j = 0; j < NJ; j++) {
    for(i = 0; i < NI; i++) {
        v = (float)g[j][i];
        if (v == 255) continue;

        c = 32;
        for(i1 = 1; i1 < 33; i1++) {
            if (v < rain[i1]) {
                c = i1;
                break;
            }
        }

        gdImageSetPixel(im, i, GJ-j, color[c]);
    }
    }

    /* map display */
    /*printf("    map drow ...\n");*/
    fd = fopen("/www/cgi-bin/ref/RDR_total.bln", "rb");

    while( fread(ibuf, sizeof(int), 2, fd) > 0 )
    {
        num  = ibuf[0];
        code = ibuf[1];

        fread(buf, sizeof(float), 2, fd);
        ix1 = (int)(buf[0] + 0.5);
        iy1 = GJ - (int)(buf[1] + 0.5);

        for(i = 1; i < num; i++)
        {
            fread(buf, sizeof(float), 2, fd);

            ix2 = (int)(buf[0] + 0.5);
            iy2 = GJ - (int)(buf[1] + 0.5);
            gdImageLine(im, ix1, iy1, ix2, iy2, color[0]);

            ix1 = ix2;
            iy1 = iy2;
        }
    }
    fclose(fd);

    /* ���浵�� */
    latlon_disp(im, color, map);

    /* ���� ǥ�� */
    for(k = 0; k < NUM_SITE; k++) {
        if (DATA_file(seq, site[k].stn_id, fname) >= 0) {
            lat = site[k].lat;
            lon = site[k].lon;
            lamcproj(&lon, &lat, &x2, &y2, 0, map);
            y2 = GJ - y2;
            gdImageFilledRectangle(im, (int)x2-3, (int)y2-3, (int)x2+3, (int)y2+3, color[249]);
        }
    }

    /* level display */
    level_disp(im, color);

    /* title display */
    title_disp(im, color, seq);

    return 0;
}

/*====================================================================
*
*  LEVEL display
*
*===================================================================*/
int level_disp(im, color)

gdImagePtr im;
int color[];
{
    char  level_text[16];
    float dy = (float)NJ/(32.0), y1, y2;
    int   i;

    gdImageFilledRectangle(im, NI, 0, GI, GJ, color[255]);

    /*------ ����ǥ ------------------------------------------------*/
    y2 = GJ;
    for(i = 1; i < 33; i++) {
        y1 = y2 - dy;
        gdImageFilledRectangle(im, NI, (int)y1, NI+8, (int)y2, color[i]);
        gdImageLine(im, NI, (int)y2, NI+8, (int)y2, color[0]);
        y2 = y1;
    }
    gdImageRectangle(im, 0, TITLE_pixel, NI, GJ, color[0]);
    gdImageRectangle(im, 0, 0, NI+8, GJ, color[0]);

    /*------ ���� ------------------------------------------------*/
    for(i = 1; i < 32; i++) {
        if (rain[i] < 10) sprintf(level_text, "%.1f", rain[i]);
        else              sprintf(level_text, "%d", (int)rain[i]);

        y1 = GJ - dy*((float)i+0.2);
        gdImageString(im, gdFontSmall, NI+10, (int)y1, level_text, color[0]);
    }
    return 0;
}

/*====================================================================
*
*  TITLE display
*
*===================================================================*/
int title_disp(im, color, seq)

gdImagePtr im;
int color[];
int seq;
{
    char  text[120];
    int   YY, MM, DD, HH, min;

    gdImageFilledRectangle(im, 0, 0, NI+8, TITLE_pixel, color[0]);

    seq2time(seq, &YY, &MM, &DD, &HH, &min, 'm', 'n');
    sprintf(text, "[JMA CMP] %04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, min);
    gdImageString(im, gdFontGiant, 8, 3, text, color[247]);
    strcpy(text, "1H RAIN");
    gdImageString(im, gdFontGiant, NI-70, 3, text, color[247]);

    return 0;
}

/*====================================================================
*
*  ���浵�� display
*
*===================================================================*/
int latlon_disp(im, color, map)

gdImagePtr im;
int    color[];
struct lamc_parameter  map;
{
    int    lon, lat;
    float  alon1, alat1, alon2, alat2;
    float  x1, y1, x2, y2;

    /* �浵�� */
    alat1 = 20.0;
    alat2 = 40.0;

    for(lon = 118; lon < 146; lon += 2) {
        alon1 = (float)lon;
        lamcproj(&alon1, &alat1, &x1, &y1, 0, map);
        lamcproj(&alon1, &alat2, &x2, &y2, 0, map);
        gdImageLine(im, (int)x1, GJ-(int)y1, (int)x2, GJ-(int)y2, color[245]);
    }

    /* ������ */
    for(lat = 20; lat < 40; lat += 2) {
        alat1 = (float)lat;
        alon1 = 118.0;
        lamcproj(&alon1, &alat1, &x1, &y1, 0, map);

        for(lon = 1180; lon < 1460; lon++) {
            alon2 = 0.1 * (float)lon;
            lamcproj(&alon2, &alat1, &x2, &y2, 0, map);
            gdImageLine(im, (int)x1, GJ-(int)y1, (int)x2, GJ-(int)y2, color[245]);
            x1 = x2;
            y1 = y2;
        }
    }

    /* ���浵�� */
    gdImageString(im, gdFontLarge,  30, GJ-17, "122E", color[246]);
    gdImageString(im, gdFontLarge, 120, GJ-17, "124E", color[246]);
    gdImageString(im, gdFontLarge, 210, GJ-17, "126E", color[246]);
    gdImageString(im, gdFontLarge, 300, GJ-17, "128E", color[246]);
    gdImageString(im, gdFontLarge, 380, GJ-17, "130E", color[246]);
    gdImageString(im, gdFontLarge, 470, GJ-17, "132E", color[246]);
    gdImageString(im, gdFontLarge, 550, GJ-17, "134E", color[246]);
    gdImageString(im, gdFontLarge, 640, GJ-17, "136E", color[246]);

    gdImageString(im, gdFontLarge, NI-25,  40, "38N", color[246]);
    gdImageString(im, gdFontLarge, NI-25, 130, "36N", color[246]);
    gdImageString(im, gdFontLarge, NI-25, 220, "34N", color[246]);
    gdImageString(im, gdFontLarge, NI-25, 310, "32N", color[246]);
    gdImageString(im, gdFontLarge, NI-25, 400, "30N", color[246]);
    gdImageString(im, gdFontLarge, NI-25, 490, "28N", color[246]);
    gdImageString(im, gdFontLarge, NI-25, 580, "26N", color[246]);
    gdImageString(im, gdFontLarge, NI-25, 670, "24N", color[246]);
    gdImageString(im, gdFontLarge, NI-25, 760, "22N", color[246]);

    return 0;
}

/*********************************************************************
*
*  GIF ���� ���翩�� �� �����̸� ��ȯ
*
*********************************************************************/
int GIF_file(var, fname)

struct INPUT var;
char   *fname;
{
    struct stat st;
    char   *p;
    int    YY, MM, DD, HH, min;
    int    code = 0;

    seq2time(var.seq, &YY, &MM, &DD, &HH, &min, 'm', 'n');
    sprintf(fname, "/www/htdocs/gif/JRD_COMP_%04d%02d%02d_%02d%02d_1CC.gif",
                    YY, MM, DD, HH, 0);
    if (stat(fname, &st) < 0)
        code = -1;
    else {
        if (st.st_size < 512)
            code = -2;
    }
    p = strstr(fname, "/gif/");
    strcpy(fname, p);

    return code;
}

/*********************************************************************
*
*  �ڷ����� ���翩�� �� �����̸� ��ȯ
*
*********************************************************************/
int DATA_file(seq, stn_id, fname)

int  seq;
int  stn_id;
char *fname;
{
    struct stat st;
    int    YY, MM, DD, HH, min;
    int    code = 0;
    int    k;

    seq2time(seq-9*60, &YY, &MM, &DD, &HH, &min, 'm', 'n');

    for(k = 0; k < NUM_SITE; k++) {
        if (stn_id == site[k].stn_id) {
            if (YY >= 2000) {
                if (stn_id == 47705 || stn_id == 47806 || stn_id == 47869 || stn_id == 47909)
                    sprintf(fname, "%sJRD_%s_SDJP81_%04d%02d%02d_%02d%02d",
                            JMA_DB, site[k].cccc, YY, MM, DD, HH, min);
                else
                    sprintf(fname, "%sJRD_%s_SDJP33_%04d%02d%02d_%02d%02d",
                            JMA_DB, site[k].cccc, YY, MM, DD, HH, min);
            } else {
                if (stn_id == 47705)
                    sprintf(fname, "%sJRD_%s_SDJP81_%04d%02d%02d_%02d%02d",
                            JMA_DB, site[k].cccc, YY, MM, DD, HH, min);
                else
                    sprintf(fname, "%sJRD_%s_SDJP33_%04d%02d%02d_%02d%02d",
                            JMA_DB, site[k].cccc, YY, MM, DD, HH, min);
            }
            break;
        }
    }
    if (k >= NUM_SITE) return -3;

    if (stat(fname, &st) < 0)
        code = -1;
    else {
        if (st.st_size < 3000)
            code = -2;
    }
    return code;
}

int print_input(var)

struct INPUT var;
{
    int  YY, MM, DD, HH, min;

    seq2time(var.seq, &YY, &MM, &DD, &HH, &min, 'm', 'n');
    printf("time     = %04d.%02d.%02d.%02d<br>\n", YY, MM, DD, HH);
    printf("auto_man = %c<br>\n", var.auto_man);
    printf("an_itv   = %d<br>\n", var.an_itv);
    printf("an_frn   = %d<br>\n", var.an_frn);
    printf("html_gif = %c<br>\n", var.html_gif);

    return 0;
}
