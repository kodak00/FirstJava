/***************************************************************************/
/*                                                                         */
/*  �Ϻ����̴� �ռ��� ��ǥ��ȯ�� ���� ������ ��ȭ Ȯ�ο� ���α׷�          */
/*                                                                         */
/*     o ������� : /www/htdocs/RDR/jma_cmp_area.gif"                      */
/*                                                                         */
/*=========================================================================*/
/*                                                                         */
/*     o �ۼ��� : ����ȯ (1999. 8. 21)                                     */
/*                                                                         */
/***************************************************************************/
#include "radar_jma.h"
#include "radar_jma_site.h"
#include "/usr/local/include/nrutil.h"

#define  NI  700
#define  NJ  800


main(argc, argv)

int  argc;
char *argv[];
{
    FILE   *fd;
    char   fname[120];
    struct lamc_parameter  map;
    struct azed_parameter  jdr;
    float  lon, lat, x1, y1, x2, y2, ac;
    gdImagePtr  im;
    int    color[16], c;
    int    ibuf[2], num, code;
    int    ix1, iy1, ix2, iy2;
    float  buf[2];
    int    i, j, k;

    /* �ռ��� MAP parameter */
    map.Re    = 6370.19584;
    map.grid  = 2.5;
    map.slat1 = 30.0;
    map.slat2 = 60.0;
    map.olon  = 125.0;
    map.olat  = 35.0;
    map.xo    = 180.0;
    map.yo    = 590.0;
    map.first = 0;
    ac = 250.0 / map.grid;

    /* gd Image alloc. & color table */
    im = gdImageCreate(NI+1, NJ+1);

    color[0] = gdImageColorAllocate(im, 0, 0, 0);
    color[1] = gdImageColorAllocate(im, 230, 230, 230);
    color[2] = gdImageColorAllocate(im, 200, 200, 200);
    color[3] = gdImageColorAllocate(im, 255, 0, 0);
    color[4] = gdImageColorAllocate(im, 0, 255, 0);
    color[5] = gdImageColorAllocate(im, 0, 0, 255);

    gdImageFilledRectangle(im, 0, 0, NI, NJ, color[1]);

    /* ���� ���̴����� */
/*
    for(k = 0; k < NUM_SITE; k++) {
        lat = site[k].lat;
        lon = site[k].lon;
        lamcproj(&lon, &lat, &x2, &y2, 0, map);
        y2 = NJ - y2;
        gdImageFilledRectangle(im, (int)(x2-ac), (int)(y2-ac), (int)(x2+ac), (int)(y2+ac), color[2]);
    }
*/
    printf(" initial ...\n");

    /* Per Radar site */
    for(k = 0; k < NUM_SITE; k++)
    {
        printf(" radar site = %d\n", site[k].stn_id);
        c = k%3 + 3;

        /* ���̴� MAP parameter */
        jdr.Re    = 6370.19584 + site[k].height * 0.001;
        jdr.grid  = 5.0;
        jdr.slon  = site[k].lon;
        jdr.slat  = site[k].lat;
        jdr.olon  = jdr.slon;
        jdr.olat  = jdr.slat;
        jdr.xo    = 250.0/jdr.grid;
        jdr.yo    = 250.0/jdr.grid;
        jdr.first = 0;

        /* ���̴��ڷ� ��ǥ ��ȯ */
        for(j = 0; j < NY; j++) {
        for(i = 0; i < NX; i++) {
            y1 = (float)j + 0.5;
            x1 = (float)i + 0.5;
            azedproj(&lon, &lat, &x1, &y1, 1, jdr);
            lamcproj(&lon, &lat, &x2, &y2, 0, map);
            ix2 = (int)x2;
            iy2 = (int)(NJ - y2);
            /*gdImageFilledRectangle(im, ix2-1, iy2-1, ix2+1, iy2+1, color[c]);*/
            gdImageSetPixel(im, ix2, iy2, color[c]);
        }
        }
    }

    /* MAP */
    printf(" map drow ...\n");
    fd = fopen("/www/cgi-bin/ref/JMA_CMP.bln", "rb");

    while( fread(ibuf, sizeof(int), 2, fd) > 0 )
    {
        num  = ibuf[0];
        code = ibuf[1];

        fread(buf, sizeof(float), 2, fd);
        ix1 = (int)(buf[0] + 0.5);
        iy1 = NJ - (int)(buf[1] + 0.5);

        for(i = 1; i < num; i++)
        {
            fread(buf, sizeof(float), 2, fd);

            ix2 = (int)(buf[0] + 0.5);
            iy2 = NJ - (int)(buf[1] + 0.5);
            gdImageLine(im, ix1, iy1, ix2, iy2, color[0]);

            ix1 = ix2;
            iy1 = iy2;
        }
    }
    fclose(fd);

    /* RADAR site */
    for(i = 0; i < NUM_SITE; i++) {
        lat = site[i].lat;
        lon = site[i].lon;
        lamcproj(&lon, &lat, &x2, &y2, 0, map);
        y2 = NJ - y2;
        gdImageFilledRectangle(im, (int)x2-3, (int)y2-3, (int)x2+3, (int)y2+3, color[3]);
        gdImageString(im, gdFontGiant, x2+2, y2, site[i].name, color[5]);
    }

    gdImageRectangle(im, 0, 0, NI, NJ, color[0]);

    /* GIF file */
    printf(" gif file make ...\n");
    sprintf(fname, "/www/htdocs/RDR/jma_cmp_area.gif");
    fd = fopen(fname, "wb");
    gdImageGif(im, fd);
    fclose(fd);

    gdImageDestroy(im);
    return 0;
}
