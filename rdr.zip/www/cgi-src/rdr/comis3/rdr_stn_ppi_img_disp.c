/*********************************************************************
**
**  RADAR CAPPI / PPI �м��� CGI ���α׷�  (�̹��� ������ƾ)
**
**********************************************************************/
#include "rdr_stn_ppi_img.h"
#include "/www/mis/cgi-src/include/rdr_stn.h"
extern struct INPUT_VAR  var;

#define  DEGRAD  3.1415927/180.0
#define  RADDEG  180.0/3.1415927
#define  MAXIMG  1024

struct COLOR HSL2RGB();

short  echo[6][MAXIMG+1][MAXIMG+1];
float  dbz[31];
float  rain[31] = {0.1, 0.2, 0.4, 0.6, 0.8, 1.0, 1.5, 2.0, 3.0, 4.0, 5.0,
                        6.0, 7.0, 8.0, 9.0,10.0,12.0,14.0,16.0,18.0,20.0,
                       25.0,30.0,35.0,40.0,50.0,60.0,70.0,80.0,90.0,100.0};
Radar  *radar;
Volume *volume;
Sweep  *sweep;
Ray    *ray;
int    seq_uf;
int    nx1, nx2, ny1, ny2;
float  RE, hl[3];                       /* ��������(m), CAPPI ����(m) */
float  rain_min=0.05, dbz_min = -50;    /* ȭ�鿡 ǥ���� �ּ� ������(mm/h) �� DBZ �� (default=50) */

int level_color(short);

/*********************************************************************
 *
 *  ������ UF���̴��ڷḦ �����ڷ�� ��ȯ�Ͽ� �̹��� ����
 *
 *********************************************************************/
int rdr_stn_ppi_img()
{
    int  YY, MM, DD, HH, min;
    int  r, first = 0, code;
    int  i, j, k, n = 0;

    /*---------------------------------------------------------------*/
    /* UF file open & volume,sweep check */

    printf("%s %04d.%02d.%02d.%02d:%02d......", var.data0,var.YY,var.MM,var.DD,var.HH,var.min);

    radar = RSL_uf_to_radar(var.fname);
    if (radar == NULL)
    {
        printf("error<br>\n");
        return -1;
    }
    else
    {
        printf("ok<br>\n");
    }

    /* UF ���ϳ� �ð� Ȯ�� (UTC) */
    YY = radar->h.year;
    MM = radar->h.month;
    DD = radar->h.day;
    HH = radar->h.hour;
    min= radar->h.minute;
    seq_uf = time2seq(YY, MM, DD, HH, min, 'm');

    /*---------------------------------------------------------------*/
    /* range check */

    var.range = 10;

    for (i = 0; i < radar->h.nvolumes; i += 2)
    {
        if (i > 3) break;

        if ((volume = radar->v[i]) != NULL)
        {
            for (j = 0; j < volume->h.nsweeps; j++)
            {
                if ((sweep = volume->sweep[j]) != NULL)
                {
                    for (k = 0; k < sweep->h.nrays; k++)
                    {
                        if ((ray = sweep->ray[i]) != NULL)
                        {
                            r = (ray->h.nbins)*(ray->h.gate_size) + ray->h.range_bin1;
                            if (r > var.range)
                            {
                                var.range = r;
                                break;
                            }
                        }
                        break;
                    }
                }
            }
        }
    }
    if (var.range < 20000) var.range = 240000;

    /*---------------------------------------------------------------*/

    code = rdr_stn_ppi_grd();

    if (code == 0)
        code = rdr_stn_ppi_img_make();
    else
        code = -1;

    /*---------------------------------------------------------------*/

    RSL_free_radar(radar);

    return code;
}

/*********************************************************************
 *
 *  UF Radar data Read & Griding
 *
 *********************************************************************/
int rdr_stn_ppi_grd()
{
    float rdr_ht, elev[2], rl[2][3], seaecho;
    int   i, j, k, nsweep = 0;
    int   first = 0;

    if ((volume = radar->v[var.ds1]) == NULL) return -1;

    /*------------------------------------------------------------*/
    /* �ʱ�ȭ */

    for (j = 0; j <= MAXIMG; j++)
    {
        for (i = 0; i <= MAXIMG; i++)
        {
            echo[0][j][i] = -32000;
            echo[1][j][i] = -32000;
            echo[2][j][i] = -32000;
            echo[3][j][i] = -32000;
            echo[4][j][i] = -31000;
            echo[5][j][i] = -31000;
        }
    }

    RE = 6371008.77;
    hl[0] = 1000;
    hl[1] = 1500;
    hl[2] = 2000;
    seaecho = 10;
    rdr_ht = 0;

    for (j = 0; j < RDR_STN_NUM; j++)
    {
        if (strcmp(var.data0,rdr_stn[j].head) == 0)
        {
            seaecho = rdr_stn[j].seaecho*1000;
            rdr_ht = rdr_stn[j].height;
            RE += rdr_ht;
            for (i = 0; i < 3; i++) hl[i] -= rdr_ht;
            break;
        }
    }

    /*------------------------------------------------------------*/
    /* ������ �����ڷ�� ��ȯ */

    for (k = 0; k < volume->h.nsweeps; k++)
    {
        if ((sweep = volume->sweep[k]) != NULL)
        {
            var.elev = sweep->h.elev;
			if (var.elev > 300) var.elev -= 360.0;
            elev[1] = var.elev;
            printf("%7.4f :", var.elev);

            for (i = 0; i < 3; i++)
            {
                rl[1][i] = sqrt(RE*RE*sin(var.elev*DEGRAD)*sin(var.elev*DEGRAD) + hl[i]*hl[i] + 2.0*hl[i]*RE)
                         - RE*sin(var.elev*DEGRAD);
                printf(" %6.2f", rl[1][i]*0.001);
            }
            printf("<br>\n");

            for (j = 0; j < sweep->h.nrays; j++)
            {
                if ((ray = sweep->ray[j]) != NULL)
                {
                    if (first == 0)
                    {
                        var.nbins = ray->h.nbins;
                        var.gate_size = ray->h.gate_size;
                        first = 1;
                    }
                    rdr_stn_ray2grd(nsweep, ray, rl, elev, rdr_ht, seaecho);
                }
            }

            for (i = 0; i < 3; i++)
            {
                rl[0][i] = rl[1][i];
            }
            elev[0] = elev[1];

            nsweep++;
        }
    }

    /*------------------------------------------------------------*/
    /* grid data smoothing */

    if (var.effect == 'S') rdr_stn_grd_sm();

    return 0;
}

/*==================================================================*
 *  1 Ray -> Griding
 *==================================================================*/
int rdr_stn_ray2grd(nsweep, ray, rl, elev, rdr_ht, seaecho)
    int nsweep;
    Ray *ray;
    float rl[2][3], elev[2], rdr_ht, seaecho;
{
    double tn1, tn2;
    float  angle[3], hs[2];
    float  cc, cr, cg, cs, s0, s1, s, r, ec1;
    short  ec;
    int    area, ix, iy;
    int    i, j, k, i1, i2;

    /* ���� �� �������� */
    angle[1] = ray->h.azimuth;
    if (strcmp(var.data0,"IIA") == 0) angle[1] -= 7.53;
    if (angle[1] < 0.0) angle[1] += 360.0;

    area = ((int)angle[1]/45) % 8 + 1;

    if (angle[1] > 45.0)
    {
        angle[1] -= 45.0;
        angle[1] = fabs( angle[1] - ((int)angle[1]/90)*90 - 45.0 );
    }
    angle[0] = angle[1] - ray->h.beam_width - 0.1;
    angle[2] = angle[1] + ray->h.beam_width + 0.1;

    /* ��ǥ ��ȯ */
    cc = 2.0*(float)var.range/(float)var.size;
    cr = ray->h.range_bin1;
    cg = ray->h.gate_size;
    cs = cos(elev[1]*DEGRAD);
    s0 = 2.0 * RE * sin(elev[0]*DEGRAD);
    s1 = 2.0 * RE * sin(elev[1]*DEGRAD);

    tn1 = tan(angle[0] * DEGRAD);
    tn2 = tan(angle[2] * DEGRAD);

    for (j = 1; j <= var.size/2; j++)
    {
        i1 = (int)(tn1 * j + 0.95);
        i2 = (int)(tn2 * j - 0.05);

        if (i2 >= i1)
        {
            for (i = i1; i <= i2; i++)
            {
                s = cc * sqrt(i*i + j*j);               /* ������ �Ÿ� */
                r = s / cs;                             /* ����Ÿ� */
                k = (int)((r - cr)/cg);                 /* ������ ���ڼ� */

                if (k >= 0 && k < ray->h.nbins)
                {
                    switch (area)
                    {
                        case 1:  iy = 512 + j;  ix = 512 + i;  break;
                        case 2:  iy = 512 + i;  ix = 512 + j;  break;
                        case 3:  iy = 512 - i;  ix = 512 + j;  break;
                        case 4:  iy = 512 - j;  ix = 512 + i;  break;
                        case 5:  iy = 512 - j;  ix = 512 - i;  break;
                        case 6:  iy = 512 - i;  ix = 512 - j;  break;
                        case 7:  iy = 512 + i;  ix = 512 - j;  break;
                        case 8:  iy = 512 + j;  ix = 512 - i;
                    }
                    ec1 = ray->h.f(ray->range[k]);
                    if (ec1 > 200.0 || ec1 < -100)
                        ec = -31000;
                    else
                        ec = (short)(ec1*100);

                    if (nsweep == 0)
                    {
                        if (echo[0][iy][ix] < ec)
                        {
                            echo[0][iy][ix] = ec;
                            echo[1][iy][ix] = ec;
                            echo[2][iy][ix] = ec;
                            echo[3][iy][ix] = ec;
                        }
                    }
                    else if (nsweep > 0)
                    {
                        /* CMAX, BASE */
                        if (ec > -30000)
                        {
                            if (echo[3][iy][ix] < ec && echo[4][iy][ix] < ec) echo[4][iy][ix] = ec;
                            if (echo[3][iy][ix] < -30000 && echo[5][iy][ix] < -30000) echo[5][iy][ix] = ec;
                        }

                        /* CAPPI */
                        if (nsweep == 1 && r < seaecho && ec < 700)     /* �Ķ����� ���� */
                        {
                            echo[0][iy][ix] = ec;
                            echo[1][iy][ix] = ec;
                            echo[2][iy][ix] = ec;
                        }

                        if (r >= rl[1][0] && r <= rl[0][2])             /* ������ */
                        {
                            hs[0] = sqrt(r*r + RE*RE + r*s0) - RE;
                            hs[1] = sqrt(r*r + RE*RE + r*s1) - RE;
                        }

                        if (r < rl[1][0])               /* 1.0 km */
                            echo[0][iy][ix] = ec;
                        else if (r < rl[0][0])
                        {
                            if (ec > -10000)
                            {
                                if (echo[0][iy][ix] > -10000)
                                    echo[0][iy][ix] += (ec - echo[0][iy][ix])/(hs[1] - hs[0])*(hl[0] - hs[0]);
                                else
                                    echo[0][iy][ix] = ec;
                            }
                        }

                        if (r < rl[1][1])               /* 1.5 km */
                            echo[1][iy][ix] = ec;
                        else if (r < rl[0][1])
                        {
                            if (ec > -10000)
                            {
                                if (echo[1][iy][ix] > -10000)
                                    echo[1][iy][ix] += (ec - echo[1][iy][ix])/(hs[1] - hs[0])*(hl[1] - hs[0]);
                                else
                                    echo[1][iy][ix] = ec;
                            }
                        }

                        if (r < rl[1][2])               /* 2.0 km */
                            echo[2][iy][ix] = ec;
                        else if (r < rl[0][2])
                        {
                            if (ec > -10000)
                            {
                                if (echo[2][iy][ix] > -10000)
                                    echo[2][iy][ix] += (ec - echo[2][iy][ix])/(hs[1] - hs[0])*(hl[2] - hs[0]);
                                else
                                    echo[2][iy][ix] = ec;
                            }
                        }
                    }
                }
            }
        }
    }
    return 0;
}

/*==================================================================*
 *  Grid data Smoothing (by 1-2-1 Smoothing)
 *==================================================================*/
int rdr_stn_grd_sm()
{
    float  e[4], e1, e2;
    int    s1, s2;
    int    i, j, k, m;

    s1 = 512 - var.size/2;
    s2 = 512 + var.size/2;

    for (m = 0; m < 6; m++)
    {
        for (k = 0; k < 2; k++)
        {
            for (j = s1; j < s2; j++)
            {
                e1 = echo[m][j][s1];
                e[0] = echo[m][j][s1];
                e[1] = echo[m][j][s1+1];

                for (i = s1+1; i < s2; i++)
                {
                    e[2] = echo[m][j][i+1];
                    if (e[0] > -5000 && e[1] > -5000 && e[2] > -5000)
                        e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
                    else if (e[0] > -5000 && e[1] <= -5000 && e[2] > -5000)
                        e2 = (e[0] + e[2]) * 0.5;
                    else
                        e2 = e[1];

                    echo[m][j][i-1] = (short)e1;
                    e1 = e2;
                    e[0] = e[1];
                    e[1] = e[2];
                }
                echo[m][j][i-1] = (short)e1;
            }

            for (i = s1; i < s2; i++)
            {
                e1 = echo[m][s1][i];
                e[0] = echo[m][s1][i];
                e[1] = echo[m][s1+1][i];

                for (j = s1+1; j < s2; j++)
                {
                    e[2] = echo[m][j+1][i];
                    if (e[0] > -5000 && e[1] > -5000 && e[2] > -5000)
                        e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
                    else if (e[0] > -5000 && e[1] <= -5000 && e[2] > -5000)
                        e2 = (e[0] + e[2]) * 0.5;
                    else
                        e2 = e[1];

                    echo[m][j-1][i] = (short)e1;
                    e1 = e2;
                    e[0] = e[1];
                    e[1] = e[2];
                }
                echo[m][j-1][i] = (short)e1;
            }
        }
    }
    return 0;
}

/*********************************************************************
 *
 *  ���̴� ������ �̹��� ���� ���
 *
 *********************************************************************/
int rdr_stn_ppi_img_make()
{
    FILE   *fd;
    char   gname[64], dname[120];
    gdImagePtr im;
    int    color[256];
    float  range, zoom_rate;
    int    bgmap = 0, ovr = 1, code;
    int    i, j, k;

    /* image size */
    var.NI = var.size % MAXIMG;
    var.NJ = var.size % MAXIMG;
    var.GI = var.NI + LVL_pixel + LEG_pixel + var.NI*2 + 10;
    var.GJ = var.NJ + TTL_pixel + END_pixel + TTL_pixel + var.NJ;

    /* data display (0,0) point */
    nx1 = var.NI + LVL_pixel + LEG_pixel;
    nx2 = var.NI + LVL_pixel + LEG_pixel + var.NI + 10;
    ny1 = TTL_pixel;
    ny2 = TTL_pixel + var.NJ + END_pixel + TTL_pixel;

    /* gd alloc. */
    im = gdImageCreate(var.GI+1, var.GJ+1);

    /* color table */
    color_table(im, color);

    if (ovr) gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color[255]);

    /* data display */
    rdr_stn_ppi_disp(im, color);

    /* map draw */
    map_draw(im, color, 1000, 0.001*(float)var.range, (float)var.size/(2.0*0.001*var.range));

    /* ���ü� & ��輱 */
    range_disp(im, color);

    /* title display */
    title_disp(im, color);

    /* level table display */
    level_disp(im, color);

    /* file write */
    if ( rdr_stn_ppi_img_file(gname) < 0 )
    {
        if ( (fd = fopen(gname, "wb")) == NULL )
        {
            gdImageDestroy(im);
            return -1;
        }
        else
        {
            gdImagePng(im, fd);
            fclose(fd);
        }
    }
    gdImageDestroy(im);
    return 0;
}

/*==================================================================*
 *
 *  Radar grid data display
 *
 *==================================================================*/
int rdr_stn_ppi_disp(im, color)

    gdImagePtr im;
    int    color[];
{
    float  x, y, r, rmax = (float)var.size*0.5;
    int    i, j, i1, j1, y1;
    int    c1;

    /* ������ �ܰ�� ǥ���ϱ� ���Ͽ� �����Ǵ� DBZ �ܰ谪 ��� */
    if (var.ds1 == 0 || var.ds1 == 3)
    {
        for (i = 0; i <= 30; i++)
            dbz[i] = (10.0*log10(200.0) + 16.0*log10(rain[i])) * 100;
    }
    dbz_min = (10.0*log10(200.0) + 16.0*log10(rain_min)) * 100;
    printf("rain_min = %f, dbz_min = %f<br>\n", rain_min, 0.01*dbz_min);

    /* ���̴� �̹��� ���� */
    for (j = 0; j <= var.size; j++)
    {
        j1 = (MAXIMG - var.size)/2 + j;
        y = j - rmax;

        for (i = 0; i <= var.size ; i++)
        {
            i1 = (MAXIMG - var.size)/2 + i;
            x = i - rmax;
            y1 = var.NJ - j;

            r = sqrt(x*x + y*y);
            if (r <= rmax)
            {
                c1 = level_color(echo[0][j1][i1]);  gdImageSetPixel(im, i,     y1+ny1, color[c1]);
                c1 = level_color(echo[1][j1][i1]);  gdImageSetPixel(im, i+nx1, y1+ny1, color[c1]);
                c1 = level_color(echo[2][j1][i1]);  gdImageSetPixel(im, i+nx2, y1+ny1, color[c1]);

                c1 = level_color(echo[3][j1][i1]);  gdImageSetPixel(im, i,     y1+ny2, color[c1]);
                c1 = level_color(echo[4][j1][i1]);  gdImageSetPixel(im, i+nx1, y1+ny2, color[c1]);
                c1 = level_color(echo[5][j1][i1]);  gdImageSetPixel(im, i+nx2, y1+ny2, color[c1]);
            }
            else
            {
                gdImageSetPixel(im, i,     y1+ny1, color[253]);
                gdImageSetPixel(im, i+nx1, y1+ny1, color[253]);
                gdImageSetPixel(im, i+nx2, y1+ny1, color[253]);

                gdImageSetPixel(im, i,     y1+ny2, color[253]);
                gdImageSetPixel(im, i+nx1, y1+ny2, color[253]);
                gdImageSetPixel(im, i+nx2, y1+ny2, color[253]);
            }
        }
    }
    return 0;
}

/*==================================================================*
 *  Color of level
 *==================================================================*/
int level_color(short v)
{
    int  c = 31, i;

    if      (v < -31000) c = 253;		/* NO area */
    else if (v < dbz_min) c = 254;		/* NO data */
    else
    {
        if (v < dbz[0])
        {
            c = 33;
        }
        else
        {
            c = 31;
            for (i = 0; i <= 30; i++)
            {
                if (v < dbz[i])
                {
                    c = i;
                    break;
                }
            }
        }
    }
    return c;
}

/*==================================================================*
 *  GIS data display
 *===================================================================*/
int map_draw(im, color, mode, range, zoom_rate)

    gdImagePtr im;
    int    color[];
    int    mode;
    float  range;
    float  zoom_rate;
{
    FILE   *fd;
    char   fname[120];
    int    num, code, ibuf[2];
    float  buf[2];
    float  xo = 500.0 - range, yo = 500.0 - range;
    float  x1, y1, x2, y2, x, y;
    int    map_color;
    int    ix1, iy1, ix2, iy2;
    int    i, j, k = 0;

    /* Per Map data */
    for (j = 1; j <= 4; j++)
    {
        if (mode % 10 == 1)
        {
            if      (j == 1) map_color = color[252];    /* ������� */
            else if (j == 2) map_color = color[251];    /* ����     */
            else if (j == 3) map_color = color[250];    /* ����     */
            else if (j == 4) map_color = color[241];    /* �ؾȼ�   */

            sprintf(fname, "%s/RDR_%s_%d.bln", MAP_DIR, var.data0, j);
            if ( (fd = fopen(fname, "rb")) == NULL ) continue;

            while (fread(ibuf, sizeof(int), 2, fd) > 0)
            {
                num  = ibuf[0];
                code = ibuf[1];

                fread(buf, sizeof(float), 2, fd);
                ix1 = (int)(zoom_rate * ( buf[0] - xo ));
                iy1 = var.NJ - (int)(zoom_rate * ( buf[1] - yo ));

                for (i = 1; i < num; i++)
                {
                    fread(buf, sizeof(float), 2, fd);

                    ix2 = (int)(zoom_rate * ( buf[0] - xo ));
                    iy2 = var.NJ - (int)(zoom_rate * ( buf[1] - yo ));

                    if (ix1 >= 0 && ix1 <= var.NI && ix2 >= 0 && ix2 <= var.NI &&
                        iy1 >= 0 && iy1 <= var.NJ && iy2 >= 0 && iy2 <= var.NJ)
                    {
                        gdImageLine(im, ix1,     iy1+ny1, ix2,     iy2+ny1, map_color);
                        gdImageLine(im, ix1+nx1, iy1+ny1, ix2+nx1, iy2+ny1, map_color);
                        gdImageLine(im, ix1+nx2, iy1+ny1, ix2+nx2, iy2+ny1, map_color);

                        gdImageLine(im, ix1,     iy1+ny2, ix2,     iy2+ny2, map_color);
                        gdImageLine(im, ix1+nx1, iy1+ny2, ix2+nx1, iy2+ny2, map_color);
                        gdImageLine(im, ix1+nx2, iy1+ny2, ix2+nx2, iy2+ny2, map_color);
                    }

                    ix1 = ix2;
                    iy1 = iy2;
                }
            }
            fclose(fd);
        }
        mode /= 10;
    }
    return 0;
}

/*==================================================================*
 *  ���ü�
 *==================================================================*/
int range_disp(im, color)

    gdImagePtr im;
    int color[];
{
    int    xo = var.size/2, yo = var.size/2;    /* ���̴���ġ */
    int    x1, y1, x2, y2;
    float  r;
    int    i, j;

    /* 100km ���� �� */
    for (i = 100; i <= var.range*0.001; i += 100)
    {
        r = (float)(0.5*var.size*i)/(float)(0.001*var.range);

        x1 = xo + r;
        y1 = yo;

        for (j = 0; j <= 360; j++)
        {
            x2 = xo + r*cos((float)j*DEGRAD);
            y2 = yo + r*sin((float)j*DEGRAD);

            if (x2 >= 0 && x2 <= var.NI && y2 >= 0 && y2 <= var.NJ)
            {
                gdImageLine(im, x1,     y1+ny1, x2,     y2+ny1, color[250]);
                gdImageLine(im, x1+nx1, y1+ny1, x2+nx1, y2+ny1, color[250]);
                gdImageLine(im, x1+nx2, y1+ny1, x2+nx2, y2+ny1, color[250]);

                gdImageLine(im, x1,     y1+ny2, x2,     y2+ny2, color[250]);
                gdImageLine(im, x1+nx1, y1+ny2, x2+nx1, y2+ny2, color[250]);
                gdImageLine(im, x1+nx2, y1+ny2, x2+nx2, y2+ny2, color[250]);
            }

            x1 = x2;
            y1 = y2;
        }
    }

    /* ���̴� �ݰ� */
    r = var.size*0.5;

    x1 = xo + r;
    y1 = yo;

    for (j = 0; j <= 360; j++)
    {
        x2 = xo + r*cos((float)j*DEGRAD);
        y2 = yo + r*sin((float)j*DEGRAD);

        if (x2 >= 0 && x2 <= var.NI && y2 >= 0 && y2 <= var.NJ)
        {
            gdImageLine(im, x1,     y1+ny1, x2,     y2+ny1, color[245]);
            gdImageLine(im, x1+nx1, y1+ny1, x2+nx1, y2+ny1, color[245]);
            gdImageLine(im, x1+nx2, y1+ny1, x2+nx2, y2+ny1, color[245]);

            gdImageLine(im, x1,     y1+ny2, x2,     y2+ny2, color[245]);
            gdImageLine(im, x1+nx1, y1+ny2, x2+nx1, y2+ny2, color[245]);
            gdImageLine(im, x1+nx2, y1+ny2, x2+nx2, y2+ny2, color[245]);
        }

        x1 = x2;
        y1 = y2;
    }

    /* 45�� �������� ���м� */
    for (i = 0; i < 360; i += 45)
    {
        x1 = (int)( r * cos(i*DEGRAD) ) + xo;
        y1 = (int)( r * sin(i*DEGRAD) ) + yo;

        gdImageLine(im, xo,     yo+ny1, x1,     y1+ny1, color[250]);
        gdImageLine(im, xo+nx1, yo+ny1, x1+nx1, y1+ny1, color[250]);
        gdImageLine(im, xo+nx2, yo+ny1, x1+nx2, y1+ny1, color[250]);

        gdImageLine(im, xo,     yo+ny2, x1,     y1+ny2, color[250]);
        gdImageLine(im, xo+nx1, yo+ny2, x1+nx1, y1+ny2, color[250]);
        gdImageLine(im, xo+nx2, yo+ny2, x1+nx2, y1+ny2, color[250]);
    }

    /* ���̴� ���� ǥ�� */
    gdImageFilledRectangle(im, xo-3,     yo-3+ny1, xo+3,     yo+3+ny1, color[245]);
    gdImageFilledRectangle(im, xo-3+nx1, yo-3+ny1, xo+3+nx1, yo+3+ny1, color[245]);
    gdImageFilledRectangle(im, xo-3+nx2, yo-3+ny1, xo+3+nx2, yo+3+ny1, color[245]);

    gdImageFilledRectangle(im, xo-3,     yo-3+ny2, xo+3,     yo+3+ny2, color[245]);
    gdImageFilledRectangle(im, xo-3+nx1, yo-3+ny2, xo+3+nx1, yo+3+ny2, color[245]);
    gdImageFilledRectangle(im, xo-3+nx2, yo-3+ny2, xo+3+nx2, yo+3+ny2, color[245]);
    return 0;
}

/*==================================================================*
 *  TITLE display
 *==================================================================*/
int title_disp(im, color)

    gdImagePtr im;
    int color[];
{
    char  text[64], text2[32];
    int   YY, MM, DD, HH, min;
    int   x = 5, y = 0;

    seq2time(seq_uf+9*60, &YY, &MM, &DD, &HH, &min, 'm', 'n');

    /*------------------------------------------------------------------------*/

    gdImageFilledRectangle(im, 0,  0, var.GI, TTL_pixel, color[255]);

    if (var.NI < 290) y += 1;

    /* CAPPI (1.0km) */
    sprintf(text, "%s CAPPI 1.0km  %04d.%02d.%02d.%02d:%02d ", var.data0, YY, MM, DD, HH, min);

    if (var.NI < 290)
        gdImageString(im, gdFontSmall, x, y, (unsigned char *)text, color[240]);
    else
        gdImageString(im, gdFontLarge, x, y, (unsigned char *)text, color[240]);

    /* CAPPI (1.5km) */
    sprintf(text, "%s CAPPI 1.5km  %04d.%02d.%02d.%02d:%02d ", var.data0, YY, MM, DD, HH, min);

    if (var.NI < 290)
        gdImageString(im, gdFontSmall, x+nx1, y, (unsigned char *)text, color[240]);
    else
        gdImageString(im, gdFontLarge, x+nx1, y, (unsigned char *)text, color[240]);

    /* CAPPI (2.0km) */
    sprintf(text, "%s CAPPI 2.0km  %04d.%02d.%02d.%02d:%02d ", var.data0, YY, MM, DD, HH, min);

    if (var.NI < 290)
        gdImageString(im, gdFontSmall, x+nx2, y, (unsigned char *)text, color[240]);
    else
        gdImageString(im, gdFontLarge, x+nx2, y, (unsigned char *)text, color[240]);

    /*------------------------------------------------------------------------*/

    gdImageFilledRectangle(im, 0, ny2-TTL_pixel, var.GI, ny2, color[255]);

    y = ny2 - TTL_pixel;
    if (var.NI < 290) y += 1;

    /* PPI0 */
    sprintf(text, "%s PPI0 %04d.%02d.%02d.%02d:%02d ", var.data0, YY, MM, DD, HH, min);

    if (var.NI < 290)
        gdImageString(im, gdFontSmall, x, y, (unsigned char *)text, color[240]);
    else
        gdImageString(im, gdFontLarge, x, y, (unsigned char *)text, color[240]);

    /* CMAX */
    sprintf(text, "%s CMAX %04d.%02d.%02d.%02d:%02d ", var.data0, YY, MM, DD, HH, min);

    if (var.NI < 290)
        gdImageString(im, gdFontSmall, x+nx1, y, (unsigned char *)text, color[240]);
    else
        gdImageString(im, gdFontLarge, x+nx1, y, (unsigned char *)text, color[240]);

    /* BASE */
    sprintf(text, "%s BASE %04d.%02d.%02d.%02d:%02d ", var.data0, YY, MM, DD, HH, min);

    if (var.NI < 290)
        gdImageString(im, gdFontSmall, x+nx2, y, (unsigned char *)text, color[240]);
    else
        gdImageString(im, gdFontLarge, x+nx2, y, (unsigned char *)text, color[240]);

    return 0;
}

/*==================================================================*
 *  Level display
 *==================================================================*/
int level_disp(im, color)

    gdImagePtr im;
    int color[];
{
    char  text[126];
    float dy, y1, y2;
    int   i, j, jc, c;

    jc = 31;
    dy = (float)var.NJ / (float)(jc + 1);

    /* level color display */
    y2 = ny1 + var.NJ;

    for (j = 0; j <= jc; j++)
    {
        y1 = y2 - dy;

        gdImageFilledRectangle(im, var.NI, (int)y1, var.NI+LEG_pixel, (int)y2, color[j]);
        y2 = y1;
    }
    gdImageRectangle(im, var.NI, TTL_pixel, var.NI+LEG_pixel, TTL_pixel+var.NJ+END_pixel, color[240]);

    /* level value */
    gdImageFilledRectangle(im, var.NI+LEG_pixel+1, 0, var.NI+LVL_pixel+LEG_pixel, TTL_pixel+var.NJ+END_pixel, color[255]);

    for (j = 0; j < jc; j++)
    {
        y1 = ny1 + var.NJ - dy*((float)j+1.5);

        if (rain[j] < 10) sprintf(text, "%.1f", rain[j]);
        else              sprintf(text, "%d", (int)rain[j]);

        if (var.size < 310)
            gdImageString(im, gdFontTiny, var.NI+LEG_pixel+2, (int)y1, (unsigned char *)text, color[240]);
        else
            gdImageString(im, gdFontSmall, var.NI+LEG_pixel+2, (int)y1, (unsigned char *)text, color[240]);
    }

    /* unit */
    strcpy(text, "mm/h");
    gdImageString(im, gdFontSmall, var.NI+LEG_pixel+1, 1, (unsigned char *)text, color[240]);

    /* data information display */
    gdImageFilledRectangle(im, 0, var.NJ+TTL_pixel, var.NI, TTL_pixel+var.NJ+END_pixel, color[255]);

    if (var.size < 310)
        sprintf(text, "Width: %dm  Gates: %d#  Range: %dkm", var.gate_size, var.nbins, var.range/1000);
    else
        sprintf(text, "Gatewidth: %dm   Gates: %d#   Max.Range: %dkm", var.gate_size, var.nbins, var.range/1000);

    gdImageString(im, gdFontSmall, 8, var.NJ+TTL_pixel+2, (unsigned char *)text, color[240]);
    gdImageRectangle(im, 0, var.NJ+TTL_pixel, var.NI+LEG_pixel, TTL_pixel+var.NJ+END_pixel, color[240]);

    /* data display area box */
    gdImageRectangle(im, 0,   ny1, var.NI,     var.NJ+ny1, color[240]);
    gdImageRectangle(im, nx1, ny1, var.NI+nx1, var.NJ+ny1, color[240]);
    gdImageRectangle(im, nx2, ny1, var.NI+nx2, var.NJ+ny1, color[240]);

    gdImageRectangle(im, 0,   ny2, var.NI,     var.NJ+ny2, color[240]);
    gdImageRectangle(im, nx1, ny2, var.NI+nx1, var.NJ+ny2, color[240]);
    gdImageRectangle(im, nx2, ny2, var.NI+nx2, var.NJ+ny2, color[240]);

    return 0;
}

/*==================================================================*
 *  Color Table
 *==================================================================*/
int color_table(im, color)

    gdImagePtr im;
    int    color[];
{
    FILE  *fd;
    char  fname[120];
    int   num_colors;
    int   R, G, B, i;

    /*------------------------------------------------------------*/

    if      (var.color == 'E') sprintf(fname,"%s/color_rain_E.rgb", COLOR_DIR);
    else if (var.color == 'C') sprintf(fname,"%s/color_rain_C.rgb", COLOR_DIR);
    else                       sprintf(fname,"%s/color_rain_R.rgb", COLOR_DIR);

    fd = fopen(fname,"r");
    if (fd == NULL) return -1;

    fscanf(fd, "%d", &num_colors);

    for (i = 0; i < num_colors; i++)
    {
        fscanf(fd, "%d %d %d", &R, &G, &B);
        color[i] = gdImageColorAllocate(im, R, G, B);
    }
    fclose(fd);

    /*------------------------------------------------------------*/
    /* other color */

    color[240] = gdImageColorAllocate(im,   0,   0,   0);   /* ������   */
    color[241] = gdImageColorAllocate(im,  66,  66,  66);   /* �ؾȼ�   */
    color[245] = gdImageColorAllocate(im, 255,   0,   0);   /* ������   */
    color[246] = gdImageColorAllocate(im,   0,   0, 255);   /* �Ķ���   */
    color[247] = gdImageColorAllocate(im, 255, 255,   0);   /* �����   */
    color[248] = gdImageColorAllocate(im,   1,   1,   1);   /* �������� */
    color[249] = gdImageColorAllocate(im, 255,   0,   0);   /* AWS      */
    color[250] = gdImageColorAllocate(im, 128,  64,   0);   /* ����     */
    color[251] = gdImageColorAllocate(im,   0,   0, 128);   /* ����     */
    color[252] = gdImageColorAllocate(im, 128, 128, 128);   /* ������� */
    color[253] = gdImageColorAllocate(im, 200, 200, 200);   /* NO area  */
    color[254] = gdImageColorAllocate(im, 230, 230, 230);   /* NO data  */
    color[255] = gdImageColorAllocate(im, 255, 255, 255);   /* white    */

    return 0;
}
