/*************************************************************************/
/*                                                                       */
/*  ���û ���̴� 1�ð� �������ڷ� �ռ��� ���� ���α׷�                  */
/*                                                                       */
/*=======================================================================*/
/*                                                                       */
/*     o �ۼ��� : ����ȯ (1999. 10. 27)                                  */
/*     o ���� ... �������Ϸ� ���� (����ȯ, 2000.1.3)                     */
/*     o ���� ... NCOMIS�� �°� ����� (MAX. 2000.12.5)                  */
/*     o ���� ... ���������߰� (2010.05.12)                              */
/*                                                                       */
/*************************************************************************/
#include "/www/mis/cgi-src/include/input_head.h"
#include "/www/mis/cgi-src/include/input_var.h"
struct INPUT_VAR  var;
#include "/www/mis/cgi-src/include/input_print.h"

struct RADAR_SITE {
    int   stn_id;
    char  head[6];
    char  name[32];
    float lat;
    float lon;
    float height;
} site[12] = {
    {47116, "KWK",  "���ǻ�"      , 37.4419, 126.9661, 634.0},
    {47185, "CJU",  "���ְ���"    , 33.2833, 126.1667,  80.0},
    {47160, "PSN",  "�λ�"        , 35.1150, 129.0022, 540.0},
    {47105, "GNG",  "����"        , 37.8177, 128.8657,  98.0},
    {47106, "DNH",  "����"        , 37.5000, 129.1255,  48.0},
    {47144, "KSN",  "����"        , 36.0105, 126.7867, 230.0},
    {47920, "ISHI", "Ishigakijima", 24.4167, 124.0167, 533.5},
    {47937, "ITOK", "Naha"        , 26.1500, 127.7667, 208.3},
    {47909, "FUNC", "Naze"        , 28.3833, 129.5500, 317.2},
    {47869, "TANE", "Tanegashima" , 30.6333, 130.9833, 292.0},
    {47806, "SEFU", "Fukuoka"     , 33.4333, 130.3667, 984.2},
    {47791, "MISA", "Matsue"      , 35.5333, 133.1000, 55.47},
    {47705, "TOJI", "Fukui"       , 36.2333, 136.1500, 17.00}
};

#define RDR_SAV_DIR      "/ncomis/rdr/pcp"
#define RDR_KMA_STN_NUM  5
#define MI  600
#define MJ  750

struct COLOR HSL2RGB();
short  g[MJ][MI];           /* �ռ��ڷ� */
char   buf[512][512];       /* PCP data */

float  rain[33] = {0.04,  0.1,  0.2,  0.4,  0.6,  0.8,  1.0,  1.5,  2.0,  3.0,  4.0,
                    5.0,  6.0,  7.0,  8.0,  9.0, 10.0, 12.0, 14.0, 16.0, 18.0, 20.0,
                   25.0, 30.0, 35.0, 40.0, 50.0, 60.0, 70.0, 80.0, 90.0,100.0,110.0};


int main()
{
    int code;

    /*--------------------------------------------------------------*/
    /* initial */

    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(60);

    printf("HTTP/1.0 200 OK\n");
    printf("Server: Netscape-Enterprise/3.0\n");

    /*--------------------------------------------------------------*/
    /* user input decode */

    var.move  = 60;
    var.fmove = 17;

    if ( (code = Input()) < 0 ) {
        printf("Content-type: text/html\n\n");
        printf(" input variable error (%d)<p>\n", code);
        input_print();
        return -1;
    }

    /*--------------------------------------------------------------*/
    /* display */

    if      (var.mode == 'H') disp_html();
    else if (var.mode == 'I') disp_img();

    alarm(0);
    return 0;
}

/*********************************************************************
*
*  ����� ��û�� Ȯ��
*
*********************************************************************/
int Input()
{
    #include "/www/mis/cgi-src/include/input_decode.inc"

    var.rand = (iHH*100+imin)/10;

    return 0;
}

/*********************************************************************
*
*  IMAGE mode
*
*********************************************************************/
int disp_img()
{
    FILE  *fd;
    char   gname[120];
    int    code, len, c;

    if (rdr_kma_cmp_pcp_img_file(gname) < 0) {
        rdr_kma_cmp_pcp_img();
    }

    printf("Content-type: image/gif\n\n");

    strcpy(gname, "/www/mis/web");
    len = strlen(gname);
    rdr_kma_cmp_pcp_img_file(&gname[len]);
    if ( (fd = fopen(gname, "rb")) != NULL ) {
        c = getc(fd);
        while(c != EOF) {
            putchar(c);
            c = getc(fd);
        }
        fclose(fd);
    }
    return 0;
}

/*********************************************************************
*
*  HTML mode
*
*********************************************************************/
int disp_html()
{
    char  gname[48][120];
    int   n, i;

    printf("Content-type: text/html\n\n");

    /*--------------------------------------------------------------*/
    /* Image file make (include animation) */

    if (var.an_frn > 1) {
        var.seq = var.seq - (var.an_frn-1) * var.an_itv;
    }

    n = 0;
    for(i = 0; i < var.an_frn; i++)
    {
        seq2time(var.seq, &var.YY, &var.MM, &var.DD, &var.HH, &var.min, 'm', 'n');

        if (rdr_kma_cmp_pcp_img_file(gname[n]) < 0) {
            rdr_kma_cmp_pcp_img();
        }
        n++;
        if (var.an_frn > 1) var.seq += var.an_itv;
    }

    /*--------------------------------------------------------------*/
    /* head part */

    disp_html_head(n, gname);

    /*--------------------------------------------------------------*/
    /* body part */

    disp_html_body(n, gname);

    return 0;
}

/*====================================================================
*
*  HEAD ������ ���
*
*===================================================================*/
int disp_html_head(n, gname)

int   n;
char  gname[][120];
{
    int  YY, MM, DD, HH, min;
    int  i;

    seq2time(var.seq, &YY, &MM, &DD, &HH, &min, 'm', 'n');

    printf("<HTML>\n");
    printf("<HEAD>\n");

    /*--------------------------------------------------------------*/
    /* for auto reload */

    if (n == 1 && var.auto_man == 'a') {
        printf("<META http-equiv='Refresh' content=600>\n");
    }

    /*--------------------------------------------------------------*/
    /* Time sync. & animation */
    printf("<SCRIPT LANGUAGE='JavaScript'>\n");
    printf("<!--\n");
    printf("parent.menu.szTime = %04d%02d%02d%02d%02d\n",
            var.YY, var.MM, var.DD, var.HH, var.min);

    /*--------------------------------------------------------------*/
    /* for animation */

    if (n > 1 && var.mode == 'H') {
        printf("var counter = 0\n");
        printf("var animation = 1\n");
        printf("var timer\n");
        printf("var i, j\n");
        printf("var imgs = new Array()\n");
        printf("for(i = 0; i < %d; i++) {\n", n);
        printf("  imgs[i] = new Image()\n");
        printf("}\n\n");
        for(i = 0; i < n; i++) {
            printf("imgs[%d].src = '%s'\n", i, gname[i]);
        }
        printf("\n");
        printf("function animate() {\n");
        printf("  if (animation == 1) {\n");
        printf("    counter = (counter + 1) %% %d\n", n);
        printf("    document.anim.src = imgs[counter].src\n");
        printf("    timer = setTimeout('animate()', 1000)\n");
        printf("  }\n");
        printf("}\n\n");
        printf("function play() {\n");
        printf("  animation = 1\n");
        printf("  animate()\n");
        printf("}\n\n");
        printf("function stop() {\n");
        printf("  animation = 0\n");
        printf("}\n\n");
        printf("function moving(bf) {\n");
        printf("  counter = (counter + bf + %d) %% %d\n", n, n);
        printf("    document.anim.src = imgs[counter].src\n");
        printf("}\n\n");
    }
    printf("// -->\n");
    printf("</SCRIPT>\n");
    printf("</HEAD>\n");

    return 0;
}

/*====================================================================
*
*  BODY ������ ���
*
*===================================================================*/
int disp_html_body(n, gname)

int   n;
char  gname[][120];
{
    char  name[16];
    int   seq, seq1, seq2;
    int   YY, MM, DD, HH, min;
    int   time_auto;
    int   i;

    /* for animation */
    if (n > 1) {
        printf("<BODY bgcolor=#ffffff onload='animate()' TOPMARGIN=0 LEFTMARGIN=0 marginwidth=0 marginheight=0>\n");
        printf("<a href='javascript:play()'><img src='/images/play.gif' border=0></a>\n");
        printf("<a href='javascript:stop()'><img src='/images/stop.gif' border=0></a>\n");
        printf("<a href='javascript:moving(-1)'><img src='/images/back.gif' border=0></a>\n");
        printf("<a href='javascript:moving(1)'><img src='/images/for.gif' border=0></a><br>\n");
    } else {
        printf("<BODY bgcolor=#ffffff TOPMARGIN=0 LEFTMARGIN=10 marginwidth=0 marginheight=0>\n");
    }

    /* for auto & man (per 10mmin) */
    if (var.auto_man == 'a') {
        time_auto = 1000 * 60 * 10;
        printf("<SCRIPT LANGUAGE='JavaScript'>\n");
        printf("<!--\n");
        printf("  window.setTimeout('parent.menu.make_cmd();', %d)\n", time_auto);
        printf("// -->\n");
        printf("</SCRIPT>\n");
    }

    /* image */
    if (n > 0) printf("<img name='anim' src='%s' border=0>\n", gname[0]);

    printf("</BODY></HTML>\n");
    return 0;
}
    
/*********************************************************************
*
*  ���̴� �ռ��� ���� ����
*
*********************************************************************/
int rdr_kma_cmp_pcp_img()
{
    FILE   *fd;
    char   gname[120];
    int    YY, MM, DD, HH, min;
    struct lamc_parameter  map;
    gdImagePtr  im;
    int    color[256], c;
    int    len, i, j, k;

    /*--------------------------------------------------------*/
    /* �ռ��� MAP parameter */
    /*--------------------------------------------------------*/
    map.Re    = 6370.19584;
    map.grid  = 4.0/3.0;
    map.slat1 = 30.0;
    map.slat2 = 60.0;
    map.olon  = 125.0;
    map.olat  = 35.0;
    map.xo    = 160.0 / map.grid;
    map.yo    = 450.0 / map.grid;
    map.first = 0;

    /*--------------------------------------------------------*/
    /* �ռ��ڷ� ��� */
    /*--------------------------------------------------------*/

    /* cmp data initialize */
    for(j = 0; j < MJ; j++) {
    for(i = 0; i < MI; i++) {
        g[j][i] = -999;
    }
    }

    /* Per radar site */
    for(k = 0; k < RDR_KMA_STN_NUM; k++) {
        rdr_kma_cmp_pcp_make(map, k);
    }

    /* composed data smoothing */
    rdr_kma_cmp_pcp_sm();

    /*--------------------------------------------------------*/
    /* �ռ��̹��� ���� */
    /*--------------------------------------------------------*/
    var.NI = MI;
    var.NJ = MJ;
    var.GI = var.NI + LEG_pixel + LVL_pixel;
    var.GJ = var.NJ + TTL_pixel;

    im = gdImageCreate(var.GI+1, var.GJ+1);
    color_table(im, color);

    rdr_kma_cmp_pcp_disp(im, color, map);

    /*--------------------------------------------------------*/
    /* �̹��� ���� ���� */
    /*--------------------------------------------------------*/
    strcpy(gname, "/www/mis/web");
    len = strlen(gname);
    rdr_kma_cmp_pcp_img_file(&gname[len]);

    if ( (fd = fopen(gname, "wb")) == NULL ) {
        gdImageDestroy(im);
        return -1;
    } else {
        gdImagePng(im, fd);
        fclose(fd);
    }
    gdImageDestroy(im);

    return 0;
}

/*====================================================================
*
*  Color Table �ۼ�
*
*===================================================================*/
int color_table(im, color)

gdImagePtr im;
int color[];
{
    struct COLOR rgb;
    int    H, S = 255, L = 127;
    float  center;
    int    i, j, k, c;

    /*------------------------------------------------------------*/
    /* data level color */

    color[0] = gdImageColorAllocate(im, 230, 230, 230);
    k = 0;

    for(j = 0; j < 6; j++)
    {
        H = (int)(256.0/6.0 * (float)(j + 1));
        if (j == 3) center = 2.0;
        else        center = 1.7;

        for(i = 0; i < 5; i++)
        {
            L = (int)(127.0 + (center - (float)i)*30.0);
            if (i == 3)      L -= 10;
            else if (i == 2) L -= 15;
            else if (i == 1) L += 20;
            else if (i == 0) L += 30;
            rgb = HSL2RGB(H, S, L);
            color[++k] = gdImageColorAllocate(im, rgb.R, rgb.G, rgb.B);
        }
    }
    color[++k] = gdImageColorAllocate(im, 40, 40, 40);

    /*------------------------------------------------------------*/
    /* other color */

    color[240] = gdImageColorAllocate(im,   0,   0,   0);   /* Black      */
    color[246] = gdImageColorAllocate(im, 160, 160, 160);   /* Wind area  */
    color[247] = gdImageColorAllocate(im, 255, 255,   0);   /* �����     */
    color[248] = gdImageColorAllocate(im,   1,   1,   1);   /* ��������   */
    color[249] = gdImageColorAllocate(im, 255,   0,   0);   /* AWS        */
    color[250] = gdImageColorAllocate(im, 128,  64,   0);   /* ����       */
    color[251] = gdImageColorAllocate(im,   0,   0, 128);   /* ����       */
    color[252] = gdImageColorAllocate(im, 128, 128, 128);   /* �������   */
    color[253] = gdImageColorAllocate(im,  80,  80,  80);   /* blank      */
    color[254] = gdImageColorAllocate(im, 200, 200, 200);   /* background */
    color[255] = gdImageColorAllocate(im, 255, 255, 255);   /* white      */
    return 0;
}

/*********************************************************************
*
*  ���ŵ� ���̴��ڷ� �ռ�
*
*********************************************************************/
int rdr_kma_cmp_pcp_make(map, k)

struct lamc_parameter  map;
int    k;
{
    FILE   *fd;
    char   fname[120];
    struct azed_parameter pcp;
    float  lon, lat, x1, y1, x2, y2;
    float  xa[4], ya[4];
    int    ix2, iy2;
    int    v;
    int    i, j, i1, j1;
    float  b;

    /* Map parameter */
    pcp.Re    = 6370.19584;
    pcp.grid  = 1.0;
    pcp.slon  = site[k].lon;
    pcp.slat  = site[k].lat;
    pcp.olon  = site[k].lon;
    pcp.olat  = site[k].lat;
    pcp.xo    = 250.0 / pcp.grid;
    pcp.yo    = 250.0 / pcp.grid;
    pcp.first = 0;

    /* ������ȯ ��� ��� */
    x1 = 0.0;
    y1 = 0.0;
    azedproj(&lon, &lat, &x1, &y1, 1, pcp);
    lamcproj(&lon, &lat, &xa[0], &ya[0], 0, map);

    x1 = (pcp.xo)*2;
    y1 = 0.0;
    azedproj(&lon, &lat, &x1, &y1, 1, pcp);
    lamcproj(&lon, &lat, &x1, &y1, 0, map);
    xa[1] = (x1 - xa[0])/pcp.xo*0.5;
    ya[1] = (y1 - ya[0])/pcp.xo*0.5;

    x1 = 0.0;
    y1 = (pcp.yo)*2;
    azedproj(&lon, &lat, &x1, &y1, 1, pcp);
    lamcproj(&lon, &lat, &x1, &y1, 0, map);
    xa[2] = (x1 - xa[0])/pcp.yo*0.5;
    ya[2] = (y1 - ya[0])/pcp.yo*0.5;

    x1 = (pcp.xo)*2;
    y1 = (pcp.yo)*2;
    azedproj(&lon, &lat, &x1, &y1, 1, pcp);
    lamcproj(&lon, &lat, &x1, &y1, 0, map);
    xa[3] = (x1 - xa[0] - xa[1]*pcp.xo*2.0 - xa[2]*pcp.yo*2)/(pcp.xo*pcp.yo*4.0);
    ya[3] = (y1 - ya[0] - ya[1]*pcp.xo*2.0 - ya[2]*pcp.yo*2)/(pcp.xo*pcp.yo*4.0);

    /* data file open */
    strcpy(var.data0, site[k].head);
    if ( rdr_kma_stn_pcp_file(1) < 0 ) return -1;

    /* map conversion */
    for(j = 0; j < 512; j++)
    {
        for(i = 0; i < 512; i++)
        {
            if (buf[j][i] < 40) b = 0.25 * (float)buf[j][i];
            else                b = (float)buf[j][i] - 30.0;

            x2 = xa[0] + xa[1]*i + xa[2]*j + xa[3]*i*j;
            y2 = ya[0] + ya[1]*i + ya[2]*j + ya[3]*i*j;
            i1 = (int)x2;
            j1 = (int)y2;

            if (i1 >= 0 && i1 < MI && j1 >= 0 && j1 < MJ) {
                if (g[j1][i1] < 0 || g[j1][i1] < (int)(b*10.0)) {
                    if (b < 225) g[j1][i1] = (short)(b*10.0);
/*
                    if (b < 254) g[j1][i1] = (short)(b*10.0);
*/
                }
            }
        }
    }

    return 0;
}

/*====================================================================
*
*  �ռ��� ���̴��ڷ� Smoothing
*
*===================================================================*/
int rdr_kma_cmp_pcp_sm()
{
    int    g1, g2, g3;
    float  d1, d2;
    int    i, j;

    for(j = 0; j < MJ; j++) {
        d1 = -999;
        for(i = 1; i < MI-1; i++) {
            g1 = g[j][i-1];
            g2 = g[j][i];
            g3 = g[j][i+1];
            if (g1 >= 0 && g2 >= 0  && g3 >= 0) {
                d2 = (float)(g1 + 2*g2 + g3) * 0.25;
            } else {
                d2 = (float)g2;
            }
            g[j][i-1] = (short)d1;
            d1 = d2;
        }
    }

    for(i = 0; i < MI; i++) {
        d1 = -999;
        for(j = 1; j < MJ-1; j++) {
            g1 = g[j-1][i];
            g2 = g[j][i];
            g3 = g[j+1][i];
            if (g1 >= 0 && g2 >= 0  && g3 >= 0) {
                d2 = (float)(g1 + 2*g2 + g3) * 0.25;
            } else {
                d2 = (float)g2;
            }
            g[j-1][i] = (short)d1;
            d1 = d2;
        }
    }
    return 0;
}

/*********************************************************************
*
*  �ռ��ڷ� �̹��� ó��
*
*********************************************************************/
int rdr_kma_cmp_pcp_disp(im, color, map)

gdImagePtr im;
int    color[];
struct lamc_parameter  map;
{
    FILE   *fd;
    char   fname[120];
    float  lon, lat, x1, y1, x2, y2;
    int    ix1, iy1, ix2, iy2;
    int    ibuf[2], num, code;
    float  buf[2];
    float  v;
    int    c;
    int    i, j, k, i1;

    /* data display */
    for(j = 0; j < MJ; j++) {
    for(i = 0; i < MI; i++) {
        v = 0.1*(float)g[j][i];
        c = level_color(v);
        gdImageSetPixel(im, i, var.GJ-j, color[c]);
    }
    }

    /* map display */
    fd = fopen("/www/mis/cgi-bin/REF/BLN/RDR_pcp.bln", "rb");

    while( fread(ibuf, sizeof(int), 2, fd) > 0 )
    {
        num  = ibuf[0];
        code = ibuf[1];

        fread(buf, sizeof(float), 2, fd);
        ix1 = (int)(buf[0] + 0.5);
        iy1 = var.GJ - (int)(buf[1] + 0.5);

        for(i = 1; i < num; i++)
        {
            fread(buf, sizeof(float), 2, fd);

            ix2 = (int)(buf[0] + 0.5);
            iy2 = var.GJ - (int)(buf[1] + 0.5);
            gdImageLine(im, ix1, iy1, ix2, iy2, color[240]);

            ix1 = ix2;
            iy1 = iy2;
        }
    }
    fclose(fd);

    /* ���浵�� */
    /*latlon_disp(im, color, map);*/

    /* ���� ǥ�� */
    for(k = 0; k < RDR_KMA_STN_NUM; k++)
    {
        strcpy(var.data0, site[k].head);
        if (rdr_kma_stn_pcp_file(0) >= 0)
        {
            lat = site[k].lat;
            lon = site[k].lon;
            lamcproj(&lon, &lat, &x2, &y2, 0, map);
            y2 = var.GJ - y2;
            gdImageFilledRectangle(im, (int)x2-3, (int)y2-3, (int)x2+3, (int)y2+3, color[249]);
        }
    }

    /* title display */
    title_disp(im, color);

    /* level display */
    level_disp(im, color);

    return 0;
}

/*==================================================================*
*  data --> level color
*===================================================================*/
int level_color(data)

float data;
{
    int  c = 31;
    int  i;

    if (data < -900) {
        data = 253;
    } else {
        for(i = 1; i <= 31; i++) {
            if (data < rain[i]) {
                c = i-1;
                break;
            }
        }
    }
    if (data > 224.0) c = 252;
    return c;
}

/*====================================================================
*
*  TITLE display
*
*===================================================================*/
int title_disp(im, color)

gdImagePtr im;
int color[];
{
    char  text[120];

    gdImageFilledRectangle(im, 0, 0, var.NI+LEG_pixel, TTL_pixel, color[255]);
    gdImageLine(im, 0, TTL_pixel, var.NI+8, TTL_pixel, color[240]);

    sprintf(text, "[ RADAR ] PCP  %04d.%02d.%02d.%02d:%02d  <1h rain>",
                   var.YY, var.MM, var.DD, var.HH, var.min);

    if (var.NI < 320)
        gdImageString(im, gdFontSmall, 5, 1, (unsigned char *)text, color[240]);
    else
        gdImageString(im, gdFontLarge, 5, 0, (unsigned char *)text, color[240]);

    return 0;
}

/*====================================================================
*
*  LEVEL display
*
*===================================================================*/
int level_disp(im, color)

gdImagePtr im;
int color[];
{
    char  level_text[16];
    float dy, y1, y2;
    int   j;

    dy = (float)(var.NJ) / 32.0;

    /*--------------------------------------------------------------*/
    /* ����ǥ */

    y2 = var.GJ;
    for(j = 0; j <= 31; j++)
    {
        y1 = y2 - dy;
        gdImageFilledRectangle(im, var.NI, (int)y1, var.NI+LEG_pixel, (int)y2, color[j]);
        gdImageLine(im, var.NI, (int)y2, var.NI+LEG_pixel, (int)y2, color[240]);
        y2 = y1;
    }
    gdImageFilledRectangle(im, var.NI+LEG_pixel+1, 0, var.GI, var.GJ, color[255]);
    gdImageRectangle(im, 0, TTL_pixel, var.NI, var.GJ, color[240]);
    gdImageRectangle(im, 0, TTL_pixel, var.NI+LEG_pixel, var.GJ, color[240]);

    /*--------------------------------------------------------------*/
    /* ���� */

    for(j = 0; j < 31; j++)
    {
        if (rain[j+1] < 10) sprintf(level_text, "%.1f", rain[j+1]);
        else                sprintf(level_text, "%d", (int)rain[j+1]);

        y1 = var.GJ - (int)(dy * (float)(j+1.5));
        gdImageString(im, gdFontSmall, var.NI+LEG_pixel+2, (int)y1, (unsigned char *)level_text, color[240]);
    }

    /*--------------------------------------------------------------*/
    /* ���� */

    gdImageString(im, gdFontMediumBold, var.NI+LEG_pixel+2, 1, (unsigned char *)"mm", color[240]);

    return 0;
}

/*====================================================================
*
*  ���浵�� display
*
*===================================================================*/
int latlon_disp(im, color, map)

gdImagePtr im;
int    color[];
struct lamc_parameter  map;
{
    int    lon, lat;
    float  alon1, alat1, alon2, alat2;
    float  x1, y1, x2, y2;

    /* �浵�� */
    alat1 = 20.0;
    alat2 = 40.0;

    for(lon = 118; lon < 146; lon += 2) {
        alon1 = (float)lon;
        lamcproj(&alon1, &alat1, &x1, &y1, 0, map);
        lamcproj(&alon1, &alat2, &x2, &y2, 0, map);
        gdImageLine(im, (int)x1, var.GJ-(int)y1, (int)x2, var.GJ-(int)y2, color[245]);
    }

    /* ������ */
    for(lat = 20; lat < 40; lat += 2) {
        alat1 = (float)lat;
        alon1 = 118.0;
        lamcproj(&alon1, &alat1, &x1, &y1, 0, map);

        for(lon = 1180; lon < 1460; lon++) {
            alon2 = 0.1 * (float)lon;
            lamcproj(&alon2, &alat1, &x2, &y2, 0, map);
            gdImageLine(im, (int)x1, var.GJ-(int)y1, (int)x2, var.GJ-(int)y2, color[245]);
            x1 = x2;
            y1 = y2;
        }
    }

    /* ���浵�� */
    gdImageString(im, gdFontLarge,  30, var.GJ-17, (unsigned char *)"122E", color[246]);
    gdImageString(im, gdFontLarge, 120, var.GJ-17, (unsigned char *)"124E", color[246]);
    gdImageString(im, gdFontLarge, 210, var.GJ-17, (unsigned char *)"126E", color[246]);
    gdImageString(im, gdFontLarge, 300, var.GJ-17, (unsigned char *)"128E", color[246]);
    gdImageString(im, gdFontLarge, 380, var.GJ-17, (unsigned char *)"130E", color[246]);
    gdImageString(im, gdFontLarge, 470, var.GJ-17, (unsigned char *)"132E", color[246]);
    gdImageString(im, gdFontLarge, 550, var.GJ-17, (unsigned char *)"134E", color[246]);
    gdImageString(im, gdFontLarge, 640, var.GJ-17, (unsigned char *)"136E", color[246]);

    gdImageString(im, gdFontLarge, var.NI-25,  40, (unsigned char *)"38N", color[246]);
    gdImageString(im, gdFontLarge, var.NI-25, 130, (unsigned char *)"36N", color[246]);
    gdImageString(im, gdFontLarge, var.NI-25, 220, (unsigned char *)"34N", color[246]);
    gdImageString(im, gdFontLarge, var.NI-25, 310, (unsigned char *)"32N", color[246]);
    gdImageString(im, gdFontLarge, var.NI-25, 400, (unsigned char *)"30N", color[246]);
    gdImageString(im, gdFontLarge, var.NI-25, 490, (unsigned char *)"28N", color[246]);
    gdImageString(im, gdFontLarge, var.NI-25, 580, (unsigned char *)"26N", color[246]);
    gdImageString(im, gdFontLarge, var.NI-25, 670, (unsigned char *)"24N", color[246]);
    gdImageString(im, gdFontLarge, var.NI-25, 760, (unsigned char *)"22N", color[246]);

    return 0;
}

/*********************************************************************
*
*  �̹��� ���� ���翩�� �� �����̸� ��ȯ
*
*********************************************************************/
int rdr_kma_cmp_pcp_img_file(fname)

char   *fname;
{
    struct stat st;
    char   *p;
    int    code = 0;

    sprintf(fname, "/www/mis/web/tmp/rdr/RDR_KMA_CMP_PCP_%04d%02d%02d_%02d%02d_%c%c%c_%s_%d_%d.png",
                    var.YY, var.MM, var.DD, var.HH, var.min,
                    var.color, var.effect, var.level[0], var.overlay, var.size, var.rand);

    if  (stat(fname, &st) < 0) code = -1;
    else if (st.st_size < 512) code = -2;

    p = strstr(fname, "/tmp/");
    strcpy(fname, p);

    return code;
}

/*********************************************************************
*
*  �ڷ����� ���翩�� �� �����̸� ��ȯ
*
*********************************************************************/
int rdr_kma_stn_pcp_file(mode)

int mode;
{
    FILE   *fd;
    struct stat st;
    int    code = 0;

    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_%04d%02d%02d%02d00.pcp.gz",
                        RDR_SAV_DIR, var.YY, var.MM, var.DD,
                        var.data0, var.YY, var.MM, var.DD, var.HH);

    if      (stat(var.fname, &st) < 0) code = -1;
    else if (st.st_size < 32) code = -2;

    if (code == 0 && mode == 1) {
        fd = gzopen(var.fname, "rb");
        if (fd != NULL) {
            gzread(fd, buf, 512*512);
            gzclose(fd);
        } else {
            code = -3;
        }
    }
    return code;
}
