/*********************************************************************/
/*                                                                   */
/*  ���û ���̴��ڷ� �̹��� ó���� ����� �����ڷ� ���� ���α׷�    */
/*                                                                   */
/*     o �� ���̴��������� ����                                      */
/*     o ����ڷ� ���丮 : /www/cgi-bin/ref/BLN                    */
/*                                                                   */
/*===================================================================*/
/*                                                                   */
/*     o �ۼ��� : ����ȯ (1999. 3)                                   */
/*     o ������ : �̱�� (2008.7.21) - �̰������̴� �����̵�         */
/*     o ������ : �̺��� (2010.5. 3) - �������̴� �����߰�           */
/*                                                                   */
/*********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>
#include "/www/mis/cgi-src/gis/program/map_ini.h"
#include "/www/mis/cgi-src/include/nrutil.h"

#define NUM_RDR  11

main(int argc, char *argv[])
{
    char   stn[8];
    float  lon, lat;
    int    i, j, k = -1;

    if (argc < 2)
    {
        printf("[using] rdr_kma_stn_map <�����ڵ�>\n");
        return 0;
    }
    sprintf(stn, "%s", argv[1]);

    if ( rdr_position(stn, &lon, &lat) == 0 )
    {
        printf(" %s : %f , %f\n", stn, lon, lat);
        rdr_kma_stn_map(stn, lon, lat);
    }
    else
    {
        printf("%s �� �ش�Ǵ� ��������(���浵)�� �����ϴ�.\n", stn);
        return 0;
    }
    return 0;
}

/*===================================================================*
 *
 *  ���̴� ������ ���浵
 *
 *===================================================================*/
int rdr_position (stn_code, lon, lat)
    char  *stn_code;
    float *lon, *lat;
{
    if (strcmp(stn_code, "KWK") == 0)
    {
        *lon = 126.0 + (57.0 + 58.0/60.0) / 60.0;
        *lat =  37.0 + (26.0 + 31.0/60.0) / 60.0;
    }
    else if (strcmp(stn_code, "KSN") == 0)
    {
        *lon = 126.0 + (47.0 + 12.0/60.0) / 60.0;
        *lat =  36.0 + ( 0.0 + 38.0/60.0) / 60.0;
    }
    else if (strcmp(stn_code, "PSN") == 0)
    {
        *lon = 129.0 + ( 0.0 +  8.0/60.0) / 60.0;
        *lat =  35.0 + ( 6.0 + 54.0/60.0) / 60.0;
    }
    else if (strcmp(stn_code, "CJU") == 0)
    {
        *lon = 126.0 + ( 9.0 + 54.0/60.0) / 60.0;
        *lat =  33.0 + (17.0 + 30.0/60.0) / 60.0;
    }
	//�������̴� ���� �߰�
    else if (strcmp(stn_code, "GNG") == 0)
    {
        *lon = 128.865708;
        *lat = 37.817689;
    }
    else if (strcmp(stn_code, "DNH") == 0)
    {
        *lon = 129.0 + ( 7.0 + 32.0/60.0) / 60.0;
        *lat =  37.0 + (30.0 +  0.0/60.0) / 60.0;
    }
    else if (strcmp(stn_code, "BRI") == 0)
    {
        *lon = 124.0 + (38.0 + 20.0/60.0) / 60.0;
        *lat =  37.0 + (57.0 + 31.0/60.0) / 60.0;
    }
    else if (strcmp(stn_code, "IIA") == 0)
    {
        *lon = 126.0 + (21.0 + 48.0/60.0) / 60.0;
        *lat =  37.0 + (27.0 + 53.0/60.0) / 60.0;
    }
    else if (strcmp(stn_code, "SCN") == 0)
    {
        *lon = 128.0 + ( 4.0 + 49.0/60.0) / 60.0;
        *lat =  35.0 + ( 5.0 + 12.0/60.0) / 60.0;
    }
    else if (strcmp(stn_code, "TAG") == 0)
    {
        *lon = 128.0 + (39.0 + 16.0/60.0) / 60.0;
        *lat =  35.0 + (54.0 + 23.0/60.0) / 60.0;
    }
    else if (strcmp(stn_code, "WNJ") == 0)
    {
        *lon = 127.0 + (58.0 + 10.0/60.0) / 60.0;
        *lat =  37.0 + (25.0 + 54.0/60.0) / 60.0;
    }
    else if (strcmp(stn_code, "YCN") == 0)
    {
        *lon = 128.0 + (21.0 + 15.0/60.0) / 60.0;
        *lat =  36.0 + (37.0 + 32.0/60.0) / 60.0;
    }
    else if (strcmp(stn_code, "KWJ") == 0)
    {
        *lon = 126.0 + (48.0 + 11.0/60.0) / 60.0;
        *lat =  35.0 + (07.0 + 47.0/60.0) / 60.0;
    }
    else if (strcmp(stn_code, "RKJK") == 0)
    {
        *lon = 126.0 + (37.0 + 30.0/60.0) / 60.0;
        *lat =  35.0 + (55.0 + 15.0/60.0) / 60.0;
    }
    else if (strcmp(stn_code, "RKSG") == 0)
    {
/** ����: ������     	
        *lon = 127.0 + (01.0 + 16.0/60.0) / 60.0;
        *lat =  36.0 + (57.0 + 21.0/60.0) / 60.0;
**/
		/* ���� : 2007.11.15 ���� */
        *lon = 127.28556111;
        *lat = 37.20756944;
    }
    else if (strcmp(stn_code, "GDK") == 0)
    {
        *lon = 127.43354;
        *lat =  38.117393;
    }
    else if (strcmp(stn_code, "MYN") == 0)
    {
        *lon = 128.0 + (59.0 + 59.0/60.0) / 60.0;
        *lat =  36.0 + (10.0 + 35.0/60.0) / 60.0;
    }
    else if (strcmp(stn_code, "MET") == 0)
    {
        *lon = 126.0 + (17.0 +  6.0/60.0) / 60.0;
        *lat =  35.0 + ( 5.0 + 37.0/60.0) / 60.0;
    }
    else if (strcmp(stn_code, "SSP") == 0)
    {
        *lon = 126.0 + (52.0 + 47.0/60.0) / 60.0;
        *lat =  33.0 + (23.0 + 13.0/60.0) / 60.0;
    }
    else if (strcmp(stn_code, "GSN") == 0)
    {
        *lon = 126.0 + ( 9.0 + 46.0/60.0) / 60.0;
        *lat =  33.0 + (15.0 + 39.0/60.0) / 60.0;
    }
    else
    {
        return -1;
    }
    return 0;
}

/*********************************************************************
 *
 *  ������ ���̴� ��� �����ڷ� ����
 *
 *********************************************************************/
int rdr_kma_stn_map(stn_code, lon, lat)
    char   *stn_code;
    float  lon, lat;
{
    FILE  *fd, *fg;
    char   fname[16][120];
    struct azed_parameter  map;
    float  xm, ym, sx, sy;
    int    n;

    /* MAP file */
    strcpy(fname[0], "/DATA/GIS/MAP/govern_map.dat");
    strcpy(fname[1], "/DATA/GIS/MAP/river_map.dat");
    strcpy(fname[2], "/DATA/GIS/MAP/highway_map.dat");
    strcpy(fname[3], "/DATA/GIS/MAP/fine_kr.dat");
    strcpy(fname[4], "/DATA/GIS/MAP/global_map.dat");

    /* MAP parameter */
    map.Re    = 6370.19584;
    map.grid  = 1.0;
    map.slon  = lon;
    map.slat  = lat;
    map.olon = map.slon;
    map.olat = map.slat;
    map.xo = 500.0;
    map.yo = 500.0;
    map.first = 0;
    xm = 1000.0;
    ym = 1000.0;

    /* Per map file */
    for (n = 0; n < 4; n++)
    {
// �ӽ÷� �����ؾ��� �ʿ� ���� : �����Ϸ� ���� ����    	
//        sprintf(fname[15], "/www/mis/cgi-bin/ref/BLN/RDR_%s_%d.bln", stn_code, n+1);
//        sprintf(fname[15], "/www/mis/web/cgi-src/rdr/bln/RDR_%s_%d.bln", stn_code, n+1);
// ==> �̰��� ����->���� ������ ���� �ӽ� ���� ������ ���� (2008.7.21 �̱��)
//        sprintf(fname[15], "/www/mis/cgi-src/rdr/bln/RDR_%s_%d_20071115.bln", stn_code, n+1);
        sprintf(fname[15], "/www/mis/cgi-src/rdr/bln/RDR_%s_%d_20100428.bln", stn_code, n+1);
        fd = fopen(fname[15], "wb");
        printf("%s\n", fname[n]);
        bln_file(fd, n, fname[n], map, xm, ym);
        fclose(fd);
    }
    return 0;
}

/*===================================================================*
 *
 *  �����ڷ� ����
 *
 *===================================================================*/
int bln_file(fd, ncode, fname, map, xm, ym)
    FILE   *fd;                     /* output file pointer        */
    int    ncode;                   /* used input map data number */
    char   *fname;                  /* used input map file name   */
    struct azed_parameter  map;     /* map parameter (for site)   */
    float  xm, ym;                  /* maximum area               */
{
    FILE   *fg;
    int    n, num, code;
    char   scode[16];
    float  *vx, *vy;
    float  lon, lat, x1, y1, x2, y2, x, y;
    float  buf[2];
    int    ibuf[2];
    int    i, j, k;
    int    now = 0;
    int    tn = 0;

    fg = fopen(fname, "r");
    if (fg == NULL) return -1;

    while (fscanf(fg, "%d %s", &num, &scode) != EOF)
    {
        if (ncode != 1)
            code = atoi(scode);
        else
            code = 3;

        tn += num + 1;
        /*printf(" --- %d %d %d\n", num, code, tn);*/
        if (num <= 0) break;
        vx = vector(0, num);
        vy = vector(0, num);
        k = 0;

        fscanf(fg, "%f %f", &lon, &lat);
        azedproj(&lon, &lat, &x1, &y1, 0, map);
        if (x1 >= 0.0 && x1 <= xm && y1 >= 0.0 && y1 <= ym)
        {
            vx[0] = x1;
            vy[0] = y1;
            k++;
            now = 1;
        }
        else
        {
            now = 0;
        }

        for (j = 1; j < num; j++)
        {
            fscanf(fg, "%f %f", &lon, &lat);
            if (ncode == 3 && code == 3) continue;
            azedproj(&lon, &lat, &x2, &y2, 0, map);

            if (x2 >= 0.0 && x2 <= xm && y2 >= 0.0 && y2 <= ym)
            {
                if (now == 0)
                {
                    CrossPoint(x1, y1, x2, y2, xm, ym, &x, &y);
                    x1 = x;
                    y1 = y;
                    vx[0] = x1;
                    vy[0] = y1;
                    k = 1;
                    now = 1;
                }
                vx[k] = x2;
                vy[k] = y2;
                k++;
            }
            else
            {
                if (now == 1)
                {
                    CrossPoint(x1, y1, x2, y2, xm, ym, &x, &y);
                    vx[k] = x2;
                    vy[k] = y2;
                    k++;
                    ibuf[0] = k;
                    ibuf[1] = code;
                    fwrite(ibuf, sizeof(int), 2, fd);

                    for (i = 0; i < k; i++)
                    {
                        buf[0] = vx[i];
                        buf[1] = vy[i];
                        fwrite(buf, sizeof(float), 2, fd);
                    }
                    k = 0;
                    now = 0;
                }
            }
            x1 = x2;
            y1 = y2;
        }

        if ( k > 1 )
        {
            ibuf[0] = k;
            ibuf[1] = code;
            fwrite(ibuf, sizeof(int), 2, fd);

            for (i = 0; i < k; i++)
            {
                buf[0] = vx[i];
                buf[1] = vy[i];
                fwrite(buf, sizeof(float), 2, fd);
            }
            k = 0;
        }
        free_vector(vy, 0, num);
        free_vector(vx, 0, num);
    }
    fclose(fg);
    return 0;
}

/*================================================================*
 *
 *  BOX �Ȱ� ���� ������ �մ� ���� ��輱�� ������ ���� ��ǥ ���
 *
 *================================================================*/
int CrossPoint(x1, y1, x2, y2, xm, ym, x, y)
    float  x1, y1, x2, y2;  /* �Ȱ� �ۿ� �ִ� ������ ��ǥ */
    float  xm, ym;          /* BOX�� ũ�� [0:xm,0:ym]     */
    float  *x, *y;          /* ��輱�� ������ ���� ��ǥ  */
{
    *y = -1.0;
    if (x1 < 0.0 || x2 < 0.0)
    {
        *y = -x1*(y2-y1)/(x2-x1) + y1;
        *x = 0.0;
    }
    else if (x1 > xm || x2 > xm)
    {
        *y = (xm-x1)*(y2-y1)/(x2-x1) + y1;
        *x = xm;
    }

    if (*y < 0.0 || *y > ym)
    {
        if (y1 < 0.0 || y2 < 0.0)
        {
            *x = -y1*(x2-x1)/(y2-y1) + x1;
            *y = 0.0;
        }
        else if (y1 > ym || y2 > ym)
        {
            *x = (ym-y1)*(x2-x1)/(y2-y1) + x1;
            *y = ym;
        }
    }
    return 0;
}
