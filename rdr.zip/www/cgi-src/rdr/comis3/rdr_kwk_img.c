/******************************************************************************
**
**  (��)���ǻ� ���̴��ڷ� �׷��� �м��� CGI ���α׷�
**
**============================================================================*
**
**     o �� �� �� : ����ȯ (2003.07.5)
**
*******************************************************************************/
#include "/www/mis/cgi-src/include/input_head.h"
#include "/www/mis/cgi-src/include/input_var.h"
struct INPUT_VAR  var;
#include "/www/mis/cgi-src/include/input_print.h"
#include "rdr_kwk_data.h"

#define  KWK_SAV_DIR  "/DATA/RDR/KWK"


int main()
{
    int code;

    /*--------------------------------------------------------------*/
    /* initial */

    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(60);

    printf("HTTP/1.0 200 OK\n");
    printf("Server: Netscape-Enterprise/3.0\n");


    /*--------------------------------------------------------------*/
    /* user input decode */

    var.move  = 1;
    var.fmove = -10;

	
    if ( (code = Input()) < 0 )
    {
        printf("Content-type: text/html\n\n");
        printf(" input variable error (%d)<p>\n", code);
        input_print();
        return -1;
    }

    /*--------------------------------------------------------------*/
    /* display */

    disp_img();

    alarm(0);
    return 0;
}

/*********************************************************************
*
*  ����� ��û�ڷ� �м�
*
*********************************************************************/
int Input()
{
    struct KWK_FILE  kwk_info;
    #include "/www/mis/cgi-src/include/input_decode.inc"


    var.winnum += 100;   /* ���ý���� ���̸� �ֱ� ���� */
    var.rand = (iHH*100 + imin)/30;


    /*--------------------------------------------------------------*/
    /* �ֱ��ڷᰡ ���� ���, ���� �ֱ��ڷḦ ã�� */
    i = 1;
    if (var.auto_man == 'a')
    {
        while( kwk_data_file(&kwk_info) <= 0 )
        {
            var.seq -= var.move;
            seq2time(var.seq, &var.YY, &var.MM, &var.DD, &var.HH, &var.min, 'm', 'n');
            if ((++i) > 48) break;
        }
    }
    if (i > 48) return -3;



    return 0;
}

/*********************************************************************
 *
 *  IMAGE mode
 *
 *********************************************************************/
int disp_img()
{
    struct  KWK_FILE  kwk_info;
    FILE    *fd;
    char    gname[120], dname[120], buf[8192];
    int     code = 0, m, n;

    /*--------------------------------------------------------------*/
    /* Image make */

    m = kwk_img_check(gname, &kwk_info);
    if (m != 0) code = kwk_img_make(kwk_info);


    /*--------------------------------------------------------------*/
    /* Image file send */

    if (code >= 0)
    {
    	
        sprintf(dname, "/www/mis/web%s", gname);

        if ((fd = fopen(dname, "rb")) != NULL)
        {
            printf("Content-type: image/png\n\n");
            while ((n = fread(buf, 1, 8192, fd)) == 8192)
            {
                fwrite(buf, 1, n, stdout);
            }
            if (n > 0) fwrite(buf, 1, n, stdout);
            fclose(fd);
        }
    }
    return 0;
}

/*********************************************************************
 *
 *  �̹��� ���� ���� ���θ� �Ǵ�
 *     - ��� : 0 -> �̹��� ������ ����
 *              1 -> �̹��� ������ ������, ���߿� �� �ڷᰡ ����
 *             -1 -> �̹��� ������ ����
 *********************************************************************/
int kwk_img_check(gname, kwk_info)

    char    *gname;
    struct  KWK_FILE  *kwk_info;
{
    int  code, code_file, code_img;
    int  i, m;

    code_img = kwk_img_file(gname);
    m = kwk_data_file(kwk_info);

    if (code_img == 0)
    {
        if (m > 0)
        {
            code = 0;
            if ((*kwk_info).seq > var.seq_img) code = 1;
        }
        else
        {
            code = -1;
        }
    }
    else
    {
        if (m > 0) code = 1;
        else       code =-1;
    }
    if (code > 0) code = m;
    return code;
}

/*==================================================================*
 *
 *  �����ڷ� ���� �̸� �� ���翩��
 *
 *==================================================================*/
int kwk_data_file(kwk_info)

    struct KWK_FILE  *kwk_info;
{
    struct tm   *ts;
    struct stat st;
    int    YY, MM, DD, HH, min;
    int    code = 1;

    sprintf((*kwk_info).dname, "%s/%04d%02d/%02d/PC%02d%02d%02d_%02d%02d.DAT.gz",
            KWK_SAV_DIR, var.YY, var.MM, var.DD, var.YY%100, var.MM, var.DD, var.HH, var.min);

    if ( stat((*kwk_info).dname, &st) < 0 ) code = -1;
    else if ( st.st_size < 10 ) code = -2;
    else {
        ts  = localtime(&st.st_mtime);
        YY  = ts -> tm_year + 1900;
        MM  = ts -> tm_mon;
        DD  = ts -> tm_mday;
        HH  = ts -> tm_hour;
        min = ts -> tm_min;
        (*kwk_info).seq = time2seq(YY, MM, DD, HH, min, 'm');
    }
    return code;
}

/*********************************************************************
 *
 *  �̹������� ���翩�� ����
 *
 *********************************************************************/
int kwk_img_file(fname)

    char *fname;
{
    struct tm   *ts;
    struct stat st;
    char   *p;
    int    YY, MM, DD, HH, min;
    int    code = 0;

    sprintf(fname, "/www/mis/web/tmp/rdr/%s_%04d%02d%02d%02d%02d_%s_%c_%d_%c_%s_%d.png",
            var.data1, var.YY, var.MM, var.DD, var.HH, var.min, var.zoom, var.area, var.size, var.color, var.level, var.rand);

    var.seq_img = -1;

    if (stat(fname, &st) < 0) code = -1;
    else if (st.st_size < 52) code = -2;
    else {
        ts  = localtime(&st.st_mtime);
        YY  = ts -> tm_year + 1900;
        MM  = ts -> tm_mon;
        DD  = ts -> tm_mday;
        HH  = ts -> tm_hour;
        min = ts -> tm_min;
        var.seq_img = time2seq(YY, MM, DD, HH, min, 'm');
    }

    p = strstr(fname, "/tmp/");
    strcpy(fname, p);

    return code;
}
