/*********************************************************************
**
**  (��)���ǻ� ���̴��ڷ� �׷��� �м��� CGI ���α׷� (�̹��� ������ƾ)
**
**********************************************************************/
#include "/www/mis/cgi-src/include/input_head.h"
#include "/www/mis/cgi-src/include/input_var.h"
extern struct INPUT_VAR  var;
#include "rdr_kwk_data.h"

#define  DEGRAD      3.1415927/180.0
#define  RADDEG      180.0/3.1415927

struct COLOR USL2RGB();
struct DATA_LVL {
    int    num;         /* ��ġ�� ��     */
    float  itv;         /* ��ġ�� ����   */
    float  min;         /* ��ġ�� �ּҰ� */
    float  level[80];   /* LEVEL */
} lvl;

float  DATA[MJ+1][MI+1];
float  dbz[31];
float  rain1[33] = {0.04,  0.1,  0.2,  0.4,  0.6,  0.8,  1.0,  1.5,  2.0,  3.0,  4.0,
                     5.0,  6.0,  7.0,  8.0,  9.0, 10.0, 12.0, 14.0, 16.0, 18.0, 20.0,
                    25.0, 30.0, 35.0, 40.0, 50.0, 60.0, 70.0, 80.0, 90.0,100.0,110.0};
int    zoom_level = 0;

/*********************************************************************
 *
 *  ���ǻ� ���̴������ڷ� ����
 *
 *********************************************************************/
int kwk_data_read(kwk_info)

    struct KWK_FILE kwk_info;
{
    struct stat st;
    unsigned char  b[40044];
    int   i, j, k, k1, n, n1, m;

    for (j = 0; j <= MJ; j++)
    {
        for (i = 0; i <= MI; i++)
        {
            DATA[j][i] = -999;
        }
    }

    /* File Open */

    if ( (kwk_info.fd = gzopen(kwk_info.dname, "rb")) == NULL )
    {
        return -1;
    }

    /* Data Read */

    n = gzread(kwk_info.fd, b, 40040);
    if (n < 40040) return -2;

    for (m = 0, n1 = 4, k = 1; k <= 20; k++)
    {
        n1 += 2;

        for (k1 = 0; k1 < 2042; k1++, n1++, m++)
        {
            if (n1 >= n) break;

            i = (int)(m / MJ);
            j = m - (i * MI);
            j = MJ - j;
            DATA[j][i+1] = b[n1] - 20;
        }
    }

    for (j = 1; j <= MJ; j++)
    {
        DATA[j][0] = DATA[j][1];
    }
    for (i = 0; i <= MI; i++)
    {
        DATA[0][i] = DATA[1][i];
    }

    /* File Close */

    gzclose(kwk_info.fd);

    /* zoom */

    if (zoom_level > 0)
    {
        for (i = 0; i < 7; i++)
        {
            if ( kwk_zoom(i) < 0 ) break;
        }
    }

    /* Smoothing */

    kwk_sm();

    return 0;
}

/*==================================================================*
 *  for ZOOM (2x)
 *==================================================================*/
int kwk_zoom(int zoom_level)
{
    int  zx, zy;
    int  i, j, i1, i2;

    zx = var.zoom[zoom_level] - '0';
    zy = var.zoom[zoom_level+8] - '0';
    if (zx == 0 || zy == 0) return -1;

    i1 = MI/4*(zx-1);
    i2 = i1 + MI/2;

    for (i = i1; i <= i2; i++)
    {
        if (zy == 1)
        {
            for (j = MJ; j >= 0; j -= 2) DATA[j][i] = DATA[j/2][i];
        }
        else if (zy == 3)
        {
            for (j = 0; j <= MJ; j += 2) DATA[j][i] = DATA[MJ/2+j/2][i];
        }
        else
        {
            for (j =  0; j < MJ/2; j += 2) DATA[j][i] = DATA[MJ/4+j/2][i];
            for (j = MJ; j > MJ/2; j -= 2) DATA[j][i] = DATA[MJ/4+j/2][i];
        }

        for (j = 1; j < MJ; j += 2)
            DATA[j][i] = ( DATA[j-1][i] + DATA[j+1][i] ) * 0.5;
    }

    for (j = 0; j <= MJ; j++)
    {
        if (zx == 1)
        {
            for (i = MI; i >= 0; i -= 2) DATA[j][i] = DATA[j][i/2];
        }
        else if (zx == 3)
        {
            for (i = 0; i <= MI; i += 2) DATA[j][i] = DATA[j][MI/2+i/2];
        }
        else
        {
            for (i =  0; i < MI/2; i += 2) DATA[j][i] = DATA[j][MI/4+i/2];
            for (i = MI; i > MI/2; i -= 2) DATA[j][i] = DATA[j][MI/4+i/2];
        }

        for (i = 1; i < MI; i += 2)
            DATA[j][i] = ( DATA[j][i-1] + DATA[j][i+1] ) * 0.5;
    }
    return 0;
}

/*==================================================================*
 *  Grid data Smoothing (by 1-2-1 Smoothing)
 *==================================================================*/
int kwk_sm()
{
    float  e[4], e1, e2;
    int    sm_num = 1;          /* Smoothing Ƚ�� (default:1) */
    int    i, j, k;

    if (var.size < MI/2) sm_num = 2;
    if (zoom_level > 0) sm_num = 1;

    for (k = 0; k < sm_num; k++)
    {
        for (j = 0; j <= MJ; j++)
        {
            e1 = DATA[j][0];
            e[0] = DATA[j][0];
            e[1] = DATA[j][1];

            for (i = 1; i < MI-1; i++)
            {
                e[2] = DATA[j][i+1];
                e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;

                DATA[j][i-1] = e1;

                e1 = e2;
                e[0] = e[1];
                e[1] = e[2];
            }
            DATA[j][i-1] = e1;
        }

        for (i = 0; i <= MI; i++)
        {
            e1 = DATA[0][i];
            e[0] = DATA[0][i];
            e[1] = DATA[1][i];

            for (j = 1; j < MJ-1; j++)
            {
                e[2] = DATA[j+1][i];
                e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;

                DATA[j-1][i] = e1;

                e1 = e2;
                e[0] = e[1];
                e[1] = e[2];
            }
            DATA[j-1][i] = e1;
        }
    }
    return 0;
}

/*********************************************************************
 *
 *  (��)���ǻ� ���̴� �̹��� ���� ��ƾ
 *
 *********************************************************************/
int kwk_img_make(kwk_info)
    struct KWK_FILE kwk_info;
{
    gdImagePtr im;
    FILE  *fd;
    char  gname[120];
    int   color[256];
    int   len, code_data;
    int   i, j, k;

    /* Zoom Level */

    zoom_level = 0;

    for (i = 0; i < 7; i++)
    {
        if (var.zoom[i] == '0') break;
        zoom_level = i + 1;
    }

    /* Data Read */

    code_data = kwk_data_read(kwk_info);

    /* Gd Alloc. */

    var.NI = var.size;
    var.NJ = var.size;
    var.rate = (float)MI / (float)var.NI;
    var.GI = var.NI + LEG_pixel + LVL_pixel;
    var.GJ = var.NJ + TTL_pixel;

    im = gdImageCreate(var.GI+1, var.GJ+1);

    /* Color Table */

    if      (var.color == 'E') color_table_E(im, color);
    else if (var.color == 'C') color_table_C(im, color);
    else if (var.color == 'B') color_table_B(im, color);

    gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color[254]);

    /* Level parameer */

    level_value();

    /* Data Display */

    data_disp(im, color);

    /* Map */

    map_draw(im, color, 1000);

    /* ���ü� & ��輱 */

    if (zoom_level == 0) range_disp(im, color);

    /* Level */

    level_disp(im, color);

    /* Title */

    title_disp(im, color);

    /* for No file */

    if (code_data == -1)
        gdImageString(im, gdFontLarge, 10, 50, (unsigned char *)"NO Data Files", color[249]);
    /*
    else
        gdImageString(im, gdFontLarge, 10, 50, (unsigned char *)"Data Files Error", color[249]);
*/
    /* File Write */

    strcpy(gname, "/www/mis/web");
    len = strlen(gname);

    if (kwk_img_check(&gname[len], &kwk_info) >= -1)
    {
        if ( (fd = fopen(gname, "wb")) == NULL )
        {
            gdImageDestroy(im);
            return -1;
        }
        else
        {
            gdImagePng(im, fd);
            fclose(fd);
        }
    }
    gdImageDestroy(im);

    return 0;
}

/*============================================================================*
 *  Color Table �ۼ� (������)
 *============================================================================*/
int color_table_E(im, color)
    gdImagePtr im;
    int    color[];
{
    struct COLOR rgb;
    int  U[6] = {  0,  42,  85, 127, 170, 213}; /* ����,���,���,�ϴ�,�Ķ�,���� */
    int  S[6] = {127, 127, 127, 127, 127, 127}; /* ä�� */
    int  L[6] = {160, 160, 160, 160, 160, 160}; /* ���� */
    int  D[6] = { 15,  15,  15,  15,  15,  15}; /* ä������ */
    int  S1, un = 6, sd = 2, j1;
    int  i, j, k;

    /*------------------------------------------------------------------------*/
    /* data level color */

    color[0] = gdImageColorAllocate(im, 230, 230, 230);
    k = 0;

    for (j = 0; j < un; j++)
    {
        j1 = (j + 1) % 6;
        S[j1] = (int)(S[j1] + (float)D[j1]*4.5);

        for (i = 0; i < 10; i += sd)
        {
            S1 = S[j1] - i*D[j1];
            rgb = USL2RGB(U[j1], S1, L[j1]);
            color[++k] = gdImageColorAllocate(im, rgb.R, rgb.G, rgb.B);
        }
    }
    color[++k] = gdImageColorAllocate(im, 40, 40, 40);

    /*------------------------------------------------------------------------*/
    /* other color */

    color[240] = gdImageColorAllocate(im,   0,   0,   0);   /* Black      */
    color[245] = gdImageColorAllocate(im, 255,   0,   0);   /* ������     */
    color[246] = gdImageColorAllocate(im, 160, 160, 160);   /* Wind area  */
    color[247] = gdImageColorAllocate(im, 255, 255,   0);   /* �����     */
    color[248] = gdImageColorAllocate(im,   1,   1,   1);   /* ��������   */
    color[249] = gdImageColorAllocate(im, 255,   0,   0);   /* AWS        */
    color[250] = gdImageColorAllocate(im, 128,  64,   0);   /* ����       */
    color[251] = gdImageColorAllocate(im,   0,   0, 128);   /* ����       */
    color[252] = gdImageColorAllocate(im, 128, 128, 128);   /* �������   */
    color[253] = gdImageColorAllocate(im,  80,  80,  80);   /* blank      */
    color[254] = gdImageColorAllocate(im, 210, 210, 210);   /* background */
    color[255] = gdImageColorAllocate(im, 255, 255, 255);   /* white      */

    return 0;
}

/*============================================================================*
 *  Color Table (���ӻ�)
 *============================================================================*/
int color_table_C(im, color)
    gdImagePtr im;
    int color[];
{
    struct COLOR rgb;
    int    U, S=127, L=180, D=15;
    int    U1, U2, U3, S0, S1;
    int    sd=2, j1=1, j2=6, j3=1, i1, i2=5, i3;
    int    i, j, k;

    /*------------------------------------------------------------------------*/
    /* color level setting */

    i3 = (j2 - j1) * i2;

    /*------------------------------------------------------------------------*/
    /* data level color */

    U1 = (int)(42.5 * (float)(j1%6));
    U2 = (int)(42.5 * (float)(j2%6));
    if (j3 > 0 && U1 > U2) U2 += 256;
    U3 = (U2 - U1)/(float)i3;

    /* start */
    color[0] = gdImageColorAllocate(im, 230, 230, 230);
    S0 = (float)S + (float)D*4.5;

    for (k = 0, i = 0; i < i2/2; i += sd)
    {
        S1 = S0 - D*i;
        rgb = USL2RGB(U1, S1, L);
        color[++k] = gdImageColorAllocate(im, rgb.R, rgb.G, rgb.B);
    }

    /* medium */
    S = 127;

    for (i = 0; i < i3; i++)
    {
        U = (int)(U3*i + U1)%256;
        rgb = USL2RGB(U, S, L);
        color[++k] = gdImageColorAllocate(im, rgb.R, rgb.G, rgb.B);
    }

    /* end */
    S0 = (float)S + (float)D*4.5;

    for (i = i2/2; i < 10; i += sd)
    {
        S1 = S0 - D*i;
        rgb = USL2RGB(U2, S1, L);
        color[++k] = gdImageColorAllocate(im, rgb.R, rgb.G, rgb.B);
    }
    color[++k] = gdImageColorAllocate(im, 40, 40, 40);

    /*------------------------------------------------------------------------*/
    /* other color */

    color[240] = gdImageColorAllocate(im,   0,   0,   0);   /* Black      */
    color[245] = gdImageColorAllocate(im, 255,   0,   0);   /* ������     */
    color[246] = gdImageColorAllocate(im, 160, 160, 160);   /* Wind area  */
    color[247] = gdImageColorAllocate(im, 255, 255,   0);   /* �����     */
    color[248] = gdImageColorAllocate(im,   1,   1,   1);   /* ��������   */
    color[249] = gdImageColorAllocate(im, 255,   0,   0);   /* AWS        */
    color[250] = gdImageColorAllocate(im, 128,  64,   0);   /* ����       */
    color[251] = gdImageColorAllocate(im,   0,   0, 128);   /* ����       */
    color[252] = gdImageColorAllocate(im, 128, 128, 128);   /* �������   */
    color[253] = gdImageColorAllocate(im,  80,  80,  80);   /* blank      */
    color[254] = gdImageColorAllocate(im, 210, 210, 210);   /* background */
    color[255] = gdImageColorAllocate(im, 255, 255, 255);   /* white      */
    return 0;
}

/*============================================================================*
 *  Color Table (���)
 *============================================================================*/
int color_table_B(im, color)
    gdImagePtr im;
    int color[];
{
    struct COLOR rgb;
    int    U, S = 255, L = 127;
    int    j1, j2;
    int    i, j, k, c;

    /* level color */

    j1 = 0;

    k = 0;
    color[k] = gdImageColorAllocate(im, 20, 20, 20);

    for (j = j1; j < 60; j++)
    {
        L = j*4 + 16;
        color[++k] = gdImageColorAllocate(im, L, L, L);
    }
    color[++k] = gdImageColorAllocate(im, 250, 250, 250);

    /* other color */

    color[240] = gdImageColorAllocate(im, 0, 0, 0);         /* ������     */
    color[245] = gdImageColorAllocate(im, 255,   0,   0);   /* ������     */
    color[246] = gdImageColorAllocate(im, 200, 230, 245);   /* ����     */
    color[247] = gdImageColorAllocate(im, 255, 255, 0);     /* �����     */
    color[248] = gdImageColorAllocate(im, 1, 1, 1);         /* ��������   */
    color[249] = gdImageColorAllocate(im, 255, 0, 0);       /* AWS        */
    color[250] = gdImageColorAllocate(im, 128, 64, 0);      /* ����       */
    color[251] = gdImageColorAllocate(im, 0, 0, 128);       /* ����       */
    color[252] = gdImageColorAllocate(im, 128, 128, 128);   /* �������   */
    color[253] = gdImageColorAllocate(im, 200, 200, 200);   /* blank      */
    color[254] = gdImageColorAllocate(im, 200, 200, 200);   /* shade line */
    color[255] = gdImageColorAllocate(im, 255, 255, 255);   /* white      */

    return 0;
}

/*===================================================================*
 *  Level value
 *===================================================================*/
int level_value()
{
    int   i;

    lvl.num = 31;
    lvl.itv = 1.0;
    lvl.min = 1.0;

    for (i = 0; i <= lvl.num; i++) lvl.level[i] = rain1[i+1];

    return 0;
}

/*===================================================================*
 *
 *  data display
 *
 *===================================================================*/
int data_disp(im, color)
    gdImagePtr im;
    int    color[];
{
    float  p, p1, p2;
    float  xx, yy, dx, dy;
    int    ix, iy;
    int    c;
    int    i, j;

    for (i = 0; i <= 30; i++)
        dbz[i] = 10.0*log10(200.0) + 16.0*log10(rain1[i]);

    for (j = 0; j < var.NJ; j++)
    {
        yy = (float)j * var.rate;
        iy = (int)yy;
        if (iy >= MJ) continue;
        dy = yy - (float)iy;

        for (i = 0; i < var.NI; i++)
        {
            xx = (float)i * var.rate;
            ix = (int)xx;
            if (ix >= MI) continue;
            dx = xx - (float)ix;

            p1 = DATA[iy][ix]*(1.0-dx) + DATA[iy][ix+1]*dx;
            p2 = DATA[iy+1][ix]*(1.0-dx) + DATA[iy+1][ix+1]*dx;
            p = p1*(1.0-dy) + p2*dy;
            c = level_color(p);
            gdImageSetPixel(im, i, j+TTL_pixel, color[c]);
        }
    }
    return 0;
}

/*===================================================================*
 *  Data value --> Color level
 *===================================================================*/
int level_color(v)
    float v;
{
    int  c = 31, i;

    if      (v < -990) c = 255;		/* NO area */
    else if (v <=   0) c = 254;		/* NO data */
    else
    {
        for (i = 1; i <= lvl.num; i++)
        {
            if (v < dbz[i])
            {
                c = i - 1;
                break;
            }
        }
    }
    return c;
}

/*===================================================================*
 *  GIS data display
 *===================================================================*/
int map_draw(im, color, mode)
    gdImagePtr im;
    int  color[];
    int  mode;
{
    FILE   *fd;
    char   fname[120], cbuf[8];
    int    num, code, ibuf[2];
    float  buf[2];
    float  xr = 500 - 400, yr = 500 - 400;      /* �����ݰ��� 500 km, ���ǻ극�̴� �ݰ��� 400 km */
    float  x1, y1, x2, y2, x, y;
    int    map_color;
    int    ix1, iy1, ix2, iy2;
    float  zm = 1, xo = 0, yo = 0;
    int    zx, zy;
    int    i, j, k = 0;

    /* Zooming rate */

    for (i = 0; i < 7; i++)
    {
        zx = var.zoom[i] - '0';
        zy = var.zoom[i+8] - '0';
        if (zx == 0 || zy == 0) break;

        xo += MI*(zx-1)/(float)zm;
        yo += MJ*(3-zy)/(float)zm;
        zm *= 2;
    }
    zm /= (var.rate*4);
    xo += xr;
    yo += yr;

    /* Per Map data */

    for(j = 1; j <= 4; j++)
    {
        if (mode % 10 == 1)
        {
            if      (j == 1) map_color = color[252];     /* ������� */
            else if (j == 2) map_color = color[251];     /* ����     */
            else if (j == 3) map_color = color[250];     /* ����     */
            else if (j == 4) map_color = color[240];     /* �ؾȼ�   */

            sprintf(fname, "/www/mis/cgi-bin/REF/BLN/RDR_%s_%d.bln", var.data1, j);
            if ( (fd = fopen(fname, "rb")) == NULL ) continue;

            while( fread(ibuf, sizeof(int), 2, fd) > 0 )
            {
                num  = ibuf[0];
                code = ibuf[1];

                fread(buf, sizeof(float), 2, fd);
                ix1 = (int)(zm * (buf[0] - xo) + 0.5);
                iy1 = var.GJ - (int)(zm * (buf[1] - yo) + 0.5);

                for(i = 1; i < num; i++)
                {
                    fread(buf, sizeof(float), 2, fd);

                    ix2 = (int)(zm * (buf[0] - xo) + 0.5);
                    iy2 = var.GJ - (int)(zm * (buf[1] - yo) + 0.5);
                    gdImageLine(im, ix1, iy1, ix2, iy2, map_color);

                    /* line depth */
/*                    gdImageLine(im, ix1+1, iy1, ix2+1, iy2, map_color);*/

                    ix1 = ix2;
                    iy1 = iy2;
                }
            }
            fclose(fd);
        }
        mode /= 10;
    }

    return 0;
}

/*==================================================================*
 *  ���ü�
 *==================================================================*/
int range_disp(im, color)
    gdImagePtr im;
    int color[];
{
    int    xo = var.size/2, yo = var.size/2 + TTL_pixel;	/* ���̴���ġ */
    int    x, y;
    float  r;
    int    i;

    var.range = 400 * 1000;

    /* 100km ���� �� */
    for (i = 100; i <= 500; i += 100)
    {
        r = (float)(var.size*i)/(float)(0.001*var.range);
        gdImageArc(im, xo, yo, (int)r, (int)r, 0, 360, color[250]);
    }
    r = var.size;
    gdImageArc(im, xo, yo, (int)r, (int)r, 0, 360, color[245]);

    /* 45�� �������� ���м� */
    for (i = 0; i < 360; i += 45)
    {
        x = (int)( r * cos(i*DEGRAD) ) + xo;
        y = (int)( r * sin(i*DEGRAD) ) + yo;
        gdImageLine(im, xo, yo, x, y, color[250]);
    }

    /* ���̴� ���� ǥ�� */
    gdImageFilledRectangle(im, xo-3, yo-3, xo+3, yo+3, color[245]);
    return 0;
}

/*===================================================================*
 *  TITLE display
 *===================================================================*/
int title_disp(im, color)
    gdImagePtr im;
    int color[];
{
    char  text[255], text2[32];
    int   YY, MM, DD, HH, min;

    gdImageFilledRectangle(im, 0, 0, var.NI+8, TTL_pixel, color[255]);
    gdImageLine(im, 0, TTL_pixel, var.NI+8, TTL_pixel, color[240]);

    /* Title */

    strcpy(text2, "RDR KWK     ");
    seq2time(var.seq, &YY, &MM, &DD, &HH, &min, 'm', 'n');
    sprintf(text, "%s  < %04d.%02d.%02d.%02d:%02d >", text2, YY, MM, DD, HH, min);

    if (var.size < 400)
        gdImageString(im, gdFontSmall, 5, 1, (unsigned char *)text, color[240]);
    else
        gdImageString(im, gdFontSmall, 5, 1, (unsigned char *)text, color[240]);

    /* ���� */

    strcpy(text, "mm/h");

    gdImageString(im, gdFontSmall, var.NI+10, 1, (unsigned char *)text, color[240]);

    return 0;
}

/*===================================================================*
 *  Level display
 *===================================================================*/
int level_disp(im, color)
    gdImagePtr im;
    int color[];
{
    char  level_text[16];
    float dy, y1, y2;
    int   i, j, jc=31, c;

    dy = (float)var.NJ/(float)(lvl.num+1);

    /* ����ǥ */

    y2 = var.GJ;

    for (j = 0; j <= lvl.num; j++)
    {
        y1 = y2 - dy;
        gdImageFilledRectangle(im, var.NI, (int)y1, var.NI+LEG_pixel, (int)y2, color[j]);
        /*gdImageLine(im, var.NI, (int)y2, var.NI+LEG_pixel, (int)y2, color[240]);*/
        y2 = y1;
    }
    gdImageFilledRectangle(im, var.NI+LEG_pixel+1, 0, var.GI, var.GJ, color[255]);
    gdImageRectangle(im, 0, TTL_pixel, var.NI, var.GJ, color[240]);
    gdImageRectangle(im, 0, 0, var.NI+LEG_pixel, var.GJ, color[240]);

    /* ���� */

    for (j = 0; j < lvl.num; j++)
    {
        if (fabs(lvl.level[j]) < 10)
            sprintf(level_text, "%.1f", lvl.level[j]);
        else
            sprintf(level_text, "%d", (int)lvl.level[j]);

        y1 = var.GJ - dy*((float)j+1.5);
        if (var.size < 400)
        {
            if (j%2 == 0) gdImageString(im, gdFontTiny, var.NI+LEG_pixel+2, (int)y1, (unsigned char *)level_text, color[240]);
        }
        else if (var.size <= 600)
            gdImageString(im, gdFontTiny, var.NI+LEG_pixel+2, (int)y1+3, (unsigned char *)level_text, color[240]);
        else
            gdImageString(im, gdFontSmall, var.NI+LEG_pixel+2, (int)y1+5, (unsigned char *)level_text, color[240]);
    }
    return 0;
}
