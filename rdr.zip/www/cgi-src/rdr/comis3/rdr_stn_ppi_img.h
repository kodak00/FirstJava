#include "input_head.h"
#include "input_var.h"
#include "rsl.h"

#define  RDR_DIR    "/DATA/RDR/RAW"
#define  WEB_DIR    "/www/mis/web"
#define  IMG_DIR1   "/www/mis/web/tmp/rdr"
#define  IMG_DIR2   IMG_DIR1
#define  CGI_DIR    "/cgi-bin/rdr"
#define  INC_DEC    "/www/mis/cgi-src/include/input_decode.inc"
