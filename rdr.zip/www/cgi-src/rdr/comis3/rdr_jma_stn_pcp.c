/*************************************************************************
**
**  �Ϻ� ���̴��� 1�ð� ���������� ����
**
**=======================================================================*
**
**     o �ۼ� : ����ȯ (1999. 10. 17)
**     o ���� : NCOMIS�� �°� ���� (����ȯ, 2000.1.2)
**
**************************************************************************/
#include "/www/mis/cgi-src/include/input_head.h"
#include "/www/mis/cgi-src/include/input_var.h"
struct INPUT_VAR  var;
#include "/www/mis/cgi-src/include/input_print.h"
#include "/www/mis/cgi-src/include/rdr_stn.h"

#define JRD_SAV_DIR  "/DATA/RDR/JMA"

struct COLOR HSL2RGB();
char   buf_jma[100][100];           /* data */

float  rain[33] = {0.04,  0.1,  0.2,  0.4,  0.6,  0.8,  1.0,  1.5,  2.0,  3.0,  4.0,
                    5.0,  6.0,  7.0,  8.0,  9.0, 10.0, 12.0, 14.0, 16.0, 18.0, 20.0,
                   25.0, 30.0, 35.0, 40.0, 50.0, 60.0, 70.0, 80.0, 90.0,100.0,110.0};

struct JMA_RDR_HEAD
{
    char  CCCC[8];
    char  TTAAii[8];
    short YY;           // �ڷ�ð�
    char  MM;
    char  DD;
    char  HH;
    char  MI;
    short YY_rcv;       // ���Žð�
    char  MM_rcv;
    char  DD_rcv;
    char  HH_rcv;
    char  MI_rcv;
    char  SS_rcv;
    short size;
    char  type;         // 1:dec, 2:noe, 3:noo
    char  mode;         // 0:���, 1:������� ����
    char  rem;          // ����
} head;


int main()
{
    int code;

    /*--------------------------------------------------------------*/
    /* initial */

    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(60);

    printf("HTTP/1.0 200 OK\n");
    printf("Server: Netscape-Enterprise/3.0\n");

    /*--------------------------------------------------------------*/
    /* user input decode */

    var.move  = 60;
    var.fmove = 17;


    if ( (code = Input()) < 0 )
    {
        printf("Content-type: text/html\n\n");
		printf(" <!--  \n");
        printf(" input variable error (%d)<p>\n", code);
        input_print();
		printf(" -->   \n");
        return -1;
    }

    /*--------------------------------------------------------------*/
    /* display */

    if      (var.mode == 'H') disp_html();
    else if (var.mode == 'I') disp_img();

    alarm(0);
    return 0;
}

/*********************************************************************
 *
 *  ����� ��û�� Ȯ��
 *
 *********************************************************************/
int Input()
{
    #include "/www/mis/cgi-src/include/input_decode.inc"

    /*--------------------------------------------------------------*/
    /* Error check (+) */

    if (strcmp(var.data0, "ALL") != 0)
    {
        for (i = 0; i < RDR_STN_NUM; i++)
        {
            if (strcmp(var.data0, rdr_stn[i].head) == 0 && rdr_stn[i].mode == 1) break;
        }
        if (i >= RDR_STN_NUM) return -2;
    }
    else
    {
        var.an_frn = 1;
        var.mode = 'H';
    }

    /*--------------------------------------------------------------*/
    /* �ֱ��ڷᰡ ���� ���, ���� �ֱ��ڷḦ ã�� */
    if (var.auto_man == 'a' && var.mode == 'H' && strcmp(var.data0, "ALL") != 0)
    {
        i = 1;
        while ( rdr_jma_stn_pcp_file(0) != 0 && i <= 48 )
        {
            var.seq -= var.move;
            seq2time(var.seq, &var.YY, &var.MM, &var.DD, &var.HH, &var.min, 'm', 'n');
            i++;
        }
    }
    if (i > 48) return -3;
    return 0;
}

/*********************************************************************
 *
 *  IMAGE mode
 *
 *********************************************************************/
int disp_img()
{
    FILE  *fd;
    char   gname[120];
    int    code, len, c;

    if ( rdr_jma_stn_pcp_img_file(gname) < 0 )
        rdr_jma_stn_pcp_img();

    printf("Content-type: image/png\n\n");

    strcpy(gname, "/www/mis/web");
    len = strlen(gname);
    rdr_jma_stn_pcp_img_file(&gname[len]);

    if ( (fd = fopen(gname, "rb")) != NULL )
    {
        c = getc(fd);

        while (c != EOF)
        {
            putchar(c);
            c = getc(fd);
        }
        fclose(fd);
    }
    return 0;
}

/*********************************************************************
 *
 *  HTML mode
 *
 *********************************************************************/
int disp_html()
{
    char  gname[48][120];
    int   n, i, j, k;

    printf("Content-type: text/html\n\n");

    /*--------------------------------------------------------------*/
    /* Image file make for all data */

    if (strcmp(var.data0, "ALL")== 0)
    {
        n = 0;
        for(k = 0; k < RDR_STN_NUM; k++)
        {
            if (rdr_stn[k].mode == 1)
            {
                strcpy(var.data0, rdr_stn[k].head);
                if ( rdr_jma_stn_pcp_img_file(gname[n]) < 0 )
                {
                    if ( rdr_jma_stn_pcp_file(1) >= 0 )
                    {
                        if ( rdr_jma_stn_pcp_img() == 0 ) n++;
                    }
                }
                else
                {
                    n++;
                }
            }
        }
        strcpy(var.data0, "ALL");
    }

    /*--------------------------------------------------------------*/
    /* Image file make for animation */

    else
    {
        if (var.an_frn > 1) var.seq = var.seq - (var.an_frn-1) * var.an_itv;
        n = 0;
        for(i = 0; i < var.an_frn; i++)
        {
            if ( rdr_jma_stn_pcp_img_file(gname[n]) < 0 )
            {
                if ( rdr_jma_stn_pcp_file(1) >= 0 )
                {
                    if ( rdr_jma_stn_pcp_img() == 0 ) n++;
                }
            }
            else
            {
                n++;
            }
        }
        if (var.an_frn > 1) var.seq += var.an_itv;
    }

    /*--------------------------------------------------------------*/
    /* head part */

    disp_html_head(n, gname);

    /*--------------------------------------------------------------*/
    /* body part */

    disp_html_body(n, gname);

    return 0;
}

/*===================================================================*
 *
 *  HEAD ������ ���
 *
 *===================================================================*/
int disp_html_head(n, gname)

    int   n;
    char  gname[][120];
{
    int  i;

    printf("<HTML>\n");
    printf("<HEAD>\n");

    /*--------------------------------------------------------------*/
    /* for auto reload */

    if (n == 1 && var.auto_man == 'a')
        printf("<META http-equiv='Refresh' content=600>\n");


	printf("<style type='text/css'>  \n");
    printf("<!--                     \n");
    printf("Body,Table {Font-family:\"����\",\"Tahoma\"; Font-Size:9pt; Color:#333333; Text-Decoration:none; \n");
    printf("					Margin-Top:0px; Margin-Left:10px; Margin-Right:0px; Margin-Bottom:0px;       \n");
    printf("					Scrollbar-Arrow-Color:#000000;                                               \n");
    printf("					Scrollbar-Highlight-Color:#FFFFFF;                                           \n");
    printf("					Scrollbar-Shadow-Color:#B4B4B4;                                              \n");
    printf("					Scrollbar-Darkshadow-Color:#EEEEEE;                                          \n");
    printf("					Scrollbar-3dlight-Color:#EEEEEE;                                             \n");
    printf("					Scrollbar-Track-Color:#FAFAFA;                                               \n");
    printf("					Scrollbar-Face-Color:#EEEEEE;}                                               \n");
    printf("-->      \n");
    printf("</style> \n");

    /*--------------------------------------------------------------*/
    /* Time sync. */

    printf("<SCRIPT LANGUAGE='JavaScript'>\n");
    printf("<!--\n");
    printf("parent.menu.resetTime ( '%04d.%02d.%02d.%02d:%02d' ); \n",
            var.YY, var.MM, var.DD, var.HH, var.min);

    /*--------------------------------------------------------------*/
    /* for animation */

    if (var.an_frn > 1 && n > 1 && var.mode == 'H')
    {
        printf("var counter = 0\n");
        printf("var animation = 1\n");
        printf("var timer\n");
        printf("var i, j\n");
        printf("var imgs = new Array()\n");
        printf("for(i = 0; i < %d; i++) {\n", n);
        printf("  imgs[i] = new Image()\n");
        printf("}\n\n");

        for (i = 0; i < n; i++)
            printf("imgs[%d].src = '%s'\n", i, gname[i]);

        printf("\n");
        printf("function animate() {\n");
        printf("  if (animation == 1) {\n");
        printf("    counter = (counter + 1) %% %d\n", n);
        printf("    document.anim.src = imgs[counter].src\n");
        printf("    timer = setTimeout('animate()', 1000)\n");
        printf("  }\n");
        printf("}\n\n");
        printf("function play() {\n");
        printf("  animation = 1\n");
        printf("  animate()\n");
        printf("}\n\n");
        printf("function stop() {\n");
        printf("  animation = 0\n");
        printf("}\n\n");
        printf("function moving(bf) {\n");
        printf("  counter = (counter + bf + %d) %% %d\n", n, n);
        printf("    document.anim.src = imgs[counter].src\n");
        printf("}\n\n");
    }
    printf("// -->\n");
    printf("</SCRIPT>\n");
    printf("</HEAD>\n");

    return 0;
}

/*===================================================================*
 *
 *  BODY ������ ���
 *
 *===================================================================*/
int disp_html_body(n, gname)

    int   n;
    char  gname[][120];
{
    char  name[16], fname[120];
    int   seq, seq1, seq2;
    int   time_auto;
    int   i, j, k, m = 0;

    /* for animation */
    if (n > 1 && var.an_frn > 1)
    {
        printf("<BODY bgcolor=#ffffff onload='animate()' TOPMARGIN=0 LEFTMARGIN=10 marginwidth=0 marginheight=0>\n");
        printf("<a href='javascript:play()'><img src='/images/play.gif' border=0></a>\n");
        printf("<a href='javascript:stop()'><img src='/images/stop.gif' border=0></a>\n");
        printf("<a href='javascript:moving(-1)'><img src='/images/back.gif' border=0></a>\n");
        printf("<a href='javascript:moving(1)'><img src='/images/for.gif' border=0></a><br>\n");
    }
    else
    {
        printf("<BODY bgcolor=#ffffff TOPMARGIN=0 LEFTMARGIN=10 marginwidth=0 marginheight=0>\n");
    }

    /* image */
    if (strcmp(var.data0, "ALL") == 0)
    {
        printf("<TABLE border=0 cellspacing=3 cellpadding=0>");

        for (k = 0; k < RDR_STN_NUM; k++)
        {
            if (rdr_stn[k].mode == 1)
            {
                strcpy(var.data0, rdr_stn[k].head);

                if (m % 3 == 0) printf("<TR>\n");
                if (rdr_jma_stn_pcp_img_file(fname) == 0)
                    printf("<TD><img src='%s'></TD>\n", fname);
                else
                    printf("<TD>&nbsp;</TD>");

                if (m % 3 == 2) printf("</TR>\n");

                m++;
            }
        }
        strcpy(var.data0, "ALL");
        printf("<TD>&nbsp;</TD></TR>\n");
        printf("</TABLE>\n");
    }
    else
    {
        printf("<img name='anim' src='%s' border=0>\n", gname[0]);
    }
    printf("</BODY></HTML>\n");
    return 0;
}

/*********************************************************************
 *
 *  1�ð� ������ ���� �̹��� ���� (������)
 *
 *********************************************************************/
int rdr_jma_stn_pcp_img()
{
    FILE   *fd;
    char   gname[120];
    struct lamc_parameter  map;
    gdImagePtr  im;
    int    color[256], c, x, y;
    int    len, i, j, k;

    /* area */
    var.NI = var.size;
    var.NJ = var.size;
    var.GI = var.NI + LEG_pixel + LVL_pixel;
    var.GJ = var.NJ + TTL_pixel;

    /* gd alloc. */
    im = gdImageCreate(var.GI+1, var.GJ+1);

    /* color table */
    color_table(im, color);

    /* blank area fill */
    gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color[254]);

    /* data display */
    if (var.ds1 == 0)
        rdr_jma_stn_pcp_disp(im, color);
    else if (var.ds1 == 1)
        gdImageString(im, gdFontGiant, var.NI/2+10, var.NJ/2-5, (unsigned char *)"NO ECHO", color[249]);
    else if (var.ds1 == 2)
        gdImageString(im, gdFontGiant, var.NI/2+10, var.NJ/2-5, (unsigned char *)"NO OPERATION", color[249]);
    else
        gdImageString(im, gdFontGiant, var.NI/2+10, var.NJ/2-5, (unsigned char *)"NO DATA", color[249]);

    /* map draw */
    map_draw(im, color, 1000, 250.0, (float)var.size/500.0);

    /* level table display */
    level_disp(im, color);

    /* title display */
    title_disp(im, color);

    /* boundary line */
    gdImageArc(im, var.NI/2, var.NI/2+TTL_pixel, var.NI, var.NI, 0, 360, color[255]);

    /* station position */
    x = var.NJ/2;
    y = var.NJ/2 + TTL_pixel;
    gdImageFilledRectangle(im, x-2, y-2, x+2, y+2, color[249]);

    /* file write */
    strcpy(gname, "/www/mis/web");

    len = strlen(gname);
    if ( rdr_jma_stn_pcp_img_file(&gname[len]) < 0 )
    {
        if ( (fd = fopen(gname, "wb")) == NULL )
        {
            gdImageDestroy(im);
            return -1;
        }
        else
        {
            gdImagePng(im, fd);
            fclose(fd);
        }
    }
    gdImageDestroy(im);
    return 0;
}

/*====================================================================*
 *
 *  Color Table
 *
 *====================================================================*/
int color_table(im, color)

    gdImagePtr im;
    int color[];
{
    struct COLOR rgb;
    int    H, S = 255, L = 127;
    float  center;
    int    i, j, k, c;

    /*------------------------------------------------------------*/
    /* data level color */

    color[0] = gdImageColorAllocate(im, 230, 230, 230);
    k = 0;

    for(j = 0; j < 6; j++)
    {
        H = (int)(256.0/6.0 * (float)(j + 1));
        if (j == 3) center = 2.0;
        else        center = 1.7;

        for(i = 0; i < 5; i++)
        {
            L = (int)(127.0 + (center - (float)i)*30.0);
            if (i == 3)      L -= 10;
            else if (i == 2) L -= 15;
            else if (i == 1) L += 20;
            else if (i == 0) L += 30;
            rgb = HSL2RGB(H, S, L);
            color[++k] = gdImageColorAllocate(im, rgb.R, rgb.G, rgb.B);
        }
    }
    color[++k] = gdImageColorAllocate(im, 40, 40, 40);

    /*------------------------------------------------------------*/
    /* other color */

    color[240] = gdImageColorAllocate(im,   0,   0,   0);   /* Black      */
    color[246] = gdImageColorAllocate(im, 160, 160, 160);   /* Wind area  */
    color[247] = gdImageColorAllocate(im, 255, 255,   0);   /* �����     */
    color[248] = gdImageColorAllocate(im,   1,   1,   1);   /* ��������   */
    color[249] = gdImageColorAllocate(im, 255,   0,   0);   /* Red        */
    color[250] = gdImageColorAllocate(im, 128,  64,   0);   /* ����       */
    color[251] = gdImageColorAllocate(im,   0,   0, 128);   /* ����       */
    color[252] = gdImageColorAllocate(im, 128, 128, 128);   /* �������   */
    color[253] = gdImageColorAllocate(im,  80,  80,  80);   /* blank      */
    color[254] = gdImageColorAllocate(im, 200, 200, 200);   /* background */
    color[255] = gdImageColorAllocate(im, 255, 255, 255);   /* white      */

    return 0;
}

/*====================================================================*
 *
 *  PCP data display
 *
 *====================================================================*/
int rdr_jma_stn_pcp_disp(im, color)

    gdImagePtr  im;
    int    color[];
{
    float  slp, c1, x, y, b;
    int    c;
    int    i, j, k, ix, iy;

    slp = 100.0/var.size;

    for(j = 0; j < var.size; j++)
    {
        y = (float)j * slp;
        iy = (int)y;

        for(i = 0; i < var.size; i++)
        {
            x = (float)i * slp;
            ix = (int)x;

            b = (float)buf_jma[iy][ix];
            if (b < 40) b *= 0.25;
            else        b -= 30.0;

            c = level_color(b);
            gdImageSetPixel(im, i, TTL_pixel+j, color[c]);
        }
    }
    return 0;
}

/*===================================================================*
 *  data --> level color
 *===================================================================*/
int level_color(data)

    float data;
{
    int  v = 31;
    int  i;

    for(i = 1; i <= 31; i++) {
        if (data < rain[i]) {
            v = i-1;
            break;
        }
    }
    if (data > 224.0) v = 252;
    return v;
}

/*====================================================================*
 *
 *  GIS data display
 *
 *====================================================================*/
int map_draw(im, color, mode, range, zoom_rate)

    gdImagePtr im;
    int    color[];
    int    mode;
    float  range;
    float  zoom_rate;
{
    FILE   *fd;
    char   fname[120];
    int    num, code, ibuf[2];
    float  buf[2];
    float  xo = 500.0 - range, yo = 500.0 - range;
    float  x1, y1, x2, y2, x, y;
    int    map_color;
    int    ix1, iy1, ix2, iy2;
    int    i, j, k = 0;

    map_color = color[240];

    sprintf(fname, "/www/mis/cgi-bin/REF/BLN/JRD_%s.bln", var.data0);
    if ( (fd = fopen(fname, "rb")) == NULL ) return 0;

    while( fread(ibuf, sizeof(int), 2, fd) > 0 )
    {
        num  = ibuf[0];
        code = ibuf[1];

        fread(buf, sizeof(float), 2, fd);
        ix1 = (int)(zoom_rate * ( buf[0] - xo ));
        iy1 = var.NJ + TTL_pixel - (int)(zoom_rate * ( buf[1] - yo ));

        for(i = 1; i < num; i++)
        {
            fread(buf, sizeof(float), 2, fd);

            ix2 = (int)(zoom_rate * ( buf[0] - xo ));
            iy2 = var.NJ + TTL_pixel - (int)(zoom_rate * ( buf[1] - yo ));
            gdImageLine(im, ix1, iy1, ix2, iy2, map_color);

            ix1 = ix2;
            iy1 = iy2;
        }
    }
    fclose(fd);

    return 0;
}

/*====================================================================*
 *
 *  TITLE display
 *
 *====================================================================*/
int title_disp(im, color)

    gdImagePtr im;
    int color[];
{
    char  text[120];

    gdImageFilledRectangle(im, 0, 0, var.NI+LEG_pixel, TTL_pixel, color[255]);
    gdImageLine(im, 0, TTL_pixel, var.NI+LEG_pixel, TTL_pixel, color[240]);

    sprintf(text, "RADAR PCP  %s %04d.%02d.%02d.%02dh",
                   var.data0, var.YY, var.MM, var.DD, var.HH);
    gdImageString(im, gdFontLarge, 5, 0, (unsigned char *)text, color[240]);
    return 0;
}

/*====================================================================*
 *
 *  LEVEL display
 *
 *====================================================================*/
int level_disp(im, color)

    gdImagePtr im;
    int color[];
{
    char  level_text[16];
    float dy, y1, y2;
    int   j;

    dy = (float)(var.NJ) / 32.0;

    /*------ ����ǥ ------------------------------------------------*/
    y2 = var.GJ;
    for (j = 0; j <= 31; j++)
    {
        y1 = y2 - dy;
        gdImageFilledRectangle(im, var.NI, (int)y1, var.NI+LEG_pixel, (int)y2, color[j]);
        gdImageLine(im, var.NI, (int)y2, var.NI+LEG_pixel, (int)y2, color[240]);
        y2 = y1;
    }
    gdImageFilledRectangle(im, var.NI+LEG_pixel+1, 0, var.GI, var.GJ, color[255]);
    gdImageRectangle(im, 0, TTL_pixel, var.NI, var.GJ, color[240]);
    gdImageRectangle(im, 0, 0, var.NI+LEG_pixel, var.GJ, color[240]);

    /*------ ���� ------------------------------------------------*/
    for (j = 0; j < 31; j++)
    {
        if (rain[j+1] < 10) sprintf(level_text, "%.1f", rain[j+1]);
        else                sprintf(level_text, "%d", (int)rain[j+1]);

        y1 = var.GJ - (int)(dy * (float)(j+1.8));
        gdImageString(im, gdFontTiny, var.NI+LEG_pixel+2, (int)y1, (unsigned char *)level_text, color[240]);
    }

    /*------ ���� --------------------------------------------------*/
    gdImageString(im, gdFontSmall, var.NI+LEG_pixel+2, 1, (unsigned char *)"mm", color[240]);

    return 0;
}

/*********************************************************************
 *
 *  �̹��� ���� ���翩�� �� �����̸� ��ȯ
 *
 *********************************************************************/
int rdr_jma_stn_pcp_img_file(fname)

char   *fname;
{
    struct stat st;
    char   *p;
    int    code = 0;

    sprintf(fname, "/www/mis/web/tmp/rdr/RDR_JMA_%s_PCP_%04d%02d%02d%02d%02d_%c%c%c_%s_%d.png",
                    var.data0, var.YY, var.MM, var.DD, var.HH, var.min,
                    var.color, var.effect, var.level[0], var.overlay, var.size);

    if  (stat(fname, &st) < 0) code = -1;
    else if (st.st_size < 512) code = -2;

    p = strstr(fname, "/tmp/");
    strcpy(fname, p);

    return code;
}

/*********************************************************************
 *
 *  �Ϻ� ���̴� 1�ð� ���� ������ ���� ���翩�� �� �����̸� ��ȯ
 *
 *********************************************************************/
int rdr_jma_stn_pcp_file(int mode)
{
    int    code = -1;

    code = rdr_jma_stn_gzip_file(mode);

    if (code < 0)
    {
        code = rdr_jma_stn_compress_file(mode);
    }
    var.ds1 = code;

    return code;
}

/*====================================================================*
 *  ���� ���� ���� ���� Ȯ��
 *====================================================================*/
int rdr_jma_stn_gzip_file(int mode)
{
    struct stat st;
    FILE   *fd;
    char   dname[120], type[16];
    int    YY, MM, DD, HH, min;
    int    len, code = -1;
    int    i;

    seq2time(var.seq-9*60, &YY, &MM, &DD, &HH, &min, 'm', 'n');

    for (i = 0; i < 2; i++)
    {
        if (i == 0) strcpy(type,"SDJP81");
        else        strcpy(type,"SDJP33");

        sprintf(var.fname, "%s/%04d%02d/%02d/JRD_%s_%s_%04d%02d%02d%02d%02d",
                           JRD_SAV_DIR, YY, MM, DD, var.data0, type, YY, MM, DD, HH, min);
        sprintf(dname, "%s.dec.gz", var.fname);

        code = stat(dname,&st);
        if (st.st_size < 10) code = -2;

        if (code != 0)
        {
            sprintf(dname, "%s.noo", var.fname);
            if (stat(dname, &st) == 0) code = 2;

            sprintf(dname, "%s.noe", var.fname);
            if (stat(dname, &st) == 0) code = 1;
        }

        if (code >= 0)
        {
            strcpy(var.fname, dname);
            break;
        }
    }

    if (code == 0 && mode == 1)
    {
        fd = gzopen(var.fname, "rb");

        if (fd != NULL)
        {
            len = gzread(fd, buf_jma, 10000);
            gzclose(fd);
        }
        else
        {
            code = -3;
        }
    }
    return code;
}

/*====================================================================*
 *  ���� ���� ���� ���� Ȯ��
 *====================================================================*/
int rdr_jma_stn_compress_file(int mode)
{
    struct stat st;
    FILE   *fd;
    char   dname[120];
    unsigned char out[80000], buf[10000];
    unsigned long len;
    int    YY, MM, DD, HH, min;
    int    code = -1, i, j, k, m;

    seq2time(var.seq-9*60, &YY, &MM, &DD, &HH, &min, 'm', 'n');
    sprintf(dname, "%s/%04d%02d/%02d/JMA_RDR_%04d%02d%02d%02d%02d.bin",
            JRD_SAV_DIR, YY, MM, DD, YY, MM, DD, HH, min);

    code = stat(dname, &st);
    if (code != 0)
    {
        code = -2;
        return code;
    }

    fd = fopen(dname, "rb");
    if (fd == NULL)
    {
        code = -1;
        return code;
    }

    code = -3;

    while (fread(&(head), sizeof(head), 1, fd) == 1)
    {
        if (strncmp(head.CCCC, var.data0, 4) == 0 && head.mode == 0)
        {
            if (strncmp(head.TTAAii, "SDJP81", 6) == 0 || strncmp(head.TTAAii, "SDJP33", 6) == 0)
            {
                if      (head.type == 1) code = 0;
                else if (head.type == 2) code = 1;
                else if (head.type == 3) code = 2;
                else                     code = -3;

                code = 0;
            }
        }

        if (head.size > 0) len = fread(buf, 1, (int)head.size, fd);
        if (code == 0) break;
    }
    fclose(fd);

    if (code == 0 && mode == 1 && head.size > 0)
    {
        len = 80000;
        code = uncompress(out, &len, buf, (unsigned long)head.size);

        for (k = 0, j = 0; j < 100; j++)
        {
            for (i = 0; i < 100; i++, k++)
            {
                buf_jma[j][i] = out[k];
            }
        }
    }
    else
    {
        for (k = 0, j = 0; j < 100; j++)
        {
            for (i = 0; i < 100; i++, k++)
            {
                buf_jma[j][i] = 0;
            }
        }
    }
    return code;
}
