/*********************************************************************/
/*                                                                   */
/*  �Ϻ����̴������� �̹���ó���� ����� �����ڷ� ���� ���α׷�      */
/*                                                                   */
/*     o �� ���̴��������� ����                                      */
/*     o ����ڷ� ���丮 : /www/cgi-bin/ref/BLN                    */
/*     o ������� �̸��Ծ� : JRD_{�����ڵ�}.bln                      */
/*                                                                   */
/*===================================================================*/
/*                                                                   */
/*     o �ۼ� : ����ȯ (1999. 8)                                     */
/*     o ���� : NCOMIS�� �°� ����                                   */
/*                                                                   */
/*********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <math.h>
#include "/www/cgi-src/map/map_ini.h"
#include "/www/cgi-src/include/nrutil.h"

#define ZR  4 
#define NUM_SITE 7
struct RADAR_SITE {
    int   stn_id;
    char  cccc[6];
    char  name[32];
    float lat;
    float lon;
    float height;
} site[NUM_SITE] = {
    {47920, "ISHI", "Ishigakijima", 24.4167, 124.0167, 533.5},
    {47937, "ITOK", "Naha"        , 26.1500, 127.7667, 208.3},
    {47909, "FUNC", "Naze"        , 28.3833, 129.5500, 317.2},
    {47869, "TANE", "Tanegashima" , 30.6333, 130.9833, 292.0},
    {47806, "SEFU", "Fukuoka"     , 33.4333, 130.3667, 984.2},
    {47791, "MISA", "Matsue"      , 35.5333, 133.1000, 55.47},
    {47705, "TOJI", "Fukui"       , 36.2333, 136.1500, 17.00}
};


main()
{
    FILE  *fd, *fg;
    char   fname[120], gname[120];
    struct azed_parameter  map;
    float  xm, ym, sx, sy;
    int    k, n;

    /* Input MAP */
    strcpy(fname, "/ncomis/FTP/MAP/fine_kr.dat");

    /* Per Site */
    for(k = 0; k < NUM_SITE; k++)
    {
        printf("-------------------------------------------\n");
        printf(" Site (%d) %s\n", site[k].stn_id, site[k].name);
        printf("-------------------------------------------\n");

        /* MAP parameter */
        /*
        map.Re   = 6370.19584 + site[k].height*0.001;
        map.grid = 5.0/ZR;
        map.slon = site[k].lon;
        map.slat = site[k].lat;
        map.olon = map.slon;
        map.olat = map.slat;
        map.xo = 250.0/map.grid;
        map.yo = 250.0/map.grid;
        map.first = 0;
        xm = 500.0/map.grid;
        ym = 500.0/map.grid;
*/
        map.Re   = 6370.19584 + site[k].height*0.001;
        map.grid = 1.0;
        map.slon = site[k].lon;
        map.slat = site[k].lat;
        map.olon = map.slon;
        map.olat = map.slat;
        map.xo = 500.0;
        map.yo = 500.0;
        map.first = 0;
        xm = 1000.0;
        ym = 1000.0;

        /* Output file */
        sprintf(gname, "/www/cgi-bin/ref/BLN/JRD_%s.bln", site[k].cccc);
        fg = fopen(gname, "wb");
        printf(" --> %s\n", gname);

        /* Make file */
        bln_file(fg, fname, map, xm, ym);

        fclose(fg);
    }
    exit(0);
}

/*********************************************************************
*
*  �����ڷ� ����
*
*********************************************************************/
int bln_file(fd, fname, map, xm, ym)

FILE   *fd;                     /* output file pointer */
char   *fname;                  /* input map file name */
struct azed_parameter  map;     /* map parameter       */
float  xm, ym;                  /* maximum area        */
{
    FILE   *fg;
    int    n, num, code;
    char   scode[16];
    float  *vx, *vy;
    float  lon, lat, x1, y1, x2, y2, x, y;
    float  buf[2];
    int    ibuf[2];
    int    i, j, k;
    int    now = 0;
    int    tn = 0;

    fg = fopen(fname, "r");
    if (fg == NULL) return -1;

    while( fscanf(fg, "%d %s", &num, &scode) != EOF ) {
        code = atoi(scode);

        tn += num + 1;
        printf(" --- %d %d %d\n", num, code, tn);
        if (num <= 0) break;
        vx = vector(0, num);
        vy = vector(0, num);
        k = 0;

        fscanf(fg, "%f %f", &lon, &lat);
        azedproj(&lon, &lat, &x1, &y1, 0, map);
        if( x1 >= 0.0 && x1 <= xm && y1 >= 0.0 && y1 <= ym ) {
            vx[0] = x1;
            vy[0] = y1;
            k++;
            now = 1;
        } else {
            now = 0;
        }

        for(j = 1; j < num; j++) {
            fscanf(fg, "%f %f", &lon, &lat);
            if (code == 3) continue;
            azedproj(&lon, &lat, &x2, &y2, 0, map);
            if( x2 >= 0.0 && x2 <= xm && y2 >= 0.0 && y2 <= ym ) {
                if( now == 0 ) {
                    CrossPoint(x1, y1, x2, y2, xm, ym, &x, &y);
                    x1 = x;
                    y1 = y;
                    vx[0] = x1;
                    vy[0] = y1;
                    k = 1;
                    now = 1;
                }
                vx[k] = x2;
                vy[k] = y2;
                k++;
            } else {
                if( now == 1 ) {
                    CrossPoint(x1, y1, x2, y2, xm, ym, &x, &y);
                    vx[k] = x2;
                    vy[k] = y2;
                    k++;
                    ibuf[0] = k;
                    ibuf[1] = code;
                    fwrite(ibuf, sizeof(int), 2, fd);
                    for(i = 0; i < k; i++) {
                        buf[0] = vx[i];
                        buf[1] = vy[i];
                        fwrite(buf, sizeof(float), 2, fd);
                    }
                    k = 0;
                    now = 0;
                }
            }
            x1 = x2;
            y1 = y2;
        }
        if ( k > 1 ) {
            ibuf[0] = k;
            ibuf[1] = code;
            fwrite(ibuf, sizeof(int), 2, fd);
            for(i = 0; i < k; i++) {
                buf[0] = vx[i];
                buf[1] = vy[i];
                fwrite(buf, sizeof(float), 2, fd);
            }
            k = 0;
        }
        free_vector(vy, 0, num);
        free_vector(vx, 0, num);
    }
    fclose(fg);
    return 0;
}

/******************************************************************
*
*  BOX �Ȱ� ���� ������ �մ� ���� ��輱�� ������ ���� ��ǥ ���
*
******************************************************************/
int  CrossPoint(x1, y1, x2, y2, xm, ym, x, y)

float  x1, y1, x2, y2;  /* �Ȱ� �ۿ� �ִ� ������ ��ǥ */
float  xm, ym;          /* BOX�� ũ�� [0:xm,0:ym]     */
float  *x, *y;          /* ��輱�� ������ ���� ��ǥ  */
{
    *y = -1.0;
    if( x1 < 0.0 || x2 < 0.0 ) {
        *y = -x1*(y2-y1)/(x2-x1) + y1;
        *x = 0.0;
    }
    else if( x1 > xm || x2 > xm ) {
        *y = (xm-x1)*(y2-y1)/(x2-x1) + y1;
        *x = xm;
    }

    if( *y < 0.0 || *y > ym ) {
        if( y1 < 0.0 || y2 < 0.0 ) {
            *x = -y1*(x2-x1)/(y2-y1) + x1;
            *y = 0.0;
        }
        else if( y1 > ym || y2 > ym ) {
            *x = (ym-y1)*(x2-x1)/(y2-y1) + x1;
            *y = ym;
        }
    }
    return 0;
}
