/***************************************************************************
**
**  ���û, �Ϻ� ���̴� 1�ð� �������ڷ� �ռ��� ǥ��� CGI ���α׷�
**
**=========================================================================*
**
**     o �ۼ��� : ����ȯ (1999. 10. 28)
**
****************************************************************************/
#include "input_head.h"
#include "input_var.h"
struct INPUT_VAR  var;
#include "input_print.h"
#include "rdr_stn.h"

struct COLOR HSL2RGB();
float  rain[33] = {0.04,  0.1,  0.2,  0.4,  0.6,  0.8,  1.0,  1.5,  2.0,  3.0,  4.0,
                    5.0,  6.0,  7.0,  8.0,  9.0, 10.0, 12.0, 14.0, 16.0, 18.0, 20.0,
                   25.0, 30.0, 35.0, 40.0, 50.0, 60.0, 70.0, 80.0, 90.0,100.0,110.0};

#define RDR_SAV_DIR  "/DATA/RDR/PCP"
#define JRD_SAV_DIR  "/DATA/RDR/JMA"
#define MI  680
#define MJ  800
short  g[MJ][MI];

char   buf_kma[512][512];
char   buf_jma[100][100];
int    num_rdr = 0;

struct JMA_RDR_HEAD
{
    char  CCCC[8];
    char  TTAAii[8];
    short YY;           // �ڷ�ð�
    char  MM;
    char  DD;
    char  HH;
    char  min;
    short YY_rcv;       // ���Žð�
    char  MM_rcv;
    char  DD_rcv;
    char  HH_rcv;
    char  MI_rcv;
    char  SS_rcv;
    short size;
    char  type;         // 1:dec, 2:noe, 3:noo
    char  mode;         // 0:���, 1:������� ����
    char  rem;          // ����
} head;


int main()
{
    int code;

    /*--------------------------------------------------------------*/
    /* initial */

    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(120);

    printf("HTTP/1.0 200 OK\n");
    printf("Server: Netscape-Enterprise/3.0\n");

    /*--------------------------------------------------------------*/
    /* user input decode */

    var.move  = 60;
    var.fmove = 17;

    if ( (code = Input()) < 0 ) {
        printf("Content-type: text/html\n\n");
        printf(" input variable error (%d)<p>\n", code);
        input_print();
        return -1;
    }

    /*--------------------------------------------------------------*/
    /* display */

    if      (var.mode == 'H') disp_html();
    else if (var.mode == 'I') disp_img();

    alarm(0);
    return 0;
}

/*********************************************************************
 *
 *  ����� ��û�ڷ� �м�
 *
 *********************************************************************/
int Input()
{
    #include "/www/mis/cgi-src/include/input_decode.inc"

    var.rand = (imin / 5) * 500;
    /*var.rand = imin*100 + sec;*/
    return 0;
}

/*********************************************************************
 *
 *  IMAGE mode
 *
 *********************************************************************/
int disp_img()
{
    FILE  *fd;
    char   gname[120];
    int    code, len, c;

    if (rdr_tot_cmp_pcp_img_file(gname) < 0) {
        rdr_tot_cmp_pcp_img();
    }

    printf("Content-type: image/png\n\n");

    strcpy(gname, "/www/mis/web");
    len = strlen(gname);
    rdr_tot_cmp_pcp_img_file(&gname[len]);

    if ( (fd = fopen(gname, "rb")) != NULL ) {
        c = getc(fd);
        while(c != EOF) {
            putchar(c);
            c = getc(fd);
        }
        fclose(fd);
    }
    return 0;
}

/*********************************************************************
 *
 *  HTML mode
 *
 *********************************************************************/
int disp_html()
{
    char  gname[48][120];
    int   n, i;

    printf("Content-type: text/html\n\n");

    /*--------------------------------------------------------------*/
    /* Image make (include animation) */

    if (var.an_frn > 1) {
        var.seq = var.seq - (var.an_frn-1) * var.an_itv;
    }

    n = 0;
    for(i = 0; i < var.an_frn; i++)
    {
        if (rdr_tot_cmp_pcp_img_file(gname[n]) < 0) {
            if (rdr_tot_cmp_pcp_img() == 0) {
                rdr_tot_cmp_pcp_img_file(gname[n]);
                n++;
            }
        }
        if (var.an_frn > 1) var.seq += var.an_itv;
    }

    /*--------------------------------------------------------------*/
    /* head part */

    disp_html_head(n, gname);

    /*--------------------------------------------------------------*/
    /* body part */

    disp_html_body(n, gname);

    return 0;
}

/*===================================================================*
 *
 *  HEAD ������ ���
 *
 *===================================================================*/
int disp_html_head(n, gname)

int   n;
char  gname[][120];
{
    int  YY, MM, DD, HH, min;
    int  i;

    printf("<HTML>\n");
    printf("<HEAD>\n");

    /*--------------------------------------------------------------*/
    /* for auto reload */

    if (n == 1 && var.auto_man == 'a') {
        printf("<META http-equiv='Refresh' content=600>\n");
    }

	printf("<style type='text/css'>  \n");
    printf("<!--                     \n");
    printf("Body,Table {Font-family:\"����\",\"Tahoma\"; Font-Size:9pt; Color:#333333; Text-Decoration:none; \n");
    printf("					Margin-Top:0px; Margin-Left:10px; Margin-Right:0px; Margin-Bottom:0px;       \n");
    printf("					Scrollbar-Arrow-Color:#000000;                                               \n");
    printf("					Scrollbar-Highlight-Color:#FFFFFF;                                           \n");
    printf("					Scrollbar-Shadow-Color:#B4B4B4;                                              \n");
    printf("					Scrollbar-Darkshadow-Color:#EEEEEE;                                          \n");
    printf("					Scrollbar-3dlight-Color:#EEEEEE;                                             \n");
    printf("					Scrollbar-Track-Color:#FAFAFA;                                               \n");
    printf("					Scrollbar-Face-Color:#EEEEEE;}                                               \n");
    printf("-->      \n");
    printf("</style> \n");
													
    /*--------------------------------------------------------------*/
    /* Time sync. & animation */

    printf("<SCRIPT LANGUAGE='JavaScript'>\n");
    printf("<!--\n");
    printf("parent.menu.resetTime ( '%04d.%02d.%02d.%02d:%02d' ); \n",
            var.YY, var.MM, var.DD, var.HH, var.min);

    /*--------------------------------------------------------------*/
    /* for animation */

    if (n > 1 && var.mode == 'H') {
        printf("var counter = 0\n");
        printf("var animation = 1\n");
        printf("var timer\n");
        printf("var i, j\n");
        printf("var imgs = new Array()\n");
        printf("for(i = 0; i < %d; i++) {\n", n);
        printf("  imgs[i] = new Image()\n");
        printf("}\n\n");
        for(i = 0; i < n; i++) {
            printf("imgs[%d].src = '%s'\n", i, gname[i]);
        }
        printf("\n");
        printf("function animate() {\n");
        printf("  if (animation == 1) {\n");
        printf("    counter = (counter + 1) %% %d\n", n);
        printf("    document.anim.src = imgs[counter].src\n");
        printf("    timer = setTimeout('animate()', 1000)\n");
        printf("  }\n");
        printf("}\n\n");
        printf("function play() {\n");
        printf("  animation = 1\n");
        printf("  animate()\n");
        printf("}\n\n");
        printf("function stop() {\n");
        printf("  animation = 0\n");
        printf("}\n\n");
        printf("function moving(bf) {\n");
        printf("  counter = (counter + bf + %d) %% %d\n", n, n);
        printf("    document.anim.src = imgs[counter].src\n");
        printf("}\n\n");
    }
    printf("// -->\n");
    printf("</SCRIPT>\n");
    printf("</HEAD>\n");

    return 0;
}

/*===================================================================*
 *
 *  BODY ������ ���
 *
 *===================================================================*/
int disp_html_body(n, gname)

int   n;
char  gname[][120];
{
    /* for animation */
    if (n > 1)
    {
        printf("<BODY bgcolor=#ffffff onload='animate()' TOPMARGIN=0 LEFTMARGIN=10 marginwidth=0 marginheight=0>\n");
        printf("<a href='javascript:play()'><img src='/images/play.gif' border=0></a>\n");
        printf("<a href='javascript:stop()'><img src='/images/stop.gif' border=0></a>\n");
        printf("<a href='javascript:moving(-1)'><img src='/images/back.gif' border=0></a>\n");
        printf("<a href='javascript:moving(1)'><img src='/images/for.gif' border=0></a><br>\n");
    }
    else
    {
        printf("<BODY bgcolor=#ffffff TOPMARGIN=0 LEFTMARGIN=10 marginwidth=0 marginheight=0>\n");
    }

    /* image */
    //printf("<center>\n");
    if (n > 0) printf("<img name='anim' src='%s' border=0>\n", gname[0]);
    //printf("</center>\n");

    printf("</BODY></HTML>\n");
    return 0;
}

/*********************************************************************
 *
 *  �ռ� �����ڷ� ������ �̹��� ���� ����
 *
 *********************************************************************/
int rdr_tot_cmp_pcp_img()
{
    struct lamc_parameter  map;
    int    code;

    /*--------------------------------------------------------*/
    /* �ռ��� MAP parameter */

    map.Re    = 6370.19584;
    map.grid  = 2.5;
    map.slat1 = 30.0;
    map.slat2 = 60.0;
    map.olon  = 125.0;
    map.olat  = 35.0;
    map.xo    = 400.0 / map.grid;
    map.yo    = 1460.0 / map.grid;
    map.first = 0;

    /*--------------------------------------------------------*/
    /* �ռ��� ���� */

    code = rdr_tot_cmp_pcp_grd(map);

    if (code == 0)
    {
        code = rdr_tot_cmp_pcp_img_make(map);
    }
    return code;
}

/*********************************************************************
 *
 *  �ѱ��� �Ϻ����̴� 1�ð� ���� ������ �ռ� �����ڷ� ����
 *
 *********************************************************************/
int rdr_tot_cmp_pcp_grd(map)

struct lamc_parameter  map;
{
    int    i, j, k;

    /*--------------------------------------------------------*/
    /* �����ڷ� �ʱ�ȭ */

    for(j = 0; j < MJ; j++) {
    for(i = 0; i < MI; i++) {
        g[j][i] = -999;
    }
    }

    /*--------------------------------------------------------*/
    /* Per radar site */

    num_rdr = 0;
    for(k = 0; k < RDR_STN_NUM; k++) {
        if (rdr_tot_cmp_pcp_griding(map, k) == 0) num_rdr++;
    }

    /*--------------------------------------------------------*/
    /* composed data smoothing */

    rdr_tot_cmp_pcp_sm();

    return 0;
}

/*==================================================================*
 *
 *  �� ������ ���̴��ڷ� �ռ�
 *
 *==================================================================*/
int rdr_tot_cmp_pcp_griding(map, stn_seq)

struct lamc_parameter  map;
int    stn_seq;
{
    char   fname[120];
    struct azed_parameter pcp;
    float  lon, lat, x1, y1, x2, y2;
    float  xa[4], ya[4], b;
    int    ix2, iy2;
    int    v;
    int    i, j, i1, j1, code;

    /*--------------------------------------------------------------*/
    /* Map parameter */

    pcp.Re = 6370.19584 + rdr_stn[stn_seq].height * 0.001;

    if      (rdr_stn[stn_seq].mode == 0) pcp.grid = 1.0;		/* ���û */
    else if (rdr_stn[stn_seq].mode == 1) pcp.grid = 5.0;		/* ��  �� */
    else  return -1;

    pcp.slon  = rdr_stn[stn_seq].lon;
    pcp.slat  = rdr_stn[stn_seq].lat;
    pcp.olon  = rdr_stn[stn_seq].lon;
    pcp.olat  = rdr_stn[stn_seq].lat;
    pcp.xo    = 250.0 / pcp.grid;
    pcp.yo    = 250.0 / pcp.grid;
    pcp.first = 0;

    /*--------------------------------------------------------------*/
    /* ������ȯ ��� ��� */

    x1 = 0.0;
    y1 = 0.0;
    azedproj(&lon, &lat, &x1, &y1, 1, pcp);
    lamcproj(&lon, &lat, &xa[0], &ya[0], 0, map);

    x1 = (pcp.xo)*2;
    y1 = 0.0;
    azedproj(&lon, &lat, &x1, &y1, 1, pcp);
    lamcproj(&lon, &lat, &x1, &y1, 0, map);
    xa[1] = (x1 - xa[0])/pcp.xo*0.5;
    ya[1] = (y1 - ya[0])/pcp.xo*0.5;

    x1 = 0.0;
    y1 = (pcp.yo)*2;
    azedproj(&lon, &lat, &x1, &y1, 1, pcp);
    lamcproj(&lon, &lat, &x1, &y1, 0, map);
    xa[2] = (x1 - xa[0])/pcp.yo*0.5;
    ya[2] = (y1 - ya[0])/pcp.yo*0.5;

    x1 = (pcp.xo)*2;
    y1 = (pcp.yo)*2;
    azedproj(&lon, &lat, &x1, &y1, 1, pcp);
    lamcproj(&lon, &lat, &x1, &y1, 0, map);
    xa[3] = (x1 - xa[0] - xa[1]*pcp.xo*2.0 - xa[2]*pcp.yo*2)/(pcp.xo*pcp.yo*4.0);
    ya[3] = (y1 - ya[0] - ya[1]*pcp.xo*2.0 - ya[2]*pcp.yo*2)/(pcp.xo*pcp.yo*4.0);

    /*--------------------------------------------------------------*/
    /* data file open & data read */

    strcpy(var.data0, rdr_stn[stn_seq].head);
    code = rdr_stn_pcp_file(1);
    if (code != 0) return code;

    /*--------------------------------------------------------------*/
    /* map conversion */

    if (rdr_stn[stn_seq].mode == 0)			/* KMA */
    {
        for(j = 0; j < 512; j++) {
        for(i = 0; i < 512; i++) {
            if (buf_kma[j][i] < 40) b = 0.25 * (float)buf_kma[j][i];
            else                    b = (float)buf_kma[j][i] - 30.0;

            x1 = (float)i + 0.5;
            y1 = (float)j + 0.5;
            x2 = xa[0] + xa[1]*i + xa[2]*j + xa[3]*i*j;
            y2 = ya[0] + ya[1]*i + ya[2]*j + ya[3]*i*j;
            i1 = (int)x2;
            j1 = (int)y2;

            if (i1 >= 0 && i1 < MI && j1 >= 0 && j1 < MJ) {
                if (g[j1][i1] < 0 || g[j1][i1] < (int)(b*10.0)) {
                    if (b < 225) g[j1][i1] = (short)(b*10.0);
                }
            }
        }
        }
    }
    else if (rdr_stn[stn_seq].mode == 1)		/* JMA */
    {
        for(j = 0; j < 100; j++) {
        for(i = 0; i < 100; i++) {
            if (buf_jma[j][i] < 40) b = 0.25 * (float)buf_jma[j][i];
            else                    b = (float)buf_jma[j][i] - 30.0;
            v = 10.0 * b;

            x1 = (float)i + 0.5;
            y1 = (float)(100 - j) - 0.5;
            x2 = xa[0] + xa[1]*x1 + xa[2]*y1 + xa[3]*x1*y1;
            y2 = ya[0] + ya[1]*x1 + ya[2]*y1 + ya[3]*x1*y1;
            ix2 = (int)x2;
            iy2 = (int)y2;

            for(j1 = iy2-1; j1 <= iy2+1; j1++) {
            for(i1 = ix2-1; i1 <= ix2+1; i1++) {
                if (g[j1][i1] < 0 || v > g[j1][i1]) g[j1][i1] = v;
            }
            }
        }
        }
    }
    return 0;
}

/*==================================================================*
 *
 *  �ռ��� ���̴��ڷ� Smoothing
 *
 *==================================================================*/
int rdr_tot_cmp_pcp_sm()
{
    int    g1, g2, g3;
    float  d1, d2;
    int    i, j;

    for(j = 0; j < MJ; j++) {
        d1 = -999;
        for(i = 1; i < MI-1; i++) {
            g1 = g[j][i-1];
            g2 = g[j][i];
            g3 = g[j][i+1];
            if (g1 >= 0 && g2 >= 0  && g3 >= 0) {
                d2 = (float)(g1 + 2*g2 + g3) * 0.25;
            } else {
                d2 = (float)g2;
            }
            g[j][i-1] = (short)d1;
            d1 = d2;
        }
    }

    for(i = 0; i < MI; i++) {
        d1 = -999;
        for(j = 1; j < MJ-1; j++) {
            g1 = g[j-1][i];
            g2 = g[j][i];
            g3 = g[j+1][i];
            if (g1 >= 0 && g2 >= 0  && g3 >= 0) {
                d2 = (float)(g1 + 2*g2 + g3) * 0.25;
            } else {
                d2 = (float)g2;
            }
            g[j-1][i] = (short)d1;
            d1 = d2;
        }
    }
    return 0;
}

/*********************************************************************
 *
 *  �ռ������ڷ� �̹��� ����
 *
 *********************************************************************/
int rdr_tot_cmp_pcp_img_make(map)

struct lamc_parameter  map;
{
    gdImagePtr im;
    int    color[256];
    FILE   *fd;
    char   fname[120], gname[120];
    float  lon, lat, x1, y1, x2, y2;
    int    ix1, iy1, ix2, iy2;
    int    ibuf[2], num, code, len;
    float  buf[2];
    float  v;
    int    c;
    int    i, j, k, i1;

    /*-------------------------------------------------------*/
    /* image area alloc */

    var.NI = MI;
    var.NJ = MJ;
    var.GI = var.NI + LVL_pixel + LEG_pixel;
    var.GJ = var.NJ + TTL_pixel;

    im = gdImageCreate(var.GI+1, var.GJ+1);

    /* color table */
    color_table(im, color);

    /*-------------------------------------------------------*/
    /* data display */

    for(j = 0; j < var.NJ; j++) {
    for(i = 0; i < var.NI; i++) {
        v = 0.1*(float)g[j][i];
        c = level_conv(v);
        gdImageSetPixel(im, i, var.GJ-j, color[c]);
    }
    }

    /*-------------------------------------------------------*/
    /* map display */

    fd = fopen("/www/mis/cgi-bin/REF/BLN/RDR_total.bln", "rb");

    while( fread(ibuf, sizeof(int), 2, fd) > 0 )
    {
        num  = ibuf[0];
        code = ibuf[1];

        fread(buf, sizeof(float), 2, fd);
        ix1 = (int)(buf[0] + 0.5);
        iy1 = var.GJ - (int)(buf[1] + 0.5);

        for(i = 1; i < num; i++)
        {
            fread(buf, sizeof(float), 2, fd);

            ix2 = (int)(buf[0] + 0.5);
            iy2 = var.GJ - (int)(buf[1] + 0.5);
            gdImageLine(im, ix1, iy1, ix2, iy2, color[240]);

            ix1 = ix2;
            iy1 = iy2;
        }
    }
    fclose(fd);

    /*-------------------------------------------------------*/
    /* ���浵�� */
    latlon_disp(im, color, map);

    /* ���� ǥ�� */
    for (k = 0; k < RDR_STN_NUM; k++)
    {
        if (rdr_stn[k].mode > 1) continue;

        strcpy(var.data0, rdr_stn[k].head);
        code = rdr_stn_pcp_file(0);
        lat = rdr_stn[k].lat;
        lon = rdr_stn[k].lon;
        lamcproj(&lon, &lat, &x2, &y2, 0, map);
        y2 = var.GJ - y2;

        gdImageFilledRectangle(im, (int)x2-2, (int)y2-2, (int)x2+2, (int)y2+2, color[249]);
        if (code == 1) gdImageString(im, gdFontGiant, (int)x2+3, (int)y2-2, (unsigned char *)"NO", color[249]);
        if (code == 2) gdImageString(im, gdFontGiant, (int)x2+3, (int)y2-2, (unsigned char *)"NE", color[249]);
        if (code <  0) gdImageString(im, gdFontGiant, (int)x2+3, (int)y2-2, (unsigned char *)"X", color[249]);
    }

    /* title display */
    title_disp(im, color);

    /* level display */
    level_disp(im, color);

    /*--------------------------------------------------------*/
    /* �̹��� ���� ���� */

    strcpy(gname, "/www/mis/web");
    len = strlen(gname);
    rdr_tot_cmp_pcp_img_file(&gname[len]);

    if ( (fd = fopen(gname, "wb")) == NULL ) {
        gdImageDestroy(im);
        return -1;
    } else {
        gdImagePng(im, fd);
        fclose(fd);
    }

    return 0;
}

/*===================================================================*
 *
 *  Color Table �ۼ�
 *
 *===================================================================*/
int color_table(im, color)

gdImagePtr im;
int color[];
{
    struct COLOR rgb;
    int    H, S = 255, L = 127;
    float  center;
    int    cj[6] = {4,3,2,1,6,5};
    int    i, j, k;

    /*------------------------------------------------------------*/
    /* data level color */

    k = -1;
    for(j = 0; j < 6; j++)
    {
        H = (int)(256.0/6.0 * (float)(j + 1));
        if (j == 3) center = 2.0;
        else        center = 1.7;

        for(i = 0; i < 5; i++)
        {
            L = (int)(127.0 + (center - (float)i)*30.0);
            if (i == 3)      L -= 10;
            else if (i == 2) L -= 15;
            else if (i == 1) L += 20;
            else if (i == 0) L += 30;
            rgb = HSL2RGB(H, S, L);
            color[++k] = gdImageColorAllocate(im, rgb.R, rgb.G, rgb.B);
        }
    }
    for(i = 0; i < 5; i++)
    {
        L = (int)(127.0 - (1.7 - (float)i)*30.0);
        color[++k] = gdImageColorAllocate(im, L, L, L);
    }

    /* other color */
    color[240] = gdImageColorAllocate(im, 0, 0, 0);         /* ������   */
    color[245] = gdImageColorAllocate(im, 128, 128, 128);   /* ���浵�� */
    color[246] = gdImageColorAllocate(im, 0, 0, 255);       /* �Ķ���   */
    color[247] = gdImageColorAllocate(im, 255, 255, 0);     /* �����   */
    color[248] = gdImageColorAllocate(im, 1, 1, 1);         /* �������� */
    color[249] = gdImageColorAllocate(im, 255, 0, 0);       /* stn      */
    color[250] = gdImageColorAllocate(im, 128, 64, 0);      /* ����     */
    color[251] = gdImageColorAllocate(im, 0, 0, 128);       /* ����     */
    color[252] = gdImageColorAllocate(im, 128, 128, 128);   /* ������� */
    color[253] = gdImageColorAllocate(im, 200, 200, 200);   /* blank    */
    color[254] = gdImageColorAllocate(im, 200, 200, 200);   /* shade line */
    color[255] = gdImageColorAllocate(im, 255, 255, 255);   /* white    */

    return 0;
}

/*==================================================================*
 *  Data value --> Color level
 *==================================================================*/
int level_conv(v)

float v;
{
    int  c = 255;
    int  i;

    if      (v < 0) c = 255;
    else if (v < rain[1]) c = 34;
    else {
        c = 30;
        for(i = 2; i < 32; i++) {
            if (v < rain[i]) {
                c = i - 2;
                break;
            }
        }
    }
    return c;
}

/*===================================================================*
 *
 *  TITLE display
 *
 *===================================================================*/
int title_disp(im, color)

gdImagePtr im;
int color[];
{
    char  text[120];

    gdImageFilledRectangle(im, 0, 0, var.GI, TTL_pixel, color[255]);

    sprintf(text, "RADAR PCP  %04d.%02d.%02d.%02d:%02d",
            var.YY, var.MM, var.DD, var.HH, var.min);

    if (var.NI < 320)
        gdImageString(im, gdFontSmall, 5, 1, (unsigned char *)text, color[240]);
    else
        gdImageString(im, gdFontLarge, 5, 0, (unsigned char *)text, color[240]);

    return 0;
}

/*===================================================================*
 *
 *  LEVEL display
 *
 *===================================================================*/
int level_disp(im, color)

gdImagePtr im;
int color[];
{
    char  level_text[16];
    float dy, y1, y2;
    int   i, j, jc, c;

    jc = 31;
    dy = (float)(var.NJ) /(float)(jc + 1);

    /*------ ����ǥ ------------------------------------------------*/
    y2 = var.GJ;
    for(j = 0; j <= 31; j++)
    {
        y1 = y2 - dy;

        if (j == 0) i = jc + 3;
        else        i = j - 1;

        gdImageFilledRectangle(im, var.NI, (int)y1, var.NI+LEG_pixel, (int)y2, color[i]);
        gdImageLine(im, var.NI, (int)y2, var.NI+LEG_pixel, (int)y2, color[240]);
        y2 = y1;
    }
    gdImageFilledRectangle(im, var.NI+LEG_pixel+1, 0, var.GI, var.GJ, color[255]);
    gdImageRectangle(im, 0, TTL_pixel, var.NI, var.GJ, color[240]);
    gdImageRectangle(im, 0, TTL_pixel, var.NI+LEG_pixel, var.GJ, color[240]);

    /*------ ���� ------------------------------------------------*/
    for(j = 0; j < jc; j++)
    {
        if (rain[j+1] < 10) sprintf(level_text, "%.1f", rain[j+1]);
        else                 sprintf(level_text, "%d", (int)rain[j+1]);

        y1 = var.GJ - (int)(dy * (float)(j+1.2));
        gdImageString(im, gdFontSmall, var.NI+10, (int)y1, (unsigned char *)level_text, color[240]);
    }
    gdImageString(im, gdFontMediumBold, var.NI+LEG_pixel+2, 1, (unsigned char *)"mm/h", color[240]);
    return 0;
}

/*===================================================================*
 *
 *  ���浵�� display
 *
 *===================================================================*/
int latlon_disp(im, color, map)

gdImagePtr im;
int    color[];
struct lamc_parameter  map;
{
    int    lon, lat;
    float  alon1, alat1, alon2, alat2;
    float  x1, y1, x2, y2;

    /* �浵�� */
    alat1 = 20.0;
    alat2 = 40.0;

    for(lon = 118; lon < 146; lon += 2) {
        alon1 = (float)lon;
        lamcproj(&alon1, &alat1, &x1, &y1, 0, map);
        lamcproj(&alon1, &alat2, &x2, &y2, 0, map);
        gdImageLine(im, (int)x1, var.GJ-(int)y1, (int)x2, var.GJ-(int)y2, color[245]);
    }

    /* ������ */
    for(lat = 20; lat < 40; lat += 2) {
        alat1 = (float)lat;
        alon1 = 118.0;
        lamcproj(&alon1, &alat1, &x1, &y1, 0, map);

        for(lon = 1180; lon < 1460; lon++) {
            alon2 = 0.1 * (float)lon;
            lamcproj(&alon2, &alat1, &x2, &y2, 0, map);
            gdImageLine(im, (int)x1, var.GJ-(int)y1, (int)x2, var.GJ-(int)y2, color[245]);
            x1 = x2;
            y1 = y2;
        }
    }

    /* ���浵�� */
    gdImageString(im, gdFontLarge,  30, var.GJ-17, (unsigned char *)"122E", color[246]);
    gdImageString(im, gdFontLarge, 120, var.GJ-17, (unsigned char *)"124E", color[246]);
    gdImageString(im, gdFontLarge, 210, var.GJ-17, (unsigned char *)"126E", color[246]);
    gdImageString(im, gdFontLarge, 300, var.GJ-17, (unsigned char *)"128E", color[246]);
    gdImageString(im, gdFontLarge, 380, var.GJ-17, (unsigned char *)"130E", color[246]);
    gdImageString(im, gdFontLarge, 470, var.GJ-17, (unsigned char *)"132E", color[246]);
    gdImageString(im, gdFontLarge, 550, var.GJ-17, (unsigned char *)"134E", color[246]);
    gdImageString(im, gdFontLarge, 640, var.GJ-17, (unsigned char *)"136E", color[246]);

    gdImageString(im, gdFontLarge, var.NI-25,  40, (unsigned char *)"38N", color[246]);
    gdImageString(im, gdFontLarge, var.NI-25, 130, (unsigned char *)"36N", color[246]);
    gdImageString(im, gdFontLarge, var.NI-25, 220, (unsigned char *)"34N", color[246]);
    gdImageString(im, gdFontLarge, var.NI-25, 310, (unsigned char *)"32N", color[246]);
    gdImageString(im, gdFontLarge, var.NI-25, 400, (unsigned char *)"30N", color[246]);
    gdImageString(im, gdFontLarge, var.NI-25, 490, (unsigned char *)"28N", color[246]);
    gdImageString(im, gdFontLarge, var.NI-25, 580, (unsigned char *)"26N", color[246]);
    gdImageString(im, gdFontLarge, var.NI-25, 670, (unsigned char *)"24N", color[246]);
    gdImageString(im, gdFontLarge, var.NI-25, 760, (unsigned char *)"22N", color[246]);

    return 0;
}

/*********************************************************************
 *
 *  GIF ���� ���翩�� �� �����̸� ��ȯ
 *
 *********************************************************************/
int rdr_tot_cmp_pcp_img_file(gname)

char   *gname;
{
    struct stat st;
    char   *p;
    int    code = 0;

    sprintf(gname, "/www/mis/web/tmp/rdr/RDR_TOT_CMP_PCP_%04d%02d%02d%02d%02d_%c_%d_%c_%d_%d.png",
                    var.YY, var.MM, var.DD, var.HH, var.min,
                    var.area, var.size, var.color, num_rdr, var.rand);

    if (stat(gname, &st) < 0 ) code = -1;
    else if (st.st_size < 512) code = -2;

    p = strstr(gname, "/tmp/");
    strcpy(gname, p);

    return code;
}

/*********************************************************************
 *
 *  �ѱ� ���̴� 1�ð� ���� ������ ���� ���翩�� �� �����̸� ��ȯ
 *
 *********************************************************************/
int rdr_stn_pcp_file(int mode)
{
    int  code = -1, i;

    for(i = 0; i < RDR_STN_NUM; i++) {
        if (strcmp(rdr_stn[i].head, var.data0) == 0) {
            if      (rdr_stn[i].mode == 0) code = rdr_kma_stn_pcp_file(mode);
            else if (rdr_stn[i].mode == 1) code = rdr_jma_stn_pcp_file(mode);
            break;
        }
    }
    return code;
}

/*********************************************************************
 *
 *  �ѱ� ���̴� 1�ð� ���� ������ ���� ���翩�� �� �����̸� ��ȯ
 *
 *********************************************************************/
int rdr_kma_stn_pcp_file(int mode)
{
    FILE   *fd;
    struct stat st;
    int    code = 0;

    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_%04d%02d%02d%02d00.pcp.gz",
                        RDR_SAV_DIR, var.YY, var.MM, var.DD,
                        var.data0, var.YY, var.MM, var.DD, var.HH);

    if      (stat(var.fname, &st) < 0) code = -1;
    else if (st.st_size < 32) code = -2;

    if (code == 0 && mode == 1) {
        fd = gzopen(var.fname, "rb");
        if (fd != NULL) {
            gzread(fd, buf_kma, 512*512);
            gzclose(fd);
        } else {
            code = -3;
        }
    }
    return code;
}

/*********************************************************************
 *
 *  �Ϻ� ���̴� 1�ð� ���� ������ ���� ���翩�� �� �����̸� ��ȯ
 *
 *********************************************************************/
int rdr_jma_stn_pcp_file(int mode)
{
    int    code = -1;

    code = rdr_jma_stn_gzip_file(mode);

    if (code < 0)
    {
        code = rdr_jma_stn_compress_file(mode);
    }
    var.ds1 = code;
    return code;
}

/*====================================================================*
 *  ���� ���� ���� ���� Ȯ��
 *====================================================================*/
int rdr_jma_stn_gzip_file(int mode)
{
    struct stat st;
    FILE   *fd;
    char   dname[120], type[16];
    int    YY, MM, DD, HH, min;
    int    len, code = -1;
    int    i;

    seq2time(var.seq-9*60, &YY, &MM, &DD, &HH, &min, 'm', 'n');

    for (i = 0; i < 2; i++)
    {
        if (i == 0) strcpy(type,"SDJP81");
        else        strcpy(type,"SDJP33");

        sprintf(var.fname, "%s/%04d%02d/%02d/JRD_%s_%s_%04d%02d%02d%02d%02d",
                           JRD_SAV_DIR, YY, MM, DD, var.data0, type, YY, MM, DD, HH, min);
        sprintf(dname, "%s.dec.gz", var.fname);

        code = stat(dname,&st);
        if (st.st_size < 10) code = -2;

        if (code != 0)
        {
            sprintf(dname, "%s.noo", var.fname);
            if (stat(dname, &st) == 0) code = 2;

            sprintf(dname, "%s.noe", var.fname);
            if (stat(dname, &st) == 0) code = 1;
        }

        if (code >= 0)
        {
            strcpy(var.fname, dname);
            break;
        }
    }

    if (code == 0 && mode == 1)
    {
        fd = gzopen(var.fname, "rb");

        if (fd != NULL)
        {
            len = gzread(fd, buf_jma, 10000);
            gzclose(fd);
        }
        else
        {
            code = -3;
        }
    }
    return code;
}

/*====================================================================*
 *  ���� ���� ���� ���� Ȯ��
 *====================================================================*/
int rdr_jma_stn_compress_file(int mode)
{
    struct stat st;
    FILE   *fd;
    char   dname[120];
    unsigned char out[80000], buf[10000];
    unsigned long len;
    int    YY, MM, DD, HH, min;
    int    code = -1, i, j, k, m;

    seq2time(var.seq-9*60, &YY, &MM, &DD, &HH, &min, 'm', 'n');
    sprintf(dname, "%s/%04d%02d/%02d/JMA_RDR_%04d%02d%02d%02d%02d.bin",
            JRD_SAV_DIR, YY, MM, DD, YY, MM, DD, HH, min);

    code = stat(dname, &st);
    if (code != 0)
    {
        code = -2;
        return code;
    }

    fd = fopen(dname, "rb");
    if (fd == NULL)
    {
        code = -1;
        return code;
    }

    code = -3;

    while (fread(&(head), sizeof(head), 1, fd) == 1)
    {
        if (strncmp(head.CCCC, var.data0, 4) == 0 && head.mode == 0)
        {
            if (strncmp(head.TTAAii, "SDJP81", 6) == 0 || strncmp(head.TTAAii, "SDJP33", 6) == 0)
            {
                if      (head.type == 1) code = 0;
                else if (head.type == 2) code = 1;
                else if (head.type == 3) code = 2;
                else                     code = -3;

                code = 0;
            }
        }

        if (head.size > 0) len = fread(buf, 1, (int)head.size, fd);
        if (code == 0) break;
    }
    fclose(fd);

    if (code == 0 && mode == 1 && head.size > 0)
    {
        len = 80000;
        code = uncompress(out, &len, buf, (unsigned long)head.size);

        for (k = 0, j = 0; j < 100; j++)
        {
            for (i = 0; i < 100; i++, k++)
            {
                buf_jma[j][i] = out[k];
            }
        }
    }
    else
    {
        for (k = 0, j = 0; j < 100; j++)
        {
            for (i = 0; i < 100; i++, k++)
            {
                buf_jma[j][i] = 0;
            }
        }
    }
    return code;
}
