/*******************************************************************************
**
**  ���̴� MAPLE��� ǥ��� CGI ���α׷�
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2008. 5. 30)
**     o ������ : ����ȯ (2010. 6.  8)
**
********************************************************************************/
#include "rdr_maple1.h"

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int
main ()
{
    struct INPUT_VAR  var;      /* ����� ��û���� */
    struct DATA_LEVEL lvl;      /* �̹��� �������� */
    int rt;

    /*
    ��� �ʱ�ȭ
    */

    setvbuf(stdout, NULL, _IONBF, 0);

    printf("HTTP/1.0 200 OK\n");
    printf("Server: Netscape-Enterprise/3.0\n");

    /*
    ����� �Է� ���� �м�
    */

    if ( rdr_maple_user_input(&var) < 0 )
    {
        printf("Content-type: text/html\n\n");
        printf(" input variable error<p>\n");
        return -1;
    }
//    printf("Content-type: text/html\n\n");
//    user_input_print(var);

    alarm(30);

    /*
    ������ ������ ���� ����
    */

    grid_img_set(&var, &lvl);

    /*
    �ڷ�ó��
    */

    if (var.mode == 'I' || var.mode == 'F')
        rt = disp_img(var, lvl);
    else
        rt = disp_html(var, lvl);

    alarm(0);
    return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int
rdr_maple_user_input
(
    struct INPUT_VAR  *var      /* out:����� ��û���� */
)
{
    char *qs;
    char tmp[512], item[32], value[512], tm_fc[30], tm_ef[30];
    int  iYY, iMM, iDD, iHH, imin, sec;
    int  seq, iseq;
    int  i, j, n = 0;

    /* ���� �ʱ�ȭ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ���� */
    strcpy(tm_fc, "0");
    strcpy(tm_ef, "0");

    /* GET ������� ���޵� ����� �Էº������� �ص� */
    qs = getenv ("QUERY_STRING");
    if (qs == NULL) return -1;

    for (i = 0; qs[0] != '\0'; i++)
    {
        getword (value, qs, '&');
        unescape_url(value);
        getword (item, value, '=');

        if      ( !strcmp(item,"data0"))     strcpy((*var).data0,value);
        else if ( !strcmp(item,"data1"))     strcpy((*var).data1,value);
        else if ( !strcmp(item,"data2"))     strcpy((*var).data2,value);
        else if ( !strcmp(item,"map"))       strcpy((*var).map,value);
        else if ( !strcmp(item,"zoom_rate")) (*var).zoom_rate = atoi(value);
        else if ( !strcmp(item,"zoom_x"))    strcpy((*var).zoom_x,value);
        else if ( !strcmp(item,"zoom_y"))    strcpy((*var).zoom_y,value);
        else if ( !strcmp(item,"level"))     strcpy((*var).level,value);
        else if ( !strcmp(item,"color"))     strcpy((*var).color,value);
        else if ( !strcmp(item,"effect"))    strcpy((*var).effect,value);
        else if ( !strcmp(item,"overlay"))   strcpy((*var).overlay,value);
        else if ( !strcmp(item,"size"))      (*var).size = atoi(value);
        else if ( !strcmp(item,"anim"))      (*var).anim = atoi(value);
        else if ( !strcmp(item,"intv"))      (*var).intv = atoi(value);
        else if ( !strcmp(item,"tm_fc"))     strcpy(tm_fc,value); 
        else if ( !strcmp(item,"dtm"))       (*var).dtm = atoi(value);
        else if ( !strcmp(item,"tm_ef"))     strcpy(tm_ef,value);
    	else if ( !strcmp(item,"auto_man"))  (*var).auto_man = value[0]; 
        else if ( !strcmp(item,"mode"))      (*var).mode = value[0];
        else if ( !strcmp(item,"umove"))     (*var).umove = atoi(value);
        else if ( !strcmp(item,"fmove"))     (*var).fmove = atoi(value);
        else if ( !strcmp(item,"dmove"))     (*var).dmove = atoi(value);
        else if ( !strcmp(item,"bmove"))     (*var).bmove = atoi(value);
        else if ( !strcmp(item,"winnum"))    (*var).winnum = atoi(value);
        else if ( !strcmp(item,"rand"))      (*var).rand = atoi(value);
        else if ( !strcmp(item,"ctrl"))      (*var).ctrl = atoi(value);
    }

    /* ����ð� �� ���� �����ð� ���� */
    get_time(&iYY, &iMM, &iDD, &iHH, &imin, &sec);
    iseq = time2seq(iYY, iMM, iDD, iHH, imin, 'm');
    (*var).seq_now = iseq;
    (*var).rand = iseq/10;

    iseq -= (*var).fmove;
    if ((*var).umove > 0) iseq = iseq / (*var).umove * (*var).umove;

    /* ��ǥ�ð� ���� */
    if (strlen(tm_fc) < 4)
    {
        (*var).seq_fc = iseq;
        (*var).auto_man = 'a';
    }
    else
    {
        strncpy(tmp, &tm_fc[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
        strncpy(tmp, &tm_fc[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
        strncpy(tmp, &tm_fc[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
        strncpy(tmp, &tm_fc[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
        strncpy(tmp, &tm_fc[10],2);  tmp[2] = '\0';  imin= atoi(tmp);
        (*var).seq_fc = time2seq(iYY, iMM, iDD, iHH, imin, 'm') + (*var).dtm;
    }
    if ((*var).umove > 0) (*var).seq_fc = ((*var).seq_fc / (*var).umove) * (*var).umove;

    /* ��ȿ�ð� ���� */
    if (strlen(tm_ef) <= 1)
        (*var).seq_ef = (*var).seq_fc;
    else
    {
        strncpy(tmp, &tm_ef[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
        strncpy(tmp, &tm_ef[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
        strncpy(tmp, &tm_ef[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
        strncpy(tmp, &tm_ef[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
        strncpy(tmp, &tm_ef[10],2);  tmp[2] = '\0';  imin= atoi(tmp);
        (*var).seq_ef = time2seq(iYY, iMM, iDD, iHH, imin, 'm');
    }
    if ((*var).seq_ef-(*var).seq_fc > 6*60) (*var).seq_ef = (*var).seq_fc + 6*60;

    /* Ȯ�� �ܰ� Ȯ�� */
    for ((*var).zoom_level = 0, i = 0; i < strlen((*var).zoom_x); i++)
    {
        if ((*var).zoom_x[i] == '0' || (*var).zoom_y[i] == '0') break;
        (*var).zoom_level++;
    }

    /* ���� ���� */
    if ((*var).size < 40 || (*var).size > 2048) (*var).size = 480;

    /* ���õ� �ð����� ���� �ֱ��� �ڷḦ ã�� */
    for (n = 0, seq = (*var).seq_fc; seq >= (*var).seq_fc-(*var).dmove; seq -= (*var).umove)
    {
        (*var).seq_fc = seq;
        if (rdr_maple_file(var) == 0) break;
        if (n++ > 30) break;
    }

    return 0;
}

/*=============================================================================*
 *
 *  ���� ���� ���� �б�
 *
 *=============================================================================*/
int
grid_map_inf
(
    char  *map,     /* inp:Ȯ���� ������ ���� */
    int   *nx,      /* out:�������� �������� [km] */
    int   *ny,      /* out:���Ϲ��� �������� [km] */
    int   *sx,      /* out:�������� ������ġ [km] */
    int   *sy       /* out:���Ϲ��� ������ġ [km] */
)
{
    FILE  *fp;
    char  buf[1024], map_list[8], value[16];

    fp = fopen(MAP_INI_FILE,"r");
    if (fp == NULL) exit(-1);

    while (fgets(buf,1024,fp))
    {
        getword(map_list, buf, ':');
        if ( !strcmp(map, map_list) )
        {
            getword(value, buf, ':');  *nx = atoi(value);
            getword(value, buf, ':');  *ny = atoi(value);
            getword(value, buf, ':');  *sx = atoi(value);
            getword(value, buf, ':');  *sy = atoi(value);
             
            break;
        }
    }
    fclose(fp);

    return 0;
}

/*******************************************************************************
 *
 *  IMAGE
 *
 *******************************************************************************/
int
disp_img
(
    struct INPUT_VAR  var,      /* ����� ��û���� */
    struct DATA_LEVEL lvl       /* �̹��� �������� */
)
{
    FILE   *fd;
    char   gname[120], buf[8192];
    int    code, n;

    /*
    ĳ������ Ȯ�� �� �̹��� ����
    */

    if ((code = rdr_maple_img_make(&var, lvl, gname)) < 0) return -1;
    if (var.mode == 'F') return 0;

    /*
    �̹��� ����
    */

    if ( (fd = fopen(gname, "rb")) != NULL)
    {
        printf("Content-type: image/png\n\n");

        while ((n = fread(buf, 1, 8192, fd)) == 8192)
        {
            fwrite(buf, 1, n, stdout);
        }

        if (n > 0) fwrite(buf, 1, n, stdout);
        fclose(fd);
    }
    return 0;
}

/*******************************************************************************
 *
 *  ������ ������ ���� ����
 *
 *******************************************************************************/
int
grid_img_set
(
    struct INPUT_VAR  *var,     /* ����� ��û���� */
    struct DATA_LEVEL *lvl      /* �̹��� �������� */
)
{
    int  nx, ny, sx, sy;

    /*
    �̹������� ���� ���丮
    */

    if ((*var).mode == 'F')
        strcpy((*var).dir_img, IMG_DIR2);
    else
        strcpy((*var).dir_img, IMG_DIR1);

    /*
    CGI �������� ���� ���丮
    */

    strcpy((*var).dir_cgi, CGI_DIR);

    /*
    ����, �ٶ����� �� ����
    */

    grid_img_set_stn((*var), lvl);

    /*
    ���� �� �̹��� ���� ����
    */

    grid_map_inf((*var).map, &nx, &ny, &sx, &sy);
    (*lvl).grid = 1;
    (*lvl).nx = nx / (*lvl).grid;
    (*lvl).ny = ny / (*lvl).grid;

    /*
    �̹��� ���� ���� (default)
    */

    (*lvl).ni = (*var).size;                            /* �̹��� : �ڷ� X-���� */
    (*lvl).nj = (int)((*lvl).ni*(*lvl).ny/(float)((*lvl).nx));    /* �̹��� : �ڷ� Y-���� */

    (*lvl).title_pixel = TITLE_pixel;       /* �̹��� : ���� ����   */
    (*lvl).color_pixel = COLOR_pixel;       /* �̹��� : ����ǥ ���� */
    (*lvl).level_pixel = LELEL_pixel;       /* �̹��� : ���� ���� */
    (*lvl).tail_pixel  = TAIL_pixel;        /* �̹��� : �ظ��� ���� */

    if (strchr((*var).effect,'T'))          /* T:���񿵿����� */
        (*lvl).title_pixel = 0;

    if (strchr((*var).effect,'L'))          /* L:������������ */
    {
        (*lvl).color_pixel = 0;
        (*lvl).level_pixel = 0;
    }

    if (strchr((*var).effect,'A'))          /* A:������������ */
        (*lvl).tail_pixel = 0;

    (*lvl).gi = (*lvl).ni + (*lvl).color_pixel + (*lvl).level_pixel + 1;
    (*lvl).gj = (*lvl).nj + (*lvl).title_pixel + (*lvl).tail_pixel + 1;

    /*
    ���� ���� ����
    */

    (*lvl).line1_depth  = 0;     /* �ؾȼ� �� ����� �β� */
    if ((*var).zoom_level >= 2) (*lvl).line1_depth  = 1;

    (*lvl).line2_depth  = 0;     /* �ñ��� �β�   */
    (*lvl).river_depth  = 0;     /* �� �β�       */
    (*lvl).road_depth   = 0;     /* ���� �β�     */
    (*lvl).latlon_depth = 0;     /* ���浵�� �β� */

    return 0;
}

/*=============================================================================*
 *  ������ ������ ���� ���� : ����, �ٶ����� �� ����
 *=============================================================================*/
int
grid_img_set_stn
(
    struct INPUT_VAR   var,     /* ����� ��û���� */
    struct DATA_LEVEL *lvl      /* �̹��� �������� */
)
{
    int  zr, zx, zy, i;

    /*
    ��ġ�� ����
    */

    (*lvl).contour = var.effect[0];

    /*
    �ٶ���, ������ȣ, ������
    */

    (*lvl).stn_point = 5;   /* ������ ǥ�� */
    strcpy((*lvl).stn_mode, "");

    if (strchr(var.overlay,'P') != NULL)
    {
        zr = var.zoom_level;
        if (var.map[0] != 'F') zr++;

        if (zr <= 1)
        {
            (*lvl).stn_level = 0;
        }
        else if (zr == 2)
        {
            (*lvl).stn_level = 3;
        }
        else if (zr == 3)
        {
            (*lvl).stn_level = 4;
        }
        else
        {
            (*lvl).stn_level = 5;
            if (zr >= 5) strcpy((*lvl).stn_mode, "W");
        }
    }
    else
    {
        (*lvl).stn_level = 0;
    }

    /*
    �ٶ����� ǥ�� ����
    */

    (*lvl).wind_itv = 3;
    if (var.zoom_level > 0) (*lvl).wind_itv = 5;

    /*
    �ڷ������
    */

    (*lvl).missing = -0.5;

    return 0;
}

/*******************************************************************************
 *
 *  HTML
 *
 *******************************************************************************/
int
disp_html
(
    struct INPUT_VAR  var,      /* ����� ��û���� */
    struct DATA_LEVEL lvl       /* �̹��� �������� */
)
{
    int    YY, MM, DD, HH, min;
    int    time_auto;
    int    code, i, n;

    /* Meta tag */
    printf("Content-type: text/html\n\n");
    printf("<html>\n");

    /*
    HEAD part -----------------------------------------------------------------
    */

    printf("<head>\n");

    printf("<style type='text/css'>  \n");
    printf("<!--\n");
    printf("Body {Font-family:\"����\",\"Tahoma\"; Font-Size:9pt; Color:#333333; Text-Decoration:none; \n");
    printf("            Scrollbar-Arrow-Color:#000000;                                               \n");
    printf("            Scrollbar-Highlight-Color:#FFFFFF;                                           \n");
    printf("            Scrollbar-Shadow-Color:#B4B4B4;                                              \n");
    printf("            Scrollbar-Darkshadow-Color:#EEEEEE;                                          \n");
    printf("            Scrollbar-3dlight-Color:#EEEEEE;                                             \n");
    printf("            Scrollbar-Track-Color:#FAFAFA;                                               \n");
    printf("            Scrollbar-Face-Color:#EEEEEE;}                                               \n");
    printf("-->\n");
    printf("</style>\n");

    printf("<style type='text/css'>\n");
    printf("<!--\n");
    printf(":link    {text-decoration:none; color=#000099;}\n");
    printf(":active  {text-decoration:none; color=#000099;}\n");
    printf(":visited {text-decoration:none; color=#000099;}\n");
    printf(".head  {font-family:'����','Verdana'; font-size:11pt; color: #000000; font-weight:bold;}\n");
    printf(".ehead {font-family:'����ü','Verdana'; font-size:11pt; color: #000000;}\n");
    printf(".regs  {font-family:'����ü','Verdana'; font-size:10pt; color: #000000;}\n");
    printf(".name  {font-family:'����','Verdana'; font-size:10pt; color: #222222; font-weight:bold}\n");
    printf(".text1 {font-family:'����ü','Verdana'; font-size: 9pt; color: #000000;}\n");
    printf(".text2 {font-family:'����ü','Verdana'; font-size: 8pt; color: #222222;}\n");
    printf(".text3 {font-family:'����ü','Verdana'; font-size:10pt; color: #222222;}\n");
    printf(".textr {font-family:'����ü','Verdana'; font-size: 9pt; color: #ff0000;}\n");
    printf(".textb {font-family:'����ü','Verdana'; font-size: 9pt; color: #0000ff;}\n");
    printf(".textg {font-family:'����ü','Verdana'; font-size: 9pt; color: #006600;}\n");
    printf(".point {font-family:'����ü','Verdana'; font-size:10pt; color: #000000; font-weight:bold;}\n");
    printf("-->\n");
    printf("</style>\n");

    /* AUTO RELOAD */
    seq2time(var.seq_fc, &YY, &MM, &DD, &HH, &min, 'm', 'n');

    if (var.auto_man == 'a')
    {
        if (var.umove == 60)
            time_auto = 60 * (70 - min) + (int)(30.0*(float)rand()/(float)RAND_MAX);
        else
            time_auto = 60*5;

        printf("<META http-equiv='Refresh' content=%d>\n", time_auto);
    }

    /* �ڷ��� ���� ���� */
    if (rdr_maple_file(&var) == 0)
    {
        rdr_maple_rain_file_info(&var);
    }

    /* �ð����� */
    printf("<SCRIPT LANGUAGE='JavaScript'>\n");
    printf("<!--\n");
    printf("parent.menu.frm.tm_fc.value = '%04d%02d%02d%02d%02d';\n", YY, MM, DD, HH, min);
    printf("parent.menu.frm.tmfc.value = '%04d.%02d.%02d.%02d:%02d';\n", YY, MM, DD, HH, min);
    printf("parent.menu.frm.maple_def.value = %d;\n", var.maple_def);
    printf("parent.menu.frm.maple_num.value = %d;\n", var.maple_num+1);

    printf("function fix()\n");
    printf("{\n");
    printf("  anims.style.top = document.body.scrollTop;\n");
    printf("}\n");
    printf("// -->\n");
    printf("</SCRIPT>\n");
    printf("</head>\n");

    /*
    BODY part -----------------------------------------------------------------
    */

    printf("<body onkeydown='javascript:doKey();' onscroll='javascript:fix();' bgcolor=#ffffff topmargin=5 leftmargin=5 marginwidth=5 marginheight=5>\n");

    if (var.anim == 0 || var.anim == 1)
        disp_html_body(var, lvl);

    printf("</body>\n");
    printf("</html>\n");

    return 0;
}

/*=============================================================================*
 *
 *  BODY part (���� �Ǵ� ��ȭ)
 *
 *=============================================================================*/
int
disp_html_body
(
    struct INPUT_VAR  var,      /* ����� ��û���� */
    struct DATA_LEVEL lvl       /* �̹��� �������� */
)
{
    char   fname[120], gname[500], tm_string[48][24], data1[8];
    int    YY, MM, DD, HH, MI;
    int    num_ani, num_ef = 0, num_success = 0, all = 0;
    int    i, j, k, n, wh = strlen(WEB_DIR);
    char   data0[3][8] = {"CAPPI","NOFF","PROB"};

    if (strstr(var.data0,"ALL")) all = 1;

    /* ������ �̹��� ǥ�� */
    if (var.anim == 1)
    {
        if (var.intv == 10)
            num_ef = 24;
        else
            num_ef = 8;
    }

    for (num_ani = 0, i = 0; i <= num_ef; i++)
    {
        if (num_ef > 0) var.seq_ef = var.seq_fc + i*var.intv;
        seq2time(var.seq_ef, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

        /* ��ȭ ���� ���� DIV ó�� */
        printf("<div id=img%d style=\"position:absolute; left:5px; top:32px; visibility:hidden; z-index:0;\">\n", num_ani);

        /* �����ڷ� ǥ�� */
        printf("<table border=0 cellspacing=1 cellpadding=0>\n");

        for (k = 0, j = 0; j < 3; j++)
        {
            if (all == 1 || strstr(var.data0,data0[j]))
            {
                if (k == 0 || k == 1 || k == 3)
                {
                    if (k == 1 || k == 3) printf("</tr>\n");
                    printf("<tr align=center class=name bgcolor=#ffffff>\n");
                }

                // MAPLE �ڷ� ǥ��
                if (all == 1) strcpy(var.data0, data0[j]);

                if (rdr_maple_img_make(&var, lvl, gname) >= 0)
                    printf("<td><img src=\"%s\" border=0 usemap=#imgmap></td>\n", &gname[wh]);
                else
                {
                    if (var.maple_num == 0)
                        printf("<td>�������ڰ� �����ϴ�.</td>\n");
                    else if (var.maple_num < 0)
                        printf("<td>���(�ռ�)����</td>\n");
                    else
                        printf("<td>���κҸ�</td>\n");
                }

                // ������ ���̴� �ռ��ڷ� ǥ��
                if (k == 0)
                {
                    if (rdr_cmp_file(YY, MM, DD, HH, MI, fname) == 0)
                    {
                        strcpy(data1,"101");
                        printf("<td valign=bottom><img src='http://172.20.154.11/cgi-bin/rdr/nph-rdr_cmp_cappi_img?tm_mode=m10&data0=RCM&data1=%s&tm_st=0&tm_ed=%04d%02d%02d%02d%02d&dtm=m0&level=C&overlay=S&zoom_level=0&zoom_rate=2&zoom_x=%s&zoom_y=%s&level=C&auto_man=m&mode=I&umove=10&fmove=2&dmove=180&bmove=10&windnum=0&rand=10&data3=0&data2=2&effect=N&color=%s&map=%s&size=%d&an_frn=1&an_itv=30&city=on&river=on&road=on&stnname=on&gis_auto=on' border=0></td>\n", data1, YY, MM, DD, HH, MI, var.zoom_x, var.zoom_y, var.color, var.map, var.size);
                    }
                    else
                    {
                        if (all == 1) printf("<td>&nbsp;</td>\n");
                    }
                }
                k++;
            }
        }
        if (k > 0) printf("</tr>\n");
        printf("<tr><td colspan=2 class=text3>MAPLE�� �������������� �������Դϴ�<br>(���: ������ ���� 79-255)</td></tr>\n");
        printf("</table>\n");
        printf("</div>\n");

        /* �Ʒ��� ��ȭ ����� ���� �ð� ǥ�ÿ� */
        sprintf(tm_string[num_ani], "%02d:%02d", HH, MI);

        num_ani++; 
    }

    if (all == 1) strcpy(var.data0,"ALL");

    /* ��ȭ ���� */
    disp_html_body_ani(var, lvl, num_ani, tm_string);

    /* ���� ���� : JavaScript */
    disp_html_body_script(var, lvl, num_ani);

    /* �̹����� �ۼ� */
    printf("<map name=imgmap>\n");
    disp_html_body_imgmap_zoom2(var, lvl);
    printf("</map>\n");

    return 0;
}

/*=============================================================================*
 *
 *  BODY part : ��ȭ �����, ����� �� ���� ����
 *
 *=============================================================================*/
int
disp_html_body_ani
(
    struct INPUT_VAR  var,      /* ����� ��û���� */
    struct DATA_LEVEL lvl,      /* �̹��� �������� */
    int    num_ani,             /* ��ȭ�� �̹��� ������ ������ �������� */
    char   tm_string[48][24]    /* ��ȭ�� ��:�� ǥ�ÿ� */
)
{
    int  i;

    if (num_ani <= 1) return 0;
    printf("<div id=anims style=\"position:absolute; left:0px; top:0px; visibility:visible; z-index:1;\">\n");

    /*
    ��ȭ���� ��ư �̹���
    */

    printf("<!------------ ��ȭ ���� ��ư ------------------------------------->\n\n");

    printf("<div id=anim_bt style=\"position:absolute; left:%dpx; top:0px; visibility:visible; z-index:100;\">\n", var.size-120+5);
    printf("<img src='/images/anim2.png' width=120px height=28px border=0 usemap=#anim_map>\n");

    printf("<MAP name=anim_map>\n");
    printf("<area shape=rect coords=0,0,20,28 href='javascript:play();'>\n");
    printf("<area shape=rect coords=21,0,40,28 href='javascript:stop();'>\n");
    printf("<area shape=rect coords=41,0,60,28 href='javascript:view_man(0);'>\n");
    printf("<area shape=rect coords=61,0,80,28 href='javascript:moving(-1);'>\n");
    printf("<area shape=rect coords=81,0,100,28 href='javascript:moving(1);'>\n");
    printf("<area shape=rect coords=101,0,120,28 href='javascript:view_man(%d);'>\n", num_ani-1);
    printf("</MAP>\n");
    printf("</div>\n\n");

    /*
    ��ȭ ����� ǥ��
    */

    printf("<!------------ ��ȭ����� ----------------------------------------->\n\n");

    printf("<div id=anim_bar style=\"position:absolute; left:5px; top:15px; visibility:visible; z-index:100;\">\n");
    printf("<table border=0 cellspacing=0 cellpadding=0>\n");
    printf("<tr><td bgcolor=#dddddd>\n");
    printf("<table border=0 cellspacing=1 cellpadding=0 width=%dpx;>\n", var.size-121);
    printf("<tr height=12 bgcolor=#bbbbbb style=\"font-family:Verdana; font-size:3pt; cursor:hand;\">\n");

    for (i = 0; i < num_ani; i++)
        printf("<td id=tani%d onclick='view_man(%d);' onMouseOver='tm_view(%d,1);' onMouseOut='tm_view(%d,0);'>&nbsp;</td>\n", i, i, i, i);

    printf("</tr>\n</table>\n");
    printf("</table>\n");
    printf("</div>\n\n");

    /*
    ��ȭ ����� ���� ���콺�� �ö� �ð��� ǥ��
    */

    printf("<!------------ ��ȭ�� �ð� ǥ�� ----------------------------------->\n\n");

    for (i = 0; i < num_ani; i++)
    {
        printf("<div id=tm%d style=\"position:absolute; left:%dpx; top:0px; visibility:hidden; backgroundColor:#ffffff; z-index:101;\">", i, (int)(i*(float)(var.size-120)/(float)num_ani)+5);
        printf("<table border=0 cellspacing=0 cellpassing=2>\n");
        printf("<tr bgcolor=#ffffaa style='font-family:Verdana; font-size:9pt;'><td>%s</td></tr></table>\n", tm_string[i]);
        printf("</div>\n\n");
    }
    printf("</div>\n");

    return 0;
}

/*=============================================================================*
 *
 *  BODY part : ������� ���� Java Script ó��
 *
 *=============================================================================*/
int
disp_html_body_script
(
    struct INPUT_VAR  var,      /* ����� ��û���� */
    struct DATA_LEVEL lvl,      /* �̹��� �������� */
    int    num_ani              /* ��ȭ�� �̹��� ������ ������ �������� */
)
{
    int  i;

    /*
    JavaScript for animation
    */

    if (num_ani >= 1)
    {
        printf("<SCRIPT LANGUAGE='JavaScript'>\n");
        printf("<!--\n");
        printf("var counter = %d;\n", num_ani-1);
        printf("var animation = 1;\n");
        printf("var timer;\n");
        printf("var i, j;\n\n");

        printf("function view_ani(n, mode)\n");
        printf("{\n");
        printf("  if (mode == 1) \n");
        printf("    view_mode = \"visible\"; \n");
        printf("  else \n");
        printf("    view_mode = \"hidden\"; \n\n");

        printf("  div_name = \"img\" + n;\n");
        printf("  document.all[div_name].style.visibility = view_mode;\n");

        printf("  div_name = \"tm\" + n;\n");
        printf("  document.all[div_name].style.visibility = view_mode;\n");

        if (strchr(var.overlay,'W') != NULL)
        {
            printf("  div_name = \"wv\" + n;\n");
            printf("  document.all[div_name].style.visibility = view_mode;\n");
        }
        printf("\n");

        if (num_ani > 1)
        {
            printf("  if (mode == 1) \n");
            printf("  {\n");
            printf("    switch (n)\n");
            printf("    {\n");

            for (i = 0; i < num_ani; i++)
                printf("      case %d:  tani%d.style.backgroundColor = \"#ffffaa\";  break;\n", i, i);

            printf("    }\n");
            printf("  }\n");
            printf("  else \n");
            printf("  {\n");
            printf("    switch (n)\n");
            printf("    {\n");

            for (i = 0; i < num_ani; i++)
                printf("      case %d:  tani%d.style.backgroundColor = \"#bbbbbb\";  break;\n", i, i);

            printf("    }\n");
            printf("  }\n");
        }
        printf("}\n\n");

        printf("function view_man(p)\n");
        printf("{\n");
        printf("  view_ani(counter, 0);\n");
        printf("  counter = p;\n");
        printf("  view_ani(counter, 1);\n");
        printf("  stop()\n");
        printf("}\n\n");

        printf("function animate()\n");
        printf("{\n");
        printf("  if (animation == 1)\n");
        printf("  {\n");
        printf("    moving(1);\n");
        printf("    timer = setTimeout('animate()', 500);\n");
        printf("  }\n");
        printf("}\n\n");

        printf("function play()\n");
        printf("{\n");
        printf("  animation = 1;\n");
        printf("  animate();\n");
        printf("}\n\n");

        printf("function stop()\n");
        printf("{\n");
        printf("  animation = 0;\n");
        printf("}\n\n");

        printf("function moving(bf)\n");
        printf("{\n");
        printf("  view_ani(counter, 0);\n");
        printf("  counter = (counter + bf + %d) %% %d;\n", num_ani, num_ani);
        printf("  view_ani(counter, 1);\n");
        printf("}\n\n");

        printf("function tm_view(p, mode)\n");
        printf("{\n");
        printf("  if (mode == 1) \n");
        printf("    view_mode = \"visible\"; \n");
        printf("  else \n");
        printf("  {\n");
        printf("    if (p == counter) \n");
        printf("      view_mode = \"visible\";\n");
        printf("    else \n");
        printf("      view_mode = \"hidden\";\n");
        printf("  }\n");
        printf("  div_name = \"tm\" + p;\n");
        printf("  document.all[div_name].style.visibility = view_mode;\n");
        printf("}\n\n");

        printf("function doKey()\n");
        printf("{\n");
        printf("  if (event.keyCode == 37)\n");
        printf("    moving(-1);\n");
        printf("  else if (event.keyCode == 39)\n");
        printf("    moving(1);\n");
        printf("  else if (event.keyCode == 32)\n");
        printf("  {\n");
        printf("    if (animation == 1)\n");
        printf("      animation = 0;\n");
        printf("    else\n");
        printf("    {\n");
        printf("      animation = 1;\n");
        printf("      animate();\n");
        printf("    }\n");
        printf("  }\n");
        printf("}\n");

        printf("view_man(1);\n");

        printf("// -->\n");
        printf("</SCRIPT>\n\n");
    }

    /*
    ��ȭ ���� �� �ڷ� ǥ��
    */
/*
    printf("<SCRIPT language='JavaScript'>\n");
    printf("<!--\n");

    if (num_ani > 1)
    {
        printf("  animate();\n");
    }
    else if ( num_ani == 1 )  // alwais���� ������
    {
        printf("  view_ani(0, 1);\n");
    }
    printf("// -->\n");
    printf("</SCRIPT>\n\n");
*/

    return 0;
}

/*=============================================================================*
 *
 *  BODY part : �̹����� (2�� Ȯ��)
 *
 *=============================================================================*/
int
disp_html_body_imgmap_zoom2
(
    struct INPUT_VAR  var,      /* ����� ��û���� */
    struct DATA_LEVEL lvl       /* �̹��� �������� */
)
{
    float  dx, dy, x1, y1, x2, y2;
    char   jsm_str[80];
    int    nmap, sx, sy, ctrl_move = 14;
    int    i, j;

    /*
    �ڹٽ�ũ��Ʈ �Լ� ��ġ
    */
    strcpy(jsm_str, "parent.menu");

    /*
    �̹����� : Ȯ��
    */

    nmap = 5;
    dy = 0.5 * lvl.nj / (nmap-1);
    dx = 0.5 * lvl.ni / (nmap-1);

    for (j = 1; j <= nmap; j++)
    {
        y1 = (lvl.nj*0.5 - dy)*0.5 + dy*(j-1);
        y2 = y1 + dy;

        if (j == 1) y1 = dy*0.5;
        if (j == nmap) y2 = lvl.nj - dy*0.5;

        y1 += TITLE_pixel;
        y2 += TITLE_pixel;

        for (i = 1; i <= nmap; i++)
        {
            x1 = (lvl.ni*0.5 - dx)*0.5 + dx*(i-1);
            x2 = x1 + dx;

            if (i == 1) x1 = dx*0.5;
            if (i == nmap) x2 = lvl.ni - dx*0.5;

            printf("<area shape=rect coords='%d,%d,%d,%d' href='javascript:%s.zoom_area(%d,%d);'>\n", (int)x1, (int)y1, (int)x2, (int)y2, jsm_str, i, nmap-j+1);
        }
    }

    /*
    �̹����� : �̵�
    */

    if (var.zoom_level > 0)
    {
        sy = (int)(dy*0.5);
        sx = (int)(dx*0.5);

        y1 = TITLE_pixel;
        y2 = TITLE_pixel + sy;

        printf("<area shape=rect coords='%d,%d,%d,%d' href='javascript:%s.move_area(%d,-1,1);'>\n", 0, (int)y1, sx, (int)y2, jsm_str, var.zoom_level);
        printf("<area shape=rect coords='%d,%d,%d,%d' href='javascript:%s.move_area(%d,0,1);'>\n", sx, (int)y1, lvl.ni-sx, (int)y2, jsm_str, var.zoom_level);
        printf("<area shape=rect coords='%d,%d,%d,%d' href='javascript:%s.move_area(%d,1,1);'>\n", lvl.ni-sx, (int)y1, lvl.ni, (int)y2, jsm_str, var.zoom_level);

        y1 = TITLE_pixel + sy;
        y2 = TITLE_pixel + lvl.nj - sy;

        printf("<area shape=rect coords='%d,%d,%d,%d' href='javascript:%s.move_area(%d,-1,0);'>\n", 0, (int)y1, sx, (int)y2, jsm_str, var.zoom_level);
        printf("<area shape=rect coords='%d,%d,%d,%d' href='javascript:%s.move_area(%d,1,0);'>\n", lvl.ni-sx, (int)y1, lvl.ni, (int)y2, jsm_str, var.zoom_level);

        y1 = TITLE_pixel + lvl.nj - sy;
        y2 = TITLE_pixel + lvl.nj;

        printf("<area shape=rect coords='%d,%d,%d,%d' href='javascript:%s.move_area(%d,-1,-1);'>\n", 0, (int)y1, sx, (int)y2, jsm_str, var.zoom_level);
        printf("<area shape=rect coords='%d,%d,%d,%d' href='javascript:%s.move_area(%d,0,-1);'>\n", sx, (int)y1, lvl.ni-sx, (int)y2, jsm_str, var.zoom_level);
        printf("<area shape=rect coords='%d,%d,%d,%d' href='javascript:%s.move_area(%d,1,-1);'>\n", lvl.ni-sx, (int)y1, lvl.ni, (int)y2, jsm_str, var.zoom_level);
    }

    return 0;
}

/*=============================================================================*
 *
 *  BODY part : ������ ǥ��
 *
 *=============================================================================*/
int
disp_html_body_stnname
(
    struct INPUT_VAR  var,      /* ����� ��û���� */
    struct DATA_LEVEL lvl       /* �̹��� ���� */
)
{
    FILE   *fp;
    struct lamc_parameter  map;
    struct STN_AWS  stn_aws;
    char   buf[1000];
    float  lon, lat, x1, y1;
    float  map_rate, zm = 1, xo = 0, yo = 0;
    int    nx, ny, sx, sy;
    int    zlevel = var.zoom_level;
    int    YY, MM, DD, HH, MI, now;
    int    zx, zy, ok, i;

    /*
    Ȯ����
    */

    if (!strcmp(var.map,"E")) zlevel++;

    grid_map_inf(var.map, &nx, &ny, &sx, &sy);
    map_rate = (float)nx / (float)var.size;

    for (i = 0; i < 7; i++)
    {
        zx = var.zoom_x[i] - '0';
        zy = var.zoom_y[i] - '0';
        if (zx == 0 || zy == 0) break;

        xo += (int)((float)nx/8.0*(zx-1)/(float)zm);
        yo += (int)((float)ny/8.0*(zy-1)/(float)zm);
        zm *= 2;
    }
    zm /= map_rate;

    /*
    ���� ������
    */

    map.Re    = 6371.00877;
    map.slat1 = 30.0;
    map.slat2 = 60.0;
    map.olon  = 126.0;
    map.olat  = 38.0;
    map.grid  = 1.0 / zm;
    map.xo = (sx - xo) / map.grid;
    map.yo = (sy - yo) / map.grid;
    map.first = 0;

    /*
    ������ ǥ��
    */

    fp = fopen(AWS_INF_FILE, "r");
    if (fp == NULL) return -1;

    seq2time(var.seq_fc+10, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    now = ((YY*100 + MM)*100 + DD)*100 + HH;

    while (fgets(buf,1000,fp) != NULL)
    {
        str2stn_aws(buf, &stn_aws);
        if (stn_aws.stn_sp[0] == 'Z') continue;     /* ����� �ݵ�� ���� */
        if (stn_aws.tm_st > now || stn_aws.tm_ed <= now) continue;

        ok = 0;
        if (zlevel >= 1 && stn_aws.stn_sp[0] == '4') ok = 1;
        if (zlevel >= 2 && stn_aws.stn_sp[0] == '3') ok = 1;
        if (zlevel >= 3) ok = 1;

        if (ok == 0) continue;

        lon = stn_aws.lon;
        lat = stn_aws.lat;

        lamcproj(&lon, &lat, &x1, &y1, 0, map);

        if (x1 > 10 && x1 < var.size-10 && y1 > 10 && y1 < lvl.nj-10)
        {
            x1 -= 2.5*strlen(stn_aws.stn_ko);
            y1 -= 1;
            printf("  <div id=aws%d style='position:absolute; left:%dpx; top:%dpx; visibility:visible; font-family:����ü; font-size:8pt;'>%s</div>\n", stn_aws.stn_id, (int)x1, lvl.gj-(int)y1, stn_aws.stn_ko);
        }
    }
    fclose(fp);

    return 0;
}

/*=============================================================================*
 *
 *  MAPLE RAIN ���� �����ð����� �� �����ڷ�� �б�
 *
 *=============================================================================*/
int
rdr_maple_rain_file_info
(
    struct INPUT_VAR  *var       /* inp/out: ����� ��û���� */
)
{
    FILE   *fp1;
    int    fct_period[10], num_fct;         /* �ڷ��� Header ���� */
    int    n;

    /* File Open */
    fp1 = gzopen((*var).fname, "rb");
    if (fp1 == NULL)
    {
        printf("file gzopen error (%s)<br>\n", (*var).fname);
        return -1;
    }

    /* Header Read */
    n = gzread(fp1, fct_period, 10*4);
    n = gzread(fp1, &num_fct, 4);

    if (num_fct == 12)
    {
        (*var).maple_num = num_fct;
        (*var).maple_def = 30;
        (*var).maple_mode = 0;
    }
    else if (num_fct > 12)
    {
        (*var).maple_num = num_fct;
        (*var).maple_def = 10;
        (*var).maple_mode = 0;
    }
    else
    {
        (*var).maple_num = 0;
        (*var).maple_def = 30;
        (*var).maple_mode = 1;
    }

    gzclose(fp1);
    return 0;
}

/*=============================================================================*
 *
 *  MAPLE RAIN CAPPI ���� �б�
 *
 *=============================================================================*/
int
rdr_maple_rain_cappi_read
(
    float  **g,                 /* out: �����ڷ� */
    struct INPUT_VAR  *var      /* inp: ����� ��û���� */
)
{
    static FILE *fp1;
    static int seq_fc = 0;
    static int fct_num_org = -999;
    static int first = 0;
    static int NX_G, NY_G, SX_G, SY_G, nx, ny, sx, sy;

    int    fct_period[10], num_fct;         /* �ڷ��� Header ���� */
    int    maple_tm[5];
    int    maple_size[2];
    float  maple_area[6];
    int    maple_etc[2];

    float  g2[2000];
    char   data1[8];
    int    fct_num, fct_num1;
    int    i, j, k, n, i1, j1;

    //
    // ��¥�� Ʋ�� ���� �ٽ� ����
    //
    if (seq_fc != 0)
    {
        if (seq_fc != (*var).seq_fc)
        {
            gzclose(fp1);
            first = 0;
        }
    }

    //
    // ó���� ���
    //
    if (first == 0)
    {
        // ó���� ���� ����
        grid_map_inf("M1", &NX_G, &NY_G, &SX_G, &SY_G);
        grid_map_inf((*var).map, &nx, &ny, &sx, &sy);

        // File Open
        fp1 = gzopen((*var).fname, "rb");
        if (fp1 == NULL)
        {
            printf("file gzopen error (%s)<br>\n", (*var).fname);
            return -1;
        }

        // Header Read
        n = gzread(fp1, fct_period, 10*4);
        n = gzread(fp1, &num_fct, 4);

        if (num_fct == 12)
        {
            (*var).maple_num = num_fct;
            (*var).maple_def = 30;
            (*var).maple_mode = 0;
        }
        else if (num_fct > 12)
        {
            (*var).maple_num = num_fct;
            (*var).maple_def = 10;
            (*var).maple_mode = 0;
        }
        else
        {
            (*var).maple_num = num_fct;
            (*var).maple_def = 30;
            (*var).maple_mode = 1;
            gzclose(fp1);
            return -2;
        }

        n = gzread(fp1, maple_tm,   5*4);
        n = gzread(fp1, maple_size, 2*4);
        n = gzread(fp1, maple_area, 6*4);
        n = gzread(fp1, maple_etc,  2*4);

        first = 1;
    }

    //
    // ������ �ڷ� ��ġ Ȯ��
    //
    fct_num = ((*var).seq_ef - (*var).seq_fc)/(*var).maple_def - 1;
    if (fct_num < 0) fct_num = (*var).maple_num;

    if (fct_num > (*var).maple_num)
    {
        gzclose(fp1);
        return -9;
    }

    if (fct_num_org == -999 || fct_num < fct_num_org)
    {
        fct_num1 = 0;
        gzrewind(fp1);
        n = gzread(fp1, fct_period, 10*4);
        n = gzread(fp1, &num_fct, 4);
        n = gzread(fp1, maple_tm,   5*4);
        n = gzread(fp1, maple_size, 2*4);
        n = gzread(fp1, maple_area, 6*4);
        n = gzread(fp1, maple_etc,  2*4);
    }
    else
    {
        fct_num1 = fct_num_org + 1;
    }

    //
    // Data Read
    //
    for (k = fct_num1; k <= fct_num; k++)
    {
        for (j = 0; j < 1024; j++)
        {
            n = gzread(fp1, g2, 1024*4);
            if (k != fct_num) continue;

            j1 = (NY_G - j) - (SY_G - sy);
            if (j1 < 0 || j1 > ny) continue;

            for (i = 0; i < 1024; i++)
            {
                i1 = i - (SX_G - sx);
                if (i1 < 0 || i1 > nx) continue;

                g[j1][i1] = g2[i];
            }
        }
    }
    fct_num_org = fct_num;

    return 0;
}

/*=============================================================================*
 *
 *  MAPLE RAIN NOFF ���� �б�
 *
 *=============================================================================*/
int
rdr_maple_rain_noff_read
(
    float  **g,                 /* out: �����ڷ� */
    struct INPUT_VAR  *var      /* inp: ����� ��û���� */
)
{
    static FILE *fp1;
    static int seq_fc = 0;
    static int fct_num_org = -999;
    static int first = 0;
    static int NX_G, NY_G, SX_G, SY_G, nx, ny, sx, sy;

    int    fct_period[10], num_fct;         /* �ڷ��� Header ���� */
    int    maple_tm[5];
    int    maple_size[2];
    float  maple_area[6];
    int    maple_etc[2];

    float  g2[2000];
    char   data1[8];
    int    fct_num, fct_num1;
    int    i, j, k, n, i1, j1;

    //
    // ��¥�� Ʋ�� ���� �ٽ� ����
    //
    if (seq_fc != 0)
    {
        if (seq_fc != (*var).seq_fc)
        {
            gzclose(fp1);
            first = 0;
        }
    }

    //
    // ó���� ���
    //
    if (first == 0)
    {
        // ó���� ���� ����
        grid_map_inf("M1", &NX_G, &NY_G, &SX_G, &SY_G);
        grid_map_inf((*var).map, &nx, &ny, &sx, &sy);

        // File Open
        fp1 = gzopen((*var).fname, "rb");
        if (fp1 == NULL)
        {
            printf("file gzopen error (%s)<br>\n", (*var).fname);
            return -1;
        }

        // Header Read
        n = gzread(fp1, fct_period, 10*4);
        n = gzread(fp1, &num_fct, 4);

        if (num_fct == 12)
        {
            (*var).maple_num = num_fct;
            (*var).maple_def = 30;
            (*var).maple_mode = 0;
        }
        else if (num_fct > 12)
        {
            (*var).maple_num = num_fct;
            (*var).maple_def = 10;
            (*var).maple_mode = 0;
        }
        else
        {
            (*var).maple_num = num_fct;
            (*var).maple_def = 30;
            (*var).maple_mode = 1;
            gzclose(fp1);
            return -2;
        }

        n = gzread(fp1, maple_tm,   5*4);
        n = gzread(fp1, maple_size, 2*4);
        n = gzread(fp1, maple_area, 6*4);
        n = gzread(fp1, maple_etc,  2*4);

        first = 1;
    }

    //
    // ������ �ڷ� ��ġ Ȯ��
    //
    fct_num = ((*var).seq_ef - (*var).seq_fc)/(*var).maple_def - 1;
    if (fct_num < 0) fct_num = (*var).maple_num;

    if (fct_num > (*var).maple_num)
    {
        gzclose(fp1);
        return -9;
    }

    if (fct_num_org == -999 || fct_num < fct_num_org)
    {
        fct_num1 = 0;
        gzrewind(fp1);
        n = gzread(fp1, fct_period, 10*4);
        n = gzread(fp1, &num_fct, 4);
        n = gzread(fp1, maple_tm,   5*4);
        n = gzread(fp1, maple_size, 2*4);
        n = gzread(fp1, maple_area, 6*4);
        n = gzread(fp1, maple_etc,  2*4);
    }
    else
    {
        fct_num1 = fct_num_org + 1;
    }

    //
    // Data Read
    //
    for (k = fct_num1; k <= fct_num; k++)
    {
        for (j = 0; j < 1024; j++)
        {
            n = gzread(fp1, g2, 1024*4);
            if (k != fct_num) continue;

            j1 = (NY_G - j) - (SY_G - sy);
            if (j1 < 0 || j1 > ny) continue;

            for (i = 0; i < 1024; i++)
            {
                i1 = i - (SX_G - sx);
                if (i1 < 0 || i1 > nx) continue;

                g[j1][i1] = g2[i];
            }
        }
    }
    fct_num_org = fct_num;

    return 0;
}

/*=============================================================================*
 *
 *  MAPLE RAIN PROB ���� �б�
 *
 *=============================================================================*/
int
rdr_maple_rain_prob_read
(
    float  **g,                 /* out: �����ڷ� */
    struct INPUT_VAR  *var      /* inp: ����� ��û���� */
)
{
    static FILE *fp1;
    static int seq_fc = 0;
    static int fct_num_org = -999;
    static int dbz = 1;
    static int first = 0;
    static int NX_G, NY_G, SX_G, SY_G, nx, ny, sx, sy;

    int    fct_period[10], num_fct;         /* �ڷ��� Header ���� */
    int    maple_tm[5];
    int    maple_size[2];
    float  maple_area[6];
    int    maple_etc[2];

    short  g2[2000];
    char   data1[8];
    int    fct_num, fct_num1;
    int    i, j, k, n, i1, j1;
    int    num = 0;

    //
    // ��¥�� Ʋ�� ���� �ٽ� ����
    //
    if (seq_fc != 0)
    {
        if (seq_fc != (*var).seq_fc)
        {
            gzclose(fp1);
            first = 0;
        }
    }

    //
    // ó���� ���
    //
    if (first == 0)
    {
        // ���� ����
        if      (strstr((*var).data0,"PROB1")) dbz = 1;
        else if (strstr((*var).data0,"PROB2")) dbz = 2;
        else if (strstr((*var).data0,"PROB3")) dbz = 3;

        // ó���� ���� ����
        grid_map_inf("M1", &NX_G, &NY_G, &SX_G, &SY_G);
        grid_map_inf((*var).map, &nx, &ny, &sx, &sy);

        // File Open
        fp1 = gzopen((*var).fname, "rb");
        if (fp1 == NULL)
        {
            printf("file gzopen error (%s)<br>\n", (*var).fname);
            return -1;
        }

        // Header Read
        n = gzread(fp1, fct_period, 10*4);
        n = gzread(fp1, &num_fct, 4);

        if (num_fct == 12)
        {
            (*var).maple_num = num_fct;
            (*var).maple_def = 30;
            (*var).maple_mode = 0;
        }
        else if (num_fct > 12)
        {
            (*var).maple_num = num_fct;
            (*var).maple_def = 10;
            (*var).maple_mode = 0;
        }
        else
        {
            (*var).maple_num = num_fct;
            (*var).maple_def = 30;
            (*var).maple_mode = 1;
            gzclose(fp1);
            return -2;
        }

        n = gzread(fp1, maple_tm,   5*4);
        n = gzread(fp1, maple_size, 2*4);
        n = gzread(fp1, maple_area, 6*4);
        n = gzread(fp1, maple_etc,  2*4);

        first = 1;
    }

    //
    // ������ �ڷ� ��ġ Ȯ��
    //
    fct_num = ((*var).seq_ef - (*var).seq_fc)/(*var).maple_def - 1;
    if (fct_num < 0) fct_num = (*var).maple_num;

    if (fct_num > (*var).maple_num)
    {
        gzclose(fp1);
        return -9;
    }

    if (fct_num_org == -999 || fct_num < fct_num_org)
    {
        fct_num1 = 0;
        gzrewind(fp1);
        n = gzread(fp1, fct_period, 10*4);
        n = gzread(fp1, &num_fct, 4);
        n = gzread(fp1, maple_tm,   5*4);
        n = gzread(fp1, maple_size, 2*4);
        n = gzread(fp1, maple_area, 6*4);
        n = gzread(fp1, maple_etc,  2*4);
    }
    else
    {
        fct_num1 = fct_num_org + 1;
    }

    //
    // Data Read
    //
    for (k = fct_num1; k <= fct_num; k++)
    {
        for (j = 0; j < 1024; j++)
        {
            n = gzread(fp1, g2, 1024*2);
            if (k != fct_num) continue;

            j1 = (NY_G - j) - (SY_G - sy);
            if (j1 < 0 || j1 > ny) continue;

            for (i = 0; i < 1024; i++)
            {
                i1 = i - (SX_G - sx);
                if (i1 < 0 || i1 > nx) continue;

                if (g2[i] >= 0)
                {
                    if (dbz == 1)
                        g[j1][i1] = 10*(g2[i]%10);
                    else if (dbz == 2)
                        g[j1][i1] = 10*((int)(g2[i]/10) % 10);
                    else
                        g[j1][i1] = 10*((int)(g2[i]/100) % 10);
                    if (g[j1][i1] > 0) g[j1][i1] -= 5;
                }
                else
                    g[j1][i1] = g2[i];
            }
        }
    }
    fct_num_org = fct_num;

    return 0;
}

/*=============================================================================*
 *
 *  �̹��� ���� ���� ���θ� �Ǵ� ( + : ����, 0 : ����, - : �Ұ� )
 *
 *=============================================================================*/
int
rdr_maple_img_check
(
    struct INPUT_VAR  *var,     /* ����� ��û���� */
    char   *gname               /* �̹������ϸ�    */
)
{
    int  code = -1, code_file, code_img;
    int  i, m;

    code_img = img_file(var, gname);
    code_file = rdr_maple_file(var);

    if (code_file < 0)
    {
        code = -1;
    }
    else
    {
        if (code_img < 0)
        {
            code = 1;
        }
        else
        {
            if ((*var).seq_file < (*var).seq_img)
                code = 0;
            else
                code = 1;
        }
    }
    return code;
}

/*=============================================================================*
 *
 *  ���̴� MAPLE �����̸� �� ���� ����
 *
 *=============================================================================*/
int
rdr_maple_file
(
    struct INPUT_VAR  *var      /* inp: ����� ��û���� */
)
{
    struct tm   *ts;
    struct stat st;
    char   data0[8];
    int    seq, YY, MM, DD, HH, MI;
    int    code = 0;

    /* ���ϸ� */
    strcpy(data0, (*var).data0);
    if (!strcmp((*var).data0,"ALL")) strcpy(data0, "CAPPI");
    seq2time((*var).seq_fc, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

    if (strstr((*var).data0, "NOFF"))
    {
        sprintf((*var).fname, "%s/%04d%02d/%02d/RDR_MAPLE_%s_RAIN_%04d%02d%02d%02d%02d.bin.gz",
                DATA_DIR, YY, MM, DD, data0,YY, MM, DD, HH, MI);
    }
    else if (strstr((*var).data0, "PROB"))
    {
        sprintf((*var).fname, "%s/%04d%02d/%02d/RDR_MAPLE_PROB_RAIN_%04d%02d%02d%02d%02d.bin.gz",
                DATA_DIR, YY, MM, DD, YY, MM, DD, HH, MI);
    }
    else
    {
        if (!strcmp((*var).data2,"RAIN"))
            sprintf((*var).fname, "%s/%04d%02d/%02d/RDR_MAPLE_%s%s_RAIN_%04d%02d%02d%02d%02d.bin.gz",
                    DATA_DIR, YY, MM, DD, data0, (*var).data1, YY, MM, DD, HH, MI);
        else
            sprintf((*var).fname, "%s/%04d%02d/%02d/RDR_MAPLE_%s%s_WIND_%04d%02d%02d%02d%02d.bin",
                    DATA_DIR, YY, MM, DD, data0, (*var).data1, YY, MM, DD, HH, MI);
    }

    /* �������� ���� */
    if ( stat((*var).fname, &st) < 0 ) code = -1;
    else if ( st.st_size < 10 ) code = -2;
    else {
        ts = localtime(&st.st_mtime);
        YY = ts -> tm_year + 1900;
        MM = ts -> tm_mon + 1;
        DD = ts -> tm_mday;
        HH = ts -> tm_hour;
        MI = ts -> tm_min;
        (*var).seq_file = time2seq(YY, MM, DD, HH, MI, 'm');
        code = 0;
    }
//printf("fname=%s(%d)<br>\n", (*var).fname, code);
    return code;
}

/*=============================================================================*
 *
 *  ���̴� �����ڷ� �ռ� �����̸� �� ���� ����
 *
 *=============================================================================*/
int
rdr_cmp_file
(
    int  YY,
    int  MM,
    int  DD,
    int  HH,
    int  MI,
    char *fname
)
{
    struct tm   *ts;
    struct stat st;
    int    code = 0;

    /* ���ϸ� */
    sprintf(fname, "%s/%04d%02d/%02d/RDR_CM0_%04d%02d%02d%02d%02d.bin.gz",
            RDR_CMP_DIR, YY, MM, DD, YY, MM, DD, HH, MI);

    /* �������� ���� */
    if ( stat(fname, &st) < 0 ) code = -1;
    else if ( st.st_size < 10 ) code = -2;
    else {
        ts = localtime(&st.st_mtime);
        YY = ts -> tm_year + 1900;
        MM = ts -> tm_mon + 1;
        DD = ts -> tm_mday;
        HH = ts -> tm_hour;
        MI = ts -> tm_min;
        code = 0;
    }
//printf("fname=%s(%d)<br>\n", fname, code);
    return code;
}

/*******************************************************************************
 *
 *  ����� ��û�� ���� �̹��� ���ϸ�
 *
 *******************************************************************************/
int
img_file
(
    struct INPUT_VAR  *var,     /* out:����� ��û���� */
    char *gname                 /* out:�̹��� ���ϸ� */
)
{
    struct stat st;
    struct tm   *ts;
    char   stime[30], tmp[120];
    int    YYe, MMe, DDe, HHe, MIe;
    int    YYs, MMs, DDs, HHs, MIs;
    int    code = 0;

    seq2time((*var).seq_fc, &YYe, &MMe, &DDe, &HHe, &MIe, 'm', 'n');

    if ((*var).seq_ef > 0)
    {
        seq2time((*var).seq_ef, &YYs, &MMs, &DDs, &HHs, &MIs, 'm', 'n');
        sprintf(stime, "%04d%02d%02d%02d%02d", YYs, MMs, DDs, HHs, MIs);
    }
    else
    {
        sprintf(stime, "0");
    }

    strcpy(gname, (*var).dir_img);
    strcat(gname, "/RDR_MAPLE_");
    strcat(gname, (*var).data0);    strcat(gname, "_");
    strcat(gname, (*var).data1);    strcat(gname, "_");
    strcat(gname, (*var).map);      strcat(gname, "_");
    strcat(gname, (*var).zoom_x);   strcat(gname, "_");
    strcat(gname, (*var).zoom_y);   strcat(gname, "_");
    strcat(gname, (*var).level);    strcat(gname, "_");
    strcat(gname, (*var).color);    strcat(gname, "_");
    strcat(gname, (*var).effect);   strcat(gname, "_");
    strcat(gname, (*var).overlay);  strcat(gname, "_");
    sprintf(tmp, "%d_%d_%04d%02d%02d%02d%02d_%s_%d_%d.png", (*var).intv, (*var).size, YYe, MMe, DDe, HHe, MIe, stime, (*var).winnum, (*var).rand);
    strcat(gname, tmp);

    if (stat(gname, &st) < 0) code = -1;
    else if (st.st_size < 100) code = -2;
    else {
        ts  = localtime(&st.st_mtime);
        YYs  = ts -> tm_year + 1900;
        MMs  = ts -> tm_mon + 1;
        DDs  = ts -> tm_mday;
        HHs  = ts -> tm_hour;
        MIs = ts -> tm_min;
        (*var).seq_img = time2seq(YYs, MMs, DDs, HHs, MIs, 'm');
        code = 0;
    }
    return code;
}

int
user_input_print
(
    struct INPUT_VAR  var     /* inp:����� ��û���� */
)
{
    char tmp[16];
    int  YY, MM, DD, HH, MI;
    int  j;

    printf("data0 = %s<br>\n", var.data0);
    printf("data1 = %s<br>\n", var.data1);
    printf("map = %s<br>\n", var.map);
    printf("zoom_rate = %d<br>\n", var.zoom_rate);
    printf("zoom_x = %s<br>\n", var.zoom_x);
    printf("zoom_y = %s<br>\n", var.zoom_y);
    printf("level = %s<br>\n", var.level);
    printf("color = %s<br>\n", var.color);
    printf("effect = %s<br>\n", var.effect);
    printf("overlay = %s<br>\n", var.overlay);
    printf("anim = %d<br>\n", var.anim);
    printf("size = %d<br>\n", var.size);
    seq2time(var.seq_fc, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    printf("seq_fc = %d  (%04d.%02d.%02d.%02d:%02d)<br>\n", var.seq_fc, YY, MM, DD, HH, MI);
    seq2time(var.seq_ef, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    printf("seq_ef = %d  (%04d.%02d.%02d.%02d:%02d)<br>\n", var.seq_ef, YY, MM, DD, HH, MI);
    printf("dtm = %s<br>\n", var.dtm);
    printf("auto_man = %c<br>\n", var.auto_man);
    printf("mode = %c<br>\n", var.mode);
    printf("umove = %d<br>\n", var.umove);
    printf("fmove = %d<br>\n", var.fmove);
    printf("dmove = %d<br>\n", var.dmove);
    printf("bmove = %d<br>\n", var.bmove);
    printf("winnum = %d<br>\n", var.winnum);
    printf("rand = %d<br>\n", var.rand);

    return 0;
}

int print_time
(
    char *head
)
{
    int  YY, MM, DD, HH, min, sec;

    get_time(&YY, &MM, &DD, &HH, &min, &sec);
    printf(" %s : time = %04d.%02d.%02d.%02d:%02d (%02d)<br>\n",
            head, YY, MM, DD, HH, min, sec);
    return 0;
}

