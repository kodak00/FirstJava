/********************************************************************/
/*                                                                  */
/*  RADAR �ڷ� �׷��� �м��� CGI ���α׷�  (�̹��� ������ƾ)        */
/*                                                                  */
/********************************************************************/
#include "rdr_kma_stn_ech.h"
extern struct INPUT_VAR  var;

#define  Tail_pixel  25
#define  DEGRAD      3.1415927/180.0
#define  RADDEG      180.0/3.1415927
#define  MAXIMG      1024
#define  MAXRNG      1024

struct COLOR HSL2RGB();

float  echo[MAXIMG+1][MAXIMG+1];
float  dbz[31], vr_max;
float  rain[31] = {0.1, 0.2, 0.4, 0.6, 0.8, 1.0, 1.5, 2.0, 3.0, 4.0, 5.0,
                        6.0, 7.0, 8.0, 9.0,10.0,12.0,14.0,16.0,18.0,20.0,
                       25.0,30.0,35.0,40.0,50.0,60.0,70.0,80.0,90.0,100.0};
Radar  *radar;
Volume *volume;
Sweep  *sweep;
Ray    *ray;
int    seq_uf;

/*********************************************************************
 *
 *  ������ UF���̴��ڷḦ �����ڷ�� ��ȯ�Ͽ� �̹��� ����
 *
 *     - Return : ������ �̹����� ����
 *
 *********************************************************************/
int rdr_kma_stn_ech_img(uf_volume, uf_sweep, gname)

    float uf_volume[];      /* �ڷ����� */
    float uf_sweep[];       /* ������ */
    char  gname[][120];
{
    FILE  *fd;
    char  fname[120];
    int   YY, MM, DD, HH, min;
    int   r, first = 0, code;
    int   i, j, k, n = 0;

    /*---------------------------------------------------------------*/
    /* UF file open & volume,sweep check */

    printf("%s %04d.%02d.%02d.%02d:%02d......", var.data0,var.YY,var.MM,var.DD,var.HH,var.min);

    radar = RSL_uf_to_radar(var.fname);
    if (radar == NULL)
    {
        printf("error<br>\n");
        return -1;
    }
    else
    {
        printf("ok<br>\n");
    }

    /* UF ���ϳ� �ð� Ȯ�� (UTC) */
    YY = radar->h.year;
    MM = radar->h.month;
    DD = radar->h.day;
    HH = radar->h.hour;
    min= radar->h.minute;
    seq_uf = time2seq(YY, MM, DD, HH, min, 'm');

    /*---------------------------------------------------------------*/
    /* UF ���ϳ� ������ �������� �ľ�, range check �� �������� Ȯ�� */
    for (i = 0; i < MAX_VOLUME; i++) uf_volume[i] = -99;
    for (i = 0; i < MAX_SWEEP; i++) uf_sweep[i] = -99;

    if ((code = rdr_kma_stn_ech_inf_file(fname)) == 0)
    {
        fd = fopen(fname, "r");

        if (fd != NULL)
        {
            fscanf(fd, "%d %f", &(var.range), &(var.nyq_vel));
            for (i = 0; i < MAX_VOLUME; i++) fscanf(fd, "%f", &uf_volume[i]);
            for (i = 0; i < MAX_SWEEP;  i++) fscanf(fd, "%f", &uf_sweep[i]);
        }
        else
        {
            code = -9;
        }
        fclose(fd);
    }

    if (code != 0)
    {
        var.range = 10;

        for (i = 0; i < radar->h.nvolumes; i++)
        {
            if (i > 3) break;

            if ((volume = radar->v[i]) != NULL)
            {
                uf_volume[i] = volume->h.nsweeps;

                for (j = 0; j < volume->h.nsweeps; j++)
                {
                    if ((sweep = volume->sweep[j]) != NULL)
                    {
                        uf_sweep[j] = sweep->h.elev;
                        ray = RSL_get_first_ray_of_sweep(sweep);
                        r = (ray->h.nbins)*(ray->h.gate_size) + ray->h.range_bin1;
                        if (r > var.range) var.range = r;
                    }
                }

                if (i == VR_INDEX)
                {
                    ray = RSL_get_first_ray_of_volume(volume);
                    var.nyq_vel = ray->h.nyq_vel;
                }
            }
        }

        if (var.range < 20000) var.range = 240000;

        fd = fopen(fname,"w");
        if (fd != NULL)
        {
            fprintf(fd, "%d %f\n", var.range, var.nyq_vel);
            for (i = 0; i < MAX_VOLUME; i++) fprintf(fd, "%f\n", uf_volume[i]);
            for (i = 0; i < MAX_SWEEP;  i++) fprintf(fd, "%f\n", uf_sweep[i]);
        }
        fclose(fd);
    }

    /*---------------------------------------------------------------*/
    /*  �� ������ ��� ���� �̹��� ����  */

    if (var.ds2 == 99)
    {
        /* KiroLee : 2007.7.5
         * volume->sweep �޸𸮸� �Ҵ��ϴ� ���� ���� �̰����� �ӽ� ��ġ��
         * TODO: �߰� ���� ���� �ʿ��� 
         */ 
        volume = radar->v[0];    

        for (j = 0; j < volume->h.nsweeps; j++)
        {
            if ((sweep = volume->sweep[j]) != NULL)
            {
                var.ds2 = j;
                if (rdr_kma_stn_ech_img_file(gname[n]) < 0)
                {
                    code = rdr_kma_stn_ech_grd();
                    if (code == 0)
                    {
                        code = rdr_kma_stn_ech_img_make();
                    }
                    if (code == 0) n++;
                }
                else
                {
                    n++;
                }
            }
        }
        var.ds2 = 99;
    }
    /*---------------------------------------------------------------*/
    /*  �� ���� ��� ������ �̹��� ����  */

    else if (var.ds1 == 99)
    {
        for (i = 0; i < radar->h.nvolumes; i++)
        {
            if ((volume = radar->v[i]) != NULL)
            {
                var.ds1 = i;
                if ( rdr_kma_stn_ech_img_file(gname[n]) < 0 )
                {
                    code = rdr_kma_stn_ech_grd();
                    if (code == 0)
                    {
                        code = rdr_kma_stn_ech_img_make();
                    }
                    if (code == 0) n++;
                }
                else
                {
                    n++;
                }
            }
        }
        var.ds1 = 99;
    }
    /*---------------------------------------------------------------*/
    /*  �� ���� �� ������ �̹��� ����  */

    else
    {
        if ( rdr_kma_stn_ech_img_file(gname[n]) < 0 )
        {
            code = rdr_kma_stn_ech_grd();
            if (code == 0)
            {
                code = rdr_kma_stn_ech_img_make();
            }
            if (code == 0) n++;
        }
        else
        {
            n++;
        }
    }

    /*---------------------------------------------------------------*/
    RSL_free_radar(radar);

    return n;
}

/*********************************************************************
 *
 *  UF Radar data Read & Griding
 *
 *********************************************************************/
int rdr_kma_stn_ech_grd()
{
    int  first = 0;
    int  i, j, k;

    /*------------------------------------------------------------*/
    /* �ʱ�ȭ */

    for (j = 0; j <= MAXIMG; j++)
    {
        for (i = 0; i <= MAXIMG; i++) echo[j][i] = -999;
    }

    if ((volume = radar->v[var.ds1]) == NULL)
    {
        var.elev = -99;
        return 0;
    }
    if ((sweep = volume->sweep[var.ds2]) == NULL)
    {
        var.elev = -98;
        return 0;
    }
    var.elev = sweep->h.elev;

    /*------------------------------------------------------------*/
    /* ������ �����ڷ�� ��ȯ */

    for (j = 0; j < sweep->h.nrays; j++)
    {
        if ((ray = sweep->ray[j]) != NULL)
        {
            if (first == 0)
            {
                var.nbins = ray->h.nbins;
                var.gate_size = ray->h.gate_size;
                first = 1;
            }
            rdr_kma_stn_ray2grd(ray);
        }
    }

    /*------------------------------------------------------------*/
    /* grid data smoothing */

    if (var.effect == 'S') rdr_kma_stn_grd_sm();

    return 0;
}

/*==================================================================*
 *  1 Ray -> Griding
 *==================================================================*/
int rdr_kma_stn_ray2grd(ray)
    Ray *ray;
{
    double tn1, tn2;
    float  angle[3];
    float  cc, cr, cg, r, ec;
    int    area, ix, iy;
    int    i, j, k, i1, i2;

    /* ���� �� �������� */
    angle[1] = ray->h.azimuth;
    if (strcmp(var.data0,"IIA") == 0) angle[1] -= 7.53;
    if (angle[1] < 0.0) angle[1] += 360.0;

    area = ((int)angle[1]/45) % 8 + 1;

    if (angle[1] > 45.0)
    {
        angle[1] -= 45.0;
        angle[1] = fabs( angle[1] - ((int)angle[1]/90)*90 - 45.0 );
    }
    angle[0] = angle[1] - ray->h.beam_width - 0.1;
    angle[2] = angle[1] + ray->h.beam_width + 0.1;

    /* ��ǥ ��ȯ */
    cc = 2.0*(float)var.range/(float)var.size;
    cr = ray->h.range_bin1;
    cg = ray->h.gate_size;

    tn1 = tan(angle[0] * DEGRAD);
    tn2 = tan(angle[2] * DEGRAD);

    for (j = 1; j <= var.size/2; j++)
    {
        i1 = (int)(tn1 * j + 0.95);
        i2 = (int)(tn2 * j - 0.05);

        if (i2 >= i1)
        {
            for (i = i1; i <= i2; i++)
            {
                r = ( cc * sqrt(i*i + j*j) - cr ) / cg;
                k = (int)r;
                if (k < ray->h.nbins)
                {
                    switch (area)
                    {
                        case 1:  iy = 512 + j;  ix = 512 + i;  break;
                        case 2:  iy = 512 + i;  ix = 512 + j;  break;
                        case 3:  iy = 512 - i;  ix = 512 + j;  break;
                        case 4:  iy = 512 - j;  ix = 512 + i;  break;
                        case 5:  iy = 512 - j;  ix = 512 - i;  break;
                        case 6:  iy = 512 - i;  ix = 512 - j;  break;
                        case 7:  iy = 512 + i;  ix = 512 - j;  break;
                        case 8:  iy = 512 + j;  ix = 512 - i;
                    }
                    ec = ray->h.f(ray->range[k]);
                    if (ec > 1000.0) ec = -990;
                    if (echo[iy][ix] < ec) echo[iy][ix] = ec;
                }
            }
        }
    }
    return 0;
}

/*==================================================================*
 *  Grid data Smoothing (by 1-2-1 Smoothing)
 *==================================================================*/
int rdr_kma_stn_grd_sm()
{
    float  e[4], e1, e2;
    int    s1, s2;
    int    i, j, k;

    s1 = 512 - var.size/2;
    s2 = 512 + var.size/2;

    for (k = 0; k < 2; k++)
    {
        for (j = s1; j < s2; j++)
        {
            e1 = echo[j][s1];
            e[0] = echo[j][s1];
            e[1] = echo[j][s1+1];

            for (i = s1+1; i < s2; i++)
            {
                e[2] = echo[j][i+1];
                if (e[0] > -50 && e[1] > -50 && e[2] > -50) {
                    e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
                } else if (e[0] > -50 && e[1] <= -50 && e[2] > -50) {
                    e2 = (e[0] + e[2]) * 0.5;
                } else {
                    e2 = e[1];
                }
                echo[j][i-1] = e1;
                e1 = e2;
                e[0] = e[1];
                e[1] = e[2];
            }
            echo[j][i-1] = e1;
        }

        for (i = s1; i < s2; i++)
        {
            e1 = echo[s1][i];
            e[0] = echo[s1][i];
            e[1] = echo[s1+1][i];

            for (j = s1+1; j < s2; j++)
            {
                e[2] = echo[j+1][i];
                if (e[0] > -50 && e[1] > -50 && e[2] > -50) {
                    e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
                } else if (e[0] > -50 && e[1] <= -50 && e[2] > -50) {
                    e2 = (e[0] + e[2]) * 0.5;
                } else {
                    e2 = e[1];
                }
                echo[j-1][i] = e1;
                e1 = e2;
                e[0] = e[1];
                e[1] = e[2];
            }
            echo[j-1][i] = e1;
        }
    }
    return 0;
}

/*********************************************************************
 *
 *  ���̴� ������ �̹��� ���� ���
 *
 *********************************************************************/
int rdr_kma_stn_ech_img_make()
{
    FILE   *fd;
    char   gname[64], dname[120];
    gdImagePtr im;
    int    color[256];
    float  range, zoom_rate;
    int    len, bgmap = 0, ovr = 1, code;
    int    i, j, k;

    /* image size */
    var.NI = var.size % MAXIMG;
    var.NJ = var.size % MAXIMG;
    var.GI = var.NI + LVL_pixel + LEG_pixel;
    var.GJ = var.NJ + TTL_pixel + END_pixel;

    /* gd alloc. */
    if (strcmp(var.overlay, "N") == 0)
    {
        im = gdImageCreate(var.GI+1, var.GJ+1);
    }
    else
    {
        if (rdr_kma_stn_topo_img_file(dname) == 0)
        {
            if ((fd = fopen(dname, "rb")) != NULL)
            {
                im = gdImageCreateFromPng(fd);
                fclose(fd);
                ovr = 0;
            }
            else
            {
                im = gdImageCreate(var.GI+1, var.GJ+1);
            }
        }
        else
        {
            im = gdImageCreate(var.GI+1, var.GJ+1);
        }
    }

    /* color table */
    if (color_table(im, color) < 0)
    {
        gdImageDestroy(im);
        return -1;
    }

    if (ovr) gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color[252]);

    /* data display */
    rdr_kma_stn_ech_disp(im, color);

    /* map draw */
    map_draw(im, color, 1000, 0.001*(float)var.range, (float)var.size/(2.0*0.001*var.range));

    /* ���ü� & ��輱 */
    range_disp(im, color);

    /* title display */
    title_disp(im, color);

    /* level table display */
    level_disp(im, color);

    /* file write */
    if ( rdr_kma_stn_ech_img_file(gname) < 0 )
    {
        if ( (fd = fopen(gname, "wb")) == NULL )
        {
            gdImageDestroy(im);
            return -1;
        }
        else
        {
            gdImagePng(im, fd);
            fclose(fd);
        }
    }
    gdImageDestroy(im);
    return 0;
}

/*==================================================================*
 *  Color Table
 *==================================================================*/
int color_table(im, color)

    gdImagePtr im;
    int    color[];
{
    FILE  *fd;
    char  fname[120];
    int   num_colors;
    int   R, G, B, i;

    /*------------------------------------------------------------*/

    if (var.ds1 == 1)       /* VR */
    {
        if (var.color == 'E') sprintf(fname,"%s/color_VR_E.rgb", COLOR_DIR);
        else                  sprintf(fname,"%s/color_VR_C.rgb", COLOR_DIR);
    }
    else                    /* DZ,CZ,SW */
    {
        if      (var.color == 'E') sprintf(fname,"%s/color_rain_E.rgb", COLOR_DIR);
        else if (var.color == 'C') sprintf(fname,"%s/color_rain_C.rgb", COLOR_DIR);
        else                       sprintf(fname,"%s/color_rain_R.rgb", COLOR_DIR);
    }

    fd = fopen(fname,"r");
    if (fd == NULL) return -1;

    fscanf(fd, "%d", &num_colors);

    for (i = 0; i < num_colors; i++)
    {
        fscanf(fd, "%d %d %d", &R, &G, &B);
        color[i] = gdImageColorAllocate(im, R, G, B);
    }
    fclose(fd);

    /*------------------------------------------------------------*/
    /* other color */

    color[240] = gdImageColorAllocate(im, 255,   0,   0);   /* ���̴��� */
    color[241] = gdImageColorAllocate(im, 128,  64,   0);   /* ����     */
    color[242] = gdImageColorAllocate(im,   0,   0, 128);   /* ����     */
    color[248] = gdImageColorAllocate(im,  51,  51,  51);   /* �ؾȼ�   */
    color[249] = gdImageColorAllocate(im, 128, 128, 128);   /* ������� */
    color[250] = gdImageColorAllocate(im, 119, 119, 119);   /* ���浵�� */
    color[251] = gdImageColorAllocate(im, 192, 192, 192);   /* NO area  */
    color[252] = gdImageColorAllocate(im, 234, 234, 234);   /* NO data  */
    color[253] = gdImageColorAllocate(im, 245, 245, 245);   /* NO rain  */
    color[254] = gdImageColorAllocate(im,   0,   0,   0);   /* ������   */
    color[255] = gdImageColorAllocate(im, 255, 255, 255);   /* white    */

    return 0;
}

/*==================================================================*
 *
 *  Radar grid data display
 *
 *==================================================================*/
int rdr_kma_stn_ech_disp(im, color)

    gdImagePtr im;
    int    color[];
{
    int    c1;
    int    i, j, i1, j1;
    float  x, y, r, rmax = (float)var.size*0.5;

    /* ������ �ܰ�� ǥ���ϱ� ���Ͽ� �����Ǵ� DBZ �ܰ谪 ��� */
    if (var.ds1 == 0 || var.ds1 == 3)
    {
        for (i = 0; i <= 30; i++) dbz[i] = 10.0*log10(200.0) + 16.0*log10(rain[i]);
    }

    /* VR ���� ���� */
    if (var.ds1 == 1)
    {
        if      (var.nyq_vel <  5) vr_max = 3.75;
        else if (var.nyq_vel <  9) vr_max = 7.5;
        else if (var.nyq_vel < 17) vr_max = 15.0;
        else if (var.nyq_vel < 34) vr_max = 30.0;
        else                       vr_max = 60.0;
    }

    /* ���̴� �̹��� ���� */
    for (j = 0; j <= var.size; j++)
    {
        j1 = (MAXIMG - var.size)/2 + j;
        y = j - rmax;

        for (i = 0; i <= var.size ; i++)
        {
            i1 = (MAXIMG - var.size)/2 + i;
            x = i - rmax;

            r = sqrt(x*x + y*y);
            c1 = level_color(echo[j1][i1]);
//            if (c1 == 253 && r > rmax) c1 = 254;
            gdImageSetPixel(im, i, var.GJ-j-END_pixel, color[c1]);
        }
    }
    return 0;
}

/*==================================================================*
 *  Color of level
 *==================================================================*/
int level_color(v)

    float v;
{
    int  c = 31, i;

    if      (v < -990) c = 251;		/* NO area */
    else if (v <  -50) c = 252;		/* NO data */
    else
    {
        switch (var.ds1)
        {
            case 0:  case 3:
                for (i = 0; i <= 30; i++)
                {
                    if (v < dbz[i])
                    {
                        c = i;
                        break;
                    }
                }
                break;
            case 1:
                c = (int)(15.0*(v + vr_max)/vr_max) + 1;
                if      (c <  0) c = 0;
                else if (c > 31) c = 31;
                break;
            case 2:
                c = (int)(v/0.3);
                if      (c <  0) c = 0;
                else if (c > 31) c = 31;
                break;
        }
    }
    return c;
}

/*==================================================================*
 *  GIS data display
 *===================================================================*/
int map_draw(im, color, mode, range, zoom_rate)

    gdImagePtr im;
    int    color[];
    int    mode;
    float  range;
    float  zoom_rate;
{
    FILE   *fd;
    char   fname[120];
    int    num, code, ibuf[2];
    float  buf[2];
    float  xo = 500.0 - range, yo = 500.0 - range;
    float  x1, y1, x2, y2, x, y;
    int    map_color;
    int    ix1, iy1, ix2, iy2;
    int    i, j, k = 0;
    int    ymd; // by kirolee

    /* Per Map data */
    for (j = 1; j <= 4; j++)
    {
        if (mode % 10 == 1)
        {
            if      (j == 1) map_color = color[249];    /* ������� */
            else if (j == 2) map_color = color[242];    /* ����     */
            else if (j == 3) map_color = color[241];    /* ����     */
            else if (j == 4) map_color = color[248];    /* �ؾȼ�   */

			/* �̰���(����)���� ó�� : 2008.07.11 �̱�� */
			ymd = var.YY*10000 + var.MM*100 + var.DD;
			if (!strcmp(var.data0, "RKSG") && ymd >= 20071115) {
				sprintf(fname, "%s/RDR_%s_%d_20071115.bln", MAP_DIR, var.data0, j);
			} else {
    	        sprintf(fname, "%s/RDR_%s_%d.bln", MAP_DIR, var.data0, j);
	        }
            if ( (fd = fopen(fname, "rb")) == NULL ) continue;

            while (fread(ibuf, sizeof(int), 2, fd) > 0)
            {
                num  = ibuf[0];
                code = ibuf[1];

                fread(buf, sizeof(float), 2, fd);
                ix1 = (int)(zoom_rate * ( buf[0] - xo ));
                iy1 = var.NJ + TTL_pixel - (int)(zoom_rate * ( buf[1] - yo ));

                for (i = 1; i < num; i++)
                {
                    fread(buf, sizeof(float), 2, fd);

                    ix2 = (int)(zoom_rate * ( buf[0] - xo ));
                    iy2 = var.NJ + TTL_pixel - (int)(zoom_rate * ( buf[1] - yo ));
                    gdImageLine(im, ix1, iy1, ix2, iy2, map_color);

                    ix1 = ix2;
                    iy1 = iy2;
                }
            }
            fclose(fd);
        }
        mode /= 10;
    }
    return 0;
}

/*==================================================================*
 *  ���ü�
 *==================================================================*/
int range_disp(im, color)

    gdImagePtr im;
    int color[];
{
    int    xo = var.size/2, yo = var.size/2 + TTL_pixel;	/* ���̴���ġ */
    int    x, y;
    float  r;
    int    i;

    /* 100km ���� �� */
    for (i = 100; i <= 500; i += 100)
    {
        r = (float)(var.size*i)/(float)(0.001*var.range);
        gdImageArc(im, xo, yo, (int)r, (int)r, 0, 360, color[241]);
    }
    r = var.size;
    gdImageArc(im, xo, yo, (int)r, (int)r, 0, 360, color[240]);

    /* 45�� �������� ���м� */
    for (i = 0; i < 360; i += 45)
    {
        x = (int)( r * cos(i*DEGRAD) ) + xo;
        y = (int)( r * sin(i*DEGRAD) ) + yo;
        gdImageLine(im, xo, yo, x, y, color[241]);
    }

    /* ���̴� ���� ǥ�� */
    gdImageFilledRectangle(im, xo-3, yo-3, xo+3, yo+3, color[240]);
    return 0;
}

/*==================================================================*
 *  TITLE display
 *==================================================================*/
int title_disp(im, color)

    gdImagePtr im;
    int color[];
{
    int   YY, MM, DD, HH, min;
    char  text[64], text2[32];
    char  volum_name[19][3] = {"DZ","VR","SW","CZ","ZT","DR","LR","ZD","DM","RH","PH",
                               "XZ","CR","MZ","MR","ZE","VE","KD","TI"};

    gdImageFilledRectangle(im, 0, 0, var.GI, TTL_pixel, color[255]);

    seq2time(seq_uf+9*60, &YY, &MM, &DD, &HH, &min, 'm', 'n');
    sprintf(text, "RADAR %s %04d.%02d.%02d.%02d:%02d (%s:%.2f)",
                   var.data0, YY, MM, DD, HH, min,
                   volum_name[var.ds1], var.elev);

    if (var.NI < 290)
        gdImageString(im, gdFontSmall, 5, 1, (unsigned char *)text, color[254]);
    else
        gdImageString(im, gdFontLarge, 5, 0, (unsigned char *)text, color[254]);

    return 0;
}

/*==================================================================*
 *  Level display
 *==================================================================*/
int level_disp(im, color)

    gdImagePtr im;
    int color[];
{
    char  text[126];
    float dy, y1, y2, v1;
    int   i, j, jc, c;

    jc = 31;
    dy = (float)var.NJ / (float)(jc + 1);

    /* level color display */
    y2 = var.GJ - END_pixel;
    for (j = 0; j <= jc; j++)
    {
        y1 = y2 - dy;
        gdImageFilledRectangle(im, var.NI, (int)y1, var.NI+LEG_pixel, (int)y2, color[j]);
        y2 = y1;
    }
    gdImageFilledRectangle(im, var.NI+LEG_pixel+1, 0, var.GI, var.GJ, color[255]);
    gdImageRectangle(im, 0, TTL_pixel, var.NI, var.GJ, color[254]);
    gdImageRectangle(im, 0, TTL_pixel, var.NI+LEG_pixel, var.GJ, color[254]);

    /* level text & unit display */

    for (j = 0; j < jc; j++)
    {
        switch (var.ds1)
        {
            case 0:  case 3:
                if (rain[j] < 10)
                    sprintf(text, "%.1f", rain[j]);
                else
                    sprintf(text, "%d", (int)rain[j]);
                break;
            case 1:
                v1 = vr_max * j / 15.0 - vr_max;
                if (vr_max > 10)
                    sprintf(text, "%.0f", v1);
                else
                    sprintf(text, "%.2f", v1);
                break;
            case 2:
                sprintf(text, "%.1f", j*0.3);  break;
            default:
                sprintf(text, " ");
        }
        y1 = var.GJ - END_pixel - dy*((float)j+1.5);
        if (var.ds1 == 1 || var.size < 310)
            gdImageString(im, gdFontTiny, var.NI+LEG_pixel+2, (int)y1, (unsigned char *)text, color[254]);
        else
            gdImageString(im, gdFontSmall, var.NI+LEG_pixel+2, (int)y1, (unsigned char *)text, color[254]);
    }

    switch (var.ds1)
    {
        case 0:  strcpy(text, "mm/h");   break;
        case 1:  strcpy(text, "m/s");    break;
        case 2:  strcpy(text, "m/s");    break;
        case 3:  strcpy(text, "mm/h");   break;
    }
    gdImageString(im, gdFontSmall, var.NI+LEG_pixel-1, 1, (unsigned char *)text, color[254]);

    /* data information display */
    gdImageFilledRectangle(im, 0, var.NJ+TTL_pixel, var.GI, var.GJ, color[255]);
    if (var.size < 400)
        sprintf(text, "Width: %dm  Gates: %d#  Range: %dkm  Nyq: %.2fm/s",
                var.gate_size, var.nbins, var.range/1000, var.nyq_vel);
    else
        sprintf(text, "Gatewidth: %dm   Gates: %d#   Max.Range: %dkm  Nyq.Vel: %.2f",
                var.gate_size, var.nbins, var.range/1000, var.nyq_vel);
    gdImageString(im, gdFontSmall, 8, var.NJ+TTL_pixel+2, (unsigned char *)text, color[254]);

    gdImageRectangle(im, 0, var.NJ+TTL_pixel, var.NI+LEG_pixel, var.GJ, color[254]);
    return 0;
}
