#include "input_head.h"
#include "input_var.h"
#include "rsl.h"

#define  RDR_DIR    "/DATA/RDR/PCP"
#define  WEB_DIR    "/www/mis/web"
#define  IMG_DIR1   "/www/mis/web/tmp/rdr"
#define  IMG_DIR2   IMG_DIR1
#define  MAP_DIR    "/www/mis/cgi-bin/REF/bln"
#define  COLOR_DIR  "/www/mis/cgi-bin/REF/color"
#define  CGI_DIR    "/cgi-bin/rdr"
#define  INC_DEC    "/www/mis/cgi-src/include/input_decode.inc"

#define  RDR_KMA_STN_NUM  10
