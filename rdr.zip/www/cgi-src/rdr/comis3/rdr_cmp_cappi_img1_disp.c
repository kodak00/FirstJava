/*******************************************************************************
**
**  ���̴� CAPPI/PPI �ռ��ڷ� ǥ��� CGI ���α׷�  (�̹��� ������ƾ)
**
**=============================================================================*
**
**     o �� �� �� : ����ȯ (2004.7.1)
**     o �� �� �� : ����ȯ (2005.5.12)
**
********************************************************************************/
#include "rdr_cmp_cappi_img.h"

extern struct INPUT_VAR  var;

#define  BLANK1  -30000     /* No Area */
#define  BLANK2  -25000     /* No Data */
#define  BLANK3  -20000     /* Minimum Data */
#define  MX  NX_B
#define  MY  NY_B

int    MI, MJ;

float  rain_min=0.05, dbz_min = -50;    /* ȭ�鿡 ǥ���� �ּ� ������(mm/h) �� DBZ �� (default=-50) */
float  dbz[31];
float  rain[31] = {0.1, 0.2, 0.4, 0.6, 0.8, 1.0, 1.5, 2.0, 3.0, 4.0, 5.0,
                        6.0, 7.0, 8.0, 9.0,10.0,12.0,14.0,16.0,18.0,20.0,
                       25.0,30.0,35.0,40.0,50.0,60.0,70.0,80.0,90.0,100.0};

int level_color(float);

/*******************************************************************************
 *
 *  ���̴� CAPPI/PPI �ռ��ڷ� �̹��� ���� ��ƾ
 *
 *******************************************************************************/
int rdr_cmp_img_make()
{
    gdImagePtr im;
    FILE   *fd;
    char   gname[120];
    float  **DATA;
    float  min_v = dbz_min, max_v = 0;
    int    zx, zy, ox, oy, zlevel, nx, pixel_km, mode;
    int    color[256];
    int    line_depth = 0;  /* 0:�Ǽ�, 1+:�� ���� */
    int    i, j, k;

    /* Data Read */

    var.NI = var.size;
    var.NJ = var.size;

    switch (var.area)
    {
        case 'E':  MI=NX_E;  MJ=NY_E;  break;
        case 'R':  MI=NX_R;  MJ=NY_R;  break;
        case 'F':  MI=NX_F;  MJ=NY_F;  break;
    }
    var.rate = (float)MI / (float)var.NI;

    var.GI = var.NI + LEG_pixel + LVL_pixel;
    var.GJ = var.NJ + TTL_pixel;

    DATA = matrix(0, MJ, 0, MI);
    rdr_cmp_read(DATA);

    /* Smoothing */

    for (zlevel = 0, nx = var.NI, i = 0; i < 7; i++, zlevel++, nx *= 2)
    {
        if (var.zoom[i] == '0' || var.zoom[i+8] == '0') break;
    }
    pixel_km = (int)((float)MI/(float)nx) - 1;

    for (i = 0; i <= pixel_km; i++)
        grid_smooth(DATA, MI, MJ, min_v);

    /* Zoom */

    if (var.effect == 'X')
        mode = 0;
    else
        mode = 1;

    for (i = 0; i < 7; i++)
    {
        zx = var.zoom[i] - '0';
        zy = var.zoom[i+8] - '0';
        if (zx == 0 || zy == 0) break;

        ox = MI/8*(zx-1);
        oy = MJ/8*(5-zy);

        grid_zoom(DATA, MI, MJ, ox, oy, min_v, mode);
    }

    /* Gd Alloc. & Color Table  */

    im = gdImageCreate(var.GI+1, var.GJ+1);
    color_table(im, color);
    gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color[251]);

    /* Data Display */

    data_disp(DATA, im, color);
    free_matrix(DATA, 0, MJ, 0, MI);

    /* GIS overlay */

    if (var.area == 'E') zlevel++;
    if (zlevel > 2) line_depth = 1;

    if (zlevel >= 4 && var.overlay[2] == 'A') map_draw(im, var.NI, var.area, var.zoom, 1, 0, color[249]);
    if (zlevel >= 2 && var.overlay[1] == 'H') map_draw(im, var.NI, var.area, var.zoom, 3, line_depth, color[241]);
    if (zlevel >= 2 && var.overlay[0] == 'R') map_draw(im, var.NI, var.area, var.zoom, 2, line_depth, color[242]);
    map_draw(im, var.NI, var.area, var.zoom, 4, line_depth, color[248]);

    latlon_lamc(im, var.NI, var.area, var.zoom, color[250]);

    /* AWS 15��*4 ������ ��ø */

    if (var.overlay[4] == 'P' && var.zoom_level > 0) aws_rain_overlay(im, color);

    /* Title */

    title_disp(im, color);

    /* Level */

    level_disp(im, color);

    /* File Write */

    if (rdr_cmp_img_check(gname) > 0)
    {
        if ( (fd = fopen(gname, "wb")) == NULL )
        {
            gdImageDestroy(im);
            return -1;
        }
        else
        {
            gdImagePng(im, fd);
            fclose(fd);
        }
    }
    gdImageDestroy(im);

    return 0;
}

/*******************************************************************************
 *  ���̴� CAPPI/PPI �ռ��ڷ� ����
 *******************************************************************************/
int rdr_cmp_read(float **DATA)
{
    FILE   *fd;
    short  buf[MX+1];
    char   head[720];
    int    x1, y1, x2, y2, x3, y3, nskip, nuse;
    int    i, j, k, n;

    /* ó���� ���� ���� */

    switch (var.area)
    {
        case 'E':  x1=SX_B-SX_E;  y1=SY_B-SY_E;  break;
        case 'R':  x1=SX_B-SX_R;  y1=SY_B-SY_R;  break;
        case 'F':  x1=SX_B-SX_F;  y1=SY_B-SY_F;  break;
    }
    x2 = x1;
    y2 = y1;
    x3 = x1 + MI;
    y3 = y1 + MJ;
    if (x2 < 0) x2 = 0;
    if (y2 < 0) y2 = 0;
    if (x3 > MX) x3 = MX;
    if (y3 > MY) y3 = MY;

    nskip = (atoi(var.data1)/10 - 1)*2;
    if (atoi(var.data1)%10 == 2) nskip++;

    nuse = 1;
    if (atoi(var.data1)%10 == 0) nuse = 2;

    /* �ʱ�ȭ */

    for (j = 0; j < MJ; j++)
    {
        for (i = 0; i < MI; i++) DATA[j][i] = BLANK1;
    }

    /* File Open */

    fd = gzopen(var.fname, "rb");

    /* Data Read */

    n = gzread(fd, head, 720);

    for (k = 0; k < nskip; k++)
    {
        for (j = 0; j <= MY; j++) n = gzread(fd, buf, (MX+1)*2);
    }

    for (j = 0; j <= MY; j++)
    {
        n = gzread(fd, buf, (MX+1)*2);

        if (j >= y2 && j <= y3)
        {
            for (i = x2; i <= x3; i++) DATA[j-y1][i-x1] = buf[i];
        }
    }

    if (nuse == 2)
    {
        for (j = 0; j <= MY; j++)
        {
            n = gzread(fd, buf, (MX+1)*2);

            if (j >= y2 && j <= y3)
            {
                for (i = x2; i <= x3; i++)
                {
                    if (DATA[j-y1][i-x1] < buf[i]) DATA[j-y1][i-x1] = buf[i];
                }
            }
        }
    }

    /* File Close */

    gzclose(fd);

    return 0;
}

/*******************************************************************************
 *  data display
 *******************************************************************************/
int data_disp(DATA, im, color)
    float  **DATA;
    gdImagePtr im;
    int    color[];
{
    float  p, p1, p2;
    float  xx, yy, dx, dy;
    int    ix, iy;
    int    c;
    int    i, j;

    /* ������ �ܰ�� ǥ���ϱ� ���Ͽ� �����Ǵ� DBZ �ܰ谪 ��� */

    if (var.ds1 == 0 || var.ds1 == 3)
    {
        for (i = 0; i <= 30; i++) dbz[i] = (10.0*log10(200.0) + 16.0*log10(rain[i])) * 100;
    }
    dbz_min = (10.0*log10(200.0) + 16.0*log10(rain_min)) * 100;

    /* ���̴� �ռ��ڷ� �̹��� ���� */

    for (j = 0; j < var.NJ; j++)
    {
        yy = (float)j * var.rate;
        iy = (int)yy;
        dy = yy - (float)iy;

        for (i = 0; i < var.NI; i++)
        {
            xx = (float)i * var.rate;
            ix = (int)xx;
            dx = xx - (float)ix;

            if (var.effect == 'X')
            {
                c = level_color(DATA[iy][ix]);
            }
            else
            {
                p1 = DATA[iy][ix]*(1.0-dx) + DATA[iy][ix+1]*dx;
                p2 = DATA[iy+1][ix]*(1.0-dx) + DATA[iy+1][ix+1]*dx;
                p = p1*(1.0-dy) + p2*dy;
                c = level_color(p);
            }
            gdImageSetPixel(im, i, var.NJ+TTL_pixel-j, color[c]);
        }
    }
    return 0;
}

/*============================================================================*
 *  Color of level
 *============================================================================*/
int level_color(float v)
{
    int  c = 31, i;

    if      (v < BLANK2) c = 251;		/* NO area */
    else if (v < dbz_min) c = 252;		/* NO data */
    else
    {
        c = 31;
        for (i = 0; i <= 30; i++)
        {
            if (v < dbz[i])
            {
                c = i;
                break;
            }
        }
    }
    return c;
}

/*******************************************************************************
 *  AWS 15��*4 ������ ��ø
 *******************************************************************************/
int aws_rain_overlay(im, color)
    gdImagePtr im;
    int color[];
{
    FILE   *fd;
    struct lamc_parameter  map;
    struct STN_AWS  stn_aws;
    struct AWS_DATA aws;
    char   buf[1000];
    float  lon, lat, x1, y1;
    float  map_rate, zm = 1, xo = 0, yo = 0;
    int    map_MI, map_MJ, map_SX, map_SY;
    int    zlevel = var.zoom_level;
    int    YY, MM, DD, HH, min, now;
    int    zx, zy, ok, i;

    if (var.area == 'E') zlevel++;

    /* Zooming rate */

    switch (var.area)
    {
        case 'G':  map_MI=NX_G;  map_MJ=NY_G;  map_SX=SX_G;  map_SY=SY_G;  break;
        case 'D':  map_MI=NX_D;  map_MJ=NY_D;  map_SX=SX_D;  map_SY=SY_D;  break;
        case 'E':  map_MI=NX_E;  map_MJ=NY_E;  map_SX=SX_E;  map_SY=SY_E;  break;
        case 'R':  map_MI=NX_R;  map_MJ=NY_R;  map_SX=SX_R;  map_SY=SY_R;  break;
        case 'F':  map_MI=NX_F;  map_MJ=NY_F;  map_SX=SX_F;  map_SY=SY_F;  break;
        case 'W':  map_MI=NX_W;  map_MJ=NY_W;  map_SX=SX_W;  map_SY=SY_W;  break;
        case 'V':  map_MI=NX_V;  map_MJ=NY_V;  map_SX=SX_V;  map_SY=SY_V;  break;
        case 'J':  map_MI=NX_J;  map_MJ=NY_J;  map_SX=SX_J;  map_SY=SY_J;  break;
        case 'A':  map_MI=NX_A;  map_MJ=NY_A;  map_SX=SX_A;  map_SY=SY_A;  break;
        case 'B':  map_MI=NX_B;  map_MJ=NY_B;  map_SX=SX_B;  map_SY=SY_B;  break;
    }
    map_rate = (float)map_MI / (float)var.size;

    for (i = 0; i < 7; i++)
    {
        zx = var.zoom[i] - '0';
        zy = var.zoom[i+8] - '0';
        if (zx == 0 || zy == 0) break;

        xo += (int)((float)map_MI/8.0*(zx-1)/(float)zm);
        yo += (int)((float)map_MJ/8.0*(5-zy)/(float)zm);
        zm *= 2;
    }
    zm /= map_rate;

    /* Map Projection Parameter */

    map.Re    = 6371.00877;
    map.slat1 = 30.0;
    map.slat2 = 60.0;
    map.olon  = 126.0;
    map.olat  = 38.0;
    map.grid  = 1.0 / zm;
    map.xo = (map_SX - xo) / map.grid;
    map.yo = (map_SY - yo) / map.grid;
    map.first = 0;

    /* ������ ǥ�� */

    fd = fopen(AWS_INF_FILE, "r");
    if (fd == NULL) return -1;

    now = ((var.YY*100 + var.MM)*100 + var.DD)*100 + var.HH;

    while (fgets(buf,1000,fd) != NULL)
    {
        str2stn_aws(buf, &stn_aws);
        if (stn_aws.stn_sp[0] == 'Z') continue;     /* ����� �ݵ�� ���� */
        if (stn_aws.tm_st > now || stn_aws.tm_ed <= now) continue;

        ok = 0;
        if (zlevel >= 1 && stn_aws.stn_sp[0] == '4') ok = 1;
        if (zlevel >= 2 && stn_aws.stn_sp[0] == '3') ok = 1;
        if (zlevel >= 3) ok = 1;

        if (ok == 0) continue;

        lon = stn_aws.lon;
        lat = stn_aws.lat;

        lamcproj(&lon, &lat, &x1, &y1, 0, map);

        if (x1 > 10 && x1 < var.size-10 && y1 > 10 && y1 < var.GJ-TTL_pixel-10)
        {
            seq2time(var.seq+10, &YY, &MM, &DD, &HH, &min, 'm', 'n');

            if (QAWSM_READ(YY, MM, DD, HH, min, (int)(stn_aws.stn_id), &aws, 'r') >= 0)
            {
                if (aws.d[24] >= 0)
                {
/*                    gdImageFilledRectangle(im, (int)x1-1, (int)(var.GJ-y1-1), (int)x1+1, (int)(var.GJ-y1+1), color[240]);*/

                    sprintf(buf, "%.1f", aws.d[24]*0.4);
                    x1 -= 8.0*(strlen(buf)-2);
                    y1 += 10;

                    gdImageString(im, gdFontMediumBold, (int)x1, (int)(var.GJ-y1), (unsigned char *)buf, color[254]);
                }
            }
        }
    }
    fclose(fd);

    return 0;
}

/*******************************************************************************
 *  TITLE display
 *******************************************************************************/
int title_disp(im, color)
    gdImagePtr im;
    int color[];
{
    char  head[32], text[64];
    int   YY, MM, DD, HH, min;

    seq2time(var.seq, &YY, &MM, &DD, &HH, &min, 'm', 'n');
    gdImageFilledRectangle(im, 0,  0, var.GI, TTL_pixel, color[255]);

    if      (var.data1[0] == '1') strcpy(head, "CAPPI");
    else if (var.data1[0] == '2') strcpy(head, " CMAX");
    else if (var.data1[0] == '3') strcpy(head, " PPI0");

    if      (var.data1[1] == '0') strcat(head, "   ");
    else if (var.data1[1] == '1') strcat(head, "(C)");
    else if (var.data1[1] == '2') strcat(head, "(S)");

    sprintf(text, "RDR %s  < %04d.%02d.%02d.%02d:%02d >", head, YY, MM, DD, HH, min);

    gdImageString(im, gdFontSmall, 5, 1, (unsigned char *)text, color[254]);

    return 0;
}


/*******************************************************************************
 *  Level display
 *******************************************************************************/
int level_disp(im, color)
    gdImagePtr im;
    int color[];
{
    char  text[126];
    float dy, y1, y2;
    int   i, j, jc, c;

    jc = 31;
    dy = (float)var.NJ / (float)(jc + 1);

    /* level color display */
    y2 = TTL_pixel + var.NJ;

    for (j = 0; j <= jc; j++)
    {
        y1 = y2 - dy;

        gdImageFilledRectangle(im, var.NI, (int)y1, var.NI+LEG_pixel, (int)y2, color[j]);
        y2 = y1;
    }
    gdImageRectangle(im, var.NI, TTL_pixel, var.NI+LEG_pixel, TTL_pixel+var.NJ, color[254]);

    /* level value */
    gdImageFilledRectangle(im, var.NI+LEG_pixel+1, 0, var.NI+LVL_pixel+LEG_pixel, TTL_pixel+var.NJ+END_pixel, color[255]);

    for (j = 0; j < jc; j++)
    {
        y1 = TTL_pixel + var.NJ - dy*((float)j+1.5);

        if (rain[j] < 10) sprintf(text, "%.1f", rain[j]);
        else              sprintf(text, "%d", (int)rain[j]);

        if (var.ds1 == 1 || var.size < 310)
            gdImageString(im, gdFontTiny, var.NI+LEG_pixel+2, (int)y1, (unsigned char *)text, color[254]);
        else
            gdImageString(im, gdFontSmall, var.NI+LEG_pixel+2, (int)y1, (unsigned char *)text, color[254]);
    }

    /* unit */
    strcpy(text, "mm/h");
    gdImageString(im, gdFontSmall, var.NI+LEG_pixel+1, 1, (unsigned char *)text, color[254]);

    /* data display area box */
    gdImageRectangle(im, 0, TTL_pixel, var.NI, var.NJ+TTL_pixel, color[254]);

    return 0;
}

/*============================================================================*
 *  Color Table
 *============================================================================*/
int color_table(im, color)

    gdImagePtr im;
    int    color[];
{
    FILE  *fd;
    char  fname[120];
    int   num_colors;
    int   R, G, B, i;

    /*------------------------------------------------------------------------*/

    if      (var.color == 'E') sprintf(fname,"%s/color_rain_E.rgb", COLOR_DIR);
    else if (var.color == 'C') sprintf(fname,"%s/color_rain_C.rgb", COLOR_DIR);
    else                       sprintf(fname,"%s/color_rain_R.rgb", COLOR_DIR);

    fd = fopen(fname,"r");
    if (fd == NULL) return -1;

    fscanf(fd, "%d", &num_colors);

    for (i = 0; i < num_colors; i++)
    {
        fscanf(fd, "%d %d %d", &R, &G, &B);
        color[i] = gdImageColorAllocate(im, R, G, B);
    }
    fclose(fd);

    /*------------------------------------------------------------------------*/
    /* other color */

    color[240] = gdImageColorAllocate(im, 255,   0,   0);   /* ���̴��� */
    color[241] = gdImageColorAllocate(im, 128,  64,   0);   /* ����     */
    color[242] = gdImageColorAllocate(im,   0,   0, 128);   /* ����     */
    color[248] = gdImageColorAllocate(im,  28,  28,  28);   /* �ؾȼ�   */
    color[249] = gdImageColorAllocate(im, 128, 128, 128);   /* ������� */
    color[250] = gdImageColorAllocate(im, 119, 119, 119);   /* ���浵�� */
    color[251] = gdImageColorAllocate(im, 192, 192, 192);   /* NO area  */
    color[252] = gdImageColorAllocate(im, 234, 234, 234);   /* NO data  */
    color[253] = gdImageColorAllocate(im, 245, 245, 245);   /* NO rain  */
    color[254] = gdImageColorAllocate(im,   0,   0,   0);   /* ������   */
    color[255] = gdImageColorAllocate(im, 255, 255, 255);   /* white    */

    return 0;
}
