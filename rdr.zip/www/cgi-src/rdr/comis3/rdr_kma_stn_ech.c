/******************************************************************************
**
**  UF RADAR �ڷ� �׷��� �м��� CGI ���α׷�
**
**============================================================================*
**
**     o �ۼ��� : ����ȯ (2000. 8)
**
*******************************************************************************/
#include "rdr_kma_stn_ech.h"
#include "/www/mis/cgi-src/include/rdr_stn.h"
#include "/www/mis/cgi-src/include/disp_htm.h"

struct INPUT_VAR  var;
char   IMG_DIR[64];

void   print_time();
float  uf_volume[RDR_KMA_STN_NUM][MAX_VOLUME];
float  uf_sweep[RDR_KMA_STN_NUM][MAX_SWEEP];

/******************************************************************************
 *
 *  MAIN
 *
 ******************************************************************************/
int main()
{
    int  code;
    IPAGE_TM itm;

    /*------------------------------------------------------------------------*/
    /* initial */

    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(240);

    printf("HTTP/1.0 200 OK\n");
    printf("Server: Netscape-Enterprise/3.0\n");

    /*------------------------------------------------------------------------*/
    /* user input decode */

    var.move  = 10;
    var.fmove = 5;


    if ((code = Input()) < 0)
    {
        if (var.mode != 'I')
        {
            /** ������������ ��ü�� : 2007.07.10
            printf("Content-type: text/html\n\n");
            printf("<!-- input variable error (%d)<p> --> \n", code);
            ***/
            seq2time(var.seq, &itm.year, &itm.mon, &itm.day, &itm.hour, &itm.min, 'm', 'n');
            disp_ipage(&itm, "�ش� �ڷᰡ �������� �ʽ��ϴ�.");
        }
        return -1;
    }

    if (var.mode == 'F')
        strcpy(IMG_DIR, IMG_DIR2);
    else
        strcpy(IMG_DIR, IMG_DIR1);

    /*------------------------------------------------------------------------*/
    /* display */

    if (var.mode == 'I')
        disp_img();
    else
        disp_html();

    alarm(0);
    return 0;
}

/******************************************************************************
 *
 *  ����� ��û�ڷ� �м�
 *
 ******************************************************************************/
int Input()
{
    #include INC_DEC

    var.winnum += 250;   /* ���ý���� ���̸� �ֱ� ���� */

    /*------------------------------------------------------------------------*/
    /* Error check (+) */

    if (strcmp(var.data0, "ALL") != 0)
    {
        /*
        for (i = 0; i < RDR_STN_NUM; i++)
        {
            if (strcmp(var.data0, rdr_stn[i].head) == 0 && rdr_stn[i].mode == 0) break;
        }
        if (i >= RDR_STN_NUM) return -2;
        */
        if (var.ds1 == 99 || var.ds2 == 99) var.mode = 'H';
    }
    else
    {
        var.ds1 = 3;
        var.ds2  = 0;
        var.an_frn = 1;
        var.mode = 'H';
    }

    /*------------------------------------------------------------------------*/
    /* �ֱ��ڷᰡ ���� ���, ���� �ֱ��ڷḦ ã�� */

    if (strcmp(var.data0, "ALL") != 0)
    {
        i = 1;
        while (rdr_kma_stn_ech_file() != 0 && i <= 60)
        {
            var.seq -= var.move;
            seq2time(var.seq, &var.YY, &var.MM, &var.DD, &var.HH, &var.min, 'm', 'n');
            i++;
        }
    }
    if (i > 60) return -3;
    return 0;
}

/******************************************************************************
 *
 *  IMAGE mode
 *
 ******************************************************************************/
int disp_img()
{
    FILE  *fd;
    char  gname[48][120], buf[8192];
    int   code = -1, c, n;

    /*------------------------------------------------------------------------*/

    if (rdr_kma_stn_ech_img_file(gname[0]) < 0)
    {
        if (rdr_kma_stn_ech_file() == 0)
            code = rdr_kma_stn_ech_img(uf_volume[0], uf_sweep[0], gname);
    }
    else
    {
        code = 1;
    }

    /*------------------------------------------------------------------------*/

    if (code > 0)
    {
        if ((fd = fopen(gname[0], "rb")) != NULL)
        {
            printf("Content-type: image/png\n\n");

            while ((n = fread(buf, 1, 8192, fd)) == 8192)
            {
                fwrite(buf, 1, n, stdout);
            }
            if (n > 0) fwrite(buf, 1, n, stdout);
            fclose(fd);
        }
    }
    return 0;
}

/******************************************************************************
 *
 *  HTML mode
 *
 ******************************************************************************/
int disp_html()
{
    char   gname[48][120];
    int    seq;
    int    i, j, n = 0, n1;

    printf("Content-type: text/html\n\n");

    /*------------------------------------------------------------------------*/
    /* head part */

    disp_html_head();

    /*------------------------------------------------------------------------*/
    /* time setting (with animation) */

    seq = var.seq;
    if (var.an_frn > 1) seq -= (var.an_frn - 1) * var.an_itv;

    /*------------------------------------------------------------------------*/
    /* Image make */

    printf("<DIV ID=log_rdr STYLE='position:absolute; left:50px; top:20px; visibility:visible;'>\n");

    if (strcmp(var.data0, "ALL") == 0)          /* ��� �����ڷ� */
    {
        for (n = 0; n < RDR_KMA_STN_NUM; n++)
        {
            strcpy(var.data0, rdr_stn[n].head);
            if (rdr_kma_stn_ech_file() == 0)
            {
                n1 = rdr_kma_stn_ech_img(uf_volume[n], uf_sweep[n], gname[n]);
                if (n1 <= 0) strcpy(gname[n], "nodata");
            }
            else
            {
                strcpy(gname[n], "nodata");
            }
        }
        strcpy(var.data0, "ALL");
    }
    else if (var.ds1 == 99 || var.ds2 == 99)    /* �� �ڷ��� ��� �� �Ǵ� ��� ���� */
    {
        if (rdr_kma_stn_ech_file() == 0)
        {
            n = rdr_kma_stn_ech_img(uf_volume[0], uf_sweep[0], gname);
        }
    }
    else                                        /* ����,�Ѻ��� */
    {
        for (n = 0, i = 0; i < var.an_frn; i++, seq += var.an_itv)
        {
            if (var.an_frn > 1) seq2time(seq, &var.YY, &var.MM, &var.DD, &var.HH, &var.min, 'm', 'n');

            if (rdr_kma_stn_ech_file() == 0)
            {
                n1 = rdr_kma_stn_ech_img(uf_volume[0], uf_sweep[0], gname[n]);
                if (n1 > 0) n++;
            }
        }
    }
    printf("</DIV>\n");

    printf("<SCRIPT LANGUAGE='JavaScript'>\n");
    printf("document.all[\"log_rdr\"].style.visibility = 'hidden'\n");
    printf("</SCRIPT>\n");

    /*------------------------------------------------------------------------*/
    /* body part */

    disp_html_body(n, gname);

    return 0;
}

/*============================================================================*
 *
 *  HEAD ������ ���
 *
 *============================================================================*/
int disp_html_head()
{
    printf("<HTML>\n");
    printf("<HEAD>\n");

    /*------------------------------------------------------------------------*/

    printf("<style type=\"text/css\">\n");
    printf("<!--\n");
    printf(":link    {text-decoration:none}\n");
    printf(":active  {text-decoration:none}\n");
    printf(":visited {text-decoration:none; color=#0000ff;}\n");
    printf(".head    {font-family:gulim,Verdana; font-size:12pt; color:#000000; font-weight:bold;}\n");
    printf(".name    {font-family:gulim,Verdana; font-size:10pt; color:#000000; font-weight:bold;}\n");
    printf(".text    {font-family:����ü,Verdana; font-size:8pt; color:#000000;}\n");
    printf(".textr   {font-family:����ü,Verdana; font-size: 9pt; color:#0000ff;}\n");
    printf("-->\n");
    printf("</style>\n");

    printf("<style type='text/css'>  \n");
    printf("<!--                     \n");
    printf("Body,Table {Font-family:\"����\",\"Tahoma\"; Font-Size:9pt; Color:#333333; Text-Decoration:none; \n");
    printf("					Margin-Top:0px; Margin-Left:10px; Margin-Right:0px; Margin-Bottom:0px;       \n");
    printf("					Scrollbar-Arrow-Color:#000000;                                               \n");
    printf("					Scrollbar-Highlight-Color:#FFFFFF;                                           \n");
    printf("					Scrollbar-Shadow-Color:#B4B4B4;                                              \n");
    printf("					Scrollbar-Darkshadow-Color:#EEEEEE;                                          \n");
    printf("					Scrollbar-3dlight-Color:#EEEEEE;                                             \n");
    printf("					Scrollbar-Track-Color:#FAFAFA;                                               \n");
    printf("					Scrollbar-Face-Color:#EEEEEE;}                                               \n");
    printf("-->      \n");
    printf("</style> \n");
													
    /*------------------------------------------------------------------------*/

    if (var.mode == 'A')
    {
        printf("<SCRIPT LANGUAGE='JavaScript'>\n");
        printf("<!--\n\n");
        printf("var menuWindow\n\n");

        printf("function menu_open()\n{\n");
        printf("  window.name = '%d'\n", var.winnum);
        printf("  menuWindow = window.open('/AUTO/rdr_menu.html?winnum=%d&size=%d&tm=%04d%02d%02d%02d%02d', ",
                var.winnum, var.size+40, var.YY, var.MM, var.DD, var.HH, var.min);
        printf("'auto_menu','width=600,height=300,alwaysRaised=yes')\n");
        printf("}\n\n");
        printf("// -->\n");
        printf("</SCRIPT>\n");
    }
    else
    {
        printf("<SCRIPT LANGUAGE='JavaScript'>\n");
        printf("<!--\n");
/*
        printf("parent.menu.frm.tm1.value = '%04d.%02d.%02d.%02d:%02d';\n", var.YY, var.MM, var.DD, var.HH, var.min);
        printf("parent.menu.frm.tm.value = '%04d%02d%02d%02d%02d';\n", var.YY, var.MM, var.DD, var.HH, var.min);
        printf("parent.menu.frm.volume.value = %d;\n", var.ds1);
        printf("parent.menu.frm.sweep.value = %d;\n", var.ds2);
*/
        printf("parent.menu.resetTime ( '%04d.%02d.%02d.%02d:%02d');\n", var.YY, var.MM, var.DD, var.HH, var.min);

        printf("// -->\n");
        printf("</SCRIPT>\n");
    }
    printf("</HEAD>\n");
    return 0;
}

/*============================================================================*
 *
 *  BODY ��� ���
 *
 *============================================================================*/
int disp_html_body(n, gname)

    int   n;
    char  gname[][120];
{
    char   volum_name[19][3] = {"DZ","VR","SW","CZ","ZT","DR","LR","ZD","DM","RH","PH",
                                "XZ","CR","MZ","MR","ZE","VE","KD","TI"};
    char   name[32];
    int    len = strlen(WEB_DIR), time_auto;
    int    i, j, k;

    /*------------------------------------------------------------------------*/
    /* for animation */

    if (var.an_frn > 1 && n > 1)
    {
        printf("<BODY bgcolor=#ffffff onload='animate()' TOPMARGIN=0 LEFTMARGIN=0 marginwidth=0 marginheight=0 class=text>\n");
    }
    else
    {
        /* for NO data */
        if (n <= 0)
        {
            printf(" �ڷᰡ �����ϴ�. (�ð�: %04d.%02d.%02d.%02d:%02d(LST))<p>\n",
                     var.YY, var.MM, var.DD, var.HH, var.min);
            printf("</BODY></HTML>\n");
            return -1;
        }
        printf("<BODY bgcolor=#ffffff TOPMARGIN=0 LEFTMARGIN=10 marginwidth=0 marginheight=0 class=text>\n");
    }

    /*------------------------------------------------------------------------*/
    /* JavaScript */
    
    //
    // image load
    //
    printf("<SCRIPT LANGUAGE='JavaScript'>\n");
    printf("<!--\n");
    printf("volume = %d\n", var.ds1);
    printf("sweep = %d\n", var.ds2);
    if (var.ds1 == 99 || var.ds2 == 99)
        printf("hi = 1\n\n");
    else
        printf("hi = 0\n\n");

    printf("function rdr_stn_img_load(stn, mode, v)\n");
    printf("{\n");
    printf("  if (mode)\n");
    printf("    parent.menu.frm.sweep.value = v\n");
    printf("  else\n");
    printf("    parent.menu.frm.volume.value = v\n\n");

    printf("  if (hi == 1 || v == 99)\n");
    printf("  {\n");
    printf("    parent.menu.doSubmit();\n");
    printf("  }\n");
    printf("  else if (parent.menu.frm.an_frn.value > 1)\n");
    printf("  {\n");
    printf("    parent.menu.doSubmit();\n");
    printf("  }\n");
    printf("  else\n");
    printf("  {\n");
    printf("    cmd = '/cgi-bin/rdr/nph-rdr_kma_stn_ech?' + stn + '&ECH&' + parent.menu.frm.volume.value +'&'+ parent.menu.frm.sweep.value + '&X&0&' + parent.menu.frm.color.value + '&' + parent.menu.frm.effect.value + '&C&' + parent.menu.frm.size.value + '&' + parent.menu.frm.topo.value + '&%4d%02d%02d%02d%02d&0&m&10&1&I&0&0';\n",
            var.YY, var.MM, var.DD, var.HH, var.min);

    if (strcmp(var.data0,"ALL") == 0)
    {
        printf("    switch (stn)\n");
        printf("    {\n");
        for (i = 0; i < RDR_KMA_STN_NUM; i++)
        {
            printf("    case \"%s\": document.anim_%s.src = cmd;  break;\n", rdr_stn[i].head, rdr_stn[i].head);
        }
        printf("    }\n");
    }
    else
    {
        printf("    document.anim.src = cmd\n");
    }
    printf("  }\n");
    printf("}\n");

    //
    // for auto & man (per 10mmin)
    //

    if (var.auto_man == 'a')
    {
        time_auto = 1000 * 60 * 10;
        printf("  window.setTimeout('parent.menu.doSubmit();', %d)\n", time_auto);
    }

    //
    // JavaScript for animation
    //

    if (var.an_frn > 1 && n > 1)
    {
        printf("var counter = 0\n");
        printf("var animation = 1\n");
        printf("var timer\n");
        printf("var i, j\n");
        printf("var imgs = new Array()\n");
        printf("for(i = 0; i < %d; i++) {\n", n);
        printf("  imgs[i] = new Image()\n");
        printf("}\n\n");

        for (i = 0; i < n; i++)
        {
            printf("imgs[%d].src = '%s'\n", i, &gname[i][len]);
        }
        printf("\n");
        printf("function animate()\n");
        printf("{\n");
        printf("  if (animation == 1) {\n");
        printf("    counter = (counter + 1) %% %d\n", n);
        printf("    document.anim.src = imgs[counter].src\n");
        printf("    timer = setTimeout('animate()', 1000)\n");
        printf("  }\n");
        printf("}\n\n");
        printf("function play()\n");
        printf("{\n");
        printf("  animation = 1\n");
        printf("  animate()\n");
        printf("}\n\n");
        printf("function stop()\n");
        printf("{\n");
        printf("  animation = 0\n");
        printf("}\n\n");
        printf("function first()\n");
        printf("{\n");
        printf("  counter = 0\n");
        printf("  document.anim.src = imgs[counter].src\n");
        printf("}\n\n");
        printf("function end()\n");
        printf("{\n");
        printf("  counter = %d\n", n-1);
        printf("  document.anim.src = imgs[counter].src\n");
        printf("}\n\n");
        printf("function moving(bf)\n");
        printf("{\n");
        printf("  counter = (counter + bf + %d) %% %d\n", n, n);
        printf("  document.anim.src = imgs[counter].src\n");
        printf("}\n\n");
    }
    printf("// -->\n");
    printf("</SCRIPT>\n");

    /*------------------------------------------------------------------------*/
    /* for Display */

    //printf("<center>\n");

    if (strcmp(var.data0, "ALL") == 0)
    {
        printf("<TABLE border=1 cellpadding=0 cellspacing=4 class=text>\n");

        for (k = 0; k < RDR_KMA_STN_NUM; k++)
        {
            strcpy(var.data0, rdr_stn[k].head);
            if (k % 2 == 0)
                printf("<TR bgcolor=#c8c8c8><TD>\n");
            else
                printf("<TD>\n");

            printf("<TABLE border=0 cellpadding=0 cellspacing=0>\n");

            if (rdr_kma_stn_ech_file() == 0 && rdr_kma_stn_ech_img_file(gname[0]) == 0)
            {
                printf("<TR bgcolor=#cdd8ff class=text height=20><TD width=40>&nbsp;</TD><TD>[����] &nbsp;\n");
                for (i = 0; i < 4; i++)
                {
                    if (uf_volume[k][i] > 0)
                         printf(" <a href='javascript:rdr_stn_img_load(\"%s\",0,%d)'>%s</a> &nbsp;\n", var.data0, i, volum_name[i]);
                }
                printf(" &nbsp; <a href='javascript:rdr_stn_img_load(\"%s\",0,99)'>All</a></TD></TR>\n", var.data0);

                printf("<TR valign=top class=text><TD bgcolor=#cdd8ff align=right>[����]<br>(deg)&nbsp;<p>");
                for (j = 0; j < uf_volume[k][var.ds1]; j++)
                {
                    if (uf_sweep[k][j] > -10)
                        printf("<a href='javascript:rdr_stn_img_load(\"%s\",1,%d)'>%.2f</a>&nbsp;<br>\n", var.data0, j, uf_sweep[k][j]);
                }
                printf("<br><a href='javascript:rdr_stn_img_load(\"%s\",1,99)'>All</a>&nbsp;</TD>\n", var.data0);
                printf("<TD align=left bgcolor=#ffffff><img name='anim_%s' src='%s' border=0></TD></TR>\n", var.data0, &gname[0][len]);
            }
            else
            {
                printf("<TR><TD rowspan=2 colspan=2 bgcolor=#ffffff>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;No data (%s)</TD></TR>\n", rdr_stn[k].name);
            }
            printf("</TABLE>\n");

            if (k%2 == 1)
                printf("</TD></TR>\n");
            else
                printf("</TD>\n");
        }
        printf("</TABLE>\n");
    }

    //
    //  �� ������ ��� ������
    //

    else if (var.ds2 == 99)
    {
        printf("<TABLE border=0 cellpadding=0 cellspacing=2 class=text>\n");
        printf("<TR bgcolor=#cdd8ff height=20 class=text><TD colspan=2>[����] ");

        for (i = 0; i < MAX_VOLUME; i++)
        {
            if (uf_volume[0][i] > 0)
            {
                if (var.ds1 == i)
                    printf(" <a href='javascript:rdr_stn_img_load(\"%s\",0,%d)'><font color=#ff0000>%s</font></a>&nbsp; ", var.data0, i,  volum_name[i]);
                else
                    printf(" <a href='javascript:rdr_stn_img_load(\"%s\",0,%d)'>%s</a>&nbsp; ", var.data0, i,  volum_name[i]);
            }
        }
        printf(" / [������] ");

        for (j = 0; j < uf_volume[0][var.ds1]; j++)
        {
            if (uf_sweep[0][j] > -10)
                printf("<a href='javascript:rdr_stn_img_load(\"%s\",1,%d)'><font color=#ff0000>%.2f</font></a>&nbsp;\n", var.data0, j, uf_sweep[0][j]);
        }
        printf("</TD></TR>\n");

        for (k = 0, j = 0; j < uf_volume[0][var.ds1]; j++)
        {
            var.ds2 = j;
            if (k%2 == 0) printf("<TR align=left>\n");
            if (rdr_kma_stn_ech_img_file(gname[0]) == 0)
            {
                printf("<TD><img src='%s' border=0></TD>\n", &gname[0][len]);
                k++;
            }
            if (k%2 == 0) printf("</TR>\n");
        }
        printf("</TABLE>\n");
    }

    //
    //  �� �������� ��� ����
    //

    else if (var.ds1 == 99)
    {
        printf("<TABLE border=0 cellpadding=0 cellspacing=2 class=text>\n");
        printf("<TR bgcolor=#cdd8ff height=20 classs=text><TD colspan=2>[������] ");

        for (j = 0; j < MAX_SWEEP; j++)
        {
            if (uf_sweep[0][j] > -10)
            {
                if (var.ds2 == j)
                    printf("<a href='javascript:rdr_stn_img_load(\"%s\",1,%d)'><font color=#ff0000>%.2f</font></a>&nbsp;\n", var.data0, j, uf_sweep[0][j]);
                else
                    printf("<a href='javascript:rdr_stn_img_load(\"%s\",1,%d)'>%.2f</a>&nbsp;\n", var.data0, j, uf_sweep[0][j]);
            }
        }
        printf(" / [����] ");
        for (i = 0; i < MAX_VOLUME; i++)
        {
            if (uf_volume[0][i] > 0)
                printf(" <a href='javascript:rdr_stn_img_load(\"%s\",0,%d)'><font color=#ff0000>%s</font></a>&nbsp; \n", var.data0, i,  volum_name[i]);
        }
        printf("</TD></TR>\n");

        for (i = 0; i < MAX_VOLUME; i++)
        {
            var.ds1 = (i+3) % 4;
            if (i%2 == 0) printf("<TR align=left>\n");
            if (rdr_kma_stn_ech_img_file(gname[0]) == 0)
                printf("<TD><img src='%s' border=0></TD>\n", &gname[0][len]);
            else
                printf("<TD>&nbsp; NO data</TD>\n");

            if (i%2 == 1) printf("</TR>\n");
        }
        printf("</TABLE>\n");
    }

    //
    //  �� ����, �� ����
    //

    else
    {
        printf("<TABLE border=0 cellpadding=0 cellspacing=0 class=text>\n");
        printf("<TR bgcolor=#cdd8ff class=text height=20><TD width=40>&nbsp;</TD><TD>[����] &nbsp;\n");
        for (i = 0; i < MAX_VOLUME; i++)
        {
            if (uf_volume[0][i] > 0)
               printf(" <a href='javascript:rdr_stn_img_load(\"%s\",0,%d)'>%s</a> &nbsp;\n", var.data0, i, volum_name[i]);
        }
        if (var.mode == 'H') printf(" &nbsp; <a href='javascript:rdr_stn_img_load(\"%s\",0,99)'>All</a>\n", var.data0);
        printf("</TD></TR>\n");

        printf("<TR valign=top class=text><TD bgcolor=#cdd8ff align=right>[����]<br>(deg)&nbsp;<p>");
        for (j = 0; j < uf_volume[0][var.ds1]; j++)
        {
            if (uf_sweep[0][j] > -10)
                printf("<a href='javascript:rdr_stn_img_load(\"%s\",1,%d)'>%.2f</a>&nbsp;<br>\n", var.data0, j, uf_sweep[0][j]);
        }
        if (var.mode == 'H') printf("<br><a href='javascript:rdr_stn_img_load(\"%s\",1,99)'>All</a>&nbsp;", var.data0);
        printf("</TD>\n");

        if (var.mode == 'A')
        {
            printf("<TD bgcolor=#ffffff align=left><a href='javascript:menu_open();'>");
            printf("<img name='anim' src='%s' border=0></a></TD></TR>\n", &gname[0][len]);
        }
        else
        {
            printf("<TD bgcolor=#ffffff align=left>\n");
            printf("<DIV id=img1 style='position:relative; top:0px;'>\n");
            printf("  <img name='anim' src='%s' border=0>\n", &gname[0][len]);

            if (n > 1 && var.an_frn > 1)
            {
                printf("  <DIV id=anim_bt style='position:absolute; left:%dpx; top:15px; visibility:visible;'>\n", var.size-120);
                printf("    <img src='/images/anim.png' border=0 usemap=#anim_map>\n");
                printf("  </DIV>\n");
            }
            printf("</DIV>\n");
            printf("</TD></TR>\n");
        }
        printf("</TABLE>\n");

        if (n > 1 && var.an_frn > 1)
        {
            printf("<MAP name=anim_map>\n");
            printf("<area shape=rect coords=0,0,20,14 href='javascript:play()'>\n");
            printf("<area shape=rect coords=21,0,40,14 href='javascript:stop()'>\n");
            printf("<area shape=rect coords=41,0,60,14 href='javascript:first()'>\n");
            printf("<area shape=rect coords=61,0,80,14 href='javascript:moving(-1)'>\n");
            printf("<area shape=rect coords=81,0,100,14 href='javascript:moving(1)'>\n");
            printf("<area shape=rect coords=101,0,120,14 href='javascript:end()'>\n");
            printf("</MAP>\n");
        }
    }
    //printf("</center>\n");
    printf("</BODY></HTML>\n");
    return 0;
}

/******************************************************************************
 *  �̹��� ���� ���翩�� �� ���� �̸� ��ȯ
 ******************************************************************************/
int rdr_kma_stn_ech_img_file(char *fname)
{
    struct stat st;
    int    code = 0;

    sprintf(fname, "%s/RDR_%s_%04d%02d%02d%02d%02d_%d_%d_%c%s%c_%d.png",
            IMG_DIR, var.data0, var.YY, var.MM, var.DD, var.HH, var.min, var.ds1, var.ds2,
            var.color, var.overlay, var.effect, var.size);

    if (stat(fname, &st) < 0) code = -1;
    else if (st.st_size < 10) code = -2;

    return code;
}

/******************************************************************************
 *  ���� ���� ���� ���翩�� �� ���� �̸� ��ȯ
 ******************************************************************************/
int rdr_kma_stn_ech_inf_file(char *fname)
{
    struct stat st;
    int    code = 0;

    sprintf(fname, "%s/RDR_%s_%04d%02d%02d%02d%02d.inf",
            IMG_DIR, var.data0, var.YY, var.MM, var.DD, var.HH, var.min);

    if (stat(fname, &st) < 0) code = -1;
    else if (st.st_size < 10) code = -2;

    return code;
}

/******************************************************************************
 *  �ڷ����� ���翩�� �� �����̸� ��ȯ
 ******************************************************************************/
int rdr_kma_stn_ech_file()
{
    struct stat st;
    int    seq, YY, MM, DD, HH, min;
    int    code = 0;
    int    i, j;

    seq = time2seq(var.YY, var.MM, var.DD, var.HH, var.min, 'm');
    for (i = 0; i < 10; i++)
    {
        seq2time(seq-i, &YY, &MM, &DD, &HH, &min, 'm', 'n');
        sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_%04d%02d%02d%02d%02d.uf",
                RDR_DIR, YY, MM, DD, var.data0, YY, MM, DD, HH, min);

        code = stat(var.fname, &st);
        if (st.st_size == 0) code = -2;
        if (code == 0) break;
    }
    
    return code;
}

/******************************************************************************
 *  TOPO �̹��� �ڷ� ���翩�� Ȯ��
 ******************************************************************************/
int rdr_kma_stn_topo_img_file(char *fname)
{
    struct stat st;
    int    code = 0;

    sprintf(fname, "%s/TOPO/RDR/rdr_stn_topo_%s_%d_%s_%d.png",
            REF_DIR, var.data0, (int)(0.001*var.range), var.overlay, var.size);
    
    if (stat(fname, &st) < 0) code = -1;
    else if (st.st_size == 0) code = -2;

    return code;
}

void print_time(char *head)
{
    int  YY, MM, DD, HH, min, sec;

    get_time(&YY, &MM, &DD, &HH, &min, &sec);
    printf(" %s : time = %04d.%02d.%02d.%02d:%02d (%02d)<br>\n",
            head, YY, MM, DD, HH, min, sec);
}
