/*******************************************************************************
**
**  ���̴� QPF ǥ��
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2015.5.2)
**
********************************************************************************/
#include "rdr_qpf1_img.h"

struct INPUT_VAR var;           // ����� �Է� ����
struct STN_VAL  stn_data[MAX_STN];

struct MAPLE_HEAD maple_head;
struct MAPLE_INFO maple_info;
float  **qpf;
FILE   *fp_log;

int grid_smooth(float **g, int nx, int ny, float missing);

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main()
{
  int   err = 0;

  // 1. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(20);

  printf("HTTP/1.0 200 OK\n");
  //printf("Content-type: text/plain\n\n");

  // 2. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    err = 1;
  }

  // 3. �ڷḦ ���� �� ���ڿ��� ����
  grid_map_inf(var.map, &(var.NX), &(var.NY), &(var.SX), &(var.SY));

  if (var.acc > 0) {
    if (var.qpe == 60) {
      if (rdr_qpf_pcp_60m_get() < 0) err = 2;
    }
    else {
      if (rdr_qpf_pcp_10m_get() < 0) err = 2;
    }
  }
  else {
    if (rdr_qpf_get() < 0) err = 2;
  }

  // 4. ���� ó��
  if (err > 0) {
    rdr_qpf_err_img(err);
    return 0;
  }

  // 5. �������� �ϰ�, Ȯ�� ó��
  if (var.aws > 0 && var.zoom_level > 0) {
    aws_info_get();
    aws_data_get();
    aws_zooming();
  }

  // 5. �̹��� ���� �� ����
  rdr_qpf_img();

  // 7. �޸� �ݳ�
  free_matrix(qpf, 0, RDR_MAPLE_NY, 0, RDR_MAPLE_NX);
  alarm(0);
  return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
  char *qs;
  char tmp[256], item[32], value[32], tm[30], tmef[30], obs1[16];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, i, j;

  // 1. ���� �ʱⰪ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  var.qpe = 10;
  strcpy(tm, "0");        // ����ð�
  strcpy(var.map, "D3");  // D3����
  var.zoom_level = 0;     // ��ü����
  var.zoom_rate = 2;      // 2�� Ȯ�밡 �⺻
  var.num_gov = 0;
  var.aws = 0;
  var.acc = 0;
  var.legend = 1;

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"map"))  strcpy(var.map, value);
    else if ( !strcmp(item,"qpe"))  var.qpe = atoi(value);
    else if ( !strcmp(item,"tm"))   strcpy(tm, value);
    else if ( !strcmp(item,"tmef")) strcpy(tmef, value);
    else if ( !strcmp(item,"acc"))  var.acc = atoi(value);
    else if ( !strcmp(item,"gov")) {
      for (var.num_gov = 0, j = 0; value[0] != '\0'; j++) {
        getword (tmp, value, ':');
        if (strlen(tmp) >= 3) {
          strcpy(var.gov_cd[var.num_gov], tmp);
          var.num_gov++;
        }
      }
    }
    else if ( !strcmp(item,"aws")) var.aws = atoi(value);
    else if ( !strcmp(item,"zoom_level")) var.zoom_level = atoi(value);
    else if ( !strcmp(item,"zoom_rate"))  var.zoom_rate = atoi(value);
    else if ( !strcmp(item,"zoom_x")) strcpy(var.zoom_x, value);
    else if ( !strcmp(item,"zoom_y")) strcpy(var.zoom_y, value);
    else if ( !strcmp(item,"size")) var.size = atoi(value);
    else if ( !strcmp(item,"legend")) var.legend = atoi(value);
  }
  if (var.grid < 0.001) var.grid = 2.0;
  var.grid = 1.0;
  if (var.num_gov == 0) {
    var.num_gov = 1;
    strcpy(var.gov_cd[0],"KMA");
  }

  // 3. ����ð� �� ���� �����ð� ����
  get_time(&iYY, &iMM, &iDD, &iHH, &iMI, &iSS);
  iseq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm') - 6;
  seq2time(iseq, &iYY, &iMM, &iDD, &iHH, &iMI, 'm', 'n');

  // 4. ���ؽð� ����
  if (strlen(tm) >= 10) {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
  }
  var.seq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  var.seq = 10*(var.seq/10);

  // 4. ����ð� ����
  if (strlen(tmef) >= 10) {
    strncpy(tmp, &tmef[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tmef[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tmef[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tmef[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tmef[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
  }
  var.seq_ef = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');

  return 0;
}

/*******************************************************************************
 *
 *  ������ �̹��� ���� �� ����
 *
 *******************************************************************************/
int rdr_qpf_img()
{
  gdImagePtr im;
  FILE  *fp;
  int   color_lvl[256];
  float data_lvl[256];

  // 1. �̹��� ���� ����
  var.NI = var.size;
  var.NJ = (int)((float)(var.NY)/(float)(var.NX)*var.NI);
  var.GI = var.NI;
  if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + TITLE_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_table(im, color_lvl, data_lvl);
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[240]);

  // 3. �����ڷ� �׸���
  grid_disp(im, color_lvl, data_lvl);

  // 4. ���� �׸���
  if (var.zoom_level >= 2) map_disp(im, color_lvl[249], 1);
  map_disp(im, color_lvl[242], 4);

  // 5. ���� ǥ��
  if (var.aws > 0 && var.zoom_level > 0) aws_disp(im, color_lvl);

  // 6. ���� �׸�
  title_disp(im, color_lvl);

  // 7. ���� �׸���
  legend_disp(im, color_lvl, data_lvl);
  gdImageRectangle(im, 0, TITLE_pixel, var.NI-1, var.GJ-1, color_lvl[242]);

  // 8. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);
  return 0;
}

/*=============================================================================*
 *  ����ǥ
 *=============================================================================*/
int color_table(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  FILE  *fp;
  char  color_file[120];
  float data_min, data_itv, v1;
  int   num_color;
  int   R, G, B;
  int   i;

  // 1. ��󺯼��� ����ǥ ���� ����
  strcpy(color_file,COLOR_SET_DIR);
  strcat(color_file,"color_rn_echo.rgb");

  // 2. ����ǥ ���ϰ� ������ �б�
  var.num_color = num_color = 0;
  if ((fp = fopen(color_file, "r")) != NULL) {
    while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
      color_lvl[num_color] = gdImageColorAllocate(im, R, G, B);
      data_lvl[num_color] = v1;
      num_color++;
      if (num_color > 119) break;
    }
    fclose(fp);
  }
  else {
    num_color = -1;
  }
  var.num_color = num_color;

  // 3. ��Ÿ ����ǥ ����
  color_lvl[240] = gdImageColorAllocate(im, 180, 180, 180);   // ����1
  color_lvl[241] = gdImageColorAllocate(im, 255, 255, 255);   // ����2
  color_lvl[242] = gdImageColorAllocate(im, 30, 30, 30);      // ������
  color_lvl[243] = gdImageColorAllocate(im, 12, 28, 236);     // ����
  color_lvl[244] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  color_lvl[245] = gdImageColorAllocate(im, 240, 240, 240);
  color_lvl[246] = gdImageColorAllocate(im, 255, 30, 0);
  color_lvl[247] = gdImageColorAllocate(im, 0, 0, 255);
  color_lvl[248] = gdImageColorAllocate(im, 160, 160, 160);   // ����3
  color_lvl[249] = gdImageColorAllocate(im, 110, 110, 110);   // �ñ����
  color_lvl[250] = gdImageColorAllocate(im, 255, 239, 0);     // ���� ����
  color_lvl[251] = gdImageColorAllocate(im, 0, 255, 255);     // �ϴû� ����

  return num_color;
}

/*=============================================================================*
 *  �����ڷ� ǥ��
 *=============================================================================*/
int grid_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  float *q1;
  float x1, y1, x, y, dd, dd1, dd2;
  float zm = 1.0, xo = 0.0, yo = 0.0;
  float grid_nx, grid_ny, zx, zy, rate;
  short blank = BLANK1 + 10;
  int   dxy, nx, ny, map_code;
  int   nd, ix, iy, color1;
  int   i, j, k;

  // 1. ����ó��
  if (var.num_color <= 0) {
    gdImageString(im, gdFontLarge, 100, 100, "No Color Level", color_lvl[244]);
    return -1;
  }

  // 3. �⺻ ����
  dxy = 1000.0;
  nx  = RDR_MAPLE_NX + 1;
  ny  = RDR_MAPLE_NY + 1;

  grid_ny = 1000.0*(float)(var.NY)/(float)dxy;
  grid_nx = 1000.0*(float)(var.NX)/(float)dxy;
  yo = 1000.0*(float)(RDR_MAPLE_SY-var.SY)/(float)dxy;
  xo = 1000.0*(float)(RDR_MAPLE_SX-var.SX)/(float)dxy;
  rate = grid_nx/(float)(var.NI);    // �̹��� �ȼ��� ���ڼ�

  // 4. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    if (var.zoom_rate == 3) {
      for (i = 0; i < 2; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (grid_nx/9.0*(zx-1)/zm);
        yo += (grid_ny/9.0*(zy-1)/zm);
        zm *= var.zoom_rate;
      }
    }
    else if (var.zoom_rate == 2) {
      for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (grid_nx/8.0*(zx-1)/zm);
        yo += (grid_ny/8.0*(zy-1)/zm);
        zm *= var.zoom_rate;
      }
    }
  }

  // 5. �̹��� �ȼ����� ���
  for (j = 1; j < var.NJ; j++) {
    y1 = rate*j;
    iy = (int)(y1/zm + yo);
    if (iy < 0 || iy >= ny) continue;

    for (q1 = &qpf[iy][0], i = 1; i < var.NI; i++) {
      x1 = rate*i;
      ix = (int)(x1/zm + xo);
      if (ix < 0 || ix >= nx) continue;

      // 5.4. �ڷᰡ �������� ������ ǥ��
      dd = *(q1 + ix);
      if (dd > blank) {
        color1 = color_lvl[var.num_color-1];
        for (k = 0; k < var.num_color; k++) {
          if (dd <= data_lvl[k]) {
            color1 = color_lvl[k];
            break;
          }
        }
        gdImageSetPixel(im, i, var.GJ-j, color1);
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int map_disp(gdImagePtr im, int color_map, int kind)
{
  FILE  *fp;
  char  fname[120];
  float zm = 1.0, xo = 0.0, yo = 0.0, x1, y1, x2, y2;
  int   zx, zy, mode;
  int   i, j, k, n;

  // 1. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    if (var.zoom_rate == 3) {
      for (i = 0; i < 2; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/9.0*(zx-1)/zm;
        yo += (float)(var.NY)/9.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
    else if (var.zoom_rate == 2) {
      for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/8.0*(zx-1)/zm;
        yo += (float)(var.NY)/8.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
  }

  // 2. �ؾȼ� ǥ��
  sprintf(fname, "%s/AFS_%s_map%d.dat", MAP_DIR, var.map, kind);
  if ((fp = fopen(fname, "r")) != NULL) {
    while (fscanf(fp, "%d %d\n", &n, &mode) != EOF) {
      for (i = 0; i < n; i++) {
        fscanf(fp, "%f %f\n", &x2, &y2);
        x2 /= var.grid;
        y2 /= var.grid;

        if (var.zoom_level > 0) {
          x2 = zm*(x2-xo);
          y2 = zm*(y2-yo);
        }
        x2 *= ((float)(var.NI)/(float)(var.NX));
        y2 *= ((float)(var.NI)/(float)(var.NX));
        if (i > 0) {
          gdImageLine(im, (int)x1, var.GJ-(int)y1, (int)x2, var.GJ-(int)y2, color_map);
          if (kind == 4 && var.zoom_level >= 2) gdImageLine(im, (int)x1, var.GJ-(int)y1-1, (int)x2, var.GJ-(int)y2-1, color_map);
        }
        x1 = x2;
        y1 = y2;
      }
    }
    fclose(fp);
  }

  return 0;
}

/*=============================================================================*
 *  EUC-KR���ڿ��� UTF-8�� ��ȯ
 *=============================================================================*/
int euckr2utf(char *str, char *out)
{
    iconv_t convp;
    size_t  ileft, oleft;
    int     err, len = strlen(str);

    ileft = len;
    oleft = len * 2;

    convp = iconv_open("UTF-8", "euc-kr");
    err = iconv(convp, &str, &ileft, &out, &oleft);
    iconv_close(convp);

    return err;
}

/*=============================================================================*
 *  ���� ǥ��(�ѱ�ó��)
 *=============================================================================*/
int title_disp(gdImagePtr im, int color_lvl[])
{
  char   title[80], tm_fc_str[100], tm_ef_str[100], num_stn_str[10], tmp[50];
  char   str_utf[100];
  double font_size = 11.5;
  int    brect[8], color1;
  int    YY, MM, DD, HH, MI, dh;
  int    x, y, i, k;

  // 1. ���񿵿��� ���� ó��
  gdImageFilledRectangle(im, 0, 0, var.GI, TITLE_pixel, color_lvl[241]);

  // 2. ������
  if (var.acc > 0) {
    if (var.acc%60 == 0)
      sprintf(tmp, "(%dH����) ", (int)(var.acc/60));
    else
      sprintf(tmp, "(%d�д���) ", (int)(var.acc/60), var.acc%60);

    if (var.seq_ef <= var.seq) {
      if (var.qpe == 60)
        sprintf(title,"���̴� �м�2%s", tmp);
      else 
        sprintf(title,"���̴� �м�1%s", tmp);
    }
    else {
      if (var.qpe == 60)
        sprintf(title, "���̴� ����2%s", tmp);
      else 
        sprintf(title, "���̴� ����1%s", tmp);
    }
  }
  else {
    if (var.seq_ef <= var.seq) {
      if (var.qpe == 60)
        strcpy(title,"���̴� �м�2(60�д���)");
      else 
        strcpy(title,"���̴� �м�1(��������)");
    }
    else {
      if (var.qpe == 60)
        strcpy(title,"���̴� ����2(60�д���)");
      else 
        strcpy(title,"���̴� ����1(��������)");
    }
  }

  for (i = 0; i < 100; i++)
    str_utf[i] = 0;
  euckr2utf(title, str_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 5, (int)(font_size+5), str_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 6, (int)(font_size+5), str_utf);

  // 3. ��ȿ�ð� ���ڿ�
  seq2time(var.seq_ef, &YY, &MM, &DD, &HH, &MI, 'm', 'y');
  sprintf(tm_ef_str, "%04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, MI);
  for (i = 0; i < 100; i++)
    str_utf[i] = 0;
  euckr2utf(tm_ef_str, str_utf);

  x = strlen(title)*8.6 + 10;
  if (x < 130) x = 130;
  y = (int)(font_size+5);

  if (var.seq_ef == var.seq)
    color1 = color_lvl[244];
  else
    color1 = color_lvl[246];

  gdImageStringFT(im, &brect[0], color1, FONTTTF, font_size, 0.0, x, y, str_utf);
  gdImageStringFT(im, &brect[0], color1, FONTTTF, font_size, 0.0, x+1, y, str_utf);

  // 3. ���ؽð� ���ڿ�
  if (var.seq_ef > var.seq) {
    seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'y');
    sprintf(tm_fc_str, "%04d.%02d.%02d.%02d:%02d ", YY, MM, DD, HH, MI);
    dh = var.seq_ef-var.seq;
    if (dh < 60)
      sprintf(tmp, "(+%d��) ", dh);
    else {
      if (dh%60 == 0)
        sprintf(tmp, "(+%d�ð�) ", (int)(dh/60));
      else
        sprintf(tmp, "(+%d�ð�%d��) ", (int)(dh/60), dh%60);
    }
    strcat(tm_fc_str, tmp);

    for (i = 0; i < 100; i++)
      str_utf[i] = 0;
    euckr2utf(tm_fc_str, str_utf);

    y = TITLE_pixel + (int)(font_size+5);
    gdImageFilledRectangle(im, 1, TITLE_pixel, strlen(tm_fc_str)*8, TITLE_pixel+18, color_lvl[241]);
    gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, 4, y, str_utf);
    gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, 5, y, str_utf);
  }
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int legend_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  char   txt[20];
  float  dy = (float)(var.NJ)/(float)(var.num_color);
  int    YY, MM, DD, HH, MI;
  int    x, y, k;

  if (var.legend != 1) return 0;
  if (var.num_color <= 0) return -1;

  // 1. ���� ���� ǥ��
  for (k = 0; k < var.num_color; k++) {
    y = var.GJ - dy*k;
    gdImageFilledRectangle(im, var.NI, y-dy, var.NI+8, y, color_lvl[k]);
  }
  gdImageRectangle(im, var.NI-1, TITLE_pixel, var.NI+8, var.GJ-1, color_lvl[242]);

  // 2. ���ʰ� ǥ��
  gdImageFilledRectangle(im, var.NI+9, 0, var.GI-1, var.GJ, color_lvl[241]);
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      if (data_lvl[k] < 10)
        sprintf(txt, "%.1f", data_lvl[k]);
      else
        sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }

  // 3. ���� ���� ǥ��
  strcpy(txt,"mm/h");

  x = var.NI + 3;
  gdImageString(im, gdFontLarge, x, 4, txt, color_lvl[244]);
  return 0;
}

/*=============================================================================*
 *  zd�� Ȯ�� ��ƾ (���밡��: �ݵ�� ������ X,Y ���� zd���� ������ �������� ��)
 *      Ȯ��� �������� sub 4-point ����� �⺻���� ���
 *  by ����ȯ (2006. 5. 22)
 *=============================================================================*/
int grid_zoom (
    float **g,      /* input -> output */
    int   nx,       /* [0:nx,0:ny] zd�� ������ �������� ��. */
    int   ny,
    int   zd,       /* Ȯ���� (2��,3�� ... ) */
    int   ox,       /* ���� �Ʒ� ������ X-��ǥ */
    int   oy,       /* ���� �Ʒ� ������ Y-��ǥ */
    float missing,  /* ���ϴ� �ڷ� ���� */
    int   mode      /* 0:����(X), 1:��������, 2:4������ */
)
{
    float x;
    int   i, j, k;

    // 1. Y ���� Ȯ��
    for (i = ox; i <= ox+nx/zd; i++) {
        for (k = 0, j = oy; j < oy*zd/(zd-1); j++, k += zd) g[k][i] = g[j][i];
        for (k = ny, j = oy+ny/zd; j >= oy*zd/(zd-1); j--, k -= zd) g[k][i] = g[j][i];
    }

    // 2. X ���� Ȯ��
    for (j = 0; j <= ny; j += zd) {
        for (k = 0, i = ox; i < ox*zd/(zd-1); i++, k += zd) g[j][k] = g[j][i];
        for (k = nx, i = ox+nx/zd; i >= ox*zd/(zd-1); i--, k -= zd) g[j][k] = g[j][i];
    }

    // 3. Y ���� ����
    for (i = 0; i <= nx; i += zd) {
        // 3.1. (0, zd) ���� ������ ��� : �������� ���
        if (mode > 0 && g[0][i] > missing && g[zd][i] > missing) {
            for (k = 1; k < zd; k++)
                g[k][i] = (g[0][i]*(float)(zd - k) + g[zd][i]*(float)k) / (float)zd;
        }
        else {
            for (k = 1; k < zd; k++) {
                if (k <= zd/2) g[k][i] = g[0][i];
                else           g[k][i] = g[zd][i];
            }
        }

        // 3.2. (ny-zd, ny) ���� ������ ��� : �������� ���
        if (mode > 0 && g[ny-zd][i] > missing && g[ny][i] > missing) {
            for (k = 1; k < zd; k++)
                g[ny-k][i] = (g[ny-zd][i]*(float)k + g[ny][i]*(float)(zd-k)) / (float)zd;
        }
        else {
            for (k = 1; k < zd; k++) {
                if (k < zd/2) g[ny-k][i] = g[ny][i];
                else          g[ny-k][i] = g[ny-zd][i];
            }
        }

        // 3.3. ������ (zd,ny-zd) ���� ������ ��� : �ؼ������� ��� (4-point)
        for (j = zd; j < ny-zd; j += zd) {
            for (k = 1; k < zd; k++) {
                if (mode > 0 && g[j][i] > missing && g[j+zd][i] > missing) {
                    x = (float)k / (float)zd;

                    if (mode == 2 && g[j-zd][i] > missing && g[j+zd*2][i] > missing)
                        g[j+k][i] = g[j][i] + x*(g[j+zd][i] - g[j][i] + (x-1.0)*0.25*(g[j-zd][i] - g[j][i] - g[j+zd][i] + g[j+zd*2][i]));
                    else
                        g[j+k][i] = g[j][i]*(1.0-x) + g[j+zd][i]*x;
                }
                else {
                    if (k <= zd/2) g[j+k][i] = g[j][i];
                    else           g[j+k][i] = g[j+zd][i];
                }
            }
        }
    }

    // 4. X ���� ����
    for (j = 0; j <= ny; j++) {
        // 4.1. (0, zd) ���� ������ ��� : �������� ���
        if (mode > 0 && g[j][0] > missing && g[j][zd] > missing) {
            for (k = 1; k < zd; k++)
                g[j][k] = (g[j][0]*(float)(zd - k) + g[j][zd]*(float)k) / (float)zd;
        }
        else {
            for (k = 1; k < zd; k++) {
                if (k <= zd/2) g[j][k] = g[j][0];
                else           g[j][k] = g[j][zd];
            }
        }

        // 4.2. (nx-zd, nx) ���� ������ ��� : �������� ���
        if (mode > 0 && g[j][nx-zd] > missing && g[j][nx] > missing) {
            for (k = 1; k < zd; k++)
                g[j][nx-k] = (g[j][nx-zd]*(float)k + g[j][nx]*(float)(zd-k)) / (float)zd;
        }
        else {
            for (k = 1; k < zd; k++) {
                if (k < zd/2) g[j][nx-k] = g[j][nx];
                else          g[j][nx-k] = g[j][nx-zd];
            }
        }

        // 4.3. ������ (zd,ny-zd) ���� ������ ��� : �ؼ������� ��� (4-point)
        for (i = zd; i < nx-zd; i += zd) {
            for (k = 1; k < zd; k++) {
                if (mode > 0 && g[j][i] > missing && g[j][i+zd] > missing) {
                    x = (float)k / (float)zd;

                    if (mode == 2 && g[j][i-zd] > missing && g[j][i+zd*2] > missing)
                        g[j][i+k] = g[j][i] + x*(g[j][i+zd] - g[j][i] + (x-1.0)*0.25*(g[j][i-zd] - g[j][i] - g[j][i+zd] + g[j][i+zd*2]));
                    else
                        g[j][i+k] = g[j][i]*(1.0-x) + g[j][i+zd]*x;
                }
                else {
                    if (k <= zd/2) g[j][i+k] = g[j][i];
                    else           g[j][i+k] = g[j][i+zd];
                }
            }
        }
    }
    return 0;
}

/*=============================================================================*
 *  Grid data Smoothing (by 1-2-1 Smoothing)
 *  by ����ȯ (1997. 3. 15)
 *=============================================================================*/
int grid_smooth (
    float **g,      /* input -> output  */
    int   nx,       /* ���� [0:nx,0:ny] */
    int   ny,
    float missing   /* ���ϴ� �ڷ� ���� */
)
{
    float  e[4], e1, e2;
    int    i, j;

    for (j = 0; j <= ny; j++) {
        e1 = g[j][0];
        e[0] = g[j][0];
        e[1] = g[j][1];

        for (i = 1; i < nx; i++) {
            e[2] = g[j][i+1];

            if (e[0] > missing && e[1] > missing && e[2] > missing)
                e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
            else if (e[0] > missing && e[1] <= missing && e[2] > missing)
                e2 = (e[0] + e[2]) * 0.5;
            else
                e2 = e[1];

            g[j][i-1] = e1;
            e1 = e2;
            e[0] = e[1];
            e[1] = e[2];
        }
        g[j][i-1] = e1;
    }

    for (i = 0; i <= nx; i++) {
        e1 = g[0][i];
        e[0] = g[0][i];
        e[1] = g[1][i];

        for (j = 1; j < ny; j++) {
            e[2] = g[j+1][i];

            if (e[0] > missing && e[1] > missing && e[2] > missing)
                e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
            else if (e[0] > missing && e[1] <= missing && e[2] > missing)
                e2 = (e[0] + e[2]) * 0.5;
            else
                e2 = e[1];

            g[j-1][i] = e1;
            e1 = e2;
            e[0] = e[1];
            e[1] = e[2];
        }
        g[j-1][i] = e1;
    }
    return 0;
}

/*******************************************************************************
 *
 *  ���� Ȯ�� (2�� Ȯ�븸 ����)
 *
 *******************************************************************************/
int grid_zooming(float **grid) {
    int  zx, zy, zm = 1, ox = 0, oy = 0, code, i, k;

    // 1. Ȯ��ø� ó��
    if (var.zoom_level == 0) return 0;

    // 2. ������ �ڷ� Ȯ��
    for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        ox = (zx-1)*var.NX/8;
        oy = (zy-1)*var.NY/8;
        code = grid_zoom(grid, var.NX, var.NY, var.zoom_rate, ox, oy, -90.0, 2);
    }
    return 0;
}

/*******************************************************************************
 *
 *  �ڷᰡ �̻��� �ִ� ���, ���� �̹��� ���
 *
 *******************************************************************************/
int rdr_qpf_err_img(int err)
{
  gdImagePtr im;
  char  text[120], tmp[120];
  int   YY, MM, DD, HH, MI;
  int   color_lvl[16];
  int   x, y, i, j, k, n;

  // 1. �̹��� ���� ����
  var.NI = var.size;
  var.NJ = var.NI;
  var.GI = var.NI;
  if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + TITLE_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_lvl[0] = gdImageColorAllocate(im, 240, 240, 240);   // ����
  color_lvl[1] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[0]);

  // 3. ���� �޽���
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(text, "TIME = %04d.%02d.%02d.%02d:%02d / err = %d", YY, MM, DD, HH, MI, err);
  gdImageString(im, gdFontLarge, 50, 50, text, color_lvl[1]);

  sprintf(text, "QPE = %d", var.qpe);
  gdImageString(im, gdFontLarge, 50, 70, text, color_lvl[1]);

  sprintf(text, "SIZE = %dpx", var.size);
  gdImageString(im, gdFontLarge, 50, 110, text, color_lvl[1]);

  if (err == 2)
    sprintf(text, "FILE = %s (file is not found)", var.fname);
  else
    sprintf(text, "FILE = %s", var.fname);
  gdImageString(im, gdFontLarge, 50, 130, text, color_lvl[1]);

  // 4. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);

  return 0;
}

/*=============================================================================*
 *  ���� ���� ���� �б�
 *
 *      map : inp:������ ����
 *      nx  : out:�������� �������� (km)
 *      ny  : out:���Ϲ��� �������� (km)
 *      sx  : out:�������� ������ġ (km)
 *      sy  : out:���Ϲ��� ������ġ (km)
 *=============================================================================*/
int grid_map_inf(char *map, int *nx, int *ny, int *sx, int *sy)
{
    FILE  *fp;
    char  buf[1024], map_list[8], value[16];

    fp = fopen(MAP_INI_FILE,"r");
    if (fp == NULL) exit(-1);

    while (fgets(buf,1024,fp)) {
        if (buf[0] == '#') continue;
        getword(map_list, buf, ':');

        if ( !strcmp(map, map_list) ) {
            getword(value, buf, ':');  *nx = atoi(value);
            getword(value, buf, ':');  *ny = atoi(value);
            getword(value, buf, ':');  *sx = atoi(value);
            getword(value, buf, ':');  *sy = atoi(value);
            break;
        }
    }
    fclose(fp);

    return 0;
}
