/*******************************************************************************
 *
 *  ���̴� �������ڷ� ǥ�⿡�� ���̴��ڷ� �д� �κ�
 *
 *******************************************************************************/
#include "rdr_stn2_img.h"

extern struct INPUT_VAR  var;
extern struct VOL_LIST vol_inf[];
extern short  **rdr_cmp_echo;  // �ռ� �����ڷ�

// �Լ� ����
int rdr_swp_bin(float, float, float, float, short, short *, float *);
int rdr_swp_echo(char, float, float, float, short, short *, short *, float *,
                 Sweep *, int, int, int, int, short, short *, short *);
int rdr_swp_cmp(char *, int, int, short, short *, short *, short *, short *);

/*******************************************************************************
 *
 *  1�� ������ ���̴� �����ڷ� ����
 *
 *******************************************************************************/
int rdr_cmp_stn()
{
  Radar  *radar;
  Volume *volume;
  Sweep  *sweep1;
  Ray    *ray, *ray1;
  char   fname[120], obs[8];
  struct stat st;
  float  stn_lon, stn_lat, stn_ht;
  float  cx[4], cy[4];
  float  x1, y1, x2, y2;
  float  s, r, az1, az2, az3, range;
  float  range_bin1[MAX_SWEEP], gate_size[MAX_SWEEP], range_max[MAX_SWEEP], elev[MAX_SWEEP];
  float  *swp_h[MAX_SWEEP];
  short  *swp_bin[MAX_SWEEP], *swp_ray[MAX_SWEEP];
  short  nbin_max[MAX_SWEEP], swp_ec[MAX_SWEEP], swp_ht[MAX_SWEEP];
  short  *s1, ec, ht, blank2s = BLANK2;
  int    x_min, x_max, y_min, y_max;
  int    voln, swpn, rayn, nsweep_max, seq5, ok, code;
  int    ia, ia1, ia2, ia3, ia4, ja, ja1, ja2, ja3, ja4;
  int    i, j, k, i1, j1, n1, n2;

  // 2. ���� ó��
  // 2.1. ���� ��ȣ Ȯ�� (����,������ CZ ���)
  if (strcmp(var.obs,"RN") == 0 ||strcmp(var.obs,"SN") == 0)
    strcpy(obs,"CZ");
  else
    strcpy(obs,var.obs);

  var.voln = -1;
  for (k = 0; k < 47; k++) {
    if (strcmp(vol_inf[k].vol_cd, obs) == 0) {
      var.voln = vol_inf[k].voln;
      break;
    }
  }
  if (var.voln < 0) return -10;

  // 2.2. UF���ϸ� Ȯ��, �����а�, VolȮ��
  code = rdr_stn_file();
  if (code < 0) return -10;
  if ((radar = RSL_uf_to_radar(var.fname)) == NULL) return -11;

  // 2.3. �ش� ������ �ִ��� Ȯ��
  ok = -1;
  if (var.voln >= 0) {
    for (k = 0; k < radar->h.nvolumes; k++) {
      if ((volume = radar->v[k]) == NULL) continue;
      if (k == var.voln) {
        ok = 0;
        break;
      }
    }
  }
  if (ok < 0) {
    // ����,������ ���, CZ�� ������ DZ�� ���(�̰���)
    if (strcmp(var.obs,"RN") == 0 || strcmp(var.obs,"SN") == 0) {
      var.voln = 0;
      for (k = 0; k < radar->h.nvolumes; k++) {
        if ((volume = radar->v[k]) == NULL) continue;
        if (k == var.voln) {
          ok = 0;
          break;
        }
      }
      if (ok < 0) return -12;
    }
    else
      return -12;
  }

  // 2.4. ������ Ȯ��
  var.swp_deg = -99;
  for (j = 0; j < radar->v[var.voln]->h.nsweeps; j++) {
    if ((sweep1 = radar->v[var.voln]->sweep[j]) == NULL) continue;
    if (j == var.swpn) {
      var.swp_deg = sweep1->h.elev;
      break;
    }
  }

  // 3. �⺻ ���� Ȯ��
  // 3.1. ����Ʈ�� �浵, ����, ���� Ȯ��
  stn_lon = radar->h.lond + (radar->h.lonm + (radar->h.lons)/60.0)/60.0;
  stn_lat = radar->h.latd + (radar->h.latm + (radar->h.lats)/60.0)/60.0;
  stn_ht  = radar->h.height;

  // 3.2. ���� �⺻ ���� �б�
  nsweep_max = radar->v[var.voln]->h.nsweeps;   // sweep ����
  for (swpn = 0; swpn < nsweep_max; swpn++) {
    range_bin1[swpn] = -1;
    gate_size[swpn]  = -1;
    nbin_max[swpn]   = -1;
    range_max[swpn]  = -1;
    if ((sweep1 = radar->v[var.voln]->sweep[swpn]) == NULL) continue;
    if (strcmp(var.cmp,"HSR") == 0)
      elev[0] = 0;
    else
      elev[swpn] = sweep1->h.elev;

    for (rayn = 0; rayn < sweep1->h.nrays; rayn++) {
      if ((ray = sweep1->ray[rayn]) != NULL) {
        range_bin1[swpn] = ray->h.range_bin1;
        gate_size[swpn]  = ray->h.gate_size;
        nbin_max[swpn]   = ray->h.nbins;
        range_max[swpn]  = nbin_max[swpn]*gate_size[swpn] + range_bin1[swpn];
        break;
      }
    }
  }

  // 3.3. ����� ���� ��ȯ�迭 ���
  for (swpn = 0; swpn < nsweep_max; swpn++) {
    if ((sweep1 = radar->v[var.voln]->sweep[swpn]) == NULL) continue;

    // 3.3.1. ���� ������ ray��ġ �迭 ����
    swp_ray[swpn] = svector(0,3600);
    rdr_swp_ray(var.stn, sweep1, swp_ray[swpn]);

    // 3.3.2. ����Ÿ� ��� ���� bin��ġ�� ������ �迭 ����
    swp_bin[swpn] = svector(0,nbin_max[swpn]*4);
    swp_h[swpn] = vector(0,nbin_max[swpn]*4);
    rdr_swp_bin(elev[swpn], stn_ht, range_bin1[swpn], gate_size[swpn], nbin_max[swpn], swp_bin[swpn], swp_h[swpn]);
  }

  // 4. ����Ʈ�� �ռ� ������ ���� �� �簢�� ������ ���� ��� ���
  conv_cof(stn_lon, stn_lat, stn_ht, range_max[0], cx, cy, &x_min, &x_max, &y_min, &y_max);

  // 5. �ռ� (�ռ������� ����Ʈ ������ ���ں��� ó��)
  // 5.0. �ռ����ڼ��� �� �ʱ�ȭ
  rdr_cmp_echo = smatrix(0, CMP_NY, 0, CMP_NX);
  for (j = 0; j <= CMP_NY; j++) {
    for (s1 = rdr_cmp_echo[j], i = 0; i <= CMP_NX; i++, s1++)
      *s1 = BLANK1;
  }

  seq5 = time2seq(2018, 3, 1, 0, 0, 'm');   // 5�� �������� �ٲ� ����

  for (j = y_min; j <= y_max; j++) {
  for (i = x_min; i <= x_max; i++) {
    if (i < 0 || i > CMP_NX || j < 0 || j > CMP_NY) continue;

    // 5.0. �ռ����������� ��ǥ
    x2 = i;
    y2 = j;

    // 5.1. ��Ÿ������� ���� ���̴��������� ��ǥ
    x1 = cx[0] + cx[1]*x2 + cx[2]*y2 + cx[3]*x2*y2;
    y1 = cy[0] + cy[1]*x2 + cy[2]*y2 + cy[3]*x2*y2;

    // 5.2. ���� ������
    if (y1 > 0 || y1 < 0)
      az1 = atan2(x1, y1)*RADDEG;
    else
      az1 = 0;
    if (az1 < 0) az1 += 360;

    // 5.3. �������̴� ���󱸿� Ȯ��
    ok = 0;
    if (!strcmp(var.stn,"DJK")) {     // ������
      if (az1 >= 44 && az1 <= 46)
        ok = 1;
      else if (az1 >= 79 && az1 <= 81)
        ok = 1;
      else if (az1 >= 152.5 && az1 <= 177.5)
        ok = 1;
    }
    else if (!strcmp(var.stn,"SRI")) {    // ������
      if (az1 >= 50 && az1 <= 120)
        ok = 1;
      else if (az1 >= 220 && az1 <= 280)
        ok = 1;
    }
    else if (!strcmp(var.stn,"MIL")) {    // ���ϻ�
      if (az1 >= 25 && az1 <= 27)
        ok = 1;
      else if (az1 >= 111 && az1 <= 225)
        ok = 1;
    }
    if (ok) continue;

    // 5.4. ����ǥ��� �̵��Ÿ� ���
    s = sqrt(x1*x1 + y1*y1)*1000;   // km -> m
    if (s >= range_max[0]) continue;

    // 5.5. �ռ������� ��ǥ���� ��� ���� ����Ʈ���� �ҿ��� �� ����
    if      (s <  5000) { ja3 = 5; ja4 = 5; }
    else if (s <  7000) { ja3 = 3; ja4 = 3; }
    else if (s < 10000) { ja3 = 2; ja4 = 2; }
    else if (s < 12000) { ja3 = 1; ja4 = 2; }
    else if (s < 17000) { ja3 = 1; ja4 = 1; }
    else if (s < 30000) { ja3 = 0; ja4 = 1; }
    else                { ja3 = 0; ja4 = 0; }

    ia3 = 0;   ia4 = 1;

    // 5.6. ���� ���ڰ� ���
    ec = BLANK1;
    ht = BLANK1;

    if (strcmp(var.cpi,"PPI") == 0) {
      for (swpn = 0; swpn < nsweep_max; swpn++) {
        swp_ec[swpn] = BLANK1;
        swp_ht[swpn] = BLANK1;
        if (swpn != var.swpn) continue;
        if ((sweep1 = radar->v[var.voln]->sweep[swpn]) == NULL) continue;

        code = rdr_swp_echo(var.maxavg, s, az1, gate_size[swpn], nbin_max[swpn],
                            swp_ray[swpn], swp_bin[swpn], swp_h[swpn], sweep1, 
                            ja3, ja4, ia3, ia4, blank2s,
                            &swp_ec[swpn], &swp_ht[swpn]);
        rdr_cmp_echo[j][i] = swp_ec[swpn];
        break;
      }
    }
    else {
      for (swpn = 0; swpn < nsweep_max; swpn++) {
        swp_ec[swpn] = BLANK1;
        swp_ht[swpn] = BLANK1;
        if ((sweep1 = radar->v[var.voln]->sweep[swpn]) == NULL) continue;

        code = rdr_swp_echo(var.maxavg, s, az1, gate_size[swpn], nbin_max[swpn],
                            swp_ray[swpn], swp_bin[swpn], swp_h[swpn], sweep1, 
                            ja3, ja4, ia3, ia4, blank2s,
                            &swp_ec[swpn], &swp_ht[swpn]);

        ok = rdr_swp_cmp(var.cpi, swpn, nsweep_max, var.cappi_ht, swp_ec, swp_ht, &ec, &ht);
        if (ok == 1) break;
      }
      if (ok) rdr_cmp_echo[j][i] = ec;
    }
  }
  }

  // 6. �޸� �ݳ�
  for (k = 0; k < nsweep_max; k++) {
    sweep1 = radar->v[var.voln]->sweep[k];
    if (sweep1 == NULL) continue;

    free_vector(swp_h[k],0,nbin_max[k]*4);
    free_svector(swp_bin[k],0,nbin_max[k]*4);
    free_svector(swp_ray[k],0,3600);
  }
  RSL_free_radar(radar);
  return 0;
}

/*=============================================================================*
 *  ���� ������ ray��ġ�� ����� �迭 ����(0.1�� �������� ��)
 *=============================================================================*/
int rdr_swp_ray(
  char  *stn_cd,    // �����ڵ�
  Sweep *sweep,     // ���̴� �����ڷ�
  short *swp_ray    // �������� ray ��ġ
)
{
  Ray    *ray;
  float  az0, az1, az2, az3, az4;
  int    i, j, k, i1, i2;

  if (strcmp(stn_cd,"IIA") == 0)  // ��õ������ �ںϱ���
    az4 = -7.53;
  else
    az4 = 0.0;

  for (i = 0; i < 3600; i++)
    swp_ray[i] = -1;

  for (j = 0; j < sweep->h.nrays; j++) {
    if ((ray = sweep->ray[j]) == NULL) continue;
    if (ray->h.beam_width == 0) ray->h.beam_width = 1.0;

    az0 = ray->h.azimuth + az4;
    if (az0 < 0) az0 += 360;
    if (az0 >= 360) az0 -= 360;

    az1 = (az0 - 0.65*ray->h.beam_width)*10;
    az2 = (az0 + 0.65*ray->h.beam_width)*10;

    i1 = floor(az1);
    i2 = ceil(az2);

    if (i1 >= 0 && i2 < 3600) {
      for (i = i1; i <= i2; i++) {
        az3 = i;
        if (az3 >= az1 && az3 < az2) swp_ray[i] = j;
      }
    }
    else if (i1 < 0) {
      for (i = 0; i <= i2; i++) {
        az3 = i;
        if (az3 >= az1 && az3 < az2) swp_ray[i] = j;
      }
      for (i = 3600+i1-1; i < 3600; i++) {
        az3 = i;
        if (az3 >= az1+3600 && az3 < 3600) swp_ray[i] = j;
      }
    }
    else if (i2 >= 3600) {
      for (i = i1; i < 3600; i++) {
        az3 = i;
        if (az3 >= az1 && az3 < az2) swp_ray[i] = j;
      }
      for (i = 0; i <= i2-3600; i++) {
        az3 = i;
        if (az3 >= 0 && az3 < az2-3600) swp_ray[i] = j;
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  ����Ÿ� ��� ���� bin��ġ�� ������ �迭 ����(�ػ� 4��� ��)
 *=============================================================================*/
int rdr_swp_bin(
  float elev,       // ������(degree)
  float stn_ht,     // ���׳� �ع߰���(m)
  float range_bin1, // 1th ���� ��ġ(m)
  float gate_size,  // gate ũ��(m)
  short nbin_max,   // gate ����
  short *swp_bin,   // [���] ��ġ
  float *swp_h      // [���] ����(m)
)
{
  double alpha, cs, ss, re1, s, r;
  double range_max = gate_size*nbin_max + range_bin1;   // �ִ�Ÿ�(m)
  int    nbin_max1 = nbin_max*4;
  int    i, i1;

  re1 = 4.0*(RE + stn_ht)/3.0;
  cs = cos(elev*DEGRAD);
  ss = sin(elev*DEGRAD);

  for (i = 0; i < nbin_max1; i++) {
    swp_bin[i] = -1;
    swp_h[i] = -1;

    s = 0.25*gate_size*i;
    alpha = 1 - pow((double)(cs/sin(s/re1)), (double)(2.0));
    r = -(re1/alpha)*(sqrt(ss*ss - alpha) + ss);
    if (r >= range_max || r <= 0) continue;

    i1 = (int)((r - range_bin1)/gate_size);   // �� ������ s��ġ�� �ش��ϴ� gate��ġ
    if (i1 >= nbin_max-1) continue;

    swp_bin[i] = i1;
    swp_h[i] = sqrt(r*r + re1*re1 + 2.0*ss*r*re1) - re1 + stn_ht;
  }
  return 0;
}

/*=============================================================================*
 *  �ռ����� �������� �ش��ϴ� ����Ʈ�� ���� ���ڿ� �������� ���
 *=============================================================================*/
int rdr_swp_echo(
  char  maxavg,     // �ҿ����� �ִ밪(M), ��հ�(A)
  float s,          // ��ǥ����� �Ÿ�(m)
  float az1,        // ������(deg.)
  float gate_size,  // gateũ��(m)
  short nbin_max,   // �ִ�bin��
  short *swp_ray,   // ������ ��ġ����
  short *swp_bin,   // bin ��ġ����
  float *swp_h,     // bin �ع߰���
  Sweep *sweep1,    // ���� ���̴�����
  int   ja3,        // �ҿ����� ����
  int   ja4,        // ����������[-ja3,ja4]
  int   ia3,        // bin ���� [-ia3,ia4]
  int   ia4,
  short blank2s,    // NULL��
  short *swp_ec,    // [���] ��� ���ڰ�
  short *swp_ht     // [���] ��ǥ �ع߰���(m)
)
{
  Ray   *ray1;
  float ec1, ec2, ht1, ht2;
  int   first;
  int   i, i1, ia, ia1, ia2, j, j1, ja, ja1, ja2, k, n1;

  // 1. �ش� bin�� ��ġ Ȯ��
  i1 = (int)(s*4.0/gate_size);
  if (i1 < 0 || i1 >= nbin_max*4-1) return -1;
  ht1 = swp_h[i1];    // �ش� ��ġ�� ����(m)

  ia = swp_bin[i1];
  if (ia < 0 || ia >= nbin_max) return -2;

  // 2. �ش� �������� ray ��ġ Ȯ��
  j1 = (int)(az1*10);
  ja = swp_ray[j1];
  if (ja < 0) return -3;

  // 3. �ִ밪�� ��ǥ������
  if (maxavg != 'A') {
    first = 0;
    ec2 = -300;

    for (ja1 = ja-ja3; ja1 <= ja+ja4; ja1++) {
      ja2 = ja1;
      if (ja2 < 0) ja2 += sweep1->h.nrays;
      if (ja2 >= sweep1->h.nrays) ja2 -= sweep1->h.nrays;

      ray1 = sweep1->ray[ja2];
      for (ia1 = ia-ia3; ia1 <= ia+ia4; ia1++) {
        if (ia1 < 0 || ia1 >= nbin_max) continue;
        ec1 = ray1->h.f(ray1->range[ia1]);
        if (first == 0) {
          ec2 = ec1;
          first = 1;
        }
        else {
          if (ec1 > -30.0 && ec1 < 100 && ec2 < ec1) ec2 = ec1;
        }
      }
    }

    if (ec2 > -30.0 && ec2 < 100)
      *swp_ec = (short)(ec2*100);
    else
      *swp_ec = blank2s;

    if (ht1 > 0 && ht1 < 20000)
      *swp_ht = (short)(ht1);
    else
      *swp_ht = blank2s;
  }

  // 4. ��հ��� ��ǥ������
  else {
    ec2 = 0;  n1 = 0;
    for (ja1 = ja-ja3; ja1 <= ja+ja4; ja1++) {
      ja2 = ja1;
      if (ja2 < 0) ja2 += sweep1->h.nrays;
      if (ja2 >= sweep1->h.nrays) ja2 -= sweep1->h.nrays;

      ray1 = sweep1->ray[ja2];
      for (ia1 = ia-ia3; ia1 <= ia+ia4; ia1++) {
        if (ia1 < 0 || ia1 >= nbin_max) continue;
        ec1 = ray1->h.f(ray1->range[ia1]);
        if (ec1 > -30.0 && ec1 < 100) {
          ec2 += ec1;
          n1++;
        }
      }
    }

    if (n1 == 0)
      *swp_ec = blank2s;
    else
      *swp_ec = (short)((ec2/(float)n1)*100);

    if (ht1 > 0 && ht1 < 20000)
      *swp_ht = (short)(ht1);
    else
      *swp_ht = blank2s;
  }
  return 0;
}

/*=============================================================================*
 *  �ش� sweep�� ���ڰ����� PPI, CAPPI, CMAX ���
 *  - return : 0(��� ���), 1(�Ϸ�)
 *=============================================================================*/
int rdr_swp_cmp(
  char  *cmp,     // �ռ����
  int   swpn,     // sweep number
  int   nsweep_max, // sweep����
  short cappi_ht, // CAPPI ���ذ���(m)
  short *swp_ec,  // sweep�� ���ڰ�
  short *swp_ht,  // sweep�� ������
  short *ec,      // [���] �ռ� ���ڰ�
  short *ht       // [���] �ռ� ������
)
{
  float d2;
  int   ok;

  if (strcmp(cmp,"PPI") == 0) {
    if (swp_ht[swpn] > 0) {
      *ec = swp_ec[swpn];
      *ht = swp_ht[swpn];
    }
    ok = 1;
  }
  else if (strcmp(cmp,"CPP") == 0) {
    if (swpn == 0) {
      *ec = swp_ec[swpn];
      *ht = swp_ht[swpn];
      if (cappi_ht <= swp_ht[swpn])
        ok = 1;
      else
        ok = 0;
    }
    else if (swpn == nsweep_max-1) {
      *ec = swp_ec[swpn];
      *ht = swp_ht[swpn];
      ok = 1;
    }
    else {
      if (swp_ht[swpn-1] < cappi_ht) {
        if (cappi_ht <= swp_ht[swpn]) {
          if (swp_ec[swpn] > BLANK2) {
            if (swp_ec[swpn-1] > BLANK2) {
              d2 = (float)(swp_ht[swpn] - swp_ht[swpn-1]);
              *ec = (short)( (float)swp_ec[swpn-1]*(float)(swp_ht[swpn] - cappi_ht)/d2
                             + (float)swp_ec[swpn]*(float)(cappi_ht - swp_ht[swpn-1])/d2 );
              *ht = cappi_ht;
            }
            else {
              *ec = swp_ec[swpn];
              *ht = swp_ht[swpn];
            }
          }
          else {
            *ec = swp_ec[swpn-1];
            *ht = swp_ht[swpn-1];
          }
          ok = 1;
        }
        else if (swp_ec[swpn] < BLANK2) {
          ok = 1;
        }
      }
      else
        ok = 0;
    }
  }
  else if (strcmp(cmp,"CMX") == 0) {
    if (swp_ht[swpn] > 0) {
      if (swpn == 0) {
        *ec = swp_ec[swpn];
        *ht = swp_ht[swpn];
      }
      else {
        if (*ec < swp_ec[swpn]) {
          *ec = swp_ec[swpn];
          *ht = swp_ht[swpn];
        }
      }
    }
    ok = 0;
  }
  return ok;
}

/*******************************************************************************
 *  ��ǥ��ȯ ��� ���
 *******************************************************************************/
int conv_cof(stn_lon, stn_lat, stn_ht, range_max, cx, cy, x_min, x_max, y_min, y_max)
  float  stn_lon, stn_lat, stn_ht;
  float  range_max;
  float  cx[4], cy[4];
  int    *x_min, *x_max, *y_min, *y_max;
{
  struct azed_parameter  rdr;
  struct lamc_parameter  map;
  float  xl[4], yl[4], xa[4], ya[4];
  float  lon, lat;
  int    i, j;

  // 1. ������ ����
  // 1.1. ����Ʈ ������
  rdr.Re    = (RE + stn_ht)*0.001;
  rdr.grid  = 1.0;
  rdr.slon  = stn_lon;
  rdr.slat  = stn_lat;
  rdr.olon  = stn_lon;
  rdr.olat  = stn_lat;
  rdr.xo    = 0;
  rdr.yo    = 0;
  rdr.first = 0;

  // 1.2. �ռ� ������ (B-map)
  map.Re    = RE*0.001;
  map.grid  = 0.5;
  map.slat1 = 30.0;
  map.slat2 = 60.0;
  map.olon  = 126.0;
  map.olat  = 38.0;
  map.xo    = 560.0 / map.grid;
  map.yo    = 840.0 / map.grid;
  map.first = 0;

  // 2. ����Ʈ������ �ռ��忡�� ���� ���� Ȯ��
  // 2.1. ����Ʈ ���������� �ױ����� ��ǥ
  xa[0] = -range_max*0.001;  ya[0] = -range_max*0.001;
  xa[1] = range_max*0.001;   ya[1] = -range_max*0.001;
  xa[2] = range_max*0.001;   ya[2] = range_max*0.001;
  xa[3] = -range_max*0.001;  ya[3] = range_max*0.001;

  // 2.2. �ռ� map���� �ش�Ǵ� ��ǥ
  for (i = 0; i < 4; i++) {
    azedproj(&lon, &lat, &xa[i], &ya[i], 1, &rdr);
    lamcproj_ellp(&lon, &lat, &xl[i], &yl[i], 0, &map);
  }

  // 2.3. �ռ� map������ ����
  *x_min = 99999;   *y_min = 99999;
  *x_max = -99999;  *y_max = -99999;

  for (i = 0; i < 4; i++) {
    if (*x_min > (int)xl[i]) *x_min = (int)xl[i];
    if (*x_max < (int)xl[i]) *x_max = (int)xl[i];
    if (*y_min > (int)yl[i]) *y_min = (int)yl[i];
    if (*y_max < (int)yl[i]) *y_max = (int)yl[i];
  }

  // 3. ��ȯ��� ���
  // 3.1. ��ǥ��ȯ�� ���� �������� �������� 60% ���� ��ġ�� ����
  for (i = 0; i < 4; i++) {
    xa[i] *= 0.6;  ya[i] *= 0.6;
    azedproj(&lon, &lat, &xa[i], &ya[i], 1, &rdr);
    lamcproj_ellp(&lon, &lat, &xl[i], &yl[i], 0, &map);
  }

  // 3.2. �ռ� map���� ����Ʈ map���� ��ȯ��� ���
  matrix_cal(xa, xl, yl, cx);
  matrix_cal(ya, xl, yl, cy);

  return 0;
}

/*=============================================================================*
 *  ��� ���
 *=============================================================================*/
int matrix_cal(a, xl, yl, c)
  float a[4], xl[4], yl[4], c[4];
{
  float  mm[4][4], d;
  int  indx[4];
  int  i, j;

  for (j = 0; j < 4; j++) {
    mm[j][0] = 1.0;
    mm[j][1] = xl[j];
    mm[j][2] = yl[j];
    mm[j][3] = xl[j] * yl[j];
    c[j] = a[j];
  }

  ludcmp(mm,4,indx,&d);
  lubksb(mm,4,indx,c);

  return 0;
}

/*=============================================================================*
 *  < LU decomposition >            from  Numerical Recips
 *=============================================================================*/
int   lubksb(a,n,indx,b)
float a[4][4],b[4];
int   n,*indx;
{
  int  i,ii=-1,ip,j;
  float  sum;

  for (i=0;i<n;i++) {
    ip=indx[i];
    sum=b[ip];
    b[ip]=b[i];
    if (ii >= 0)
      for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
    else if (sum) ii=i;
    b[i]=sum;
  }
  for (i=n-1;i>=0;i--) {
    sum=b[i];
    for (j=i+1;j<n;j++) sum -= a[i][j]*b[j];
    b[i]=sum/a[i][i];
  }
  return 0;
}

/*=============================================================================*
 *  < LU decomposition >            from  Numerical Recips
 *=============================================================================*/
#define TINY 1.0e-20;

int   ludcmp(a,n,indx,d)
float a[4][4];
int   n,*indx;
float *d;
{
  int  i,imax,j,k;
  float  big,dum,sum,temp;
  float  vv[8];

  *d=1.0;
  for (i=0;i<n;i++) {
    big=0.0;
    for (j=0;j<n;j++) {
      if ((temp=fabs(a[i][j])) > big) big=temp;
    }
    if (big == 0.0) printf("Singular matrix in routine LUDCMP\n");
    vv[i]=1.0/big;
  }
  for (j=0;j<n;j++) {
    for (i=0;i<j;i++) {
      sum=a[i][j];
      for (k=0;k<i;k++) sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
    }
    big=0.0;
    for (i=j;i<n;i++) {
      sum=a[i][j];
      for (k=0;k<j;k++)
        sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
      if ( (dum=vv[i]*fabs(sum)) >= big) {
        big=dum;
        imax=i;
      }
    }
    if (j != imax) {
      for (k=0;k<n;k++) {
        dum=a[imax][k];
        a[imax][k]=a[j][k];
        a[j][k]=dum;
      }
      *d = -(*d);
      vv[imax]=vv[j];
    }
    indx[j]=imax;
    if (a[j][j] == 0.0) a[j][j]=TINY;
    if (j != n-1) {
      dum=1.0/(a[j][j]);
      for (i=j+1;i<n;i++) a[i][j] *= dum;
    }
  }
  return 0;
}

/*=============================================================================*
 *  ���̴� �������ڷ� ���� ���� Ȯ��
 *=============================================================================*/
int rdr_stn_file()
{
  struct stat st;
  int    YY, MM, DD, HH, MI;
  int    code, rtn;

  // 1. �ڷ� �ð�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  // 2. ���ϸ�
  if (strcmp(var.cmp,"RAW") == 0) {
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_%04d%02d%02d%02d%02d.uf",
            RDR_RAW_DIR, YY, MM, DD, var.stn, YY, MM, DD, HH, MI);
  }
  else if (strcmp(var.cmp,"QCD") == 0) {
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_FQC_%04d%02d%02d%02d%02d.uf",
            RDR_QCD_DIR, YY, MM, DD, var.stn, YY, MM, DD, HH, MI);
  }
  else if (strcmp(var.cmp,"HSR") == 0) {
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_HSR2_%04d%02d%02d%02d%02d.uf",
            RDR_HSR_DIR, YY, MM, DD, var.stn, YY, MM, DD, HH, MI);
  }
  else if (strcmp(var.cmp,"HCI") == 0) {
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_HCI_%04d%02d%02d%02d%02d.uf",
            RDR_HCI_DIR, YY, MM, DD, var.stn, YY, MM, DD, HH, MI);
  }
  else if (strcmp(var.cmp,"LNG") == 0) {
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_LNG_%04d%02d%02d%02d%02d.uf",
            RDR_LNG_DIR, YY, MM, DD, var.stn, YY, MM, DD, HH, MI);
  }
  else if (strcmp(var.cmp,"LQC") == 0) {
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_LNG_FQC_%04d%02d%02d%02d%02d.uf",
            RDR_LNG_DIR, YY, MM, DD, var.stn, YY, MM, DD, HH, MI);
  }
  else if (strcmp(var.cmp,"VER") == 0) {
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_VER_%04d%02d%02d%02d%02d.uf",
            RDR_VER_DIR, YY, MM, DD, var.stn, YY, MM, DD, HH, MI);
  }

  // 3. ���� ���� ���� Ȯ��
  code = stat(var.fname, &st);
  if (code < 0 || st.st_size <= 100) {
    if (strcmp(var.cmp,"HSR") == 0) {
      sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_HSR1_%04d%02d%02d%02d%02d.uf",
              RDR_HSR_DIR, YY, MM, DD, var.stn, YY, MM, DD, HH, MI);
      code = stat(var.fname, &st);
      if (code < 0 || st.st_size <= 100)
        rtn = -1;
      else
        rtn = 0;
    }
    else
      rtn = -1;
  }
  else
    rtn = 0;
  return rtn;
}
