/*******************************************************************************
**
**  ���̴� �ռ��ڷ� URL-API �׽�Ʈ��
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.7.19)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>

#include "cgiutil.h"
#include "nrutil.h"
#include "map_ini.h"
#include "url_io.h"

#define  NX  2305
#define  NY  2881

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main()
{
  // ����1
  //rdr_cmp_get1();

  // ����2
  rdr_cmp_get2();
  return 0;
}

/*=============================================================================*
 *  disp=B���� ���������� �̸� �˾Ƽ� ������ �迭�� �̸� ������ ���
 *=============================================================================*/
int rdr_cmp_get1()
{
  URL_FILE *fr;
  short  nx1, ny1, dbz[NY][NX];  // �迭�� �ʹ� ũ��� �� �ȵɼ��� ����.
  char   url[1000];
  int    i, j, k, n;

  // URL ����
  strcpy(url, "http://rdr.kma.go.kr/cgi-bin/rdr/nph-rdr_cmp1_api?&tm=201807091620&cmp=HSR&obs=ECHO&qcd=QPE&acc=&map=HB&disp=B");
  fr = url_fopen(url, "r");
  if (!fr) {
    printf("can not open url (%s)\n", url);
    return -1;
  }

  // URL-API �б�
  n = url_fread(&nx1, 1, sizeof(nx1), fr);
  n = url_fread(&ny1, 1, sizeof(ny1), fr);
  n = url_fread(dbz, NY*NX, 2, fr);
  url_fclose(fr);

  // ��� Ȯ��
  printf("%d %d\n", nx1, ny1);
  for (j = 0; j < ny1; j++)
    printf("j = %4d, %6d %6d %6d\n", j, dbz[j][nx1/4], dbz[j][nx1/2], dbz[j][3*nx1/4]);
  return 0;
}

/*=============================================================================*
 *  disp=B���� ���������� �о �迭�� ���������� ���� ��� ���
 *=============================================================================*/
int rdr_cmp_get2()
{
  URL_FILE *fr;
  short  **dbz;
  short  nx, ny;
  char   url[1000];
  int    i, j, k, n;

  // URL ����
  strcpy(url, "http://rdr.kma.go.kr/cgi-bin/rdr/nph-rdr_cmp1_api?&tm=201807091620&cmp=HSR&obs=ECHO&qcd=QPE&acc=&map=HB&disp=B");
  fr = url_fopen(url, "r");
  if (!fr) {
    printf("can not open url (%s)\n", url);
    return -1;
  }

  // URL-API �б�
  n = url_fread(&nx, 1, sizeof(nx), fr);
  n = url_fread(&ny, 1, sizeof(ny), fr);
  dbz = smatrix(0, (int)ny, 0, (int)nx);   // �迭 ����
  for (j = 0; j < ny; j++)
    n = url_fread(dbz[j], nx, 2, fr);
  url_fclose(fr);

  // ���
  printf("%d %d\n", nx, ny);
  for (j = 0; j < ny; j++)
    printf("j = %4d, %6d %6d %6d\n", j, dbz[j][nx/4], dbz[j][nx/2], dbz[j][3*nx/4]);
  free_smatrix(dbz, 0, (int)ny, 0, (int)nx);
  return 0;
}
