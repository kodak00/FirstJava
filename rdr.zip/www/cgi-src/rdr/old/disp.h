/*-------------------------------------------------------------*/
/* �м����� (1km ����)                                         */
/*-------------------------------------------------------------*/
#define  NX_S  1080     /* S : ���� �ƽþ� ��ü ���� */
#define  NY_S  1170
#define  NX_M  4800     /* M : MM5 ���ƽþ� ���� */
#define  NY_M  4160
#define  NX_R  1024     /* R : ���̴� ���� */
#define  NY_R  1024
#define  NX_B  1152     /* B : �ѹݵ� */
#define  NY_B  1440
#define  NX_A  576      /* A : ���� */
#define  NY_A  720
#define  NX_G  740      /* G : Digital Forecast Area */
#define  NY_G  1260
#define  NX_D  684      /* D : ����(+����) */
#define  NY_D  684
#define  NX_E  768      /* E : ����(+����,�̾) */
#define  NY_E  768
#define  NX_F  1536     /* F : �ѹݵ�(Ȯ��) */
#define  NY_F  1536
#define  NX_W  900      /* W : WPMM */
#define  NY_W  1050
#define  NX_V  795      /* V : VSRF */
#define  NY_V  795
#define  NX_J  5700     /* J : �ѹݵ�+�Ϻ� */
#define  NY_J  5100
#define  NX_T  12000    /* T : MTSAT */
#define  NY_T  9000

/*-------------------------------------------------------------*/
/* �м��������� �������� ��ġ (1km ����)                       */
/*-------------------------------------------------------------*/
#define  SX_S  480
#define  SY_S  570
#define  SX_M  2620
#define  SY_M  1780
#define  SX_R  440
#define  SY_R  770
#define  SX_B  560
#define  SY_B  840
#define  SX_A  144
#define  SY_A  560
#define  SX_G  210
#define  SY_G  665
#define  SX_D  154
#define  SY_D  581
#define  SX_E  238
#define  SY_E  665
#define  SX_F  720
#define  SY_F  920
#define  SX_W  365
#define  SY_W  770
#define  SX_V  310
#define  SY_V  615
#define  SX_J  2850
#define  SY_J  2550
#define  SX_T  6000
#define  SY_T  4500

#define  GMSRG_LEN  (NY_S+1)*(NX_S+1)+513
#define  GMSLC_LEN  (NY_B+1)*(NX_B+1)+515

#define  BOUNDARY_pixel  20
#define  TITLE_pixel     20
#define  TITLE_pixel2    15
#define  LEVEL_pixel     35
#define  TTL_pixel       15
#define  LVL_pixel       27
#define  LEG_pixel       8
#define  END_pixel       14

struct COLOR {
    int  R;
    int  G;
    int  B;
};

struct GMSRG_FILE {
    short index[256];
    char  blank;
    char  d[NY_S+1][NX_S+1];
};

struct GMSLC_FILE {
    short index[256];
    char  blank[3];
    char  d[NY_B+1][NX_B+1];
};

struct WINDOW {
    int  width;
    int  height;
    int  border_width;
    int  background;
    int  foreground;
    int  border;
    int  shadow;
};

struct LEVEL {
    int   num;
    float itv;
    float min;
    int   color[128];
};

struct POINT {
    int x;
    int y;
};
