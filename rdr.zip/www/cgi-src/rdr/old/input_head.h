#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <gd.h>
#include <gdfontt.h>
#include <gdfonts.h>
#include <gdfontmb.h>
#include <gdfontl.h>
#include <gdfontg.h>
#include <zlib.h>
#include <zconf.h>
#include "/ncomis/src/include/cgiutil.h"
#include "/www/htdocs/gis/program/map_ini.h"
#include "/www/cgi-src/include/nrutil.h"
#include "/www/cgi-src/include/disp.h"

#define  MAP_DIR    "/www/cgi-bin/ref/bln"
#define  COLOR_DIR  "/www/cgi-bin/ref/color"
