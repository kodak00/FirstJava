/*******************************************************************************
**
**  ������ ���̴��ڷḦ �ռ��������� ��ȯ
**
**=============================================================================*
**
**   o �ۼ��� : ����ȯ (2018.2.15)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "rsl_wrc.h"
#include "nrutil.h"
#include "stn_inf.h"
#include "map_ini.h"
#include "rdr_cmp_ppi_header.h"
#include "pseudo_cappi.h" //add (RadarCener,KWG,2012.02.13)
#include "rdr_cmp_stn_img.h"

#define  SAV_CMP_DIR    "/DATA/RDR/CMP"
#define  FTP_CMP_DIR    "/rdr/FTPD/RDR"
#define  RAW_UF_DIR     "/DATA/RDR/RAW"
#define  QCD_UF_DIR     "/DATA/RDR/QCD"
#define  HSR_UF_DIR     "/DATA/RDR/HSR"
#define  RDR_CMP_INI    "/rdr/REF/INI/rdr_cmp.ini"

#define  DEGRAD  3.1415927/180.0
#define  RADDEG  180.0/3.1415927

#define  BLANK1  -30000   /* No Area */
#define  BLANK2  -25000   /* No Data */
#define  BLANK3  -20000   /* Minimum Data */

//-----------------------------------------------------------------------------
// �ռ��ڷ��� ���ڿ��� (1152 km x 1440 km : 1 km ���ڰ���)
#define  NI  1152
#define  NJ  1440

//-----------------------------------------------------------------------------
// ���̴� �����ڷ� ���ڿ��� (1000.5 km x 1000.5 km : 500m ���ڰ���)
#define  NS  2000
int      MS;

extern struct INPUT_VAR var;
extern short  rdr_cmp[NJ+1][NI+1];     // �ռ��ڷ� 1km

//-----------------------------------------------------------------------------

short  rdr_stn[NS+2][NS+2];     // ������ 0.5km �����ڷ�
Radar  *radar;
Volume *volume;
Sweep  *sweep;
Ray    *ray;
int rdr_cmp_grd(float, float, float);

/*******************************************************************************
 *
 *  1�� ������ ���̴� �����ڷ� ����
 *
 *******************************************************************************/
int rdr_cmp_stn()
{
  char   vol_code[47][4] = {"DZ","VR","SW","CZ","ZT","DR","LR","ZD","DM","RH",
                            "PH","XZ","CD","MZ","MD","ZE","VE","KD","TI","DX",
                            "CH","AH","CV","AV","SQ","VS","VL","VG","VT","NP",
                            "HC","VC","V2","S2","V3","S3","CR","CC","PR","SD",
                            "ZZ","RD","ET","EZ","TV","ZV","SN"};
  float  cappi_ht[11] = {1.0, 1.5, 2, 3, 4, 5, 6, 7, 8, 9, 10};
  float  elev[2], rl[2];
  float  stn_lon, stn_lat, stn_ht;  // ���̴������� �浵, ����, �ع߰���
  float  RE, hl;        // �����ݰ�(m), CAPPI ����(m)
  int    YY, MM, DD, HH, MI;
  int    index, ppi, code;
  int    i, j, k;

  // 1. �������� �ƴ����� �ڷ� �ʱ�ȭ
  for (j = 0; j <= NJ; j++) {
    for (i = 0; i <= NI; i++)
      rdr_cmp[j][i] = BLANK1;
  }

  // 2. UF ���� �б�
  code = rdr_uf_file(var.stn_cd, var.seq, var.data, var.qcd, var.fname);
  if (code <= 0) {
    var.exist = 0;
    return -1;
  }
  else
    var.exist = 1;

  // 3. UF ���� �б�
  if ((radar = RSL_uf_to_radar(var.fname)) == NULL) return -2;

  if (strcmp(var.vol,"RN") == 0 || strcmp(var.vol,"SD") == 0) {
    if (strstr(var.stn_cd,"RKJK") || strstr(var.stn_cd,"RKSG"))
      volume = radar->v[DZ_INDEX];
    else
      volume = radar->v[CZ_INDEX];
  }
  else {
    for (k = 0; k < 47; k++) {
      if (strcmp(var.vol,vol_code[k]) == 0) {
        index = k;
        break;
      }
    }
    volume = radar->v[index];
  }
  if (volume == NULL) return -3;

  // 4. ������ �����ڷ� �ʱ�ȭ
  stn_lon = radar->h.lond + (radar->h.lonm + (radar->h.lons)/60.0)/60.0;
  stn_lat = radar->h.latd + (radar->h.latm + (radar->h.lats)/60.0)/60.0;
  stn_ht  = radar->h.height;

  RE = 6371008.77 + stn_ht; // unit : m
  hl = 1500 - stn_ht;       // unit : m

  for (j = 0; j <= NS+1; j++) {
    for (i = 0; i <= NS+1; i++)
      rdr_stn[j][i] = BLANK1;
  }

  // 5. ������ 0.5km �����ڷ� ����
  // 5.1. PPIO
  if (var.data == 3) {
    for (k = 0; k < volume->h.nsweeps; k++) {
      if ((sweep = volume->sweep[k]) != NULL && k == var.swp) {
        elev[1] = sweep->h.elev;
        var.elev = elev[1];
        rl[1] = sqrt(RE*RE*sin(elev[1]*DEGRAD)*sin(elev[1]*DEGRAD) + hl*hl + 2.0*hl*RE) - RE*sin(elev[1]*DEGRAD);

        for (j = 0; j < sweep->h.nrays; j++) {
          if ((ray = sweep->ray[j]) != NULL) 
            rdr_stn_ray2grd(var.stn_cd, stn_ht, rl, elev);
        }
        break;
      }
    }
  }

  // 5.2. CMAX
  else if (var.data == 2) {
    for (k = 0; k < volume->h.nsweeps; k++) {
      if ((sweep = volume->sweep[k]) != NULL) {
        elev[1] = sweep->h.elev;
        rl[1] = sqrt(RE*RE*sin(elev[1]*DEGRAD)*sin(elev[1]*DEGRAD) + hl*hl + 2.0*hl*RE) - RE*sin(elev[1]*DEGRAD);

        for (j = 0; j < sweep->h.nrays; j++) {
          if ((ray = sweep->ray[j]) != NULL)
            rdr_stn_ray2grd(var.stn_cd, stn_ht, rl, elev);
        }
        rl[0] = rl[1];
        elev[0] = elev[1];
      }
    }
  }

  // 5.2. CAPPI : Pseudo_cappi (RadarCener,KWG,2012.02.13)
  else if (var.data == 1) {
    var.elev = cappi_ht[var.swp];
    hl = cappi_ht[var.swp]*1000 - stn_ht;
    int lng = (volume->sweep[0]->ray[0]->h.nbins)*(volume->sweep[0]->ray[0]->h.gate_size) + volume->sweep[0]->ray[0]->h.range_bin1;
    pseudo_cappi(volume, hl, NS, NS, lng/1000, 500);
  }
  RSL_free_radar(radar);

  // 6. ��ó��
  // 6.1. 0.5km grid data smoothing
  rdr_stn_grd_sm();

  // 6.2. downsizing for 1km
  rdr_stn_grd_down();

  // 6.3. ������ �����ڷ� -> �ռ��ڷ� ���ڷ� ��ȯ
  rdr_cmp_grd(stn_lon, stn_lat, stn_ht);

  return 0;
}

/*=============================================================================*
 *  UF���ϸ��� ���� ���� Ȯ��
 *=============================================================================*/
int rdr_uf_file(char *stn_cd, int seq, int data, int qcd, char *fname)
{
  struct stat st;
  int    YY, MM, DD, HH, MI;
  int    size;
  int    code;

  // 1. �ð�Ȯ��
  seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  // 2. ���ϸ�
  //if (data == 3)
  //  sprintf(fname, "%s/%04d%02d/%02d/RDR_%s_NQS_%04d%02d%02d%02d%02d.uf",
  //          RAW_UF_DIR, YY, MM, DD, stn_cd, YY, MM, DD, HH, MI);
  //else {
    if (qcd == 0)
      sprintf(fname, "%s/%04d%02d/%02d/RDR_%s_%04d%02d%02d%02d%02d.uf",
              RAW_UF_DIR, YY, MM, DD, stn_cd, YY, MM, DD, HH, MI);
    else if (qcd == 1)
      sprintf(fname, "%s/%04d%02d/%02d/RDR_%s_FQC_%04d%02d%02d%02d%02d.uf",
              QCD_UF_DIR, YY, MM, DD, stn_cd, YY, MM, DD, HH, MI);
  //}

  // 3. ���翩�� Ȯ��
  code = stat(fname, &st);
  if (code < 0 || st.st_size <= 0)
    size = -1;
  else
    size = st.st_size;
  return size;
}

/*=============================================================================*
 *  1 Ray -> Griding
 *=============================================================================*/
int rdr_stn_ray2grd(stn_cd, rdr_ht, rl, elev)
  char  stn_cd[8];
  float rl[2], elev[2], rdr_ht;
{
  double tn1, tn2;
  float  angle[3], hs[2];
  float  range, cc, cr, cg, cs, s0, s1, s, r, ec1;
  short  ec, blank2s = BLANK2;
  int    MS1, area, ix, iy;
  int    i, j, k, i1, i2;

  // 1. �̰����ڷ�� �ڷᰡ ������ �̰����������� ó��
  if (strcmp(stn_cd,"RKSG") == 0 || strcmp(stn_cd,"RKJK") == 0)
    blank2s = BLANK1;
  else
    blank2s = BLANK3;

  // 2. ���� �� ��������
  angle[1] = ray->h.azimuth;
  if (strcmp(stn_cd,"IIA") == 0) angle[1] -= 7.53;   // �������� �ںϱ���
  if (angle[1] < 0.0) angle[1] += 360.0;

  area = ((int)angle[1]/45) % 8 + 1;

  if (angle[1] > 45.0) {
    angle[1] -= 45.0;
    angle[1] = fabs( angle[1] - ((int)angle[1]/90)*90 - 45.0 );
  }

  if (ray->h.beam_width == 0) ray->h.beam_width = 1.0;
  angle[0] = angle[1] - ray->h.beam_width - 0.1;
  angle[2] = angle[1] + ray->h.beam_width + 0.1;

  tn1 = tan(angle[0] * DEGRAD);
  tn2 = tan(angle[2] * DEGRAD);

  // 3. ���� �� ��ó��
  cc = 500;         // 500 m ���� ����
  range = (ray->h.nbins)*(ray->h.gate_size) + ray->h.range_bin1;
  MS1 = (int)(range/cc);
  if (MS1 > 1000) MS1 = 1000;
  if (MS < MS1) MS = MS1;

  cr = ray->h.range_bin1;
  cg = ray->h.gate_size;
  cs = cos(elev[1] * DEGRAD);

  // 4. ���
  for (j = 1; j <= MS1; j++) {
    i1 = (int)(tn1 * j + 0.95);
    i2 = (int)(tn2 * j - 0.05);

    if (i2 >= i1) {
      for (i = i1; i <= i2; i++) {
        s = cc * (sqrt(i*i + j*j) - 0.5);   // ������ �Ÿ�
        r = s / cs;                         // ����Ÿ�
        k = (int)((r - cr)/cg);             // ������ ���ڼ�

        if (k >= 0 && k < ray->h.nbins) {
          switch (area) {
            case 1:  iy = 1000 + j;  ix = 1000 + i;  break;
            case 2:  iy = 1000 + i;  ix = 1000 + j;  break;
            case 3:  iy = 1000 - i;  ix = 1000 + j;  break;
            case 4:  iy = 1000 - j;  ix = 1000 + i;  break;
            case 5:  iy = 1000 - j;  ix = 1000 - i;  break;
            case 6:  iy = 1000 - i;  ix = 1000 - j;  break;
            case 7:  iy = 1000 + i;  ix = 1000 - j;  break;
            case 8:  iy = 1000 + j;  ix = 1000 - i;
          }
          ec1 = ray->h.f(ray->range[k]);
          if (ec1 > 200.0 || ec1 < -100)
            ec = blank2s;
          else
            ec = (short)(ec1*100);

          if (rdr_stn[iy][ix] < ec) rdr_stn[iy][ix] = ec;
        }
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  Grid data Smoothing (by 1-2-1 Smoothing)
 *=============================================================================*/
int rdr_stn_grd_sm()
{
  float  e[4], e1, e2;
  int  s1, s2;
  int  i, j, k;

  s1 = 1000 - MS;
  s2 = 1000 + MS;

  for (j = s1; j < s2; j++) {
    e1 = rdr_stn[j][s1];
    e[0] = rdr_stn[j][s1];
    e[1] = rdr_stn[j][s1+1];

    for (i = s1+1; i < s2; i++) {
      e[2] = rdr_stn[j][i+1];
      if (e[0] > BLANK3 && e[1] > BLANK3 && e[2] > BLANK3)
        e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
      else if (e[0] > BLANK3 && e[1] <= BLANK3 && e[2] > BLANK3)
        e2 = (e[0] + e[2]) * 0.5;
      else
        e2 = e[1];

      rdr_stn[j][i-1] = (short)e1;
      e1 = e2;
      e[0] = e[1];
      e[1] = e[2];
    }
    rdr_stn[j][i-1] = (short)e1;
  }

  for (i = s1; i < s2; i++) {
    e1 = rdr_stn[s1][i];
    e[0] = rdr_stn[s1][i];
    e[1] = rdr_stn[s1+1][i];

    for (j = s1+1; j < s2; j++) {
      e[2] = rdr_stn[j+1][i];
      if (e[0] > BLANK3 && e[1] > BLANK3 && e[2] > BLANK3)
        e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
      else if (e[0] > BLANK3 && e[1] <= BLANK3 && e[2] > BLANK3)
        e2 = (e[0] + e[2]) * 0.5;
      else
        e2 = e[1];

      rdr_stn[j-1][i] = (short)e1;
      e1 = e2;
      e[0] = e[1];
      e[1] = e[2];
    }
    rdr_stn[j-1][i] = (short)e1;
  }
  return 0;
}

/*=============================================================================*
 *  ������ �����ڷ� �ػ� ���� (500 m -> 1 km)
 *=============================================================================*/
int rdr_stn_grd_down()
{
  short  e1;
  int  i, j, i1, j1, k;

  for (j = 0; j <= NS; j += 2) {
    j1 = j + 1;

    for (i = 0; i <= NS; i += 2) {
      i1 = i + 1;

      e1 = rdr_stn[j][i];
      if (e1 < rdr_stn[j][i1] ) e1 = rdr_stn[j][i1];
      if (e1 < rdr_stn[j1][i] ) e1 = rdr_stn[j1][i];
      if (e1 < rdr_stn[j1][i1]) e1 = rdr_stn[j1][i1];

      rdr_stn[j][i] = e1;
      rdr_stn[j][i1] = e1;
      rdr_stn[j1][i] = e1;
      rdr_stn[j1][i1] = e1;
    }
  }
  return 0;
}

/*******************************************************************************
 *
 *  Radar data sum
 *
 *******************************************************************************/
int rdr_cmp_grd(float lon, float lat, float ht)
{
  float  cx[4], cy[4];
  float  xl, yl;
  short  e1;
  int    x_min, x_max, y_min, y_max;
  int    i, j, ia, ja;

  conv_cof(cx, cy, &x_min, &x_max, &y_min, &y_max, lon, lat, ht);

  for (j = y_min; j <= y_max; j++) {
    yl = j + 0.5;

    for (i = x_min; i <= x_max; i++) {
      xl = i + 0.5;
      ia = (int)(cx[0] + cx[1]*xl + cx[2]*yl + cx[3]*xl*yl);
      ja = (int)(cy[0] + cy[1]*xl + cy[2]*yl + cy[3]*xl*yl);

      if (ia >= 0 && ia <= NS && ja >= 0 && ja <= NS) {
        e1 = rdr_stn[ja][ia];
        if (e1 > rdr_cmp[j][i]) rdr_cmp[j][i] = e1;
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  ��ǥ��ȯ ��� ���
 *=============================================================================*/
int conv_cof(cx, cy, x_min, x_max, y_min, y_max, lon, lat, ht)
  float  cx[4], cy[4];
  int    *x_min, *x_max, *y_min, *y_max;
  float  lon, lat, ht;
{
  struct lamc_parameter  map;
  struct azed_parameter  rdr;
  float  xl[4], yl[4], xa[4], ya[4];
  float  lon1, lat1;
  float  t1, t2;
  int  i, j;

  /* OUT Map parameter */
  map.Re  = 6371.00877;
  map.grid  = 1.0;
  map.slat1 = 30.0;
  map.slat2 = 60.0;
  map.olon  = 126.0;
  map.olat  = 38.0;
  map.xo  = 4.0 * 140.0 / map.grid;
  map.yo  = 4.0 * 210.0 / map.grid;
  map.first = 0;

  /* IN map parameter */
  rdr.Re  = 6371.00877 + ht * 0.001;
  rdr.grid  = 0.5;
  rdr.slon  = lon;
  rdr.slat  = lat;
  rdr.olon  = lon;
  rdr.olat  = lat;
  rdr.xo  = 1000.5;
  rdr.yo  = 1000.5;
  rdr.first = 0;

  /* IN map �������� �ױ����� ��ǥ */
  xa[0] = 0.0;
  ya[0] = 0.0;
  xa[1] = rdr.xo * 2.0;
  ya[1] = 0.0;
  xa[2] = rdr.xo * 2.0;
  ya[2] = rdr.yo * 2.0;
  xa[3] = 0.0;
  ya[3] = rdr.yo * 2.0;

  /* OUT map���� �ش�Ǵ� ��ǥ */
  for (i = 0; i < 4; i++) {
    azedproj(&lon1, &lat1, &xa[i], &ya[i], 1, &rdr);
    lamcproj_ellp(&lon1, &lat1, &xl[i], &yl[i], 0, &map);
  }

  /* OUT map������ ���� */
  *x_min = 99999;
  *x_max = -99999;
  *y_min = 99999;
  *y_max = -99999;

  for (i = 0; i < 4; i++) {
    if (*x_min > (int)xl[i]) *x_min = (int)xl[i];
    if (*x_max < (int)xl[i]) *x_max = (int)xl[i];
    if (*y_min > (int)yl[i]) *y_min = (int)yl[i];
    if (*y_max < (int)yl[i]) *y_max = (int)yl[i];
  }
  if (*x_min <  0) *x_min = 0;
  if (*x_max > NS) *x_max = NS;
  if (*y_min <  0) *y_min = 0;
  if (*y_max > NS) *y_max = NS;

  /* OUT map���� IN map���� ��ȯ��� ��� */
  matrix_cal(xa, xl, yl, cx);
  matrix_cal(ya, xl, yl, cy);

  return 0;
}

/*=============================================================================*
 *  ��� ���
 *=============================================================================*/
int matrix_cal(a, xl, yl, c)
  float a[4], xl[4], yl[4], c[4];
{
  float  mm[4][4], d;
  int  indx[4];
  int  i, j;

  for (j = 0; j < 4; j++) {
    mm[j][0] = 1.0;
    mm[j][1] = xl[j];
    mm[j][2] = yl[j];
    mm[j][3] = xl[j] * yl[j];
    c[j] = a[j];
  }

  ludcmp(mm,4,indx,&d);
  lubksb(mm,4,indx,c);

  return 0;
}

/*=============================================================================*
 *  < LU decomposition >            from  Numerical Recips
 *=============================================================================*/
int   lubksb(a,n,indx,b)
float a[4][4],b[4];
int   n,*indx;
{
  int  i,ii=-1,ip,j;
  float  sum;

  for (i=0;i<n;i++) {
    ip=indx[i];
    sum=b[ip];
    b[ip]=b[i];
    if (ii >= 0)
      for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
    else if (sum) ii=i;
    b[i]=sum;
  }
  for (i=n-1;i>=0;i--) {
    sum=b[i];
    for (j=i+1;j<n;j++) sum -= a[i][j]*b[j];
    b[i]=sum/a[i][i];
  }
  return 0;
}

/*=============================================================================*
 *  < LU decomposition >            from  Numerical Recips
 *=============================================================================*/
#define TINY 1.0e-20;

int   ludcmp(a,n,indx,d)
float a[4][4];
int   n,*indx;
float *d;
{
  int  i,imax,j,k;
  float  big,dum,sum,temp;
  float  vv[8];

  *d=1.0;
  for (i=0;i<n;i++) {
    big=0.0;
    for (j=0;j<n;j++) {
      if ((temp=fabs(a[i][j])) > big) big=temp;
    }
    if (big == 0.0) printf("Singular matrix in routine LUDCMP\n");
    vv[i]=1.0/big;
  }
  for (j=0;j<n;j++) {
    for (i=0;i<j;i++) {
      sum=a[i][j];
      for (k=0;k<i;k++) sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
    }
    big=0.0;
    for (i=j;i<n;i++) {
      sum=a[i][j];
      for (k=0;k<j;k++)
        sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
      if ( (dum=vv[i]*fabs(sum)) >= big) {
        big=dum;
        imax=i;
      }
    }
    if (j != imax) {
      for (k=0;k<n;k++) {
        dum=a[imax][k];
        a[imax][k]=a[j][k];
        a[j][k]=dum;
      }
      *d = -(*d);
      vv[imax]=vv[j];
    }
    indx[j]=imax;
    if (a[j][j] == 0.0) a[j][j]=TINY;
    if (j != n-1) {
      dum=1.0/(a[j][j]);
      for (i=j+1;i<n;i++) a[i][j] *= dum;
    }
  }
  return 0;
}

/*******************************************************************************
 *
 *  �ռ��� ���̴��ڷ� Smoothing
 *
 *******************************************************************************/
int rdr_cmp_sm()
{
  short  *p, d1, d2, p1, p2, p3;
  int  i, j;

  for (j = 0; j <= NJ; j++) {
    d1 = rdr_cmp[j][0];
    p = &(rdr_cmp[j][1]);

    for (i = 1; i < NI; i++, p++) {
      if (*(p-1) > BLANK3 && *p > BLANK3 && *(p+1) > BLANK3)
        d2 = (short)((float)(*(p-1) + *p*2 + *(p+1))*0.25);
      else if (*(p-1) > BLANK3 && *p <= BLANK3 && *(p+1) > BLANK3)
        d2 = (short)((float)(*(p-1) + *(p+1)) * 0.5);
      else
        d2 = *p;

      *(p-1) = d1;
      d1 = d2;
    }
  }

  for (i = 0; i <= NI; i++) {
    d1 = rdr_cmp[0][i];
    p1 = d1;
    p2 = rdr_cmp[1][i];

    for (j = 1; j < NJ; j++) {
      p3 = rdr_cmp[j+1][i];
      if (p1 > BLANK3 && p2 > BLANK3 && p3 > BLANK3)
        d2 = (short)((float)(p1 + 2*p2 + p3)*0.25);
      else if (p1 > BLANK3 && p2 <= BLANK3 && p3 > BLANK3)
        d2 = (short)((float)(p1 + p2) * 0.5);
      else
        d2 = p2;

      rdr_cmp[j-1][i] = d1;
      d1 = d2;
      p1 = p2;
      p2 = p3;
    }
  }
  return 0;
}

//======== add (RadarCener,KWG,2012.02.13) =============================
int pseudo_cappi(Volume* volume,float height,int xdim, int ydim, int range, float grid_size)
{
  int x, y; // The number of CAPPI grid point
  int s,r,b;
  float center_x,center_y;
  center_x = (xdim-1)/2.;
  center_y = (ydim-1)/2.;

  float point_x,point_y;//,point_z;

  float el_limit= 2.0;
  float az_limit= 1.0;

  float elevation;
  float azimuth;
  float echo;
  float slant_range;
  double sum_Z;

  int bin_count;
  int range_out;

  CLOEST_SWEEPS cloest_sweeps;

  //�ʱ�ȭ
  for (s = 0 ; s < 2 ; s++ ) {
    cloest_sweeps.valid[s] = 0;
    cloest_sweeps.s[s] = NULL;
    for (r = 0 ; r < 2 ; r++ ) {
      cloest_sweeps.rays[s].valid[r] = 0;
      cloest_sweeps.rays[s].r[r] = NULL;
      for (b = 0 ; b < 2 ; b++ ) {
        cloest_sweeps.rays[s].values[r].valid[b] = 0;
        cloest_sweeps.rays[s].values[r].dBZ[b] = -127;
      }
    }
  }

  for (y = 0 ; y < ydim ; y++ ) {
    for (x = 0 ; x < xdim ; x++ ) {
      bin_count = 0;
      sum_Z = 0;

      point_x = x - center_x;
      point_y = y - center_y;
      slant_range = get_slant_range(point_x,point_y,height,grid_size);
      elevation = get_elevation(point_x,point_y,height,grid_size);
      azimuth = get_azimuth(point_x,point_y);

      //����� SWEEP 2�� ã��
      cloest_sweeps = get_cloest_2_sweeps(volume, elevation, el_limit);
      for (s = 0 ; s < 2 ; s++ ) {
        cloest_sweeps.rays[s] = get_cloest_2_rays(cloest_sweeps.s[s],azimuth,az_limit);
        for (r = 0 ; r < 2 ; r++ ) {
          cloest_sweeps.rays[s].values[r] = get_cloest_2_bins(cloest_sweeps.rays[s].r[r],slant_range);
        }
      }
      echo = cal_mohr_cappi_value_f2(volume,cloest_sweeps,azimuth,elevation,slant_range,0,1);

      //BLANK1=No Area, BLANK2=No Data, BLANK3=Minimum Data
      range_out = (int)(sqrt((center_x-x)*(center_x-x)+(center_y-y)*(center_y-y)));
      range_out =range_out*grid_size/1000;

      if (echo > 200.0 || echo < -100) 
        echo = BLANK2;
      else
        echo = (short)(echo*100);

      if (range_out > range) echo = BLANK1;

      rdr_stn[ydim-y-1][x] = echo;
    }
  }
  return 0;
}

//=======================================================================
float get_slant_range(float x, float y, float height,float grid_size)
{
  float range_x, range_y, range_z;

  range_x = x * grid_size;
  range_y = y * grid_size;
  range_z = height;  // * grid_size;

  return sqrt(pow(range_x,2)+pow(range_y,2)+pow(range_z,2));
}

//=======================================================================
float get_elevation(float x,float y,float h,float grid_size)
{
  double Ae, r;
  float result;

  r = get_slant_range(x,y,h,grid_size);
  Ae = (MAP_RE * 1000.)*4./3.;

  //Doviak and Zrnic, 1993
  result = RADDEG * asin((h*h - r*r + 2*Ae*h) / (2*r*Ae));

  return result;
}

//=======================================================================
float get_azimuth(float x,float y)
{
  float azimuth;

  if (x < 0.0)
    azimuth = (atan(y/x) * RADDEG) + 270.0;
  else if (x > 0.0)
    azimuth = (atan(y/x) * RADDEG) + 90.0;
  else if ((x == 0.0) && (y <= 0.0))
    azimuth = 0.0;
  else
    azimuth = 180.0;
  return azimuth;
}

//=======================================================================
static CLOEST_SWEEPS get_cloest_2_sweeps(Volume* volume,float elevation,float limit)
{
  CLOEST_SWEEPS cloest_sweeps;
  int sweep_index1,sweep_index2;

  cloest_sweeps.s[0] = NULL;
  cloest_sweeps.valid[0] = 0;
  cloest_sweeps.s[1] = NULL;
  cloest_sweeps.valid[1] = 0;

  if (volume == NULL)
    return cloest_sweeps;
  
  if (get_closest_sweep_2_index(volume,elevation,&sweep_index1,&sweep_index2) < 0) {
    cloest_sweeps.valid[0] = 0;
    cloest_sweeps.valid[1] = 0;
    return cloest_sweeps;
  }

  if ((sweep_index1 >= 0) && diff_degree(elevation,volume->sweep[sweep_index1]->h.elev) <= limit) {
    cloest_sweeps.s[0] = volume->sweep[sweep_index1];
    cloest_sweeps.valid[0] = 1;
    cloest_sweeps.phi[0] = volume->sweep[sweep_index1]->h.elev;
  }
  else {
    cloest_sweeps.s[0] = NULL;
    cloest_sweeps.valid[0] = 0;
  }

  if ((sweep_index2 >= 0) && diff_degree(elevation,volume->sweep[sweep_index2]->h.elev) <= limit) {
    cloest_sweeps.s[1] = volume->sweep[sweep_index2];
    cloest_sweeps.valid[1] = 1;
    cloest_sweeps.phi[1] = volume->sweep[sweep_index2]->h.elev;
  }
  else {
    cloest_sweeps.s[1] = NULL;
    cloest_sweeps.valid[1] = 0;
  }
  return cloest_sweeps;
}

//=======================================================================
static CLOEST_RAYS get_cloest_2_rays(Sweep* s,float azimuth,float limit)
{
  CLOEST_RAYS cloest_rays;
  Ray* ray;
  Ray* cw_ray;
  Ray* ccw_ray;
  Ray* ray_temp1 = NULL;
  Ray* ray_temp2 = NULL;

  //�ʱ�ȭ
  cloest_rays.valid[0] = 0;
  cloest_rays.valid[1] = 0;
  cloest_rays.r[0] = NULL;
  cloest_rays.r[1] = NULL;

  if (s == NULL)
    return cloest_rays;
  //���� ����� ray������.
  if ((ray = RSL_get_closest_ray_from_sweep(s,azimuth,limit)) == NULL)
    return cloest_rays;

  ray_temp1 = ray;

  cw_ray = RSL_get_next_cwise_ray(s,ray); 
  ccw_ray = RSL_get_next_ccwise_ray(s,ray);
  //CW_RAY�� ������ �ƴϰ� limit�� ���� ������ &&  CW_RAY�� ������ �ƴϰ� limit�� ���� ������
  if ((cw_ray  != NULL) && (diff_degree(cw_ray->h.azimuth,azimuth) <= limit) &&
      (ccw_ray != NULL) && (diff_degree(ccw_ray->h.azimuth,azimuth) <= limit)) {
    if (diff_degree(cw_ray->h.azimuth,azimuth) > diff_degree(ccw_ray->h.azimuth,azimuth))
      ray_temp2 = ccw_ray;
    else
      ray_temp2 = cw_ray;
  }
  //CW_RAY�� ������ �ƴϰ� limit�� ���� ������(CCW_RAY�� ����)
  else if ((cw_ray != NULL) && (diff_degree(cw_ray->h.azimuth,azimuth) <= limit))
    ray_temp2 = cw_ray;
  //CCW_RAY�� ������ �ƴϰ� limit�� ���� ������(CW_RAY�� ����)
  else if ((ccw_ray != NULL) && (diff_degree(ccw_ray->h.azimuth,azimuth) <= limit))
    ray_temp2 = ccw_ray;

  if (ray_temp1 != NULL) {
    if (minus_degree(ray_temp1->h.azimuth,azimuth) < 0) {
      cloest_rays.r[0] = ray_temp1;
      cloest_rays.valid[0] = 1;
      cloest_rays.theta[0] = ray_temp1->h.azimuth;
    }
    else {
      cloest_rays.r[1] = ray_temp1;
      cloest_rays.valid[1] = 1;
      cloest_rays.theta[1] = ray_temp1->h.azimuth;
    }
  }

  if (ray_temp2 != NULL) {
    if (minus_degree(ray_temp2->h.azimuth,azimuth) < 0) {
      cloest_rays.r[0] = ray_temp2;
      cloest_rays.valid[0] = 1;
      cloest_rays.theta[0] = ray_temp2->h.azimuth;
    }
    else {
      cloest_rays.r[1] = ray_temp2;
      cloest_rays.valid[1] = 1;
      cloest_rays.theta[1] = ray_temp2->h.azimuth;
    }
  }
  return cloest_rays;
}

//=======================================================================
static CLOEST_VALUES get_cloest_2_bins(Ray* r,float range)
{
  CLOEST_VALUES cloest_values;
  float bin_num_f;
  int bin_num1;
  int bin_num2;
  float gate_size;
  float range_bin1;

  //�ʱ�ȭ
  cloest_values.dBZ[0] = BAD_VALUE_F;
  cloest_values.dBZ[1] = BAD_VALUE_F;
  cloest_values.valid[0] = 0;
  cloest_values.valid[1] = 0;

  if (r == NULL)
    return cloest_values;

  range_bin1 = r->h.range_bin1;
  gate_size = r->h.gate_size;

  bin_num_f = (range-range_bin1)/(gate_size*1.0);
  bin_num1 = (int)(bin_num_f);
  bin_num2 = (int)(bin_num_f + 1);
  if ((bin_num1 <= r->h.nbins) && (bin_num1 >= 0) && (r->h.f(r->range[bin_num1]) != BADVAL)) {
    cloest_values.dBZ[0] = r->h.f(r->range[bin_num1]);
    cloest_values.bin_num[0] = bin_num1;
    cloest_values.valid[0] = 1;
    cloest_values.R[0] = bin_num1;
  }

  if ((bin_num2 <= r->h.nbins) && (bin_num2 >= 0) && (r->h.f(r->range[bin_num2]) != BADVAL)) {
    cloest_values.dBZ[1] = r->h.f(r->range[bin_num2]);
    cloest_values.bin_num[1] = bin_num2;
    cloest_values.valid[1] = 1;
    cloest_values.R[1] = bin_num2;
  }
  return cloest_values;
}

//=======================================================================
float cal_mohr_cappi_value_f2(Volume* volume,CLOEST_SWEEPS cs,float azimuth,float elevation,float slant_range, int pseudo_cappi, int is_dBZ)
{
  int s;
  float result;

  float dR,dT;
  float R_Ri,R_Rip1;//R-R_i,R-R_(i+1)
  float T_Tj,T_Tjp1;//T-T_i,T-T_(j+1)
  float Ze_i_j,Ze_ip1_j,Ze_i_jp1,Ze_ip1_jp1;
  float Ze_R_T[2];
  float Ze_R_T_temp1,Ze_R_T_temp2;
  float dP;
  float P_Pk,P_Pkp1;
  int   processed;

  result = BAD_VALUE_F;

  dR = 1.;
  dT = 1.;

  processed = 0;

  //���� ������ �׳� return
  if (!cs.rays[0].values[0].valid[0] && !cs.rays[0].values[0].valid[1] && !cs.rays[0].values[1].valid[0] && !cs.rays[0].values[1].valid[1] &&
      !cs.rays[1].values[0].valid[0] && !cs.rays[1].values[0].valid[1] && !cs.rays[1].values[1].valid[0] && !cs.rays[1].values[1].valid[1])
    return BAD_VALUE_F;

  switch (pseudo_cappi) {
    case 0 : break;
/*    //ù��° sweep���� ���� ���� ���� beamwidth��ŭ�� �׸��� �������� �ȱ׸�
    if (cs.valid[1] && !cs.valid[0] && cs.s[1]->h.sweep_num == 1) {
      if (elevation < (cs.s[1]->h.elev - cs.s[1]->h.beam_width/2.))
        return BAD_VALUE_F;
    }
*/
    //REAL_CAPPI ù��° sweep���� ���� ���� �ȱ׸�
    case 1 : 
      if (cs.valid[1] && !cs.valid[0] && cs.s[1]->h.sweep_num == 1) {
        if (elevation < (cs.s[1]->h.elev))
          return BAD_VALUE_F;
      }
      break;
    default : return -9999;
  }

  /****************************************************
    Ze(R,Theta)
  ****************************************************/
  for (s = 0 ; s < 2 ; s++ )
  {
    //�⺻�� ����
    R_Ri = 0.5;
    R_Rip1 = -0.5;
    T_Tj = 1.;
    T_Tjp1 = -1.;
    Ze_i_j = 0.;
    Ze_ip1_j = 0.;
    Ze_i_jp1 = 0.;
    Ze_ip1_jp1 = 0.;
    Ze_R_T[s] = 0.;

    if (!cs.valid[s])  continue;

//    if (!cs.rays[s].values[0].valid[0] && !cs.rays[s].values[0].valid[1] && !cs.rays[s].values[1].valid[0] && !cs.rays[s].values[1].valid[1])
//      continue;

    if (cs.s[s]->ray[0] != NULL) {
      //R-Ri�� R-Ri+1�� �⺻���� gate_size/2�� ������.
      R_Ri = (cs.s[s]->ray[0]->h.gate_size/1000.)/2.;
      R_Rip1 = -1. * R_Ri;
      //dR�� �⺻���� ù��° ray�� gate_size�� ��.
      dR = cs.s[s]->ray[0]->h.gate_size/1000.;
    }

    if (cs.s[s]->ray[0] != NULL && cs.s[s]->ray[1] != NULL) {
      //Theta - Theta_j�� Theta - Theta_j+1�� �⺻���� ù��° ray�� �ι�° ray�� azimuth��/2�� ������.
      T_Tj = diff_degree(cs.s[s]->ray[0]->h.azimuth,cs.s[s]->ray[1]->h.azimuth)/2.;
      T_Tjp1 = -1. * T_Tj;
      //dT�� �⺻���� ù��° ray�� �ι�° ray�� azimuth�� ������.
      dT = diff_degree(cs.s[s]->ray[0]->h.azimuth,cs.s[s]->ray[1]->h.azimuth);
    }
    //�⺻�� ���� ��

    //Theta - Theata_j �� Theth - Theata_j+1�� ����.
    if (cs.rays[s].valid[0]) T_Tj = minus_degree(azimuth,cs.rays[s].r[0]->h.azimuth);
    if (cs.rays[s].valid[1]) T_Tjp1 = minus_degree(azimuth,cs.rays[s].r[1]->h.azimuth);

    //�� Ze���� ����.
    if (cs.rays[s].valid[0]) {
      if (cs.rays[s].values[0].valid[0]) {
        if (is_dBZ == 1)
          Ze_i_j = pow(10.,(cs.rays[s].values[0].dBZ[0])/10.);
        else
          Ze_i_j = cs.rays[s].values[0].dBZ[0];
      }
      if (cs.rays[s].values[0].valid[1]) {
        if (is_dBZ == 1)
          Ze_ip1_j = pow(10.,(cs.rays[s].values[0].dBZ[1])/10.);
        else
          Ze_ip1_j = cs.rays[s].values[0].dBZ[1];
      }
    }

    if (cs.rays[s].valid[1]) {
      if (cs.rays[s].values[1].valid[0]) {
        if (is_dBZ == 1)
          Ze_i_jp1 = pow(10.,(cs.rays[s].values[1].dBZ[0])/10.);
        else
          Ze_i_jp1 = cs.rays[s].values[1].dBZ[0];
      }
      if (cs.rays[s].values[1].valid[1]) {
        if (is_dBZ == 1)
          Ze_ip1_jp1 = pow(10.,(cs.rays[s].values[1].dBZ[1])/10.);
        else
          Ze_ip1_jp1 = cs.rays[s].values[1].dBZ[1];
      }
    }

    //R-Ri����. dR����.
    if (cs.rays[s].values[0].valid[0]) {
      R_Ri = (slant_range - (cs.rays[s].values[0].bin_num[0] * cs.rays[s].r[0]->h.gate_size + cs.rays[s].r[0]->h.range_bin1))/1000.;
      dR = cs.rays[s].r[0]->h.gate_size/1000.;
    }
    else if (cs.rays[s].values[1].valid[0]) {
      R_Ri = (slant_range - (cs.rays[s].values[1].bin_num[0] * cs.rays[s].r[1]->h.gate_size + cs.rays[s].r[1]->h.range_bin1))/1000.;
      dR = cs.rays[s].r[1]->h.gate_size/1000.;
    }

    //R-Ri+1����. dR����.
    if (cs.rays[s].values[0].valid[1]) {
      R_Rip1 = (slant_range - (cs.rays[s].values[0].bin_num[1] * cs.rays[s].r[0]->h.gate_size + cs.rays[s].r[0]->h.range_bin1))/1000.;
      dR = cs.rays[s].r[0]->h.gate_size/1000.;
    }
    else if (cs.rays[s].values[1].valid[1]) {
      R_Rip1 = (slant_range - (cs.rays[s].values[1].bin_num[1] * cs.rays[s].r[1]->h.gate_size + cs.rays[s].r[1]->h.range_bin1))/1000.;
      dR = cs.rays[s].r[1]->h.gate_size/1000.;
    }

    //dTheata
    if (cs.rays[s].valid[0] && cs.rays[s].valid[1]) {
      dT = diff_degree(cs.rays[s].theta[1],cs.rays[s].theta[0]);
      Ze_R_T_temp1 = R_Ri * ((T_Tj * Ze_ip1_jp1) - (T_Tjp1 * Ze_ip1_j));
      Ze_R_T_temp2 = R_Rip1 * ((T_Tj * Ze_i_jp1) - (T_Tjp1 * Ze_i_j));

      Ze_R_T[s] = (1/(dR*dT)) * (Ze_R_T_temp1 - Ze_R_T_temp2);
    }
    //ray�� �ϳ��� ������ ������ ������ ���� ����
    else if (cs.rays[s].valid[0])
      Ze_R_T[s] = (1/(dR)) * (R_Ri * Ze_ip1_j - R_Rip1 * Ze_i_j);
    else if (cs.rays[s].valid[1])
      Ze_R_T[s] = (1/(dR)) * (R_Ri * Ze_i_jp1 - R_Rip1 * Ze_ip1_jp1);
    else
      return BAD_VALUE_F;

    processed++;
  }

  if (processed <= 0)
    return BAD_VALUE_F;

  /****************************************************
    Ze(R,Theta,Phi)
  ****************************************************/
  //�⺻�� ����
  dP = 1.;
  P_Pk = 0.5;
  P_Pkp1 = 0.5;

  //dP����.
  //sweep�� ���������
  if (cs.valid[0] && cs.valid[1]) {
    //elevation�� �Ʒ� sweep�� �������� ������
    if (elevation == cs.phi[0])
      result = Ze_R_T[0];
    //elevation�� �� sweep�� �������� ������
    else if (elevation == cs.phi[1])
      result = Ze_R_T[1];
    else {
      dP = diff_degree(cs.phi[1],cs.phi[0]);
      //P-Pk�� P-Pk+1����.
      if (cs.valid[0]) P_Pk = minus_degree(elevation,cs.phi[0]);
      if (cs.valid[1]) P_Pkp1 = minus_degree(elevation,cs.phi[1]);
      result = (1/dP) * (P_Pk * Ze_R_T[1] - P_Pkp1 * Ze_R_T[0]);
      //printf("(%9.1f)*(%9.1f*%9.1f - %9.1f*%9.1f = %9.1f\n",(1/dP),P_Pk,Ze_R_T[1],P_Pkp1,Ze_R_T[0],result);
    }
  }
  //�Ʒ� sweep�� ������
  else if (cs.valid[0] && !cs.valid[1])
    result = Ze_R_T[0];
  //�� sweep�� ������
  else if (!cs.valid[0] && cs.valid[1])
    result = Ze_R_T[1];
  else
    return BAD_VALUE_F;

  if (is_dBZ == 1) {
    if (result <= 1) 
      return 0;
    else 
      return (10. * log10(result));
  }
  else
    return result;
}

//=======================================================================
int get_closest_sweep_2_index(Volume *v,float sweep_angle,int* sweep_index1,int* sweep_index2)
{
  Sweep *s;
  int i,ci1,ci2;
  float delta_angle = 91;
  float check_angle;
  
  if(v == NULL) return -1;

  ci1 = -1;
  ci2 = -1;

  //first cloest sweep index
  delta_angle = 91;
  for (i=0; i < v->h.nsweeps; i++) {
    s = v->sweep[i];
    if (s == NULL) continue;
    check_angle = diff_degree(s->h.elev,sweep_angle);

    if (s->h.elev > sweep_angle) break;

    if(check_angle <= delta_angle) {
      delta_angle = check_angle;
      ci1 = i;
    }
  }

  //second cloest sweep index
  delta_angle = 91;
  for (i=v->h.nsweeps - 1; i >= 0 ; i--) {
    s = v->sweep[i];
    if (s == NULL) continue;
    if (ci1 == i) continue;  //skip first cloest sweep
    check_angle = diff_degree(s->h.elev,sweep_angle);

    if (s->h.elev < sweep_angle) break;
    if(check_angle <= delta_angle) {
      delta_angle = check_angle;
      ci2 = i;
    }
  }
  if ((ci1 - ci2) < 0) {
    *sweep_index1 = ci1;
    *sweep_index2 = ci2;
  }
  else {
    *sweep_index1 = ci2;
    *sweep_index2 = ci1;
  }
  return 1;
}

//=======================================================================
float diff_degree(float alpha, float beta)
{
  return fabs(minus_degree(alpha,beta));
}

//=======================================================================
float minus_degree(float alpha, float beta)
{
  float min;
  min = alpha - beta;

  if (alpha == beta) return 0.;

  if (min > 180.)
    return min - 360.;
  else if (min < -180.)
    return 360. + min;
  return min;
}
