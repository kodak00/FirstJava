/*******************************************************************************
**
**  ���̴� �ռ��ڷ��� ������� ǥ��
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.3.28)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "cgiutil.h"
#include "nrutil.h"
#include "rdr_cmp_header.h"

#define  DEGRAD   3.1415927/180.0
#define  RADDEG   180.0/3.1415927

#define  RDR_CMP_DIR   "/DATA/RDR/CMP"        // ���̴��ռ����� ���������
#define  RDR_PCP_DIR   "/DATA/RDR/PCP"        // ���������� ���������

#define  BLANK1  -30000     // No Area
#define  BLANK2  -25000     // No Data
#define  BLANK3  -20000     // Minimum Data

// ����� �Է� ����
struct INPUT_VAR {
  int   seq;          // ���ؽð� SEQ(��)
  char  cmp[8];       // HSR, HCI, PPI, CPP, CMX, MPD, PCPH, PCPP
  char  obs[8];       // ECHO, EBH, STN
  char  qcd[8];       // NQC, QCD, EXT
  char  fname[120];   // ���ϸ�
} var;

struct RDR_PCP_HEAD  rdr_pcp_head;      // PCP�ռ� Header
struct RDR_CMP_HEAD  rdr_cmp_head;      // �ռ��ڷ� HEAD
struct RDR_CMP_STN_LIST  rdr_cmp_stn_list[48];  // �ռ��� ���̴� ���

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main()
{
  float km_px;
  int   num_sm, i;

  // 1. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(20);

  printf("HTTP/1.0 200 OK\n");
  printf("Content-type: text/plain\n\n");

  // 2. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    printf("# input variable error<p>\n");
    return -1;
  }

  // 3. ���̴��ڷḦ ����
  rdr_cmp_get();

  // 5. ������� ǥ��
  rdr_cmp_header();

  alarm(0);
  return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
  char *qs;
  char tmp[256], item[32], value[32], tm[30];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, i;

  // 1. ���� �ʱⰪ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "0");        // ����ð�

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"cmp")) strcpy(var.cmp, value);
    else if ( !strcmp(item,"obs")) strcpy(var.obs, value);
    else if ( !strcmp(item,"qcd")) strcpy(var.qcd, value);
    else if ( !strcmp(item,"tm"))  strcpy(tm, value);
  }

  // 3. ����ð� �� ���� �����ð� ����
  get_time(&iYY, &iMM, &iDD, &iHH, &iMI, &iSS);
  iseq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');

  // 4. ��û�ð� ����
  if (strlen(tm) < 10)
    var.seq = iseq;
  else {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
    var.seq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  }
  var.seq = 5*(var.seq/5);

  return 0;
}

/*******************************************************************************
 *
 *  ���̴� �ռ��ڷ� ���� ����
 *
 *******************************************************************************/
int rdr_cmp_get()
{
  FILE   *fp;
  char   head[720];
  float  z1, z2, rn1, rn2;
  int    dbz_max, data1, nskip;
  int    GX, GY, SX, SY;
  int    i, j, k, n, ii, jj, i1, i2, j1, j2;

  // 2. ���� ���� ���� Ȯ��
  if (rdr_cmp_file(var.seq, var.cmp, var.qcd, var.fname) < 0) return -1;

  // 3. ���̴� �ռ��ڷ� �б�
  fp = gzopen(var.fname, "rb");
  if (strstr(var.cmp,"PCP") != NULL) {
    n = gzread(fp, &rdr_pcp_head, sizeof(rdr_pcp_head));
  }
  else {
    n = gzread(fp, &rdr_cmp_head, sizeof(rdr_cmp_head));
    n = gzread(fp, rdr_cmp_stn_list, sizeof(rdr_cmp_stn_list));
  }
  gzclose(fp);
  return 0;
}

/*******************************************************************************
 *
 *  ������� ǥ��
 *
 *******************************************************************************/
int rdr_cmp_header()
{
  int  k;

  printf("file = %s\n", var.fname);
  printf("\n");

  if (strstr(var.cmp,"PCP") != NULL) {
    printf("version = %d\n", rdr_pcp_head.version);
    printf("ptype = %d\n", rdr_pcp_head.ptype);
    printf("tm = %04d.%02d.%02d.%02d:%02d:%02d\n",
      rdr_pcp_head.tm.YY, rdr_pcp_head.tm.MM, rdr_pcp_head.tm.DD,
      rdr_pcp_head.tm.HH, rdr_pcp_head.tm.MI, rdr_pcp_head.tm.SS);
    printf("tm_in = %04d.%02d.%02d.%02d:%02d:%02d (�����ð�)\n",
      rdr_pcp_head.tm_in.YY, rdr_pcp_head.tm_in.MM, rdr_pcp_head.tm_in.DD,
      rdr_pcp_head.tm_in.HH, rdr_pcp_head.tm_in.MI, rdr_pcp_head.tm_in.SS);
    printf("\n");

    printf("map_code = %d\n", rdr_pcp_head.map_code);
    printf("map_etc = %d\n", rdr_pcp_head.map_etc);
    printf("\n");

    printf("nx = %d (���� ���ڼ�)\n", rdr_pcp_head.nx);
    printf("ny = %d (���� ���ڼ�)\n", rdr_pcp_head.ny);
    printf("nz = %d (���� ���ڼ�)\n", rdr_pcp_head.nz);
    printf("dxy = %d (������ڰ���,m)\n", rdr_pcp_head.dxy);
    printf("dz = %d (�������ڰ���,m)\n", rdr_pcp_head.dz);
    printf("z_min = %d (�������� ��������)\n", rdr_pcp_head.z_min);
    printf("\n");

    printf("num_data = %d (����� �ڷ��)\n", rdr_pcp_head.num_data);
    for (k = 0; k < rdr_pcp_head.num_data; k++) {
      printf("data_code(%d) = %d\n", k, rdr_pcp_head.data_code[k]);
    }
    printf("\n");

    printf("acc_min = %d (�����Ⱓ(��))\n", rdr_pcp_head.acc_min);
    printf("itv_min = %d (�ڷᰣ ����(��))\n", rdr_pcp_head.itv_min);
    printf("cmp_cnt = %d (�ռ��� ���� �ڷ��)\n", rdr_pcp_head.cmp_cnt);
    printf("\n");
  }
  else {
    printf("version = %d\n", rdr_cmp_head.version);
    printf("ptype = %d\n", rdr_cmp_head.ptype);
    printf("tm = %04d.%02d.%02d.%02d:%02d:%02d\n",
      rdr_cmp_head.tm.YY, rdr_cmp_head.tm.MM, rdr_cmp_head.tm.DD,
      rdr_cmp_head.tm.HH, rdr_cmp_head.tm.MI, rdr_cmp_head.tm.SS);
    printf("tm_in = %04d.%02d.%02d.%02d:%02d:%02d (�����ð�)\n",
      rdr_cmp_head.tm_in.YY, rdr_cmp_head.tm_in.MM, rdr_cmp_head.tm_in.DD,
      rdr_cmp_head.tm_in.HH, rdr_cmp_head.tm_in.MI, rdr_cmp_head.tm_in.SS);
    printf("\n");

    printf("num_stn = %d (���� ����Ʈ��)\n", rdr_cmp_head.num_stn);
    printf("map_code = %d\n", rdr_cmp_head.map_code);
    printf("map_etc = %d\n", rdr_cmp_head.map_etc);
    printf("\n");

    printf("nx = %d (���� ���ڼ�)\n", rdr_cmp_head.nx);
    printf("ny = %d (���� ���ڼ�)\n", rdr_cmp_head.ny);
    printf("nz = %d (���� ���ڼ�)\n", rdr_cmp_head.nz);
    printf("dxy = %d (������ڰ���,m)\n", rdr_cmp_head.dxy);
    printf("dz = %d (�������ڰ���,m)\n", rdr_cmp_head.dz);
    printf("z_min = %d (�������� ��������)\n", rdr_cmp_head.z_min);
    printf("\n");

    printf("num_data = %d (����� �ڷ��)\n", rdr_cmp_head.num_data);
    for (k = 0; k < rdr_cmp_head.num_data; k++) {
      printf("data_code(%d) = %d\n", k, rdr_cmp_head.data_code[k]);
    }
    printf("\n");

    printf("�ռ��� ���� ������\n");
    for (k = 0; k < rdr_cmp_head.num_stn; k++) {
      printf("(%2d) stn_cd = %4s, ", k, rdr_cmp_stn_list[k].stn_cd);
      printf("tm = %04d.%02d.%02d.%02d:%02d:%02d, ",
        rdr_cmp_stn_list[k].tm.YY, rdr_cmp_stn_list[k].tm.MM, rdr_cmp_stn_list[k].tm.DD,
        rdr_cmp_stn_list[k].tm.HH, rdr_cmp_stn_list[k].tm.MI, rdr_cmp_stn_list[k].tm.SS);
      printf("tm_in = %04d.%02d.%02d.%02d:%02d:%02d\n",
        rdr_cmp_stn_list[k].tm_in.YY, rdr_cmp_stn_list[k].tm_in.MM, rdr_cmp_stn_list[k].tm_in.DD,
        rdr_cmp_stn_list[k].tm_in.HH, rdr_cmp_stn_list[k].tm_in.MI, rdr_cmp_stn_list[k].tm_in.SS);
    }
  }
  return 0;
}

/*=============================================================================*
 *  ���̴� �ռ��ڷ� ���� ���� Ȯ��
 *=============================================================================*/
int rdr_cmp_file(
  int  seq,
  char *cmp,
  char *qcd,
  char *dname
)
{
  struct stat st;
  char   sname[120];
  int    YY, MM, DD, HH, MI;
  int    data, code, rtn;

  // 1. �ڷ� �ð�
  seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  // 2. ���ϸ�
  if (strstr(cmp,"HSR") != NULL) {
    if (strcmp(qcd,"NQC") == 0)
      sprintf(sname, "RDR_CMP_HSR_KMA_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    else
      sprintf(sname, "RDR_CMP_HSR_EXT_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }
  else if (strstr(cmp,"LNG") != NULL) {
    sprintf(sname, "RDR_CMP_%s_%s_%04d%02d%02d%02d%02d.bin.gz", cmp, qcd, YY, MM, DD, HH, MI);
    sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }
  else if (strstr(cmp,"HCI") != NULL) {
    if (strcmp(qcd,"EXT") == 0)
      sprintf(sname, "RDR_CMP_HCI_EXT_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    else
      sprintf(sname, "RDR_CMP_HCI_KMA_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }
  else if (strstr(cmp,"HAIL") != NULL) {
    if (strcmp(qcd,"EXT") == 0)
      sprintf(sname, "RDR_CMP_HAIL_EXT_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    else
      sprintf(sname, "RDR_CMP_HAIL_KMA_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }
  else if (strstr(cmp,"PCP") != NULL) {
    if (strcmp(cmp,"PCPH") == 0) {        // HSR ����
      if (strcmp(qcd,"EXT") == 0)
        sprintf(sname, "RDR_PCP_HSR_EXT_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
      else if (strcmp(qcd,"KMA") == 0 || strcmp(qcd,"NQC") == 0)
        sprintf(sname, "RDR_PCP_HSR_KMA_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
      else if (strcmp(qcd,"MSK") == 0 || strcmp(qcd,"QCD") == 0)
        sprintf(sname, "RDR_PCP_HSR_MSK_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    }
    else if (strcmp(cmp,"PCPP") == 0) {   // PPI ����
      if (strcmp(qcd,"EXT") == 0)
        sprintf(sname, "RDR_PCP_PPI_EXT_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
      else if (strcmp(qcd,"KMA") == 0 || strcmp(qcd,"NQC") == 0)
        sprintf(sname, "RDR_PCP_PPI_NQC_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
      else if (strcmp(qcd,"MSK") == 0 || strcmp(qcd,"QCD") == 0)
        sprintf(sname, "RDR_PCP_PPI_QCD_M060_%04d%02d%02d%02d%02d.bin.gz", YY, MM, DD, HH, MI);
    }
    sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_PCP_DIR, YY, MM, DD, sname);
  }
  else {
    sprintf(sname, "RDR_CMP_%s_%s_%04d%02d%02d%02d%02d.bin.gz", cmp, qcd, YY, MM, DD, HH, MI);
    sprintf(dname, "%s/%04d%02d/%02d/%s", RDR_CMP_DIR, YY, MM, DD, sname);
  }

  // 3. ���� ���� ���� Ȯ��
  code = stat(dname, &st);
  if (code < 0 || st.st_size <= 100)
    rtn = -1;
  else
    rtn = 0;
  return rtn;
}
