/*******************************************************************************
**
**  ���̴� 3���� �ռ��ڷ� ǥ��
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.8.30)
**
********************************************************************************/
#include "rdr_r3d_img.h"

//------------------------------------------------------------------------------
// ����ü�� ����ǥ
// ����ü ����
#define  NUM_HCI_COLOR  7
#define  NUM_HCI_DETAIL_COLOR  16

// ����ü �׷캰 ����ǥ
struct RDR_HCI_COLOR {
  int  hci;
  char hci_ko[10];
  int  color;
  int  R;
  int  G;
  int  B;
} hci_color[NUM_HCI_COLOR] = {
  {0,"����",    0,255,255,255},
  //{1,"�񰭼�",  0,102,255,102},
  {1,"�񰭼�",  0,210,210,210},
  {2,"����",    0,245,255,102},
  {3,"��",      0,255,102,255},
  {4,"����",    0,102,255,255},
  {5,"��",      0, 51,102,255},
  {6,"���",    0,255, 51,  0},
};

// ����ü �󼼺з���(NCAR) ����ǥ
struct RDR_HCI_DETAIL_COLOR {
  int  hci;
  char hci_ko[40];
  int  color;
  int  R;
  int  G;
  int  B;
} hci_detail_color[NUM_HCI_DETAIL_COLOR] = {
  { 0,"����",     0,255,255,255},
  { 1,"����",     0,204,255,204},
  { 2,"�̽���",   0,153,204,255},
  { 3,"���Ѻ�",   0,102,153,255},
  { 4,"�߰���",   0, 51,102,255},
  { 5,"���Ѻ�",   0, 51, 51,204},
  { 6,"���",     0,255, 51,  0},
  { 7,"���/ ��", 0,255,102,  0},
  { 8,"��ڽζ�", 0,255,153,153},
  { 9,"�ζ�/ ��", 0,255,204,204},
  {10,"�Ǽ�",     0,255,102,255},
  {11,"����",     0,102,255,255},
  {14,"���ð�",   0, 51,204,204},
  {12,"������", 0,245,255,102},
  {13,"����",   0,255,204,102},
  {50,"�񰭼�",   0,210,210,210},
};

//------------------------------------------------------------------------------
// ��� ������ ����ǥ
// ��� ���� ����
#define  NUM_HAIL_COLOR  7

// ��� ������ ����ǥ
struct RDR_HAIL_COLOR {
  int  hail;
  char hail_ko[10];
  int  color;
  int  R;
  int  G;
  int  B;
} hail_color[NUM_HAIL_COLOR] = {
  {0,"����",0,255,255,255},
  {1,"1km", 0,255, 51,  0},
  {2,"2km", 0,255,153, 51},
  {3,"3km", 0,  0,128,  0},
  {4,"4km", 0, 51,204, 51},
  {5,"5km", 0,102,255,102},
  {6,"5km", 0,153,255,204},
};

//------------------------------------------------------------------------------
// ������ ����ǥ
// ������
#define  NUM_STN_COLOR  18

// ����ǥ
struct RDR_STN_COLOR {
  char stn_cd[8];
  char stn_ko[20];
  int  color;
  int  R;
  int  G;
  int  B;
} stn_color[NUM_STN_COLOR] = {
  {"BRI","��ɵ�",  0, 255, 82,  0},
  {"IIA","��õ����",0,   0,255,255},
  {"KWK","���ǻ�",  0, 173,  7,255},
  {"GDK","������",  0,   0,213,  0},
  {"GNG","����",    0, 255,165,  0},
  {"KSN","������",  0, 238,238, 73},
  {"JNI","����",    0,  73,238,238},
  {"MYN","�����",  0,   0,172,255},
  {"PSN","������",  0, 105,252,105},
  {"GSN","����",    0, 218,135,255},
  {"SSP","����",    0, 204,170,  0},
  {"RKSG","����U",  0, 233,147,106},
  {"RKJK","����U",  0,   0,102,255},
  {"GRS","������",  0, 249,205,  0},
  {"SBS","�ҹ��",  0,  76, 78,177},
  {"SDS","�����",  0,   0,128,  0},
  {"MHS","���Ļ�",  0,  31, 33,157},
  {"BSL","�񽽻�",  0, 250,133,133}
};

struct INPUT_VAR  var;
struct STN_VAL  stn_data[MAX_STN];

struct RDR_R3D_HEAD  rdr_r3d_head;              // �ռ��ڷ� Header
struct RDR_CMP_STN_LIST  rdr_r3d_stn_list[48];  // �ռ��� ���̴� ���
unsigned short  **echo;

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main()
{
  int   err = 0;
  float km_px;
  int   num_sm, i;

  // 1. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(20);

  printf("HTTP/1.0 200 OK\n");
  //printf("Content-type: text/plain\n\n");

  // 2. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    err = 1;
  }

  // 3. ���̴��ڷḦ ����
  if (rdr_r3d_get() < 0) err = 2;

  // 4. ���� ó��
  if (err > 0) {
    err_img(err);
    return 0;
  }

  // 5. AWS���� �а�, Ȯ�� ó��
  if (var.aws > 0 && var.zoom_level > 0) {
    aws_info_get();
    aws_data_get();
    aws_zooming();
  }

  // 6. ��Ȱȭ
  /*
  if ((!strcmp(var.cmp,"HSR") || !strcmp(var.cmp,"PPI") || !strcmp(var.cmp,"CPP") ||
       !strcmp(var.cmp,"CMX") || !strcmp(var.cmp,"LNG") || !strcmp(var.cmp,"LQC"))
       && !strcmp(var.obs,"ECHO")) {
    km_px = ((float)var.NX/var.grid) / (float)(var.size*(var.zoom_level+1)); // Pixel�� ���ڼ�

    if (km_px >= 1.0)
      var.sms += (int)(km_px + 0.5);
    else if (km_px >= 0.5)
      var.sms += 1;

    if (var.sms > 3) var.sms = 3;  // ���ϰ氨����

    for (i = 0; i < var.sms; i++)
      grid_smooth(echo, (int)(rdr_r3d_head.nx), (int)(rdr_r3d_head.ny), BLANK3);
  }
  */

  // 7. �̹��� ���� �� ����
  rdr_r3d_img();

  // 8. �޸� �ݳ�
  free_smatrix2(echo, 0, (int)(rdr_r3d_head.ny-1), 0, (int)(rdr_r3d_head.nx-1));

  alarm(0);
  return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
  char *qs;
  char tmp[256], item[32], value[32], tm[30];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, i, j;

  // 1. ���� �ʱⰪ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "0");        // ����ð�
  strcpy(var.map, "HR");  // ���̴� ����
  var.ht = 1500;
  var.zoom_level = 0;     // ��ü����
  var.zoom_rate = 2;      // 2�� Ȯ�밡 �⺻
  var.ZRa = 200;
  var.ZRb = 1.6;
  var.num_gov = 0;
  var.aws = 0;
  var.sms = 1;
  var.legend = 1;
  var.dir_mode = 0;

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"cmp")) strcpy(var.cmp, value);
    else if ( !strcmp(item,"qcd")) strcpy(var.qcd, value);
    else if ( !strcmp(item,"obs")) strcpy(var.obs, value);
    else if ( !strcmp(item,"vol")) strcpy(var.vol, value);
    else if ( !strcmp(item,"map")) strcpy(var.map, value);
    else if ( !strcmp(item,"color")) strcpy(var.color, value);
    else if ( !strcmp(item,"tm"))  strcpy(tm, value);
    else if ( !strcmp(item,"ht")) var.ht = atoi(value);
    else if ( !strcmp(item,"x1")) var.x1 = atoi(value);
    else if ( !strcmp(item,"y1")) var.y1 = atoi(value);
    else if ( !strcmp(item,"x2")) var.x2 = atoi(value);
    else if ( !strcmp(item,"y2")) var.y2 = atoi(value);
    else if ( !strcmp(item,"auto_man")) var.auto_man = value[0];
    else if ( !strcmp(item,"gov")) {
      for (var.num_gov = 0, j = 0; value[0] != '\0'; j++) {
        getword (tmp, value, ':');
        if (strlen(tmp) >= 3) {
          strcpy(var.gov_cd[var.num_gov], tmp);
          var.num_gov++;
        }
      }
    }
    else if ( !strcmp(item,"rate")) var.rate = value[0];
    else if ( !strcmp(item,"aws")) var.aws = atoi(value);
    else if ( !strcmp(item,"sms")) var.sms = atoi(value);
    else if ( !strcmp(item,"ZRa")) var.ZRa = atof(value);
    else if ( !strcmp(item,"ZRb")) var.ZRb = atof(value);
    else if ( !strcmp(item,"zoom_level")) var.zoom_level = atoi(value);
    else if ( !strcmp(item,"zoom_rate"))  var.zoom_rate = atoi(value);
    else if ( !strcmp(item,"zoom_x")) strcpy(var.zoom_x, value);
    else if ( !strcmp(item,"zoom_y")) strcpy(var.zoom_y, value);
    else if ( !strcmp(item,"size")) var.size = atoi(value);
    else if ( !strcmp(item,"legend")) var.legend = atoi(value);
    else if ( !strcmp(item,"dir")) var.dir_mode = atoi(value);
  }

  // 3. �⺻�� ����
  var.grid = 0.5;
  if (var.num_gov == 0) {
    var.num_gov = 1;
    strcpy(var.gov_cd[0],"KMA");
  }
  if (var.ht <= 0) var.ht = 1500;

  if (strcmp(var.vol,"SN") == 0) {
    var.ZRa = 2000;
    var.ZRb = 2;
  }

  // 4. ����ð� �� ���� �����ð� ����
  get_time(&iYY, &iMM, &iDD, &iHH, &iMI, &iSS);
  iseq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  var.seq_now = iseq;

  // 5. ��û�ð� ����
  if (strlen(tm) < 10 || var.auto_man == 'a')
    var.seq = iseq;
  else {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
    var.seq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  }
  var.seq = 5*(var.seq/5);

  // 6. ���� ���翩�� Ȯ��
  for (i = 0; i < 10; i++, var.seq -= 5) {
    if (rdr_r3d_file() >= 0) {
      break;
    }
  }
  return 0;
}

/*******************************************************************************
 *
 *  ���̴� 3���� �ռ��� �̹��� ���� �� ����
 *
 *******************************************************************************/
int rdr_r3d_img()
{
  gdImagePtr im;
  FILE  *fp;
  float data_lvl[256];
  int   color_lvl[256];

  // 1. �̹��� ���� ����
  var.NI = var.size;
  var.NJ = (int)((float)(var.NY)/(float)(var.NX)*var.NI);
  var.GI = var.NI;
  if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + TITLE_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_table(im, color_lvl, data_lvl);
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[240]);

  // 3. �����ڷ� �׸���
  grid_disp(im, color_lvl, data_lvl);

  // 4. �������� �׸���
  topo_disp(im, color_lvl);

  // 5. ���� �׸���
  if (var.zoom_level >= 2) map_disp(im, color_lvl[249], 1);
  map_disp(im, color_lvl[244], 4);

  // 6. ���� ǥ��
  if (var.aws > 0 && var.zoom_level > 0) aws_disp(im, color_lvl);

  // 7. ���� �׸�
  title_disp(im, color_lvl);

  // 8. ���� �׸���
  legend_disp(im, color_lvl, data_lvl);
  gdImageRectangle(im, 0, TITLE_pixel, var.NI-1, var.GJ-1, color_lvl[242]);

  // 9. �ܸ鵵 �� �׸���
  cross_line_disp(im, color_lvl);

  // 10. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);
  return 0;
}

/*=============================================================================*
 *  ����ǥ
 *=============================================================================*/
int color_table(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  FILE  *fp;
  float v1;
  char  color_file[120];
  int   R, G, B;

  // 1. ��󺯼��� ����ǥ ���� ����
  strcpy(color_file,COLOR_SET_DIR);
  if      (strcmp(var.vol,"RN") == 0) strcat(color_file,"color_rdr_echo.rgb");
  else if (strcmp(var.vol,"SN") == 0) strcat(color_file,"color_rdr_SN.rgb");
  else if (strcmp(var.vol,"CZ") == 0) strcat(color_file,"color_rdr_CZ.rgb");
  else if (strcmp(var.vol,"DR") == 0) strcat(color_file,"color_rdr_DR.rgb");
  else if (strcmp(var.vol,"RH") == 0) strcat(color_file,"color_rdr_RH.rgb");
  else if (strcmp(var.vol,"KD") == 0) strcat(color_file,"color_rdr_KD.rgb");

  // 2. ����ǥ ���ϰ� ������ �б�
  if (strcmp(var.obs,"STN") == 0) {
    var.num_color = NUM_STN_COLOR;
    for (var.num_color = 0; var.num_color < NUM_STN_COLOR; var.num_color++) {
      R = stn_color[var.num_color].R;
      G = stn_color[var.num_color].G;
      B = stn_color[var.num_color].B;
      stn_color[var.num_color].color = gdImageColorAllocate(im, R, G, B);
    }
  }
  else if (strcmp(var.vol,"HC") == 0) {
    for (var.num_color = 0; var.num_color < NUM_HCI_DETAIL_COLOR; var.num_color++) {
      R = hci_detail_color[var.num_color].R;
      G = hci_detail_color[var.num_color].G;
      B = hci_detail_color[var.num_color].B;
      hci_detail_color[var.num_color].color = gdImageColorAllocate(im, R, G, B);
    }
  }
  else {
    var.num_color = 0;
    if ((fp = fopen(color_file, "r")) != NULL) {
      while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
        color_lvl[var.num_color] = gdImageColorAllocate(im, R, G, B);
        data_lvl[var.num_color] = v1;
        var.num_color++;
        if (var.num_color > 119) break;
      }
      fclose(fp);
    }
  }

  // 4. ��Ÿ ����ǥ ����
  color_lvl[240] = gdImageColorAllocate(im, 180, 180, 180);   // ����1
  color_lvl[241] = gdImageColorAllocate(im, 255, 255, 255);   // ����2
  color_lvl[242] = gdImageColorAllocate(im, 30, 30, 30);      // ������
  color_lvl[243] = gdImageColorAllocate(im, 12, 28, 236);     // ����
  color_lvl[244] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  color_lvl[245] = gdImageColorAllocate(im, 240, 240, 240);
  color_lvl[246] = gdImageColorAllocate(im, 255, 0, 0);
  color_lvl[247] = gdImageColorAllocate(im, 0, 0, 255);
  color_lvl[248] = gdImageColorAllocate(im, 160, 160, 160);   // ����3
  color_lvl[249] = gdImageColorAllocate(im, 110, 110, 110);   // �ñ����
  color_lvl[250] = gdImageColorAllocate(im, 80, 80, 80);      // ��������
  color_lvl[251] = gdImageColorAllocate(im, 255, 0, 172);     // �ܸ鼱

  return 0;
}

/*=============================================================================*
 *  ����ü ����� ����ü ������ �߿䵵�� ���� ��з�
 *=============================================================================*/
short rdr_hci_num(short ec)
{
  short hci;

  switch (ec) {
    case 0:  hci = 0;  break;   // ������
    case 50: hci = 1;  break;   // �񰭼�
    case 12: hci = 2;  break;   // ����(���)
    case 13: hci = 2;  break;   // ����(����)
    case 10: hci = 3;  break;   // ��(�Ǽ�)
    case 14: hci = 4;  break;   // ��������(���ð�����)
    case 11: hci = 4;  break;   // ��������(����)
    case 9:  hci = 4;  break;   // ��������(�ζ���/��)
    case 1:  hci = 5;  break;   // ��(����)
    case 2:  hci = 5;  break;   // ��(�̽���)
    case 3:  hci = 5;  break;   // ��(���Ѻ�)
    case 4:  hci = 5;  break;   // ��(�߰���)
    case 5:  hci = 5;  break;   // ��(���Ѻ�)
    case 8:  hci = 6;  break;   // ���(�ζ���+�������)
    case 7:  hci = 6;  break;   // ���(��+���)
    case 6:  hci = 6;  break;   // ���
    default: hci = -1;
  }
  return hci;
}

/*=============================================================================*
 *  �����ڷ� ǥ��
 *=============================================================================*/
int grid_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  float obs_mltp = rdr_r3d_head.data_scale, obs_plus = rdr_r3d_head.data_minus;
  unsigned char *n1, *n2;
  unsigned short *e1, *e2, e3, e4;
  float *r1, *r2;

  float lvl[256], dbz1, rain1;
  float x1, y1, x, y, dd, d1, d2, dd1, dd2;
  float zm = 1.0, xo = 0.0, yo = 0.0;
  float grid_nx, grid_ny, zx, zy, rate, wy1, wy2, wx1, wx2;
  short blank = BLANK1;
  int   dxy, nx, ny, map_code;
  int   list_num[NUM_STN_COLOR];
  int   stn_ok = 0, num_ok = 0, pcp_ok = 0, hci_ok = 0, hci2_ok = 0, hail_ok = 0;
  int   nd, ix, iy, color1;
  int   i, j, k;

  // 1. ����ó��
  if (var.num_color <= 0) {
    gdImageString(im, gdFontLarge, 100, 100, "No Color Level", color_lvl[244]);
    return -1;
  }

  // 2. �⺻ ����
  dxy = rdr_r3d_head.dxy;
  nx  = rdr_r3d_head.nx;
  ny  = rdr_r3d_head.ny;
  map_code = rdr_r3d_head.map_code;

  grid_ny = 1000.0*(float)(var.NY)/(float)dxy;
  grid_nx = 1000.0*(float)(var.NX)/(float)dxy;
  if (map_code == 1) {
    yo = 1000.0*(float)(HB_SY-var.SY)/(float)dxy;
    xo = 1000.0*(float)(HB_SX-var.SX)/(float)dxy;
  }
  else if (map_code == 2) {
    yo = 1000.0*(float)(HC_SY-var.SY)/(float)dxy;
    xo = 1000.0*(float)(HC_SX-var.SX)/(float)dxy;
  }
  else if (map_code == 3) {
    yo = 1000.0*(float)(HR_SY-var.SY)/(float)dxy;
    xo = 1000.0*(float)(HR_SX-var.SX)/(float)dxy;
  }
  rate = grid_nx/(float)(var.NI);    // �̹��� �ȼ��� ���ڼ�

  if (strcmp(var.obs,"ECHO") == 0) {
    if (strcmp(var.vol,"HC")  == 0) { hci2_ok  = 1;  blank = BLANK1; }
  }

  // 3. ��ϰ� ����
  if (strcmp(var.obs,"STN") == 0) {
    for (k = 0; k < rdr_r3d_head.num_stn; k++) {
      list_num[k] = -1;
      for (i = 0; i < NUM_STN_COLOR; i++) {
        if (strstr(rdr_r3d_stn_list[k].stn_cd, stn_color[i].stn_cd) != NULL) {
          list_num[k] = i;
          break;
        }
      }
    }
    stn_ok = 1;
    blank = 0;
  }
  else if (strcmp(var.vol,"RN") == 0 || strcmp(var.vol,"SN") == 0) {
    for (k = 0; k < var.num_color; k++) {
      rain1 = data_lvl[k];
      dbz_rain_conv(&dbz1, &rain1, 1);
      lvl[k] = dbz1*obs_mltp + obs_plus;
    }
    stn_ok = 0;
    blank = BLANK1;
  }
  else {
    for (k = 0; k < var.num_color; k++)
      lvl[k] = data_lvl[k]*obs_mltp + obs_plus;
    stn_ok = 0;
    blank = BLANK1;
  }

  // 4. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    if (var.zoom_rate == 3) {
      for (i = 0; i < 2; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (grid_nx/9.0*(zx-1)/zm);
        yo += (grid_ny/9.0*(zy-1)/zm);
        zm *= var.zoom_rate;
      }
    }
    else if (var.zoom_rate == 2) {
      for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (grid_nx/8.0*(zx-1)/zm);
        yo += (grid_ny/8.0*(zy-1)/zm);
        zm *= var.zoom_rate;
      }
    }
  }

  // 5. �̹��� �ȼ����� ���
  for (j = 1; j < var.NJ; j++) {
    y1 = rate*j/zm + yo;
    iy = (int)(y1);
    if (iy < 1 || iy >= ny-1) continue;
    wy2 = y1 - iy;
    wy1 = 1.0 - wy2;

    e1 = echo[iy];
    e2 = echo[iy+1];

    for (i = 1; i < var.NI; i++) {
      // 5.1. �ȼ��� �ش��ϴ� ��ǥ Ȯ��
      x1 = rate*i/zm + xo;
      ix = (int)(x1);
      if (ix < 1 || ix >= nx-1) continue;
      wx2 = x1 - ix;
      wx1 = 1.0 - wx2;

      // 5.4. �ٸ� �ڷ��� ���, �ڷᰡ �������� ������ ǥ��
      if (stn_ok)
        e3 = (*(e1 + ix) & 0xF800) >> 11;
      else
        e3 = *(e1 + ix) & 0x07FF;

      if (e3 > blank) {
        if (stn_ok) {
          nd = (int)(e3 + 0.1) - 1;
          if (nd >= 0 && nd < NUM_STN_COLOR) {
            if (list_num[nd] >= 0) {
              gdImageSetPixel(im, i, var.GJ-j, stn_color[list_num[nd]].color);
            }
          }
        }
        else if (hci2_ok) {
          nd = (int)(e3 - obs_plus + 0.1);
          for (k = 0; k < NUM_HCI_DETAIL_COLOR; k++) {
            if (nd == hci_detail_color[k].hci) {
              gdImageSetPixel(im, i, var.GJ-j, hci_detail_color[k].color);
              break;
            }
          }
        }
        else {
          d1 = e3;  d2 = *(e1+ix+1)&0x07FF;  dd1 = d1*wx1 + d2*wx2;
          d1 = *(e2+ix)&0x07FF;  d2 = *(e2+ix+1)&0x07FF;  dd2 = d1*wx1 + d2*wx2;
          dd = dd1*wy1 + dd2*wy2;

          color1 = color_lvl[var.num_color-1];
          for (k = 0; k < var.num_color; k++) {
            if (dd <= lvl[k]) {
              color1 = color_lvl[k];
              break;
            }
          }
          gdImageSetPixel(im, i, var.GJ-j, color1);
        }
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  �������� ǥ��
 *=============================================================================*/
int topo_disp(gdImagePtr im, int color_lvl[])
{
  FILE  *fp;
  short **topo;
  long  offset1 = (HB_SX-COM_SX)*2;
  long  offset2 = (HB_NX-COM_NX)*2 - offset1;
  float dg = (float)COM_NX/(float)(var.NI);
  float zm = 1.0, xo = 0.0, yo = 0.0, zx, zy, x1, y1, ht;
  int   ix, iy;
  int   i, j, k;

  // 1. ���� ����
  if ((fp = fopen(TOPO_FILE, "rb")) == NULL) return -1;

  // 2. �ش�(64byts) + �Ʒ��κ� skip
  fseek(fp, (long)((HB_SY-COM_SY)*(HB_NX+1)*2 + 64), SEEK_SET);
  topo = smatrix(0, COM_NY, 0, COM_NX);

  // 3. HR ������ �б�
  for (j = 0; j <= COM_NY; j++) {
    fseek(fp, offset1, SEEK_CUR);
    fread(topo[j], 2, COM_NX+1, fp);  // ���� 0.1m
    fseek(fp, offset2, SEEK_CUR);
  }
  fclose(fp);

  // 4. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    if (var.zoom_rate == 3) {
      for (i = 0; i < 2; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += ((COM_NX - 1)/9.0*(zx-1)/zm);
        yo += ((COM_NY - 1)/9.0*(zy-1)/zm);
        zm *= var.zoom_rate;
      }
    }
    else if (var.zoom_rate == 2) {
      for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += ((COM_NX - 1)/8.0*(zx-1)/zm);
        yo += ((COM_NY - 1)/8.0*(zy-1)/zm);
        zm *= var.zoom_rate;
      }
    }
  }

  // 5. �̹��� �ȼ����� ���
  for (j = 1; j < var.NJ; j++) {
    y1 = dg*j/zm + yo;
    iy = (int)(y1);
    if (iy < 0 || iy >= COM_NY) continue;

    for (i = 1; i < var.NI; i++) {
      x1 = dg*i/zm + xo;
      ix = (int)(x1);
      if (ix < 0 || ix >= COM_NX) continue;

      ht = (float)topo[iy][ix]*0.1;
      if (var.ht <= ht) {
        gdImageSetPixel(im, i, var.GJ-j, color_lvl[250]);
      }
    }
  }

  free_smatrix(topo, 0, COM_NY, 0, COM_NX);
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int map_disp(gdImagePtr im, int color_map, int kind)
{
  FILE  *fp;
  char  fname[120];
  float zm = 1.0, xo = 0.0, yo = 0.0, x1, y1, x2, y2;
  int   zx, zy, depth, mode;
  int   i, j, k, n;

  // 0. �ʱ� ����
  if (var.NI > 600)
    depth = 1;
  else if (var.NI > 450 && kind == 4)
    depth = 1;
  else
    depth = 0;

  // 1. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    if (var.zoom_rate == 3) {
      for (i = 0; i < 2; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/9.0*(zx-1)/zm;
        yo += (float)(var.NY)/9.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
    else if (var.zoom_rate == 2) {
      for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/8.0*(zx-1)/zm;
        yo += (float)(var.NY)/8.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
  }

  // 2. �ؾȼ� ǥ��
  sprintf(fname, "%s/AFS_%s_map%d.dat", MAP_DIR, var.map, kind);
  if ((fp = fopen(fname, "r")) != NULL) {
    while (fscanf(fp, "%d %d\n", &n, &mode) != EOF) {
      for (i = 0; i < n; i++) {
        fscanf(fp, "%f %f\n", &x2, &y2);
        if (var.zoom_level > 0) {
          x2 = zm*(x2-xo);
          y2 = zm*(y2-yo);
        }
        x2 *= ((float)(var.NI)/(float)(var.NX));
        y2 *= ((float)(var.NI)/(float)(var.NX));
        if (i > 0) {
          gdImageLine(im, (int)x1, var.GJ-(int)y1, (int)x2, var.GJ-(int)y2, color_map);
          if (depth) gdImageLine(im, (int)x1, var.GJ-(int)y1-1, (int)x2, var.GJ-(int)y2-1, color_map);
        }
        x1 = x2;
        y1 = y2;
      }
    }
    fclose(fp);
  }

  return 0;
}

/*=============================================================================*
 *  EUC-KR���ڿ��� UTF-8�� ��ȯ
 *=============================================================================*/
int euckr2utf(char *str, char *out)
{
    iconv_t convp;
    size_t  ileft, oleft;
    int     err, len = strlen(str);

    ileft = len;
    oleft = len * 2;

    convp = iconv_open("UTF-8", "euc-kr");
    err = iconv(convp, &str, &ileft, &out, &oleft);
    iconv_close(convp);

    return err;
}

/*=============================================================================*
 *  ���� ǥ��(�ѱ�ó��)
 *=============================================================================*/
int title_disp(gdImagePtr im, int color_lvl[])
{
  char   title[80], tm_fc_str[100], num_stn_str[10], text[100], tmp[50];
  char   title_utf[100], str_utf[100];
  double font_size = 11.5;
  int    brect[8];
  int    YY, MM, DD, HH, MI;
  int    x, y, i, k;

  // 1. ���񿵿��� ���� ó��
  gdImageFilledRectangle(im, 0, 0, var.GI, TITLE_pixel, color_lvl[241]);

  // 2. ������
  strcpy(title, "���̴� R3D");
  if      (strcmp(var.qcd,"KMA") == 0) strcat(title, "(���û) ");
  else if (strcmp(var.qcd,"EXT") == 0) strcat(title, "(����) ");

  if      (strcmp(var.vol,"RN") == 0) strcat(title, "����");
  else if (strcmp(var.vol,"SN") == 0) strcat(title, "����");
  else strcat(title, var.vol);

  if (strcmp(var.obs,"STN") == 0) strcat(title,"(����)");

  for (i = 0; i < 100; i++)
    title_utf[i] = 0;
  euckr2utf(title, title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 5, (int)(font_size+5), title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 6, (int)(font_size+5), title_utf);

  // 3. �ð� ���ڿ�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(tm_fc_str, "%04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, MI);

  x = strlen(title)*8.6 + 10;
  if (x < 130) x = 130;
  gdImageString(im, gdFontLarge, x, 1, tm_fc_str, color_lvl[244]);
  gdImageString(im, gdFontLarge, x+1, 1, tm_fc_str, color_lvl[244]);

  // 4. ���� ǥ��
  sprintf(text, "���� %dm", var.ht);
  for (i = 0; i < 100; i++)
    str_utf[i] = 0;
  euckr2utf(text, str_utf);
  y = (int)(font_size+5) + TITLE_pixel;
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 5, y, str_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 6, y, str_utf);

  // 5. ǥ�⿵���� ������ ǥ��
  sprintf(num_stn_str, "#%d", var.num_rdr_stn);
  gdImageFilledRectangle(im, var.NI-38, var.GJ-18, var.NI-2, var.GJ-2, color_lvl[241]);
  gdImageString(im, gdFontLarge, var.NI-35, var.GJ-17, num_stn_str, color_lvl[244]);

  // 6. Z/R ��� ǥ��
  if (strcmp(var.obs,"ECHO") == 0 && var.size > 350 && (strcmp(var.vol,"RN") == 0 || strcmp(var.vol,"SN") == 0)) {
    if (var.ZRa != 200 && var.ZRb != 1.6) {
      sprintf(text, "%.1f / %.1f", var.ZRa, var.ZRb);
      gdImageFilledRectangle(im, 1, var.GJ-18, strlen(text)*9, var.GJ-1, color_lvl[241]);
      gdImageString(im, gdFontLarge, 5, var.GJ-17, text, color_lvl[244]);
    }
  }
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int legend_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  char   txt[20];
  char   txt_utf[30];
  double font_size = 9.0;
  int    brect[8], unit_ok = 0, color1;
  float  dy = (float)(var.NJ)/(float)(var.num_color);
  int    YY, MM, DD, HH, MI;
  int    x, y, i, j, k;

  if (var.legend != 1) return 0;
  if (var.num_color <= 0) return -1;

  // 1. ���� ���� ǥ��
  if (strcmp(var.obs,"STN") == 0) {
    for (k = 0; k < var.num_color; k++) {
      y = TITLE_pixel + dy*k;
      gdImageFilledRectangle(im, var.NI, y, var.NI+8, y+dy, stn_color[k].color);
    }
  }
  else if (strcmp(var.vol,"HC") == 0) {
    for (k = 0; k <= var.num_color-1; k++) {
      y = TITLE_pixel + dy*k;
      gdImageFilledRectangle(im, var.NI, y, var.NI+8, y+dy, hci_detail_color[k].color);
    }
  }
  else {
    for (k = 0; k < var.num_color; k++) {
      y = var.GJ - dy*k;
      gdImageFilledRectangle(im, var.NI, y-dy, var.NI+8, y, color_lvl[k]);
    }
  }
  gdImageRectangle(im, var.NI-1, TITLE_pixel, var.NI+8, var.GJ-1, color_lvl[242]);

  // 2. ���ʰ� ǥ��
  gdImageFilledRectangle(im, var.NI+9, 0, var.GI-1, var.GJ, color_lvl[241]);
  if (strcmp(var.obs,"STN") == 0) {
    for (k = 0; k < NUM_STN_COLOR; k++) {
      for (j = 0; j <= 4; j += 4) {
        y = TITLE_pixel + k*dy + j/4*14 + 15;
        strncpy(txt, &(stn_color[k].stn_ko[j]), 4);

        for (i = 0; i < 30; i++) txt_utf[i] = 0;
        euckr2utf(txt, txt_utf);

        color1 = color_lvl[244];
        for (i = 0; i < rdr_r3d_head.num_stn; i++) {
          if (!strcmp(rdr_r3d_stn_list[i].stn_cd,stn_color[k].stn_cd)) {
            color1 = color_lvl[247];
            break;
          }
        }
        gdImageStringFT(im, &brect[0], color1, FONTTTF, font_size, 0.0, var.NI+11, y, txt_utf);
      }
    }
  }
  else if (strcmp(var.vol,"HC") == 0) {
    font_size = 9.0;
    for (k = 0; k <= var.num_color-1; k++) {
      for (j = 0; j < strlen(hci_detail_color[k].hci_ko)-1; j += 4) {
        y = TITLE_pixel + dy*k + dy/4 + j*4;
        strncpy(txt, &(hci_detail_color[k].hci_ko[j]), 4);
        txt[4] = '\0';
        for (i = 0; i < 30; i++) txt_utf[i] = 0;
        euckr2utf(txt, txt_utf);
        gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, var.NI+11, y, txt_utf);
      }
    }
  }
  else if (strcmp(var.vol,"RN") == 0 || strcmp(var.vol,"SN") == 0) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      if (data_lvl[k] < 5)
        sprintf(txt, "%.1f", data_lvl[k]);
      else
        sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (strcmp(var.vol,"RH") == 0) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.2f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (strcmp(var.vol,"DZ") == 0 || strcmp(var.vol,"CZ") == 0 ||
           strcmp(var.vol,"VR") == 0 || strcmp(var.vol,"PH") == 0 ) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.1f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }

  // 3. ���� ���� ǥ��
  if (strcmp(var.obs,"STN") != 0) {
    if      (strcmp(var.vol,"RN") == 0) strcpy(txt,"mm/h");
    else if (strcmp(var.vol,"SN") == 0) strcpy(txt,"cm/h");
    else if (strcmp(var.vol,"DZ") == 0) strcpy(txt,"dBZ");
    else if (strcmp(var.vol,"CZ") == 0) strcpy(txt,"dBZ");
    else if (strcmp(var.vol,"DR") == 0) strcpy(txt,"dB");
    else if (strcmp(var.vol,"RH") == 0) strcpy(txt,"");
    else if (strcmp(var.vol,"KD") == 0) strcpy(txt,"deg/km");
    else if (strcmp(var.vol,"HC") == 0) strcpy(txt,"");

    x = var.NI + 3;
    gdImageString(im, gdFontLarge, x, 4, txt, color_lvl[244]);
  }
  return 0;
}

/*=============================================================================*
 *  �ܸ鼱 ǥ��
 *=============================================================================*/
int cross_line_disp(gdImagePtr im, int color_lvl[])
{
  float zm = 1.0, xo = 0.0, yo = 0.0, zx, zy;
  int   x1, y1, x2, y2;
  int   i;

  // 1. �ܸ鼱�� �ִ��� �Ǵ�
  if (var.x1 < 0) return;

  // 2. 2�� Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    for (i = 0; i < 7; i++) {
      zx = var.zoom_x[i]-'0';
      zy = var.zoom_y[i]-'0';
      if (zx == 0 || zy == 0) break;

      xo += (var.NX/8.0*(zx-1)/zm);
      yo += (var.NY/8.0*(zy-1)/zm);
      zm *= 2;
    }
  }

  // 3. Ȯ�븦 �����Ͽ� �ܸ鼱�� �ȼ� ��ġ �ľ�
  x1 = (var.x1 - xo)*zm*(float)var.NI/(float)var.NX;
  x2 = (var.x2 - xo)*zm*(float)var.NI/(float)var.NX;
  y1 = var.GJ - (var.y1 - yo)*zm*(float)var.NJ/(float)var.NY;
  y2 = var.GJ - (var.y2 - yo)*zm*(float)var.NJ/(float)var.NY;

  // 4. �ܸ鼱 ǥ��
  gdImageLine(im, x1, y1, x2, y2, color_lvl[251]);
  gdImageLine(im, x1, y1-1, x2, y2-1, color_lvl[251]);
  gdImageFilledArc(im, x1, y1, 5, 5, 0, 360, color_lvl[251], gdArc);
  gdImageFilledArc(im, x2, y2, 5, 5, 0, 360, color_lvl[251], gdArc);
  return 0;
}

/*******************************************************************************
 *
 *  �ڷᰡ �̻��� �ִ� ���, ���� �̹��� ���
 *
 *******************************************************************************/
int err_img(int err)
{
  gdImagePtr im;
  char  text[120], tmp[120];
  int   YY, MM, DD, HH, MI;
  int   color_lvl[16];
  int   x = 20, y = 20;
  int   i, j, k, n;

  // 1. �̹��� ���� ����
  var.NI = var.size;
  var.NJ = var.NI;
  var.GI = var.NI;
  if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + TITLE_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_lvl[0] = gdImageColorAllocate(im, 240, 240, 240);   // ����
  color_lvl[1] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[0]);

  // 3. ���� �޽���
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(text, "TIME = %04d.%02d.%02d.%02d:%02d / err = %d", YY, MM, DD, HH, MI, err);
  gdImageString(im, gdFontLarge, x, y, text, color_lvl[1]);

  sprintf(text, "CMP = %s / QCD = %s / OBS = %s", var.cmp, var.qcd, var.obs);
  gdImageString(im, gdFontLarge, x, y+=20, text, color_lvl[1]);

  sprintf(text, "SIZE = %dpx / ZRa = %.1f / ZRb = %.2f", var.size, var.ZRa, var.ZRb);
  gdImageString(im, gdFontLarge, x, y+=20, text, color_lvl[1]);

  if (err == 2)
    sprintf(text, "FILE = %s (file is not found)", var.fname);
  else
    sprintf(text, "FILE = %s", var.fname);
  gdImageString(im, gdFontLarge, x, y+=20, text, color_lvl[1]);

  // 4. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);

  return 0;
}
