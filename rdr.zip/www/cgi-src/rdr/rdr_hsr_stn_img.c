/*******************************************************************************
**
**  ���̴� ������ HSR�ڷḦ �ռ��������� ��ȯ�Ͽ� ǥ��
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.4.7)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include <gd.h>
#include <gdfontt.h>
#include <gdfonts.h>
#include <gdfontmb.h>
#include <gdfontl.h>
#include <gdfontg.h>
#include "rsl_wrc.h"
#include "cgiutil.h"
#include "nrutil.h"
#include "stn_inf.h"
#include "map_ini.h"
#include "url_io.h"
#include "rdr_cmp_ppi_header.h"
#include "rdr_cmp_stn_img.h"

#define  DEGRAD   3.1415927/180.0
#define  RADDEG   180.0/3.1415927

#define  MAP_INI_FILE  "/rdr/REF/MAP/map.ini"
#define  RDR_CMP_DIR   "/DATA/RDR/CMP"
#define  BLANK1  -30000     // No Area
#define  BLANK2  -25000     // No Data
#define  BLANK3  -20000     // Minimum Data

#define  LEG_pixel   35     // ����ǥ�ÿ���
#define  TITLE_pixel 20     // ����ǥ�ÿ���

// ����� �ѱ�TTF
char *fontttf = "/usr/share/fonts/korean/TrueType/gulim.ttf";

// ����ǥ
#define  NUM_STN_COLOR  15    // ����ǥ�� ������ ������
struct RDR_STN_COLOR {
  char stn_cd[8];
  char stn_ko[20];
  int  color;
  int  R;
  int  G;
  int  B;
} stn_color[NUM_STN_COLOR] = {
  {"BRI","��ɵ�",0, 255, 82,  0},
  {"KWK","���ǻ�",0, 173,  7,255},
  {"GDK","������",0,   0,213,  0},
  {"GNG","����",  0, 255,165,  0},
  {"KSN","������",0, 238,238, 73},
  {"JNI","����",  0,  73,238,238},
  {"MYN","�����",0,   0,172,255},
  {"PSN","������",0, 105,252,105},
  {"GSN","����",  0, 218,135,255},
  {"SSP","����",  0, 204,170,  0},
  {"GRS","������",0, 249,205,  0},
  {"SBS","�ҹ��",0,  76, 78,177},
  {"SDS","�����",0,   0,128,  0},
  {"MHS","���Ļ�",0,  31, 33,157},
  {"BSL","�񽽻�",0, 250,133,133}
};

//-----------------------------------------------------------------------------
// �ռ��ڷ��� ���ڿ��� (1152 km x 1440 km : 0.5 km ���ڰ���)
#define  NI  1152*2
#define  NJ  1440*2

struct INPUT_VAR var;          // ����� �Է� ����
short  rdr_cmp[NJ+1][NI+1];     // �ռ��ڷ� 
float  **g;                     // �����м����
struct RDR_CMP_HEAD  rdr_cmp_head;              // �ռ��ڷ� HEAD
struct RDR_CMP_STN_LIST  rdr_cmp_stn_list[29];  // �ռ��� ���̴� ���

int grid_smooth(float **g, int nx, int ny, float missing);

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main()
{
  float km_px;
  int   num_sm, i;

  // 1. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(20);

  printf("HTTP/1.0 200 OK\n");
  //printf("Content-type: text/plain\n\n");

  // 2. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    printf("Content-type: text/plain\n\n");
    printf("# input variable error<p>\n");
    return -1;
  }

  // 3. ���̴��ڷḦ ����
  rdr_data_get();

  // 4. ��Ȱȭ �� Ȯ��
  km_px = (float)(var.NX)*var.grid/(var.size*(var.zoom_level+1));
  if (km_px > 0.5) {
    if (km_px <= 2) num_sm = 1;
    else if (km_px <= 4) num_sm = 2;
    else num_sm = 3;

    for (i = 0; i < num_sm; i++)
      grid_smooth(g, var.NX, var.NY, BLANK3*0.01);
  }
  grid_zooming(g);

  // 5. �̹��� ���� �� ����
  rdr_ana_img();

  // 7. �޸� �ݳ�
  free_matrix(g, 0, var.NY, 0, var.NX);

  alarm(0);
  return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
  char *qs;
  char tmp[256], item[32], value[32], tm[30];
  char fname[120];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, i;

  // 1. ���� �ʱⰪ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "0");        // ����ð�
  strcpy(var.map, "D3");  // D3����
  var.zoom_level = 0;     // ��ü����
  var.zoom_rate = 2;      // 2�� Ȯ�밡 �⺻
  var.ZRa = 200;
  var.ZRb = 1.6;

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"map")) strcpy(var.map, value);
    else if ( !strcmp(item,"stn")) strcpy(var.stn_cd, value);
    else if ( !strcmp(item,"tm"))  strcpy(tm, value);
    else if ( !strcmp(item,"obs")) strcpy(var.obs, value);
    else if ( !strcmp(item,"grp")) var.grp = atoi(value);
    else if ( !strcmp(item,"qcd")) var.qcd = atoi(value);
    else if ( !strcmp(item,"vol")) strcpy(var.vol, value);
    else if ( !strcmp(item,"swp")) var.swp = atoi(value);
    else if ( !strcmp(item,"sms")) var.sms = atoi(value);
    else if ( !strcmp(item,"ZRa")) var.ZRa = atof(value);
    else if ( !strcmp(item,"ZRb")) var.ZRb = atof(value);
    else if ( !strcmp(item,"zoom_level")) var.zoom_level = atoi(value);
    else if ( !strcmp(item,"zoom_rate"))  var.zoom_rate = atoi(value);
    else if ( !strcmp(item,"zoom_x")) strcpy(var.zoom_x, value);
    else if ( !strcmp(item,"zoom_y")) strcpy(var.zoom_y, value);
    else if ( !strcmp(item,"size")) var.size = atoi(value);
    else if ( !strcmp(item,"legend")) var.legend = atoi(value);
    else if ( !strcmp(item,"color")) strcpy(var.color, value);
  }
  if (var.grid < 0.001) var.grid = 2.0;
  var.grid = 1.0;

  if      (strstr(var.obs,"cpp")) var.data = 1;
  else if (strstr(var.obs,"cmx")) var.data = 2;
  else if (strstr(var.obs,"ppi")) var.data = 3;
  else var.data = 4;

  // 3. ����ð� �� ���� �����ð� ����
  get_time(&iYY, &iMM, &iDD, &iHH, &iMI, &iSS);
  iseq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm') - 3;
  seq2time(iseq, &iYY, &iMM, &iDD, &iHH, &iMI, 'm', 'n');

  // 4. ��û�ð� ����
  if (strlen(tm) >= 10) {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
  }
  var.seq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  var.seq = 5*(var.seq/5);

  // 5. ���� ���翩�� Ȯ��
  for (i = 0; i < 5; i++, var.seq -= 5) {
    if (rdr_uf_file(var.stn_cd, var.seq, var.data, var.qcd, fname) >= 0) {
      break;
    }
  }
  return 0;
}

/*******************************************************************************
 *
 *  ���̴��ڷ� ���� ����
 *
 *******************************************************************************/
int rdr_data_get()
{
  FILE   *fp;
  short  buf[RDR_NX+1];
  char   head[720];
  float  z1, z2, rn1, rn2;
  int    dbz_max, nskip;
  int    GX, GY, SX, SY;
  int    i, j, k, n, ii, jj, i1, i2, j1, j2;
  int    code;

  // 1. ������ ���� ���� �� �ʱ�ȭ
  grid_map_inf(var.map, &GX, &GY, &SX, &SY);
  var.NX = (int)(GX/var.grid);   var.NY = (int)(GY/var.grid);
  g = matrix(0, var.NY, 0, var.NX);
  for (j = 0; j <= var.NY; j++) {
    for (i = 0; i <= var.NX; i++)
      g[j][i] = BLANK1;
  }

  // 2. ������ �ڷḦ �ռ��������� ��ȯ
  if (code = rdr_hsr_stn() < 0) {
    return -1;
  }

  // 5. �ڷ� ��ȯ
  for (jj = 0, j = 0; j <= GY; j += var.grid, jj++) {
    j1 = j + (RDR_SY - SY);
    if (j1 < 1 || j1 > RDR_NY-1) continue;

    for (ii = 0, i = 0; i <= GX; i += var.grid, ii++) {
      i1 = i + (RDR_SX - SX);
      if (i1 < 1 || i1 > RDR_NX-1) continue;

      // 5.1. ���ڰ��ݿ� ���� ��ǥ���� ����
      if ((int)(var.grid) >= 2) {
        for (dbz_max = BLANK1, j2 = j1-1; j2 <= j1+1; j2++) {
          for (i2 = i1-1; i2 <= i1+1; i2++) {
            if (rdr_cmp[j1][i1] > dbz_max) dbz_max = rdr_cmp[j1][i1];
          }
        }
        z1 = 0.01*dbz_max;
      }
      else
        z1 = 0.01*rdr_cmp[j1][i1];

      // 5.2. ���������� ��ȯ or �迭�� �Ҵ�
      if (strcmp(var.vol,"RN") == 0 || strcmp(var.vol,"SD") == 0) {
        if (z1*100 > BLANK3)
          dbz_rain_conv(&z1, &rn1, 0);
        else
          rn1 = z1;
        g[jj][ii] = rn1;
      }
      else {
        g[jj][ii] = z1;
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  Z-R �����
 *     - mode : 0(dBZ->������), 1(������->dBZ)
 *=============================================================================*/
int dbz_rain_conv(float *dbz, float *rain, int mode)
{
  if (mode == 0) {
    *rain = (*dbz*0.1 - log10(var.ZRa) )/var.ZRb;
    *rain = pow(10.0, *rain);
  }
  else if (mode == 1) {
    *dbz = 10.0 * log10( var.ZRa * pow(*rain, var.ZRb) );
  }
  return 0;
}

/*******************************************************************************
 *
 *  ������ �̹��� ���� �� ����
 *
 *******************************************************************************/
int rdr_ana_img()
{
  gdImagePtr im;
  FILE  *fp;
  int   color_lvl[256];
  float data_lvl[256];

  // 1. �̹��� ���� ����
  var.NI = var.size;
  var.NJ = (int)((float)(var.NY)/(float)(var.NX)*var.NI);
  var.GI = var.NI;
  if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + TITLE_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_table(im, color_lvl, data_lvl);
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[240]);

  // 3. �����ڷ� �׸���
  if (strcmp(var.obs,"STN") == 0)
    grid_stn_disp(im, color_lvl);
  else
    grid_disp(im, color_lvl, data_lvl);

  // 4. ���� �׸���
  if (var.zoom_level >= 2) map_disp(im, color_lvl[249], 1);
  map_disp(im, color_lvl[242], 4);

  // 6. ���� �׸�
  title_disp(im, color_lvl);

  // 7. ���� �׸���
  legend_disp(im, color_lvl, data_lvl);
  gdImageRectangle(im, 0, TITLE_pixel, var.NI-1, var.GJ-1, color_lvl[242]);

  // 8. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);
  return 0;
}

/*=============================================================================*
 *  ����ǥ
 *=============================================================================*/
int color_table(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  FILE  *fp;
  char  color_file[120];
  int   num_color;
  int   R, G, B;
  float v1;

  // 1. ��󺯼��� ����ǥ ���� ����
  strcpy(color_file,"/rdr/REF/COLOR/");
  if (strcmp(var.obs,"EBH") == 0)
    strcat(color_file,"color_rdr_ebh.rgb");
  else if (strcmp(var.obs,"ECHO") == 0) {
    if      (strcmp(var.color,"C1") == 0) strcat(color_file,"color_rn.rgb");
    else if (strcmp(var.color,"C2") == 0) strcat(color_file,"color_rdr.rgb");
    else if (strcmp(var.color,"C3") == 0) strcat(color_file,"color_rdr_blue.rgb");
    else if (strcmp(var.color,"C7") == 0) strcat(color_file,"color_rdr_snow.rgb");  // ����
    else
      strcat(color_file,"color_rdr_echo.rgb");
  }

  // 2. ����ǥ ���ϰ� ������ �б�
  if (strcmp(var.obs,"STN") == 0) {
    var.num_color = NUM_STN_COLOR;
    for (num_color = 0; num_color < NUM_STN_COLOR; num_color++) {
      R = stn_color[num_color].R;
      G = stn_color[num_color].G;
      B = stn_color[num_color].B;
      stn_color[num_color].color = gdImageColorAllocate(im, R, G, B);
    }
  }
  else {
    var.num_color = num_color = 0;
    if ((fp = fopen(color_file, "r")) != NULL) {
      while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
        color_lvl[num_color] = gdImageColorAllocate(im, R, G, B);
        data_lvl[num_color] = v1;
        num_color++;
        if (num_color > 119) break;
      }
      fclose(fp);
    }
    else {
      num_color = -1;
    }
    var.num_color = num_color;
  }

  // 3. ��Ÿ ����ǥ ����
  color_lvl[240] = gdImageColorAllocate(im, 220, 220, 220);   // ����1
  color_lvl[241] = gdImageColorAllocate(im, 255, 255, 255);   // ����2
  color_lvl[242] = gdImageColorAllocate(im, 30, 30, 30);      // ������
  color_lvl[243] = gdImageColorAllocate(im, 12, 28, 236);     // ����
  color_lvl[244] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  color_lvl[245] = gdImageColorAllocate(im, 240, 240, 240);
  color_lvl[246] = gdImageColorAllocate(im, 255, 0, 0);
  color_lvl[247] = gdImageColorAllocate(im, 0, 0, 255);
  color_lvl[248] = gdImageColorAllocate(im, 160, 160, 160);   // ����3
  color_lvl[249] = gdImageColorAllocate(im, 90, 90, 90);      // �ñ����

  return num_color;
}

/*=============================================================================*
 *  �����ڷ� ǥ�� (����)
 *=============================================================================*/
int grid_stn_disp(gdImagePtr im, int color_lvl[])
{
  float x, y, dx, dy, d1, d2;
  int   i, j, k, ix, iy, dd, color1;
  int   list_num[NUM_STN_COLOR];

  // 0. ���� Ȯ��
  for (k = 0; k < rdr_cmp_head.num_stn; k++) {
    list_num[k] = -1;
    for (i = 0; i < NUM_STN_COLOR; i++) {
      if (strstr(rdr_cmp_stn_list[k].stn_cd, stn_color[i].stn_cd) != NULL) {
        list_num[k] = i;
        break;
      }
    }
  }

  // 1. Y�� ����
  for (j = 1; j < var.NJ; j++) {
    y = (float)j*(float)(var.NY)/(float)(var.NJ);
    iy = (int)y;
    dy = y - iy;
    if (iy < 0 || iy > var.NY-1) continue;

    // 2. X������ ����
    for (i = 1; i < var.NI; i++) {
      x = (float)i*(float)(var.NX)/(float)(var.NI);
      ix = (int)x;
      dx = x - ix;
      if (ix < 0 || ix > var.NX-1) continue;

      dd = (int)(g[iy][ix] + 0.1) - 1;

      // 4. �ڷᰡ �������� ������ ǥ��
      if (dd >= 0 && dd < NUM_STN_COLOR) {
        if (list_num[dd] >= 0) {
          color1 = stn_color[list_num[dd]].color;
          gdImageSetPixel(im, i, var.GJ-j, color1);
        }
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  �����ڷ� ǥ��
 *=============================================================================*/
int grid_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  float x, y, dx, dy, d1, d2, dd;
  int   i, j, k, ix, iy, color1;

  // 0. ����ó��
  if (var.num_color <= 0) {
    gdImageString(im, gdFontLarge, 100, 100, "No Color Level", color_lvl[244]);
    return -1;
  }

  // 1. Y�� ����
  for (j = 1; j < var.NJ; j++) {
    y = (float)j*(float)(var.NY)/(float)(var.NJ);
    iy = (int)y;
    dy = y - iy;
    if (iy < 0 || iy > var.NY-1) continue;

    // 2. X������ ����
    for (i = 1; i < var.NI; i++) {
      x = (float)i*(float)(var.NX)/(float)(var.NI);
      ix = (int)x;
      dx = x - ix;
      if (ix < 0 || ix > var.NX-1) continue;

      // 3. �ش� �̹��� �ȼ� ��ġ�� ���� ���
      //if (g[iy][ix] > -90 && g[iy][ix+1] > -90 && g[iy+1][ix] > -90 && g[iy+1][ix+1] > -90) {
      //  d1 = (1.0-dx)*g[iy][ix] + dx*g[iy][ix+1];
      //  d2 = (1.0-dx)*g[iy+1][ix] + dx*g[iy+1][ix+1];
      //  dd = (1.0-dy)*d1 + dy*d2;
      //}
      //else {
        dd = g[iy][ix];
      //}

      // 4. �ڷᰡ �������� ������ ǥ��
      if (dd > BLANK1*0.01) {
        color1 = color_lvl[var.num_color-1];
        for (k = 0; k < var.num_color; k++) {
          if (dd <= data_lvl[k]) {
            color1 = color_lvl[k];
            break;
          }
        }
        gdImageSetPixel(im, i, var.GJ-j, color1);
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int map_disp(gdImagePtr im, int color_map, int kind)
{
  FILE  *fp;
  char  fname[120];
  float zm = 1.0, xo = 0.0, yo = 0.0, x1, y1, x2, y2;
  int   zx, zy, mode;
  int   i, j, k, n;

  // 1. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    if (var.zoom_rate == 3) {
      for (i = 0; i < 2; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/9.0*(zx-1)/zm;
        yo += (float)(var.NY)/9.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
    else if (var.zoom_rate == 2) {
      for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/8.0*(zx-1)/zm;
        yo += (float)(var.NY)/8.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
  }

  // 2. �ؾȼ� ǥ��
  sprintf(fname, "/DATA/GIS/MAP/dat/AFS_%s_map%d.dat", var.map, kind);
  if ((fp = fopen(fname, "r")) != NULL) {
    while (fscanf(fp, "%d %d\n", &n, &mode) != EOF) {
      for (i = 0; i < n; i++) {
        fscanf(fp, "%f %f\n", &x2, &y2);
        x2 /= var.grid;
        y2 /= var.grid;

        if (var.zoom_level > 0) {
          x2 = zm*(x2-xo);
          y2 = zm*(y2-yo);
        }
        x2 *= ((float)(var.NI)/(float)(var.NX));
        y2 *= ((float)(var.NI)/(float)(var.NX));
        if (i > 0) {
          gdImageLine(im, (int)x1, var.GJ-(int)y1, (int)x2, var.GJ-(int)y2, color_map);
          if (kind == 4 && var.zoom_level >= 2) gdImageLine(im, (int)x1, var.GJ-(int)y1-1, (int)x2, var.GJ-(int)y2-1, color_map);
        }
        x1 = x2;
        y1 = y2;
      }
    }
    fclose(fp);
  }

  return 0;
}

/*=============================================================================*
 *  EUC-KR���ڿ��� UTF-8�� ��ȯ
 *=============================================================================*/
int euckr2utf(char *str, char *out)
{
    iconv_t convp;
    size_t  ileft, oleft;
    int     err, len = strlen(str);

    ileft = len;
    oleft = len * 2;

    convp = iconv_open("UTF-8", "euc-kr");
    err = iconv(convp, &str, &ileft, &out, &oleft);
    iconv_close(convp);

    return err;
}

/*=============================================================================*
 *  ���� ǥ��(�ѱ�ó��)
 *=============================================================================*/
int title_disp(gdImagePtr im, int color_lvl[])
{
  char   title[80], tm_fc_str[100], num_stn_str[10], tmp[50];
  char   title_utf[100];
  double font_size = 11.5;
  int    brect[8];
  int    YY, MM, DD, HH, MI;
  int    x, y, i, k;

  // 1. ���񿵿��� ���� ó��
  gdImageFilledRectangle(im, 0, 0, var.GI, TITLE_pixel, color_lvl[241]);

  // 2. ������
  if      (strcmp(var.stn_cd,"BRI") == 0) strcpy(title,"��ɵ�");
  else if (strcmp(var.stn_cd,"KWK") == 0) strcpy(title,"���ǻ�");
  else if (strcmp(var.stn_cd,"GDK") == 0) strcpy(title,"������");
  else if (strcmp(var.stn_cd,"GNG") == 0) strcpy(title,"����");
  else if (strcmp(var.stn_cd,"KSN") == 0) strcpy(title,"������");
  else if (strcmp(var.stn_cd,"JNI") == 0) strcpy(title,"����");
  else if (strcmp(var.stn_cd,"MYN") == 0) strcpy(title,"�����");
  else if (strcmp(var.stn_cd,"PSN") == 0) strcpy(title,"������");
  else if (strcmp(var.stn_cd,"GSN") == 0) strcpy(title,"����");
  else if (strcmp(var.stn_cd,"SSP") == 0) strcpy(title,"����");
  else if (strcmp(var.stn_cd,"IMJ") == 0) strcpy(title,"������");
  else if (strcmp(var.stn_cd,"GRS") == 0) strcpy(title,"������");
  else if (strcmp(var.stn_cd,"SBS") == 0) strcpy(title,"�ҹ��");
  else if (strcmp(var.stn_cd,"SDS") == 0) strcpy(title,"�����");
  else if (strcmp(var.stn_cd,"MHS") == 0) strcpy(title,"���Ļ�");
  else if (strcmp(var.stn_cd,"BSL") == 0) strcpy(title,"�񽽻�");
  else if (strcmp(var.stn_cd,"K03") == 0) strcpy(title,"Ȳ����");
  else if (strcmp(var.stn_cd,"K02") == 0) strcpy(title,"����");
  else if (strcmp(var.stn_cd,"K01") == 0) strcpy(title,"����");
  else if (strcmp(var.stn_cd,"RKSG") == 0) strcpy(title,"����(��)");
  else if (strcmp(var.stn_cd,"RKJK") == 0) strcpy(title,"����(��)");
  else if (strcmp(var.stn_cd,"KAN") == 0) strcpy(title,"����A");
  else if (strcmp(var.stn_cd,"KWJ") == 0) strcpy(title,"����A");
  else if (strcmp(var.stn_cd,"TAG") == 0) strcpy(title,"�뱸A");
  else if (strcmp(var.stn_cd,"SCN") == 0) strcpy(title,"��õA");
  else if (strcmp(var.stn_cd,"SAN") == 0) strcpy(title,"����A");
  else if (strcmp(var.stn_cd,"SWN") == 0) strcpy(title,"����A");
  else if (strcmp(var.stn_cd,"YCN") == 0) strcpy(title,"��õA");
  else if (strcmp(var.stn_cd,"WNJ") == 0) strcpy(title,"����A");
  else if (strcmp(var.stn_cd,"JWN") == 0) strcpy(title,"�߿�A");
  else  strcpy(title,var.stn_cd);
  strcat(title," ���̴�HSR ");

  for (i = 0; i < 100; i++)
    title_utf[i] = 0;
  euckr2utf(title, title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, font_size, 0.0, 5, (int)(font_size+5), title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, font_size, 0.0, 6, (int)(font_size+5), title_utf);

  // 3. �ð� ���ڿ�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(tm_fc_str, "%04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, MI);

  x = strlen(title)*8.6 + 10;
  gdImageString(im, gdFontLarge, x, 1, tm_fc_str, color_lvl[244]);
  gdImageString(im, gdFontLarge, x+1, 1, tm_fc_str, color_lvl[244]);

  // 5. ������ ������
  if (var.exist == 0) {
    gdImageString(im, gdFontLarge, var.NI/2-50, var.NJ/2-100, "No Data File", color_lvl[247]);
    gdImageString(im, gdFontLarge, var.NI/2-51, var.NJ/2-100, "No Data File", color_lvl[247]);
  }
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int legend_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  char   txt[20];
  float  dy = (float)(var.NJ)/(float)(var.num_color);
  int    YY, MM, DD, HH, MI;
  int    x, y, k;

  if (var.legend != 1) return 0;
  if (var.num_color <= 0) return -1;

  // 1. ���� ���� ǥ��
  if (strcmp(var.obs,"STN") == 0) {
    for (k = 0; k < var.num_color; k++) {
      y = TITLE_pixel + dy*k;
      gdImageFilledRectangle(im, var.NI, y, var.NI+8, y+dy, stn_color[k].color);
    }
  }
  else {
    for (k = 0; k < var.num_color; k++) {
      y = var.GJ - dy*k;
      gdImageFilledRectangle(im, var.NI, y-dy, var.NI+8, y, color_lvl[k]);
    }
  }
  gdImageRectangle(im, var.NI-1, TITLE_pixel, var.NI+8, var.GJ-1, color_lvl[242]);

  // 2. ���ʰ� ǥ��
  gdImageFilledRectangle(im, var.NI+9, 0, var.GI-1, var.GJ, color_lvl[241]);
  if (strcmp(var.obs,"EBH") == 0) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.1f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (strcmp(var.obs,"STN") == 0) {
    for (k = 0; k < NUM_STN_COLOR; k++) {
      y = TITLE_pixel + k*dy + 15;
      sprintf(txt, "%s", stn_color[k].stn_ko);
      //gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);

      for (i = 0; i < 30; i++)
        txt_utf[i] = 0;
      euckr2utf(txt, txt_utf);
      gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, font_size, 0.0, var.NI+12, y, txt_utf);
      //gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, font_size, 0.0, var.NI+12, y, txt_utf);
    }
  }
  else if (strcmp(var.color,"C7") == 0) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      if (data_lvl[k] < 0.1)
        sprintf(txt, "%.2f", data_lvl[k]);
      else if (data_lvl[k] < 2)
        sprintf(txt, "%.1f", data_lvl[k]);
      else
        sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      if (data_lvl[k] < 2)
        sprintf(txt, "%.1f", data_lvl[k]);
      else
        sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }

  // 3. ���� ���� ǥ��
  if (strcmp(var.obs,"EBH") == 0)
    strcpy(txt,"km");
  else if (strcmp(var.color,"C7") == 0)
    strcpy(txt,"cm/h");
  else
    strcpy(txt,"mm/h");

  if (strcmp(var.obs,"STN") != 0) {
    x = var.NI + 3;
    gdImageString(im, gdFontLarge, x, 4, txt, color_lvl[244]);
  }

  return 0;
}

/*=============================================================================*
 *  zd�� Ȯ�� ��ƾ (���밡��: �ݵ�� ������ X,Y ���� zd���� ������ �������� ��)
 *      Ȯ��� �������� sub 4-point ����� �⺻���� ���
 *  by ����ȯ (2006. 5. 22)
 *=============================================================================*/
int grid_zoom (
    float **g,      /* input -> output */
    int   nx,       /* [0:nx,0:ny] zd�� ������ �������� ��. */
    int   ny,
    int   zd,       /* Ȯ���� (2��,3�� ... ) */
    int   ox,       /* ���� �Ʒ� ������ X-��ǥ */
    int   oy,       /* ���� �Ʒ� ������ Y-��ǥ */
    float missing,  /* ���ϴ� �ڷ� ���� */
    int   mode      /* 0:����(X), 1:��������, 2:4������ */
)
{
    float x;
    int   i, j, k;

    // 1. Y ���� Ȯ��
    for (i = ox; i <= ox+nx/zd; i++) {
        for (k = 0, j = oy; j < oy*zd/(zd-1); j++, k += zd) g[k][i] = g[j][i];
        for (k = ny, j = oy+ny/zd; j >= oy*zd/(zd-1); j--, k -= zd) g[k][i] = g[j][i];
    }

    // 2. X ���� Ȯ��
    for (j = 0; j <= ny; j += zd) {
        for (k = 0, i = ox; i < ox*zd/(zd-1); i++, k += zd) g[j][k] = g[j][i];
        for (k = nx, i = ox+nx/zd; i >= ox*zd/(zd-1); i--, k -= zd) g[j][k] = g[j][i];
    }

    // 3. Y ���� ����
    for (i = 0; i <= nx; i += zd) {
        // 3.1. (0, zd) ���� ������ ��� : �������� ���
        if (mode > 0 && g[0][i] > missing && g[zd][i] > missing) {
            for (k = 1; k < zd; k++)
                g[k][i] = (g[0][i]*(float)(zd - k) + g[zd][i]*(float)k) / (float)zd;
        }
        else {
            for (k = 1; k < zd; k++) {
                if (k <= zd/2) g[k][i] = g[0][i];
                else           g[k][i] = g[zd][i];
            }
        }

        // 3.2. (ny-zd, ny) ���� ������ ��� : �������� ���
        if (mode > 0 && g[ny-zd][i] > missing && g[ny][i] > missing) {
            for (k = 1; k < zd; k++)
                g[ny-k][i] = (g[ny-zd][i]*(float)k + g[ny][i]*(float)(zd-k)) / (float)zd;
        }
        else {
            for (k = 1; k < zd; k++) {
                if (k < zd/2) g[ny-k][i] = g[ny][i];
                else          g[ny-k][i] = g[ny-zd][i];
            }
        }

        // 3.3. ������ (zd,ny-zd) ���� ������ ��� : �ؼ������� ��� (4-point)
        for (j = zd; j < ny-zd; j += zd) {
            for (k = 1; k < zd; k++) {
                if (mode > 0 && g[j][i] > missing && g[j+zd][i] > missing) {
                    x = (float)k / (float)zd;

                    if (mode == 2 && g[j-zd][i] > missing && g[j+zd*2][i] > missing)
                        g[j+k][i] = g[j][i] + x*(g[j+zd][i] - g[j][i] + (x-1.0)*0.25*(g[j-zd][i] - g[j][i] - g[j+zd][i] + g[j+zd*2][i]));
                    else
                        g[j+k][i] = g[j][i]*(1.0-x) + g[j+zd][i]*x;
                }
                else {
                    if (k <= zd/2) g[j+k][i] = g[j][i];
                    else           g[j+k][i] = g[j+zd][i];
                }
            }
        }
    }

    // 4. X ���� ����
    for (j = 0; j <= ny; j++) {
        // 4.1. (0, zd) ���� ������ ��� : �������� ���
        if (mode > 0 && g[j][0] > missing && g[j][zd] > missing) {
            for (k = 1; k < zd; k++)
                g[j][k] = (g[j][0]*(float)(zd - k) + g[j][zd]*(float)k) / (float)zd;
        }
        else {
            for (k = 1; k < zd; k++) {
                if (k <= zd/2) g[j][k] = g[j][0];
                else           g[j][k] = g[j][zd];
            }
        }

        // 4.2. (nx-zd, nx) ���� ������ ��� : �������� ���
        if (mode > 0 && g[j][nx-zd] > missing && g[j][nx] > missing) {
            for (k = 1; k < zd; k++)
                g[j][nx-k] = (g[j][nx-zd]*(float)k + g[j][nx]*(float)(zd-k)) / (float)zd;
        }
        else {
            for (k = 1; k < zd; k++) {
                if (k < zd/2) g[j][nx-k] = g[j][nx];
                else          g[j][nx-k] = g[j][nx-zd];
            }
        }

        // 4.3. ������ (zd,ny-zd) ���� ������ ��� : �ؼ������� ��� (4-point)
        for (i = zd; i < nx-zd; i += zd) {
            for (k = 1; k < zd; k++) {
                if (mode > 0 && g[j][i] > missing && g[j][i+zd] > missing) {
                    x = (float)k / (float)zd;

                    if (mode == 2 && g[j][i-zd] > missing && g[j][i+zd*2] > missing)
                        g[j][i+k] = g[j][i] + x*(g[j][i+zd] - g[j][i] + (x-1.0)*0.25*(g[j][i-zd] - g[j][i] - g[j][i+zd] + g[j][i+zd*2]));
                    else
                        g[j][i+k] = g[j][i]*(1.0-x) + g[j][i+zd]*x;
                }
                else {
                    if (k <= zd/2) g[j][i+k] = g[j][i];
                    else           g[j][i+k] = g[j][i+zd];
                }
            }
        }
    }
    return 0;
}

/*=============================================================================*
 *  Grid data Smoothing (by 1-2-1 Smoothing)
 *  by ����ȯ (1997. 3. 15)
 *=============================================================================*/
int grid_smooth (
    float **g,      /* input -> output  */
    int   nx,       /* ���� [0:nx,0:ny] */
    int   ny,
    float missing   /* ���ϴ� �ڷ� ���� */
)
{
    float  e[4], e1, e2;
    int    i, j;

    for (j = 0; j <= ny; j++) {
        e1 = g[j][0];
        e[0] = g[j][0];
        e[1] = g[j][1];

        for (i = 1; i < nx; i++) {
            e[2] = g[j][i+1];

            if (e[0] > missing && e[1] > missing && e[2] > missing)
                e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
            else if (e[0] > missing && e[1] <= missing && e[2] > missing)
                e2 = (e[0] + e[2]) * 0.5;
            else
                e2 = e[1];

            g[j][i-1] = e1;
            e1 = e2;
            e[0] = e[1];
            e[1] = e[2];
        }
        g[j][i-1] = e1;
    }

    for (i = 0; i <= nx; i++) {
        e1 = g[0][i];
        e[0] = g[0][i];
        e[1] = g[1][i];

        for (j = 1; j < ny; j++) {
            e[2] = g[j+1][i];

            if (e[0] > missing && e[1] > missing && e[2] > missing)
                e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
            else if (e[0] > missing && e[1] <= missing && e[2] > missing)
                e2 = (e[0] + e[2]) * 0.5;
            else
                e2 = e[1];

            g[j-1][i] = e1;
            e1 = e2;
            e[0] = e[1];
            e[1] = e[2];
        }
        g[j-1][i] = e1;
    }
    return 0;
}

/*******************************************************************************
 *
 *  ���� Ȯ�� (2�� Ȯ�븸 ����)
 *
 *******************************************************************************/
int grid_zooming(float **grid)
{
  int  zx, zy, zm = 1, ox = 0, oy = 0;
  int  mode, code, i, k;

  // 1. Ȯ��ø� ó��
  if (var.zoom_level == 0) return 0;

  // 2. Ȯ�� ��� (�������� �ʴ� ������)
  if (strcmp(var.obs,"ECHO") == 0)
    mode = 0;
  else
    mode = 0;

  // 3. ������ �ڷ� Ȯ��
  for (i = 0; i < 7; i++) {
    zx = var.zoom_x[i]-'0';
    zy = var.zoom_y[i]-'0';
    if (zx == 0 || zy == 0) break;

    ox = (zx-1)*var.NX/8;
    oy = (zy-1)*var.NY/8;
    code = grid_zoom(grid, var.NX, var.NY, var.zoom_rate, ox, oy, -90.0, mode);
  }
  return 0;
}

/*=============================================================================*
 *  ���� ���� ���� �б�
 *
 *      map : inp:������ ����
 *      nx  : out:�������� �������� (km)
 *      ny  : out:���Ϲ��� �������� (km)
 *      sx  : out:�������� ������ġ (km)
 *      sy  : out:���Ϲ��� ������ġ (km)
 *=============================================================================*/
int grid_map_inf(char *map, int *nx, int *ny, int *sx, int *sy)
{
    FILE  *fp;
    char  buf[1024], map_list[8], value[16];

    fp = fopen(MAP_INI_FILE,"r");
    if (fp == NULL) exit(-1);

    while (fgets(buf,1024,fp)) {
        if (buf[0] == '#') continue;
        getword(map_list, buf, ':');

        if ( !strcmp(map, map_list) ) {
            getword(value, buf, ':');  *nx = atoi(value);
            getword(value, buf, ':');  *ny = atoi(value);
            getword(value, buf, ':');  *sx = atoi(value);
            getword(value, buf, ':');  *sy = atoi(value);
            break;
        }
    }
    fclose(fp);

    return 0;
}
