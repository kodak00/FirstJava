/*******************************************************************************
**
**  ���̴� 3���� �ռ��ڷ��� �ܸ鵵 ǥ��
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.9.2)
**
********************************************************************************/
/*
http://rdr.kma.go.kr/cgi-bin/rdr/nph-rdr_r3d_rhi_img?tm=201809031600&obs=ECHO&vol=CZ&x1=500&y1=1000&x2=1500&y2=2000&size_y=400
rdr_r3d_echo new EXT CZ 2018 9 3 16 10
rdr_r3d_echo new EXT DR 2018 9 3 16 10
rdr_r3d_echo new EXT RH 2018 9 3 16 10
rdr_r3d_echo new EXT KD 2018 9 3 16 10
rdr_r3d_echo new EXT HC 2018 9 3 16 10

http://rdr.kma.go.kr/cgi-bin/rdr/nph-rdr_r3d_rhi_img?tm=201808240200&obs=ECHO&vol=CZ&x1=500&y1=1000&x2=1500&y2=1000&size_y=400
rdr_r3d_echo new EXT CZ 2018 8 24 2 10;
rdr_r3d_echo new EXT DR 2018 8 24 2 10;
rdr_r3d_echo new EXT RH 2018 8 24 2 10;
rdr_r3d_echo new EXT KD 2018 8 24 2 10;
rdr_r3d_echo new EXT HC 2018 8 24 2 10;
*/

#include "rdr_r3d_img.h"

//------------------------------------------------------------------------------
// ����ü�� ����ǥ
// ����ü ����
#define  NUM_HCI_COLOR  7
#define  NUM_HCI_DETAIL_COLOR  16

// ����ü �׷캰 ����ǥ
struct RDR_HCI_COLOR {
  int  hci;
  char hci_ko[10];
  int  color;
  int  R;
  int  G;
  int  B;
} hci_color[NUM_HCI_COLOR] = {
  {0,"����",    0,255,255,255},
  //{1,"�񰭼�",  0,102,255,102},
  {1,"�񰭼�",  0,210,210,210},
  {2,"����",    0,245,255,102},
  {3,"��",      0,255,102,255},
  {4,"����",    0,102,255,255},
  {5,"��",      0, 51,102,255},
  {6,"���",    0,255, 51,  0},
};

// ����ü �󼼺з���(NCAR) ����ǥ
struct RDR_HCI_DETAIL_COLOR {
  int  hci;
  char hci_ko[40];
  int  color;
  int  R;
  int  G;
  int  B;
} hci_detail_color[NUM_HCI_DETAIL_COLOR] = {
  { 0,"����",     0,255,255,255},
  { 1,"����",     0,204,255,204},
  { 2,"�̽���",   0,153,204,255},
  { 3,"���Ѻ�",   0,102,153,255},
  { 4,"�߰���",   0, 51,102,255},
  { 5,"���Ѻ�",   0, 51, 51,204},
  { 6,"���",     0,255,  0,  0},
  { 8,"��ڽζ�", 0,255,102,  0},
  { 7,"���/ ��", 0,255,153,153},
  { 9,"�ζ�/ ��", 0,255,204,204},
  {10,"�Ǽ�",     0,255,153,255},
  {11,"����",     0,102,255,255},
  {14,"���ð�",   0, 51,204,204},
  {12,"������", 0,245,255,  0},
  {13,"����",   0,255,204,  0},
  {50,"�񰭼�",   0,210,210,210},
};

//------------------------------------------------------------------------------
// ��� ������ ����ǥ
// ��� ���� ����
#define  NUM_HAIL_COLOR  7

// ��� ������ ����ǥ
struct RDR_HAIL_COLOR {
  int  hail;
  char hail_ko[10];
  int  color;
  int  R;
  int  G;
  int  B;
} hail_color[NUM_HAIL_COLOR] = {
  {0,"����",0,255,255,255},
  {1,"1km", 0,255, 51,  0},
  {2,"2km", 0,255,153, 51},
  {3,"3km", 0,  0,128,  0},
  {4,"4km", 0, 51,204, 51},
  {5,"5km", 0,102,255,102},
  {6,"5km", 0,153,255,204},
};

//------------------------------------------------------------------------------
// ������ ����ǥ
// ������
#define  NUM_STN_COLOR  18

// ����ǥ
struct RDR_STN_COLOR {
  char stn_cd[8];
  char stn_ko[20];
  int  color;
  int  R;
  int  G;
  int  B;
} stn_color[NUM_STN_COLOR] = {
  {"BRI","��ɵ�",  0, 255, 82,  0},
  {"IIA","��õ����",0,   0,255,255},
  {"KWK","���ǻ�",  0, 173,  7,255},
  {"GDK","������",  0,   0,213,  0},
  {"GNG","����",    0, 255,165,  0},
  {"KSN","������",  0, 238,238, 73},
  {"JNI","����",    0,  73,238,238},
  {"MYN","�����",  0,   0,172,255},
  {"PSN","������",  0, 105,252,105},
  {"GSN","����",    0, 218,135,255},
  {"SSP","����",    0, 204,170,  0},
  {"RKSG","����U",  0, 233,147,106},
  {"RKJK","����U",  0,   0,102,255},
  {"GRS","������",  0, 249,205,  0},
  {"SBS","�ҹ��",  0,  76, 78,177},
  {"SDS","�����",  0,   0,128,  0},
  {"MHS","���Ļ�",  0,  31, 33,157},
  {"BSL","�񽽻�",  0, 250,133,133}
};

struct INPUT_VAR  var;
struct STN_VAL  stn_data[MAX_STN];

struct RDR_R3D_HEAD  rdr_r3d_head;              // �ռ��ڷ� Header
struct RDR_CMP_STN_LIST  rdr_r3d_stn_list[48];  // �ռ��� ���̴� ���
unsigned short  **echo;   // 3���� �ռ��ڷ�
unsigned short  **g;      // ǥ���� �ܸ��ڷ�

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main()
{
  int   err = 0;
  float km_px;
  int   num_sm, i;

  // 1. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(20);

  printf("HTTP/1.0 200 OK\n");
  //printf("Content-type: text/plain\n\n");

  // 2. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    err = 1;
  }

  // 3. ���̴��ڷḦ ����
  if (rdr_r3d_rhi_get() < 0) err = 2;

  // 4. ���� ó��
  if (err > 0) {
    err_img(err);
    return 0;
  }

  // 7. �̹��� ���� �� ����
  rdr_r3d_rhi_img();

  // 8. �޸� �ݳ�
  free_smatrix2(echo, 0, (int)(rdr_r3d_head.ny-1), 0, (int)(rdr_r3d_head.nx-1));

  alarm(0);
  return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
  char *qs;
  char tmp[256], item[32], value[32], tm[30];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, i, j, x, y;

  // 1. ���� �ʱⰪ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "0");        // ����ð�
  strcpy(var.map, "HR");  // ���̴� ����
  var.zoom_level = 0;     // ��ü����
  var.zoom_rate = 2;      // 2�� Ȯ�밡 �⺻
  var.ZRa = 200;
  var.ZRb = 1.6;
  var.sms = 1;
  var.legend = 1;
  var.dir_mode = 0;

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"cmp")) strcpy(var.cmp, value);
    else if ( !strcmp(item,"qcd")) strcpy(var.qcd, value);
    else if ( !strcmp(item,"obs")) strcpy(var.obs, value);
    else if ( !strcmp(item,"vol")) strcpy(var.vol, value);
    else if ( !strcmp(item,"map")) strcpy(var.map, value);
    else if ( !strcmp(item,"color")) strcpy(var.color, value);
    else if ( !strcmp(item,"tm"))  strcpy(tm, value);
    else if ( !strcmp(item,"x1")) var.x1 = atoi(value);
    else if ( !strcmp(item,"y1")) var.y1 = atoi(value);
    else if ( !strcmp(item,"x2")) var.x2 = atoi(value);
    else if ( !strcmp(item,"y2")) var.y2 = atoi(value);
    else if ( !strcmp(item,"size_y")) var.size_y = atoi(value);
    else if ( !strcmp(item,"auto_man")) var.auto_man = value[0];
    else if ( !strcmp(item,"ZRa")) var.ZRa = atof(value);
    else if ( !strcmp(item,"ZRb")) var.ZRb = atof(value);
    else if ( !strcmp(item,"size")) var.size = atoi(value);
    else if ( !strcmp(item,"legend")) var.legend = atoi(value);
    else if ( !strcmp(item,"dir")) var.dir_mode = atoi(value);
  }

  // 3. �⺻�� ����
  strcpy(var.cmp,"R3D");
  var.grid = 0.5;
  var.ht_max = 10;  // km
  var.NX = 0;

  if (var.x1 > var.x2) {
    x = var.x1;  y = var.y1;
    var.x1 = var.x2;  var.y1 = var.y2;
    var.x2 = x;  var.y2 = y;
  }
  var.NY = 200;
  var.NX = sqrt((var.x1-var.x2)*(var.x1-var.x2) + (var.y1-var.y2)*(var.y1-var.y2))/var.grid;
  if      (var.NX <= 200) var.size_rate = 4;
  else if (var.NX <= 400) var.size_rate = 2;
  else                    var.size_rate = 1;

  var.size_x = var.NX*var.size_rate;
  if (var.size_y < 100) var.size_y = 600;

  // 4. ����ð� �� ���� �����ð� ����
  get_time(&iYY, &iMM, &iDD, &iHH, &iMI, &iSS);
  iseq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  var.seq_now = iseq;

  // 5. ��û�ð� ����
  if (strlen(tm) < 10 || var.auto_man == 'a')
    var.seq = iseq;
  else {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
    var.seq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  }
  var.seq = 5*(var.seq/5);

  // 6. ���� ���翩�� Ȯ��
  for (i = 0; i < 10; i++, var.seq -= 5) {
    if (rdr_r3d_file() >= 0) {
      break;
    }
  }
  return 0;
}

/*=============================================================================*
 *  3���� �ռ� ���ϸ�
 *=============================================================================*/
int rdr_r3d_file()
{
  FILE   *fp;
  struct stat st;
  char   qcd[8], vol[8];
  int    YY, MM, DD, HH, MI;
  int    code;

  // 1. �ռ� ���ϸ�
  if (strcmp(var.vol,"RN") == 0|| strcmp(var.vol,"SN") == 0)
    strcpy(vol, "CZ");
  else
    strcpy(vol, var.vol);

  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_%s_%s_%04d%02d%02d%02d%02d.bin.gz",
          RDR_R3D_DIR, YY, MM, DD, var.cmp, var.qcd, vol, YY, MM, DD, HH, MI);

  // 2. ���翩�� Ȯ��
  code = stat(var.fname, &st);
  if (code < 0 || st.st_size <= 0) return -1;
  return 0;
}

/*******************************************************************************
 *
 *  �ܸ鵵 �ڷ� �б�
 *
 *******************************************************************************/
int rdr_r3d_rhi_get()
{
  FILE   *fp;
  unsigned short *x, *y;
  float  dx, dy;
  int    stn_ok = 0, io_ok = 0;
  int    i, j, k, n;

  // 1. ���� ���� ���� Ȯ��
  if (rdr_r3d_file() < 0) return -1;
  if (strstr(var.obs,"STN")) stn_ok = 1;

  // 2. �ܸ鵵�� ��� Ȯ��
  x = svector2(0, var.NX);  dx = (float)(var.x2 - var.x1)/(float)(var.grid*var.NX);
  y = svector2(0, var.NX);  dy = (float)(var.y2 - var.y1)/(float)(var.grid*var.NX);

  for (i = 0; i <= var.NX; i++) {
    x[i] = var.x1/var.grid + (short)(dx*i);
    y[i] = var.y1/var.grid + (short)(dy*i);
  }
  g = smatrix2(0, COM_NZ, 0, var.NX);

  // 3. ���̴� �ռ��ڷ� �б�
  fp = gzopen(var.fname, "rb");
  if (fp != NULL) {
    // 3.1. ������� �б�
    gzread(fp, &rdr_r3d_head, sizeof(rdr_r3d_head));
    gzread(fp, rdr_r3d_stn_list, sizeof(rdr_r3d_stn_list));
    var.num_rdr_stn = rdr_r3d_head.num_stn;
    var.grid = (rdr_r3d_head.dxy)*0.001;
    echo = smatrix2(0, (int)(rdr_r3d_head.ny-1), 0, (int)(rdr_r3d_head.nx-1));

    // 3.2. ���� �б�
    for (k = 0; k < rdr_r3d_head.nz; k++) {
      for (j = 0; j < rdr_r3d_head.ny; j++) {
        gzread(fp, echo[j], (rdr_r3d_head.nx)*2);
      }

      for (i = 0; i <= var.NX; i++) {
        if (stn_ok)
          g[k][i] = (echo[y[i]][x[i]] & 0xF800) >> 11;
        else
          g[k][i] = echo[y[i]][x[i]] & 0x07FF;
      }
    }
    gzclose(fp);
  }
  else {
    io_ok = -1;
  }

  // 4. �ӽ� �迭 ����
  free_svector2(y, 0, var.NX);
  free_svector2(x, 0, var.NX);

  return io_ok;
}

/*******************************************************************************
 *
 *  ���̴� 3���� �ռ����� �ܸ鵵 �̹��� ���� �� ����
 *
 *******************************************************************************/
int rdr_r3d_rhi_img()
{
  gdImagePtr im;
  FILE  *fp;
  float data_lvl[256];
  int   color_lvl[256];

  // 1. �̹��� ���� ����
  var.NI = var.size_x;
  var.NJ = var.size_y;
  var.GI = var.NI + LEFT_pixel;
  if (var.legend == 1) var.GI += LEGEND_pixel;
  var.GJ = var.NJ + TITLE_pixel + TAIL_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_table(im, color_lvl, data_lvl);
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[240]);

  // 3. �ڷ� �׸���
  data_disp(im, color_lvl, data_lvl);

  // 4. �������� �׸���
  topo_disp(im, color_lvl);

  // 5. ���� �׸�
  title_disp(im, color_lvl);

  // 6. ���� �׸���
  legend_disp(im, color_lvl, data_lvl);

  // 7. XY�� �׸���
  xy_disp(im, color_lvl);
  gdImageRectangle(im, LEFT_pixel, TITLE_pixel, LEFT_pixel+var.NI, TITLE_pixel+var.NJ-1, color_lvl[242]);

  // 8. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);
  return 0;
}

/*=============================================================================*
 *  ����ǥ
 *=============================================================================*/
int color_table(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  FILE  *fp;
  float v1;
  char  color_file[120];
  int   R, G, B;

  // 1. ��󺯼��� ����ǥ ���� ����
  strcpy(color_file,COLOR_SET_DIR);
  if      (strcmp(var.vol,"RN") == 0) strcat(color_file,"color_rdr_RN.rgb");
  else if (strcmp(var.vol,"SN") == 0) strcat(color_file,"color_rdr_SN.rgb");
  else if (strcmp(var.vol,"CZ") == 0) strcat(color_file,"color_rdr_CZ.rgb");
  else if (strcmp(var.vol,"DR") == 0) strcat(color_file,"color_rdr_DR.rgb");
  else if (strcmp(var.vol,"RH") == 0) strcat(color_file,"color_rdr_RH.rgb");
  else if (strcmp(var.vol,"KD") == 0) strcat(color_file,"color_rdr_KD.rgb");

  // 2. ����ǥ ���ϰ� ������ �б�
  if (strstr(var.obs,"STN")) {
    var.num_color = NUM_STN_COLOR;
    for (var.num_color = 0; var.num_color < NUM_STN_COLOR; var.num_color++) {
      R = stn_color[var.num_color].R;
      G = stn_color[var.num_color].G;
      B = stn_color[var.num_color].B;
      stn_color[var.num_color].color = gdImageColorAllocate(im, R, G, B);
    }
  }
  else if (strcmp(var.vol,"HC") == 0) {
    for (var.num_color = 0; var.num_color < NUM_HCI_DETAIL_COLOR; var.num_color++) {
      R = hci_detail_color[var.num_color].R;
      G = hci_detail_color[var.num_color].G;
      B = hci_detail_color[var.num_color].B;
      hci_detail_color[var.num_color].color = gdImageColorAllocate(im, R, G, B);
    }
  }
  else {
    var.num_color = 0;
    if ((fp = fopen(color_file, "r")) != NULL) {
      while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
        color_lvl[var.num_color] = gdImageColorAllocate(im, R, G, B);
        data_lvl[var.num_color] = v1;
        var.num_color++;
        if (var.num_color > 119) break;
      }
      fclose(fp);
    }
  }

  // 4. ��Ÿ ����ǥ ����
  color_lvl[240] = gdImageColorAllocate(im, 180, 180, 180);   // ����1
  color_lvl[241] = gdImageColorAllocate(im, 255, 255, 255);   // ����2
  color_lvl[242] = gdImageColorAllocate(im, 30, 30, 30);      // ������
  color_lvl[243] = gdImageColorAllocate(im, 12, 28, 236);     // ����
  color_lvl[244] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  color_lvl[245] = gdImageColorAllocate(im, 240, 240, 240);
  color_lvl[246] = gdImageColorAllocate(im, 255, 0, 0);
  color_lvl[247] = gdImageColorAllocate(im, 0, 0, 255);
  color_lvl[248] = gdImageColorAllocate(im, 160, 160, 160);   // ����3
  color_lvl[249] = gdImageColorAllocate(im, 110, 110, 110);   // �ñ����
  color_lvl[250] = gdImageColorAllocate(im, 80, 80, 80);      // ��������

  return 0;
}

/*=============================================================================*
 *  �ڷ� ǥ��
 *=============================================================================*/
int data_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  float obs_mltp = rdr_r3d_head.data_scale;
  float obs_plus = rdr_r3d_head.data_minus;
  float dx = (float)(var.NX)/(float)(var.NI);
  float dy = (float)COM_NZ/(float)(var.NJ);
  float dd;
  float lvl[256], dbz1, rain1;
  short blank = BLANK1;
  int   list_num[NUM_STN_COLOR];
  int   stn_ok = 0, hci_ok = 0;
  int   color1, x, y, nd;
  int   x1, z1 = TITLE_pixel+var.NJ;
  int   i, j, k;

  // 1. ��ϰ� ����
  if (strstr(var.obs,"STN")) {
    for (k = 0; k < rdr_r3d_head.num_stn; k++) {
      list_num[k] = -1;
      for (i = 0; i < NUM_STN_COLOR; i++) {
        if (strstr(rdr_r3d_stn_list[k].stn_cd, stn_color[i].stn_cd) != NULL) {
          list_num[k] = i;
          break;
        }
      }
    }
    stn_ok = 1;
  }
  else if (strcmp(var.vol,"RN") == 0) {
    for (k = 0; k < var.num_color; k++) {
      rain1 = data_lvl[k];
      dbz_rain_conv(&dbz1, &rain1, 1);
      lvl[k] = dbz1*obs_mltp + obs_plus;
    }
  }
  else if (strcmp(var.vol,"HC") == 0) {
    for (k = 0; k < var.num_color; k++)
      lvl[k] = data_lvl[k];
    hci_ok = 1;
  }
  else {
    for (k = 0; k < var.num_color; k++)
      lvl[k] = data_lvl[k]*obs_mltp + obs_plus;
  }

  // 2. �̹��� ����
  for (j = 0; j < var.NJ; j++) {
    y = (int)(dy*j);
    if (y < 0 || y >= COM_NZ) continue;

    for (i = 0; i < var.NI; i++) {
      x = (int)(dx*i);
      if (x < 0 || x >= var.NX) continue;

      dd = (float)g[y][x];
      x1 = LEFT_pixel+i;

      if (stn_ok) {
        nd = (int)(dd + 0.1) - 1;
        if (nd >= 0 && nd < NUM_STN_COLOR) {
          if (list_num[nd] >= 0) {
            gdImageSetPixel(im, x1, z1-j, stn_color[list_num[nd]].color);
          }
        }
      }
      else if (hci_ok) {
        nd = (int)(dd - obs_plus + 0.1);
        for (k = 0; k < NUM_HCI_DETAIL_COLOR; k++) {
          if (nd == hci_detail_color[k].hci) {
            gdImageSetPixel(im, x1, z1-j, hci_detail_color[k].color);
            break;
          }
        }
      }
      else {
        if (dd > BLANK1){
          color1 = color_lvl[var.num_color-1];
          for (k = 0; k < var.num_color; k++) {
            if (dd <= lvl[k]) {
              color1 = color_lvl[k];
              break;
            }
          }
          gdImageSetPixel(im, x1, z1-j, color1);
        }
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  Z-R �����
 *     - mode : 0(dBZ->������), 1(������->dBZ)
 *=============================================================================*/
int dbz_rain_conv(float *dbz1, float *rain1, int mode)
{
  static int first = 0;
  static float za, zb;

  if (first == 0) {
    za = 0.1/var.ZRb;
    zb = log10(var.ZRa)/var.ZRb;
    first = 1;
  }

  if (mode == 0) {
    //*rain1 = (*dbz1*0.1 - log10(var.ZRa) )/var.ZRb;
    *rain1 = *dbz1*za - zb;
    *rain1 = pow(10.0, *rain1);
  }
  else if (mode == 1) {
    *dbz1 = 10.0 * log10( var.ZRa * pow(*rain1, var.ZRb) );
  }
  return 0;
}

/*=============================================================================*
 *  �������� ǥ��
 *=============================================================================*/
int topo_disp(gdImagePtr im, int color_lvl[])
{
  FILE   *fp;
  short  **topo;
  long   offset1 = (HB_SX-COM_SX)*2;
  long   offset2 = (HB_NX-COM_NX)*2 - offset1;
  float  dg = (float)(var.NX)/(float)(var.NI);
  float  dx = (float)(var.x2 - var.x1)/(float)(var.NX);
  float  dy = (float)(var.y2 - var.y1)/(float)(var.NX);
  float  dk;
  short  xx, yy, ht;
  int    x1, z1;
  int    i, j, k;

  // 1. ���� ����
  if ((fp = fopen(TOPO_FILE, "rb")) == NULL) return -1;

  // 2. �ش�(64byts) + �Ʒ��κ� skip
  fseek(fp, (long)((HB_SY-COM_SY)*(HB_NX+1)*2 + 64), SEEK_SET);
  topo = smatrix(0, COM_NY, 0, COM_NX);

  // 3. HR ������ �б�
  for (j = 0; j <= COM_NY; j++) {
    fseek(fp, offset1, SEEK_CUR);
    fread(topo[j], 2, COM_NX+1, fp);  // ���� 0.1m
    fseek(fp, offset2, SEEK_CUR);
  }
  fclose(fp);

  // 4. �ܸ鼱�� ���� ���� ��ġ�� ����Ͽ� ���� �����Ͽ� ǥ��
  for (k = 0; k < var.NI; k++) {  // �ܸ鼱 �̹��� �ȼ� ��ġ
    dk = dg*k;  // �ܸ鼱 ���� ���
    xx = (short)(var.x1 + dx*dk);   // 2�������� �ܸ鼱 ������ ��ġ
    yy = (short)(var.y1 + dy*dk);
    if (xx >= 0 && xx < COM_NX && yy >= 0 && yy <= COM_NY) {
      ht = (float)topo[yy][xx]*(float)(var.NJ)/100000.0;
      x1 = LEFT_pixel + k;
      z1 = TITLE_pixel+var.NJ;
      gdImageLine(im, x1, z1, x1, z1-ht, color_lvl[250]);
    }
  }

  // 5. �޸� ����
  free_smatrix(topo, 0, COM_NY, 0, COM_NX);
  return 0;
}

/*=============================================================================*
 *  EUC-KR���ڿ��� UTF-8�� ��ȯ
 *=============================================================================*/
int euckr2utf(char *str, char *out)
{
  iconv_t convp;
  size_t  ileft, oleft;
  int     err, len = strlen(str);

  ileft = len;
  oleft = len * 2;

  convp = iconv_open("UTF-8", "euc-kr");
  err = iconv(convp, &str, &ileft, &out, &oleft);
  iconv_close(convp);

  return err;
}

/*=============================================================================*
 *  ���� ǥ��(�ѱ�ó��)
 *=============================================================================*/
int title_disp(gdImagePtr im, int color_lvl[])
{
  char   title[80], tm_fc_str[100], num_stn_str[10], text[100], tmp[50];
  char   title_utf[100], str_utf[100];
  double font_size = 11.5;
  int    brect[8];
  int    YY, MM, DD, HH, MI;
  int    x, y, i, k;

  // 1. ���񿵿��� ���� ó��
  gdImageFilledRectangle(im, 0, 0, var.GI, TITLE_pixel, color_lvl[241]);

  // 2. ������
  strcpy(title, "���̴� R3D");
  if      (strcmp(var.qcd,"KMA") == 0) strcat(title, "(���û) ");
  else if (strcmp(var.qcd,"EXT") == 0) strcat(title, "(����) ");

  if      (strcmp(var.vol,"RN") == 0) strcat(title, "����");
  else if (strcmp(var.vol,"SN") == 0) strcat(title, "����");
  else strcat(title, var.vol);

  if (strstr(var.obs,"STN")) strcat(title,"(����)");

  for (i = 0; i < 100; i++)
    title_utf[i] = 0;
  euckr2utf(title, title_utf);
  x = LEFT_pixel + 5;
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, x, (int)(font_size+5), title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, x+1, (int)(font_size+5), title_utf);

  // 3. �ð� ���ڿ�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(tm_fc_str, "%04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, MI);

  x = LEFT_pixel + strlen(title)*8.8 + 10;
  gdImageString(im, gdFontLarge, x, 1, tm_fc_str, color_lvl[244]);
  gdImageString(im, gdFontLarge, x+1, 1, tm_fc_str, color_lvl[244]);

  // 6. Z/R ��� ǥ��
  if (strcmp(var.obs,"ECHO") == 0 && (strcmp(var.vol,"RN") == 0 || strcmp(var.vol,"SN") == 0)) {
    if (var.ZRa != 200 && var.ZRb != 1.6) {
      sprintf(text, "%.1f / %.1f", var.ZRa, var.ZRb);
      gdImageFilledRectangle(im, LEFT_pixel+1, TITLE_pixel+var.NJ-18, strlen(text)*9, TITLE_pixel+var.NJ-1, color_lvl[241]);
      gdImageString(im, gdFontLarge, LEFT_pixel+5, TITLE_pixel+var.NJ-17, text, color_lvl[244]);
    }
  }
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int legend_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  char   txt[20], txt_utf[30];
  double font_size = 8.0;
  int    brect[8];
  float  dy = (float)(var.NJ)/(float)(var.num_color);
  int    YY, MM, DD, HH, MI;
  int    color1;
  int    x, y, i, j, k;

  if (var.legend != 1) return 0;
  if (var.num_color <= 0) return -1;

  // 1. ���� ���� ǥ��
  x = LEFT_pixel + var.NI;
  if (strstr(var.obs,"STN")) {
    for (k = 0; k < var.num_color; k++) {
      y = TITLE_pixel + dy*k;
      gdImageFilledRectangle(im, x, y, x+8, y+dy, stn_color[k].color);
    }
  }
  else if (strcmp(var.vol,"HC") == 0) {
    for (k = 0; k <= var.num_color-1; k++) {
      y = TITLE_pixel + dy*k;
      gdImageFilledRectangle(im, x, y, x+8, y+dy, hci_detail_color[k].color);
    }
  }
  else {
    for (k = 0; k < var.num_color; k++) {
      y = TITLE_pixel + var.NJ - dy*k;
      gdImageFilledRectangle(im, x, y-dy, x+8, y, color_lvl[k]);
    }
  }
  gdImageRectangle(im, x-1, TITLE_pixel, x+8, TITLE_pixel+var.NJ-1, color_lvl[242]);

  // 2. ���ʰ� ǥ��
  gdImageFilledRectangle(im, x+9, 0, var.GI-1, TITLE_pixel+var.NJ, color_lvl[241]);
  if (strstr(var.obs,"STN")) {
    for (k = 0; k < NUM_STN_COLOR; k++) {
      for (j = 0; j <= 8; j += 8) {
        y = TITLE_pixel + k*dy + j/8*12 + 15;
        strncpy(txt, &(stn_color[k].stn_ko[j]), 8);

        for (i = 0; i < 30; i++) txt_utf[i] = 0;
        euckr2utf(txt, txt_utf);

        color1 = color_lvl[249];
        for (i = 0; i < rdr_r3d_head.num_stn; i++) {
          if (!strcmp(rdr_r3d_stn_list[i].stn_cd,stn_color[k].stn_cd)) {
            color1 = color_lvl[247];
            break;
          }
        }
        gdImageStringFT(im, &brect[0], color1, FONTTTF, font_size, 0.0, x+11, y, txt_utf);
      }
    }
  }
  else if (strcmp(var.vol,"HC") == 0) {
    font_size = 8.0;
    for (k = 0; k <= var.num_color-1; k++) {
      for (j = 0; j < strlen(hci_detail_color[k].hci_ko)-1; j += 8) {
        y = TITLE_pixel + dy*k + dy/4 + j/2*3 + 7;
        strncpy(txt, &(hci_detail_color[k].hci_ko[j]), 8);
        txt[8] = '\0';
        for (i = 0; i < 30; i++) txt_utf[i] = 0;
        euckr2utf(txt, txt_utf);
        gdImageStringFT(im, &brect[0], color_lvl[244], FONTTTF, font_size, 0.0, x+11, y, txt_utf);
      }
    }
  }
  else if (strcmp(var.vol,"RN") == 0 || strcmp(var.vol,"SN") == 0) {
    for (k = 0; k < var.num_color-1; k++) {
      y = TITLE_pixel + var.NJ - (k+1)*dy - 5;
      if (data_lvl[k] < 5)
        sprintf(txt, "%.1f", data_lvl[k]);
      else
        sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, x+12, y, txt, color_lvl[244]);
    }
  }
  else if (strcmp(var.vol,"RH") == 0) {
    for (k = 0; k < var.num_color-1; k++) {
      y = TITLE_pixel + var.NJ - (k+1)*dy - 5;
      sprintf(txt, "%.2f", data_lvl[k]);
      gdImageString(im, gdFontSmall, x+12, y, txt, color_lvl[244]);
    }
  }
  else if (strcmp(var.vol,"DZ") == 0 || strcmp(var.vol,"CZ") == 0 ||
           strcmp(var.vol,"VR") == 0 || strcmp(var.vol,"PH") == 0 ) {
    for (k = 0; k < var.num_color-1; k++) {
      y = TITLE_pixel + var.NJ - (k+1)*dy - 5;
      sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, x+12, y, txt, color_lvl[244]);
    }
  }
  else {
    for (k = 0; k < var.num_color-1; k++) {
      y = TITLE_pixel + var.NJ - (k+1)*dy - 5;
      sprintf(txt, "%.1f", data_lvl[k]);
      gdImageString(im, gdFontSmall, x+12, y, txt, color_lvl[244]);
    }
  }

  // 3. ���� ���� ǥ��
  if      (strcmp(var.vol,"RN") == 0) strcpy(txt,"mm/h");
  else if (strcmp(var.vol,"SN") == 0) strcpy(txt,"cm/h");
  else if (strcmp(var.vol,"CZ") == 0) strcpy(txt,"dBZ");
  else if (strcmp(var.vol,"DR") == 0) strcpy(txt,"dB");
  else if (strcmp(var.vol,"RH") == 0) strcpy(txt,"");
  else if (strcmp(var.vol,"KD") == 0) strcpy(txt,"deg/km");
  else if (strcmp(var.vol,"HC") == 0) strcpy(txt,"");

  gdImageString(im, gdFontLarge, x-3, 4, txt, color_lvl[244]);

  return 0;
}

/*=============================================================================*
 *  XY�� ǥ��
 *=============================================================================*/
int xy_disp(gdImagePtr im, int color_lvl[])
{
  char txt[20];
  int  ang_ok;
  int  dx, x, y, i, j, k;

  // Y�� ǥ��
  gdImageFilledRectangle(im, 0, 0, LEFT_pixel, var.GJ, color_lvl[241]);
  for (j = 0; j <= var.ht_max; j++) {
    sprintf(txt, "%2dkm", j);
    y = var.GJ - TAIL_pixel - (int)(j*(float)(var.NJ)/var.ht_max);
    gdImageString(im, gdFontLarge, 3, y-7, txt, color_lvl[244]);
    gdImageDashedLine(im, LEFT_pixel, y, LEFT_pixel+var.NI, y, color_lvl[248]);
  }

  // X�� ǥ��
  gdImageFilledRectangle(im, LEFT_pixel, var.GJ-TAIL_pixel, var.GI, var.GJ, color_lvl[241]);
  if      (var.NX <= 200) dx = 10;
  else if (var.NX <= 400) dx = 20;
  else if (var.NX <= 1000) dx = 50;
  else dx = 100;

  for (i = 0; i <= var.NX; i += dx*2) {
    sprintf(txt, "%dkm", i/2);
    x = LEFT_pixel + (int)(i*(float)(var.NI)/(float)(var.NX));
    gdImageString(im, gdFontLarge, x-5, TITLE_pixel+var.NJ+1, txt, color_lvl[244]);
    gdImageDashedLine(im, x, TITLE_pixel, x, TITLE_pixel+var.NJ, color_lvl[248]);
  }
  return 0;
}

/*=============================================================================*
 *  ����ü ����� ����ü ������ �߿䵵�� ���� ��з�
 *=============================================================================*/
short rdr_hci_num(short ec)
{
  short hci;

  switch (ec) {
    case 0:  hci = 0;  break;   // ������
    case 50: hci = 1;  break;   // �񰭼�
    case 12: hci = 2;  break;   // ����(���)
    case 13: hci = 2;  break;   // ����(����)
    case 10: hci = 3;  break;   // ��(�Ǽ�)
    case 14: hci = 4;  break;   // ��������(���ð�����)
    case 11: hci = 4;  break;   // ��������(����)
    case 9:  hci = 4;  break;   // ��������(�ζ���/��)
    case 1:  hci = 5;  break;   // ��(����)
    case 2:  hci = 5;  break;   // ��(�̽���)
    case 3:  hci = 5;  break;   // ��(���Ѻ�)
    case 4:  hci = 5;  break;   // ��(�߰���)
    case 5:  hci = 5;  break;   // ��(���Ѻ�)
    case 8:  hci = 6;  break;   // ���(�ζ���+�������)
    case 7:  hci = 6;  break;   // ���(��+���)
    case 6:  hci = 6;  break;   // ���
    default: hci = -1;
  }
  return hci;
}

/*******************************************************************************
 *
 *  �ڷᰡ �̻��� �ִ� ���, ���� �̹��� ���
 *
 *******************************************************************************/
int err_img(int err)
{
  gdImagePtr im;
  char  text[120], tmp[120];
  int   YY, MM, DD, HH, MI;
  int   color_lvl[16];
  int   x = 20, y = 20, i, j, k, n;

  // 1. �̹��� ���� ����
  var.NI = var.size_x;
  var.NJ = var.size_y;
  var.GI = LEFT_pixel + var.NI;
  if (var.legend == 1) var.GI += LEGEND_pixel;
  var.GJ = var.NJ + TITLE_pixel + TAIL_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_lvl[0] = gdImageColorAllocate(im, 240, 240, 240);   // ����
  color_lvl[1] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[0]);

  // 3. ���� �޽���
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(text, "TIME = %04d.%02d.%02d.%02d:%02d / err = %d", YY, MM, DD, HH, MI, err);
  gdImageString(im, gdFontLarge, x, y, text, color_lvl[1]);

  sprintf(text, "%s / %s / %s", var.cmp, var.qcd, var.obs);
  gdImageString(im, gdFontLarge, x, (y+=20), text, color_lvl[1]);

  sprintf(text, "(x1,y1) = (%d,%d) / (x2,y2) = (%d,%d)", var.x1, var.y1, var.x2, var.y2);
  gdImageString(im, gdFontLarge, x, (y+=20), text, color_lvl[1]);

  if (err == 2)
    sprintf(text, "FILE = %s (file is not found)", var.fname);
  else
    sprintf(text, "FILE = %s", var.fname);
  gdImageString(im, gdFontLarge, x, (y+=20), text, color_lvl[1]);

  // 4. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);

  return 0;
}
