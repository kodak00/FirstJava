/*******************************************************************************
**
**  ������ ���̴� HSR�ڷḦ �ռ��������� ��ȯ
**
**=============================================================================*
**
**   o �ۼ��� : ����ȯ (2018.4.7)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "rsl_wrc.h"
#include "nrutil.h"
#include "stn_inf.h"
#include "map_ini.h"
#include "rdr_cmp_ppi_header.h"
#include "rdr_hsr_stn_img.h"

#define  SAV_CMP_DIR    "/DATA/RDR/CMP"
#define  FTP_CMP_DIR    "/rdr/FTPD/RDR"
#define  RAW_UF_DIR     "/DATA/RDR/RAW"
#define  QCD_UF_DIR     "/DATA/RDR/QCD"
#define  HSR_UF_DIR     "/DATA/RDR/HSR"
#define  RDR_HSR_INI    "/home/rdr/REF/INI/rdr_HSR.ini"

#define  DEGRAD  3.1415927/180.0
#define  RADDEG  180.0/3.1415927

#define  BLANK1  -30000   /* No Area */
#define  BLANK2  -25000   /* No Data */
#define  BLANK3  -20000   /* Minimum Data */

//-----------------------------------------------------------------------------
// �ռ��ڷ��� ���ڿ��� (1152 km x 1440 km : 0.5 km ���ڰ���)
#define  NI  1152*2
#define  NJ  1440*2

//-----------------------------------------------------------------------------
// ���̴� �����ڷ� ���ڿ��� (1000.5 km x 1000.5 km : 500m ���ڰ���)
#define  NS  2000
int      MS;

extern struct INPUT_VAR var;
extern short  rdr_cmp[NJ+1][NI+1];     // �ռ��ڷ�

//-----------------------------------------------------------------------------

short  rdr_stn[NS+2][NS+2];     // ������ 0.5km �����ڷ�
Radar  *radar;
Volume *volume;
Sweep  *sweep;
Ray    *ray;
int rdr_cmp_grd(float, float, float);

/*******************************************************************************
 *
 *  1�� ������ ���̴� HSR �����ڷ� ����
 *
 *******************************************************************************/
int rdr_hsr_stn()
{
  Radar  *radar;
  Volume *volume;
  Sweep  *sweep1, *sweep2;
  Ray    *ray, *ray1, *ray2;
  char   fname[120];
  struct stat st;
  struct azed_parameter  rdr;
  struct lamc_parameter  map;
  double cs, ss, re1, alpha, s, r, ec1, tc1, ec2, tc2;
  float  az1, az2, az3, range, range_max;
  float  stn_lon, stn_lat, stn_ht;
  float  range_bin1, gate_size, elev;
  float  cx[4], cy[4];
  float  x1, y1, x2, y2;
  short  ec, tc, blank2s = BLANK2;
  short  az[3600];
  int    x_min, x_max, y_min, y_max;
  int    nbin_max, first, code;
  int    seq1, seq2;
  int    i, j, k, i1, i2, ia, ja, ja1, ja2, ja3, ja4, k1, k2, k3;

  // 1. UF ���� �б�
  code = rdr_HSR_file(stn_list[stn_num].seq, stn_list[stn_num].stn_cd, stn_list[stn_num].HSR, &st, fname);
  fprintf(fp_log, "%s:%s:", msg_ini, fname);
  if ((radar = RSL_uf_to_radar(fname)) == NULL) {
    fprintf(fp_log, "open error\n");
    return -1;
  }

  if (radar->v[3] == NULL || radar->v[43] == NULL) {
    fprintf(fp_log, "volume error\n");
    return -2;
  }
  if (radar->v[3]->sweep[0] == NULL || radar->v[3]->sweep[0] == NULL) {
    fprintf(fp_log, "sweep error\n");
    return -3;
  }
  fprintf(fp_log, "\n");

  // 2. �������� �ڷᰡ �ִ� �迭 ��ġ Ȯ��
  // 2.1. �ʱ�ȭ �� �ڷ� ����
  for (i = 0; i < 3600; i++)
    az[i] = -1;

  sweep1 = radar->v[3]->sweep[0];   // ���ڰ�
  sweep2 = radar->v[43]->sweep[0];  // ���� �ع߰�����

  // 2.2. ������ Ȯ��
  nbin_max = 0;
  range_max = 0;
  for (j = 0; j < sweep1->h.nrays; j++) {
    if ((ray = sweep1->ray[j]) == NULL) continue;

    // 2.2.1. �� ���۰Ÿ�(m), �ڷᰣ��(m)
    if (range_max < 10) {
      range_bin1 = ray->h.range_bin1;
      gate_size  = ray->h.gate_size;
      elev = 0;   // for HSR
    }

    // 2.2.2. �ִ� �ݰ�� ���� ���
    range = (ray->h.nbins)*(ray->h.gate_size) + ray->h.range_bin1;
    if (range_max < range) range_max = range;
    if (nbin_max < ray->h.nbins) nbin_max = ray->h.nbins;

    // 2.2.3. �������� �ڷ� ��ġ Ȯ��
    if (ray->h.beam_width == 0) ray->h.beam_width = 1.0;
    if (ray->h.azimuth < 0) ray->h.azimuth += 360;
    az1 = (ray->h.azimuth - 0.5*ray->h.beam_width) * 10;
    az2 = (ray->h.azimuth + 0.5*ray->h.beam_width) * 10;
    i1 = floor(az1);
    i2 = ceil(az2);
    if (i1 >= 0 && i2 < 3600) {
      for (i = i1; i <= i2; i++) {
        az3 = i;
        if (az3 >= az1 && az3 < az2) az[i] = j;
      }
    }
    else if (i1 < 0) {
      for (i = 0; i <= i2; i++) {
        az3 = i;
        if (az3 >= az1 && az3 < az2) az[i] = j;
      }
      for (i = 3600+i1-1; i < 3600; i++) {
        az3 = i;
        if (az3 >= az1+3600 && az3 < 3600) az[i] = j;
      }
    }
    else if (i2 >= 3600) {
      for (i = i1; i < 3600; i++) {
        az3 = i;
        if (az3 >= az1 && az3 < az2) az[i] = j;
      }
      for (i = 0; i <= i2-3600; i++) {
        az3 = i;
        if (az3 >= 0 && az3 < az2-3600) az[i] = j;
      }
    }
  }

  // 3. �ռ��� ���� ���� �ڷ�ó��
  // 3.1. ����Ʈ�� �浵, ����, ���� Ȯ��
  stn_lon = radar->h.lond + (radar->h.lonm + (radar->h.lons)/60.0)/60.0;
  stn_lat = radar->h.latd + (radar->h.latm + (radar->h.lats)/60.0)/60.0;
  stn_ht  = radar->h.height;

  // 3.2. ���� ���
  cs = cos(elev * DEGRAD);
  ss = sin(elev * DEGRAD);
  re1 = 4.0*(RE+stn_ht)/3.0;

  // 3.3. �ռ���� ���ؽð�
  seq1 = time2seq(2018, 3,  1, 0, 0, 'm');

  // 3.4. �̰����ڷ�� �ڷᰡ ������ �̰����������� ó��
  if (strcmp(stn_list[stn_num].stn_cd,"RKSG") == 0 || strcmp(stn_list[stn_num].stn_cd,"RKJK") == 0)
    blank2s = BLANK1;
  else
    blank2s = BLANK2;

  // 4. ����Ʈ�� �ռ� ������ ���� �� �簢�� ������ ���� ��� ���
  // 4.1. ����Ʈ ������
  rdr.Re    = (RE + stn_ht)*0.001;
  rdr.grid  = 1.0;
  rdr.slon  = stn_lon;
  rdr.slat  = stn_lat;
  rdr.olon  = stn_lon;
  rdr.olat  = stn_lat;
  rdr.xo    = 0;
  rdr.yo    = 0;
  rdr.first = 0;

  // 4.2. �ռ� ������ (B-map)
  map.Re    = RE*0.001;
  map.grid  = 0.5;
  map.slat1 = 30.0;
  map.slat2 = 60.0;
  map.olon  = 126.0;
  map.olat  = 38.0;
  map.xo    = 560.0 / map.grid;
  map.yo    = 840.0 / map.grid;
  map.first = 0;

  // 4.3. �簢�� ������ ���� ��� ���
  conv_cof(rdr, map, range_max, cx, cy, &x_min, &x_max, &y_min, &y_max);
  //printf("%s [%4d,%4d] [%4d,%4d]\n", stn_list[stn_num].stn_cd, x_min, x_max, y_min, y_max);

  // 5. �ռ� (�ռ������� ����Ʈ ������ ���ں��� ó��)
  for (j = y_min; j <= y_max; j++) {
    y2 = j;

    for (i = x_min; i <= x_max; i++) {
      x2 = i;

      // 5.1. ��Ÿ������� ���� ��ġ���� ���
      x1 = cx[0] + cx[1]*x2 + cx[2]*y2 + cx[3]*x2*y2;
      y1 = cy[0] + cy[1]*x2 + cy[2]*y2 + cy[3]*x2*y2;

      // 5.2. ����ǥ��� �̵��Ÿ� ���
      s = sqrt(x1*x1 + y1*y1)*1000;   // km -> m
      if (s >= range_max) continue;

      // 5.3. �� �浵�� �̵��Ÿ��� �׿� ���� �ڷ� �迭 ��ġ Ȯ��
      alpha = 1 - pow((double)(cs/sin(s/re1)), (double)(2.0));
      r = -(re1/alpha)*(sqrt(ss*ss - alpha) + ss);
      if (r >= range_max) continue;
      k = (int)((r - range_bin1)/gate_size);  // ������ ���ڼ�
      if (k < 0 || k >= nbin_max) continue;

      // 5.4. ���� ������ ��� �� �迭 ��ġ Ȯ��
      if (y1 > 0 || y1 < 0)
        az1 = atan2(x1, y1)*RADDEG;
      else
        az1 = 0;
      if (az1 < 0) az1 += 360;
      ia = (int)(az1*10);
      ja = az[ia];
      if (ja < 0 || ja >= sweep1->h.nrays) continue;

      // 5.5. �ش� ��ġ�� ���ڰ��� �ع߰����� Ȯ��
      first = 0;
      ec2 = -300;
      tc2 = -1;

      if      (r <  5000) { ja3 = 5; ja4 = 5; }
      else if (r <  7000) { ja3 = 3; ja4 = 3; }
      else if (r < 10000) { ja3 = 2; ja4 = 2; }
      else if (r < 15000) { ja3 = 1; ja4 = 2; }
      else if (r < 20000) { ja3 = 1; ja4 = 1; }
      else if (r < 38000) { ja3 = 0; ja4 = 1; }
      else                { ja3 = 0; ja4 = 0; }

      for (ja1 = ja-ja3; ja1 <= ja+ja4; ja1++) {
        ja2 = ja1;
        if (ja2 < 0) ja2 += sweep1->h.nrays;
        if (ja2 >= sweep1->h.nrays) ja2 -= sweep1->h.nrays;

        ray1 = sweep1->ray[ja2];
        ray2 = sweep2->ray[ja2];

        if (r < 100000)
          k3 = 1;
        else
          k3 = 1;

        for (k1 = k; k1 <= k+k3; k1++) {
          if (k1 < 0 || k1 >= nbin_max-1) continue;

          ec1 = ray1->h.f(ray1->range[k1]);
          tc1 = ray2->h.f(ray2->range[k1]);

          if (first == 0) {
            ec2 = ec1;
            tc2 = tc1;
            first = 1;
          }
          else {
            if (ec2 < ec1) {
              ec2 = ec1;
              tc2 = tc1;
            }
          }
        }
      }

      if (ec2 > 200.0 || ec2 < -100)
        ec = blank2s;
      else
        ec = (short)(ec2*100);

      if (tc2 > 20.0 || tc2 < 0)
        tc = blank2s;
      else
        tc = (short)(tc2*1000);

      // 5.7. �ռ�
      // 5.7.1. �ִ밪 �ռ�
      if (var.cmp == 2)
        rdr_cmp_grd_make_max(i, j, ec, tc);

      // 5.7.2. ���������� �ռ�
      else {
        if (var.seq < seq1)
          rdr_cmp_grd_make_min1(i, j, ec, tc);
        else
          rdr_cmp_grd_make_min2(i, j, ec, tc);
      }

    }
  }

  RSL_free_radar(radar);

  return 0;
}

/*=============================================================================*
 *  HSR ���ϸ��� ���� ���� Ȯ��
 *=============================================================================*/
int rdr_HSR_file(int seq, char *stn_cd, char *HSR, struct stat *st, char *fname)
{
  int    YY, MM, DD, HH, MI;
  int    size;
  int    code;

  // 1. �ð�Ȯ��
  seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  // 2. ���ϸ�
  if (strcmp(HSR,"SNQDM") == 0)
    sprintf(fname, "%s/%04d%02d/%02d/RDR_%s_HSR2_%04d%02d%02d%02d%02d.uf",
            HSR_UF_DIR, YY, MM, DD, stn_cd, YY, MM, DD, HH, MI);
  else
    sprintf(fname, "%s/%04d%02d/%02d/RDR_%s_HSR1_%04d%02d%02d%02d%02d.uf",
            HSR_UF_DIR, YY, MM, DD, stn_cd, YY, MM, DD, HH, MI);

  // 3. ���翩�� Ȯ��
  code = stat(fname, st);
  if (code < 0 || (*st).st_size <= 0)
    size = -1;
  else
    size = (*st).st_size;
  return size;
}

/*=============================================================================*
 *  1 Ray -> Griding
 *=============================================================================*/
int rdr_stn_ray2grd(stn_cd, rdr_ht, rl, elev)
  char  stn_cd[8];
  float rl[2], elev[2], rdr_ht;
{
  double tn1, tn2;
  float  angle[3], hs[2];
  float  range, cc, cr, cg, cs, s0, s1, s, r, ec1;
  short  ec, blank2s = BLANK2;
  int    MS1, area, ix, iy;
  int    i, j, k, i1, i2;

  // 1. �̰����ڷ�� �ڷᰡ ������ �̰����������� ó��
  if (strcmp(stn_cd,"RKSG") == 0 || strcmp(stn_cd,"RKJK") == 0)
    blank2s = BLANK1;
  else
    blank2s = BLANK3;

  // 2. ���� �� ��������
  angle[1] = ray->h.azimuth;
  if (strcmp(stn_cd,"IIA") == 0) angle[1] -= 7.53;   // �������� �ںϱ���
  if (angle[1] < 0.0) angle[1] += 360.0;

  area = ((int)angle[1]/45) % 8 + 1;

  if (angle[1] > 45.0) {
    angle[1] -= 45.0;
    angle[1] = fabs( angle[1] - ((int)angle[1]/90)*90 - 45.0 );
  }

  if (ray->h.beam_width == 0) ray->h.beam_width = 1.0;
  angle[0] = angle[1] - ray->h.beam_width - 0.1;
  angle[2] = angle[1] + ray->h.beam_width + 0.1;

  tn1 = tan(angle[0] * DEGRAD);
  tn2 = tan(angle[2] * DEGRAD);

  // 3. ���� �� ��ó��
  cc = 500;         // 500 m ���� ����
  range = (ray->h.nbins)*(ray->h.gate_size) + ray->h.range_bin1;
  MS1 = (int)(range/cc);
  if (MS1 > 1000) MS1 = 1000;
  if (MS < MS1) MS = MS1;

  cr = ray->h.range_bin1;
  cg = ray->h.gate_size;
  cs = cos(elev[1] * DEGRAD);

  // 4. ���
  for (j = 1; j <= MS1; j++) {
    i1 = (int)(tn1 * j + 0.95);
    i2 = (int)(tn2 * j - 0.05);

    if (i2 >= i1) {
      for (i = i1; i <= i2; i++) {
        s = cc * (sqrt(i*i + j*j) - 0.5);   // ������ �Ÿ�
        r = s / cs;                         // ����Ÿ�
        k = (int)((r - cr)/cg);             // ������ ���ڼ�

        if (k >= 0 && k < ray->h.nbins) {
          switch (area) {
            case 1:  iy = 1000 + j;  ix = 1000 + i;  break;
            case 2:  iy = 1000 + i;  ix = 1000 + j;  break;
            case 3:  iy = 1000 - i;  ix = 1000 + j;  break;
            case 4:  iy = 1000 - j;  ix = 1000 + i;  break;
            case 5:  iy = 1000 - j;  ix = 1000 - i;  break;
            case 6:  iy = 1000 - i;  ix = 1000 - j;  break;
            case 7:  iy = 1000 + i;  ix = 1000 - j;  break;
            case 8:  iy = 1000 + j;  ix = 1000 - i;
          }
          ec1 = ray->h.f(ray->range[k]);
          if (ec1 > 200.0 || ec1 < -100)
            ec = blank2s;
          else
            ec = (short)(ec1*100);

          if (rdr_stn[iy][ix] < ec) rdr_stn[iy][ix] = ec;
        }
      }
    }
  }
  return 0;
}

/*******************************************************************************
 *
 *  Radar data sum
 *
 *******************************************************************************/
int rdr_cmp_grd(float lon, float lat, float ht)
{
  float  cx[4], cy[4];
  float  xl, yl;
  short  e1;
  int    x_min, x_max, y_min, y_max;
  int    i, j, ia, ja;

  conv_cof(cx, cy, &x_min, &x_max, &y_min, &y_max, lon, lat, ht);

  for (j = y_min; j <= y_max; j++) {
    yl = j + 0.5;

    for (i = x_min; i <= x_max; i++) {
      xl = i + 0.5;
      ia = (int)(cx[0] + cx[1]*xl + cx[2]*yl + cx[3]*xl*yl);
      ja = (int)(cy[0] + cy[1]*xl + cy[2]*yl + cy[3]*xl*yl);

      if (ia >= 0 && ia <= NS && ja >= 0 && ja <= NS) {
        e1 = rdr_stn[ja][ia];
        if (e1 > rdr_cmp[j][i]) rdr_cmp[j][i] = e1;
      }
    }
  }
  return 0;
}

/*******************************************************************************
 *  ��ǥ��ȯ ��� ���
 *******************************************************************************/
int conv_cof(rdr, map, range_max, cx, cy, x_min, x_max, y_min, y_max)
  struct azed_parameter  rdr;
  struct lamc_parameter  map;
  float  range_max;
  float  cx[4], cy[4];
  int    *x_min, *x_max, *y_min, *y_max;
{
  float  xl[4], yl[4], xa[4], ya[4];
  float  lon, lat;
  float  t1, t2;
  int  i, j;

  // ����Ʈ map �������� �ױ����� ��ǥ
  xa[0] = -range_max*0.001;
  ya[0] = -range_max*0.001;
  xa[1] = range_max*0.001;
  ya[1] = -range_max*0.001;
  xa[2] = range_max*0.001;
  ya[2] = range_max*0.001;
  xa[3] = -range_max*0.001;
  ya[3] = range_max*0.001;

  // �ռ� map���� �ش�Ǵ� ��ǥ
  for (i = 0; i < 4; i++) {
    azedproj(&lon, &lat, &xa[i], &ya[i], 1, &rdr);
    lamcproj_ellp(&lon, &lat, &xl[i], &yl[i], 0, &map);
  }

  // �ռ� map������ ����
  *x_min = 99999;
  *x_max = -99999;
  *y_min = 99999;
  *y_max = -99999;

  for (i = 0; i < 4; i++) {
    if (*x_min > (int)xl[i]) *x_min = (int)xl[i];
    if (*x_max < (int)xl[i]) *x_max = (int)xl[i];
    if (*y_min > (int)yl[i]) *y_min = (int)yl[i];
    if (*y_max < (int)yl[i]) *y_max = (int)yl[i];
  }
  if (*x_min <  0) *x_min = 0;
  if (*x_max > NI) *x_max = NI;
  if (*y_min <  0) *y_min = 0;
  if (*y_max > NJ) *y_max = NJ;

  // �ռ� map���� ����Ʈ map���� ��ȯ��� ���
  matrix_cal(xa, xl, yl, cx);
  matrix_cal(ya, xl, yl, cy);

  return 0;
}

/*=============================================================================*
 *  ��� ���
 *=============================================================================*/
int matrix_cal(a, xl, yl, c)
  float a[4], xl[4], yl[4], c[4];
{
  float  mm[4][4], d;
  int  indx[4];
  int  i, j;

  for (j = 0; j < 4; j++) {
    mm[j][0] = 1.0;
    mm[j][1] = xl[j];
    mm[j][2] = yl[j];
    mm[j][3] = xl[j] * yl[j];
    c[j] = a[j];
  }

  ludcmp(mm,4,indx,&d);
  lubksb(mm,4,indx,c);

  return 0;
}

/*=============================================================================*
 *  < LU decomposition >            from  Numerical Recips
 *=============================================================================*/
int   lubksb(a,n,indx,b)
float a[4][4],b[4];
int   n,*indx;
{
  int  i,ii=-1,ip,j;
  float  sum;

  for (i=0;i<n;i++) {
    ip=indx[i];
    sum=b[ip];
    b[ip]=b[i];
    if (ii >= 0)
      for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
    else if (sum) ii=i;
    b[i]=sum;
  }
  for (i=n-1;i>=0;i--) {
    sum=b[i];
    for (j=i+1;j<n;j++) sum -= a[i][j]*b[j];
    b[i]=sum/a[i][i];
  }
  return 0;
}

/*=============================================================================*
 *  < LU decomposition >            from  Numerical Recips
 *=============================================================================*/
#define TINY 1.0e-20;

int   ludcmp(a,n,indx,d)
float a[4][4];
int   n,*indx;
float *d;
{
  int  i,imax,j,k;
  float  big,dum,sum,temp;
  float  vv[8];

  *d=1.0;
  for (i=0;i<n;i++) {
    big=0.0;
    for (j=0;j<n;j++) {
      if ((temp=fabs(a[i][j])) > big) big=temp;
    }
    if (big == 0.0) printf("Singular matrix in routine LUDCMP\n");
    vv[i]=1.0/big;
  }
  for (j=0;j<n;j++) {
    for (i=0;i<j;i++) {
      sum=a[i][j];
      for (k=0;k<i;k++) sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
    }
    big=0.0;
    for (i=j;i<n;i++) {
      sum=a[i][j];
      for (k=0;k<j;k++)
        sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
      if ( (dum=vv[i]*fabs(sum)) >= big) {
        big=dum;
        imax=i;
      }
    }
    if (j != imax) {
      for (k=0;k<n;k++) {
        dum=a[imax][k];
        a[imax][k]=a[j][k];
        a[j][k]=dum;
      }
      *d = -(*d);
      vv[imax]=vv[j];
    }
    indx[j]=imax;
    if (a[j][j] == 0.0) a[j][j]=TINY;
    if (j != n-1) {
      dum=1.0/(a[j][j]);
      for (i=j+1;i<n;i++) a[i][j] *= dum;
    }
  }
  return 0;
}

/*******************************************************************************
 *
 *  �ռ��� ���̴��ڷ� Smoothing
 *
 *******************************************************************************/
int rdr_cmp_sm()
{
  short  *p, d1, d2, p1, p2, p3;
  int  i, j;

  for (j = 0; j <= NJ; j++) {
    d1 = rdr_cmp[j][0];
    p = &(rdr_cmp[j][1]);

    for (i = 1; i < NI; i++, p++) {
      if (*(p-1) > BLANK3 && *p > BLANK3 && *(p+1) > BLANK3)
        d2 = (short)((float)(*(p-1) + *p*2 + *(p+1))*0.25);
      else if (*(p-1) > BLANK3 && *p <= BLANK3 && *(p+1) > BLANK3)
        d2 = (short)((float)(*(p-1) + *(p+1)) * 0.5);
      else
        d2 = *p;

      *(p-1) = d1;
      d1 = d2;
    }
  }

  for (i = 0; i <= NI; i++) {
    d1 = rdr_cmp[0][i];
    p1 = d1;
    p2 = rdr_cmp[1][i];

    for (j = 1; j < NJ; j++) {
      p3 = rdr_cmp[j+1][i];
      if (p1 > BLANK3 && p2 > BLANK3 && p3 > BLANK3)
        d2 = (short)((float)(p1 + 2*p2 + p3)*0.25);
      else if (p1 > BLANK3 && p2 <= BLANK3 && p3 > BLANK3)
        d2 = (short)((float)(p1 + p2) * 0.5);
      else
        d2 = p2;

      rdr_cmp[j-1][i] = d1;
      d1 = d2;
      p1 = p2;
      p2 = p3;
    }
  }
  return 0;
}
