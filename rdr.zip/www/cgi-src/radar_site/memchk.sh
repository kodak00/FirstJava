#!/bin/sh 

export QUERY_STRING="DATE=201610231410&P_TYPE=PPI&SITE_NAME=BRI&D_TYPE=RN&CAPPI_ALT=1&SWEEP_NO=0"
valgrind --leak-check=yes --show-reachable=yes --log-file=mem.log ./radar_site_map >/dev/null
