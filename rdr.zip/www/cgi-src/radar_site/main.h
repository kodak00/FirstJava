/* ================================================================================ */
//
// 2016.07.29
//
// SnK : Choi Hyun-Jun
//
/* ================================================================================ */

#ifndef MAIN_H
#define MAIN_H

// DEFINE FOR ATOM7
#define IS_SWAP 1
#define HT_SIZE 4
#define SITENAME_LENGTH 8
#define DATE_LENGTH 6
#define HCPPI_ARRAY_SIZE 1000
#define HC_14   15
#define HC_7    8

#define MAX_HCPPI_SWEEPS 12
#define ZHH_RAW_INDEX 0
#define ZDR_RAW_INDEX 1
#define ZHH_COR_INDEX 2
#define ZDR_COR_INDEX 3
#define PDP_INDEX 4
#define RHV_INDEX 5
#define KDP_INDEX 6
#define ID_INDEX 7
#define RZHH_RAW_INDEX 8
#define RZHH_COR_INDEX 9
#define RKDP_INDEX 10
#define RDSD_INDEX 11

typedef struct
{
    // PARAM
    char    m_szSiteName[MAX_STR];
    char    m_szInputFileName[MAX_STR];
    char    m_szDate[MAX_STR];
    char    m_szDataType[MAX_STR];
    char    m_szProductType[MAX_STR];
    char    m_szQC_Type[MAX_STR];
    float   m_fLU_lon;
    float   m_fLU_lat;
    float   m_fRL_lon;
    float   m_fRL_lat;
    float   m_fCT_lon;
    float   m_fCT_lat;
    int     m_nMapLevel;
    int     m_nImgXdim;
    int     m_nImgYdim;
    float   m_fImgGridKm;
    struct  tm m_tFileTime;
    struct  tm m_tDataTime;
    int     m_nColorType;
    int     m_nSmooth;
    int     m_nSweepNo;
    float   m_fCappi_Alt;
    int     m_nUnitBar;
    float   m_fZr_A;
    float   m_fZr_B;
    // added by khbaek - 20180417
    int     m_nUF_Flag;
    int     m_nGZ_Flag;
} st_Option;

typedef struct
{
    float   m_fSiteLon;
    float   m_fSiteLat;
    int     m_nSiteXdim;
    int     m_nSiteYdim;
    int     m_nGateSize;
    int     m_nBinCount;
    float   m_fMaxRange;
    float   m_fSiteGridKm;
    float   m_fAzimuthCorrection;
    float   m_fNyqVel;
    char    m_szInfoDataType[MAX_STR][3];
    float   m_szInfoElv[MAX_STR];
    //khbaek 20180508 (HCI)
    float   m_fSiteAlt;
    float   m_rgfElev[HCPPI_ARRAY_SIZE];
} st_Site;

typedef struct
{
    float   m_fSiteLon;
    float   m_fSiteAlt;
    float   m_fSiteLat;
    int     m_nSiteXdim;
    int     m_nSiteYdim;
    int     m_nGateSize;
    int     m_nBinCount;
    float   m_fMaxRange;
    float   m_fSiteGridKm;
    float   m_rgfElev[HCPPI_ARRAY_SIZE];
    float   m_fAzimuthCorrection;
    float   m_fNyqVel;
} st_Atom_Site;

typedef struct
{
    char    m_szSiteName[SITENAME_LENGTH+1];
    int     m_rgnDate[DATE_LENGTH];
    int     m_nSweeps;
    int     m_nRays;
    float   m_fFixAng;
    float   m_rgfEld[HCPPI_ARRAY_SIZE];
    float   m_rgfAzmd[HCPPI_ARRAY_SIZE];
    float   m_fRan_1st_Gate;
    float   m_fResol_Gate;
    int     m_nRay;
    int     m_nGate;
} HCPPI_HEAD;

typedef struct
{
    HCPPI_HEAD  h;
    int         **m_nId;
} HCPPI_SWEEP;

typedef struct
{
    int         m_nSweeps;
    HCPPI_SWEEP *m_pSweep;
}HCPPI;

extern float**      g_pSiteData;
extern float**      g_pImgData;
extern st_Option    g_option;
extern st_Site      g_site;


//oskim 20180202

#define SITENAME_LENGTH 8
#define DATE_LENGTH 6
#define MAX_BIN 1500
#define MAX_RAY 1000
#define MAX_GATE 1500
#define MAX_SWEEP 17

#pragma pack(push,1)
typedef struct {
   char szRadar[SITENAME_LENGTH+1];
   float latitude;
   float longitude;
   float height;
   unsigned short YYYY;
   unsigned char MM;
   unsigned char DD;
   unsigned char HH;
   unsigned char MI;
   unsigned char SS;
   short Nsweeps;
   unsigned char dummy[32];
} HCI_Main_HEADER;

typedef struct {
   short sweepn;
   float sw_fix_angle;
   float resolution_gate;
   float first_gate;
   short Nray;
   short Ngate;
   float *azimuth;
   unsigned char dummy[32];
} HCI_Sweep_HEADER;

typedef struct {
   HCI_Sweep_HEADER h;
   char **data;
} HCI_Sweeps;
#pragma pack(pop)

typedef struct {
   HCI_Main_HEADER h;
   HCI_Sweeps *s;
} HCI;

#endif

