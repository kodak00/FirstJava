/* ================================================================================ */
//
// GIS 우하단 사이트 영상 표출 소스
//
// 2016.07.11 최초작성 : Kim Jung-Jin
//
// 2016. 11. 24 수정 : Choi Hyun-Jun
//
/* ================================================================================ */
// INCLUDE

#include <pthread.h>

#include "cgi_site_common.h"

#include "cgi_cmm_util.h"
#include "cgi_cmm_color.h"
#include "cgi_cmm_map_ini.h"

#include "cgi_site_uf.h"
#include "cgi_site_data.h"
#include "cgi_site_calc.h"
#include "cgi_site_draw.h"
#include "cgi_site_smooth.h"

#include "main.h"
#include "disp.h"
#include "disp_atom7.h"
#include "parameter.h"

/* ================================================================================ */
// GLOBAL

float**         g_pSiteData     = NULL;
float**         g_pImgData      = NULL;

st_Option       g_option;
st_Site         g_site;

//oskim 20171204
// 20171116 대기수상체 자료구조변경
// 대기수상체분류(14종) - 내부에 id 데이터만 존재
// 대기수상체분류(7종)  - 내부에 id 데이터만 존재, TDPPI 파일사용안함, 총6종만 표시됨
int         g_bOldFile  = 1;    //1: Old File, 0: New File

/* ================================================================================ */
// FUNCTION PROTO



/* ================================================================================ */
// LOCAL FUNCTION

static void fnInitProc(void)
{
    memset(&g_option, 0x00, sizeof(st_Option));
    memset(&g_site,   0x00, sizeof(st_Site));
}

static void fnInitOption(void)
{
    g_option.m_nImgXdim = 513;
    g_option.m_nImgYdim = 513;
    g_option.m_fImgGridKm = 1.0; // GNG 1.1

    if((strcmp(g_option.m_szSiteName, "K01") == 0)||
        (strcmp(g_option.m_szSiteName, "K02") == 0)||
        (strcmp(g_option.m_szSiteName, "K03") == 0))
            g_option.m_fImgGridKm = 0.4;
    if(strcmp(g_option.m_szSiteName, "GNG") == 0)
        g_option.m_fImgGridKm = 1.1;

    if(strcmp(g_option.m_szSiteName, "IIA") == 0)
        g_site.m_fAzimuthCorrection = -7.53;
    else
        g_site.m_fAzimuthCorrection = 0.0;

    sprintf(g_option.m_szQC_Type, "%s", "NOQC");


    if(strcmp(g_option.m_szProductType, "CAPPI") != 0 &&
       strcmp(g_option.m_szProductType, "PPI")   != 0 &&
       strcmp(g_option.m_szProductType, "ATOM7") != 0)
        sprintf(g_option.m_szProductType, "CAPPI");
}

static int fnSetInputFileName(void)
{
    int  nSetTime               = 0;
    int  nSix_Hour              = 360;
    char szFileName[MAX_STR]    = {0,};
    char szPath[MAX_STR]        = {0,};
    char szQC[MAX_STR]          = {0,};
    struct tm CurFileTime;

    memset(&CurFileTime, 0, sizeof(CurFileTime));

    if(strcmp(g_option.m_szProductType, "CAPPI") == 0 || strcmp(g_option.m_szProductType, "PPI") == 0)
    {
        if(strcmp(g_option.m_szQC_Type, "NOQC") == 0)
        {
      	    sprintf(szPath, "%s", "RAW");
            sprintf(szQC, "%s", "");
                 sprintf(szFileName, "/DATA/RDR/%s/%%Y%%m/%%d/RDR_%s%s_%%Y%%m%%d%%H%%M.uf", szPath, g_option.m_szSiteName, szQC);
             CurFileTime = g_option.m_tFileTime;
        }
        else if(strcmp(g_option.m_szQC_Type, "FQC") == 0)
        {
            sprintf(szPath, "%s", "QCD");
            sprintf(szQC, "%s", "FQC");
            sprintf(szFileName, "/DATA/RDR/%s/%%Y%%m/%%d/RDR_%s_%s_%%Y%%m%%d%%H%%M.uf", szPath, g_option.m_szSiteName, szQC);
            CurFileTime = g_option.m_tFileTime;
        }
 
        for(nSetTime = 0; nSetTime < nSix_Hour; nSetTime++)
        {
            strftime(g_option.m_szInputFileName, sizeof(g_option.m_szInputFileName), szFileName, &CurFileTime);
            if(!access(g_option.m_szInputFileName, 0))
            {
                break;
            }
            CurFileTime = fnGetIncMin(CurFileTime, -1);
        }
    }

    if (strcmp(g_option.m_szProductType, "HSR") == 0)
    {
        memset(&CurFileTime, 0, sizeof(CurFileTime));
        sprintf(szPath, "%s", "HSR");
        sprintf(szQC, "%s", "");
        
	if (strcmp(g_option.m_szSiteName, "GNG") == 0 || strcmp(g_option.m_szSiteName, "KSN") == 0)
        {
            sprintf(szFileName, "/DATA/RDR/%s/%%Y%%m/%%d/RDR_%s%s_HSR1_%%Y%%m%%d%%H%%M.uf", szPath, g_option.m_szSiteName, szQC);
            CurFileTime = g_option.m_tFileTime;
        }
        else
        {
            sprintf(szFileName, "/DATA/RDR/%s/%%Y%%m/%%d/RDR_%s%s_HSR2_%%Y%%m%%d%%H%%M.uf", szPath, g_option.m_szSiteName, szQC);
            CurFileTime = g_option.m_tFileTime;
        }

        fprintf(stderr,"FileName : [%s]\n",   szFileName);
        for(nSetTime = 0; nSetTime < nSix_Hour; nSetTime++)
        {
            strftime(g_option.m_szInputFileName, sizeof(g_option.m_szInputFileName), szFileName, &CurFileTime);
            if(!access(g_option.m_szInputFileName, 0))
            {
                break;
            }
            CurFileTime = fnGetIncMin(CurFileTime, -1);
        }

    }

    if (strcmp(g_option.m_szProductType, "ATOM7") == 0)
    {
        //khbaek 20180503
        //  - GZ, UF 모두 읽을 수 있도록 수정
        //  - UF를 우선적으로 읽고 UF 없는 경우 GZ 읽음
        //
        //  UF 먼저 시도
        memset(&CurFileTime, 0, sizeof(CurFileTime));
        sprintf(szPath, "%s", "HCI");
        sprintf(szQC, "%s", "");

        sprintf(szFileName, "/DATA/RDR/%s/%%Y%%m/%%d/RDR_%s_HCI_%%Y%%m%%d%%H%%M.uf", szPath, g_option.m_szSiteName);
        CurFileTime = g_option.m_tFileTime;
        fprintf(stderr,"FileName : [%s]\n",   szFileName);
        for(nSetTime = 0; nSetTime < nSix_Hour; nSetTime++)
        {
            if (g_option.m_nUF_Flag == 0)
            {
                strftime(g_option.m_szInputFileName, sizeof(g_option.m_szInputFileName), szFileName, &CurFileTime);
                strftime(g_option.m_szDate, sizeof(g_option.m_szDate), "%Y%m%d%H%M", &CurFileTime);

                if (!access(g_option.m_szInputFileName, 0))
                {
                    g_option.m_nUF_Flag = 1;
                    break;
                }
                else
                {
                    g_option.m_nUF_Flag = 0;
                }
            }
        }
        
        //oskim 20171204
        //New File 먼저 시도
        //khbaek 20180503
        //UF 없으면 New File 시도
        if (g_option.m_nUF_Flag == 0)
        {
            memset(&CurFileTime, 0, sizeof(CurFileTime));
            sprintf(szFileName, "/DATA/RDR/%s/%%Y%%m/%%d/RDR_%s_HCPPI_%%Y%%m%%d%%H%%M.gz", szPath, g_option.m_szSiteName);
            CurFileTime = g_option.m_tFileTime;

            for(nSetTime = 0; nSetTime < nSix_Hour; nSetTime++)
            {
                strftime(g_option.m_szInputFileName, sizeof(g_option.m_szInputFileName), szFileName, &CurFileTime);
                strftime(g_option.m_szDate, sizeof(g_option.m_szDate), "%Y%m%d%H%M", &CurFileTime);

                if(!access(g_option.m_szInputFileName, 0))
                {
                    //신규파일 존재
                    g_option.m_nGZ_Flag = 1;
                    g_bOldFile = 0;
                    break;
                }

                CurFileTime = fnGetIncMin(CurFileTime, -1);
            }


            //New 파일이 없으면, Old File 시도
            if(g_bOldFile == 1)
            {
                memset(&CurFileTime, 0, sizeof(CurFileTime));
                sprintf(szFileName, "/DATA/RDR/%s/%%Y%%m/%%d/RDR_%s_HCPPI_%%Y%%m%%d%%H%%M.gz", szPath, g_option.m_szSiteName);
                CurFileTime = g_option.m_tFileTime;

                for(nSetTime = 0; nSetTime < nSix_Hour; nSetTime++)
                {
                    strftime(g_option.m_szInputFileName, sizeof(g_option.m_szInputFileName), szFileName, &CurFileTime);
                    strftime(g_option.m_szDate, sizeof(g_option.m_szDate), "%Y%m%d%H%M", &CurFileTime);

                    if(!access(g_option.m_szInputFileName, 0))
                    {
                        g_option.m_nGZ_Flag = 1;
                        break;
                    }
                    else
                    {
                        g_option.m_nGZ_Flag = 0;
                    }

                    CurFileTime = fnGetIncMin(CurFileTime, -1);
                }

                if(nSetTime == nSix_Hour)
                    return -1;  //New, Old 파일 모두 없을 경우
            }
        }
    }

    g_option.m_tDataTime = CurFileTime;
    return 0;
}

static void fnSetSiteValueToUf(ST_UF_DATA *pUf)
{
    int nAIdx = 0;
    int nBIdx = 0;

    if(pUf == NULL)
        return;

    g_site.m_fSiteLon = pUf->m_fSiteLon;
    g_site.m_fSiteLat = pUf->m_fSiteLat;
    g_site.m_nGateSize = pUf->m_nGateSize[g_option.m_nSweepNo][0];
    g_site.m_nBinCount = pUf->m_nBins[g_option.m_nSweepNo][0];
    g_site.m_fMaxRange = (g_site.m_nGateSize * g_site.m_nBinCount) / 1000.
                       + (pUf->m_nRangeBin[g_option.m_nSweepNo][0]) / 1000.;
    g_site.m_fSiteGridKm = 1.0;

    if((strcmp(g_option.m_szSiteName, "K01") == 0)||
      (strcmp(g_option.m_szSiteName, "K02") == 0)||
      (strcmp(g_option.m_szSiteName, "K03") == 0))
        g_site.m_fSiteGridKm = 0.4;

    g_site.m_nSiteXdim = (g_site.m_fMaxRange / g_site.m_fSiteGridKm)*2 + 1;
    g_site.m_nSiteYdim = (g_site.m_fMaxRange / g_site.m_fSiteGridKm)*2 + 1;

    if(strcmp(g_option.m_szDataType, "VR") == 0)
        g_site.m_fNyqVel = pUf->m_fNyqVel;
    else
        g_site.m_fNyqVel = 0;

    for(nAIdx = 0; nAIdx < pUf->m_nFieldCnt; nAIdx++)
    {
        g_site.m_szInfoDataType[nAIdx][0] = pUf->szField_Name[nAIdx][0];
        g_site.m_szInfoDataType[nAIdx][1] = pUf->szField_Name[nAIdx][1];
        g_site.m_szInfoDataType[nAIdx][2] = '\0';
    }

    for(nBIdx = 0; nBIdx < pUf->m_nSweeps; nBIdx++)
    {
        g_site.m_szInfoElv[nBIdx] = pUf->m_fUfElevation[nBIdx];
    }
    
    if(strcmp(g_option.m_szDataType, "SN") == 0)
    {
        g_option.m_fZr_A = 2000;
        g_option.m_fZr_B = 2;
    }
    else
    {
        g_option.m_fZr_A = DEFAULT_ZR_A;
        g_option.m_fZr_B = DEFAULT_ZR_B;
    }
}

static void fnSwap_4Bytes(void *pWord)
{
    unsigned char *pByte;
    unsigned char cTemp;
    pByte    = pWord;
    cTemp    = pByte[0];
    pByte[0] = pByte[3];
    pByte[3] = cTemp;
    cTemp    = pByte[1];
    pByte[1] = pByte[2];
    pByte[2] = cTemp;
}

//oskim 20171204
static int fnRead_HCPPI(char *filename, HCPPI *pHcppi, int bOldFile)
{
    gzFile pFp     = NULL;
    float fAz     = 360.0 / 362.5;
    int  i        = 0;
    int  j        = 0;
    int  k        = 0;
    int  nSkip    = 0;
    int  nSweeps  = 0;

    if((pFp = gzopen(filename, "r")) == NULL )
    {
        return -1;
    }

    /*
     * get m_pSweep & memory allocation
     */
    // nSkip site name
    nSkip += HT_SIZE + sizeof(char)*SITENAME_LENGTH + HT_SIZE;
    // nSkip m_rgnDate
    nSkip += HT_SIZE + sizeof(int)*DATE_LENGTH + HT_SIZE;
    // read m_pSweep
    nSkip += HT_SIZE;

    gzseek(pFp, nSkip, SEEK_SET);
    gzread(pFp, &nSweeps, sizeof(nSweeps));
    if(IS_SWAP)
    {
        fnSwap_4Bytes(&nSweeps);
    }
    gzrewind(pFp);

    pHcppi->m_nSweeps = nSweeps;
    pHcppi->m_pSweep = (HCPPI_SWEEP *)calloc(pHcppi->m_nSweeps, sizeof(HCPPI_SWEEP)*nSweeps);
    /*
     * read hcppi data while nSweeps
     */
    for(i=0 ; i<nSweeps ; i++)
    {
        /* site name */
        gzseek(pFp, HT_SIZE, SEEK_CUR);
        gzread(pFp, pHcppi->m_pSweep[i].h.m_szSiteName, sizeof(char)*SITENAME_LENGTH);
        pHcppi->m_pSweep[i].h.m_szSiteName[SITENAME_LENGTH] = '\0';
        gzseek(pFp, HT_SIZE, SEEK_CUR);

        /* m_rgnDate */
        gzseek(pFp, HT_SIZE, SEEK_CUR);
        gzread(pFp, pHcppi->m_pSweep[i].h.m_rgnDate, sizeof(pHcppi->m_pSweep[i].h.m_rgnDate));

        if(IS_SWAP)
        {
            for(j=0 ; j<DATE_LENGTH ; j++)
            {
                fnSwap_4Bytes(&pHcppi->m_pSweep[i].h.m_rgnDate[j]);
            }
        }
        gzseek(pFp, HT_SIZE, SEEK_CUR);

        /* m_pSweep */
        gzseek(pFp, HT_SIZE, SEEK_CUR);
        gzread(pFp, &pHcppi->m_pSweep[i].h.m_nSweeps, sizeof(pHcppi->m_pSweep[i].h.m_nSweeps));
        if(IS_SWAP)
        {
            fnSwap_4Bytes(&pHcppi->m_pSweep[i].h.m_nSweeps);
        }
        gzseek(pFp, HT_SIZE, SEEK_CUR);

        /* m_nRays */
        gzseek(pFp, HT_SIZE, SEEK_CUR);
        gzread(pFp, &pHcppi->m_pSweep[i].h.m_nRays, sizeof(pHcppi->m_pSweep[i].h.m_nRays));
        if(IS_SWAP)
        {
            fnSwap_4Bytes(&pHcppi->m_pSweep[i].h.m_nRays);
        }
        gzseek(pFp, HT_SIZE, SEEK_CUR);

        /* m_fFixAng: real*1 */
        gzseek(pFp, HT_SIZE, SEEK_CUR);
        gzread(pFp, &pHcppi->m_pSweep[i].h.m_fFixAng, sizeof(pHcppi->m_pSweep[i].h.m_fFixAng));
        if(IS_SWAP)
        {
            fnSwap_4Bytes(&pHcppi->m_pSweep[i].h.m_fFixAng);
        }
        gzseek(pFp, HT_SIZE, SEEK_CUR);

        /* m_rgfEld: real*1000 */
        gzseek(pFp, HT_SIZE, SEEK_CUR);
        gzread(pFp, pHcppi->m_pSweep[i].h.m_rgfEld, sizeof(pHcppi->m_pSweep[i].h.m_rgfEld));
        if(IS_SWAP)
        {
            for(j=0 ; j<HCPPI_ARRAY_SIZE ; j++)
            {
                fnSwap_4Bytes(&pHcppi->m_pSweep[i].h.m_rgfEld[j]);
            }
        }
        gzseek(pFp, HT_SIZE, SEEK_CUR);

        /* m_rgfAzmd: real*1000 */
        gzseek(pFp, HT_SIZE, SEEK_CUR);
        gzread(pFp, pHcppi->m_pSweep[i].h.m_rgfAzmd, sizeof(pHcppi->m_pSweep[i].h.m_rgfAzmd));
        if(IS_SWAP)
        {
            for(j=0 ; j<HCPPI_ARRAY_SIZE ; j++)
            {
                fnSwap_4Bytes(&pHcppi->m_pSweep[i].h.m_rgfAzmd[j]);
            }
        }

        if(!strncasecmp(pHcppi->m_pSweep[i].h.m_szSiteName, "BRI", 3))
        {
            for(j=0 ; j<HCPPI_ARRAY_SIZE ; j++)
            {
                pHcppi->m_pSweep[i].h.m_rgfAzmd[j] = fAz * (j+1);
            }
        }

        gzseek(pFp, HT_SIZE, SEEK_CUR);

        /* m_fRan_1st_Gate: real*1 */
        gzseek(pFp, HT_SIZE, SEEK_CUR);
        gzread(pFp, &pHcppi->m_pSweep[i].h.m_fRan_1st_Gate, sizeof(pHcppi->m_pSweep[i].h.m_fRan_1st_Gate));
        gzseek(pFp, HT_SIZE, SEEK_CUR);

        /* m_fResol_Gate: real*1 */
        gzseek(pFp, HT_SIZE, SEEK_CUR);
        gzread(pFp, &pHcppi->m_pSweep[i].h.m_fResol_Gate, sizeof(pHcppi->m_pSweep[i].h.m_fResol_Gate));
        if(IS_SWAP)
        {
            fnSwap_4Bytes(&pHcppi->m_pSweep[i].h.m_fResol_Gate);
        }
        gzseek(pFp, HT_SIZE, SEEK_CUR);

        /* m_nRay: integer*1 */
        gzseek(pFp, HT_SIZE, SEEK_CUR);
        gzread(pFp, &pHcppi->m_pSweep[i].h.m_nRay, sizeof(pHcppi->m_pSweep[i].h.m_nRay));
        if(IS_SWAP)
        {
            fnSwap_4Bytes(&pHcppi->m_pSweep[i].h.m_nRay);
        }
        gzseek(pFp, HT_SIZE, SEEK_CUR);

        /* m_nGate: integer*1 */
        gzseek(pFp, HT_SIZE, SEEK_CUR);
        gzread(pFp, &pHcppi->m_pSweep[i].h.m_nGate, sizeof(pHcppi->m_pSweep[i].h.m_nGate));
        if(IS_SWAP)
        {
            fnSwap_4Bytes(&pHcppi->m_pSweep[i].h.m_nGate);
        }
        gzseek(pFp, HT_SIZE, SEEK_CUR);

        //oskim 20171204
        if(bOldFile == 1)
        {
            /* zhh_raw: real*m_nGate*m_nRay */
            nSkip = (HT_SIZE + sizeof(float)*pHcppi->m_pSweep[i].h.m_nGate + HT_SIZE) * pHcppi->m_pSweep[i].h.m_nRay;
            gzseek(pFp, nSkip, SEEK_CUR);

            /* zdr_raw: real*m_nGate*m_nRay */
            nSkip = (HT_SIZE + sizeof(float)*pHcppi->m_pSweep[i].h.m_nGate + HT_SIZE) * pHcppi->m_pSweep[i].h.m_nRay;
            gzseek(pFp, nSkip, SEEK_CUR);

            /* zhh_cor: real*m_nGate*m_nRay */
            nSkip = (HT_SIZE + sizeof(float)*pHcppi->m_pSweep[i].h.m_nGate + HT_SIZE) * pHcppi->m_pSweep[i].h.m_nRay;
            gzseek(pFp, nSkip, SEEK_CUR);

            /* zdr_cor: real*m_nGate*m_nRay */
            nSkip = (HT_SIZE + sizeof(float)*pHcppi->m_pSweep[i].h.m_nGate + HT_SIZE) * pHcppi->m_pSweep[i].h.m_nRay;
            gzseek(pFp, nSkip, SEEK_CUR);

            /* pdp: real*m_nGate*m_nRay */
            nSkip = (HT_SIZE + sizeof(float)*pHcppi->m_pSweep[i].h.m_nGate + HT_SIZE) * pHcppi->m_pSweep[i].h.m_nRay;
            gzseek(pFp, nSkip, SEEK_CUR);

            /* rhv: real*m_nGate*m_nRay */
            nSkip = (HT_SIZE + sizeof(float)*pHcppi->m_pSweep[i].h.m_nGate + HT_SIZE) * pHcppi->m_pSweep[i].h.m_nRay;
            gzseek(pFp, nSkip, SEEK_CUR);

            /* kdp: real*m_nGate*m_nRay */
            nSkip = (HT_SIZE + sizeof(float)*pHcppi->m_pSweep[i].h.m_nGate + HT_SIZE) * pHcppi->m_pSweep[i].h.m_nRay;
            gzseek(pFp, nSkip, SEEK_CUR);
        }

        /* id: real*m_nGate*m_nRay */
        if(i != g_option.m_nSweepNo)
        {
            nSkip = (HT_SIZE + sizeof(float)*pHcppi->m_pSweep[i].h.m_nGate + HT_SIZE) * pHcppi->m_pSweep[i].h.m_nRay;
            gzseek(pFp, nSkip, SEEK_CUR);
        }
        else
        {
            pHcppi->m_pSweep[i].m_nId = (int **)calloc(pHcppi->m_nSweeps, sizeof(int *)*pHcppi->m_pSweep[i].h.m_nRay);
            for(j=0 ; j<pHcppi->m_pSweep[i].h.m_nRay ; j++)
            {
                pHcppi->m_pSweep[i].m_nId[j] = (int *)calloc(pHcppi->m_nSweeps, sizeof(int)*pHcppi->m_pSweep[i].h.m_nGate);

                gzseek(pFp, HT_SIZE, SEEK_CUR);
                gzread(pFp, pHcppi->m_pSweep[i].m_nId[j], sizeof(int)*pHcppi->m_pSweep[i].h.m_nGate);
                gzseek(pFp, HT_SIZE, SEEK_CUR);

                if(IS_SWAP)
                {
                    for(k=0 ; k<pHcppi->m_pSweep[i].h.m_nGate ; k++)
                    {
                        fnSwap_4Bytes(&pHcppi->m_pSweep[i].m_nId[j][k]);
                    }
                }
            }
        }

        //oskim 20171204
        if(bOldFile == 1)
        {
            /* rzhh_raw: real*m_nGate*m_nRay */
            nSkip = (HT_SIZE + sizeof(float)*pHcppi->m_pSweep[i].h.m_nGate + HT_SIZE) * pHcppi->m_pSweep[i].h.m_nRay;
            gzseek(pFp, nSkip, SEEK_CUR);

            /* rzhh_cor: real*m_nGate*m_nRay */
            nSkip = (HT_SIZE + sizeof(float)*pHcppi->m_pSweep[i].h.m_nGate + HT_SIZE) * pHcppi->m_pSweep[i].h.m_nRay;
            gzseek(pFp, nSkip, SEEK_CUR);

            /* rkdp: real*m_nGate*m_nRay */
            nSkip = (HT_SIZE + sizeof(float)*pHcppi->m_pSweep[i].h.m_nGate + HT_SIZE) * pHcppi->m_pSweep[i].h.m_nRay;
            gzseek(pFp, nSkip, SEEK_CUR);

            /* rdsd: real*m_nGate*m_nRay */
            nSkip = (HT_SIZE + sizeof(float)*pHcppi->m_pSweep[i].h.m_nGate + HT_SIZE) * pHcppi->m_pSweep[i].h.m_nRay;
            gzseek(pFp, nSkip, SEEK_CUR);
        }

        if(i == g_option.m_nSweepNo)
            break;
//      print_HCPPI(*hcppi, i);
    }

    gzclose(pFp);
    return 1;
}

static int ReadHCI(char *filename, HCI *hci,  HCPPI *pHcppi)
{
    gzFile fp;
    float fAz     = 360.0 / 362.5;
    int i,j,k;
    unsigned char cbuf[4] = {0,};

    if ( ( fp = gzopen(filename, "rb") ) == NULL ) {
        return -1;
    }

    /*** Main Header ***/
    // There is no separate tags
    //name_Radar
    gzread(fp, hci->h.szRadar, sizeof(char)*SITENAME_LENGTH);
    //hci->h.nRadar[SITENAME_LENGTH] = '\0';
    gzread(fp, cbuf, 1L);

    // latitude
    gzread(fp, &hci->h.latitude, sizeof(float));
    // longitude
    gzread(fp, &hci->h.longitude, sizeof(float));
    // height
    gzread(fp, &hci->h.height, sizeof(float));

    // Time
    gzread(fp, &hci->h.YYYY, sizeof(unsigned short));
    gzread(fp, &hci->h.MM, sizeof(unsigned char));
    gzread(fp, &hci->h.DD, sizeof(unsigned char));
    gzread(fp, &hci->h.HH, sizeof(unsigned char));
    gzread(fp, &hci->h.MI, sizeof(unsigned char));
    gzread(fp, &hci->h.SS, sizeof(unsigned char));

    // Nsweeps
    gzread(fp, &hci->h.Nsweeps, sizeof(short));

    pHcppi->m_nSweeps = hci->h.Nsweeps;
    pHcppi->m_pSweep = (HCPPI_SWEEP *)calloc(pHcppi->m_nSweeps, sizeof(HCPPI_SWEEP)*pHcppi->m_nSweeps);

    // SKIP dummy
    gzseek(fp, sizeof(unsigned char)*32, SEEK_CUR);

    /*** Sweeps ***/
    for(k=0; k<hci->h.Nsweeps; k++) {
        /*** Sweep Header ***/
        gzread(fp, &hci->s[k].h.sweepn, sizeof(short));
        gzread(fp, &hci->s[k].h.sw_fix_angle,sizeof(float));
        //gzread(fp, hci->s[k].h.azimuth, sizeof(float)*MAX_RAY);
        gzread(fp, &hci->s[k].h.resolution_gate, sizeof(float));
        gzread(fp, &hci->s[k].h.first_gate, sizeof(float));
        gzread(fp, &hci->s[k].h.Nray, sizeof(short));
        gzread(fp, &hci->s[k].h.Ngate, sizeof(short));

        //Allocate azimuth array and Read
        hci->s[k].h.azimuth = calloc(hci->s[k].h.Nray, sizeof(float));
        gzread(fp, hci->s[k].h.azimuth, sizeof(float)*hci->s[k].h.Nray);

        //SKIP dummy
        gzseek(fp, sizeof(unsigned char)*32, SEEK_CUR);

        strncpy(pHcppi->m_pSweep[k].h.m_szSiteName, hci->h.szRadar, SITENAME_LENGTH);
        pHcppi->m_pSweep[k].h.m_szSiteName[SITENAME_LENGTH] = '\0';

        pHcppi->m_pSweep[k].h.m_rgnDate[0] = hci->h.YYYY;
        pHcppi->m_pSweep[k].h.m_rgnDate[1] = hci->h.MM;
        pHcppi->m_pSweep[k].h.m_rgnDate[2] = hci->h.DD;
        pHcppi->m_pSweep[k].h.m_rgnDate[3] = hci->h.HH;
        pHcppi->m_pSweep[k].h.m_rgnDate[4] = hci->h.MI;
        pHcppi->m_pSweep[k].h.m_rgnDate[5] = hci->h.SS;

        pHcppi->m_pSweep[k].h.m_nSweeps  = hci->h.Nsweeps; //hci->s[k].h.sweepn;
        pHcppi->m_pSweep[k].h.m_nRays    = hci->s[k].h.Nray;
        pHcppi->m_pSweep[k].h.m_fFixAng  = hci->s[k].h.sw_fix_angle;
//        memset(pHcppi->m_pSweep[k].h.m_rgfEld, 0, sizeof(pHcppi->m_pSweep[k].h.m_rgfEld));
//        memset(pHcppi->m_pSweep[k].h.m_rgfEld, hci->s[k].h.sw_fix_angle, sizeof(pHcppi->m_pSweep[k].h.m_rgfEld));
        memcpy(pHcppi->m_pSweep[k].h.m_rgfAzmd, hci->s[k].h.azimuth, sizeof(float)*hci->s[k].h.Nray);
        pHcppi->m_pSweep[k].h.m_fRan_1st_Gate  = hci->s[k].h.first_gate;
        pHcppi->m_pSweep[k].h.m_fResol_Gate    = hci->s[k].h.resolution_gate;
        pHcppi->m_pSweep[k].h.m_nRay           = hci->s[k].h.Nray;
        pHcppi->m_pSweep[k].h.m_nGate          = hci->s[k].h.Ngate;

        if(!strncasecmp(pHcppi->m_pSweep[k].h.m_szSiteName, "BRI", 3))
        {
            for(j=0 ; j<pHcppi->m_pSweep[k].h.m_nRays /*MAX_RAY*/ ; j++)
            {
                pHcppi->m_pSweep[k].h.m_rgfAzmd[j] = fAz * (j+1);
            }
        }

        /*** Sweep Data ***/
        pHcppi->m_pSweep[k].m_nId = (char **)calloc(pHcppi->m_nSweeps, sizeof(char *)*pHcppi->m_pSweep[k].h.m_nRay);
        for(j=0; j < hci->s[k].h.Nray; j++) {
            pHcppi->m_pSweep[k].m_nId[j] = (char *)calloc(pHcppi->m_nSweeps, sizeof(char)*pHcppi->m_pSweep[k].h.m_nGate);
            for(i=0; i< hci->s[k].h.Ngate; i++) {
                gzread(fp, &hci->s[k].data[j][i], sizeof(char));
                pHcppi->m_pSweep[k].m_nId[j][i] = hci->s[k].data[j][i];
            }//i
        }//j

        if(k == g_option.m_nSweepNo)
            break;

    }//k

    gzclose(fp);

    return 1;
}
//oskim 20180202 - end


static int fnMakeImgData(void)
{
    int                     nXIdx           = 0;
    int                     nYIdx           = 0;
    int                     nImgLLx       = 0;
    int                     nImgLLy       = 0;
    float                   fGridScale    = 0.0;
    float                   fImgGridKm      = 0.0;

    if((g_pImgData = fnGetMatrixFloat(g_option.m_nImgXdim, g_option.m_nImgYdim)) == NULL)
    {
        return -1;
    }

    for(nYIdx = 0; nYIdx < g_option.m_nImgYdim; nYIdx++)
    {
        for(nXIdx = 0; nXIdx < g_option.m_nImgXdim; nXIdx++)
        {
            g_pImgData[nYIdx][nXIdx] = BAD_VALUE_F;
        }
    }

    fImgGridKm = g_option.m_fImgGridKm;
    fGridScale = (g_site.m_fSiteGridKm / fImgGridKm);

    nImgLLx = (g_option.m_nImgXdim - (g_site.m_nSiteXdim * fGridScale)) / 2;
    nImgLLy = (g_option.m_nImgYdim - (g_site.m_nSiteYdim * fGridScale)) / 2;

    for(nYIdx = 0; nYIdx < g_option.m_nImgYdim; nYIdx++)
    {
        for(nXIdx = 0; nXIdx < g_option.m_nImgXdim; nXIdx++)
        {
            g_pImgData[nYIdx][nXIdx] = fnCalcRadarValue_Map(g_pSiteData,
                                                            g_site.m_nSiteXdim,
                                                            g_site.m_nSiteYdim,
                                                            nImgLLx,
                                                            nImgLLy,
                                                            nXIdx,
                                                            nYIdx,
                                                            fGridScale);
        }
    }

    return 0;
}

static int fnCreatePPI(ST_UF_DATA *pUf)
{
    float   *pfImsiData  = NULL;
    int     nXIdx        = 0;
    int     nYIdx        = 0;
    int     nImsiCount   = 0;
    st_Azimuth* table;

    if(pUf == NULL)
        return -1;

    if(g_option.m_nSweepNo >= pUf->m_nSweeps)
        return -1;

    table = fnMakeHashTable(pUf, g_option.m_nSweepNo);

    pfImsiData = fnKRL_SweepToCart(pUf, g_option.m_nSweepNo, g_site.m_nSiteXdim, g_site.m_nSiteYdim, g_site.m_fMaxRange, table);
    if(pfImsiData == NULL)
    {
        free(table);
        return -1;
    }

    for (nYIdx = 0 ; nYIdx < g_site.m_nSiteYdim ; nYIdx++ )
    {
        for (nXIdx = 0 ; nXIdx < g_site.m_nSiteXdim ; nXIdx++ )
        {
            g_pSiteData[nYIdx][nXIdx] = pfImsiData[nImsiCount];
            nImsiCount++;
        }
    }

    free(pfImsiData);
    free(table);

    return 0;
}

static int fnCreateMohrCAPPI(ST_UF_DATA *pUf, int nIs_Dbz)
{
    int   nXIdx             = 0;
    int   nYIdx             = 0;
    int   nImsiCount        = 0;
    float fHeightFromRadar  = 0.0;
    float fHeight           = 0.0;
    float *pfImsiData       = NULL;
    st_Azimuth** table;

    if(pUf == NULL)
        return -1;

    //해발 고도 계산
    fHeight = pUf->m_nHeight;
    fHeightFromRadar = g_option.m_fCappi_Alt-(fHeight/1000.);

    table = (st_Azimuth**)malloc(sizeof(st_Azimuth*)*(pUf->m_nSweeps));
    for(nYIdx = 0; nYIdx < pUf->m_nSweeps; nYIdx++)
    {
        table[nYIdx] = fnMakeHashTable(pUf, nYIdx);
    }

    for(nYIdx = 0; nYIdx < g_site.m_nSiteYdim; nYIdx++)
    {
        for(nXIdx = 0; nXIdx < g_site.m_nSiteXdim; nXIdx++)
        {
            g_pSiteData[nYIdx][nXIdx] = BAD_VALUE_F;
        }
    }

    pfImsiData = fnMakeMohrCappi(pUf, nIs_Dbz, g_site.m_nSiteYdim, g_site.m_nSiteXdim, g_site.m_fSiteGridKm,
                                 0, g_site.m_nSiteYdim, 0, g_site.m_nSiteXdim, fHeightFromRadar, table);

    if(pfImsiData != NULL)
    {
        nImsiCount = 0;
        for (nYIdx = 0 ; nYIdx < g_site.m_nSiteYdim ; nYIdx++ )
        {
            for (nXIdx = 0 ; nXIdx < g_site.m_nSiteXdim ; nXIdx++ ){

                g_pSiteData[nYIdx][nXIdx] = pfImsiData[nImsiCount];
                nImsiCount++;
            }
        }
        free(pfImsiData);
    }

    for(nYIdx = 0; nYIdx < pUf->m_nSweeps; nYIdx++)
    {
        free(table[nYIdx]);
    }

    free(table);
    return 0;
}


//oskim 20180202 - start
static HCI *init_HCI(void)
{
   int i, k;

   HCI *hci = (HCI *) malloc(sizeof(HCI));
   //hci->s = (HCI_Sweeps **)malloc( sizeof(HCI_Sweeps *)*MAX_SWEEP );
   hci->s = (HCI_Sweeps *)malloc( sizeof(HCI_Sweeps)*MAX_SWEEP );
   for(k=0; k<MAX_SWEEP; k++) {
      //hci->s[k] = (HCI_Sweeps *) malloc( sizeof(HCI_Sweeps) );
      hci->s[k].h.azimuth = NULL;
      hci->s[k].data = (int **) malloc( sizeof(int *)*MAX_RAY );
      for(i=0; i < MAX_RAY; i++) {
         hci->s[k].data[i] = (int *)malloc( sizeof(int)*MAX_GATE );
      }//i
   }//k

  return hci;
}

static void free_HCI(HCI *hci)
{
   int i, k;

   for(k=0; k<MAX_SWEEP; k++) {
       if(hci->s[k].h.azimuth != NULL)
       {
          free(hci->s[k].h.azimuth);
          hci->s[k].h.azimuth = NULL;
       }
      for(i=0; i <MAX_RAY ; i++) {
         free(hci->s[k].data[i]);
         hci->s[k].data[i] = NULL;
      }//i
      free(hci->s[k].data);
      hci->s[k].data = NULL;
   }//k
   free(hci->s);
   hci->s = NULL;
   free(hci);
   hci = NULL;
}

static int fnGet_Closest_Ray_From_Sweep(HCPPI_HEAD h, float ray_angle)
{
    int  ray_index   = -1;
    int  i           = 0;

    for(i=0 ; i<h.m_nRay ; i++)
    {
        //khbaek 20180504
        //PPI에 비해 HCI가 시계 방향으로 1도 이상 돌아간 문제 수정
        //BIN 포맷의 파일 자체에 원인이 있어서 ray_angle + 2.5 하여 임시방편으로 수정함.
        if(h.m_rgfAzmd[i] <= ray_angle + 2.5)
        {
            ray_index = i;
        }
    }

    if( ray_index>0 && fabs(h.m_rgfAzmd[ray_index-1]-ray_angle) < fabs(h.m_rgfAzmd[ray_index]-ray_angle) )
    {
        ray_index = ray_index - 1;
    }

    return ray_index;
}

static int fnGet_Value_From_Ray(int *ray, float range_bin1, float gate_size, int nbins, float r)
{
    int     bin_index = 0;
    float   rm        = r * 1000;
    float   gs        = gate_size * 1000;
    float   rb        = range_bin1 * 1000;

    if (ray == NULL)
        return BADVAL;

    if(gate_size == 0)
        return BADVAL;

    bin_index = (int)(((rm - rb)/gs) + 0.5);

    if (bin_index >= nbins || bin_index < 0)
        return BADVAL;

    return ray[bin_index];
}

static int **fnHCPPI_to_cart(HCPPI hcppi, int nSweep_Index, int xdim, int ydim, float range)
{
    int   **cart_image = NULL;
    float fAzim = 0, r = 0;
    int  ray_index    = 0;
    int  val          = 0;
    int  x = 0, y = 0, i=0;

    if (xdim != ydim || ydim < 0 || xdim < 0)
    {
        return NULL;
    }

    cart_image = malloc(ydim*sizeof(int*));
    for ( i = ydim-1 ; i >= 0; i-- )         // OPT
    {
        cart_image[i] = malloc(xdim*sizeof(int));
        memset( &cart_image[i][0], BADVAL, xdim*sizeof(int));
    }

    int  x_cnt = xdim / 2;
    int  y_cnt = ydim / 2;

    for (y= -ydim / 2; y<y_cnt; y++)      // OPT
    {
        for (x= -xdim / 2; x<x_cnt; x++)  // OPT
        {   
            r = (float)sqrt((double)x*x + (double)y*y);

            if (ydim < xdim)    r *= range/(.5*ydim);
            else                r *= range/(.5*xdim);

            // Find fAzimuth and range, then search Volume.
            if (x !=0 )
                fAzim = (float)atan((double)y/(double)x)*180.0/3.14159;
            else
            {
                if (y < 0)  fAzim = -90.0;
                else        fAzim = 90.0;
            }

            if (y<0 && x<0)         fAzim -= 180;    // Quadrant 3 (math notation).
            else if (y>0 && x<0)    fAzim += 180;    // Quad: 1

            fAzim =  -fAzim;
            fAzim -= 90.0;
            if (fAzim < 0)   fAzim += 360.0;


            if (r > range)
                val = BADVAL;
            else
            {
                ray_index = fnGet_Closest_Ray_From_Sweep(hcppi.m_pSweep[nSweep_Index].h, fAzim);

                if(ray_index>=0)
                    val = fnGet_Value_From_Ray (hcppi.m_pSweep[nSweep_Index].m_nId[ray_index], hcppi.m_pSweep[nSweep_Index].h.m_fRan_1st_Gate
                            , hcppi.m_pSweep[nSweep_Index].h.m_fResol_Gate, hcppi.m_pSweep[nSweep_Index].h.m_nGate, r);
                else
                    val = BADVAL;
            }
            cart_image[y+y_cnt][(xdim-1)-(x+x_cnt)] = val;   // OPT
        }
    }

    return cart_image;
}

static int fnCreateHC_UF(ST_UF_DATA *pUf)
{
    float   *pfImsiData  = NULL;
    int     nXIdx        = 0;
    int     nYIdx        = 0;
    int     nImsiCount   = 0;
    st_Azimuth* table;

    if(pUf == NULL)
        return -1;

    if(g_option.m_nSweepNo >= pUf->m_nSweeps)
        return -1;

    table = fnMakeHashTable(pUf, g_option.m_nSweepNo);

    pfImsiData = fnKRL_SweepToCart(pUf, g_option.m_nSweepNo, g_site.m_nSiteXdim, g_site.m_nSiteYdim, g_site.m_fMaxRange, table);
    if(pfImsiData == NULL)
    {
        free(table);
        return -1;
    }
    else
    {
        for (nYIdx = 0 ; nYIdx < g_site.m_nSiteYdim ; nYIdx++ )
        {
            for (nXIdx = 0 ; nXIdx < g_site.m_nSiteXdim ; nXIdx++ )
            {
                g_pSiteData[nYIdx][nXIdx] = pfImsiData[nImsiCount];
                nImsiCount++;
            }
        }
        free(pfImsiData);
    }

    free(table);
    return 0;
}

static int fnCreateHC_GZ(HCPPI hcppi)
{
    int     **pfImsiData = NULL;
    int     nXIdx       = 0;
    int     nYIdx       = 0;

    pfImsiData = fnHCPPI_to_cart(hcppi, g_option.m_nSweepNo, g_site.m_nSiteXdim, g_site.m_nSiteYdim, g_site.m_fMaxRange);

    if(pfImsiData == NULL)
    {
        return -1;
    }
    else
    {
        for (nYIdx = 0 ; nYIdx < g_site.m_nSiteYdim ; nYIdx++ )
        {
            for (nXIdx = 0 ; nXIdx < g_site.m_nSiteXdim ; nXIdx++)
            {
                if(pfImsiData[nYIdx][nXIdx] == BADVAL)
                    g_pSiteData[nYIdx][nXIdx] = BAD_VALUE_F;
                else
                    g_pSiteData[nYIdx][nXIdx] = (float)pfImsiData[nYIdx][nXIdx];
            }
        }
    }

    fnFreeMatrixInt(pfImsiData, g_site.m_nSiteXdim);

    return 0;
}

static void fnSetSiteDataBound(void)
{
    int     nYidx = 0;
    int     nXidx = 0;
    float   fDist = 0;

    for(nYidx = 0; nYidx < g_site.m_nSiteYdim; nYidx++)
    {
        for(nXidx = 0; nXidx < g_site.m_nSiteXdim; nXidx++)
        {
            fDist = sqrt(pow(nYidx-(g_site.m_nSiteYdim/2), 2) + pow(nXidx-(g_site.m_nSiteXdim/2), 2)) * g_site.m_fSiteGridKm;

            if(fDist > g_site.m_fMaxRange)
            {
                if (g_pSiteData != NULL)
                    g_pSiteData[nYidx][nXidx] = OUT_BOUND_F;
            }
        }
    }
}

static int fnGetSiteInfo(char *szSiteName, float *fSiteLon, float *fSiteLat, float *fSiteAlt)
{
    FILE    *pFp;
    char    szData[MAX_STR]          = {0,};
    char    szData_SiteName[MAX_STR] = {0,};

    if(szSiteName == NULL)
        return -1;

    if((pFp = fopen(CGI_DF_HC_SITE_INFO_PATH, "r")) == NULL)
        return -1;

    if(fgets(szData, sizeof(szData), pFp) == NULL)
        return -1;

    while(szData != NULL)
    {

        sscanf(szData, "%s %f %f %f", szData_SiteName, fSiteLon, fSiteLat, fSiteAlt);
        if(strcmp(szSiteName, szData_SiteName) == 0)
            break;
        else
            fgets(szData, sizeof(szData), pFp);
    }

    fclose(pFp);
    return 0;
}

static void fnFree_HCPPI(HCPPI hcppi)
{
    int nIIdx = 0;
    int nJIdx = 0;

    if(hcppi.m_pSweep != NULL)
    {
        for(nIIdx=0 ; nIIdx<hcppi.m_nSweeps; nIIdx++)
        {
            if(hcppi.m_pSweep[nIIdx].m_nId != NULL)
            {
                for(nJIdx=0 ; nJIdx<hcppi.m_pSweep[nIIdx].h.m_nRay ; nJIdx++)
                {
                    if(hcppi.m_pSweep[nIIdx].m_nId[nJIdx] != NULL)
                        free(hcppi.m_pSweep[nIIdx].m_nId[nJIdx]);
                }
                free(hcppi.m_pSweep[nIIdx].m_nId);
            }
        }
        free(hcppi.m_pSweep);
    }
}

static int fnGetSite_UF_Data(void)
{
    ST_UF_DATA  *pUf            = NULL;
    int         nIs_Dbz         = 0;
    char        szFieldName[3]  = {0,};
    
    if(strcmp(g_option.m_szDataType, "DZ") == 0 || strcmp(g_option.m_szDataType, "CZ") == 0)
    {
        nIs_Dbz = 1;
    }
    
    if((strcmp(g_option.m_szDataType, "RN") == 0) || (strcmp(g_option.m_szDataType, "SN") == 0))
    {
        sprintf(szFieldName, "%s", "CZ");
    }
    else
    {
        sprintf(szFieldName, "%s", g_option.m_szDataType);
    }

    if(strcmp(g_option.m_szProductType, "ATOM7") == 0)
    {
        sprintf(szFieldName, "%s", "HC");
    }
    
    if((pUf = fnReadUfFile(g_option.m_szInputFileName, szFieldName, g_site.m_fAzimuthCorrection)) == NULL)
    {
        if(strcmp(g_option.m_szDataType, "RN") == 0)
        {
            sprintf(szFieldName, "%s", "DZ");
            if((pUf = fnReadUfFile(g_option.m_szInputFileName, szFieldName, g_site.m_fAzimuthCorrection)) == NULL)
            {
                return -1;
            }
        }
        else
        {
            return -1;
        }
    }
    
    fnSetSiteValueToUf(pUf);
    
    g_pSiteData = fnGetMatrixFloat(g_site.m_nSiteYdim, g_site.m_nSiteXdim);
    
    if(strcmp(g_option.m_szProductType, "PPI") == 0)
    {
        if(fnCreatePPI(pUf) < 0)
        {
            free(pUf);
            return -1;
        }
    }
    else if(strcmp(g_option.m_szProductType,"CAPPI") == 0)
    {
        if(fnCreateMohrCAPPI(pUf, nIs_Dbz) < 0)
        {
            free(pUf);
            return -1;
        }
    }
    else if(strcmp(g_option.m_szProductType,"ATOM7") == 0)
    {
        if(fnCreateHC_UF(pUf) < 0)
        {
            free(pUf);
            return -1;
        }
    }

    fnSetSiteDataBound();
    
    free(pUf);
    return 0;
}


static int fnGetSite_GZ_Data(void)
{
    char    szFileName[MAX_STR]   = "";
    int     nIdx = 0;
    int     bOldFile = g_bOldFile;
    HCPPI   hcppi;
// khbaek 20180508
//    HCI     *hci = NULL;

    if (g_option.m_nGZ_Flag == 0)
        return -1;

    memset(&hcppi, 0x00, sizeof(hcppi));

    snprintf(szFileName, sizeof(szFileName), "%s", g_option.m_szInputFileName);

    //oskim 20171204
    if(fnRead_HCPPI(szFileName, &hcppi, bOldFile) < 0)
        return -1;

/* khbaek 20180508 ([분석시스템-사이트]와 맞추기 위하여 HCPPI 읽도록 변경)
    //oskim 20180202
    hci = init_HCI();

    if(ReadHCI(szFileName, hci, &hcppi) < 0)
    {
        free_HCI(hci);
        return -1;
    }

    free_HCI(hci);
*/

    for(nIdx = 0; nIdx < hcppi.m_nSweeps; nIdx++)
    {
//        g_site.m_rgfElev[nIdx] = hcppi.m_pSweep[nIdx].h.m_fFixAng;
        g_site.m_rgfElev[nIdx] = hcppi.m_pSweep[nIdx].h.m_rgfEld[0];
    }

    g_site.m_nGateSize = hcppi.m_pSweep->h.m_fResol_Gate * 1000;
    //oskim 20180309 , Gate정보 가변처리, replace below 2 lines
    //g_site.m_nBinCount = hcppi.m_pSweep->h.m_nGate;
    //g_site.m_fMaxRange = (g_site.m_nGateSize * g_site.m_nBinCount)/1000.;
    g_site.m_nBinCount = hcppi.m_pSweep[g_option.m_nSweepNo].h.m_nGate;
    g_site.m_fMaxRange = (g_site.m_nGateSize * g_site.m_nBinCount)/1000.;
    g_site.m_fSiteGridKm = 1;

    if((strcmp(g_option.m_szSiteName, "K01") == 0) ||
            (strcmp(g_option.m_szSiteName, "K02") == 0) ||
            (strcmp(g_option.m_szSiteName, "K03") == 0))
        g_site.m_fSiteGridKm = 0.25; 

/*
    for(nAIdx = 0; nAIdx < pUf->m_nFieldCnt; nAIdx++)
    {
        g_site.m_szInfoDataType[nAIdx][0] = pUf->szField_Name[nAIdx][0];
        g_site.m_szInfoDataType[nAIdx][1] = pUf->szField_Name[nAIdx][1];
        g_site.m_szInfoDataType[nAIdx][2] = '\0';

    }
*/

    for(nIdx = 0; nIdx < hcppi.m_nSweeps; nIdx++)
    {
        g_site.m_szInfoElv[nIdx] = g_site.m_rgfElev[nIdx];
    }


    g_site.m_nSiteXdim = (g_site.m_fMaxRange / g_site.m_fSiteGridKm)*2 + 1;
    g_site.m_nSiteYdim = (g_site.m_fMaxRange / g_site.m_fSiteGridKm)*2 + 1;
    g_site.m_fNyqVel = 0;

    if(fnGetSiteInfo(g_option.m_szSiteName, &g_site.m_fSiteLon, &g_site.m_fSiteLat, &g_site.m_fSiteAlt) < 0)
        return -1;

    g_pSiteData = fnGetMatrixFloat(g_site.m_nSiteYdim, g_site.m_nSiteYdim);

    if(fnCreateHC_GZ(hcppi) < 0)
    {
        fnFree_HCPPI(hcppi);
        return -1;
    }

    fnFree_HCPPI(hcppi);
    return 0;
}

static void* fnMakeHcThread(void *arg)               
{                                                    
    fnGetSite_GZ_Data();                             
    fnSetSiteDataBound();                            
    if(g_pSiteData != NULL)                          
    {                                                
        fnMakeImgData();
    }

    return (void *)0;
}

/* ================================================================================ */
// FUNCTION
static int fnRead_DataFile(void)
{
    if(fnSetInputFileName() < 0)
    {
        return -1;
    }

    if(strcmp(g_option.m_szProductType,"ATOM7") != 0)
    {
        if(fnGetSite_UF_Data() < 0)     // UF
            return -1;
    }
    else
    {

        if(g_option.m_nUF_Flag == 1)
        {
            if(fnGetSite_UF_Data() < 0)     // UF
                return -1;
        }
        else
        {
            if(g_option.m_nGZ_Flag == 1)
            {
                pthread_t hc_thr = -1;
                pthread_create(&hc_thr, NULL, fnMakeHcThread, NULL);
                pthread_join(hc_thr, NULL);
            }
            else
            {
                return -1;
            }
        }
    }

    return 0;
}



/* ================================================================================ */
// MAIN

int main(int argc, char** argv)
{
#define MAIN_FREE() \
        if(g_pImgData != NULL) {fnFreeMatrixFloat(g_pImgData, g_option.m_nImgYdim);} \
        if(g_pSiteData != NULL) {fnFreeMatrixFloat(g_pSiteData, g_site.m_nSiteYdim);}\
        gdFreeFontCache();

    fnInitProc();   //g_option, g_site memset

    if(fnParamSet() < 0)    //파라미터 분리
    {
        MAIN_FREE()
        return -1;
    }

    fnInitOption();

    if(fnRead_DataFile() < 0)
    {
        if(strcmp(g_option.m_szProductType,"ATOM7") == 0)
        {
            fnNoDataDisp_MAP_Atom7(g_option.m_szQC_Type, g_option.m_szProductType, g_option.m_szDataType, g_option.m_fCappi_Alt, g_site.m_fMaxRange, g_site.m_nGateSize, g_site.m_nBinCount, g_site.m_fNyqVel, g_option.m_nImgXdim, g_option.m_nImgYdim);
            MAIN_FREE()
        }
        else
        {
        //oskim 20171204 - 단일편파 레이더(강릉 등) 데이터 없을때, 자료없음 화면 표시
            fnNoDataDisp_MAP(g_option.m_szQC_Type, g_option.m_szProductType, g_option.m_szDataType, g_option.m_fCappi_Alt, g_site.m_fMaxRange, g_site.m_nGateSize, g_site.m_nBinCount, g_site.m_fNyqVel, g_option.m_nImgXdim, g_option.m_nImgYdim);
            MAIN_FREE()
        }
        return -1;
    }

    if(strcmp(g_option.m_szProductType,"ATOM7") != 0)
    {
        if(fnKmaSmooth(g_pSiteData, g_site.m_nSiteYdim, g_site.m_nSiteXdim) < 0)
        {
            fnNoDataDisp_MAP(g_option.m_szQC_Type, g_option.m_szProductType, g_option.m_szDataType, g_option.m_fCappi_Alt, g_site.m_fMaxRange, g_site.m_nGateSize, g_site.m_nBinCount, g_site.m_fNyqVel, g_option.m_nImgXdim, g_option.m_nImgYdim);
            MAIN_FREE()
            return -1;
        }
    }

    if(strcmp(g_option.m_szProductType,"ATOM7") != 0 || g_option.m_nUF_Flag == 1)
    {
        if (fnMakeImgData() < 0)
        {
            fnNoDataDisp_MAP(g_option.m_szQC_Type, g_option.m_szProductType, g_option.m_szDataType, g_option.m_fCappi_Alt, g_site.m_fMaxRange, g_site.m_nGateSize, g_site.m_nBinCount, g_site.m_fNyqVel, g_option.m_nImgXdim, g_option.m_nImgYdim);
            MAIN_FREE();
            return -1;
        }
    }
/*
    if(g_pImgData == NULL)
    {
        fnNoDataDisp_MAP(g_option.m_szQC_Type, g_option.m_szProductType, g_option.m_szDataType, g_option.m_fCappi_Alt, g_site.m_fMaxRange, g_site.m_nGateSize, g_site.m_nBinCount, g_site.m_fNyqVel, g_option.m_nImgXdim, g_option.m_nImgYdim);
        MAIN_FREE()
        return -1;
    }
*/
    if(strcmp(g_option.m_szProductType,"ATOM7") == 0)
    {
        if(fnCreateImgAtom7() < 0)
        {
            fnNoDataDisp_MAP_Atom7(g_option.m_szQC_Type, g_option.m_szProductType, g_option.m_szDataType, g_option.m_fCappi_Alt, g_site.m_fMaxRange, g_site.m_nGateSize, g_site.m_nBinCount, g_site.m_fNyqVel, g_option.m_nImgXdim, g_option.m_nImgYdim);
            MAIN_FREE()
                return -1;
        }
    }
    else
    {
        if(fnCreateImg() < 0)
        {
            fnNoDataDisp_MAP(g_option.m_szQC_Type, g_option.m_szProductType, g_option.m_szDataType, g_option.m_fCappi_Alt, g_site.m_fMaxRange, g_site.m_nGateSize, g_site.m_nBinCount, g_site.m_fNyqVel, g_option.m_nImgXdim, g_option.m_nImgYdim);
            MAIN_FREE()
                return -1;
        }
    }

    MAIN_FREE()

    return 0;
}

/* ================================================================================ */
