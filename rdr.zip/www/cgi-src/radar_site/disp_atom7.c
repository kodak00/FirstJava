/* ================================================================================ */
// INCLUDE

#include "cgi_site_common.h"

#include "cgi_cmm_util.h"
#include "cgi_cmm_color.h"
#include "cgi_cmm_map_ini.h"

#include "cgi_site_uf.h"
#include "cgi_site_data.h"
#include "cgi_site_calc.h"
#include "cgi_site_draw.h"
#include "cgi_site_smooth.h"

#include "cgi_cmm_wst_disp.h"

#include "main.h"
#include "disp_atom7.h"

/* ================================================================================ */
// GLOBAL
//oskim 20171204
extern int g_bOldFile;


/* ================================================================================ */
// FUNCTION PROTO



/* ================================================================================ */
// LOCAL FUNCTION



/* ================================================================================ */
// FUNCTION

static void fnDispImg(gdImagePtr pImg, CGI_COLOR_TBL *pColor_ini, int echoColorTbl[CGI_DF_COLOR_MAX])
{
    int             nXIdx           = 0;
    int             nYIdx           = 0;
    int             nColorIdx       = 0;
    float           fMinVal         = 1.0f;
    int             nOptIdx         = 0;
    int             nWhite          = 0;
    int             nOutBound       = 0;

    nWhite          = gdImageColorAllocate(pImg, 255, 255, 255);
    nOutBound       = gdImageColorAllocate(pImg, 201, 201, 201);

    if(pImg == NULL)
        return;

    if(g_pImgData == NULL)
        return;

    for(nYIdx = 0; nYIdx < g_option.m_nImgYdim; nYIdx++)
    {
        for(nXIdx = 0; nXIdx < g_option.m_nImgXdim; nXIdx++)
        {
            if(g_pImgData[nYIdx][nXIdx] == OUT_BOUND_F)
                gdImageSetPixel(pImg, nXIdx, nYIdx, nOutBound);

            else if(g_pImgData[nYIdx][nXIdx] == BAD_VALUE_F)
                gdImageSetPixel(pImg, nXIdx, nYIdx, nWhite);

            else if(g_pImgData[nYIdx][nXIdx] != BAD_VALUE_F)
            {
                if(g_pImgData[nYIdx][nXIdx] > fMinVal)
                {
                    nColorIdx = fnGetColorLevel(g_pImgData[nYIdx][nXIdx], pColor_ini,
                                                CGI_EN_COLOR_RAIN, fMinVal, 1, 1);

                    if(g_pImgData[nYIdx][nXIdx] == 50)
                    {
                        nColorIdx = 14;
                        nOptIdx = 0;
                    }

                    if(nColorIdx < 0 && nColorIdx > pColor_ini->m_iEchoColorCnt)
                        continue;
                    else
                    {
                        if(nColorIdx == 14)
                        {
                            nColorIdx = 0;
                            nOptIdx = 0;
                        }
                        else if(nColorIdx >= 0 && nColorIdx <= 3)
                        {
                            nColorIdx = 2;
                            nOptIdx = 1;
                        }
                        else if(nColorIdx == 4)
                        {
                            nOptIdx = 2;
                        }
                        else if(nColorIdx >= 5 && nColorIdx <= 7)
                        {
                            nColorIdx = 6;
                            nOptIdx = 3;
                        }
                        else if(nColorIdx == 8 || nColorIdx == 10)
                        {
                            nColorIdx = 10;
                            nOptIdx = 4;
                        }
                        else if(nColorIdx == 9)
                        {
                            nOptIdx = 5;
                        }
                        else if(nColorIdx >= 11 && nColorIdx <= 13)
                        {
                            nColorIdx = 12;
                            nOptIdx = 6;
                        }
                        else
                        {
                            continue;
                        }

                        gdImageSetPixel(pImg, nXIdx, nYIdx, echoColorTbl[nColorIdx]);
                    }
                }
            }
        }
    }

}

gdImagePtr fnSiteImgCommentAtom7(struct tm stFileTime, char *szSiteName, char *szProductType, int nImgXdim)
{
    char szComment[MAX_STR] = {0,};
    gdImagePtr pImg_Comment;
    int nWhite = 0;
    int nBlack = 0;
    char szDateTime[MAX_STR] = {0,};

    if(szSiteName == NULL)
        return NULL;

    if((pImg_Comment = gdImageCreateTrueColor(nImgXdim, CGI_SITE_DF_TOP_HEIGHT)) == NULL)
        return NULL;

    strftime(szDateTime, sizeof(szDateTime), "%Y.%m.%d. %H:%M(KST)", &stFileTime);


    nWhite = gdImageColorAllocate(pImg_Comment, 255, 255, 255);
    nBlack = gdImageColorAllocate(pImg_Comment, 0, 0, 0);

    gdImageFilledRectangle(pImg_Comment, 0, 0, nImgXdim, CGI_SITE_DF_TOP_HEIGHT, nWhite);

    sprintf(szComment, "%s Radar %s %s", szSiteName, "Hydrometeors", szDateTime);
    gdImageStringTTF(pImg_Comment, NULL, nBlack, NANUMGOTHIC_FONT_PATH, 11, 0.0, 10, CGI_SITE_DF_TOP_HEIGHT-5, szComment);

    return pImg_Comment;
}

int fnWriteSiteColorIndxAtom7(gdImagePtr pImg, int nImgXdim, int nImgYdim, CGI_COLOR_TBL *pColor_ini, int rgnColor[])
{
    int     nIdx                = 0;
    int     nCellYdim           = 0;
    int     nYdim               = 0;
    int     nBlack              = 0;
    int     nWhite              = 0;
    int     nX_pos              = 0;
    int     nY_pos              = 0;
    int     nCount              = 0;
    int     rgnBrect[8]         = {0};
    char    rgcFont[MAX_STR]    = {0,};
    char    szStr[MAX_STR]      = {0,}; //출력할 파일 경로
    int     nX_Cell             = CGI_SITE_DF_COLOR_BAR_WIDTH;

    sprintf(rgcFont, "%s", NANUMGOTHIC_FONT_PATH);

    if(pImg == NULL || pColor_ini == NULL || rgnColor == NULL)
        return -1;

    nBlack       = gdImageColorAllocate(pImg, 0, 0, 0);
    nWhite       = gdImageColorAllocate(pImg, 255, 255, 255);

    gdImageFilledRectangle(pImg, nImgXdim, 0, nImgXdim+CGI_SITE_DF_RIGHT_WIDTH, nImgYdim, nWhite);

    nX_pos = nImgXdim;
    nYdim = nImgYdim;
    nCellYdim = (nYdim) / (pColor_ini->m_iEchoColorCnt) * 2;
    nCount = 0;
    for(nIdx = (pColor_ini->m_iEchoColorCnt)/2-1; nIdx >= 0; nIdx--)
    {
        nY_pos = nCellYdim * nCount++;
        if(nIdx > 0)
        {
            switch(nIdx)
            {
                case 6:
                    gdImageFilledRectangle(pImg, nX_pos, nY_pos , nX_pos + nX_Cell , nY_pos + nCellYdim, rgnColor[12]);
                    break;
                case 5:
                    gdImageFilledRectangle(pImg, nX_pos, nY_pos , nX_pos + nX_Cell , nY_pos + nCellYdim, rgnColor[9]);
                    break;
                case 4:
                    gdImageFilledRectangle(pImg, nX_pos, nY_pos , nX_pos + nX_Cell , nY_pos + nCellYdim, rgnColor[10]);
                    break;
                case 3:
                    gdImageFilledRectangle(pImg, nX_pos, nY_pos , nX_pos + nX_Cell , nY_pos + nCellYdim, rgnColor[6]);
                    break;
                case 2:
                    gdImageFilledRectangle(pImg, nX_pos, nY_pos , nX_pos + nX_Cell , nY_pos + nCellYdim, rgnColor[4]);
                    break;
                case 1:
                    gdImageFilledRectangle(pImg, nX_pos, nY_pos , nX_pos + nX_Cell , nY_pos + nCellYdim, rgnColor[2]);
                    break;
            }
        }
        else
        {
            gdImageFilledRectangle(pImg, nX_pos, nY_pos , nX_pos + nX_Cell , nYdim, rgnColor[nIdx]);
        }
    }

    nCount = 0;
    for(nIdx = (pColor_ini->m_iEchoColorCnt)/2-1; nIdx >= 0; nIdx--)
    {
        switch(nIdx)
        {
            case 0:
                sprintf(szStr, "非\n강\n수");
                break;
            case 1:
                sprintf(szStr, "비");
                break;
            case 2:
                sprintf(szStr, "강\n한\n비");
                break;
            case 3:
                sprintf(szStr, "우\n박\n/\n비");
                break;
            case 4:
                sprintf(szStr, "습\n설");
                break;
            case 5:
                sprintf(szStr, "건\n설");
                break;
            case 6:
                sprintf(szStr, "빙\n정");
                break;
            default:
                sprintf(szStr, "-");
                break;
        }

        //sprintf(szStr, szFormat, pColor_ini->m_echoColorTbl[nIdx].m_fUnit);

        nX_pos = nImgXdim + nX_Cell + 5;
        nY_pos = nCellYdim * nCount;
        nY_pos += nCellYdim/2 - 4;

        gdImageStringFT(pImg, &rgnBrect[0], nBlack, rgcFont, 8, 0.0, nX_pos, nY_pos, szStr);
        //gdImageString(pImg, gdFontGetSmall(), nX_pos, nY_pos, (unsigned char*)szStr, nBlack);
        nCount++;
    }

    nX_pos = nImgXdim;
    nY_pos = 0;
    gdImageRectangle(pImg, nX_pos, nY_pos, nX_pos + nX_Cell, nImgYdim, nBlack);

    return 0;
}

void fnNoDataDisp_MAP_Atom7(char *szQC_Type, char *szProductType, char *szDataType, float fProductArg, float fMaxRange, int nGateSize, int nBinCount, float fNyqVel, int nImgXdim, int nImgYdim)
{
    gdImagePtr  pImg;
    char        rgcText[126]        = {0,};
    int         rgnBrect[8]         = {0};
    char        *rgcErr             = NULL;
    int         nWhite              = 0;
    int         nBlack              = 0;
    char        rgcFont[MAX_STR]    = {0,};
    int         nX                  = 0;
    int         echoColorTbl[CGI_DF_COLOR_MAX] = { 0, };
    int         dispColorTbl[CGI_EN_DISP_COLOR_MAX] = { 0, };
    CGI_COLOR_TBL *pColor_ini = NULL;

    if(szProductType == NULL || szDataType == NULL)
        return;

    if((pColor_ini = fnReadColorTable(CGI_DF_HC_COLOR_FILE)) == NULL)
        return;

    pImg = gdImageCreateTrueColor(nImgXdim+CGI_SITE_DF_RIGHT_WIDTH, nImgYdim+CGI_SITE_DF_BOTTOM_HEIGHT);

    fnAllocColorTbl(pImg, pColor_ini, echoColorTbl, dispColorTbl);

    gdImageAlphaBlending(pImg, 0);
    gdImageSaveAlpha(pImg, 1);
    nBlack = gdImageColorAllocate(pImg, 0, 0, 0);
    nWhite = gdImageColorAllocateAlpha(pImg, 255, 255, 255, 0);

    gdImageFilledRectangle(pImg, 0, 0, nImgXdim-1, nImgYdim-1, nWhite);
    gdImageRectangle(pImg, 0, 0, nImgXdim, nImgYdim, nBlack);

    sprintf(rgcFont, "%s", NANUMGOTHIC_FONT_PATH);

    sprintf(rgcText, "%s", "선택된 시각의 레이더자료가 없습니다.");
    gdImageStringFT(NULL, &rgnBrect[0], nBlack, rgcFont, CGI_SITE_DF_NODISP_FONT_SIZE, 0.0, 0, 0, rgcText);

    nX = rgnBrect[2];
    rgcErr = gdImageStringFT(pImg, &rgnBrect[0], nBlack, rgcFont, CGI_SITE_DF_NODISP_FONT_SIZE,
                             0.0, (nImgXdim-nX)/2, nImgYdim/2, rgcText);

    fnWriteSiteColorIndxAtom7(pImg, nImgXdim, nImgYdim, pColor_ini, echoColorTbl);
    fnWriteBottomText(pImg, szQC_Type, szProductType, szDataType, fProductArg, fMaxRange, nGateSize, fNyqVel, nBinCount, nImgXdim, nImgYdim);

    fprintf(stdout, "Content-type: image/png\r\n\r\n");
    gdImagePng(pImg,stdout);
    gdImageDestroy(pImg);

    free(pColor_ini);
}

int fnCreateImgAtom7(void)
{
    gdImagePtr      pImg_Border     = NULL;
    gdImagePtr      pImg            = NULL;
    gdImagePtr      pImg_Top        = NULL;
    int             nBlack          = 0;
    int             nWhite          = 0;
    int             nRed            = 0;
    int             nOutBound       = 0;
    int             dispColorTbl[CGI_EN_DISP_COLOR_MAX] = { 0, };
    int             echoColorTbl[CGI_DF_COLOR_MAX]      = { 0, };
    float           fProductArg     = 0.0f;
    CGI_COLOR_TBL   *pColor_ini = NULL;

    if((pColor_ini = fnReadColorTable(CGI_DF_HC_COLOR_FILE)) == NULL)
        return -1;

    pImg_Border = gdImageCreateTrueColor(g_option.m_nImgXdim+CGI_SITE_DF_RIGHT_WIDTH,
                                      g_option.m_nImgYdim+CGI_SITE_DF_BOTTOM_HEIGHT+CGI_SITE_DF_TOP_HEIGHT);
    pImg = gdImageCreateTrueColor(g_option.m_nImgXdim+CGI_SITE_DF_RIGHT_WIDTH,
                                  g_option.m_nImgYdim+CGI_SITE_DF_BOTTOM_HEIGHT);

    fnAllocColorTbl(pImg, pColor_ini, echoColorTbl, dispColorTbl);
    gdImageAlphaBlending(pImg_Border, 0);
    gdImageAlphaBlending(pImg, 0);
    gdImageSaveAlpha(pImg_Border, 1);  //이 두줄 있어야 배경 투명하게 됨.
    gdImageSaveAlpha(pImg, 1);  //이 두줄 있어야 배경 투명하게 됨.

    nWhite          = gdImageColorAllocate(pImg, 255, 255, 255);
    nBlack          = gdImageColorAllocate(pImg,  51,  51,  51);
    nRed            = gdImageColorAllocate(pImg, 255, 0, 0);
    nOutBound       = gdImageColorAllocate(pImg, 201,201,201);

    gdImageFilledRectangle(pImg_Border, 0, 0, g_option.m_nImgXdim+CGI_SITE_DF_RIGHT_WIDTH,
                                              g_option.m_nImgYdim+CGI_SITE_DF_BOTTOM_HEIGHT+CGI_SITE_DF_TOP_HEIGHT,
                                              nWhite);
    gdImageFilledRectangle(pImg, 0, 0, g_option.m_nImgXdim, g_option.m_nImgYdim, nWhite);

    fnDispImg(pImg, pColor_ini, echoColorTbl);

    pImg_Top=fnSiteImgCommentAtom7(g_option.m_tDataTime, g_option.m_szSiteName, g_option.m_szProductType, g_option.m_nImgXdim+CGI_SITE_DF_RIGHT_WIDTH);

    fnDrawMap(pImg, g_site.m_fSiteLon, g_site.m_fSiteLat, g_option.m_nImgXdim/2, g_option.m_nImgYdim/2,
              g_option.m_fImgGridKm, dispColorTbl[CGI_EN_LINE_COLOR]);
    fnSiteAws(pImg, g_option.m_nImgXdim, g_option.m_nImgYdim, g_option.m_fImgGridKm,
              g_site.m_fSiteLon, g_site.m_fSiteLat, g_option.m_nImgXdim/2, g_option.m_nImgYdim/2,
              nRed, nBlack);
    fnDrawRangeRing(pImg, dispColorTbl[CGI_EN_LINE_COLOR], g_option.m_fImgGridKm, g_option.m_nImgYdim/2);
    fnDrawRangeDirection(pImg, dispColorTbl[CGI_EN_LINE_COLOR]);
    fnWriteSiteColorIndxAtom7(pImg, g_option.m_nImgXdim, g_option.m_nImgYdim, pColor_ini, echoColorTbl);

    fProductArg = g_site.m_szInfoElv[g_option.m_nSweepNo];

    fnWriteBottomText(pImg, g_option.m_szQC_Type, g_option.m_szProductType, g_option.m_szDataType,
                            fProductArg, g_site.m_fMaxRange, g_site.m_nGateSize, g_site.m_nBinCount,
                            g_site.m_fNyqVel, g_option.m_nImgXdim, g_option.m_nImgYdim);

    gdImageRectangle(pImg, 0, 0, g_option.m_nImgXdim+CGI_SITE_DF_COLOR_BAR_WIDTH,
                     g_option.m_nImgYdim+CGI_SITE_DF_BOTTOM_HEIGHT-1, nBlack);


    gdImageCopy(pImg_Border, pImg_Top, 0,0,0,0, g_option.m_nImgXdim+CGI_SITE_DF_RIGHT_WIDTH, CGI_SITE_DF_TOP_HEIGHT);
    gdImageCopy(pImg_Border, pImg, 0,CGI_SITE_DF_TOP_HEIGHT, 0, 0, g_option.m_nImgXdim+CGI_SITE_DF_RIGHT_WIDTH,
                g_option.m_nImgYdim+CGI_SITE_DF_BOTTOM_HEIGHT);

    fprintf(stdout, "Content-type: image/png\r\n\r\n");
    gdImagePng(pImg_Border, stdout);
    fflush(stdout);

    gdImageDestroy(pImg_Border);
    gdImageDestroy(pImg);
    gdImageDestroy(pImg_Top);

    free(pColor_ini);

    return 0;
}

/* ================================================================================ */
// MAIN



/* ================================================================================ */
