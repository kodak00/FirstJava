/* ================================================================================ */
// INCLUDE

#include "cgi_site_common.h"


#include "cgi_cmm_util.h"
#include "cgi_cmm_color.h"

#include "cgi_site_uf.h"
#include "cgi_site_data.h"
#include "cgi_site_calc.h"
#include "cgi_site_draw.h"
#include "cgi_site_smooth.h"

#include "main.h"
#include "disp.h"

/* ================================================================================ */
// GLOBAL



/* ================================================================================ */
// FUNCTION PROTO



/* ================================================================================ */
// LOCAL FUNCTION



/* ================================================================================ */
// FUNCTION

int fnCreateImg(void)
{
    gdImagePtr      pImg_Border        = NULL;
    gdImagePtr      pImg            = NULL;
    gdImagePtr      pImg_Top        = NULL;
    int             nBlack          = 0;
    int             nWhite          = 0;
    int             nRed            = 0;
    int             nOutBound       = 0;
    int             nXIdx           = 0;
    int             nYIdx           = 0;
    int             nColorIdx       = 0;
    int             dispColorTbl[CGI_EN_DISP_COLOR_MAX] = { 0, };
    int             echoColorTbl[CGI_DF_COLOR_MAX]      = { 0, };
    float           fProductArg     = 0.0f;
    CGI_COLOR_TBL   *pColor_ini = NULL;
    st_ColorInfo    stColorInfo;

    if(fnGetColorInfo(g_option.m_szProductType, g_option.m_szDataType, &stColorInfo) == -1)
        return -1;

    if((pColor_ini = fnReadColorTable(stColorInfo.m_szColorFile)) == NULL)
        return -1;

    pImg_Border = gdImageCreateTrueColor(g_option.m_nImgXdim+CGI_SITE_DF_RIGHT_WIDTH,
                                      g_option.m_nImgYdim+CGI_SITE_DF_BOTTOM_HEIGHT+CGI_SITE_DF_TOP_HEIGHT);
    pImg = gdImageCreateTrueColor(g_option.m_nImgXdim+CGI_SITE_DF_RIGHT_WIDTH,
                                  g_option.m_nImgYdim+CGI_SITE_DF_BOTTOM_HEIGHT);

    fnAllocColorTbl(pImg, pColor_ini, echoColorTbl, dispColorTbl);
    gdImageAlphaBlending(pImg_Border, 0);
    gdImageAlphaBlending(pImg, 0);
    gdImageSaveAlpha(pImg_Border, 1);  //이 두줄 있어야 배경 투명하게 됨.
    gdImageSaveAlpha(pImg, 1);  //이 두줄 있어야 배경 투명하게 됨.

    nWhite          = gdImageColorAllocate(pImg, 255, 255, 255);
    nBlack          = gdImageColorAllocate(pImg,  51,  51,  51);
    nRed            = gdImageColorAllocate(pImg, 255, 0, 0);
    nOutBound       = gdImageColorAllocate(pImg, 201,201,201);

    gdImageFilledRectangle(pImg_Border, 0, 0, g_option.m_nImgXdim+CGI_SITE_DF_RIGHT_WIDTH,
                                              g_option.m_nImgYdim+CGI_SITE_DF_BOTTOM_HEIGHT+CGI_SITE_DF_TOP_HEIGHT,
                                              nWhite);
    gdImageFilledRectangle(pImg, 0, 0, g_option.m_nImgXdim, g_option.m_nImgYdim, nWhite);

    for(nYIdx = 0; nYIdx < g_option.m_nImgYdim; nYIdx++)
    {
        for(nXIdx = 0; nXIdx < g_option.m_nImgXdim; nXIdx++)
        {
            if(g_pImgData[nYIdx][nXIdx] == OUT_BOUND_F)
            {
                gdImageSetPixel(pImg, nXIdx, nYIdx, nOutBound);
            }
            else if(g_pImgData[nYIdx][nXIdx] == BAD_VALUE_F)
            {
                gdImageSetPixel(pImg, nXIdx, nYIdx, nWhite);
            }
            else if(g_pImgData[nYIdx][nXIdx] != BAD_VALUE_F)
            {
                if(strcmp(g_option.m_szProductType, "VIL") != 0 && stColorInfo.m_nColorKind == CGI_EN_COLOR_RAIN)
                {
                        g_pImgData[nYIdx][nXIdx] = (float)fnDbz_To_R_f((double)g_pImgData[nYIdx][nXIdx],
                                                                            g_option.m_fZr_A, g_option.m_fZr_B);
                }
                if(g_pImgData[nYIdx][nXIdx] > stColorInfo.m_fMinValue)
                {
                    nColorIdx = fnGetColorLevel(g_pImgData[nYIdx][nXIdx], pColor_ini,
                                                stColorInfo.m_nColorKind, stColorInfo.m_fMinValue, 0, 0);
                    gdImageSetPixel(pImg, nXIdx, nYIdx, echoColorTbl[nColorIdx]);
                }
            }
        }
    }

    pImg_Top=fnSiteImgComment(g_option.m_tDataTime, g_option.m_szSiteName, g_option.m_szProductType, g_option.m_szDataType, g_option.m_nImgXdim+CGI_SITE_DF_RIGHT_WIDTH);

    fnDrawMap(pImg, g_site.m_fSiteLon, g_site.m_fSiteLat, g_option.m_nImgXdim/2, g_option.m_nImgYdim/2,
              g_option.m_fImgGridKm, dispColorTbl[CGI_EN_LINE_COLOR]);
    fnSiteAws(pImg, g_option.m_nImgXdim, g_option.m_nImgYdim, g_option.m_fImgGridKm,
              g_site.m_fSiteLon, g_site.m_fSiteLat, g_option.m_nImgXdim/2, g_option.m_nImgYdim/2,
              nRed, nBlack);
    fnDrawRangeRing(pImg, dispColorTbl[CGI_EN_LINE_COLOR], g_option.m_fImgGridKm, g_option.m_nImgYdim/2);
    fnDrawRangeDirection(pImg, dispColorTbl[CGI_EN_LINE_COLOR]);
    fnWriteSiteColorIndx(pImg, g_option.m_nImgXdim, g_option.m_nImgYdim, pColor_ini, echoColorTbl, stColorInfo, g_option.m_szDataType);

    if(strcmp(g_option.m_szProductType, "PPI") == 0)
        fProductArg = g_site.m_szInfoElv[g_option.m_nSweepNo];
    else
        fProductArg = g_option.m_fCappi_Alt;

    fnWriteBottomText(pImg, g_option.m_szQC_Type, g_option.m_szProductType, g_option.m_szDataType, 
                            fProductArg, g_site.m_fMaxRange, g_site.m_nGateSize, g_site.m_nBinCount, 
                            g_site.m_fNyqVel, g_option.m_nImgXdim, g_option.m_nImgYdim);
   
    gdImageRectangle(pImg, 0, 0, g_option.m_nImgXdim+CGI_SITE_DF_COLOR_BAR_WIDTH,
                     g_option.m_nImgYdim+CGI_SITE_DF_BOTTOM_HEIGHT-1, nBlack);


    gdImageCopy(pImg_Border, pImg_Top, 0,0,0,0, g_option.m_nImgXdim+CGI_SITE_DF_RIGHT_WIDTH, CGI_SITE_DF_TOP_HEIGHT);
    gdImageCopy(pImg_Border, pImg, 0,CGI_SITE_DF_TOP_HEIGHT, 0, 0, g_option.m_nImgXdim+CGI_SITE_DF_RIGHT_WIDTH,
                g_option.m_nImgYdim+CGI_SITE_DF_BOTTOM_HEIGHT);

    fprintf(stdout, "Content-type: image/png\r\n\r\n");
    gdImagePng(pImg_Border, stdout);
    fflush(stdout);
    
    gdImageDestroy(pImg_Border);
    gdImageDestroy(pImg);
    gdImageDestroy(pImg_Top);

    free(pColor_ini);

    return 0;
}

/* ================================================================================ */
// MAIN



/* ================================================================================ */
