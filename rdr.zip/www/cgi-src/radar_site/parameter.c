/* ================================================================================ */
// 2016. 7. 29
//
// SnK : Choi Hyun-Jun
//
// 파라미터 처리함수, 구조체 초기화 함수
//
/* ================================================================================ */
// INCLUDE

#include "cgi_site_common.h"

#include "main.h"
#include "parameter.h"

/* ================================================================================ */
// FUNCTION

int fnParamSet(void)
{
    char* szQueryString = NULL;
    char* szEqualPos = NULL;
    char* szToken = NULL;
    char szTemp[MAX_STR] = "";
    

    if((szQueryString = getenv("QUERY_STRING")) == NULL)
    {
        return -1;
    }

    snprintf(szTemp, sizeof(szTemp), "%s", szQueryString);
    
    szToken = strtok(szTemp, "&");
    
    while(szToken != NULL)
    {
        szEqualPos = strstr(szToken, "=");
        if(strncmp(szToken, "SITE_NAME", strlen("SITE_NAME")) == 0)
        {
            sprintf(g_option.m_szSiteName, "%s", szEqualPos+1);
        }
        else if(strncmp(szToken, "DATE", strlen("DATE")) == 0)
        {
            memset(&g_option.m_tFileTime, 0x00, sizeof(struct tm));
            strptime(szEqualPos+1, "%Y%m%d%H%M", &g_option.m_tFileTime);
        }
        else if(strncmp(szToken, "P_TYPE", strlen("P_TYPE")) == 0)
        {
            sprintf(g_option.m_szProductType, "%s", szEqualPos+1);
        }
        else if(strncmp(szToken, "D_TYPE", strlen("D_TYPE")) == 0)
        {
            sprintf(g_option.m_szDataType, "%s", szEqualPos+1);
        }
        else if(strncmp(szToken, "Q_TYPE", strlen("Q_TYPE")) == 0)        
        {
            sprintf(g_option.m_szQC_Type, "%s", szEqualPos+1);
        }
        else if(strncmp(szToken, "SWEEP_NO", strlen("SWEEP_NO")) == 0)
        {
            g_option.m_nSweepNo = atof(szEqualPos+1);
        }
        else if(strncmp(szToken, "CAPPI_ALT", strlen("CAPPI_ALT")) == 0)
        {
            g_option.m_fCappi_Alt = atof(szEqualPos+1);
        }
        szToken = strtok(NULL, "&");
    }
    return 0;
}
/* ================================================================================ */
