/* ================================================================================ */
//
// 2016.07.29
//
// SnK : Choi Hyun-Jun
//
/* ================================================================================ */

#ifndef DISP_ATOM7_H
#define DISP_ATOM7_H

int fnCreateImgAtom7(void);
void fnNoDataDisp_MAP_Atom7(char *szQC_Type, char *szProductType, char *szDataType, float fProductArg, float fMaxRange, int nGateSize, int nBinCount, float fNyqVel, int nImgXdim, int nImgYdim);

#endif