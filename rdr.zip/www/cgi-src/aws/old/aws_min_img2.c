/*******************************************************************************
**
**  AWS�� �ٶ����� ������ ǥ�� ���α׷�
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2014.8.18)
**
********************************************************************************/
#include "obj.h"
char *fontttf = "/usr/share/fonts/korean/TrueType/gulim.ttf";   // ����� �ѱ�TTF

struct INPUT_VAR var;           // ����� �Է� ����
struct STN_VAL stn_data[1000];  // ���� �ڷ�
float  **g, **g1;               // �����м����
float  **topo;          // �������� ����(m)
int    GX, GY, SX, SY;  // ��������(km)
int    trans = 0;       // ����ó�� ���� (obs=wv_10x)
FILE   *fp_log;

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main()
{
  int  i, j, k;

  // 0. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(60);

  printf("HTTP/1.0 200 OK\n");
  printf("Server: Netscape-Enterprise/3.0\n");
  //printf("Content-type: text/plain\n\n");

  // 1. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    printf("Content-type: text/plain\n\n");
    printf("# input variable error<p>\n");
    return -1;
  }

  // 2. ���ڿ��� �Ҵ� �� �ʱ�ȭ
  grid_map_inf(var.map, &GX, &GY, &SX, &SY);
  var.NX = (int)(GX/var.grid);   var.NY = (int)(GY/var.grid);

  g = matrix(0, var.NY, 0, var.NX);
  topo = matrix(0, var.NY, 0, var.NX);

  for (j = 0; j <= var.NY; j++) {
    for (i = 0; i <= var.NX; i++) {
      g[j][i] = -999;
      topo[j][i] = 0;
    }
  }

  // 3. ������� �б�
  stn_info_get();

  // 4. �����ڷ� �б�
  data_get();

  // 5. U���� �����м�
  grid_masking();   // �м����� Ȯ��
  topo_calc();      // �������� ������ �б�
  var.topo = 1;
  data_obj();       // �����м�

  // 6. V���� �����м�
  g1 = matrix(0, var.NY, 0, var.NX);

  for (j = 0; j <= var.NY; j++) {
    for (i = 0; i <= var.NX; i++)
      g1[j][i] = g[j][i];
  }

  for (k = 0; k < var.num_stn_obj; k++)
    stn_data[k].d = stn_data[k].v;
  data_obj();

  // 7. Ȯ��
  grid_zooming(g);
  grid_zooming(g1);
  stn_zooming();

  // 8. �̹��� ���� �� ����
  if (!strcmp(var.obs,"wv_10x")) trans = 1;
  aws_wind_img();

  // 9. �޸� �ݳ�
  free_matrix(g1, 0, var.NY, 0, var.NX);
  free_matrix(topo, 0, var.NY, 0, var.NX);
  free_matrix(g, 0, var.NY, 0, var.NX);

  alarm(0);
  return 0;
}

/*******************************************************************************
 *
 *  ������ �̹��� ���� �� ����
 *
 *******************************************************************************/
int aws_wind_img()
{
  gdImagePtr im;
  FILE  *fp;
  int   color_lvl[256];
  float data_lvl[256];

  // 1. �̹��� ���� ����
  if (var.title == 0)
    var.title_pixel = 0;
  else
    var.title_pixel = TITLE_pixel;

  var.NI = var.size;
  var.NJ = (int)((float)(var.NY)/(float)(var.NX)*var.NI);
  var.GI = var.NI;
  if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + var.title_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_table(im, color_lvl, data_lvl);
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[240]);

  // 3. �����ڷ� �׸���
  grid_disp(im, color_lvl, data_lvl);

  // 4. ���� �׸���
  if (trans != 1) {
    if (var.zoom_level >= 2) map_disp(im, color_lvl[249], 1);
    map_disp(im, color_lvl[242], 4);
  }

  // 5. ���� �׸�
  if (trans != 1) title_disp(im, color_lvl);

  // 6. ���� �׸���
  if (trans != 1) stn_disp(im, color_lvl);

  // 7. ���� �׸���
  if (trans != 1) {
    legend_disp(im, color_lvl, data_lvl);
    gdImageRectangle(im, 0, var.title_pixel, var.NI-1, var.GJ-1, color_lvl[242]);
  }

  // 8. �̹��� ����
  if (trans == 1) gdImageColorTransparent(im, color_lvl[240]);  // ����ó��

  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);
  return 0;
}

/*=============================================================================*
 *  ����ǥ
 *=============================================================================*/
int color_table(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  FILE  *fp;
  char  color_file[120];
  int   num_color;
  int   R, G, B;
  int   YY, MM, DD, HH, MI;
  float v1, diff;
  int   i, j, k;

  // 1. ��󺯼��� ����ǥ ���� ����
  strcpy(color_file,"/rdr/REF/COLOR/color_ws.rgb");

  // 2. ����ǥ ���ϰ� ������ �б�
  var.num_color = num_color = 0;
  if ((fp = fopen(color_file, "r")) != NULL) {
    while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
      color_lvl[num_color] = gdImageColorAllocate(im, R, G, B);
      data_lvl[num_color] = v1;
      num_color++;
      if (num_color > 119) break;
    }
    fclose(fp);
  }
  else {
    num_color = -1;
  }
  var.num_color = num_color;

  // 3. ��Ÿ ����ǥ ����
  color_lvl[240] = gdImageColorAllocate(im, 210, 210, 210);   // ����1
  color_lvl[241] = gdImageColorAllocate(im, 255, 255, 255);   // ����2
  color_lvl[242] = gdImageColorAllocate(im, 30, 30, 30);      // ������
  color_lvl[243] = gdImageColorAllocate(im, 12, 28, 236);     // ����
  color_lvl[244] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  color_lvl[245] = gdImageColorAllocate(im, 240, 240, 240);
  color_lvl[246] = gdImageColorAllocate(im, 255, 0, 0);
  color_lvl[247] = gdImageColorAllocate(im, 0, 0, 255);
  color_lvl[248] = gdImageColorAllocate(im, 150, 150, 150);   // ����3
  color_lvl[249] = gdImageColorAllocate(im, 90, 90, 90);      // �ñ����

  return num_color;
}

/*=============================================================================*
 *  �����ڷ� ǥ��
 *=============================================================================*/
int grid_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  float x, y, dx, dy, d1, d2, dd, uu1, vv1, ws;
  float Vs, As, hs, a, b, theta0, theta1, theta, zm;
  int   i, j, k, ix, iy, color1;
  int   x1, y1, x2, y2, x3, y3;
  int   ng;

  // 0. ����ó��
  if (var.num_stn_obj <= 0) {
    gdImageString(im, gdFontLarge, 100, 100, "No Data", color_lvl[244]);
    return -1;
  }
  if (var.num_color <= 0) {
    gdImageString(im, gdFontLarge, 100, 100, "No Color Level", color_lvl[244]);
    return -1;
  }

  // 1. �ٶ����͸� ���� ����
  if (trans != 1) {
    for (j = 1; j < var.NJ; j++) {
      iy = j*(float)(var.NY)/(float)(var.NJ);

      for (i = 1; i < var.NI; i++) {
        ix = i*(float)(var.NX)/(float)(var.NI);
        if (g[iy][ix] >= -80 && g1[iy][ix] >= -80) gdImageSetPixel(im, i, var.GJ-j, color_lvl[248]);
      }
    }
  }

  // 2. �ٶ����� ǥ�� ����(���ڰ��ݿ� ����)
  if (var.zoom_level == 0)
    ng = 8;
  else
    ng = 8;

  // 3. �ٶ����� ǥ��
  for (iy = 1; iy < var.NY; iy += ng) {
    j = iy*(float)(var.NJ)/(float)(var.NY);

    for (ix = 1; ix < var.NX; ix += ng) {
      i = ix*(float)(var.NI)/(float)(var.NX);

      // 3.1. �ش� �̹��� �ȼ� ��ġ�� ���� ���
      uu1 = g1[iy][ix];
      vv1 = g[iy][ix];
      if (uu1 < -90 || vv1 < -90) continue;

      // 3.2. ǳ������ ����ǥ ����
      ws = sqrt(uu1*uu1 + vv1*vv1);
      color1 = color_lvl[var.num_color-1];
      for (k = 0; k < var.num_color; k++) {
        if (ws <= data_lvl[k]) {
          color1 = color_lvl[k];
          break;
        }
      }

      // 3.3. ȭ��� ǥ��
      if (trans == 1) color1 = color_lvl[244];
      wind_arrow(im, (float)i, (float)(var.GJ-j), uu1, vv1, ws, color1);
    }
  }
  return 0;
}

/*============================================================================*
 *  Wind Arrow (�ܳ� ȭ��)
 *============================================================================*/
int wind_arrow(im, x0, y0, u, v, ws, color)
  gdImagePtr im;
  float  x0, y0;
  float  u, v, ws;
  int    color;
{
  float  vs1 = 6.0, vs2 = 5.0;
  float  theta, theta0, theta1, a, b, hs;
  int    x1, y1, x2, y2, x3, y3;

  // ��ǳ�� ����� ���
  if (ws < 0.4) {
    gdImageFilledRectangle(im, x0, y0, x0+1, y0+1, color);
    return 0;
  }

  // ����ȭ
  u /= ws;  v /= ws;
  vs1 = log10(ws + 0.1)*10;

  // ȭ���
  x1 = x0 - vs1*u;  y1 = y0 + vs1*v;
  x2 = x0 + vs1*u;  y2 = y0 - vs1*v;
  gdImageLine(im, (int)x1, (int)y1, (int)x2, (int)y2, color);
  if (ws >= 40) gdImageLine(im, (int)x1, (int)y1+1, (int)x2, (int)y2+1, color);

  // ȭ����
  if (ws < 3.5)
    vs2 = 3.0;
  else if (ws <= 10)
    vs2 = 6.0;
  else
    vs2 = 9.0;

  theta0 = 160.0*DEGRAD;
  theta1 = atan2(v, u);
  theta  = theta1 + theta0;
  x3 = x2 + vs2*cos(theta);
  y3 = y2 - vs2*sin(theta);
  gdImageLine(im, (int)x2, (int)y2, (int)x3, (int)y3, color);

  return 0;
}
/*============================================================================*
 *  Wind Arrow (5m/s ����) (ǳ���� ũ�� ȭ�쵵 Ŀ��)
 *============================================================================*/
int wind_arrow1(im, x0, y0, u, v, ws, color)
  gdImagePtr im;
  float  x0, y0;
  float  u, v, ws;
  int    color;
{
  int    x1, y1, x2, y2, x3, y3;
  float  theta, theta0, theta1, a, b, hs;
  float  zm = 1.0/((float)(var.NX)/(float)(var.NI)*var.grid);
  float  Vs = 2.0, As = 1.8;             // 10m/sec�� ������ *0.5

  // ȭ���
  x1 = x0 - (Vs * u)*zm;
  y1 = y0 + (Vs * v)*zm;
  x2 = x0 + (Vs * u)*zm;
  y2 = y0 - (Vs * v)*zm;
  gdImageLine(im, (int)x1, (int)y1, (int)x2, (int)y2, color);

  // ȭ����
  if (ws > 0.2) {
    theta0 = 170.0*DEGRAD;

    theta1 = atan2(v, u);
    theta  = theta1 + theta0;
    hs = As * ws;
    a  = hs * cos(theta);
    b  = hs * sin(theta);
    x3 = x2 + a*zm;
    y3 = y2 - b*zm;
    gdImageLine(im, (int)x2, (int)y2, (int)x3, (int)y3, color);

    theta = theta1 - theta0;
    hs = As * ws;
    a  = hs * cos(theta);
    b  = hs * sin(theta);
    x3 = x2 + a*zm;
    y3 = y2 - b*zm;
    gdImageLine(im, (int)x2, (int)y2, (int)x3, (int)y3, color);
  }
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int map_disp(gdImagePtr im, int color_map, int kind)
{
  FILE  *fp;
  char  fname[120];
  float zm = 1.0, xo = 0.0, yo = 0.0, x1, y1, x2, y2;
  int   zx, zy, mode;
  int   i, j, k, n;

  // 1. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    if (var.zoom_rate == 3) {
      for (i = 0; i < 2; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/9.0*(zx-1)/zm;
        yo += (float)(var.NY)/9.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
    else if (var.zoom_rate == 2) {
      for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/8.0*(zx-1)/zm;
        yo += (float)(var.NY)/8.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
  }

  // 2. �ؾȼ� ǥ��
  sprintf(fname, "/DATA/GIS/MAP/dat/AFS_%s_map%d.dat", var.map, kind);
  if ((fp = fopen(fname, "r")) != NULL) {
    while (fscanf(fp, "%d %d\n", &n, &mode) != EOF) {
      for (i = 0; i < n; i++) {
        fscanf(fp, "%f %f\n", &x2, &y2);
        x2 /= var.grid;
        y2 /= var.grid;

        if (var.zoom_level > 0) {
          x2 = zm*(x2-xo);
          y2 = zm*(y2-yo);
        }
        x2 *= ((float)(var.NI)/(float)(var.NX));
        y2 *= ((float)(var.NI)/(float)(var.NX));
        if (i > 0) {
          gdImageLine(im, (int)x1, var.GJ-(int)y1, (int)x2, var.GJ-(int)y2, color_map);
          if (kind == 4 && var.zoom_level >= 2) gdImageLine(im, (int)x1, var.GJ-(int)y1-1, (int)x2, var.GJ-(int)y2-1, color_map);
        }
        x1 = x2;
        y1 = y2;
      }
    }
    fclose(fp);
  }

  return 0;
}

/*=============================================================================*
 *  ������ ǥ��
 *=============================================================================*/
int stn_disp(gdImagePtr im, int color_lvl[])
{
  float  wr, ang, ws, ang_s, wr_s;
  float  data_min = 99999, data_max = -99999, d1;
  char   txt[20];
  int    x, y, x1, y1, x2, y2;
  int    stn_min = 0, stn_max = 0;
  int    color_dot, maxmin;
  int    i, j, k;

  // 1. ���� ǥ�⿩�� Ȯ��
  if (var.stn == 0 || !strcmp(var.obs,"rn_ex")) return 0;

  // 2. ���� ���� ǥ��
  if (var.num_stn_area > 0 && var.size*var.size/var.num_stn_area > 60*60) {
    for (k = 0; k < var.num_stn_obj; k++) {
      x = stn_data[k].x*var.NI/var.NX;
      y = var.GJ - stn_data[k].y*var.NI/var.NX;
      wr = 30;

      // 2.1. ǳ��� ǥ��
      if (stn_data[k].wd >= 0 && stn_data[k].ws > 0.2) {
        ang = stn_data[k].wd*DEGRAD;
        x1 = x + wr*sin(ang);
        y1 = y - wr*cos(ang);
        gdImageLine(im, x, y, x1, y1, color_lvl[244]);
      }

      // 2.2. ǳ�ӱ� ǥ��
      if (stn_data[k].wd >= 0 && stn_data[k].ws > 0.2) {
        ws = stn_data[k].ws;
        ang_s = (stn_data[k].wd + 60.0)*DEGRAD;

        while (ws > 0.0) {
          if (ws >= 5.0) wr_s = 20.0;
          else           wr_s = 4.0*ws;

          x2 = x1 + wr_s*sin(ang_s);
          y2 = y1 - wr_s*cos(ang_s);
          gdImageLine(im, x1, y1, x2, y2, color_lvl[244]);

          ws -= 5.0;
          wr -= 5.0;
          x1 = x + wr*sin(ang);
          y1 = y - wr*cos(ang);
        }
      }

      // 2.3. �������� ǥ��
      color_dot = color_lvl[246];
      if (stn_data[k].re == 1) color_dot = color_lvl[247];
      gdImageFilledArc(im, x, y, 8, 8, 0, 360, color_lvl[245], gdArc);
      gdImageFilledArc(im, x, y, 5, 5, 0, 360, color_dot, gdArc);

      // 2.4. �� ǥ��
      x -= 10;  y += 3;
      sprintf(txt, "%.1f", stn_data[k].ws);
      gdImageString(im, gdFontMediumBold, x-1, y-1, txt, color_lvl[245]);
      gdImageString(im, gdFontMediumBold, x-1, y+1, txt, color_lvl[245]);
      gdImageString(im, gdFontMediumBold, x+1, y+1, txt, color_lvl[245]);
      gdImageString(im, gdFontMediumBold, x+1, y-1, txt, color_lvl[245]);
      gdImageString(im, gdFontMediumBold, x,   y,   txt, color_lvl[246]);
    }
  }

  // 3. �ִ밪 ǥ�� (�ٶ������� ���)
  if (var.size*(var.zoom_level+1) > 100) {
    // 3.1. ��󺯼��� ǥ�� ��� ����
    maxmin = 2;

    // 3.2. �ּ�,�ִ밪�� ���� Ȯ��
    for (k = 0; k < var.num_stn_obj; k++) {
      if (stn_data[k].x > 0 && stn_data[k].x < var.NX && stn_data[k].y > 0 && stn_data[k].y < var.NY) {
        d1 = stn_data[k].ws;
        if (data_min > d1) { stn_min = k;  data_min = d1; }
        if (data_max < d1) { stn_max = k;  data_max = d1; }
      }
    }

    // 3.3. ���� ǥ��
    for (i = 1; i <= 2; i++) {
      if (maxmin == i || maxmin == 3) {
        if (i == 1) k = stn_min;
        if (i == 2) k = stn_max;

        // ��ġ ���
        x = stn_data[k].x*var.NI/var.NX;
        y = var.GJ - stn_data[k].y*var.NI/var.NX;

        // ���� ǥ��
        color_dot = color_lvl[246];
        if (stn_data[k].re == 1) color_dot = color_lvl[247];
        gdImageFilledArc(im, x, y, 8, 8, 0, 360, color_lvl[245], gdArc);
        gdImageFilledArc(im, x, y, 5, 5, 0, 360, color_lvl[246], gdArc);

        // �� ǥ��
        x -= 10;  y += 3;
        sprintf(txt, "%.1f", stn_data[k].ws);
        gdImageString(im, gdFontMediumBold, x-1, y-1, txt, color_lvl[245]);
        gdImageString(im, gdFontMediumBold, x-1, y+1, txt, color_lvl[245]);
        gdImageString(im, gdFontMediumBold, x+1, y+1, txt, color_lvl[245]);
        gdImageString(im, gdFontMediumBold, x+1, y-1, txt, color_lvl[245]);
        gdImageString(im, gdFontMediumBold, x,   y,   txt, color_lvl[246]);
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  EUC-KR���ڿ��� UTF-8�� ��ȯ
 *=============================================================================*/
int euckr2utf(char *str, char *out)
{
    iconv_t convp;
    size_t  ileft, oleft;
    int     err, len = strlen(str);

    ileft = len;
    oleft = len * 2;

    convp = iconv_open("UTF-8", "euc-kr");
    err = iconv(convp, &str, &ileft, &out, &oleft);
    iconv_close(convp);

    return err;
}

/*=============================================================================*
 *  ���� ǥ��(�ѱ�ó��)
 *=============================================================================*/
int title_disp(gdImagePtr im, int color_lvl[])
{
  char   title[80], gov_name[40], tm_fc_str[40], num_stn_str[10], tmp[50];
  char   title_utf[100], gov_utf[100];
  double font_size = 11.5;
  int    brect[8];
  int    YY, MM, DD, HH, MI;
  int    ok_kma, ok_tot, ok_oth;
  int    x, i, k;

  // 1. ���񿵿��� ���� ó��
  gdImageFilledRectangle(im, 0, 0, var.GI, var.title_pixel, color_lvl[241]);

  // 2. ������
  if      (!strcmp(var.obs,"wv_01m")) strcpy(title,"�ٶ�(1��)");
  else if (!strcmp(var.obs,"wv_10m")) strcpy(title,"�ٶ�(10��)");
  else if (!strcmp(var.obs,"wv_ins")) strcpy(title,"���� �ٶ�");

  for (i = 0; i < 100; i++)
    title_utf[i] = 0;
  euckr2utf(title, title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, font_size, 0.0, 5, (int)(font_size+5), title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, font_size, 0.0, 6, (int)(font_size+5), title_utf);

  // 3. �ð� ���ڿ� 
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'y');
  sprintf(tm_fc_str, "%04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, MI);

  gdImageString(im, gdFontLarge, 125, 1, tm_fc_str, color_lvl[244]);
  gdImageString(im, gdFontLarge, 126, 1, tm_fc_str, color_lvl[244]);

  // 4. ǥ�⿵���� ������ ǥ��
  for (var.num_stn_area = 0, k = 0; k < var.num_stn_obj; k++) {
    if (stn_data[k].x > 0 && stn_data[k].x < var.NX && stn_data[k].y > 0 && stn_data[k].y < var.NY)
      var.num_stn_area++;
  }
  sprintf(num_stn_str, "#%d", var.num_stn_area);
  gdImageFilledRectangle(im, var.NI-38, var.GJ-16, var.NI-2, var.GJ-2, color_lvl[241]);
  gdImageString(im, gdFontMediumBold, var.NI-35, var.GJ-15, num_stn_str, color_lvl[244]);

  // 5. ��� ǥ��
  if (!strcmp(var.obs,"uw_10m"))
    strcpy(gov_name, "[ ��������û ]");
  else {
    ok_kma = ok_tot = ok_oth = 0;
    for (i = 0; i < var.num_gov; i++) {
      if (strcmp(var.gov_cd[i],"KMA") == 0) ok_kma = 1;
      if (strcmp(var.gov_cd[i],"TOT") == 0) ok_tot = 1;
      if (strcmp(var.gov_cd[i],"OTH") == 0) ok_oth = 1;
    }

    if (ok_kma) {
      if (ok_tot == 1) {
        strcpy(gov_name, "[ ���û+���� ]");
      }
      else {
        if (var.num_gov == 1)
          strcpy(gov_name, "[ ���û ]");
        else if (var.num_gov == 2) {
          if (strcmp(var.gov_cd[1],"GFR") == 0)
            strcpy(gov_name, "[ ���û+�긲û ]");
          else
            strcpy(gov_name, "[ ���û+���� ]");
        }
        else
          strcpy(gov_name, "[ ���û+���� ]");
      }
    }
    else {
      if (ok_oth == 1) {
        strcpy(gov_name, "[ ��������� ]");
      }
      else {
        if (var.num_gov == 1)
          strcpy(gov_name, "[ ������� ]");
        else
          strcpy(gov_name, "[ ��������� ]");
      }
    }
  }
  gdImageFilledRectangle(im, 0, var.title_pixel+1, strlen(gov_name)*7, var.title_pixel*2-3, color_lvl[241]);

  for (i = 0; i < 100; i++)
    gov_utf[i] = 0;
  euckr2utf(gov_name, gov_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, 10.0, 0.0, 5, var.title_pixel*2-5, gov_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, 10.0, 0.0, 6, var.title_pixel*2-5, gov_utf);

  // 5. Sample Arrow
  //wind_arrow(im, (float)(var.NI-45), (float)var.title_pixel/2.0, 5.0, 0.0, 5.0, color_lvl[244]);
  //gdImageString(im, gdFontMediumBold, var.NI-30, 5, (unsigned char *)"5m/s", color_lvl[244]);

  return 0;
}

/*=============================================================================*
 *  ���� ǥ��(�ѱ�TTFó���� �ȵɶ�)
 *=============================================================================*/
/*
int title_disp(gdImagePtr im, int color_lvl[])
{
  gdImagePtr im1;
  FILE  *fp;
  char  fname[120], title[80], tm_fc_str[40], num_stn_str[10];
  int   YY, MM, DD, HH, MI;
  int   x, k;

  // 1. ���񿵿��� ���� ó��
  gdImageFilledRectangle(im, 0, 0, var.GI, var.title_pixel, color_lvl[241]);

  // 2. �ð� ���ڿ�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  if (HH*100+MI == 0) {
    seq2time(var.seq-1, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    sprintf(tm_fc_str, "%04d.%02d.%02d.24:00", YY, MM, DD);
  }
  else
    sprintf(tm_fc_str, "%04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, MI);

  // 3. �������� �̹��� ������ �ִ� ���
  sprintf(fname, "/fct/www/ROOT/aws/icon/title_%s.png", var.obs);
  if ((fp = fopen(fname,"rb")) != NULL)
  {
    // 3.1. ������
    im1 = gdImageCreateFromPng(fp);
    gdImageCopy(im, im1, 1, 1, 0, 0, gdImageSX(im1), gdImageSY(im1));

    // 3.2. �ð�
    x = gdImageSX(im1) + 10;
    gdImageString(im, gdFontLarge, x, 1, tm_fc_str, color_lvl[244]);
    gdImageString(im, gdFontLarge, x+1, 1, tm_fc_str, color_lvl[244]);
    gdImageDestroy(im1);
  }

  // 4. ������ ������ ���� ���
  else {
    if      (!strcmp(var.obs,"wv_01m")) strcpy(title,"Wind(1min)");
    else if (!strcmp(var.obs,"wv_10m")) strcpy(title,"Wind(10min)");
    else if (!strcmp(var.obs,"wv_ins")) strcpy(title,"Ins. Wind");

    strcat(title, " / ");
    strcat(title, tm_fc_str);
    gdImageString(im, gdFontLarge, 5, 1, title, color_lvl[244]);
    gdImageString(im, gdFontLarge, 6, 1, title, color_lvl[244]);
  }

  // 5. ǥ�⿵���� ������ ǥ��
  for (var.num_stn_area = 0, k = 0; k < var.num_stn_obj; k++) {
    if (stn_data[k].x > 0 && stn_data[k].x < var.NX && stn_data[k].y > 0 && stn_data[k].y < var.NY)
      var.num_stn_area++;
  }
  sprintf(num_stn_str, "#%d", var.num_stn_area);
  gdImageFilledRectangle(im, var.NI-38, var.GJ-16, var.NI-2, var.GJ-2, color_lvl[241]);
  gdImageString(im, gdFontMediumBold, var.NI-35, var.GJ-15, num_stn_str, color_lvl[244]);

  // 6. Sample Arrow
  wind_arrow(im, (float)(var.NI-45), (float)var.title_pixel/2.0, 5.0, 0.0, 5.0, color_lvl[244]);
  gdImageString(im, gdFontMediumBold, var.NI-30, 5, (unsigned char *)"5m/s", color_lvl[244]);

  return 0;
}
*/

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int legend_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  char   txt[20];
  float  dy = (float)(var.NJ)/(float)(var.num_color);
  int    y, k;

  if (var.legend != 1) return 0;
  if (var.num_color <= 0) return -1;

  // 1. ���� ���� ǥ��
  for (k = 0; k < var.num_color; k++) {
    y = var.GJ - dy*k;
    gdImageFilledRectangle(im, var.NI, y-dy, var.NI+8, y, color_lvl[k]);
  }
  gdImageRectangle(im, var.NI-1, var.title_pixel, var.NI+8, var.GJ-1, color_lvl[242]);

  // 2. ���ʰ� ǥ��
  gdImageFilledRectangle(im, var.NI+9, 0, var.GI-1, var.GJ, color_lvl[241]);
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      if (data_lvl[k] >= 10)
        sprintf(txt, "%.0f", data_lvl[k]);
      else
        sprintf(txt, "%.1f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }

  // 3. ���� ���� ǥ��
  strcpy(txt,"m/s");
  gdImageString(im, gdFontLarge, var.NI+3, 4, txt, color_lvl[244]);
  return 0;
}
