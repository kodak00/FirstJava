/*******************************************************************************
**
**  AWS �����м�
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2014.6.2)
**
********************************************************************************/
#include "obj.h"

extern struct INPUT_VAR var;       // ����� �Է� ����
extern struct STN_VAL stn_data[];  // ���� �ڷ�
extern float  **g;     // �����м����
extern float  **topo;  // �������� ����(m)
extern int    GX, GY, SX, SY;  // ��������(km)

// ���׿��� ����ŷ ����
#define  MAP_INI_FILE   "/rdr/REF/MAP/map.ini"
#define  DFS_MASK_FILE  "/rdr/REF/MAP/landseamask.dat"

// ���׿��� ����
#define  DFS_NX   149   // ���������� �糡���� ���Ե� (5km����)
#define  DFS_NY   253
#define  DFS_SX   43    // 5km �������� �糡���� ���Ե�
#define  DFS_SY   136

/*******************************************************************************
 *
 *  ���ڿ������� ���� ����� ������ ���� (AWS ������ ���׿��� ����ŷ ������ Ȱ��)
 *
 *******************************************************************************/
int grid_masking()
{
  FILE   *fp;
  unsigned char dfs_mask[DFS_NY][DFS_NX];
  int    xo, yo, x1, y1, x2, y2, zb = 4;
  int    i, j, i1, j1, k;

  // 3. ���׿��� ����ŷ ������ Ȱ���Ͽ� 1�ܰ� ����ŷ
  if ((fp = fopen(DFS_MASK_FILE, "r")) != NULL) {
    fread(dfs_mask, 1, DFS_NY*DFS_NX, fp);
    fclose(fp);

    for (j = 0; j <= var.NY; j++) {
      j1 = (int)(((DFS_SY-1)*5 - SY + j*var.grid )/5);

      for (i = 0; i <= var.NX; i++) {
        i1 = (int)(((DFS_SX-1)*5 - SX + i*var.grid )/5);

        if (i1 >= 0 && i1 <= DFS_NX && j1 >= 0 && j1 <= DFS_NY) {
          if (dfs_mask[j1][i1]%10 == 1 && dfs_mask[j1][i1] < 70) g[j][i] = 1;
        }
      }
    }
  }
  else
    printf("# file not opened (%s)\n", DFS_MASK_FILE);
 
  // 4. ������������ 2�ܰ� ����ŷ ���� ����
  if (!strncmp(var.obs,"wv",2)) zb = (int)(24.0/var.grid);

  for (k = 0; k < var.num_stn_obj; k++) {
    xo = (int)(stn_data[k].x + 0.5);  yo = (int)(stn_data[k].y + 0.5);
    x1 = xo - zb;  x2 = xo + zb;
    y1 = yo - zb;  y2 = yo + zb;
    if (x1 < 0 ) x1 = 0;  if (x2 > var.NX) x2 = var.NX;
    if (y1 < 0 ) y1 = 0;  if (y2 > var.NY) y2 = var.NY;

    for (j = y1; j <= y2; j++) {
      for (i = x1; i <= x2; i++)
        g[j][i] = 1;
    }
  }
  return 0;
}

/*******************************************************************************
 *
 *  �ػ��ڷ��� ���, ���ڿ������� ���� ����� ������ ����
 *
 *******************************************************************************/
int grid_masking_sea()
{
  FILE   *fp;
  unsigned char dfs_mask[DFS_NY][DFS_NX];
  int    xo, yo, x1, y1, x2, y2, zb = 12;
  int    i, j, i1, j1, k;

  // 3. ������ ������������ 1�ܰ� ����ŷ ���� ����
  for (k = 0; k < var.num_stn_obj; k++) {
    xo = (int)(stn_data[k].x + 0.5);  yo = (int)(stn_data[k].y + 0.5);
    x1 = xo - zb;  x2 = xo + zb;
    y1 = yo - zb;  y2 = yo + zb;
    if (x1 < 0 ) x1 = 0;  if (x2 > var.NX) x2 = var.NX;
    if (y1 < 0 ) y1 = 0;  if (y2 > var.NY) y2 = var.NY;

    for (j = y1; j <= y2; j++) {
      for (i = x1; i <= x2; i++)
        g[j][i] = 1;
    }
  }
  return 0;
}

/*******************************************************************************
 *
 *  �������� ��������(m) ���
 *
 *******************************************************************************/
int topo_calc()
{
  FILE   *fp;
  char   fname[120];
  float  **ht, ta, hm;
  short  *com;
  int    Bmap_NX = 1152, Bmap_NY = 1440, Bmap_SX = 560, Bmap_SY = 840, Bmap_Grid = 1.0; // Bmap ����
  int    GX, GY, SX, SY;
  int    ok = 0;
  int    i, j, k, n, ii, jj, i1, i2, j1, j2;

  // 0. ����ȿ���� �ʿ��Ҷ��� �����
  if (var.topo == 0) return 0;

  // 1. ���� ���� ���� Ȯ�� �� �ڷ� �б�
  strcpy(fname, "/C4N2_DATA/GIS/TOPO/SRTM/topo_mapB_1km.bin");
  if ((fp = fopen(fname, "rb")) == NULL) return -1;

  // 2. �б�
  fseek(fp, 64, SEEK_SET);
  com = svector(0, Bmap_NX);
  ht = matrix(0, Bmap_NY, 0, Bmap_NX);
  for (j = 0; j <= Bmap_NY; j++) {
    n = fread(com, 2, Bmap_NX+1, fp);
    for (i = 0; i < Bmap_NX; i++)
      ht[j][i] = 0.1*com[i];
  }
  free_vector(com, 0, Bmap_NX);
  fclose(fp);

  // 3. �ѹ� ��Ȱȭ��
  grid_smooth(ht, Bmap_NX, Bmap_NY, -1);

  // 4. �ڷ� ��ȯ
  grid_map_inf(var.map, &GX, &GY, &SX, &SY);

  for (j = 0; j <= var.NY; j++) {
    j1 = (int)((j*var.grid + Bmap_Grid*Bmap_SY - SY)/Bmap_Grid + 0.5);
    for (i = 0; i <= var.NX; i++) {
      i1 = (int)((i*var.grid + Bmap_Grid*Bmap_SX - SX)/Bmap_Grid + 0.5);
      if (j1 < 0 || j1 > Bmap_NY || i1 < 0 || i1 > Bmap_NX)
        topo[j][i] = -999;
      else
        topo[j][i] = ht[j1][i1];
    }
  }
  free_smatrix(ht, 0, Bmap_NY, 0, Bmap_NX);
  return 0;
}

/*******************************************************************************
 *
 *  ����ȿ�� �ݿ��� �ʿ��� ���� ����
 *
 *******************************************************************************/
int topo_effect()
{
  char   obs[16];
  float  **g1, **g2, ta, hm, rs, vs;
  int    ok;
  int    i, j, k, n;

  // 0. ����ȿ���� �ʿ��Ҷ��� �����
  if (var.topo == 0) return 0;

  // 1. �ش� �������� ���� Ȯ��
  ok = 0;
  if (!strcmp(var.obs,"hm_tpo")) ok = 1;
  if (!strcmp(var.obs,"tw_tpo")) ok = 1;
  if (!strcmp(var.obs,"ww_lee")) ok = 1;
  if (!strcmp(var.obs,"ww_aws")) ok = 1;
  if (ok == 0) return 0;

  // 2. �ӽ� �迭 Ȯ��
  g2 = matrix(0, var.NY, 0, var.NX);
  g1 = matrix(0, var.NY, 0, var.NX);
  strcpy(obs, var.obs);

  // 3. ��ȭ������� ��� �� ��� ��� ����
  for (j = 0; j <= var.NY; j++) {
    for (i = 0; i <= var.NX; i++) {
      ta = g[j][i];
      g2[j][i] = ta;
      if (ta > -40 && ta < 45)
        g1[j][i] = 6.112*exp((17.67*ta)/(ta+243.5));
      else
        g1[j][i] = -999;
    }
  }

  // 4. ������� ���
  strcpy(var.obs,"pv");  strcpy(var.obs_cd,"HM");  var.varn = 9;
  stn_info_get();
  data_get();
  var.topo = 0;
  data_obj();

  // 5. ������ ���
  for (j = 0; j <= var.NY; j++) {
    for (i = 0; i <= var.NX; i++) {
      if (g[j][i] > 0 && g1[j][i] > 0) {
        g[j][i] = 100.0*g[j][i]/g1[j][i];
        if (g[j][i] > 100) g[j][i] = 100;
      }
      else
        g[j][i] = -999;
    }
  }

  // 6. �����µ�(����) ���
  if (!strcmp(obs,"tw_tpo")) {
    for (j = 0; j <= var.NY; j++) {
      for (i = 0; i <= var.NX; i++) {
        ta = g2[j][i];
        hm = g[j][i];
        if (ta < -40 || ta > 45 || hm < 1 || hm > 100)
          g[j][i] = -999;
        else
          g[j][i] = ta*atan(0.151977*sqrt(hm+8.313659)) + atan(ta+hm) - atan(hm-1.676331) + 0.00391838*pow(hm,1.5)*atan(0.023101*hm) - 4.68035;
      }
    }
  }

  // 7. ����:���ɿ��� ��� (1:��, 2:��/��, 3:��)
  if (!strcmp(obs,"ww_lee")) {
    for (j = 0; j <= var.NY; j++) {
      for (i = 0; i <= var.NX; i++) {
        ta = g2[j][i];
        hm = g[j][i];
        if (ta < -40 || ta > 45 || hm < 1 || hm > 100)
          g[j][i] = -999;
        else {
          if (hm >= -12*ta+120)
            g[j][i] = 1;
          else if ((ta > 0.9 && hm < 89.5-ta*100/13) || (ta <= 0.9 && hm < 75))
            g[j][i] = 3;
          else if (hm >= 75 && ta <= 0.9 && hm < 102.5-ta*100.0/13.0)
            g[j][i] = 3;
          else
            g[j][i] = 2;
        }
      }
    }
  }

  // 8. ���� �� ������� ���� ǥ��
  if (!strcmp(obs,"ww_aws")) {
    // 8.1. ����:���ɿ��� ���
    for (j = 0; j <= var.NY; j++) {
      for (i = 0; i <= var.NX; i++) {
        ta = g2[j][i];
        hm = g[j][i];
        g1[j][i] = hm;
        if (ta < -40 || ta > 45 || hm < 1 || hm > 100)
          g2[j][i] = -999;
        else {
          if (hm >= -12*ta+120)
            g2[j][i] = 1;
          else if ((ta > 0.9 && hm < 89.5-ta*100/13) || (ta <= 0.9 && hm < 75))
            g2[j][i] = 3;
          else if (hm >= 75 && ta <= 0.9 && hm < 102.5-ta*100.0/13.0)
            g2[j][i] = 3;
          else
            g2[j][i] = 2;
        }
      }
    }

    // 8.2. �������� ���� ���
    strcpy(var.obs,"rn_ex");  strcpy(var.obs_cd,"RE");  var.varn = 7;  var.missing = -1;  var.max = 1000;
    stn_info_get();
    data_get();
    var.topo = 0;
    data_obj();

    for (j = 0; j <= var.NY; j++) {
      for (i = 0; i <= var.NX; i++) {
        if (g[j][i] <= 0.15 && g2[j][i] > 0)
          g2[j][i] = -0.5;
      }
    }

    // 8.3. ������ ���
    strcpy(var.obs,"vs");  strcpy(var.obs_cd,"VS");  var.varn = 28;  var.missing = 0;  var.max = 60000;
    stn_info_get();
    data_get();
    var.topo = 0;
    data_obj();

    // 8.4. ����,����,�������� ���� �Ǻ�
    for (j = 0; j <= var.NY; j++) {
      for (i = 0; i <= var.NX; i++) {
        rs = g2[j][i];    // ����
        hm = g1[j][i];    // ����
        vs = g[j][i];     // ����
        if (rs > 0.1)
          g[j][i] = rs;
        else if (rs > -1.0) {
          if (vs <= 1.0) {
            if (hm >= 70)
              g[j][i] = 4;  // �Ȱ�
            else
              g[j][i] = 6;  // ����
          }
          else if (vs < 10) {
            if (hm >= 75)
              g[j][i] = 5;  // �ڹ�
            else
              g[j][i] = 6;  // ����
          }
          else {
            if (vs > 0)
              g[j][i] = 0;
            else
              g[j][i] = -999;
          }
        }
        else {
          g[j][i] = -999;
        }
      }
    }
  }

  // 9. �ӽ� �迭���� ����
  strcpy(var.obs,obs);
  free_matrix(g1, 0, var.NY, 0, var.NX);
  free_matrix(g2, 0, var.NY, 0, var.NX);
  return 0;
}

/*******************************************************************************
 *
 *  �����м�
 *
 *******************************************************************************/
int data_obj()
{
  if (var.num_stn_obj <= 0) return 0;

  if (!strcmp(var.obj,"mq"))
    data_obj_mq();
  else
    data_obj_bn();

  return 0;
}

/*******************************************************************************
 *
 *  �����м� (MQ ���)
 *
 *******************************************************************************/
int data_obj_mq()
{
  float  data_min, data_max, data_avg, d1;
  float  *x, *y, *z;
  double *v, *s, mp = 0.0005, sm = 100;
  double minv, maxv;
  int    i, j, k;

  // 0. �迭����
  x = vector(0, var.num_stn_obj);
  y = vector(0, var.num_stn_obj);
  z = vector(0, var.num_stn_obj);
  v = dvector(0, var.num_stn_obj);
  s = dvector(0, var.num_stn_obj);

  // 1. �����м� ��� �����鿡�� �ִ�,�ּҰ� Ȯ��
  data_min = 99999;  data_max = -99999;  data_avg = 0;
  for (k = 0; k < var.num_stn_obj; k++) {
    d1 = stn_data[k].d;
    if (!strncmp(var.obs,"wv",2)) d1 = stn_data[k].ws;
    if (data_min > d1) data_min = d1;
    if (data_max < d1) data_max = d1;
    data_avg += d1;
  }
  data_avg /= (float)var.num_stn_obj;

  // 2. MQ�� �°� ����ȭ�۾� ����
  for (k = 0; k < var.num_stn_obj; k++) {
    x[k] = stn_data[k].x / var.NX;
    y[k] = stn_data[k].y / var.NY;
    if (var.topo)
      z[k] = stn_data[k].ht / 2000.0;   // �ִ븦 2000m�� ����
    else
      z[k] = 0.0;

    if (data_max != data_min) {
      v[k] = (stn_data[k].d-data_min)/(data_max-data_min);
      s[k] = var.mq_sm*var.num_stn_obj*(0.1/(data_max-data_min))*(0.1/(data_max-data_min));
    }
    else {
      v[k] = stn_data[k].d;
      s[k] = var.mq_sm*var.num_stn_obj*(0.1*0.1);
    }
  }

  // 3. �����м� ����
  mq_obj(x, y, z, v, s, (double)(var.mq_mp), var.num_stn_obj, var.NX, var.NY);

  // 4. ��ȯ �� ǥ��
  for (j = 0; j <= var.NY; j++) {
    for (i = 0; i <= var.NX; i++) {
      if (g[j][i] > -90) g[j][i] = g[j][i]*(data_max-data_min) + data_min;
    }
  }

  // 5. �迭����
  free_dvector(s, 0, var.num_stn_obj);
  free_dvector(v, 0, var.num_stn_obj);
  free_vector(z, 0, var.num_stn_obj);
  free_vector(y, 0, var.num_stn_obj);
  free_vector(x, 0, var.num_stn_obj);

  return 0;
}

/*=============================================================================*
 *  < LU decomposition >    from  Numerical Recips
 *=============================================================================*/
#define TINY 1.0e-20;

int ludcmp(double **a, int n, int *indx, float *d)
{
  int i,imax,j,k;
  double big,dum,sum,temp;
  double *vv;

  vv=dvector(0,n-1);
  *d=1.0;
  for (i=0;i<n;i++) {
    big=0.0;
    for (j=0;j<n;j++)
      if ((temp=fabs(a[i][j])) > big) big=temp;
    if (big == 0.0) printf("Singular matrix in routine LUDCMP");
    vv[i]=1.0/big;
  }
  for (j=0;j<n;j++) {
    for (i=0;i<j;i++) {
      sum=a[i][j];
      for (k=0;k<i;k++) sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
    }
    big=0.0;
    for (i=j;i<n;i++) {
      sum=a[i][j];
      for (k=0;k<j;k++) sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
      if ( (dum=vv[i]*fabs(sum)) >= big) {
        big=dum;
        imax=i;
      }
    }
    if (j != imax) {
      for (k=0;k<n;k++) {
        dum=a[imax][k];
        a[imax][k]=a[j][k];
        a[j][k]=dum;
      }
      *d = -(*d);
      vv[imax]=vv[j];
    }
    indx[j]=imax;
    if (a[j][j] == 0.0) a[j][j]=TINY;
    if (j != n-1) {
      dum=1.0/(a[j][j]);
      for (i=j+1;i<n;i++) a[i][j] *= dum;
    }
  }
  free_dvector(vv,0,n-1);
  return 0;
}

/*=============================================================================*
 *  < A * X = B  calculation >    from  Numerical Recips
 *=============================================================================*/
int lubksb(double **a, int n, int *indx, double b[])
{
  int i,ii=-1,ip,j;
  double sum;

  for (i=0;i<n;i++) {
    ip=indx[i];
    sum=b[ip];
    b[ip]=b[i];
    if (ii >= 0)
      for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
    else if (sum) ii=i;
      b[i]=sum;
  }
  for (i=n-1;i>=0;i--) {
    sum=b[i];
    for (j=i+1;j<n;j++) sum -= a[i][j]*b[j];
    b[i]=sum/a[i][i];
  }
  return 0;
}

/*=============================================================================*
 *  hydroboloid fuction as the basis function for m-q interpolation
 *       - input -
 *           (x1,y1) : Normalized coordinate of pistion 1
 *           (x2,y2) : Normalized coordinate of pistion 2
 *=============================================================================*/
double hydrof(double x1, double y1, double z1, double x2, double y2, double z2, double cc)
{
  double dx=x2-x1, dy=y2-y1, dz=z2-z1, hf;
  hf = -sqrt( (dx*dx+dy*dy+dz*dz)*cc + 1.0 );
  return hf;
}

/*=============================================================================*
 *   Multi-quadric interpolation
 *
 *       - input -
 *           v(n) : observation value of the stations  (destroyed)
 *           s(n) : smooting value
 *                   ( = n * smooting parameter
 *                         * mean-squared observation error )
 *           mp   : multiquadric parameter
 *           num_stn : ������
 *           nx, ny  : X��� Y���� ���ڼ�
 *=============================================================================*/
int mq_obj(float *x, float *y, float *z, double *v, double *s, double mp, int num_stn, int nx, int ny) {
  double dx=1.0/nx, dy=1.0/ny, cc=1.0/(mp*mp);
  double x1, y1, z1, q1;
  double **q;
  float  d;
  int    *indx;
  int    i,j,k;

  // 1. �޸� �Ҵ�
  q = dmatrix(0, num_stn-1, 0, num_stn-1);
  indx = ivector(0, num_stn-1);

  // 2. Q-matrix ���
  for (i = 0; i < num_stn; i++) {
    for (j = i+1; j < num_stn; j++)
      q[i][j] = hydrof((double)x[i], (double)y[i], (double)z[i], (double)x[j], (double)y[j], (double)z[j], cc);
  }
  for (i = 1; i < num_stn; i++) {
    for (j = 0; j < i; j++)
      q[i][j] = q[j][i];
  }
  for (i = 0; i < num_stn; i++)   // Smooting parameter
    q[i][i] = -1.0 + s[i];

  // 3. LU decomposition of Q
  ludcmp(q, num_stn, indx, &d);

  // 4. (Invers matrix of Q)*v
  lubksb(q, num_stn, indx, v);

  // 5. Grid value (Center-point grid system)
  for (j = 0; j <= ny; j++) {
    y1 = dy*j;

    for (i = 0; i <= nx; i++) {
      x1 = dx*i;
      if (var.topo)
        z1 = topo[j][i]/2000.0;
      else
        z1 = 0.0;

      if (g[j][i] > -90) {
        for (q1 = 0.0, k = 0 ; k < num_stn; k++)
          q1 += v[k]*hydrof(x1, y1, z1, (double)x[k], (double)y[k], (double)z[k], cc);
        g[j][i] = q1;
      } else {
        g[j][i] = -99.9;
      }
    }
  }

  // 6. �޸� �ݳ�
  free_dmatrix(q,0,num_stn-1,0,num_stn-1);
  free_ivector(indx,0,num_stn-1);

  return 0;
}

/*******************************************************************************
 *
 *  �����м� (Barnes ���)
 *
 *******************************************************************************/
int data_obj_bn() {
  float rs, r1, r2, v1;
  int   xo, yo, x1, y1, x2, y2, ms;
  int   i, j, k;

  // 1. ���߹ݰ� ����
  rs = 100.0;
  r1 = var.bn_r1/var.grid;
  r2 = var.bn_r2/var.grid;

  rs = rs*rs;
  r1 = 1.0/(r1*r1);
  r2 = 1.0/(r2*r2);

  // 2. Objective analysis (Barnes scheme) 
  ms = barnes(var.num_stn_obj, stn_data, var.NX, var.NY, g, rs, r1, r2);

  return 0;
}

/*=============================================================================*
 *  Barnes' objective analysis (2-pass)
 *  by  ����ȯ (1997. 3. 15)
 *=============================================================================*/
int barnes(ns, stn, ni, nj, g, rs, r1, r2)
    int    ns;                      /* number of observation's                          */
    struct STN_VAL stn[];           /* station information & data                       */
    int    ni, nj;                  /* (grid number-1) of x, y direction                */
    float  **g;                     /* analysis data                          <output>  */
    float  rs;                      /* (search radius)**2  [grid unit]                  */
    float  r1;                      /* 1.0/(smoothing radius)**2  in 1-pass [grid unit] */
    float  r2;                      /* 1.0/(smoothing radius)**2  in 2-pass [grid unit] */
{
    float  s1, s2, wt1, wt2, sum_wt1, sum_wt2;
    float  x1, y1, xg, yg, xd, yd, rr;
    int    i, j, k, n, ks, ms = ns;

    // 1. 1-pass 
    for (n = 0; n < ms; n++) {
        x1 = stn[n].x;  y1 = stn[n].y;
        s1 = 0.0;  sum_wt1 = 0.0;

        for (k = 0; k < ms; k++) {
            rr = (x1-stn[k].x)*(x1-stn[k].x) + (y1-stn[k].y)*(y1-stn[k].y);
            wt1 = exp(-rr*r1);  sum_wt1 += wt1;  s1 += wt1*stn[k].d;
        }
        stn[n].s = stn[n].d - s1/sum_wt1;
    }

    // 2. 2-pass
    for (j = 0; j <= nj; j++) {
        yg = (float)j;

        for (i = 0; i <= ni; i++) {
            xg = (float)i;

            if (g[j][i] > -990) {
                s1 = s2 = sum_wt1 = sum_wt2 = 0.0;

                for (n = 0; n < ms; n++) {
                    rr = (xg-stn[n].x)*(xg-stn[n].x) + (yg-stn[n].y)*(yg-stn[n].y);
                    if (rr < rs) {
                        wt1 = exp(-rr*r1);  sum_wt1 += wt1;  s1 += wt1*stn[n].d;
                        wt2 = exp(-rr*r2);  sum_wt2 += wt2;  s2 += wt2*stn[n].s;
                    }
                }
                if (sum_wt1 > 0 && sum_wt2 > 0)
                    g[j][i] = s1/sum_wt1 + s2/sum_wt2;
                else
                    g[j][i] = -99.9;
            } else
                g[j][i] = -99.9;
        }
    }
    return ms;
}

/*=============================================================================*
 *  zd�� Ȯ�� ��ƾ (���밡��: �ݵ�� ������ X,Y ���� zd���� ������ �������� ��)
 *      Ȯ��� �������� sub 4-point ����� �⺻���� ���
 *  by ����ȯ (2006. 5. 22)
 *=============================================================================*/
int grid_zoom (
    float **g,      /* input -> output */
    int   nx,       /* [0:nx,0:ny] zd�� ������ �������� ��. */
    int   ny,
    int   zd,       /* Ȯ���� (2��,3�� ... ) */
    int   ox,       /* ���� �Ʒ� ������ X-��ǥ */
    int   oy,       /* ���� �Ʒ� ������ Y-��ǥ */
    float missing,  /* ���ϴ� �ڷ� ���� */
    int   mode      /* 0:����(X), 1:��������, 2:4������ */
)
{
    float x;
    int   i, j, k;

    // 1. Y ���� Ȯ��
    for (i = ox; i <= ox+nx/zd; i++) {
        for (k = 0, j = oy; j < oy*zd/(zd-1); j++, k += zd) g[k][i] = g[j][i];
        for (k = ny, j = oy+ny/zd; j >= oy*zd/(zd-1); j--, k -= zd) g[k][i] = g[j][i];
    }

    // 2. X ���� Ȯ��
    for (j = 0; j <= ny; j += zd) {
        for (k = 0, i = ox; i < ox*zd/(zd-1); i++, k += zd) g[j][k] = g[j][i];
        for (k = nx, i = ox+nx/zd; i >= ox*zd/(zd-1); i--, k -= zd) g[j][k] = g[j][i];
    }

    // 3. Y ���� ����
    for (i = 0; i <= nx; i += zd) {
        // 3.1. (0, zd) ���� ������ ��� : �������� ���
        if (mode > 0 && g[0][i] > missing && g[zd][i] > missing) {
            for (k = 1; k < zd; k++)
                g[k][i] = (g[0][i]*(float)(zd - k) + g[zd][i]*(float)k) / (float)zd;
        }
        else {
            for (k = 1; k < zd; k++) {
                if (k <= zd/2) g[k][i] = g[0][i];
                else           g[k][i] = g[zd][i];
            }
        }

        // 3.2. (ny-zd, ny) ���� ������ ��� : �������� ���
        if (mode > 0 && g[ny-zd][i] > missing && g[ny][i] > missing) {
            for (k = 1; k < zd; k++)
                g[ny-k][i] = (g[ny-zd][i]*(float)k + g[ny][i]*(float)(zd-k)) / (float)zd;
        }
        else {
            for (k = 1; k < zd; k++) {
                if (k < zd/2) g[ny-k][i] = g[ny][i];
                else          g[ny-k][i] = g[ny-zd][i];
            }
        }

        // 3.3. ������ (zd,ny-zd) ���� ������ ��� : �ؼ������� ��� (4-point)
        for (j = zd; j < ny-zd; j += zd) {
            for (k = 1; k < zd; k++) {
                if (mode > 0 && g[j][i] > missing && g[j+zd][i] > missing) {
                    x = (float)k / (float)zd;

                    if (mode == 2 && g[j-zd][i] > missing && g[j+zd*2][i] > missing)
                        g[j+k][i] = g[j][i] + x*(g[j+zd][i] - g[j][i] + (x-1.0)*0.25*(g[j-zd][i] - g[j][i] - g[j+zd][i] + g[j+zd*2][i]));
                    else
                        g[j+k][i] = g[j][i]*(1.0-x) + g[j+zd][i]*x;
                }
                else {
                    if (k <= zd/2) g[j+k][i] = g[j][i];
                    else           g[j+k][i] = g[j+zd][i];
                }
            }
        }
    }

    // 4. X ���� ����
    for (j = 0; j <= ny; j++) {
        // 4.1. (0, zd) ���� ������ ��� : �������� ���
        if (mode > 0 && g[j][0] > missing && g[j][zd] > missing) {
            for (k = 1; k < zd; k++)
                g[j][k] = (g[j][0]*(float)(zd - k) + g[j][zd]*(float)k) / (float)zd;
        }
        else {
            for (k = 1; k < zd; k++) {
                if (k <= zd/2) g[j][k] = g[j][0];
                else           g[j][k] = g[j][zd];
            }
        }

        // 4.2. (nx-zd, nx) ���� ������ ��� : �������� ���
        if (mode > 0 && g[j][nx-zd] > missing && g[j][nx] > missing) {
            for (k = 1; k < zd; k++)
                g[j][nx-k] = (g[j][nx-zd]*(float)k + g[j][nx]*(float)(zd-k)) / (float)zd;
        }
        else {
            for (k = 1; k < zd; k++) {
                if (k < zd/2) g[j][nx-k] = g[j][nx];
                else          g[j][nx-k] = g[j][nx-zd];
            }
        }

        // 4.3. ������ (zd,ny-zd) ���� ������ ��� : �ؼ������� ��� (4-point)
        for (i = zd; i < nx-zd; i += zd) {
            for (k = 1; k < zd; k++) {
                if (mode > 0 && g[j][i] > missing && g[j][i+zd] > missing) {
                    x = (float)k / (float)zd;

                    if (mode == 2 && g[j][i-zd] > missing && g[j][i+zd*2] > missing)
                        g[j][i+k] = g[j][i] + x*(g[j][i+zd] - g[j][i] + (x-1.0)*0.25*(g[j][i-zd] - g[j][i] - g[j][i+zd] + g[j][i+zd*2]));
                    else
                        g[j][i+k] = g[j][i]*(1.0-x) + g[j][i+zd]*x;
                }
                else {
                    if (k <= zd/2) g[j][i+k] = g[j][i];
                    else           g[j][i+k] = g[j][i+zd];
                }
            }
        }
    }
    return 0;
}

/*=============================================================================*
 *  Grid data Smoothing (by 1-2-1 Smoothing)
 *  by ����ȯ (1997. 3. 15)
 *=============================================================================*/
int grid_smooth (
    float **g,      /* input -> output  */
    int   nx,       /* ���� [0:nx,0:ny] */
    int   ny,
    int   missing   /* ���ϴ� �ڷ� ���� */
)
{
    float  e[4], e1, e2;
    int    i, j;

    for (j = 0; j <= ny; j++) {
        e1 = g[j][0];
        e[0] = g[j][0];
        e[1] = g[j][1];

        for (i = 1; i < nx; i++) {
            e[2] = g[j][i+1];

            if (e[0] > missing && e[1] > missing && e[2] > missing)
                e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
            else if (e[0] > missing && e[1] <= missing && e[2] > missing)
                e2 = (e[0] + e[2]) * 0.5;
            else
                e2 = e[1];

            g[j][i-1] = e1;
            e1 = e2;
            e[0] = e[1];
            e[1] = e[2];
        }
        g[j][i-1] = e1;
    }

    for (i = 0; i <= nx; i++) {
        e1 = g[0][i];
        e[0] = g[0][i];
        e[1] = g[1][i];

        for (j = 1; j < ny; j++) {
            e[2] = g[j+1][i];

            if (e[0] > missing && e[1] > missing && e[2] > missing)
                e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
            else if (e[0] > missing && e[1] <= missing && e[2] > missing)
                e2 = (e[0] + e[2]) * 0.5;
            else
                e2 = e[1];

            g[j-1][i] = e1;
            e1 = e2;
            e[0] = e[1];
            e[1] = e[2];
        }
        g[j-1][i] = e1;
    }
    return 0;
}

/*******************************************************************************
 *
 *  ���� Ȯ�� (2�� Ȯ�븸 ����)
 *
 *******************************************************************************/
int grid_zooming(float **grid) {
    int  zx, zy, zm = 1, ox = 0, oy = 0, code, i, k;

    // 1. Ȯ��ø�, �׸��� �ڷᰡ ��������
    if (var.zoom_level == 0) return 0;
    if (var.num_stn_obj <= 0) return 0;

    // 2. ������ �ڷ� Ȯ��
    for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        ox = (zx-1)*var.NX/8;
        oy = (zy-1)*var.NY/8;
        code = grid_zoom(grid, var.NX, var.NY, var.zoom_rate, ox, oy, -90.0, 2);
    }
    return 0;
}

/*******************************************************************************
 *
 *  Ȯ���, ���� ��ǥ�� Ȯ��
 *
 *******************************************************************************/
int stn_zooming() {
  float ox = 0.0, oy = 0.0, zm = 1.0;
  int  zx, zy, i, k;

  // 1. Ȯ��ø�, �׸��� �ڷᰡ ��������
  if (var.zoom_level == 0) {
    var.num_stn_area = var.num_stn_obj;   // �̶��� �翬�� ��ü ������
    return 0;
  }
  if (var.num_stn_obj <= 0) return 0;

  // 2. ���� ��ġ Ȯ�� ���� ���� ����
  if (var.zoom_rate == 3) {
    for (i = 0; i < 2; i++) {
      zx = var.zoom_x[i]-'0';
      zy = var.zoom_y[i]-'0';
      if (zx == 0 || zy == 0) break;
      ox += (var.NX/9.0*(zx-1)/zm);
      oy += (var.NY/9.0*(zy-1)/zm);
      zm *= var.zoom_rate;
    }
  }
  else if (var.zoom_rate == 2) {
    for (i = 0; i < 7; i++) {
      zx = var.zoom_x[i]-'0';
      zy = var.zoom_y[i]-'0';
      if (zx == 0 || zy == 0) break;
      ox += (var.NX/8.0*(zx-1)/zm);
      oy += (var.NY/8.0*(zy-1)/zm);
      zm *= var.zoom_rate;
    }
  }

  // 3. Ȯ��� ���� ���� ��ġ
  for (k = 0; k < var.num_stn_obj; k++) {
    stn_data[k].x = zm*(stn_data[k].x - ox);
    stn_data[k].y = zm*(stn_data[k].y - oy);
  }

  // 4. ǥ�⿵���� ������
  for (var.num_stn_area = 0, k = 0; k < var.num_stn_obj; k++) {
    if (stn_data[k].x > 0 && stn_data[k].x < var.NX && stn_data[k].y > 0 && stn_data[k].y < var.NY)
      var.num_stn_area++;
  }
  return 0;
}

/*=============================================================================*
 *  ���� ���� ���� �б�
 *
 *      map : inp:������ ����
 *      nx  : out:�������� �������� (km)
 *      ny  : out:���Ϲ��� �������� (km)
 *      sx  : out:�������� ������ġ (km)
 *      sy  : out:���Ϲ��� ������ġ (km)
 *=============================================================================*/
int grid_map_inf(char *map, int *nx, int *ny, int *sx, int *sy)
{
    FILE  *fp;
    char  buf[1024], map_list[8], value[16];

    fp = fopen(MAP_INI_FILE,"r");
    if (fp == NULL) exit(-1);

    while (fgets(buf,1024,fp)) {
        if (buf[0] == '#') continue;
        getword(map_list, buf, ':');

        if ( !strcmp(map, map_list) ) {
            getword(value, buf, ':');  *nx = atoi(value);
            getword(value, buf, ':');  *ny = atoi(value);
            getword(value, buf, ':');  *sx = atoi(value);
            getword(value, buf, ':');  *sy = atoi(value);
            break;
        }
    }
    fclose(fp);

    return 0;
}
