/*******************************************************************************
**
**  LAU ������ ���� Ȯ��
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.01.05)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <math.h>
#include "cgiutil.h"
#include "aws3_data.h"
#include "stn_inf.h"
#include "url_io.h"

// ����� ��û��
struct INPUT_VAR {
  char fname[120];
} var;

FILE  *fp_log;

/******************************************************************************
 *
 *  MAIN
 *
 ******************************************************************************/
int main()
{
  // 1. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  fp_log = stdout;
  alarm(60);

  printf("HTTP/1.0 200 OK\n");
  printf("Server: Netscape-Enterprise/3.0\n");
  printf("Content-type: text/plain\n\n");

  // 2. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    printf("Content-type: text/plain\n\n");
    printf("# input variable error<p>\n");
    return -1;
  }

  // 4. Header
  //printf("<html>\n");
  //head_disp();

  // 5. ��� ���
  lau_disp();
  //printf("</html>\n");

  alarm(0);
  return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
  char *qs;
  char tmp[256], value[500], item[500], gov_lst[500], tm[30], dtm[30];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, bn_set = 0, zr, i, j, k;

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if ( !strcmp(item,"fname")) strcpy(var.fname, value);
  }
  return 0;
}

/******************************************************************************
 *
 *  HEAD
 *
 ******************************************************************************/
int head_disp() 
{
  printf("<head>\n");
  printf("<style type='text/css'>\n");
  printf("<!--\n");
  printf(":link    {text-decoration:none; color=#000099;}\n");
  printf(":active  {text-decoration:none; color=#000099;}\n");
  printf(":visited {text-decoration:none; color=#000099;}\n");
  printf(".head  {font-family:'���� ����'; font-size:11pt; color:#222222; font-weight:bold;}\n");
  printf(".ehead {font-family:'���� ����'; font-size:9pt; color:#000000; font-weight:bold;}\n");
  printf(".text1 {font-family:'���� ����'; font-size:9pt; color:#000000;}\n");
  printf(".text2 {font-family:'���� ����'; font-size:8pt; color:#222222;}\n");
  printf("-->\n");
  printf("</style>\n");
  printf("</head>\n");
  return 0;
}

/******************************************************************************
 *
 *  BODY
 *
 ******************************************************************************/
int lau_disp() 
{
  FILE  *fp;

  printf("%s", var.fname);

  // ���� ����
  if ((fp = fopen(var.fname,"rb")) == NULL) {
    printf(" : ���� ���� ����\n");
    return -1;
  }

  // �������� �ص�
  if (strstr(var.fname,"LAU4011") != NULL)
    lau1_disp(fp);
  else if (strstr(var.fname,"LAU3_") != NULL)
    lau3_disp(fp);
  else
    lau2_disp(fp);

  // ���� �ݱ�
  fclose(fp);
  return 0;
}

/******************************************************************************
 *  LAU3 �ص�
 ******************************************************************************/
int lau3_disp(FILE *fp)
{
  unsigned char buf[MAX3_BYTE];
  unsigned short v;
  unsigned short aws3_raw[AWS3_LEN];
  short  lau3[12];
  long   filesize;
  int    read_b, naws, n1, n2;
  int    i, j, k, n;

  // 1. ���Ե� AWS ��
  fseek(fp, 0L, SEEK_END);
  filesize = ftell(fp);
  if (filesize < (HEAD3_BYTE + END3_BYTE)) {
    printf(" : ���� ũ�Ⱑ �ʹ� �۽��ϴ�.(%d)\n", filesize);
    return -2;
  }
  naws = (filesize + 4 - HEAD3_BYTE - END3_BYTE) / AWS3_BYTE;
  printf(" (����ũ�� %d bytes, ���� ������ %d��)\n\n", filesize, naws);

  // 2. Header Decode
  fseek(fp, 0L, SEEK_SET);
  read_b = fread(buf, sizeof(char), HEAD3_BYTE, fp);
  lau3[0] = buf[2]*256 + buf[3];            /* LAU ID */
  lau3[1] = buf[4];                         /* Year   */
  lau3[1] = lau3[1] + 2000;
  lau3[2] = buf[5];                         /* Month  */
  lau3[3] = buf[6];                         /* Day    */
  lau3[4] = buf[7];                         /* Hour   */
  lau3[5] = buf[8];                         /* Minute */
  lau3[6] = naws;                           /* AWS ���� */

  printf("LAU Header(11bytes) :");
  for (k = 0; k < HEAD3_BYTE; k++)
    printf(" %3d", buf[k]);
  printf("\n");

  printf("LAU Header �ص�     : LAU ID = %d, LAU TIME = %04d.%02d.%02d.%02d:%02d, AWS�� = %d\n\n",
    lau3[0], lau3[1], lau3[2], lau3[3], lau3[4], lau3[5], buf[10]);

  // 3. AWS data Decode
  for (n = 0; n < naws; n++) {
    // 3.1. �б�
    read_b = fread(buf, sizeof(char), AWS3_BYTE, fp);

    // 3.2. �ص�
    aws3_raw[0]  = buf[2] + 2000;          // �������� ���� Year
    aws3_raw[1]  = buf[3];                 // �������� ���� Month
    aws3_raw[2]  = buf[4];                 // �������� ���� Day

    aws3_raw[3]  = buf[5] + 2000;          // AWS Year
    aws3_raw[4]  = buf[6];                 // AWS Month
    aws3_raw[5]  = buf[7];                 // AWS Day
    aws3_raw[6]  = buf[8];                 // AWS Hour
    aws3_raw[7]  = buf[9];                 // AWS Minute

    aws3_raw[8]  = buf[10];                // �ڷ� ����('I','B','Q')
    aws3_raw[9]  = buf[11];                // �ڷ����� ��ȣ(0:�ʼ�/����, 1:�ʼ�  2:������ )
    aws3_raw[10] = buf[12]*256 + buf[13];  // AWS ID

    k = 11; i = 14;
    for (j = k; j < AWS3_LEN-1; j++, i += 2)
      aws3_raw[j] = buf[i]*256 + buf[i+1];
    aws3_raw[j] = buf[i];

    // 3.3. ǥ��
    printf("n = %d\n", n);
    for (i = 0; i < 12; i++)
      printf(" %3d", buf[i]);
    printf("  ( AWS ID = %d, AWS TIME = %d.%02d.%02d.%02d:%02d )\n",
      aws3_raw[10], aws3_raw[3], aws3_raw[4], aws3_raw[5], aws3_raw[6], aws3_raw[7]); 

    for (i = 14; i < AWS3_BYTE; i++) {
      printf(" %3d", buf[i]);
      if ((i-14)%30 == 29) printf("\n");
    }
    printf("\n");
    printf("........................................................................................................................\n");

    for (j = 11; j < AWS3_LEN; j++) {
      printf("%8d", aws3_raw[j]);
      if ((j-11)%15 == 14) printf("\n");
    }
    printf("\n");
    printf("------------------------------------------------------------------------------------------------------------------------\n");
  }
/*
  read_b = fread(buf, 1, filesize-11, fp);
  for (n1 = 0, k = 140; k < read_b; k++) {
    if (buf[k] == 251 && buf[k-1] == 250) {
      n2 = k-1;
      printf("k = %4d (%d)", n2, n2-n1);
      if (buf[n1] == 250 && buf[n1+1] == 251)
        printf(" %3d %3d:", buf[n1], buf[n1+1]);
      else {
        printf(" --- ---:");
        n1 -= 2;
      }
      printf(" %3d %3d %3d:", buf[n1+2], buf[n1+3], buf[n1+4]);
      printf(" %3d %3d %3d %3d %3d: %5d:", buf[n1+5], buf[n1+6], buf[n1+7], buf[n1+8], buf[n1+9], buf[n1+12]*256+buf[n1+13]);
      printf(" %3d %3d %3d %3d", buf[n2-4], buf[n2-3], buf[n2-2], buf[n2-1]);
      printf("\n");
      n1 = n2;
    }
  }
  n2 = read_b - 4;
      printf("k = %4d (%d)", n2, n2-n1);
      if (buf[n1] == 250 && buf[n1+1] == 251)
        printf(" %3d %3d:", buf[n1], buf[n1+1]);
      else {
        printf(" --- ---:");
        n1 -= 2;
      }
      printf(" %3d %3d %3d:", buf[n1+2], buf[n1+3], buf[n1+4]);
      printf(" %3d %3d %3d %3d %3d: %5d:", buf[n1+5], buf[n1+6], buf[n1+7], buf[n1+8], buf[n1+9], buf[n1+12]*256+buf[n1+13]);
      printf(" %3d %3d %3d %3d", buf[n2-4], buf[n2-3], buf[n2-2], buf[n2-1]);
      printf("\n");
*/
  return 0;
}

/******************************************************************************
 *  LAU2 �ص�
 ******************************************************************************/
int lau2_disp(FILE *fp)
{
  unsigned char buf[MAX2_BYTE];
  unsigned short v;
  unsigned short aws2_raw[AWS2_LEN];
  short  lau2[12];
  long   filesize;
  int    read_b, naws;
  int    i, j, k, n;

  // 1. ���Ե� AWS ��
  fseek(fp, 0L, SEEK_END);
  filesize = ftell(fp);
  if (filesize < (HEAD2_BYTE + END2_BYTE)) {
    printf(" : ���� ũ�Ⱑ �ʹ� �۽��ϴ�.(%d)\n", filesize);
    return -2;
  }
  naws = (filesize + 4 - HEAD2_BYTE - END2_BYTE) / AWS2_BYTE;
  printf(" (����ũ�� %d bytes, ���� ������ %d��)\n\n", filesize, naws);

  // 2. Header Decode
  fseek(fp, 0L, SEEK_SET);
  read_b = fread(buf, sizeof(char), HEAD2_BYTE, fp);
  lau2[0] = (buf[2] & 0x3f)*256 + buf[3];          /* LAU ID */
  lau2[1] = buf[4] & 0x7f;                         /* Year   */
  lau2[1] = lau2[1] + 2000;
  lau2[2] = buf[5] & 0x0f;                         /* Month  */
  lau2[3] = buf[6] & 0x1f;                         /* Day    */
  lau2[4] = buf[7] & 0x1f;                         /* Hour   */
  lau2[5] = buf[8] & 0x3f;                         /* Minute */
  lau2[6] = naws;                                  /* AWS ���� */

  printf("LAU Header(%dbytes) :", HEAD2_BYTE);
  for (k = 0; k < HEAD2_BYTE; k++)
    printf(" %3d", buf[k]);
  printf("\n");

  printf("LAU Header �ص�     : LAU ID = %d, LAU TIME = %04d.%02d.%02d.%02d:%02d, AWS�� = %d\n\n",
    lau2[0], lau2[1], lau2[2], lau2[3], lau2[4], lau2[5], buf[10]);

  // 3. AWS data Decode
  for (n = 0; n < naws; n++) {
    // 3.1. �б�
    read_b = fread(buf, sizeof(char), AWS2_BYTE, fp);

    // 3.2. �ص�
    aws2_raw[0]  =  buf[0]  & 0x7f;                 // �������� ���� Year
    aws2_raw[0]  =  aws2_raw[0] + 2000;
    aws2_raw[1]  =  buf[1]  & 0x0f;                 // �������� ���� Month
    aws2_raw[2]  =  buf[2]  & 0x1f;                 // �������� ���� Day

    aws2_raw[3]  =  buf[3]  & 0x7f;                 // AWS Year
    aws2_raw[3]  =  aws2_raw[3] + 2000;
    aws2_raw[4]  =  buf[4]  & 0x0f;                 // AWS Month
    aws2_raw[5]  =  buf[5]  & 0x1f;                 // AWS Day
    aws2_raw[6]  =  buf[6]  & 0x1f;                 // AWS Hour
    aws2_raw[7]  =  buf[7]  & 0x3f;                 // AWS Minute

    aws2_raw[8]  =  buf[8]  & 0xff;                 // �ڷ� ����('I','B','Q')
    aws2_raw[9]  =  buf[9]  & 0x03;                 // �ڷ����� ��ȣ(0:�ʼ�/����, 1:�ʼ�  2:������ )
    aws2_raw[10] = (buf[10] & 0x7f)*256 + buf[11];  // AWS ID

    k = 11; i = 12;
    for (j = k; j < (k + AWS2_OPP + AWS2_OPT); j++, i += 2)
      aws2_raw[j] = buf[i]*256 + buf[i+1];

    j = k + AWS2_OPP + AWS2_OPT;
    aws2_raw[j] = (buf[i] & 0xff);    // ���л���

    j++; i++;
    v = (buf[i] & 0xff)*256 + (buf[i+1] & 0xff);
    aws2_raw[j] = v;    // ��������

    // 3.3. ǥ��
    printf("n = %d\n", n);
    for (i = 0; i < 12; i++)
      printf(" %3d", buf[i]);
    printf("  ( AWS ID = %d, AWS TIME = %d.%02d.%02d.%02d:%02d )\n",
      aws2_raw[10], aws2_raw[3], aws2_raw[4], aws2_raw[5], aws2_raw[6], aws2_raw[7]); 

    for (i = 12; i < AWS2_BYTE; i++) {
      printf(" %3d", buf[i]);
      if ((i-12)%30 == 29) printf("\n");
    }
    printf("\n");
    printf("........................................................................................................................\n");

    for (j = 11; j < AWS2_LEN; j++) {
      printf("%8d", aws2_raw[j]);
      if ((j-11)%15 == 14) printf("\n");
    }
    printf("\n");
    printf("------------------------------------------------------------------------------------------------------------------------\n");
  }

  return 0;
}

/******************************************************************************
 *  LAU1 �ص�
 ******************************************************************************/
int lau1_disp(FILE *fp)
{
  unsigned char buf[MAX1_BYTE];
  unsigned short aws1_raw[AWS1_LEN];
  short  lau1[12];
  long   filesize;
  int    read_b, naws;
  int    i, j, k, n;

  // 1. ���Ե� AWS ��
  fseek(fp, 0L, SEEK_END);
  filesize = ftell(fp);
  if (filesize < (HEAD1_BYTE + LAU1_BYTE)) {
    printf(" : ���� ũ�Ⱑ �ʹ� �۽��ϴ�.(%d)\n", filesize);
    return -2;
  }
  naws = (filesize - HEAD1_BYTE - LAU1_BYTE) / AWS1_BYTE;
  printf(" (����ũ�� %d bytes, ���� ������ %d��)\n\n", filesize, naws);

  // 2. Header Decode
  fseek(fp, 0L, SEEK_SET);
  read_b = fread(buf, sizeof(char), HEAD1_BYTE, fp);
  lau1[0] = (buf[2] & 0x3f)*256 + buf[3];         // LAU ID
  lau1[1] = buf[5];                               // AWS ��
  lau1[2] = buf[6] >> 1;                          // Year
  if (lau1[2] < 90)
    lau1[2] += 2000;
  else
    lau1[2] += 1900;
  lau1[3] = (buf[6] & 0x01)*8 + (buf[7] >> 5);    // Month
  lau1[3] = lau1[3]*256 + (buf[7] & 0x1f);        // Day
  lau1[4] = buf[8] & 0x1f;                        // Hour
  lau1[4] = lau1[4]*256 + (buf[9] & 0x3f);        // Minute 
  lau1[1] = naws; ;                               // AWS ����

  printf("LAU Header(%dbytes) :", HEAD1_BYTE);
  for (i = 0; i < HEAD1_BYTE; i++)
    printf(" %3d", buf[i]);
  printf("\n");

  printf("LAU Header �ص�     : LAU ID = %d, LAU TIME = %04d.%02d.%02d.%02d:%02d, AWS�� = %d\n\n",
    lau1[0], lau1[2], lau1[3]/256, lau1[3]%256, lau1[4]/256, lau1[4]%256, lau1[1]);

  // 3. AWS data Decode
  for (n = 0; n < naws; n++) {
    // 3.1. �б�
    read_b = fread(buf, sizeof(char), AWS1_BYTE, fp);

    // 3.2. �ص�
    aws1_raw[0] = (buf[0] & 0x7f)*256 + buf[1];                 // ��  ��
    aws1_raw[1] = (buf[2] & 0x7f)*256 + buf[3];                 // AWS ID
    aws1_raw[2] = buf[4] >> 1;                                  // Year
    if ( aws1_raw[2] < 90 )
      aws1_raw[2] += 2000;
    else
      aws1_raw[2] += 1900;
    aws1_raw[3] = (buf[4] & 0x01)*8 + ((buf[5] >> 5) & 0x07);   // Month
    aws1_raw[3] = aws1_raw[3]*256 + (buf[5] & 0x1f);            // Day
    aws1_raw[4] = buf[6] & 0x1f;                                // Hour
    aws1_raw[4] = aws1_raw[4]*256 + (buf[7] & 0x3f);            // Minute

    for (i = 8, j = 5; j < 29; j++, i += 2)     // Data
      aws1_raw[j] = buf[i]*256 + buf[i+1];

    // 3.3. ǥ��
    printf("n = %d\n", n);
    for (i = 0; i < 7; i++)
      printf(" %3d", buf[i]);
    printf("  ( AWS ID = %d, AWS TIME = %d.%02d.%02d.%02d:%02d )\n",
      aws1_raw[1], aws1_raw[2], aws1_raw[3]/256, aws1_raw[3]%256, aws1_raw[4]/256, aws1_raw[4]%256); 

    for (i = 8; i < AWS1_BYTE; i++) {
      printf(" %3d", buf[i]);
      if ((i-8)%30 == 29) printf("\n");
    }
    printf("\n");
    printf("........................................................................................................................\n");

    for (j = 5; j < AWS1_LEN; j++) {
      printf("%8d", aws1_raw[j]);
      if ((j-5)%15 == 14) printf("\n");
    }
    printf("\n");
    printf("------------------------------------------------------------------------------------------------------------------------\n");
  }
  return 0;
}
