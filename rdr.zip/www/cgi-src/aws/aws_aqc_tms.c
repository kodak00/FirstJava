/*******************************************************************************
**
**  AWS MQC���� �ڷ� �м�
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2016.10.18)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>

#include "cgiutil.h"
#include "nrutil.h"
#include "aws_data.h"
#include "aws2_data.h"
#include "stn_inf.h"
#include "map_ini.h"

#define  AWS_INF_FILE   "/home/fct/REF/STN/stn_aws.csv"

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
 int main()
{
  // 1. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(60);

  printf("HTTP/1.0 200 OK\n");
  printf("Server: Netscape-Enterprise/3.0\n");
  //printf("Content-type: text/plain\n\n");

  // 2. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    printf("Content-type: text/plain\n\n");
    printf("# input variable error<p>\n");
    return -1;
  }
}
