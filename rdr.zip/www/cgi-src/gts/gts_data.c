/*******************************************************************************
**
**  URL �Լ� �̿��� ���� GTS �ڷ� �����м� CGI ���α׷�
**
**=============================================================================*
**
**   o �ۼ��� : ����ȯ (2018.7.3)
**
********************************************************************************/
#include "gts_img.h"

extern struct INPUT_VAR var;       // ����� �Է� ����
extern struct STN_VAL stn_data[];  // ���� �ڷ�
extern float  **g;                 // �����м����

float ta_min[12] = {-15,-15,-10, -5, 5,5,10,10, 0, -5,-10,-15};
float td_min[12] = {-25,-20,-20,-10,-5,5,10,10,-5,-15,-20,-25};

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
  char *qs;
  char tmp[256], item[32], value[32], tm[30], tm_st[30];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, bn_set = 0, zr, i, j;

  // 1. ���� �ʱⰪ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "0");    // ����ð�
  strcpy(var.obs, "ta");  // ���
  strcpy(var.map, "H1");  // HD����
  strcpy(var.obj, "mq");  // MQ������� �����м�
  var.grid = 8.0;         // km ����
  var.itv  = 1;
  var.sms  = 0;
  var.stn  = 9;         // �ִ��ְ��� ����
  var.zoom_level = 0;   // ��ü����
  var.zoom_rate = 2;    // 2�� Ȯ�밡 �⺻
  var.mq_mp = 0.0005;   // MQ: ����1
  var.mq_sm = 1.0;      // MQ: ����2
  var.bn_r1 = 30;       // Barnes: 1�� �ݰ� = 30km
  var.bn_r2 = 10;       // Barnes: 2�� �ݰ� = 10km
  var.title = 1;        // ���� ǥ�� ����(1:ǥ��, 0:ǥ�� ����)
  strcpy(var.color, "C4");  // ����ǥ
  var.disp = 0;
  var.help = 0;

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"gts")) strcpy(var.gts, value);
    else if ( !strcmp(item,"obs")) strcpy(var.obs, value);
    else if ( !strcmp(item,"map")) strcpy(var.map, value);
    else if ( !strcmp(item,"obj")) strcpy(var.obj, value);
    else if ( !strcmp(item,"stn")) var.stn = atoi(value);
    else if ( !strcmp(item,"tm"))  strcpy(tm, value);
    else if ( !strcmp(item,"tm_st")) strcpy(tm_st, value);
    else if ( !strcmp(item,"grid")) var.grid = atof(value);
    else if ( !strcmp(item,"itv")) var.itv = atoi(value);
    else if ( !strcmp(item,"sms")) var.sms = atoi(value);
    else if ( !strcmp(item,"zoom_level")) var.zoom_level = atoi(value);
    else if ( !strcmp(item,"zoom_rate"))  var.zoom_rate = atoi(value);
    else if ( !strcmp(item,"zoom_x")) strcpy(var.zoom_x, value);
    else if ( !strcmp(item,"zoom_y")) strcpy(var.zoom_y, value);
    else if ( !strcmp(item,"mp"))   var.mq_mp = atof(value);
    else if ( !strcmp(item,"sm"))   var.mq_sm = atof(value);
    else if ( !strcmp(item,"r1")) { var.bn_r1 = atof(value);  bn_set = 1; }
    else if ( !strcmp(item,"r2")) { var.bn_r1 = atof(value);  bn_set = 1; }
    else if ( !strcmp(item,"disp")) var.disp = atoi(value);
    else if ( !strcmp(item,"size")) var.size = atoi(value);
    else if ( !strcmp(item,"color")) strcpy(var.color, value);
    else if ( !strcmp(item,"legend")) var.legend = atoi(value);
    else if ( !strcmp(item,"title")) var.title = atoi(value);
    else if ( !strcmp(item,"help")) var.help = atoi(value);
  }
  if (var.grid < 0.001) var.grid = 8.0;

  // 3. ����ð� �� ���� �����ð� ����
  get_time(&iYY, &iMM, &iDD, &iHH, &iMI, &iSS);
  iseq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm') - 3;
  seq2time(iseq, &iYY, &iMM, &iDD, &iHH, &iMI, 'm', 'n');

  // 4. ��û�ð� ����
  if (strlen(tm) >= 10) {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
  }
  var.seq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  //if (var.itv > 1) var.seq = (int)(var.seq/var.itv)*var.itv;

  // 5. ���۽ð� ���� (�ִ� ���)
  if (strlen(tm_st) >= 10) {
    strncpy(tmp, &tm_st[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm_st[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm_st[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm_st[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm_st[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
  }
  var.seq_st = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');

  // 6. ���� ����
  var.lon1 = 80;
  var.lon2 = 180;
  var.lat1 = 0;
  var.lat2 = 70;

  return 0;
}

/*******************************************************************************
 *
 *  �ڷ� �б�
 *
 *******************************************************************************/
int data_get()
{
  int  i, k, n;

  // 2. GTS �ڷ� �б�
  gts_data_get();

  // 3. �ڷᰡ ���� ������ ��Ͽ��� ����.
  for (k = 0; k < var.num_stn_obj; k++) {
    if (stn_data[k].d < -90) {
      if (k < var.num_stn_obj-1) {
        for (i = k; i < var.num_stn_obj-1; i++)
          stn_data[i] = stn_data[i+1];
      }
      else {
        var.num_stn_obj--;
        break;
      }
      var.num_stn_obj--;
      k--;
    }
  }
  return 0;
}

/*******************************************************************************
 *  GTS �ڷ� �б�
 *******************************************************************************/
int gts_data_get()
{
  FILE   *fp;
  URL_FILE *fr; 
  struct lamc_parameter map;
  char   buf[1000], url[500], tmp[500], v[30][50];
  char   stn_tp[8], stn_tm[16], flag[16];
  float  vv, xx, yy, u1, v1;
  float  gh, rn, wd, ws, ta, td, pa, ps, pr, vs, hm, rn_day, ta_min1, ta_max1, tw;
  float  lat, lon, ht, ht_pa, ht_ta, ht_wd, ht_rn;
  int    stn_id, pt, wc, wp, ca, cd, ch, cl, cm, ct, rh;
  int    YY, MM, DD, HH, MI;
  int    seq, seq1;
  int    qc, code, rtn, now, i, j, k;
  int    GX, GY, SX, SY;

  // 1. MAP parameter
  grid_map_inf(var.map, &GX, &GY, &SX, &SY);
  map.Re  = 6371.00877;
  map.grid  = var.grid;
  map.slat1 = 30.0;  map.slat2 = 60.0;
  map.olon  = 126.0;   map.olat  = 38.0;
  map.xo = (float)SX/map.grid;   map.yo = (float)SY/map.grid;
  map.first = 0;

  // 2. ������ ������ �б�
  var.num_stn_obj = 0;
  seq2time(var.seq-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  if (strcmp(var.gts,"SFC") == 0) {
    sprintf(url, "http://172.20.134.91/url/gts_cht_syn2.php?tm=%04d%02d%02d%02d00&lon1=%f&lon2=%f&lat1=%f&lat2=%f&help=0",
            YY, MM, DD, HH, var.lon1, var.lon2, var.lat1, var.lat2);
    if ((fr = url_fopen(url, "r"))) {
      while (!url_feof(fr)) {
        url_fgets(buf, sizeof(buf), fr);
        if (buf[0] == '#') continue;

        qc = 0;
        sscanf(buf, "%s %s %d %f %f %f %d %f %f %f %f %d %d %d %d %d %d %d %d %d %f %f %d %f %f %f %f %f",
               stn_tp, stn_tm, &stn_id, &lon, &lat, &ps, &pt, &pr, &ta, &td, &hm,
               &vs, &wc, &wp, &ca, &cd, &ch, &cl, &cm, &ct,
               &wd, &ws, &rh, &rn, &pa, &ta_min1, &ta_max1, &tw);

        if (!strcmp(var.obs,"ps")) {
          vv = ps;
          if (vv > 600 && vv < 1200) qc = 1;
        }
        else if (!strcmp(var.obs,"pa")) {
          vv = pa;
          if (vv > 600 && vv < 1200) qc = 1;
        }
        else if (!strcmp(var.obs,"ta")) {
          vv = ta;
          if (vv >= -50) qc = 1;
        }
        else if (!strcmp(var.obs,"td")) {
          vv = td;
          if (vv >= -50) qc = 1;
        }
        else if (!strcmp(var.obs,"dd")) {
          vv = ta - td;
          if (vv >= 0 && vv < 50) qc = 1;
        }
        else if (!strcmp(var.obs,"tw")) {
          vv = tw;
          if (vv >= -50) qc = 1;
        }
        else if (!strcmp(var.obs,"ta_min")) {
          vv = ta_min1;
          if (vv >= -50) qc = 1;
        }
        else if (!strcmp(var.obs,"ta_max")) {
          vv = ta_max1;
          if (vv >= -50) qc = 1;
        }
        else if (!strcmp(var.obs,"hm")) {
          vv = hm;
          if (vv >= 0) qc = 1;
        }
        else if (!strcmp(var.obs,"ca")) {
          vv = ca;
          if (vv >= 0) qc = 1;
        }
        else if (!strcmp(var.obs,"cd")) {
          vv = cd;
          if (vv >= 0) qc = 1;
        }
        else if (!strcmp(var.obs,"r06")) {
          if (rn >= 0 && rh == 1) {
            vv = rn;
            qc = 1;
          }
        }
        else if (!strcmp(var.obs,"r12")) {
          if (rn >= 0 && rh == 2) {
            vv = rn;
            qc = 1;
          }
        }
        else if (!strcmp(var.obs,"ws")) {
          vv = ws;
          if (vv >= 0) qc = 1;
        }
        else if (!strcmp(var.obs, "wv")) {
          if (wd >= 0 && ws >= 0) {
            u1 = -ws * sin( DEGRAD * wd );
            v1 = -ws * cos( DEGRAD * wd );
            qc = 1;
          }
        }
        else
          break;

        if (qc) {
          lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);
          if (xx >= 0 && xx <= var.NX && yy >= 0 && yy <= var.NY) {
//printf("%d, %f %f %f\n", stn_id, xx, yy, vv);
            stn_data[var.num_stn_obj].id = stn_id;
            stn_data[var.num_stn_obj].x = xx;
            stn_data[var.num_stn_obj].y = yy;
            if (!strcmp(var.obs,"wv")) {
              stn_data[var.num_stn_obj].d = u1;
              stn_data[var.num_stn_obj].v = v1;
            }
            else {
              stn_data[var.num_stn_obj].d = vv;
            }
            stn_data[var.num_stn_obj].wd = wd;
            stn_data[var.num_stn_obj].ws = ws;
            var.num_stn_obj++;
          }
        }
      }
    }
    url_fclose(fr);
  }

  // 3. �����ڷ� �б�
  else {
    sprintf(url, "http://172.20.134.91/url/gts_cht_temp.php?pa=%s&tm=%04d%02d%02d%02d00&lon1=%f&lon2=%f&lat1=%f&lat2=%f&help=0",
            var.gts, YY, MM, DD, HH, var.lon1, var.lon2, var.lat1, var.lat2);
    if ((fr = url_fopen(url, "r"))) {
      while (!url_feof(fr)) {
        url_fgets(buf, sizeof(buf), fr);
        if (buf[0] == '#') continue;

        qc = 0;
        sscanf(buf, "%s %d %f %f %f %f %f %f %f %f %s",
               stn_tm, &stn_id, &lon, &lat, &pa, &gh, &ta, &td, &wd, &ws, flag);

        if (!strcmp(var.obs,"gh")) {
          vv = gh;
          if (vv >= 0) qc = 1;
        }
        else if (!strcmp(var.obs,"ta")) {
          vv = ta;
          if (vv >= -50) qc = 1;
        }
        else if (!strcmp(var.obs,"td")) {
          vv = td;
          if (vv >= -50) qc = 1;
        }
        else if (!strcmp(var.obs,"dd")) {
          vv = ta - td;
          if (vv >= 0 && vv < 50) qc = 1;
        }
        else if (!strcmp(var.obs,"ws")) {
          vv = ws;
          if (vv > 0) qc = 1;
        }
        else if (!strcmp(var.obs, "wv")) {
          if (wd >= 0 && ws > 0) {
            u1 = -ws * sin( DEGRAD * wd );
            v1 = -ws * cos( DEGRAD * wd );
            qc = 1;
          }
        }
        else
          break;

        if (qc) {
          lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);
          if (xx >= 0 && xx <= var.NX && yy >= 0 && yy <= var.NY) {
//printf("%d, %f %f %f\n", stn_id, xx, yy, vv);
            stn_data[var.num_stn_obj].id = stn_id;
            stn_data[var.num_stn_obj].x = xx;
            stn_data[var.num_stn_obj].y = yy;
            if (!strcmp(var.obs,"wv")) {
              stn_data[var.num_stn_obj].d = u1;
              stn_data[var.num_stn_obj].v = v1;
            }
            else {
              stn_data[var.num_stn_obj].d = vv;
            }
            stn_data[var.num_stn_obj].wd = wd;
            stn_data[var.num_stn_obj].ws = ws;
            var.num_stn_obj++;
          }
        }
      }
    }
    url_fclose(fr);
  }
  //printf("num_stn_obj = %d\n", var.num_stn_obj);
  return 0;
}
