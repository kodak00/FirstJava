/*******************************************************************************
**
**  URL �Լ� �̿��� ���� GTS �ڷ� �����м� CGI ���α׷�
**
**=============================================================================*
**
**   o �ۼ��� : ����ȯ (2018.8.22)
**
********************************************************************************/
#include "gts_map_img.h"

extern struct INPUT_VAR var;       // ����� �Է� ����
extern struct STN_VAL stn_data[];  // ���� �ڷ�

/*******************************************************************************
 *
 *  �ڷ� �б�
 *
 *******************************************************************************/
int data_get()
{
  float data_avg, data_std, d1, d2;
  int   i, k, n;

  // 2. GTS �ڷ� �б�
  gts_data_get();
  if (var.num_stn_obj < 10) return -1;

  // 3. �ڷᰡ ���� ������ ��Ͽ��� ����.
  for (k = 0; k < var.num_stn_obj; k++) {
    if (stn_data[k].d < -98) {
      if (k < var.num_stn_obj-1) {
        for (i = k; i < var.num_stn_obj-1; i++)
          stn_data[i] = stn_data[i+1];
      }
      else {
        var.num_stn_obj--;
        break;
      }
      var.num_stn_obj--;
      k--;
    }
  }

  // 4. �������� ����
  if (strcmp(var.obs,"ws") != 0 && strcmp(var.obs,"wd") != 0) {
    // 4.1. ��հ� ���
    for (data_avg = 0, k = 0; k < var.num_stn_obj; k++) {
      data_avg += stn_data[k].d;
    }
    data_avg /= (float)(var.num_stn_obj);

    // 4.2. ǥ������ ���
    for (data_std = 0, k = 0; k < var.num_stn_obj; k++) {
      data_std += (data_avg - stn_data[k].d)*(data_avg - stn_data[k].d);
    }
    data_std = sqrt(data_std/(float)(var.num_stn_obj));

    // 4.3. �ذ� ����
    d1 = data_avg - 3.0*data_std;
    d2 = data_avg + 3.0*data_std;

    for (k = 0; k < var.num_stn_obj; k++) {
      if (stn_data[k].d < d1 || stn_data[k].d > d2) {
        if (k < var.num_stn_obj-1) {
          for (i = k; i < var.num_stn_obj-1; i++)
            stn_data[i] = stn_data[i+1];
        }
        else {
          var.num_stn_obj--;
          break;
        }
        var.num_stn_obj--;
        k--;
      }
    }
  }

  // 5. �浵�� ����
  for (k = 0; k < var.num_stn_obj; k++) {
    if (stn_data[k].x < var.lon1)
      stn_data[k].x += 360;
    else if (stn_data[k].x > var.lon2)
      stn_data[k].x -= 360;
  }
  return 0;
}

/*******************************************************************************
 *  GTS �ڷ� �б�
 *******************************************************************************/
int gts_data_get()
{
  FILE   *fp;
  URL_FILE *fr; 
  //struct lamc_parameter map;
  char   buf[1000], url[500], tmp[500], v[30][50];
  char   stn_tp[8], stn_tm[16], flag[16];
  float  vv, xx, yy, u1, v1;
  float  gh, rn, wd, ws, ta, td, pa, ps, pr, vs, hm, rn_day, ta_min1, ta_max1, tw;
  float  lat, lon, ht, ht_pa, ht_ta, ht_wd, ht_rn;
  int    stn_id, pt, wc, wp, ca, cd, ch, cl, cm, ct, rh;
  int    YY, MM, DD, HH, MI;
  int    seq, seq1;
  int    qc, code, rtn, now, i, j, k;
  int    GX, GY, SX, SY;

  // 2. ������ ������ �б�
  var.num_stn_obj = 0;
  seq2time(var.seq-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  if (strcmp(var.gts,"SFC") == 0) {
    sprintf(url, "http://172.20.134.91/url/gts_cht_syn2.php?tm=%04d%02d%02d%02d00&lon1=%f&lon2=%f&lat1=%f&lat2=%f&help=0",
            YY, MM, DD, HH, var.lon1, var.lon2, var.lat1, var.lat2);
    if ((fr = url_fopen(url, "r"))) {
      while (!url_feof(fr)) {
        url_fgets(buf, sizeof(buf), fr);
        if (buf[0] == '#') continue;

        qc = 0;
        sscanf(buf, "%s %s %d %f %f %f %d %f %f %f %f %d %d %d %d %d %d %d %d %d %f %f %d %f %f %f %f %f",
               stn_tp, stn_tm, &stn_id, &lon, &lat, &ps, &pt, &pr, &ta, &td, &hm,
               &vs, &wc, &wp, &ca, &cd, &ch, &cl, &cm, &ct,
               &wd, &ws, &rh, &rn, &pa, &ta_min1, &ta_max1, &tw);

        if (!strcmp(var.obs,"ps")) {
          vv = ps;
          if (vv > 600 && vv < 1200) qc = 1;
        }
        else if (!strcmp(var.obs,"pa")) {
          vv = pa;
          if (vv > 600 && vv < 1200) qc = 1;
        }
        else if (!strcmp(var.obs,"ta")) {
          vv = ta;
          if (vv >= -50) qc = 1;
        }
        else if (!strcmp(var.obs,"td")) {
          vv = td;
          if (vv >= -50) qc = 1;
        }
        else if (!strcmp(var.obs,"wn")) {
          vv = ta - td;
          if (vv >= 0 && vv < 50) qc = 1;
        }
        else if (!strcmp(var.obs,"tw")) {
          vv = tw;
          if (vv >= -50) qc = 1;
        }
        else if (!strcmp(var.obs,"ta_min")) {
          vv = ta_min1;
          if (vv >= -50) qc = 1;
        }
        else if (!strcmp(var.obs,"ta_max")) {
          vv = ta_max1;
          if (vv >= -50) qc = 1;
        }
        else if (!strcmp(var.obs,"hm")) {
          vv = hm;
          if (vv >= 0) qc = 1;
        }
        else if (!strcmp(var.obs,"ca")) {
          vv = ca;
          if (vv >= 0) qc = 1;
        }
        else if (!strcmp(var.obs,"cd")) {
          vv = cd;
          if (vv >= 0) qc = 1;
        }
        else if (!strcmp(var.obs,"r06")) {
          if (rn >= 0 && rh == 1) {
            vv = rn;
            qc = 1;
          }
        }
        else if (!strcmp(var.obs,"r12")) {
          if (rn >= 0 && rh == 2) {
            vv = rn;
            qc = 1;
          }
        }
        else if (!strcmp(var.obs,"ws")) {
          vv = ws;
          if (vv >= 0) qc = 1;
        }
        else if (!strcmp(var.obs,"wd")) {
          if (wd >= 0 && ws >= 0) {
            u1 = -ws * sin( DEGRAD * wd );
            v1 = -ws * cos( DEGRAD * wd );
            qc = 1;
          }
        }
        else
          break;

        if (qc) {
            stn_data[var.num_stn_obj].id = stn_id;
            stn_data[var.num_stn_obj].x = lon;
            stn_data[var.num_stn_obj].y = lat;
            if (!strcmp(var.obs,"wd")) {
              stn_data[var.num_stn_obj].d = u1;
              stn_data[var.num_stn_obj].v = v1;
            }
            else {
              stn_data[var.num_stn_obj].d = vv;
            }
            stn_data[var.num_stn_obj].wd = wd;
            stn_data[var.num_stn_obj].ws = ws;
            var.num_stn_obj++;
        }
      }
    }
    url_fclose(fr);
  }

  // 3. �����ڷ� �б�
  else {
    sprintf(url, "http://172.20.134.91/url/gts_cht_temp.php?pa=%s&tm=%04d%02d%02d%02d00&lon1=%f&lon2=%f&lat1=%f&lat2=%f&help=0",
            var.gts, YY, MM, DD, HH, var.lon1, var.lon2, var.lat1, var.lat2);
    if ((fr = url_fopen(url, "r"))) {
      while (!url_feof(fr)) {
        url_fgets(buf, sizeof(buf), fr);
        if (buf[0] == '#') continue;

        qc = 0;
        sscanf(buf, "%s %d %f %f %f %f %f %f %f %f %s",
               stn_tm, &stn_id, &lon, &lat, &pa, &gh, &ta, &td, &wd, &ws, flag);

        if (!strcmp(var.obs,"gh")) {
          vv = gh;
          if (vv >= -90) qc = 1;
        }
        else if (!strcmp(var.obs,"ta")) {
          vv = ta;
          if (vv >= -99) qc = 1;
        }
        else if (!strcmp(var.obs,"td")) {
          vv = td;
          if (vv >= -99) qc = 1;
        }
        else if (!strcmp(var.obs,"wn")) {
          vv = ta - td;
          if (vv >= 0 && vv < 99) qc = 1;
        }
        else if (!strcmp(var.obs,"ws")) {
          vv = ws;
          if (vv > 0) qc = 1;
        }
        else if (!strcmp(var.obs,"wd")) {
          if (wd >= 0 && ws > 0) {
            u1 = -ws * sin( DEGRAD * wd );
            v1 = -ws * cos( DEGRAD * wd );
            qc = 1;
          }
        }
        else
          break;

        if (qc) {
            stn_data[var.num_stn_obj].id = stn_id;
            stn_data[var.num_stn_obj].x = lon;
            stn_data[var.num_stn_obj].y = lat;
            if (!strcmp(var.obs,"wd")) {
              stn_data[var.num_stn_obj].d = u1;
              stn_data[var.num_stn_obj].v = v1;
            }
            else {
              stn_data[var.num_stn_obj].d = vv;
            }
            stn_data[var.num_stn_obj].wd = wd;
            stn_data[var.num_stn_obj].ws = ws;
            var.num_stn_obj++;
        }
      }
    }
    url_fclose(fr);
  }
  return 0;
}
