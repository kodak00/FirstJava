/*******************************************************************************
**
**  ���浵 �������� GTS �ٶ����� ������ ǥ�� ���α׷�
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.8.24)
**
********************************************************************************/
#include "gts_map_img.h"

struct INPUT_VAR var;              // ����� �Է� ����
struct STN_VAL stn_data[MAX_STN];  // ���� �ڷ�
float  **g, **g1;     // �����м����
int    trans = 0;       // ����ó�� ���� (obs=wv_10x)
FILE   *fp_log;

int level_conv(float data, float data_lvl[]);

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main()
{
  int  i, j, k;

  // 0. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(60);

  printf("HTTP/1.0 200 OK\n");
  printf("Server: Netscape-Enterprise/3.0\n");
  //printf("Content-type: text/plain\n\n");

  // 1. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    printf("Content-type: text/plain\n\n");
    printf("# input variable error<p>\n");
    return -1;
  }

  // 2. ���ڿ��� �Ҵ� �� �ʱ�ȭ
  var.grid = 0.5;
  var.NX = (int)((var.lon2-var.lon1)/var.grid);
  var.NY = (int)((var.lat2-var.lat1)/var.grid);

  // 4. �����ڷ� �б�
  data_get();

  // 5.1. U���� �����м�
  g = matrix(0, var.NY, 0, var.NX);
  for (j = 0; j <= var.NY; j++) {
    for (i = 0; i <= var.NX; i++)
      g[j][i] = -999;
  }

  grid_masking();
  data_obj();

  // 5.2. V���� �����м�
  if (!strcmp(var.obs,"wd")) {
    for (k = 0; k < var.num_stn_obj; k++)
      stn_data[k].d = stn_data[k].v;

    g1 = matrix(0, var.NY, 0, var.NX);
    for (j = 0; j <= var.NY; j++) {
      for (i = 0; i <= var.NX; i++)
        g1[j][i] = g[j][i];
    }

    grid_masking();
    data_obj();
  }

  // 6. Ȯ���� ���, ���ڿ��� Ȯ��
  grid_zooming(g);
  if (!strcmp(var.obs,"wd")) grid_zooming(g1);

  // 7. �̹��� ���� �� ����
  gts_ana_img();

  // 8. �޸� �ݳ�
  if (!strcmp(var.obs,"wd")) free_matrix(g1, 0, var.NY, 0, var.NX);
  free_matrix(g, 0, var.NY, 0, var.NX);

  alarm(0);
  return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
  char *qs;
  char tmp[256], item[32], value[32], tm[30], tm_st[30];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, bn_set = 0, zr, i, j;

  // 1. ���� �ʱⰪ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "0");    // ����ð�
  strcpy(var.obs, "ta");  // ���
  strcpy(var.map, "H1");  // HD����
  strcpy(var.obj, "mq");  // MQ������� �����м�
  var.grid = 8.0;         // km ����
  var.itv  = 1;
  var.sms  = 0;
  var.stn  = 9;         // �ִ��ְ��� ����
  var.zoom_level = 0;   // ��ü����
  var.zoom_rate = 2;    // 2�� Ȯ�밡 �⺻
  var.mq_mp = 0.0005;   // MQ: ����1
  var.mq_sm = 1.0;      // MQ: ����2
  var.bn_r1 = 30;       // Barnes: 1�� �ݰ� = 30km
  var.bn_r2 = 10;       // Barnes: 2�� �ݰ� = 10km
  var.title = 1;        // ���� ǥ�� ����(1:ǥ��, 0:ǥ�� ����)
  strcpy(var.color, "C4");  // ����ǥ
  var.disp = 0;
  var.help = 0;

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"gts")) strcpy(var.gts, value);
    else if ( !strcmp(item,"obs")) strcpy(var.obs, value);
    else if ( !strcmp(item,"map")) strcpy(var.map, value);
    else if ( !strcmp(item,"obj")) strcpy(var.obj, value);
    else if ( !strcmp(item,"cont")) var.cont = atoi(value);
    else if ( !strcmp(item,"obs")) strcpy(var.obs, value);
    else if ( !strcmp(item,"tm"))  strcpy(tm, value);
    else if ( !strcmp(item,"tm_st")) strcpy(tm_st, value);
    else if ( !strcmp(item,"grid")) var.grid = atof(value);
    else if ( !strcmp(item,"itv")) var.itv = atoi(value);
    else if ( !strcmp(item,"lon1")) var.lon1 = atof(value);
    else if ( !strcmp(item,"lon2")) var.lon2 = atof(value);
    else if ( !strcmp(item,"lat1")) var.lat1 = atof(value);
    else if ( !strcmp(item,"lat2")) var.lat2 = atof(value);
    else if ( !strcmp(item,"sms")) var.sms = atoi(value);
    else if ( !strcmp(item,"zoom_level")) var.zoom_level = atoi(value);
    else if ( !strcmp(item,"zoom_rate"))  var.zoom_rate = atoi(value);
    else if ( !strcmp(item,"zoom_x")) strcpy(var.zoom_x, value);
    else if ( !strcmp(item,"zoom_y")) strcpy(var.zoom_y, value);
    else if ( !strcmp(item,"mp"))   var.mq_mp = atof(value);
    else if ( !strcmp(item,"sm"))   var.mq_sm = atof(value);
    else if ( !strcmp(item,"r1")) { var.bn_r1 = atof(value);  bn_set = 1; }
    else if ( !strcmp(item,"r2")) { var.bn_r1 = atof(value);  bn_set = 1; }
    else if ( !strcmp(item,"disp")) var.disp = atoi(value);
    else if ( !strcmp(item,"size")) var.size = atoi(value);
    else if ( !strcmp(item,"color")) strcpy(var.color, value);
    else if ( !strcmp(item,"legend")) var.legend = atoi(value);
    else if ( !strcmp(item,"title")) var.title = atoi(value);
    else if ( !strcmp(item,"help")) var.help = atoi(value);
  }
  if (var.grid < 0.001) var.grid = 0.5;
  var.size -= BORDER_pixel*2;

  // 3. ����ð� �� ���� �����ð� ����
  get_time(&iYY, &iMM, &iDD, &iHH, &iMI, &iSS);
  iseq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm') - 3;
  seq2time(iseq, &iYY, &iMM, &iDD, &iHH, &iMI, 'm', 'n');

  // 4. ��û�ð� ����
  if (strlen(tm) >= 10) {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
  }
  var.seq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');

  // 5. ���۽ð� ���� (�ִ� ���)
  if (strlen(tm_st) >= 10) {
    strncpy(tmp, &tm_st[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm_st[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm_st[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm_st[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm_st[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
  }
  var.seq_st = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');

  return 0;
}

/*******************************************************************************
 *
 *  ������ �̹��� ���� �� ����
 *
 *******************************************************************************/
int gts_ana_img()
{
  gdImagePtr im;
  FILE   *fp;
  char   dname[120], txt[50];
  int    color_lvl[256];
  float  data_lvl[256];

  // 1. �̹��� ���� ����
  if (var.title == 0)
    var.title_pixel = 0;
  else
    var.title_pixel = TITLE_pixel;

  var.NI = var.size;
  var.NJ = (int)(var.NI*(float)(var.NY)/(float)(var.NX)/cos((var.lat1+var.lat2)*DEGRAD*0.5));
  var.GI = var.NI;
  //if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + var.title_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI+BORDER_pixel*2, var.GJ+BORDER_pixel*2);
  color_table(im, color_lvl, data_lvl);
  gdImageFilledRectangle(im, 0, 0, var.GI+BORDER_pixel*2, var.GJ+BORDER_pixel*2, color_lvl[241]);

  // 3. �����ڷ� �׸���
  if (!strcmp(var.obs,"wd")) {
    if (var.cont >= 1) wind_disp(im, color_lvl, data_lvl);
  }
  else {
    if (var.cont >= 3) grid_disp(im, color_lvl, data_lvl);
    if (var.cont != 4) data_contour(im, color_lvl, data_lvl);
  }

  // 5. ���� �׸���
  if (var.title != 0) title_disp(im, color_lvl);

  // 6. ��꿡 ���� ������ ǥ��
  sprintf(txt, "#%d", var.num_stn_obj);
  //gdImageFilledRectangle(im, var.NI-48, var.GJ-16, var.NI-2, var.GJ-2, color_lvl[241]);
  gdImageString(im, gdFontMediumBold, var.NI-55, var.GJ, txt, color_lvl[244]);

  // 7. ���� �׸���
  if (var.legend == 1 && var.cont > 1) legend_disp(im, color_lvl, data_lvl);

  // 8. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);
  gdImageDestroy(im);
  return 0;
}

/*=============================================================================*
 *  ����ǥ
 *=============================================================================*/
int color_table(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  FILE  *fp;
  URL_FILE *fr; 
  char  color_file[120], buf[1000];
  int   num_color;
  int   R, G, B;
  int   YY, MM, DD, HH, MI, dseq;
  float v1, diff, avg, std, dd;
  int   i, j, k;

  // 1. ��󺯼��� ����ǥ ���� ����
  if (!strcmp(var.obs,"ws"))
    sprintf(color_file, "%scolor_upp_ws.rgb", COLOR_SET_DIR);
  else if (!strcmp(var.obs,"wd"))
    sprintf(color_file, "%scolor_upp_ws.rgb", COLOR_SET_DIR);
  else if (!strcmp(var.obs,"wn"))
    sprintf(color_file, "%scolor_upp_wn.rgb", COLOR_SET_DIR);
  else if (!strcmp(var.obs,"gh"))
    sprintf(color_file, "%scolor_%s_%s.rgb", COLOR_SET_DIR, var.gts, var.obs);
  else if (!strcmp(var.obs,"ta"))
    sprintf(color_file, "%scolor_upp_ta.rgb", COLOR_SET_DIR);
  else if (!strcmp(var.obs,"td"))
    sprintf(color_file, "%scolor_upp_ta.rgb", COLOR_SET_DIR);

  // 2. ����ǥ ���ϰ� ������ �б�
  var.num_color = num_color = 0;
  if ((fp = fopen(color_file, "r")) != NULL) {
    while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
      color_lvl[num_color] = gdImageColorAllocate(im, R, G, B);
      data_lvl[num_color] = v1;
      num_color++;
      if (num_color > 119) break;
    }
    fclose(fp);
  }
  else {
    num_color = -1;
  }
  var.num_color = num_color;

  // 3. ��Ÿ ����ǥ ����
  color_lvl[240] = gdImageColorAllocate(im, 210, 210, 210);   // ����1
  color_lvl[241] = gdImageColorAllocate(im, 255, 255, 255);   // ����2
  color_lvl[242] = gdImageColorAllocate(im, 30, 30, 30);      // ������
  color_lvl[243] = gdImageColorAllocate(im, 12, 28, 236);     // ����
  color_lvl[244] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  color_lvl[245] = gdImageColorAllocate(im, 240, 240, 240);
  color_lvl[246] = gdImageColorAllocate(im, 255, 0, 0);
  color_lvl[247] = gdImageColorAllocate(im, 0, 0, 255);
  color_lvl[248] = gdImageColorAllocate(im, 160, 160, 160);   // ����3
  color_lvl[249] = gdImageColorAllocate(im, 90, 90, 90);      // �ñ����

  // 4. ��°� �̽����� ���, ������ ������ �������� ����
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  if (!strcmp(var.obs,"ta")) {
    if (!strcmp(var.gts,"925")) {
      if (MM >= 5 && MM <= 10)
        diff = 10;
      else
        diff = 30;
    }
    else if (!strcmp(var.gts,"850")) {
      if (MM >= 5 && MM <= 10)
        diff = 20;
      else
        diff = 30;
    }
    else if (!strcmp(var.gts,"700")) 
      diff = 40;
    else if (!strcmp(var.gts,"500")) 
      diff = 50;
    else if (!strcmp(var.gts,"300")) 
      diff = 70;
    else if (!strcmp(var.gts,"200")) 
      diff = 90;
    else if (!strcmp(var.gts,"100")) 
      diff = 90;

    for (k = 0; k < var.num_color; k++)
      data_lvl[k] -= diff;
  }
  else if (!strcmp(var.obs,"td")) {
    if (!strcmp(var.gts,"925")) {
      if (MM >= 5 && MM <= 10)
        diff = 10;
      else
        diff = 30;
    }
    else if (!strcmp(var.gts,"850")) {
      if (MM >= 5 && MM <= 10)
        diff = 20;
      else
        diff = 30;
    }
    else if (!strcmp(var.gts,"700")) 
      diff = 40;
    else if (!strcmp(var.gts,"500")) 
      diff = 50;
    else if (!strcmp(var.gts,"300")) 
      diff = 70;
    else if (!strcmp(var.gts,"200")) 
      diff = 90;
    else if (!strcmp(var.gts,"100")) 
      diff = 100;

    for (k = 0; k < var.num_color; k++)
      data_lvl[k] -= diff;
  }
  return num_color;
}

/*=============================================================================*
 *  �����ڷ� ǥ��
 *=============================================================================*/
int grid_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  float rate_x = (float)(var.NX)/(float)(var.NI);
  float rate_y = (float)(var.NY)/(float)(var.NJ);
  float x, y, dx, dy, d1, d2, dd;
  int   i, j, k, ix, iy, color1;

  // 0. ����ó��
  if (var.num_stn_obj <= 0) {
    gdImageString(im, gdFontLarge, 100, 100, "No Data", color_lvl[244]);
    return -1;
  }
  if (var.num_color <= 0) {
    gdImageString(im, gdFontLarge, 100, 100, "No Color Level", color_lvl[244]);
    return -1;
  }

  // 1. Y�� ����
  for (j = 1; j < var.NJ; j++) {
    y = (float)j*rate_y;
    iy = (int)y;
    dy = y - iy;
    if (iy < 0 || iy > var.NY-1) continue;

    // 2. X������ ����
    for (i = 1; i < var.NI; i++) {
      x = (float)i*rate_x;
      ix = (int)x;
      dx = x - ix;
      if (ix < 0 || ix > var.NX-1) continue;

      // 3. �ش� �̹��� �ȼ� ��ġ�� ���� ���
      if (g[iy][ix] > -90 && g[iy][ix+1] > -90 && g[iy+1][ix] > -90 && g[iy+1][ix+1] > -90) {
          d1 = (1.0-dx)*g[iy][ix] + dx*g[iy][ix+1];
          d2 = (1.0-dx)*g[iy+1][ix] + dx*g[iy+1][ix+1];
          dd = (1.0-dy)*d1 + dy*d2;
      }
      else
        dd = g[iy][ix];

      // 4. �ڷᰡ �������� ������ ǥ��
      if (dd > -98) {
        color1 = color_lvl[var.num_color-1];
        for (k = 0; k < var.num_color; k++) {
          if (dd <= data_lvl[k]) {
            color1 = color_lvl[k];
            break;
          }
        }
        gdImageSetPixel(im, i+BORDER_pixel, var.GJ-j+BORDER_pixel, color1);
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  �ٶ����� ǥ��
 *=============================================================================*/
int wind_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  float rate_x = (float)(var.NX)/(float)(var.NI);
  float rate_y = (float)(var.NY)/(float)(var.NJ);
  float x, y, dx, dy, d1, d2, dd, uu1, vv1, ws;
  float Vs, As, hs, a, b, theta0, theta1, theta, zm;
  int   i, j, k, ix, iy, color1;
  int   x1, y1, x2, y2, x3, y3;
  int   ng;

  // 0. ����ó��
  if (var.num_stn_obj <= 0) {
    gdImageString(im, gdFontLarge, 100, 100, "No Data", color_lvl[244]);
    return -1;
  }
  if (var.num_color <= 0) {
    gdImageString(im, gdFontLarge, 100, 100, "No Color Level", color_lvl[244]);
    return -1;
  }

  // 1. �ٶ����͸� ���� ����
  if (trans != 1) {
    //color1 = color_lvl[248];
    color1 = color_lvl[241];
    for (j = 1; j < var.NJ; j++) {
      iy = j*(float)(var.NY)/(float)(var.NJ);

      for (i = 1; i < var.NI; i++) {
        ix = i*(float)(var.NX)/(float)(var.NI);
        if (g[iy][ix] >= -80 && g1[iy][ix] >= -80) gdImageSetPixel(im, i+BORDER_pixel, var.GJ-j+BORDER_pixel, color1);
      }
    }
  }

  // 2. �ٶ����� ǥ�� ����(���ڰ��ݿ� ����)
  if (var.zoom_level == 0)
    ng = 6;
  else
    ng = 8;
  ng = 12;

  // 3. �ٶ����� ǥ��
  for (j = ng; j < var.NJ; j += ng) {
    y = (float)j*rate_y;
    iy = (int)y;
    dy = y - iy;
    if (iy < 0 || iy > var.NY-1) continue;

    // 2. X������ ����
    for (i = 1; i < var.NI; i += ng) {
      x = (float)i*rate_x;
      ix = (int)x;
      dx = x - ix;
      if (ix < 0 || ix > var.NX-1) continue;

      // 3.1. �ش� �̹��� �ȼ� ��ġ�� ���� ���
      uu1 = g1[iy][ix];
      vv1 = g[iy][ix];
      if (uu1 < -90 || vv1 < -90) continue;

      // 3.2. ǳ������ ����ǥ ����
      ws = sqrt(uu1*uu1 + vv1*vv1);
      color1 = color_lvl[var.num_color-1];
      for (k = 0; k < var.num_color; k++) {
        if (ws <= data_lvl[k]) {
          color1 = color_lvl[k];
          break;
        }
      }

      // 3.3. ȭ��� ǥ��
      if (trans == 1) color1 = color_lvl[244];
      wind_arrow(im, (float)(i+BORDER_pixel), (float)(var.GJ-j+BORDER_pixel), uu1, vv1, ws, color1);
    }
  }
  return 0;
}

/*============================================================================*
 *  Wind Arrow (ȭ��ũ��� ����, ǳ���� �������� ����)
 *============================================================================*/
int wind_arrow(im, x0, y0, u, v, ws, color)
  gdImagePtr im;
  float  x0, y0;
  float  u, v, ws;
  int    color;
{
  float  vs1 = 6.0, vs2 = 5.0;
  float  theta, theta0, theta1, a, b, hs;
  int    x1, y1, x2, y2, x3, y3;

  // ��ǳ�� ����� ���
  if (ws < 1) {
    gdImageFilledRectangle(im, x0, y0, x0+1, y0+1, color);
    return 0;
  }

  // ����ȭ
  u /= ws;  v /= ws;

  // ȭ���
  x1 = x0 - vs1*u;  y1 = y0 + vs1*v;
  x2 = x0 + vs1*u;  y2 = y0 - vs1*v;
  gdImageLine(im, (int)x1, (int)y1, (int)x2, (int)y2, color);
  if (ws >= 40) gdImageLine(im, (int)x1, (int)y1+1, (int)x2, (int)y2+1, color);

  // ȭ����
  theta0 = 150.0*DEGRAD;
  theta1 = atan2(v, u);
  theta  = theta1 + theta0;
  x3 = x2 + vs2*cos(theta);
  y3 = y2 - vs2*sin(theta);
  gdImageLine(im, (int)x2, (int)y2, (int)x3, (int)y3, color);

  return 0;
}

/*============================================================================*
 *  Wind Arrow (ǳ���� ũ�� ȭ�쵵 Ŀ��)
 *============================================================================*/
int wind_arrow1(im, x0, y0, u, v, ws, color)
  gdImagePtr im;
  float  x0, y0;
  float  u, v, ws;
  int    color;
{
  int    x1, y1, x2, y2, x3, y3;
  float  theta, theta0, theta1, a, b, hs;
  //float  zm = (float)(var.NI)/(float)(var.NX*var.grid);
  float  zm = 0.3;
  float  Vs = 2.0, As = 1.2;

  // ȭ���
  x1 = x0 - (Vs * u)*zm;
  y1 = y0 + (Vs * v)*zm;
  x2 = x0 + (Vs * u)*zm;
  y2 = y0 - (Vs * v)*zm;
  gdImageLine(im, (int)x1, (int)y1, (int)x2, (int)y2, color);

  // ȭ����
  if (ws > 0.2) {
    theta0 = 170.0*DEGRAD;

    theta1 = atan2(v, u);
    theta  = theta1 + theta0;
    hs = As * ws;
    a  = hs * cos(theta);
    b  = hs * sin(theta);
    x3 = x2 + a*zm;
    y3 = y2 - b*zm;
    gdImageLine(im, (int)x2, (int)y2, (int)x3, (int)y3, color);

    theta = theta1 - theta0;
    hs = As * ws;
    a  = hs * cos(theta);
    b  = hs * sin(theta);
    x3 = x2 + a*zm;
    y3 = y2 - b*zm;
    gdImageLine(im, (int)x2, (int)y2, (int)x3, (int)y3, color);
  }
  return 0;
}

/******************************************************************************
 *
 *  contour line
 *
 ******************************************************************************/
int data_contour(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  float  *p1, *p2;
  float  d[5][5], q1, q2, q3, q4;
  float  a1, a2, a3, a4;
  float  x, y, f;
  float  rate_x = (float)(var.NI)/(float)(var.NX);
  float  rate_y = (float)(var.NJ)/(float)(var.NY);
  int    x1, y1, x2, y2;
  int    i, j, i1, j1, n, m;
  int    v[5], vmax, vmin, v1;

  for (j = 0; j < var.NY; j++) {
    p1 = &g[j][0];
    p2 = &g[j+1][0];

    for (i = 0; i < var.NX; i++, p1++, p2++) {
      q1 = *p1;
      q2 = *(p1+1);
      q3 = *(p2+1);
      q4 = *p2;

      if (q1 > -99.0 && q2 > -99.0 && q3 > -99.0 && q4 > -99.0) {
        v[0] = level_conv(q1, data_lvl);
        v[1] = level_conv(q2, data_lvl);
        v[2] = level_conv(q3, data_lvl);
        v[3] = level_conv(q4, data_lvl);
        v[4] = v[0];
        imax_min(v, 4, &vmax, &vmin);
        if (vmax != vmin) {
          for (v1 = vmin; v1 < vmax; v1++) {
            f = data_lvl[v1];
            m = 0;
            for (n = 0; n < 4; n++) {
              if (v[n] != v[n+1]) {
                if (n == 0) {
                  x = (f - q1) / (q2 - q1);
                  y = 0.0;
                }
                else if (n == 1) {
                  x = 1.0;
                  y = (f - q2) / (q3 - q2);
                }
                else if (n == 2) {
                  x = (f - q4) / (q3 - q4);
                  y = 1.0;
                }
                else if (n == 3) {
                  x = 0.0;
                  y = (f - q1) / (q4 - q1);
                }
                if (x >= 0.0 && x <= 1.0 && y >= 0.0 && y <= 1.0) {
                  m++;
                  if (m == 1) {
                    x1 = (int)((x + i)*rate_x + 0.5);
                    y1 = var.GJ - (int)((y + j)*rate_y + 0.5);
                  }
                  else {
                    x2 = (int)((x + i)*rate_x + 0.5);
                    y2 = var.GJ - (int)((y + j)*rate_y + 0.5);
                  }
                }
              }
            }
            if (m >= 2) {
              x1 += BORDER_pixel;  y1 += BORDER_pixel;
              x2 += BORDER_pixel;  y2 += BORDER_pixel;
              if (var.cont == 2)
                gdImageLine(im, x1, y1, x2, y2, color_lvl[v1]);
              else if (var.cont == 1)
                gdImageLine(im, x1, y1, x2, y2, color_lvl[248]);
              else
                gdImageLine(im, x1, y1, x2, y2, color_lvl[248]);
            }
          }
        }
      }
    }
  }
  return 0;
}

/*============================================================================*
 *  data --> level
 *============================================================================*/
int level_conv(float data, float data_lvl[])
{
  int v = var.num_color - 1;
  int k;

  for (k = 0; k < var.num_color; k++) {
    if (data < data_lvl[k]) {
      v = k;
      break;
    }
  }
  return v;
}

/*============================================================================*
 *  minimum & maximum of level
 *============================================================================*/
int imax_min(
  int *v,     // [�Է�] �迭
  int n,      // [�Է�] �迭�� ����
  int *imax,  // [���] �ּҰ�
  int *imin   // [���] �ִ밪
)
{
  int i;

  *imax = v[0];
  *imin = v[0];

  for (i = 1; i < n; i++) {
    if (v[i] > *imax) *imax = v[i];
    if (v[i] < *imin) *imin = v[i];
  }
   return 0;
}

/*=============================================================================*
 *  EUC-KR���ڿ��� UTF-8�� ��ȯ
 *=============================================================================*/
int euckr2utf(char *str, char *out)
{
  iconv_t convp;
  size_t  ileft, oleft;
  int     err, len = strlen(str);

  ileft = len;
  oleft = len * 2;

  convp = iconv_open("UTF-8", "euc-kr");
  err = iconv(convp, &str, &ileft, &out, &oleft);
  iconv_close(convp);

  return err;
}

/*=============================================================================*
 *  ���� ǥ��(�ѱ�ó��)
 *=============================================================================*/
int title_disp(gdImagePtr im, int color_lvl[])
{
  char   title[80], gov_name[40], tm_fc_str[40], num_stn_str[10], tmp[50];
  char   title_utf[100], gov_utf[100];
  double font_size = 11.5;
  int    brect[8];
  int    YY, MM, DD, HH, MI;
  int    ok_kma, ok_tot, ok_oth;
  int    x, i, k;

  // 0. ���� ǥ�� ���� Ȯ��
  if (var.title == 0) return 0;

  // 1. ���񿵿��� ���� ó��
  gdImageFilledRectangle(im, 0, 0, var.GI, var.title_pixel, color_lvl[241]);

  // 2. ������
  strcpy(title, var.gts);
  if (strcmp(var.gts,"SFC") != 0) strcat(title,"hPa");
  strcat(title," ");

  if      (!strcmp(var.obs,"r06")) strcat(title,"����(6H)");
  else if (!strcmp(var.obs,"r12")) strcat(title,"����(12H)");
  else if (!strcmp(var.obs,"ws"))  strcat(title,"ǳ��");
  else if (!strcmp(var.obs,"ta"))  strcat(title,"���");
  else if (!strcmp(var.obs,"tw"))  strcat(title,"����");
  else if (!strcmp(var.obs,"td"))  strcat(title,"�̽����µ�");
  else if (!strcmp(var.obs,"wn"))  strcat(title,"����");
  else if (!strcmp(var.obs,"hm"))  strcat(title,"����");
  else if (!strcmp(var.obs,"pv"))  strcat(title,"�������");
  else if (!strcmp(var.obs,"sh"))  strcat(title,"���");
  else if (!strcmp(var.obs,"gh"))  strcat(title,"��������");
  else if (!strcmp(var.obs,"pa"))  strcat(title,"�������");
  else if (!strcmp(var.obs,"ps"))  strcat(title,"�ظ���");
  else if (!strcmp(var.obs,"ca"))  strcat(title,"���");
  else if (!strcmp(var.obs,"cd"))  strcat(title,"�������");
  else if (!strcmp(var.obs,"vs"))  strcat(title,"����");
  else if (!strcmp(var.obs,"ch"))  strcat(title,"���");

  for (i = 0; i < 100; i++)
    title_utf[i] = 0;
  euckr2utf(title, title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 5, (int)(font_size+5), title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], FONTTTF, font_size, 0.0, 6, (int)(font_size+5), title_utf);

  // 3. �ð� ���ڿ�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'y');
  sprintf(tm_fc_str, "%04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, MI);
  gdImageString(im, gdFontLarge, 125, 1, tm_fc_str, color_lvl[244]);
  gdImageString(im, gdFontLarge, 126, 1, tm_fc_str, color_lvl[244]);

  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int legend_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  char   leg_utf[100];
  char   txt[20];
  double font_size = 9.5;
  float  dy = (float)(var.NJ)/(float)(var.num_color);
  int    x_lgd = BORDER_pixel+var.NI-LEG_pixel, y_lgd = BORDER_pixel+var.GJ;
  int    brect[8], i;
  int    x, y, k;

  if (var.legend != 1) return 0;
  if (var.num_color <= 0) return -1;

  // 1. ���� ���� ǥ��
  for (k = 0; k < var.num_color; k++) {
    y = y_lgd - dy*k;
    gdImageFilledRectangle(im, x_lgd, y-dy, x_lgd+8, y, color_lvl[k]);
  }
  gdImageRectangle(im, x_lgd-1, BORDER_pixel, x_lgd+8, y_lgd-1, color_lvl[242]);

  // 2. ���ʰ� ǥ��
  gdImageFilledRectangle(im, x_lgd+9, BORDER_pixel, x_lgd+LEG_pixel, y_lgd, color_lvl[241]);
  if (!strcmp(var.obs,"ta") || !strcmp(var.obs,"tw") || !strcmp(var.obs,"td")) {
    for (k = 0; k < var.num_color-1; k += 2) {
      y = y_lgd - (k+1)*dy - 5;
      sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, x_lgd+12, y, txt, color_lvl[244]);
    }
  }
  else {
    for (k = 0; k < var.num_color-1; k++) {
      y = y_lgd - (k+1)*dy - 5;
      sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, x_lgd+12, y, txt, color_lvl[244]);
    }
  }

  // 3. ���� ���� ǥ��
  if      (!strcmp(var.obs,"rn_ex")) strcpy(txt,"");
  else if (!strncmp(var.obs,"rn",2)) strcpy(txt,"mm");
  else if (!strncmp(var.obs,"sd",2)) strcpy(txt,"cm");
  else if (!strncmp(var.obs,"ws",2)) strcpy(txt,"m/s");
  else if (!strncmp(var.obs,"ta",2)) strcpy(txt,"C");
  else if (!strncmp(var.obs,"tw",2)) strcpy(txt,"C");
  else if (!strncmp(var.obs,"td",2)) strcpy(txt,"C");
  else if (!strncmp(var.obs,"wn",2)) strcpy(txt,"C");
  else if (!strncmp(var.obs,"hm",2)) strcpy(txt,"%");
  else if (!strncmp(var.obs,"pv",2)) strcpy(txt,"hPa");
  else if (!strncmp(var.obs,"sh",2)) strcpy(txt,"g/kg");
  else if (!strncmp(var.obs,"gh",2)) strcpy(txt,"m");
  else if (!strncmp(var.obs,"pa",2)) strcpy(txt,"hPa");
  else if (!strncmp(var.obs,"ps",2)) strcpy(txt,"hPa");
  else if (!strncmp(var.obs,"ss",2)) strcpy(txt,"min");
  else if (!strncmp(var.obs,"si",2)) strcpy(txt,"MJ");
  else if (!strncmp(var.obs,"ca",2)) strcpy(txt,"1/10");
  else if (!strncmp(var.obs,"ch",2)) strcpy(txt,"km");
  else if (!strncmp(var.obs,"vs",2)) strcpy(txt,"km");
  else if (!strncmp(var.obs,"ts",2)) strcpy(txt,"C");
  else if (!strncmp(var.obs,"tg",2)) strcpy(txt,"C");
  else if (!strncmp(var.obs,"te",2)) strcpy(txt,"C");
  else if (!strncmp(var.obs,"pm",2)) strcpy(txt,"ug/m3");
  else if (!strncmp(var.obs,"uw",2)) strcpy(txt,"%");
  else strcpy(txt,"");

  x = x_lgd + 3;
  if (strlen(txt) > 4) x = x_lgd - 5;
  //if (var.title == 0) x -= 20;
  gdImageString(im, gdFontLarge, x, 3, txt, color_lvl[244]);

  return 0;
}
