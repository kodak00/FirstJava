/******************************************************************************
**
**  UF RADAR �ڷ� ������ CGI ���α׷�
**
**============================================================================*
**
**     o �ۼ��� : ����ȯ (2010. 8. 3)
**
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "cgiutil.h"
#include "rsl_wrc.h"

#define  RDR_UF_RAW_DIR  "/DATA/RDR/RAW"
#define  RDR_UF_QCD_DIR  "/DATA/RDR/QCD"
#define  RDR_UF_HSR_DIR  "/DATA/RDR/HSR"
#define  RDR_UF_LNG_DIR  "/DATA/RDR/LNG"

struct INPUT_VAR
{
    int  seq;
    int  YY;
    int  MM;
    int  DD;
    int  HH;
    int  MI;
    char stn_cd[16];
    int  qcd;
    int  vol;
    int  sw;
    char mode;
    int  help;
    char fname[120];
    int  size;
} var;

/******************************************************************************
 *
 *  MAIN
 *
 ******************************************************************************/
int main()
{
    int  code;

    //
    // ��� �ʱ�ȭ
    //
    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(120);

    printf("HTTP/1.0 200 OK\n");
    printf("Server: Netscape-Enterprise/3.0\n");

    //
    // ����� �Է� ���� �м�
    //
    if ( (code = user_input()) < 0)
    {
        printf("Content-type: text/plain\n\n");

        if (code == -2)
            printf("# no file\n");
        else
            printf("# input variable error\n");
        return -1;
    }

    //
    // �ڷ� ���
    //
    if (var.mode == 'B')
    {
        printf("Content-type: data/data\n\n");
        disp_bin();
    }
    else
    {
        printf("Content-type: text/plain\n\n");
        disp_txt();
    }

    alarm(0);
    return 0;
}

/******************************************************************************
 *
 *  ����� ��û�ڷ� �м�
 *
 ******************************************************************************/
int user_input()
{
    char *qs;
    char tmp[256], item[32], value[32], tm[30], fname[120];
    int  YY, MM, DD, HH, MI, SS;
    int  seq, seq1, i, j;

    //
    // ���� �ʱ�ȭ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
    //

    strcpy(tm, "");
    strcpy(var.stn_cd, "");
    var.vol = 0;
    var.sw = 0;
    var.mode = 'A';
    var.help = 1;

    //
    // GET ������� ���޵� ����� �Էº������� �ص�
    //
    qs = getenv("QUERY_STRING");
    if (qs == NULL) return -1;

    for (i = 0; qs[0] != '\0'; i++)
    {
        getword (value, qs, '&');
        getword (item, value, '=');

        if      ( !strcmp(item,"tm"))   strcpy(tm,value);
        else if ( !strcmp(item,"stn"))  strcpy(var.stn_cd,value);
        else if ( !strcmp(item,"qcd"))  var.qcd = atoi(value);
        else if ( !strcmp(item,"vol"))  var.vol = atoi(value);
        else if ( !strcmp(item,"sw"))   var.sw = atoi(value);
        else if ( !strcmp(item,"mode")) var.mode = value[0];
        else if ( !strcmp(item,"help")) var.help = atoi(value);
    }

    if (strlen(var.stn_cd) < 3) return -1;

    //
    // ��û�ð� �� ���� ����ð� ����
    //
    if (strlen(tm) >= 12)
    {
        strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  YY = atoi(tmp);
        strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  MM = atoi(tmp);
        strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  DD = atoi(tmp);
        strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  HH = atoi(tmp);
        strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  MI = atoi(tmp);
        seq = time2seq(YY, MM, DD, HH, MI, 'm');
    }
    else
    {
        get_time(&YY, &MM, &DD, &HH, &MI, &SS);
        seq = time2seq(YY, MM, DD, HH, MI, 'm');
    }

    //
    // ���� ����� �ð����� UF �ڷḦ ã��
    //
    for (var.seq = -1, j = 0; j <= 20; j++)
    {
        for (i = 0; i < 2; i++)
        {
            if (i == 0)
                seq1 = seq + j;
            else
                seq1 = seq - j;

            seq2time(seq1, &(var.YY), &(var.MM), &(var.DD), &(var.HH), &(var.MI), 'm', 'n');
            if (rdr_uf_file() >= 0)
            {
                var.seq = seq1;
                break;
            }
        }
        if (var.seq > 0) break;
    }
    if (var.seq < 0) return -2;

    return 0;
}

/******************************************************************************
 *
 *  ASCII mode
 *
 ******************************************************************************/
int disp_txt()
{
    Radar  *radar;
    Volume *volume;
    Sweep  *sweep;
    Ray    *ray;
    char   fname[120];
    float  ec;
    int    seq, YY, MM, DD, HH, MI, SS;
    int    i, j, k;

    if (var.help == 1)
    {
        printf("#--------------------------------------------------------------------------------------------------\n");
        printf("#  [�Է��μ�����][��] ?tm=201001051200&stn=KWK&vol=0&sw=0&mode=A&help=1\n");
        printf("#--------------------------------------------------------------------------------------------------\n");
        printf("#   fname : UF���ϸ� (���ϸ����� �ð��� KST)\n");
        printf("#      tm : UF���� ����� ��ϵ� �������� �ð� (KST)\n");
        printf("#     lat : ���̴������� ���� (��.��.��)\n");
        printf("#     lon : ���̴������� �浵 (��.��.��)\n");
        printf("#      ht : ���̴� ���׳� �ع߰��� (m)\n");
        printf("#--------------------------------------------------------------------------------------------------\n");
        printf("#      Vn : Volume Number\n");
        printf("#      sw : sweep number\n");
        printf("#    nray : �ش� sweep�� ��(ray)�� ��\n");
        printf("#    evel : �ش� sweep�� ������ (degree)\n");
        printf("#--------------------------------------------------------------------------------------------------\n");
        printf("#    nbin : Number of array elements for 'Range' \n");
        printf("#    gate : gate_size : Data gate size (meters)\n");
        printf("#    bin1 : range_bin1 : Range to first gate.(meters)\n");
        printf("#   width : Beam-Width (degree)\n");
        printf("# nyq_vel : Nyquist velocity (m/s)\n");
        printf("#--------------------------------------------------------------------------------------------------\n");
    }

    //
    // ���� ����
    //
    radar = RSL_uf_to_radar(var.fname);
    if (radar == NULL)
    {
        printf("# radar rsl open error (%s)\n", var.fname);
        return -1;
    }

    //
    // ���� ����
    //
    YY = radar->h.year;
    MM = radar->h.month;
    DD = radar->h.day;
    HH = radar->h.hour;
    MI = radar->h.minute;
    SS = (int)(radar->h.sec + 0.5);

    seq = time2seq(YY, MM, DD, HH, MI, 'm');
    seq2time(seq+9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

    printf("#                        fname :           tm :       lat :       lon :   ht : Vn sw   nray   evel\n");

    if (var.qcd == 1)
        sprintf(fname, "RDR_%s_QCD_%04d%02d%02d%02d%02d.uf", var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
    else
        sprintf(fname, "RDR_%s_%04d%02d%02d%02d%02d.uf", var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);

    printf("%30s : %04d%02d%02d%02d%02d", var.fname, YY, MM, DD, HH, MI);
    printf(" : %3d.%02d.%02d", radar->h.latd, radar->h.latm, radar->h.lats);
    printf(" : %3d.%02d.%02d", radar->h.lond, radar->h.lonm, radar->h.lons);
    printf(" : %4d", radar->h.height);

    //
    // �ڷ��� ����
    //
    if ((volume = radar->v[var.vol]) == NULL)
    {
        printf("\n# radar rsl : volume read error (%s,%d)\n", var.fname, var.vol);
        return -2;
    }

    if ((sweep = volume->sweep[var.sw]) == NULL)
    {
        printf("\n# radar rsl : sweep read error (%s,%d,%d)\n", var.fname, var.vol, var.sw);
        return -3;
    }
    printf(" : %2d %2d %4d %8.4f\n", var.vol, var.sw, sweep->h.nrays, sweep->h.elev);

    for (i = 0; i < sweep->h.nrays; i++)
    {
        if ((ray = sweep->ray[i]) != NULL)
        {
            printf("#   no  azimuth nbins  gate  bin1   width nyq_vel\n");
            printf(" %5d",   ray->h.ray_num);
            printf(" %8.4f", ray->h.azimuth);
            printf(" %5d",   ray->h.nbins);
            printf(" %5d",   ray->h.gate_size);
            printf(" %5d",   ray->h.range_bin1);
            printf(" %7.3f", ray->h.beam_width);
            printf(" %7.3f", ray->h.nyq_vel);
            printf("\n");
            printf("#--------------------------------------------------------------------------------------------------\n");

            for (j = 0; j < ray->h.nbins; j++)
            {
                ec = ray->h.f(ray->range[j]);
                if (ec > 131000) ec = -99;

                printf(" %7.3f", ec);
                if ((j+1)%10 == 0) printf("\n");
            }
            if (ray->h.nbins % 10 != 0) printf("\n");
        }
    }

    //
    // ���� �ݱ�
    //
    RSL_free_radar(radar);

    return 0;
}

/******************************************************************************
 *
 *  BINARY mode
 *
 ******************************************************************************/
int disp_bin()
{
    Radar  *radar;
    Volume *volume;
    Sweep  *sweep;
    Ray    *ray;
    short  header[32];
    char   fname[120];
    float  ec[2048];
    int    seq, YY, MM, DD, HH, MI, SS;
    int    first = 0;
    int    i, j, k;

    //
    // ���� ����
    //
    radar = RSL_uf_to_radar(var.fname);
    if (radar == NULL)
    {
//        printf("# radar rsl open error (%s)\n", var.fname);
        return -1;
    }

    //
    // �ڷ� �ð�
    //
    YY = radar->h.year;
    MM = radar->h.month;
    DD = radar->h.day;
    HH = radar->h.hour;
    MI = radar->h.minute;
    SS = (int)(radar->h.sec + 0.5);

    seq = time2seq(YY, MM, DD, HH, MI, 'm');
    seq2time(seq+9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

    //
    // Header
    //
    header[0] = 55;             // ���̴�-UF����-SWEEP
    header[1] = YY;             // �����ð�:��
    header[2] = MM*100 + DD;    // ��*100 + ��
    header[3] = HH*100 + MI;    // ��*100 + ��
    header[4] = SS*100;         // ��*100
    header[5] = 0;              // ����
    header[6] = 0;              // ������ȣ
    header[7] = radar->h.latd;                      // ���̴�����-����:��
    header[8] = radar->h.latm*100 + radar->h.lats;  // ��*100 + ��
    header[9] = radar->h.lond;                      // ���̴�����-�浵:��
    header[10]= radar->h.lonm*100 + radar->h.lons;  // ��*100 + ��
    header[11]= radar->h.height;                    // ���׳� �ع߰���(m)
    header[12]= 0;              // ����
    header[13]= 0;              // ����
    header[14]= 0;              // ����
    header[15]= 1;              // �ڿ� 32byte �߰�
    header[16]= var.vol;
    header[17]= var.sw;
    header[27]= 0;
    header[28]= 0;
    header[29]= 0;
    header[30]= 0;
    header[31]= 0;

    //
    // �ڷ� ó��
    //
    if ((volume = radar->v[var.vol]) == NULL)
    {
//        printf("\n# radar rsl : volume read error (%s,%d)\n", var.fname, var.vol);
        return -2;
    }

    if ((sweep = volume->sweep[var.sw]) == NULL)
    {
//        printf("\n# radar rsl : sweep read error (%s,%d,%d)\n", var.fname, var.vol, var.sw);
        return -3;
    }
    header[18]= sweep->h.nrays;
    header[19]= (int)(sweep->h.elev);
    header[20]= (sweep->h.elev - (int)(sweep->h.elev)) * 1000;

    for (i = 0; i < sweep->h.nrays; i++)
    {
        if ((ray = sweep->ray[i]) != NULL)
        {
            // Header ó��
            if (first == 0)
            {
                header[21]= ray->h.nbins;
                header[22]= ray->h.gate_size;
                header[23]= ray->h.range_bin1;
                header[24]= (ray->h.beam_width)*1000;
                header[25]= (int)(ray->h.nyq_vel);
                header[26]= (ray->h.nyq_vel - (int)(ray->h.nyq_vel)) * 1000;;
                first = 1;

                fwrite(header, sizeof(short), 32, stdout);
            }

            // �ڷ� �а� ����
            ec[0] = ray->h.azimuth;
            for (j = 0; j < ray->h.nbins; j++)
            {
                ec[j+1] = ray->h.f(ray->range[j]);
                if (ec[j+1] > 131000) ec[j+1] = -99;
            }
            fwrite(ec, sizeof(float), ray->h.nbins+1, stdout);
        }
    }

    //
    // ���� �ݱ�
    //
    RSL_free_radar(radar);

    return 0;
}

/*=============================================================================*
 *  ���̴� UF�ڷ� ���� ���� Ȯ��
 *=============================================================================*/
int rdr_uf_file()
{
  struct stat st;
  int    code;

  if (var.qcd == 5) {
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_HSR2_%04d%02d%02d%02d%02d.uf",
        RDR_UF_HSR_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
    code = stat(var.fname, &st);
    if (code < 0) {
      sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_HSR1_%04d%02d%02d%02d%02d.uf",
          RDR_UF_HSR_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
      code = stat(var.fname, &st);
    }
    if (code < 0) return -1;
    var.size = st.st_size;
    if (st.st_size <= 100) return -1;
  }
  else {
    if (var.qcd == 1)
        sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_QCD_%04d%02d%02d%02d%02d.uf",
                RDR_UF_QCD_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
    else if (var.qcd == 2)
        sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_FQC_%04d%02d%02d%02d%02d.uf",
                RDR_UF_QCD_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
    else if (var.qcd == 3)
        sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_NQS_%04d%02d%02d%02d%02d.uf",
                RDR_UF_RAW_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
    else if (var.qcd == 6)
      sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_LNG_%04d%02d%02d%02d%02d.uf",
          RDR_UF_LNG_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
    else if (var.qcd == 7)
      sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_LNG_FQC_%04d%02d%02d%02d%02d.uf",
          RDR_UF_LNG_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
    else if (var.qcd == 99)
      sprintf(var.fname, "/rdr/REF/HSR/RDR_%s_REAL_TIME_BK.uf", var.stn_cd);
    else
        sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_%04d%02d%02d%02d%02d.uf",
                RDR_UF_RAW_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
    code = stat(var.fname, &st);
    var.size = st.st_size;
    if (code < 0 || st.st_size <= 100) return -1;
  }
  return 0;
}
