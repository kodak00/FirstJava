/*******************************************************************************
**
**  HR ���̴� �ռ������� ���� ��� 3���� �����м��� ���� �����ڷ� ����
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.9.16)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>

#include "cgiutil.h"
#include "nrutil.h"
#include "stn_inf.h"
#include "aws3_data.h"
#include "map_ini.h"
#include "url_io.h"

#define  DEGRAD   3.1415927/180.0
#define  RADDEG   180.0/3.1415927
#define  MAX_DATA  10000
#define  MAP_INI_FILE  "/rdr/REF/MAP/map.ini" // �������� ��������

// �ֺ��� �����ڷᰡ �־ ��ġ���� ������� �ʴ� ����
#define  VDPS_PNT_RANGE  50     // �� �ݰ�(km)�̳�
#define  VDPS_PNT_HT     500    // �� �Ʒ��� ����(m) �̳�

//------------------------------------------------------------------------------
// ����� �Է� ����
struct INPUT_VAR {
  int   seq_now;      // ����ð� SEQ(��)
  int   seq;          // ���ؽð� or ����ð� SEQ(��)
  char  obs[8];       // ta(���), pa(���), td(�̽���), ws(ǳ��)
  char  map[8];       // ����� �����ڵ�
  float grid;         // ����ũ��(km)
  int   mode;         // 9(������ ���� ǥ��)
  char  disp;         // C(csv), A(ASCII)

  // ����� �ڷ�
  int   num_data;     // �� �ڷ��
  int   NX, NY;       // ���ڼ�, ���� ���������� ������ 1�� ���ϸ� ��
  int   SX, SY;       // ���� ������ ��ġ
} var;

// ���� �ڷ�
struct STN_VAL {
  int   seq;          // �����ð�
  int   stn_id;       // ������ȣ
  char  stn_ko[24];   // ������(�ѱ�)
  char  stn_sp[8];    // �����漺
  float x, y;         // ��ġ(���ڰŸ�)
  float ht;           // �ع߰���(m)
  float d;            // ��
  float v;            // ��(�ٶ����ͽ� Vǳ�� ���)
} stn_data[MAX_DATA];

// �ڷ� ���
#define NUM_SP_LIST  13
struct STN_SP_LIST {
  char stn_sp[8];     // ����Ư��
  char sp_name[20];   // Ư����
  int  sp_num;        // Ư���� �ڷ��
} sp_lst[NUM_SP_LIST] = {
  {"SS", "KMA:ASOS",   0},
  {"AM", "KMA:AMOS",   0},
  {"SA", "KMA:AWS",    0},
  {"SG", "KMA:��⵵", 0},
  {"SJ", "JMA:AMeDAS", 0},
  {"OY", "KMA:BUOY",   0},
  {"ST", "GTS:SYNOP",  0},
  {"OH", "GTS:SHIP",   0},
  {"AD", "AIR:AMDAR",  0},
  {"UR", "KMA:SONDER", 0},
  {"UK", "KMA:SONDE",  0},
  {"UT", "GTS:SONDE",  0},
  {"NM", "NWP:VDAPS",  0}
};

FILE *fp_log;
struct lamc_parameter map;

int upp_sonde_ext_get(int, int, float, float);

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main()
{
  // 1. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(40);

  printf("HTTP/1.0 200 OK\n");
  printf("Content-type: text/plain\n\n");

  // 2. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    printf("# ����� �Էº��� ����\n");
    return -1;
  }

  // 3. MAP parameter
  grid_map_inf(var.map, &(var.NX), &(var.NY), &(var.SX), &(var.SY));
  map.Re  = 6371.00877;
  map.grid  = 1.0;
  map.slat1 = 30.0;    map.slat2 = 60.0;
  map.olon  = 126.0;   map.olat  = 38.0;
  map.xo = (float)(var.SX)/map.grid;   map.yo = (float)(var.SY)/map.grid;
  map.first = 0;
  var.num_data = 0;

  // 4. �����ڷ� �б�
  aws_data_get();
  amedas_data_get();
  sea_data_get();
  gts_synop_data_get();

  // 5. �����ڷ� �б�
  amdar_data_get();
  gts_airep_data_get();
  upp_sonde_data_get();
  gts_temp_data_get();

  // 6. ��ġ�� �ڷ� �б�
  vdps_data_get();

  // 7. ��� ���
  rdr_r3d_obs_write();

  return 0;
}

/*******************************************************************************
 *  ����� ��û �м� �κ�
 *******************************************************************************/
int user_input()
{
  char *qs;
  char tmp[256], item[32], value[32], tm[30];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, i, j;

  // 1. ���� �ʱⰪ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "0");        // ����ð�
  strcpy(var.map, "HR");  // ���̴� ����
  var.mode = 0;
  var.disp = 'C';

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"obs")) strcpy(var.obs, value);
    else if ( !strcmp(item,"map")) strcpy(var.map, value);
    else if ( !strcmp(item,"tm"))  strcpy(tm, value);
    else if ( !strcmp(item,"mode")) var.mode = atoi(value);
    else if ( !strcmp(item,"disp")) var.disp = value[0];
  }

  // 3. �⺻�� ����
  var.grid = 1.0;   // 1km

  // 4. ����ð� �� ���� �����ð� ����
  get_time(&iYY, &iMM, &iDD, &iHH, &iMI, &iSS);
  iseq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  var.seq_now = iseq;

  // 5. ��û�ð� ����
  if (strlen(tm) < 10)
    var.seq = iseq;
  else {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
    var.seq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  }
  return 0;
}

/*******************************************************************************
 *  AWS �ڷ� �б�
 *******************************************************************************/
int aws_data_get()
{
  FILE     *fp;
  URL_FILE *fr; 
  struct AWS3_DATA aws[1];
  float  vv, ta, hm, es, e, td;
  int    seq, YY, MM, DD, HH, MI;
  int    code, qc, i, j, k;

  // 1. �������� �б�
  if (aws_info_get() < 0) return -1;

  // 2. ������ ������ �б�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  for (k = 0; k < var.num_data; k++) {
    // 2.1. �ڷ� �б�
    code = AWS3_DATA_READ(YY, MM, DD, HH, MI, stn_data[k].stn_id, aws, 'r');
    if (code != 0) continue;

    // 2.2. ������
    qc = 0;
    if (!strcmp(var.obs, "ta")) {
      vv = 0.1*(float)(aws[0].d[0]);
      if (vv >= -40 && vv < 50) qc = 1;
    }
    else if (!strcmp(var.obs, "td")) {
      hm = 0.1*(float)(aws[0].d[9]);
      ta = 0.1*(float)(aws[0].d[0]);
      if (hm > 4 && hm <= 100 && ta > -40 && ta < 50) {
        es = 6.112*exp((17.67*ta)/(ta+243.5));
        e = es*hm*0.01;
        vv = log(e/6.112)*243.5/(17.67-log(e/6.112));
        qc = 1;
      }
    }
    else if (!strcmp(var.obs, "pa")) {
      vv = 0.1*(float)(aws[0].d[6]);
      if (vv >= 600 && vv < 1200) qc = 1;
    }
    else if (!strcmp(var.obs, "ws")) {
      vv = 0.1*(float)(aws[0].d[66]);
      if (vv >= 0 && vv < 100) qc = 1;
    }

    if (qc)
      stn_data[k].d = vv;
    else
      stn_data[k].d = -999;
  }

  // 3. �ڷᰡ ���� ������ ��Ͽ��� ����.
  for (k = 0; k < var.num_data; k++) {
    if (stn_data[k].d < -900) {
      if (k < var.num_data-1) {
        for (i = k; i < var.num_data-1; i++)
          stn_data[i] = stn_data[i+1];
      }
      else {
        var.num_data--;
        break;
      }
      var.num_data--;
      k--;
    }
  }
  return 0;
}

/*=============================================================================*
 *  AWS �������� �б�
 *=============================================================================*/
int aws_info_get()
{
  URL_FILE *fr; 
  char   buf[1000], url[1000], tmp[500], stn_ko[32], stn_sp[16], gov_lst[1000], obs[8];
  float  lon, lat, xx, yy, ht;
  int    GX, GY, SX, SY;
  int    stn_id, seq;
  int    YY, MM, DD, HH, MI;
  int    i, j, k;

  // 1. �������� �б�� URL-API �ۼ�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  if (strcmp(var.obs,"td") == 0)
    strcpy(obs,"HM");
  else if (strcmp(var.obs,"pa") == 0)
    strcpy(obs,"PA");
  else
    strcpy(obs,"TA");
  sprintf(url, "http://172.20.134.147/url/stn_obs_inf.php?mode=3&gov=KMA:GFR&obs=%s&tm=%04d%02d%02d%02d%02d&disp=0",
          obs, YY, MM, DD, HH, MI);
  printf("# %s", url);
  if ((fr = url_fopen(url, "r")) == NULL) {
    printf(" (X)\n");
    return -1;
  }
  else {
    printf(" (O)\n");
  }

  // 2. �������� ����
  while (!url_feof(fr)) {
    url_fgets(buf, sizeof(buf), fr);
    if (buf[0] == '#') continue;

    // �ص�
    getword(tmp, buf, ',');  stn_id = atoi(tmp);  // ������ȣ
    getword(tmp, buf, ',');  strcpy(stn_ko, tmp);   // ������
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');  strcpy(stn_sp, tmp);   // �������
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');  lon = atof(tmp);   // �浵
    getword(tmp, buf, ',');  lat = atof(tmp);   // ����
    getword(tmp, buf, ',');
    if (strlen(tmp) <= 0)   // �ع߰��� ��
      ht = -999;
    else
      ht = atof(tmp);

    // NUM_AWS3 ���� ū ������ ����
    if (stn_id < 0 || stn_id >= NUM_AWS3) continue;

    // ���浵�� ���� ������ ����
    if (lon < 120 || lon > 135 || lat < 30 || lat > 45) continue;

    // ��ǥ��ȯ : �����ۿ� ���� ����
    lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);
    if (xx < 0 || xx > var.NX || yy < 0 || yy > var.NY) continue;

    // �������� ���ų�, �̻��� ���� ����
    if (ht < 0 || ht > 4000) continue;

    // ���� ����
    if (strcmp(stn_sp,"SZ") == 0) continue;   // �ӽ����� ����
    if (strcmp(stn_sp,"PA") == 0) continue;   // ��âAWS ����
    if (strcmp(stn_sp,"PB") == 0) continue;   // ��â���ռ��� ����
    if (strcmp(stn_sp,"SO") == 0) continue;   // ����� ����

    // ���������� ��Ī
    stn_data[var.num_data].seq = var.seq;
    stn_data[var.num_data].stn_id = stn_id;
    strcpy(stn_data[var.num_data].stn_ko, stn_ko);
    strcpy(stn_data[var.num_data].stn_sp, stn_sp);
    stn_data[var.num_data].x = xx;
    stn_data[var.num_data].y = yy;
    stn_data[var.num_data].ht = ht;
    stn_data[var.num_data].d = -999;
    var.num_data++;
  }
  url_fclose(fr);
  return 0;
}

/*******************************************************************************
 *  AMEDAS �ڷ� �б�
 *******************************************************************************/
int amedas_data_get()
{
  int  YY, MM, DD, HH, MI;
  int  i, j, k;

  // 1. �ð� Ȯ��
  seq2time((int)(var.seq/10)*10, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  // 2. �⵵�� �����Ͽ� �ڷ� ����
  if (YY < 2018) {
    amedas_info_get();
    amedas3_get();
  }
  else {
    amedas4_get();
  }
  return 0;
}

/*=============================================================================*
 *  �Ϻ� AMEDAS �������� �б� (2018�� �� �Ⱓ�� ���)
 *=============================================================================*/
int amedas_info_get()
{
  URL_FILE *fr; 
  struct lamc_parameter map;
  char   buf[1000], url[1000], tmp[500], name[32], stn_sp[16], gov_lst[1000], obs[8];
  float  lon, lat, xx, yy, ht, ht_wd, dd = (float)var.NX*0.1;
  int    stn_id, seq;
  int    YY, MM, DD, HH, MI;
  int    i, j, k;

  // 1. �������� �б�� URL-API �ۼ�
  seq2time((int)(var.seq/10)*10, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(url, "http://172.20.134.91/url/stn_amedas.php?tm=%04d%02d%02d%02d%02d&stn=0&raw=0&help=1", YY, MM, DD, HH, MI);
  printf("# %s", url);
  if ((fr = url_fopen(url, "r")) == NULL) {
    printf(" (X)\n");
    return -1;
  }
  else {
    printf(" (O)\n");
  }

  // 2. �������� ����
  while (!url_feof(fr)) {
    url_fgets(buf, sizeof(buf), fr);
    if (buf[0] == '#') continue;

    // �ص�
    sscanf(buf, "%d %f %f %s %f %f %s", &stn_id, &lon, &lat, stn_sp, &ht, &ht_wd, name);

    // ���浵�� ���� ������ ����
    if (lon < 100 || lon > 150 || lat < 0 || lat > 60) continue;

    // �������� ���ų�, �̻��� ���� ����
    if (ht < 0 || ht > 5000) continue;

    // ���������� ��Ī
    lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);
    if (xx >= -0.1*var.NX && xx <= 1.1*var.NX && yy >= -0.1*var.NY && yy <= 1.1*var.NY) {
      stn_data[var.num_data].stn_id = stn_id;
      strcpy(stn_data[var.num_data].stn_ko, name);
      strcpy(stn_data[var.num_data].stn_sp, "SJ");
      stn_data[var.num_data].x = xx;
      stn_data[var.num_data].y = yy;
      stn_data[var.num_data].ht = ht;
      stn_data[var.num_data].d = -999;
      var.num_data++;
    }
  }
  url_fclose(fr);
  return 0;
}

/*=============================================================================*
 *  AMEDAS �ڷ� �б� (2018�� ����)
 *=============================================================================*/
int amedas3_get()
{
  URL_FILE *fr; 
  char   buf[1000], url[500], tmp[500], v[30][50];
  float  vv, xx, yy, u1, v1;
  float  rn, ws, ta, pa, ps, vs, hm;
  float  lat, lon, ht;
  int    stn_id, wd, sd;
  int    YY, MM, DD, HH, MI;
  int    qc, code, rtn, now, i, j, k;

  // 1. URL-API ����
  seq2time((int)(var.seq/10)*10, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(url, "http://172.20.134.91/url/amedas.php?tm=%04d%02d%02d%02d00&stn=0&help=0", YY, MM, DD, HH);
  printf("# %s", url);
  if ((fr = url_fopen(url, "r")) == NULL) {
    printf(" (X)\n");
    return -1;
  }
  else {
    printf(" (O)\n");
  }

  // 2. ������ ������ �д´�.
  while (!url_feof(fr)) {
    url_fgets(buf, sizeof(buf), fr);
    if (buf[0] == '#') continue;

    qc = 0;
    sscanf(buf, "%s %d %f %d %f %f %d", tmp, &stn_id, &rn, &wd, &ws, &ta, &sd);
    if (!strcmp(var.obs,"rn_60m")) {
      vv = rn;
      if (vv >= 0) qc = 1;
    }
    else if (!strcmp(var.obs,"ws")) {
      vv = ws;
      if (vv >= 0) qc = 1;
    }
    else if (!strcmp(var.obs,"ta")) {
      vv = ta - 273;
      if (vv > -45 && vv < 50) qc = 1;
    }
    else if (!strcmp(var.obs, "wv_10m") || !strcmp(var.obs, "wv_10x")) {
      if (wd >= 0 && ws >= 0) {
        u1 = -ws * sin( DEGRAD * wd );
        v1 = -ws * cos( DEGRAD * wd );
        qc = 1;
      }
    }
    else if (!strcmp(var.obs, "wv_ins")) {
      if (wd >= 0 && ws >= 0) {
        u1 = -ws * sin( DEGRAD * wd );
        v1 = -ws * cos( DEGRAD * wd );
        qc = 1;
      }
    }
    else
      break;

    if (qc) {
      for (k = 0; k < var.num_data; k++) {
        if (stn_data[k].stn_id == stn_id) {
          if (!strncmp(var.obs,"wv_",3)) {
            stn_data[k].d = u1;
            stn_data[k].v = v1;
          }
          else {
            stn_data[k].d = vv;
          }
          stn_data[k].seq = (int)(var.seq/10)*10;
          break;
        }
      }
    }
  }
  url_fclose(fr);
  return 0;
}

/*=============================================================================*
 *  AMEDAS4 �ڷ� �б� (2018�� ����)
 *=============================================================================*/
int amedas4_get()
{
  FILE   *fp;
  URL_FILE *fr; 
  char   buf[1000], url[500], tmp[500], v[30][50];
  float  vv, xx, yy, u1, v1, dd = (float)var.NX*0.1;
  float  rn, wd, ws, ta, pa, ps, vs, hm, rn_day, wd_ins, ws_ins, es, e;
  float  lat, lon, ht, ht_pa, ht_ta, ht_wd, ht_rn;
  int    stn_id, wc;
  int    YY, MM, DD, HH, MI;
  int    qc, code, rtn, now, i, j, k;

  // 1. URL-API ����
  seq2time((int)(var.seq/10)*10, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(url, "http://172.20.134.91/url/amedas4.php?tm=%04d%02d%02d%02d00&stn=0&help=0", YY, MM, DD, HH);
  printf("# %s", url);
  if ((fr = url_fopen(url, "r")) == NULL) {
    printf(" (X)\n");
    return -1;
  }
  else {
    printf(" (O)\n");
  }

  // 2. ������ ������ �д´�.
  while (!url_feof(fr)) {
    url_fgets(buf, sizeof(buf), fr);
    if (buf[0] == '#') continue;

    qc = 0;
    sscanf(buf, "%s %d %f %f %f %f %d %f %f %f %f %f %f %f %f %f %f %f %f %f %f",
                tmp, &stn_id, &rn, &wd, &ws, &ta, &wc, &pa, &ps, &vs, &hm, &rn_day, &wd_ins, &ws_ins,
                &lat, &lon, &ht, &ht_pa, &ht_ta, &ht_wd, &ht_rn);

    if (!strcmp(var.obs,"rn_60m")) {
      vv = rn;
      if (vv >= 0) qc = 1;
    }
    else if (!strcmp(var.obs,"ws")) {
      vv = ws;
      if (vv >= 0) qc = 1;
    }
    else if (!strcmp(var.obs,"ta")) {
      vv = ta - 273;
      if (vv >= -50 && vv < 50) qc = 1;
    }
    else if (!strcmp(var.obs,"td")) {
      ta -= 273;
      if (hm > 4 && hm <= 100 && ta > -40 && ta < 45) {
        es = 6.112*exp((17.67*ta)/(ta+243.5));
        e = es*hm*0.01;
        vv = log(e/6.112)*243.5/(17.67-log(e/6.112));
        qc = 1;
      }
    }
    else if (!strcmp(var.obs,"pa")) {
      vv = pa;
      if (vv > 600 && vv < 1200) qc = 1;
    }
    else if (!strcmp(var.obs,"ps1") || !strcmp(var.obs,"ps2") || !strcmp(var.obs,"ps3")) {
      vv = ps;
      if (vv > 600 && vv < 1200) qc = 1;
    }
    else if (!strcmp(var.obs,"rn_day")) {
      vv = rn_day;
      if (vv >= 0) qc = 1;
    }
    else if (!strcmp(var.obs,"ws_ins")) {
      vv = ws_ins;
      if (vv >= 0) qc = 1;
    }
    else if (!strcmp(var.obs, "wv_10m") || !strcmp(var.obs, "wv_10x")) {
      if (wd >= 0 && ws >= 0) {
        u1 = -ws * sin( DEGRAD * wd );
        v1 = -ws * cos( DEGRAD * wd );
        qc = 1;
      }
    }
    else if (!strcmp(var.obs, "wv_ins")) {
      if (wd >= 0 && ws >= 0) {
        u1 = -ws * sin( DEGRAD * wd );
        v1 = -ws * cos( DEGRAD * wd );
        qc = 1;
      }
    }
    else
      break;

    if (qc) {
      lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);
      if (xx >= -dd && xx <= var.NX+dd && yy >= -dd && yy <= var.NY+dd) {
        stn_data[var.num_data].seq = (int)(var.seq/10)*10;
        stn_data[var.num_data].stn_id = stn_id;
        strcpy(stn_data[var.num_data].stn_ko, "AMEDAS");
        strcpy(stn_data[var.num_data].stn_sp, "SJ");
        stn_data[var.num_data].x = xx;
        stn_data[var.num_data].y = yy;
        stn_data[var.num_data].ht = ht;
        if (!strncmp(var.obs,"wv_",3)) {
          stn_data[var.num_data].d = u1;
          stn_data[var.num_data].v = v1;
        }
        else {
          stn_data[var.num_data].d = vv;
        }
        var.num_data++;
      }
    }
  }
  url_fclose(fr);
  return 0;
}

/*******************************************************************************
 *  �ؾ�����ڷ� �б�
 *******************************************************************************/
int sea_data_get()
{
  URL_FILE *fr;
  float vv, xx, yy, ht, lon, lat, ta, pa, ps, ws, hm, es, e, td;
  float *sea_data, data1, data2, data3, dd;
  char  url[120], buf[200], tmp[32], tm[32], name[40], sea_type;
  int   seq1a, seq1b, seq3, id;
  int   YY, MM, DD, HH, MI;
  int   num_sea = 0, qc, ok;
  int   i, j, k;

  // 1. �ð� ����
  seq1a = var.seq - 60;  seq1b = var.seq + 1;

  // 2. URL
  strcpy(url, "http://172.20.134.91/url/sea_obs3.php?");

  seq2time(seq1a, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(tmp, "&tm1=%04d%02d%02d%02d%02d", YY, MM, DD, HH, MI);
  strcat(url, tmp);

  seq2time(seq1b, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(tmp, "&tm2=%04d%02d%02d%02d%02d", YY, MM, DD, HH, MI);
  strcat(url, tmp);
  strcat(url, "&stn=0&help=0&disp=0");
  printf("# %s", url);
  if ((fr = url_fopen(url, "r")) == NULL) {
    printf(" (X)\n");
    return -1;
  }
  else {
    printf(" (O)\n");
  }

  // 3. �б�
  while (!url_feof(fr)) {
    url_fgets(buf, sizeof(buf), fr);
    if (buf[0] == '#') continue;

    // 3.1. �ص�
    getword(tmp, buf, ',');   sea_type = tmp[0];
    if (sea_type == 'C') continue;    // �İ����� ���� (��� ���� ����)
    if (sea_type == 'L') continue;    // ��ǥ ���� (AWS�� ����)
    if (sea_type == 'N') continue;    // ���������� ����

    getword(tmp, buf, ',');
    strncpy(tm, &tmp[0], 4);  tm[4]='\0';  YY = atoi(tm);
    strncpy(tm, &tmp[4], 2);  tm[2]='\0';  MM = atoi(tm);
    strncpy(tm, &tmp[6], 2);  tm[2]='\0';  DD = atoi(tm);
    strncpy(tm, &tmp[8], 2);  tm[2]='\0';  HH = atoi(tm);
    strncpy(tm, &tmp[10],2);  tm[2]='\0';  MI = atoi(tm);
    seq3 = time2seq(YY, MM, DD, HH, MI, 'm');

    getword(tmp, buf, ',');  id = atoi(tmp);
    getword(tmp, buf, ',');  sprintf(name,"KMA:%s", tmp);

    getword(tmp, buf, ',');  lon = atof(tmp);   // �浵
    getword(tmp, buf, ',');  lat = atof(tmp);   // ����

    // 3.2. ���浵�� ���� ������ ����
    if (lon < 120 || lon > 135 || lat < 30 || lat > 45) continue;

    // 3.3. ��ǥ��ȯ : �����ۿ� ���� ����
    lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);
    if (xx < -0.1*var.NX || xx > 1.1*var.NX || yy < -0.1*var.NY || yy > 1.1*var.NY) continue;

    // 3.4. ���� �а�, ����QC ó��
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');  ws = atof(tmp);
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');  ta = atof(tmp);
    getword(tmp, buf, ',');  pa = atof(tmp);
    getword(tmp, buf, ',');  hm = atof(tmp);

    qc = 0;
    if (!strcmp(var.obs,"ta")) {
      if (ta >= -40 && ta < 50) {
        vv = ta;
        qc = 1;
      }
    }
    else if (!strcmp(var.obs,"pa")) {
      if (pa > 600 && pa < 1200) {
        vv = pa;
        qc = 1;
      }
    }
    else if (!strcmp(var.obs,"td")) {
      if (hm > 4 && hm <= 100 && ta > -40 && ta < 50) {
        es = 6.112*exp((17.67*ta)/(ta+243.5));
        e = es*hm*0.01;
        vv = log(e/6.112)*243.5/(17.67-log(e/6.112));
        qc = 1;
      }
    }
    else if (!strcmp(var.obs,"ws")) {
      if (ws >= 0 && ws < 100) {
        vv = ws;
        qc = 1;
      }
    }
    if (qc == 0) continue;

    // 3.4. ���� ������ ������, ��û�ð��� ����� ���� ����Ѵ�.
    for (ok = 0, k = 0; k < var.num_data; k++) {
      if (stn_data[k].stn_id == id) {
        if (abs(var.seq - seq3) >= abs(stn_data[k].seq - seq3)) {
          ok = 1;
          break;
        }
      }
    }
    if (ok) continue;   // ������ ����� ���� �� ����� �� ��ü���� �ʴ´�.

    // 3.5. ���������� ��Ī
    stn_data[var.num_data].seq = seq3;
    stn_data[var.num_data].stn_id = id;
    strcpy(stn_data[var.num_data].stn_ko, name);
    strcpy(stn_data[var.num_data].stn_sp, "OY");
    stn_data[var.num_data].x = xx;
    stn_data[var.num_data].y = yy;
    stn_data[var.num_data].ht = 2.0;  // ���̰����� 2m�� ����
    stn_data[var.num_data].d = vv;
    var.num_data++;
    num_sea++;
  }
  url_fclose(fr);

  // 4. QC (�߰������� ���̰� 3Q-1Q ���� 2.5�躸�� ũ�� ����ó��)
  if (num_sea <= 3) return 0;

  sea_data = vector(0, num_sea);
  for (i = 0, k = var.num_data-num_sea; k < var.num_data; k++, i++) {
    sea_data[i] = stn_data[k].d;
  }

  for (i = 0; i < num_sea-1; i++) {
    for (j = i+1; j < num_sea; j++) {
      if (sea_data[i] > sea_data[j]) {
        vv = sea_data[i];
        sea_data[i] = sea_data[j];
        sea_data[j] = vv;
      }
    }
  }
  data2 = sea_data[num_sea/2];
  data1 = sea_data[num_sea/4];
  data3 = sea_data[3*num_sea/4];
  dd = fabs(data3-data1)*2.5;

  for (k = var.num_data-num_sea; k < var.num_data; k++) {
    if (fabs(stn_data[k].d-data2) >= dd)
      stn_data[k].d = -999;
  }
  free_vector(sea_data, 0, num_sea);
  return 0;
}

/*******************************************************************************
 *  GTS SYNOP �����ڷ� �б�
 *******************************************************************************/
int gts_synop_data_get()
{
  URL_FILE *fr;
  char  url[120], buf[200], tmp[32], tm[32], stn_cd[20], stn_sp[8], name[40], tp;
  float vv, xx, yy, ht, lon, lat, rn, pa, ps, pr, ta, td, hm, ws, es, e;
  int   vs, wc, wp, ca, cd, ch, cl, cm, ct, wd, rh;
  int   stn_id, stn_id2, seq3, pt, ox, qc;
  int   YY, MM, DD, HH, MI;
  int   i, j, k;

  // 1. URL ����
  seq2time(var.seq-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(url, "http://172.20.134.91/url/gts_cht_syn3.php?&tm=%04d%02d%02d%02d00&lon1=115&lon2=135&lat1=25&lat2=45&help=0",
          YY, MM, DD, HH);
  printf("# %s", url);
  if ((fr = url_fopen(url, "r")) == NULL) {
    printf(" (X)\n");
    return -1;
  }
  else {
    printf(" (O)\n");
  }

  // 2. �ڷ� ó��
  while (!url_feof(fr)) {
    url_fgets(buf, sizeof(buf), fr);
    if (buf[0] == '#') continue;

    // �б�
    sscanf(buf, "%c %s %s %f %f %f %f %d %f %f %f %f %d %d %d %d %d %d %d %d %d %d %f %d %f %f",
                &tp, tm, &stn_cd, &lon, &lat, &ht, &ps, &pt, &pr, &ta, &td, &hm,
                &vs, &wc, &wp, &ca, &cd, &ch, &cl, &cm, &ct, &wd, &ws, &rh, &rn, &pa);

    // ������ȣ�� �̸� Ȯ��
    if (tp == 'S' || tp == 'B')
      stn_id = atoi(stn_cd);
    else
      stn_id = 30000;
    strcpy(name, "GTS:");
    strcat(name, stn_cd);

    // �������� ������ ������� ����
    if (ht <= 0) continue;

    // �ѱ��� AWS�� ���ԵǴ� ���� ����
    if (tp == 'S' && stn_id >= 47090 && stn_id < 47300) continue;

    // ����QC
    qc = 0;
    if (!strcmp(var.obs,"ta")) {
      if (ta >= -40 && ta < 50) {
        vv = ta;
        qc = 1;
      }
    }
    else if (!strcmp(var.obs,"pa")) {
      if (pa > 600 && pa < 1200) {
        vv = pa;
        qc = 1;
      }
    }
    else if (!strcmp(var.obs,"td")) {
      if (hm > 4 && hm <= 100 && ta > -40 && ta < 50) {
        es = 6.112*exp((17.67*ta)/(ta+243.5));
        e = es*hm*0.01;
        vv = log(e/6.112)*243.5/(17.67-log(e/6.112));
        qc = 1;
      }
    }
    else if (!strcmp(var.obs,"ws")) {
      if (ws >= 0 && ws < 100) {
        vv = ws;
        qc = 1;
      }
    }
    if (qc == 0) continue;

    // �ѱ�BUOY�� �̹� ������ ����
    ox = 0;
    if (tp == 'B') {
      for (k = 0; k < var.num_data; k++) {
        stn_id2 = (int)(stn_data[k].stn_id/1000)*100000 + stn_data[k].stn_id%1000;
        if (stn_id == stn_data[k].stn_id || stn_id == stn_id2) {
          ox = 1;
          break;
        }
      }
    }
    if (ox) continue;

    // �ð�Ȯ��
    strncpy(tmp, &tm[0], 4);  tmp[4]='\0';  YY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2]='\0';  MM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2]='\0';  DD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2]='\0';  HH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2]='\0';  MI = atoi(tmp);
    seq3 = time2seq(YY, MM, DD, HH, MI, 'm') + 9*60;

    // ���� Ư�� �з�
    if      (tp == 'S') strcpy(stn_sp, "ST");   // ����ASOS
    else if (tp == 'H') strcpy(stn_sp, "OH");   // SHIP����
    else if (tp == 'B') strcpy(stn_sp, "OT");   // BUOY����

    // ��ǥ��ȯ : �����ۿ� ���� ����
    lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);
    if (xx < -0.1*var.NX || xx > 1.1*var.NX || yy < -0.1*var.NY || yy > 1.1*var.NY) continue;

    // ���������� ��Ī
    stn_data[var.num_data].seq = seq3;
    stn_data[var.num_data].stn_id = stn_id;
    strcpy(stn_data[var.num_data].stn_ko, name);
    strcpy(stn_data[var.num_data].stn_sp, stn_sp);
    stn_data[var.num_data].x = xx;
    stn_data[var.num_data].y = yy;
    stn_data[var.num_data].ht = ht;
    stn_data[var.num_data].d = vv;
    var.num_data++;
  }
  url_fclose(fr);
  return 0;
}

/*******************************************************************************
 *  AMDAR �����ڷ� �б�
 *******************************************************************************/
int amdar_data_get()
{
  URL_FILE *fr;
  float vv, xx, yy, ht, lon, lat, ta, wd, ws;
  char  url[120], buf[200], tmp[32], tm[32];
  int   seq1a, seq1b, seq2a, seq2b, seq3, qc;
  int   YY, MM, DD, HH, MI;

  // 1. �ð� ����
  seq1a = var.seq - 30;  seq1b = var.seq + 30;
  seq2a = var.seq - 60;  seq2b = var.seq + 60;

  // 2. URL
  strcpy(url, "http://172.20.134.91/url/amdar_kma.php?");

  seq2time(seq2a, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(tmp, "&tm1=%04d%02d%02d%02d%02d", YY, MM, DD, HH, MI);
  strcat(url, tmp);

  seq2time(seq2b, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(tmp, "&tm2=%04d%02d%02d%02d%02d", YY, MM, DD, HH, MI);
  strcat(url, tmp);
  strcat(url, "&help=0");
  printf("# %s", url);
  if ((fr = url_fopen(url, "r")) == NULL) {
    printf(" (X)\n");
    return -1;
  }
  else {
    printf(" (O)\n");
  }

  // 3. �б�
  while (!url_feof(fr)) {
    url_fgets(buf, sizeof(buf), fr);
    if (buf[0] == '#') continue;

    // �ص�
    getword(tmp, buf, ',');
    strncpy(tm, &tmp[0], 4);  tm[4]='\0';  YY = atoi(tm);
    strncpy(tm, &tmp[4], 2);  tm[2]='\0';  MM = atoi(tm);
    strncpy(tm, &tmp[6], 2);  tm[2]='\0';  DD = atoi(tm);
    strncpy(tm, &tmp[8], 2);  tm[2]='\0';  HH = atoi(tm);
    strncpy(tm, &tmp[10],2);  tm[2]='\0';  MI = atoi(tm);
    seq3 = time2seq(YY, MM, DD, HH, MI, 'm');
    if (seq3 < seq2a || seq3 > seq2b) continue;   // +-1 �ð� �̳��� ���

    getword(tmp, buf, ',');  lon = atof(tmp);   // �浵
    getword(tmp, buf, ',');  lat = atof(tmp);   // ����

    // ��ǥ��ȯ : �����ۿ� ���� ����
    lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);
    if (xx < -0.1*var.NX || xx > 1.1*var.NX || yy < -0.1*var.NY || yy > 1.1*var.NY) continue;

    getword(tmp, buf, ',');  ht = atof(tmp);    // ����(m)
    if (ht <= 0 || ht > 12000) continue;  // 12km �̳��� ���, ���� 0�� �ǽɽ�����
    if (ht <= 3000 && (seq3 < seq1a || seq3 > seq1b)) continue;   // 3km ���ϴ� +-30�и� ���

    getword(tmp, buf, ',');  ta = atof(tmp);
    getword(tmp, buf, ',');  wd = (float)(atoi(tmp));
    getword(tmp, buf, ',');  ws = (float)(atoi(tmp));

    // ����QC
    qc = 0;
    if (!strcmp(var.obs,"ta")) {
      if (ta >= -40 && ta < 50) {
        vv = ta;
        qc = 1;
      }
    }
    else if (!strcmp(var.obs,"ws")) {
      if (ws >= 0 && ws < 200) {
        vv = ws*0.5;    // knot -> m/s
        qc = 1;
      }
    }
    if (qc == 0) continue;

    // ���������� ��Ī
    stn_data[var.num_data].seq = seq3;
    stn_data[var.num_data].stn_id = 10000;
    strcpy(stn_data[var.num_data].stn_ko, "AMDAR");
    strcpy(stn_data[var.num_data].stn_sp, "AD");
    stn_data[var.num_data].x = xx;
    stn_data[var.num_data].y = yy;
    stn_data[var.num_data].ht = ht;
    stn_data[var.num_data].d = vv;
    var.num_data++;
  }
  url_fclose(fr);
  return 0;
}

/*******************************************************************************
 *  GTS AIREP �����ڷ� �б�
 *******************************************************************************/
int gts_airep_data_get()
{
  URL_FILE *fr;
  float vv, xx, yy, ht, lon, lat, ta, wd, ws;
  char  url[120], buf[1000], tmp[200], stn[20], tm[32];
  int   seq2a, seq2b, seq3, dseq, qc, ox;
  int   YY, MM, DD, HH, MI;

  // 1. �ð� ����
  seq2a = var.seq - 13*60;  seq2b = var.seq + 10*60;
  seq2time(seq2b-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  // 2. URL
  sprintf(url, "http://172.20.134.91/url/gts_airep1.php?tm=%04d%02d%02d%02d%02d&dtm=%d&stn=0&lon1=115&lon2=135&lat1=25&lat2=45&help=0",
          YY, MM, DD, HH, MI, seq2b-seq2a);
  printf("# %s", url);
  if ((fr = url_fopen(url, "r")) == NULL) {
    printf(" (X)\n");
    return -1;
  }
  else {
    printf(" (O)\n");
  }

  // 3. �б�
  while (!url_feof(fr)) {
    url_fgets(buf, sizeof(buf), fr);
    if (buf[0] == '#') continue;

    // �ص�
    sscanf(buf, "%s %s %f %f %f %f %f %f", tmp, stn, &lon, &lat, &ht, &ta, &wd, &ws);
    if (ht <= 0 || ht > 12000) continue;  // 12km �̳��� ���, ���� 0�� �ǽɽ�����

    // ����QC
    qc = 0;
    if (!strcmp(var.obs,"ta")) {
      if (ta >= -40 && ta < 50) {
        vv = ta;
        qc = 1;
      }
    }
    else if (!strcmp(var.obs,"ws")) {
      if (ws >= 0 && ws < 200) {
        vv = ws*0.5;    // knot -> m/s
        qc = 1;
      }
    }
    if (qc == 0) continue;

    strncpy(tm, &tmp[0], 4);  tm[4]='\0';  YY = atoi(tm);
    strncpy(tm, &tmp[4], 2);  tm[2]='\0';  MM = atoi(tm);
    strncpy(tm, &tmp[6], 2);  tm[2]='\0';  DD = atoi(tm);
    strncpy(tm, &tmp[8], 2);  tm[2]='\0';  HH = atoi(tm);
    strncpy(tm, &tmp[10],2);  tm[2]='\0';  MI = atoi(tm);
    seq3 = time2seq(YY, MM, DD, HH, MI, 'm') + 9*60;    // UTC -> KST

    // �����ϼ��� ����� �ð��븦 ����Ѵ�.
    dseq = abs(var.seq - seq3);
    ox = 0;
    if (ht < 3000) {
      if (dseq > 3*60) ox = 1;
    }
    else if (ht < 6000) {
      if (dseq > 6*60) ox = 1;
    }
    else {
      if (dseq > 12*60) ox = 1;
    }
    if (ox) continue;

    // ��ǥ��ȯ : �����ۿ� ���� ����
    lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);
    if (xx < 0 || xx > var.NX || yy < 0 || yy > var.NY) continue;

    // ���������� ��Ī
    stn_data[var.num_data].seq = seq3;
    stn_data[var.num_data].stn_id = 80000;
    strcpy(stn_data[var.num_data].stn_ko, "GTS:AIREP");
    strcpy(stn_data[var.num_data].stn_sp, "AR");
    stn_data[var.num_data].x = xx;
    stn_data[var.num_data].y = yy;
    stn_data[var.num_data].ht = ht;
    stn_data[var.num_data].d = vv;
    var.num_data++;
  }
  url_fclose(fr);
  return 0;
}

/*******************************************************************************
 *  ���� �����ڷ� �б�
 *******************************************************************************/
#define  UPP_SND_RAW  "/DATA/UPP/SND/RAW/"
#define  UPP_SND_JUN  "/DATA/UPP/SND/JUN/"

struct UPP_SONDE_STN {
  int   stn_id;
  int   seq;
  char  raw;
  float x;
  float y;
} upp_stn[30];

int upp_sonde_data_get()
{
  URL_FILE *fr;
  float xx, yy, ht, lon, lat, ta;
  char  url[120], buf[200], tmp[32], tm[32];
  int   num_upp = 0;
  int   seq1a, seq1b, seq2a, seq2b, seq3;
  int   YY, MM, DD, HH, MI;
  int   k;

  // 1. ������ �������� ���� ����� �����.
  upp_sonde_raw_list(&num_upp);
  upp_sonde_jun_list(&num_upp);

  // 2. ������ ���, ���浵�� Ȯ�δ�.
  upp_sonde_jun_lonlat(num_upp);

  // 3. ������Ϻ��� �ڷḦ �д´�.
  for (k = 0; k < num_upp; k++) {
    if (upp_stn[k].raw == 'R')
      upp_sonde_raw_get(upp_stn[k].stn_id, upp_stn[k].seq);
    else
      upp_sonde_ext_get(upp_stn[k].stn_id, upp_stn[k].seq, upp_stn[k].x, upp_stn[k].y);
  }
  return 0;
}

/*=============================================================================*
 *  ���� ���� �����ڷ� �߿��� ��û�ð��� ���� ����� ���ϵ��� ã�´�
 *=============================================================================*/
int upp_sonde_raw_list(int *num_upp)
{
  DIR    *dp;
  struct dirent   *dirp;
  char   dir1[120], fname[120], *p, tmp[32], tm[32];
  int    seq_day, seq1_day, seq2_day;
  int    stn_id, seq3;
  int    num_stn = *num_upp, ok;
  int    YY, MM, DD, HH, MI;
  int    k;

  // 1. ������ �����Ѵ�.
  seq2time(var.seq-12*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  seq1_day = time2seq(YY, MM, DD, HH, MI, 'd');
  seq2time(var.seq+12*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  seq2_day = time2seq(YY, MM, DD, HH, MI, 'd');

  // 2. �Ϻ��� ����� ������ �����Ѵ�.
  for (seq_day = seq1_day; seq_day <= seq2_day; seq_day++) {
    // 2.1. ���丮�� Ȯ���Ѵ�.
    seq2time(seq_day, &YY, &MM, &DD, &HH, &MI, 'd', 'n');
    sprintf(dir1, "%s%04d%02d/%02d/", UPP_SND_RAW, YY, MM, DD);
    if ( (dp = opendir(dir1)) == NULL) continue;

    // 2.2. ���丮�� ���ϸ��� Ȯ���Ѵ�.
    while ((dirp = readdir(dp)) != NULL) {
      // 2.2.1. ����ASCII������ �����Ѵ�.
      strcpy(fname, dirp->d_name);
      if (strlen(fname) < 10) continue;

      // 2.2.2. ���ϸ����� ������ �����Ѵ�.
      getword (tmp, fname, '_');
      getword (tmp, fname, '_');
      getword (tmp, fname, '_');  stn_id = atoi(tmp);
      getword (tmp, fname, '_');
      strncpy(tm, &tmp[0], 4);  tm[4]='\0';  YY = atoi(tm);
      strncpy(tm, &tmp[4], 2);  tm[2]='\0';  MM = atoi(tm);
      strncpy(tm, &tmp[6], 2);  tm[2]='\0';  DD = atoi(tm);
      strncpy(tm, &tmp[8], 2);  tm[2]='\0';  HH = atoi(tm);
      strncpy(tm, &tmp[10],2);  tm[2]='\0';  MI = atoi(tm);
      seq3 = time2seq(YY, MM, DD, HH, MI, 'm', 'n') + 9*60; // UTC -> KST

      // 2.2.3. ������Ͽ� �߰��Ѵ�.
      if (num_stn == 0) {
        upp_stn[num_stn].stn_id = stn_id;
        upp_stn[num_stn].seq = seq3;
        upp_stn[num_stn].raw = 'R';
        num_stn++;
      }
      else {
        for (ok = 0, k = 0; k < num_stn; k++) {
          if (upp_stn[k].stn_id == stn_id) {
            ok = 1;
            if (abs(upp_stn[k].seq - seq3) > abs(var.seq - seq3)) {
              upp_stn[k].seq = seq3;
            }
          }
        }
        if (ok == 0) {
          upp_stn[num_stn].stn_id = stn_id;
          upp_stn[num_stn].seq = seq3;
          upp_stn[num_stn].raw = 'R';
          num_stn++;
        }
      }
    }
    if (seq1_day == seq2_day) break;
  }
  *num_upp = num_stn;
  return 0;
}

/*=============================================================================*
 *  ���� ���� �����ڷ� �߿��� ��û�ð��� ���� ����� ���ϵ��� ã�´�
 *=============================================================================*/
int upp_sonde_jun_list(int *num_upp)
{
  DIR    *dp;
  struct dirent   *dirp;
  char   dir1[120], fname[120], *p, tmp[32], tm[32];
  int    seq_day, seq1_day, seq2_day;
  int    stn_id, seq3;
  int    num_stn = *num_upp, ok;
  int    YY, MM, DD, HH, MI;
  int    k;

  // 1. ������ �����Ѵ�.
  seq2time(var.seq-12*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  seq1_day = time2seq(YY, MM, DD, HH, MI, 'd');
  seq2time(var.seq+12*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  seq2_day = time2seq(YY, MM, DD, HH, MI, 'd');

  // 2. �Ϻ��� ����� ������ �����Ѵ�.
  for (seq_day = seq1_day; seq_day <= seq2_day; seq_day++) {
    // 2.1. ���丮�� Ȯ���Ѵ�.
    seq2time(seq_day, &YY, &MM, &DD, &HH, &MI, 'd', 'n');
    sprintf(dir1, "%s%04d%02d/%02d/", UPP_SND_JUN, YY, MM, DD);
    if ( (dp = opendir(dir1)) == NULL) continue;

    // 2.2. ���丮�� ���ϸ��� Ȯ���Ѵ�.
    while ((dirp = readdir(dp)) != NULL) {
      // 2.2.1. �����ص������� �����Ѵ�.
      strcpy(fname, dirp->d_name);
      if (strlen(fname) < 10) continue;
      if (strstr(fname,"UTKO60_") == NULL) continue;

      // 2.2.2. ���ϸ����� ������ �����Ѵ�.
      getword (tmp, fname, '_');
      getword (tmp, fname, '_');
      strncpy(tm, &tmp[0], 4);  tm[4]='\0';  YY = atoi(tm);
      strncpy(tm, &tmp[4], 2);  tm[2]='\0';  MM = atoi(tm);
      strncpy(tm, &tmp[6], 2);  tm[2]='\0';  DD = atoi(tm);
      strncpy(tm, &tmp[8], 2);  tm[2]='\0';  HH = atoi(tm);
      strncpy(tm, &tmp[10],2);  tm[2]='\0';  MI = atoi(tm);
      seq3 = time2seq(YY, MM, DD, HH, MI, 'm', 'n') + 9*60; // UTC -> KST
      getword (tmp, fname, '_');  stn_id = atoi(tmp);

      // 2.2.3. �����ڷᰡ �ִ� ������ �����Ѵ�.
      for (ok = 0, k = 0; k < *num_upp; k++) {
        if (upp_stn[k].stn_id == stn_id) {
          ok = 1;
          break;
        }
      }
      if (ok) continue;

      // 2.2.4. ������Ͽ� �߰��Ѵ�.
      if (num_stn == 0) {
        upp_stn[num_stn].stn_id = stn_id;
        upp_stn[num_stn].seq = seq3;
        upp_stn[num_stn].raw = 'J';
        num_stn++;
      }
      else {
        for (ok = 0, k = 0; k < num_stn; k++) {
          if (upp_stn[k].stn_id == stn_id) {
            ok = 1;
            if (abs(upp_stn[k].seq - seq3) > abs(var.seq - seq3)) {
              upp_stn[k].seq = seq3;
            }
          }
        }
        if (ok == 0) {
          upp_stn[num_stn].stn_id = stn_id;
          upp_stn[num_stn].seq = seq3;
          upp_stn[num_stn].raw = 'J';
          num_stn++;
        }
      }
    }
    if (seq1_day == seq2_day) break;
  }
  *num_upp = num_stn;
  return 0;
}

/*=============================================================================*
 *  ���� ���� �����ڷῡ �ش��ϴ� ������ ���浵�� Ȯ���Ѵ�.
 *=============================================================================*/
int upp_sonde_jun_lonlat(int num_upp)
{
  URL_FILE *fr;
  float xx, yy, lon, lat;
  char  url[120], buf[200];
  int   YY, MM, DD, HH, MI;
  int   stn_id, k;

  // 1. URL ����
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(url, "http://172.20.134.91/url/stn_inf.php?inf=UPP&stn=&tm=%04d%02d%02d%02d%02d",
          YY, MM, DD, HH, MI);
  printf("# %s", url);
  if ((fr = url_fopen(url, "r")) == NULL) {
    printf(" (X)\n");
    return -1;
  }
  else {
    printf(" (O)\n");
  }

  // 2. �б�
  while (!url_feof(fr)) {
    url_fgets(buf, sizeof(buf), fr);
    if (buf[0] == '#') continue;

    sscanf(buf, "%d %f %f", &stn_id, &lon, &lat);
    for (k = 0; k < num_upp; k++) {
      if (upp_stn[k].raw == 'J') {
        if (upp_stn[k].stn_id == stn_id) {
          lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);
          upp_stn[k].x = xx;
          upp_stn[k].y = yy;
          break;
        }
      }
    }
  }
  url_fclose(fr);
  return 0;
}

/*=============================================================================*
 *  ���� ���� �����ڷ� �б�
 *=============================================================================*/
int upp_sonde_raw_get(
  int stn_id,   // ������ ���� ������ȣ
  int seq       // ������ �ð�(KST)
)
{
  FILE  *fp;
  char  dname[120], buf[1000];
  float pa, ta, rh, ws, wd, ht, gph, td, asc, lon, lat, vv, xx, yy, ht1, hm, es, e;
  int   YY, MM, DD, HH, MI, SS;
  int   seq1, seq2, seq3, dseq, min, sec;
  int   mode, qc, ok;
  int   k;

  // 1. ���� ����
  seq2time(seq-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(dname, "%s%04d%02d/%02d/UPP_RAW_%d_%04d%02d%02d%02d%02d00.txt", 
          UPP_SND_RAW, YY, MM, DD, stn_id, YY, MM, DD, HH, MI);
  if ((fp = fopen(dname, "r")) == NULL) return -1;
  printf("# %s (O)\n", dname);

  // 2. ��� skip �� ���۽ð� ����
  fgets(buf, 1000, fp);
  if (strstr(buf,"Balloon")) {
    mode = 1;
    sscanf(&buf[30], " %d/%d/%d", &DD, &MM, &YY);  YY += 2000;
    fgets(buf, 1000, fp);
    sscanf(&buf[30], " %d:%d:%d", &HH, &MI, &SS);
    seq1 = time2seq(YY, MM, DD, HH, MI, 'm') + 9*60;
    seq2time(seq1, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

    for (k = 0; k < 4; k++)
      fgets(buf, 1000, fp);
  }
  else {
    mode = 0;
    sscanf(&buf[6], "%d-%d-%d %d:%d:%d", &YY, &MM, &DD, &HH, &MI, &SS);
    seq1 = time2seq(YY, MM, DD, HH, MI, 'm');

    for (k = 0; k < 10; k++)
      fgets(buf, 1000, fp);
  }

  // 3. �ڷ� �б�
  ht1 = 0;
  while (fgets(buf, 1000, fp) != NULL) {
    // 3.1. 1�پ� �о ó���Ѵ�.
    if (mode)
      sscanf(buf, " %d %d %f %f %f %f %f %f %f %f %f %f %f", &min, &sec, &pa, &ta, &hm, &ws, &wd, &ht, &gph, &td, &asc, &lat, &lon);
    else
      sscanf(buf, "%d:%d %f %f %f %f %f %f %f %f", &min, &sec, &pa, &ta, &hm, &ws, &wd, &lon, &lat, &ht);

    // 3.2. �⺻ QC
    if (ht <  500 || ht > 12000) continue;    // �ʹ� ���ų� ������ ����

    qc = 0;
    if (!strcmp(var.obs,"ta")) {
      if (ta >= -95 && ta < 50) {
        vv = ta;
        qc = 1;
      }
    }
    else if (!strcmp(var.obs,"pa")) {
      if (pa > 0 && pa < 1200) {
        vv = pa;
        qc = 1;
      }
    }
    else if (!strcmp(var.obs,"td")) {
      if (hm > 4 && hm <= 100 && ta > -40 && ta < 50) {
        es = 6.112*exp((17.67*ta)/(ta+243.5));
        e = es*hm*0.01;
        vv = log(e/6.112)*243.5/(17.67-log(e/6.112));
        qc = 1;
      }
    }
    else if (!strcmp(var.obs,"ws")) {
      if (ws >= 0 && ws < 250) {
        vv = ws*0.5;
        qc = 1;
      }
    }
    if (qc == 0) continue;

    // 3.3. �ʹ� �������� �ʰ� 100m �̻� �������� ����Ѵ�.
    if (abs(ht - ht1) >= 100)
      ht1 = ht;
    else
      continue;

    // 3.4. �����ϼ��� ����� �ð��븦 ����Ѵ�.
    dseq = abs(var.seq - (seq1 + min));
    ok = 0;
    if (ht < 3000) {
      if (dseq > 2*60) ok = 1;
    }
    else if (ht < 6000) {
      if (dseq > 4*60) ok = 1;
    }
    else {
      if (dseq > 6*60) ok = 1;
    }
    if (ok) continue;

    // 3.5. ���浵 ��ȯ�Ѵ�.
    lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);
    if (xx < 0 || xx > var.NX || yy < 0 || yy > var.NY) continue;

    // 3.6. ���� �迭�� ����Ѵ�.
    stn_data[var.num_data].seq = seq1 + min;
    stn_data[var.num_data].stn_id = stn_id;
    strcpy(stn_data[var.num_data].stn_ko, "KMA:SONDE");
    strcpy(stn_data[var.num_data].stn_sp, "UR");
    stn_data[var.num_data].x = xx;
    stn_data[var.num_data].y = yy;
    stn_data[var.num_data].ht = ht;
    stn_data[var.num_data].d = vv;
    var.num_data++;
  }
  fclose(fp);
  return 0;
}

/*=============================================================================*
 *  ���� ���� Ȯ���� �ص��ڷ� �б�
 *=============================================================================*/
int upp_sonde_ext_get(
  int stn_id, // ������ ���� ������ȣ
  int seq,    // ������ �ð�(KST)
  float x,    // �ش� ������ X,Y ��ǥ
  float y
)
{
  URL_FILE *fr;
  char  url[120], buf[200], tmp[32], tm[32], name[40];
  float vv, xx, yy, ht, lon, lat, pa, ps, ta, td, wd, ws;
  int   stn1, seq3, dseq, dh, qc, ox;
  int   YY, MM, DD, HH, MI;
  int   i, j, k;

  // 1. URL ����
  seq2time(seq-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(url, "http://172.20.134.147/cgi-bin/url/nph-gts_stn_temp_ext?tm=%04d%02d%02d%02d00&stn=%d&mode=2&pa_itv=20&disp=C",
          YY, MM, DD, HH, stn_id);
  printf("# %s", url);
  if ((fr = url_fopen(url, "r")) == NULL) {
    printf(" (X)\n");
    return -1;
  }
  else {
    printf(" (O)\n");
  }

  // 2. �ڷ� ó��
  while (!url_feof(fr)) {
    url_fgets(buf, sizeof(buf), fr);
    if (buf[0] == '#') continue;

    // �ص�
    getword(tm,  buf, ',');
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');   pa = atof(tmp);
    getword(tmp, buf, ',');   ht = atof(tmp);
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');   ta = atof(tmp);
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');   td = atof(tmp);
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');   wd = atof(tmp);
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');   ws = atof(tmp);

    // ���� Ȯ��
    if (ht < 0 || ht > 12000) continue;

    // ����QC Ȯ��
    qc = 0;
    if (!strcmp(var.obs,"ta")) {
      if (ta >= -95 && ta < 50) {
        vv = ta;
        qc = 1;
      }
    }
    else if (!strcmp(var.obs,"pa")) {
      if (pa > 0 && pa < 1200) {
        vv = pa;
        qc = 1;
      }
    }
    else if (!strcmp(var.obs,"td")) {
      if (td >= -95 && td < 50) {
        vv = td;
        qc = 1;
      }
    }
    else if (!strcmp(var.obs,"ws")) {
      if (ws >= 0 && ws < 250) {
        vv = ws;
        qc = 1;
      }
    }
    if (qc == 0) continue;

    // �ð�Ȯ��
    strncpy(tmp, &tm[0], 4);  tmp[4]='\0';  YY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2]='\0';  MM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2]='\0';  DD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2]='\0';  HH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2]='\0';  MI = atoi(tmp);
    seq3 = time2seq(YY, MM, DD, HH, MI, 'm') + 9*60;

    // �����ϼ��� ����� �ð��븦 ����Ѵ�.
    dseq = abs(var.seq - seq3);
    ox = 0;
    if (ht < 3000) {
      if (dseq > 2*60) ox = 1;
    }
    else if (ht < 6000) {
      if (dseq > 4*60) ox = 1;
    }
    else {
      if (dseq > 6*60) ox = 1;
    }
    if (ox) continue;

    // �̸� Ȯ��
    sprintf(name, "KMA:%d", stn_id);

    // ���������� ��Ī
    stn_data[var.num_data].seq = seq3;
    stn_data[var.num_data].stn_id = stn_id;
    strcpy(stn_data[var.num_data].stn_ko, name);
    strcpy(stn_data[var.num_data].stn_sp, "UK");
    stn_data[var.num_data].x = x;
    stn_data[var.num_data].y = y;
    stn_data[var.num_data].ht = ht;
    stn_data[var.num_data].d = vv;
    var.num_data++;
  }
  url_fclose(fr);
  return 0;
}

/*=============================================================================*
 *  ���� ���� �����ص��ڷ� �б� (��¸�)
 *=============================================================================*/
int upp_sonde_jun_get(
  int stn_id, // ������ ���� ������ȣ
  int seq,    // ������ �ð�(KST)
  float x,    // �ش� ������ X,Y ��ǥ
  float y
)
{
  FILE  *fp;
  char  dname[120], buf[200], tmp[100];
  int   ht, ta, dseq, ok;
  int   YY, MM, DD, HH, MI;

  // 1. ���� ����
  seq2time(seq-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(dname, "%s%04d%02d/%02d/UTKO60_%04d%02d%02d%02d%02d_%d", 
          UPP_SND_JUN, YY, MM, DD, YY, MM, DD, HH, MI, stn_id);
  if ((fp = fopen(dname, "r")) == NULL) return -1;
  printf("# %s (O)\n", dname);

  // 2. 1�پ� ó���Ѵ�.
  while (fgets(buf, 200, fp) != NULL) {
    // 2.1. �ڷḦ �д´�.
    getword(tmp, buf, '#');   // ������ȣ
    getword(tmp, buf, '#');   // �ð�(UTC)
    getword(tmp, buf, '#');   // ���(hPa*10)
    getword(tmp, buf, '#');  ht = atoi(tmp);  // GPH(m)
    getword(tmp, buf, '#');  ta = atoi(tmp);  // ���(C*10)

    // 2.2. �⺻ QC
    if (ht <  500 || ht > 12000) continue;    // �ʹ� ���ų� ������ ����
    if (ta < -900 || ta > 500) continue;      // ��°� �̻� ����

    // 2.3. �����ϼ��� ����� �ð��븦 ����Ѵ�.
    dseq = abs(var.seq - seq);
    ok = 0;
    if (ht < 3000) {
      if (dseq > 2*60) ok = 1;
    }
    else if (ht < 6000) {
      if (dseq > 4*60) ok = 1;
    }
    else {
      if (dseq > 6*60) ok = 1;
    }
    if (ok) continue;

    // 2.4. ���� �迭�� ����Ѵ�.
    stn_data[var.num_data].seq = seq;
    stn_data[var.num_data].stn_id = stn_id;
    strcpy(stn_data[var.num_data].stn_ko, "KMA:SONDE");
    strcpy(stn_data[var.num_data].stn_sp, "US");
    stn_data[var.num_data].x = x;
    stn_data[var.num_data].y = y;
    stn_data[var.num_data].ht = ht;
    stn_data[var.num_data].d = 0.1*ta;
    var.num_data++;
  }
  fclose(fp);
  return 0;
}

/*******************************************************************************
 *  GTS TEMP �����ڷ� �б� (Ȯ����)
 *******************************************************************************/
int gts_temp_data_get()
{
  URL_FILE *fr;
  char  url[120], buf[200], tmp[32], tm[32], name[40];
  float vv, xx, yy, ht, lon, lat, pa, ps, ta, td, wd, ws;
  int   stn1, seq, seq3, dseq, dh, qc, ox;
  int   YY, MM, DD, HH, MI;
  int   i, j, k;

  int   num_stn = 0, stn_id[50], stn_seq[50];
  float stn_lon[50], stn_lat[50];

  // ������� ����
  for (dh = 0; dh <= 12; dh += 3) {
    seq = var.seq - dh*60;
    seq2time(seq-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    sprintf(url, "http://172.20.134.91/url/gts_cht_temp.php?tm=%04d%02d%02d%02d00&lon1=115&lon2=135&lat1=25&lat2=45&help=0",
            YY, MM, DD, HH);
    printf("# %s", url);
    if ((fr = url_fopen(url, "r")) == NULL) {
      printf(" (X)\n");
      continue;
    }
    else {
      printf(" (O)\n");
    }

    while (!url_feof(fr)) {
      url_fgets(buf, sizeof(buf), fr);
      if (buf[0] == '#') continue;

      // ���κ� �б�
      sscanf(buf, "%s %d %f %f %f %f %f %f %f %f",
             tm, &stn1, &lon, &lat, &pa, &ht, &ta, &td, &wd, &ws);

      // �ʹ� ���ų� ������ ����
      if (ht < 10 || ht > 12000) continue;

      // �ѱ��� ����
      if (stn1 >= 47090 && stn1 < 47300) continue;

      // ������ �̹� �ִ��� Ȯ��
      for (ox = 0, k = 0; k < var.num_data; k++) {
        if (stn1 == stn_data[k].stn_id && strcmp(stn_data[k].stn_sp,"UT") == 0) {
          ox = 1;
          break;
        }
      }
      if (ox) continue;

      // ������ �̹� �ִ��� Ȯ��
      for (ox = 0, k = 0; k < num_stn; k++) {
        if (stn1 == stn_id[k]) {
          ox = 1;
          break;
        }
      }
      if (ox) continue;

      // ������� ���
      stn_id[num_stn] = stn1;
      stn_seq[num_stn] = seq;
      stn_lon[num_stn] = lon;
      stn_lat[num_stn] = lat;
      num_stn++;
    }
    url_fclose(fr);
  }

  // �������� Ȯ���� URL ȣ��
  for (ox = 0, k = 0; k < num_stn; k++) {
    seq2time(stn_seq[k]-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    sprintf(url, "http://172.20.134.147/cgi-bin/url/nph-gts_stn_temp_ext?tm=%04d%02d%02d%02d00&stn=%d&disp=C",
            YY, MM, DD, HH, stn_id[k]);
    printf("# %s", url);
    if ((fr = url_fopen(url, "r")) == NULL) {
      printf(" (X)\n");
      continue;
    }
    else {
      printf(" (O)\n");
    }

    while (!url_feof(fr)) {
      url_fgets(buf, sizeof(buf), fr);
      if (buf[0] == '#') continue;

      // �ص�
      getword(tm,  buf, ',');
      getword(tmp, buf, ',');
      getword(tmp, buf, ',');   pa = atof(tmp);
      getword(tmp, buf, ',');   ht = atof(tmp);
      getword(tmp, buf, ',');
      getword(tmp, buf, ',');   ta = atof(tmp);
      getword(tmp, buf, ',');
      getword(tmp, buf, ',');   td = atof(tmp);
      getword(tmp, buf, ',');
      getword(tmp, buf, ',');   wd = atof(tmp);
      getword(tmp, buf, ',');
      getword(tmp, buf, ',');   ws = atof(tmp);

      // ���� Ȯ��
      if (ht < 0 || ht > 12000) continue;

      // ����QC Ȯ��
        qc = 0;
      if (!strcmp(var.obs,"ta")) {
        if (ta >= -95 && ta < 50) {
          vv = ta;
          qc = 1;
        }
      }
      else if (!strcmp(var.obs,"pa")) {
        if (pa > 0 && pa < 1200) {
          vv = pa;
          qc = 1;
        }
      }
      else if (!strcmp(var.obs,"td")) {
        if (td >= -95 && td < 50) {
          vv = td;
          qc = 1;
        }
      }
      else if (!strcmp(var.obs,"ws")) {
        if (ws >= 0 && ws < 250) {
          vv = ws;
          qc = 1;
        }
      }
      if (qc == 0) continue;

      // �ð�Ȯ��
      strncpy(tmp, &tm[0], 4);  tmp[4]='\0';  YY = atoi(tmp);
      strncpy(tmp, &tm[4], 2);  tmp[2]='\0';  MM = atoi(tmp);
      strncpy(tmp, &tm[6], 2);  tmp[2]='\0';  DD = atoi(tmp);
      strncpy(tmp, &tm[8], 2);  tmp[2]='\0';  HH = atoi(tmp);
      strncpy(tmp, &tm[10],2);  tmp[2]='\0';  MI = atoi(tmp);
      seq3 = time2seq(YY, MM, DD, HH, MI, 'm') + 9*60;

      // �����ϼ��� ����� �ð��븦 ����Ѵ�.
      dseq = abs(var.seq - seq3);
      ox = 0;
      if (ht < 3000) {
        if (dseq > 2*60) ox = 1;
      }
      else if (ht < 6000) {
        if (dseq > 4*60) ox = 1;
      }
      else {
        if (dseq > 6*60) ox = 1;
      }
      if (ox) continue;

      // �̸� Ȯ��
      sprintf(name, "GTS:%d", stn_id[k]);

      // ��ǥ��ȯ : �����ۿ� ���� ����
      lamcproj_ellp(&stn_lon[k], &stn_lat[k], &xx, &yy, 0, &map);
      if (xx < -0.1*var.NX || xx > 1.1*var.NX || yy < -0.1*var.NY || yy > 1.1*var.NY) continue;

      // ���������� ��Ī
      stn_data[var.num_data].seq = seq3;
      stn_data[var.num_data].stn_id = stn_id[k];
      strcpy(stn_data[var.num_data].stn_ko, name);
      strcpy(stn_data[var.num_data].stn_sp, "UT");
      stn_data[var.num_data].x = xx;
      stn_data[var.num_data].y = yy;
      stn_data[var.num_data].ht = ht;
      stn_data[var.num_data].d = vv;
      var.num_data++;
    }
    url_fclose(fr);
  }
  return 0;
}

/*******************************************************************************
 *  GTS TEMP �����ڷ� �б� (���� �״��, ��¸�)
 *******************************************************************************/
int gts_temp_jun_get()
{
  URL_FILE *fr;
  char  url[120], buf[200], tmp[32], tm[32], stn_cd[20], stn_sp[8], name[40], tp;
  float xx, yy, ht, lon, lat, pa, ps, ta, td, wd, ws;
  int   stn_id, seq, seq3, dseq, pt, dh, ox;
  int   YY, MM, DD, HH, MI;
  int   i, j, k;

  for (dh = 0; dh <= 12; dh += 3) {
    seq = var.seq - dh*60;
    seq2time(seq-9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    sprintf(tm, "&tm=%04d%02d%02d%02d00", YY, MM, DD, HH);

    strcpy(url, "http://172.20.134.91/url/gts_cht_temp.php?");
    strcat(url, tm);
    strcat(url, "&lon1=115&lon2=135&lat1=25&lat2=45&help=0");

    printf("# %s", url);
    if ((fr = url_fopen(url, "r")) == NULL) {
      printf(" (X)\n");
      continue;
    }
    else {
      printf(" (O)\n");
    }

    while (!url_feof(fr)) {
      url_fgets(buf, sizeof(buf), fr);
      if (buf[0] == '#') continue;

      // ���κ� �б�
      sscanf(buf, "%s %d %f %f %f %f %f %f %f %f",
             tm, &stn_id, &lon, &lat, &pa, &ht, &ta, &td, &wd, &ws);

      // �ʹ� ���ų� ������ ����
      if (ht < 10 || ht > 12000) continue;

      // �ѱ��� ����
      if (stn_id >= 47090 && stn_id < 47300) continue;

      // ��� ���� Ȯ��
      if (ta < -90 || ta > 50) continue;

      // ������ �̹� �ִ��� Ȯ��
      for (ox = 0, k = 0; k < var.num_data; k++) {
        if (stn_id == stn_data[k].stn_id && strcmp(stn_data[k].stn_sp,"UT") == 0) {
          ox = 1;
          break;
        }
      }
      if (ox) continue;

      // �ð�Ȯ��
      strncpy(tmp, &tm[0], 4);  tmp[4]='\0';  YY = atoi(tmp);
      strncpy(tmp, &tm[4], 2);  tmp[2]='\0';  MM = atoi(tmp);
      strncpy(tmp, &tm[6], 2);  tmp[2]='\0';  DD = atoi(tmp);
      strncpy(tmp, &tm[8], 2);  tmp[2]='\0';  HH = atoi(tmp);
      strncpy(tmp, &tm[10],2);  tmp[2]='\0';  MI = atoi(tmp);
      seq3 = time2seq(YY, MM, DD, HH, MI, 'm') + 9*60;

      // �����ϼ��� ����� �ð��븦 ����Ѵ�.
      dseq = abs(var.seq - seq3);
      ox = 0;
      if (ht < 3000) {
        if (dseq > 2*60) ox = 1;
      }
      else if (ht < 6000) {
        if (dseq > 4*60) ox = 1;
      }
      else {
        if (dseq > 6*60) ox = 1;
      }
      if (ox) continue;

      // �̸� Ȯ��
      sprintf(name, "GTS:%d", stn_id);

      // ��ǥ��ȯ : �����ۿ� ���� ����
      lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);

      // ���������� ��Ī
      stn_data[var.num_data].seq = seq3;
      stn_data[var.num_data].stn_id = stn_id;
      strcpy(stn_data[var.num_data].stn_ko, name);
      strcpy(stn_data[var.num_data].stn_sp, "UT");
      stn_data[var.num_data].x = xx;
      stn_data[var.num_data].y = yy;
      stn_data[var.num_data].ht = ht;
      stn_data[var.num_data].d = ta;
      var.num_data++;
    }
    url_fclose(fr);
  }
  return 0;
}

/*******************************************************************************
 *  VDPS �ڷ� �б�
 *******************************************************************************/
int vdps_data_get()
{
  URL_FILE *fr;
  char  url[120], buf[200], tmp[32];
  float vv, xx, yy, ht, ta;
  int   ox;
  int   YY, MM, DD, HH, MI;
  int   i, j, k;

  // 1. URL-API ����
  seq2time((int)(var.seq/5)*5, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(url, "http://172.20.134.147/cgi-bin/url/nph-rdr_r3d_vdps_pnt?obs=%s&tm=%04d%02d%02d%02d00&disp=0",
          var.obs, YY, MM, DD, HH);
  printf("# %s", url);
  if ((fr = url_fopen(url, "r")) == NULL) {
    printf(" (X)\n");
    return -1;
  }
  else {
    printf(" (O)\n");
  }

  // 3. �б�
  while (!url_feof(fr)) {
    url_fgets(buf, sizeof(buf), fr);
    if (buf[0] == '#') continue;

    getword(tmp, buf, ',');
    getword(tmp, buf, ',');  xx = atof(tmp);
    getword(tmp, buf, ',');  yy = atof(tmp);
    getword(tmp, buf, ',');  ht = atof(tmp);
    getword(tmp, buf, ',');
    if (strstr(tmp,"nan")) continue;
    vv = atof(tmp);
    if (vv < -90) continue;

    // �ֺ��� �����ڷᰡ ������ ������� �ʴ´�.
    for (k = 0; k < var.num_data; k++) {
      if (strcmp(stn_data[k].stn_sp,"NM") == 0) continue;

      ox = 0;
      if (fabs(stn_data[k].x - xx) < VDPS_PNT_RANGE && fabs(stn_data[k].y - yy) < VDPS_PNT_RANGE) {
        if (stn_data[k].ht < 10)
          ox = 1;
        else {
          if (fabs(stn_data[k].ht - ht) < VDPS_PNT_HT) ox = 1;
        }
      }
      if (ox) break;
    }
    if (ox) continue;

    // 3.5. ���������� ��Ī
    stn_data[var.num_data].seq = var.seq;
    stn_data[var.num_data].stn_id = 9000;
    strcpy(stn_data[var.num_data].stn_ko, "VDPS");
    strcpy(stn_data[var.num_data].stn_sp, "NM");
    stn_data[var.num_data].x = xx;
    stn_data[var.num_data].y = yy;
    stn_data[var.num_data].ht = ht;
    stn_data[var.num_data].d = vv;
    var.num_data++;
  }
  url_fclose(fr);
  return 0;
}

/*******************************************************************************
 *  ��� ���
 *******************************************************************************/
int rdr_r3d_obs_write()
{
  int   YY, MM, DD, HH, MI;
  int   i, j, k;

  // 1. �ڷᰡ ���� ������ ��Ͽ��� ����.
  for (k = 0; k < var.num_data; k++) {
    if (stn_data[k].d < -90) {
      if (k < var.num_data-1) {
        for (i = k; i < var.num_data-1; i++)
          stn_data[i] = stn_data[i+1];
      }
      else {
        var.num_data--;
        break;
      }
      var.num_data--;
      k--;
    }
  }

  // 2. �ڷ� ������ �ڷ� ��
  for (k = 0; k < var.num_data; k++) {
    for (i = 0; i < NUM_SP_LIST; i++) {
      if (strcmp(stn_data[k].stn_sp, sp_lst[i].stn_sp) == 0) {
        sp_lst[i].sp_num += 1;
        break;
      }
    }
  }

  // 3. ���
  if (var.mode == 9) {
    for (i = 0; i < NUM_SP_LIST; i++)
      printf("%s,%s,%d\n", sp_lst[i].stn_sp, sp_lst[i].sp_name, sp_lst[i].sp_num);
    return 0;
  }
  else {
    for (i = 0; i < NUM_SP_LIST; i++)
      printf("# %s, %10s, %d\n", sp_lst[i].stn_sp, sp_lst[i].sp_name, sp_lst[i].sp_num);
  }

  printf("%d\n", var.num_data);
  if (var.disp == 'A') {
    for (k = 0; k < var.num_data; k++) {
      printf("%4d,", k);
      seq2time(stn_data[k].seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
      printf("%04d%02d%02d%02d%02d,", YY, MM, DD, HH, MI);
      printf("%7d,", stn_data[k].stn_id);
      printf("%2s,", stn_data[k].stn_sp);
      printf("%7.3f,%7.3f,%7.2f,", stn_data[k].x, stn_data[k].y, stn_data[k].ht);
      printf("%6.2f,", stn_data[k].d);
      printf("%s,", stn_data[k].stn_ko);
      printf("=\n");
    }
  }
  else {
    for (k = 0; k < var.num_data; k++) {
      printf("%d,", k);
      seq2time(stn_data[k].seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
      printf("%04d%02d%02d%02d%02d,", YY, MM, DD, HH, MI);
      printf("%d,", stn_data[k].stn_id);
      printf("%s,", stn_data[k].stn_sp);
      printf("%.3f,%.3f,%.2f,", stn_data[k].x, stn_data[k].y, stn_data[k].ht);
      printf("%.2f,", stn_data[k].d);
      printf("%s,", stn_data[k].stn_ko);
      printf("=\n");
    }
  }
  return 0;
}

/*=============================================================================*
 *  ���� ���� ���� �б�
 *
 *      map : inp:������ ����
 *      nx  : out:�������� �������� (km)
 *      ny  : out:���Ϲ��� �������� (km)
 *      sx  : out:�������� ������ġ (km)
 *      sy  : out:���Ϲ��� ������ġ (km)
 *=============================================================================*/
int grid_map_inf(char *map, int *nx, int *ny, int *sx, int *sy)
{
  FILE  *fp;
  char  buf[1024], map_list[8], value[16];

  fp = fopen(MAP_INI_FILE,"r");
  if (fp == NULL) exit(-1);

  while (fgets(buf,1024,fp)) {
    if (buf[0] == '#') continue;
    getword(map_list, buf, ':');

    if ( !strcmp(map, map_list) ) {
      getword(value, buf, ':');  *nx = atoi(value);
      getword(value, buf, ':');  *ny = atoi(value);
      getword(value, buf, ':');  *sx = atoi(value);
      getword(value, buf, ':');  *sy = atoi(value);
      break;
    }
  }
  fclose(fp);
  return 0;
}
