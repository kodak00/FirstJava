/*******************************************************************************
**
**  URL �Լ� �̿��� ���� ��ġ�� GRIB ���� �ص� �� ���� CGI ���α׷�
**     o ��� : ��ǥ�ð�, �����ð�, ����, ������ ���� ������ �����ڷ�
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2013.08.24)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <math.h>
#include "cgiutil.h"

#define DATA_HOME_SUPER   "/op_data1/NWPD/"
#define DATA_HOME_COMIS   "/DATA/NWP/" //2017.12.04.Ȳ����.
#define DATA_HOME_TMPD    "/home/fct/TMPD/"
#define DATA_MODE   2     // 0:SUPER, 1: COMIS

#define MAX_BUF    5000000

struct TIMES {
  int   YY;
  int   MM;
  int   DD;
  int   HH;
  int   MI;
};

struct INPUT_VAR {
  char   fname[120];      // ����� ����, ���ϸ�
  int    mode;            // ������� ǥ�⿩�� (1: ǥ��)
} var;

struct GRIB1_SECTION0 {   // INDICATOR SECTION (IS)
  char  head[5];          // "GRIB"
  int   length;           // Total length
  int   version;          // Edition number
};

struct GRIB1_SECTION1 {   // PRODUCT DEFINITION SECTION (PDS)
  int   length;           // �� ������ ����
  int   version;          // Parameter Table Version number
  int   center;           // Identification of center (Table 0 - Part 1)
  int   process;          // Generating process ID number
  int   grid;             // Grid Identification (geographical location and area; See Table B)
  char  GB[2];            // Flag specifying the presence or absence of a GDS or a BMS (See Table 1)
  int   parameter;        // Indicator of parameter and units (Table 2)
  int   type_level;       // Indicator of type of level or layer (See Tables 3 & 3a)
  int   lvl_L1;           // Height, pressure, etc. of the level or layer (See Table 3)
  int   lvl_L2;           // Height, pressure, etc. of the level or layer (See Table 3)
  int   level;            // Height, pressure, etc. of the level or layer (See Table 3)
  int   YY;               // �ڷ�ð� : ��
  int   MM;               // �ڷ�ð� : ��
  int   DD;               // �ڷ�ð� : ��
  int   HH;               // �ڷ�ð� : ��
  int   MI;               // �ڷ�ð� : ��
  int   time_unit;        // Forecast time unit (see Table 4)
  int   time_P1;          // P1 - Period of time (Number of time units) : Units of time given by content of octet 18
  int   time_P2;          // P2 - Period of time (Number of time units) : Time interval between ...
  int   time_range;       // Time range indicator (See Table 5)
  int   time_acc;         // Number included in average, when octet 21 (Table 5) indicates an average or accumulation; otherwise set to zero
  int   time_miss;        // Number Missing from averages or accumulations
  int   century;          // Century of Initial (Reference) time (=20 until Jan. 1, 2001)
  int   sub_center;       // Identification of sub-center (Table 0 - Part 2)
  int   D;                // The decimal scale factor D. A negative value is indicated by setting the high order bit(bit No. 1) in octet 27 to 1 (on).
  int   d[300];           // ECMWF �ӻ���� ���, 50���� �����ȣ�� ����
};

struct GRIB1_SECTION2 {   // GRID DESCRIPTION SECTION (GDS)
  int   length;           // �� ������ ����
  int   NV;               // number of vertical coordinate parameters
  int   PV;               // location (octet number) of the list of vertical coordinate
  int   grid_type;        // Data representation type (See Table 6)
  int   NX;               // Number of points along x-axis
  int   NY;               // Number of points along y-axis

  // �����浵�� ���
  int   Lo1;              // longitude of first grid point / units : degrees x 1000
  int   Lo2;              // Longitude of last grid point  / units : degrees x 1000
  int   La1;              // latitude of first grid point  / units : degrees x 1000
  int   La2;              // Latitude of last grid point   / units : degrees x 1000
  int   Dx;               // Longitudinal Direction Increment / units : degrees x 1000
  int   Dy;               // latitude Direction Increment / units : degrees x 1000
  char  scan[3];          // Scanning mode
};

struct GRIB1_SECTION3 {   // BIT MAP SECTION (BMS)
  int   length;           // �� ������ ����
  int   unused_bits;      // Number of unused bits at end of Section 3
  int   predef;           // 0: a bit map follows or not / the numeric refers to a predefined bit map provided by the center
};

struct GRIB1_SECTION4 {   // BINARY DATA SECTION (BDS).
  int   length;           // �� ������ ����
  int   flag;             // flag (Table 11)
  int   unused_bits;      // Number of unused bits at end of Section 4
  int   E;                // binary scale factor (E). A negative value is indicated by setting the high order bit (bit No. 1) in octet 5 to 1 (on)
  float R;                // Reference value
  int   num_bits;         // Number of bits into which a datum point is packed
};

struct GRIB1_INF {
  struct GRIB1_SECTION0 s0;
  struct GRIB1_SECTION1 s1;
  struct GRIB1_SECTION2 s2;
  struct GRIB1_SECTION3 s3;
  struct GRIB1_SECTION4 s4;
} grib;

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main() {
  // 1. ��� �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(60);

  printf("HTTP/1.0 200 OK\n");
  printf("Server: Netscape-Enterprise/3.0\n");

  // 2. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    printf("Content-type: text/html\n\n");
    printf(" input variable error<p>\n");
    return -1;
  }

  // 3. �ڷ� ���
  printf("Content-type: text/plain\n\n");
  printf("#START7777\n");

  GRIB1_head_dec(var.fname);

  printf("#7777END\n");

  alarm(0);
  return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
  char *qs;
  char tmp[256], item[1000], value[1000], tmfc[30], tmef[30];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  seq, iseq, i;

  // 1. ���� �ʱ�ȭ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  var.mode = 0;

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"fname")) strcpy(var.fname,value);
    else if ( !strcmp(item,"mode" )) var.mode = atoi(value);
  }
  return 0;
}

/*=============================================================================*
 *  GRIB-1 Header Decode
 *=============================================================================*/
int GRIB1_head_dec(char  *fname) {
  static FILE  *fp;
  struct stat st;
  unsigned char  buf[MAX_BUF];
  long   S, A, B, fsize, total_length;
  int    mode, code, i, j, k = 1;

  code = stat(fname, &st);
  if (code != 0) return -22;
  fsize = st.st_size;

  fp = fopen(fname, "rb");
  if (fp == NULL) return -23;
  total_length = 0;

  if (var.mode != 1) printf("     #:    GRIB:PDS:GDS:GB:SCAN:����:type:   ����:BIT:            �ð�           : NX * NY : G:NV:  PV:���:\n");

  while ((fsize -= total_length) > 0) {
    // 1. Section 0
    if (fread(buf, 1, 4, fp) <= 0) return -24;

    for (mode = 0, i = 0; i < fsize; i++) {  // GRIB ���� ��ġ ã��
      buf[4] = '\0';

      if (strncmp(buf, "GRIB", 4) == 0) {
        mode = 1;
        break;
      }
      else {
        for (j = 0; j < 3; j++)
          buf[j] = buf[j+1];
        buf[3] = fgetc(fp);
      }
    }
    fsize -= i;
    if (mode != 1) return -25;
    printf("%4dth:", k);

    strcpy(grib.s0.head, buf);
    fread(buf, 1, 4, fp);       // ��ü ���� Ȯ��
    grib.s0.length = (buf[0]*256 + buf[1])*256 + buf[2];
    grib.s0.version = buf[4];
    total_length = grib.s0.length;

    if (var.mode) {
      printf("\n[ Section 0 (INDICATOR SECTION) ]\n");
      printf("%s\n", grib.s0.head);
      printf("total length   = %d bytes\n", grib.s0.length);
      printf("edition number = %d\n", grib.s0.version);
    }

    // 2. Section 1 (PDS)
    fread(buf, 1, 3, fp);
    grib.s1.length = (buf[0]*256 + buf[1])*256 + buf[2];
    fread(buf, 1, grib.s1.length-3, fp);

    grib.s1.version = buf[0];
    grib.s1.center  = buf[1];
    grib.s1.process = buf[2];
    grib.s1.grid = buf[3];

    strcpy(grib.s1.GB, "00");
    if ((buf[4]&128) > 0) grib.s1.GB[0] = '1';
    if ((buf[4]&64)  > 0) grib.s1.GB[1] = '1';

    grib.s1.parameter  = buf[5];
    grib.s1.type_level = buf[6];
    grib.s1.lvl_L1 = buf[7];
    grib.s1.lvl_L2 = buf[8];

    switch (grib.s1.type_level) {
      case 101:  case 104:  case 106:  case 108:  case 110:  case 112:  case 114:  case 121:  case 128:  case 141:
        grib.s1.level = grib.s1.lvl_L1*1000 + grib.s1.lvl_L2;
        break;
      default:
        grib.s1.level = grib.s1.lvl_L1*256 + grib.s1.lvl_L2;
    }

    grib.s1.YY = buf[9];
    grib.s1.MM = buf[10];
    grib.s1.DD = buf[11];
    grib.s1.HH = buf[12];
    grib.s1.MI = buf[13];
    grib.s1.time_unit = buf[14];
    grib.s1.time_P1 = (unsigned int)buf[15];
    grib.s1.time_P2 = (unsigned int)buf[16];
    grib.s1.time_range = buf[17];
    grib.s1.time_acc   = buf[18]*256 + buf[19];;
    grib.s1.time_miss  = buf[20];
    grib.s1.century    = buf[21];
    grib.s1.sub_center = buf[22];

    S = buf[23] & 128;
    grib.s1.D = (buf[23]&127)*256 + buf[24];
    if (S > 0) grib.s1.D = -1 * grib.s1.D;
    grib.s1.YY = (grib.s1.century-1)*100 + grib.s1.YY;

    if (grib.s1.length > 40) {
      for (i = 41; i <= grib.s1.length; i++)
        grib.s1.d[i] = buf[i-4];
    }

    if (var.mode) {
      printf("\n[ Section 1 (PRODUCT DEFINITION SECTION) ]\n");
      printf("length     = %d bytes\n", grib.s1.length);
      printf("version    = %d\n", grib.s1.version);
      printf("center     = %d\n", grib.s1.center);
      printf("process    = %d\n", grib.s1.process);
      printf("grid       = %d\n", grib.s1.grid);
      printf("GDS/BMS    = %s\n", grib.s1.GB);
      printf("parameter  = %d\n", grib.s1.parameter);
      printf("type_level = %d ", grib.s1.type_level);

      switch (grib.s1.type_level) {
        case 1:   printf("(surface)");  break;
        case 2:   printf("(cloud base level)");  break;
        case 3:   printf("(cloud top level)");  break;
        case 4:   printf("(0 deg (C) isotherm level)");  break;
        case 5:   printf("(adiabatic condensation level)");  break;
        case 6:   printf("(maximum wind speed level)");  break;
        case 7:   printf("(tropopause level)");  break;
        case 8:   printf("(Nominal top of atmosphere)");  break;
        case 9:   printf("(Sea bottom)");  break;
        case 100: printf("(isobaric(hPa))");  break;
        case 102: printf("(mean sea level)");  break;
        case 105: printf("(height above ground(m))");  break;
        case 109: printf("(Hybrid level number)");  break;
      }
      printf("\n");
      printf("level      = %d\n", grib.s1.level);

      printf("YY.MM.DD.HH:MI = %04d.%02d.%02d.%02d:%02d\n",
             grib.s1.YY, grib.s1.MM, grib.s1.DD, grib.s1.HH, grib.s1.MI);
      printf("time_unit  = %d\n", grib.s1.time_unit);
      printf("time_P1    = %d\n", grib.s1.time_P1);
      printf("time_P2    = %d\n", grib.s1.time_P2);
      printf("time_range = %d\n", grib.s1.time_range);
      printf("time_acc   = %d\n", grib.s1.time_acc);
      printf("time_miss  = %d\n", grib.s1.time_miss);
      printf("century    = %d\n", grib.s1.century);
      printf("sub_center = %d\n", grib.s1.sub_center);
      printf("D          = %d\n", grib.s1.D);

      if (grib.s1.length > 40) {
        for (i = 41; i <= grib.s1.length; i++)
          printf("d[%d] = %d\n", i, grib.s1.d[i]);
      }
    }

    // 3. Section 2 (GDS)
    fread(buf, 1, 3, fp);
    grib.s2.length = (buf[0]*256 + buf[1])*256 + buf[2];
    fread(buf, 1, grib.s2.length-3, fp);

    grib.s2.NV = buf[0];
    grib.s2.PV = buf[1];
    grib.s2.grid_type = buf[2];
    grib.s2.NX = buf[3]*256 + buf[4];
    grib.s2.NY = buf[5]*256 + buf[6];

    if (grib.s2.grid_type == 0) {
      grib.s2.La1 = ((buf[7]&127)*256 + buf[8])*256 + buf[9];
      if (buf[7]&128) grib.s2.La1 *= -1;
      grib.s2.Lo1 = ((buf[10]&127)*256 + buf[11])*256 + buf[12];
      if (buf[10]&128) grib.s2.Lo1 *= -1;
      grib.s2.La2 = ((buf[14]&127)*256 + buf[15])*256 + buf[16];
      if (buf[14]&128) grib.s2.La2 *= -1;
      grib.s2.Lo2 = ((buf[17]&127)*256 + buf[18])*256 + buf[19];
      if (buf[17]&128) grib.s2.Lo2 *= -1;
      grib.s2.Dx  = buf[20]*256 + buf[21];
      grib.s2.Dy  = buf[22]*256 + buf[23];

      strcpy(grib.s2.scan, "000");
      if (buf[24] & 128) grib.s2.scan[0] = '1';
      if (buf[24] & 64)  grib.s2.scan[1] = '1';
      if (buf[24] & 32)  grib.s2.scan[2] = '1';
    }

    if (var.mode) {
      printf("\n[ Section 2 (GRID DESCRIPTION SECTION) ]\n");
      printf("length     = %d bytes\n", grib.s2.length);
      printf("NV         = %d\n", grib.s2.NV);
      printf("PV         = %d\n", grib.s2.PV);
      printf("grid_type  = %d ",  grib.s2.grid_type);

      switch (grib.s2.grid_type) {
        case 0:  printf("(�����浵)");  break;
        case 1:  printf("(Mercator Projection)");  break;
        case 2:  printf("(Gnomonic Projection)");  break;
        case 3:  printf("(Lambert Conformal)");  break;
        case 4:  printf("(Gaussian Latitude/Longitude)");  break;
        case 5:  printf("(Polar Stereographic Projection)");  break;
        case 13: printf("(Oblique Lambert conformal)");  break;
        case 50: printf("(Spherical Harmonic Coefficients)");  break;
        case 90: printf("(Space view perspective or orthographic grid)");  break;
      }
      printf("\n");

      printf("NX,NY      = %d,%d\n", grib.s2.NX, grib.s2.NY);
      printf("Lo1,Lo2    = %d,%d\n", grib.s2.Lo1, grib.s2.Lo2);
      printf("La1,La2    = %d,%d\n", grib.s2.La1, grib.s2.La2);
      printf("Dx,Dy      = %d,%d\n", grib.s2.Dx, grib.s2.Dy);
      printf("scan       = %s\n", grib.s2.scan);
    }

    // 4. Section 3 (BMS)
    if (grib.s1.GB[1] == '1') {
      fread(buf, 1, 3, fp);
      grib.s3.length = (buf[0]*256 + buf[1])*256 + buf[2];
      fread(buf, 1, grib.s3.length-3, fp);

      grib.s3.unused_bits = buf[0];
      grib.s3.predef = buf[1]*256 + buf[2];

      if (var.mode) {
        printf("\n[ Section 3 (BIT MAP SECTION) ]\n");
        printf("length     = %d bytes\n", grib.s3.length);
        printf("unused_bits= %d (Code Table 3.0)\n", grib.s3.unused_bits);
        printf("predef     = %d\n", grib.s3.predef);
      }
    }

    // 5. Section 4 (BDS)
    fread(buf, 1, 3, fp);
    grib.s4.length = (buf[0]*256 + buf[1])*256 + buf[2];
    fread(buf, 1, grib.s4.length-3, fp);

    grib.s4.flag = buf[0];

    S = buf[1] & 128;
    grib.s4.E = (buf[1]&127)*256 + buf[2];
    if (S > 0) grib.s4.E = -1 * grib.s4.E;

    S = buf[3] & 128;
    A = buf[3] & 127;
    B = (buf[4]*256 + buf[5])*256 + buf[6];

    grib.s4.R = pow(2,-24) * B * pow(16,(A-64));
    if (S > 0) grib.s4.R = -1 * grib.s4.R;

    grib.s4.num_bits = buf[7];

    if (var.mode) {
      printf("\n[ Section 4 (BINARY DATA SECTION) ]\n");
      printf("length     = %d bytes\n", grib.s4.length);
      printf("flag       = %d\n", grib.s4.flag);
      printf("E          = %d\n", grib.s4.E);
      printf("R          = %f\n", grib.s4.R);
      printf("num_bits   = %d\n", grib.s4.num_bits);
    }

    // 6. Section 5
    fread(buf, 1, 4, fp);

    // 7. ���
    if (var.mode != 1) {
      printf("%8d:", grib.s0.length);
      printf("%3d:", grib.s1.length);
      printf("%3d:", grib.s2.length);
      printf("%s:", grib.s1.GB);
      printf(" %3s:", grib.s2.scan);
      printf(" %3d:", grib.s1.parameter);
      printf(" %3d:", grib.s1.type_level);
      printf(" %6d:", grib.s1.level);
      printf("%3d:", grib.s4.num_bits);
      printf(" %04d.%02d.%02d.%02d:%02d", grib.s1.YY, grib.s1.MM, grib.s1.DD, grib.s1.HH, grib.s1.MI);
      printf("(+%03d,%03d):", grib.s1.time_P1, grib.s1.time_P2);
      printf("%4d*%4d:", grib.s2.NX, grib.s2.NY);
      printf(" %d: %d: %d:", grib.s2.grid_type, grib.s2.NV, grib.s2.PV);

      if (strstr(var.fname, "ecen_") || strstr(var.fname, "ecmw_ewam"))
        printf("%4d:", grib.s1.d[50]);
      else
        printf("%4d:", 0);
      printf("\n");
    }
    else
      printf("-----------------------------------------------------------\n");
    k++;
  }
  return 0;
}

/*=============================================================================*
 *  GRIB ���Ͽ��� GRIB~7777 ������ ����
 *=============================================================================*/
int GRIB_block_read(
    FILE  *fp,              // inp: Read File Point
    int   *fsize,           // inp: file size
    unsigned char buf[]     // out: GRIB block data
                            // return: block size (include GRIB and 7777)
)
{
  static int fz = 0;
  unsigned char b[MAX_BUF], c1;
  int   bsize = 0;
  int   mode = 0, i, j;

  // GRIB position Search
  if (fread(b, 4, 1, fp) <= 0) return -301;
  if (fz == 0) fz = *fsize;

  for (i = 0; i < fz; i++) {
    b[4] = '\0';

    if (strncmp(b, "GRIB", 4) == 0) {
      mode = 1;
      break;
    }
    else {
      for (j = 0; j < 3; j++)
        b[j] = b[j+1];
      b[3] = fgetc(fp);
    }
  }
  fz -= (i + 4);
  if (mode != 1) return -303;
  *fsize -= i;

  // 7777 ���� �ڷ� �б�
  strcpy(buf, b);
  bsize = 4;

  for (i = 0; i < fz; i++) {
    buf[i+4] = fgetc(fp);

    if (strncmp(&buf[i+1], "7777", 4) == 0) {
      buf[i+5] = '\0';
      bsize = i + 5;
      fz -= (i + 1);
      break;
    }
  }
  *fsize -= bsize;
  return bsize;
}
