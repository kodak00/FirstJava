/******************************************************************************
**
**  ���̴� UF������ ��ŸDB ����� �ڷ� ���� ���α׷�
**
**============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.11.25)
**
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "cgiutil.h"
#include "rsl_wrc.h"

#define  RDR_UF_RAW_DIR  "/DATA/RDR/RAW"
#define  RDR_UF_QCD_DIR  "/DATA/RDR/QCD"
#define  RDR_UF_HSR_DIR  "/DATA/RDR/HSR"
#define  RDR_UF_LNG_DIR  "/DATA/RDR/LNG"
#define  MAX_SWPN  50   // ������ �ִ� ����

// ����� ��û����
struct INPUT_VAR {
  int  seq;         // ��û�� �ڷ�ð�(KST)
  char stn_cd[8];   // ���̴�����Ʈ �����ڵ�
  char qcd[8];      // RAW, QCD, FQC ��
  char disp;        // A(ASCII), C(CSV)
  int  help;
  char fname[120];
  int  size;
} var;

// ��������
struct RDR_UF_META {
  int   seq;          // �ڷ�ð�(KST)
  char  stn_cd[8];    // �����ڵ�
  int   swpn;         // ������ȣ
  float elev;         // ������(degree)
  int   num_vol;      // ���� ����
  int   num_ray;      // ray ����
  int   num_diff_ray; // ���� ray�� �������� �������̻� ���̰� �� ray��
  int   num_bin;      // bin ����
  int   num_DZ;       // DZ�� NULL�� �ƴ� �ڷ��
  int   num_CZ;       // CZ�� NULL�� �ƴ� �ڷ��
  int   num_VR;       // VR�� NULL�� �ƴ� �ڷ��
  int   num_SW;       // SW�� NULL�� �ƴ� �ڷ��
  int   num_DR;       // DR�� NULL�� �ƴ� �ڷ��
  int   num_RH;       // RH�� NULL�� �ƴ� �ڷ��
  int   num_PH;       // PH�� NULL�� �ƴ� �ڷ��
  int   num_KD;       // KD�� NULL�� �ƴ� �ڷ��
  int   num_DZ_24dbz; // DZ�� 24dbz �̻��� �ڷ��
  int   num_CZ_24dbz; // CZ�� 24dbz �̻��� �ڷ��
} meta[MAX_SWPN];

/******************************************************************************
 *
 *  MAIN
 *
 ******************************************************************************/
int main()
{
  int  code;

  // 1. ��� �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(30);

  printf("HTTP/1.0 200 OK\n");
  //printf("Server: Netscape-Enterprise/3.0\n");
  printf("Content-type: text/plain\n\n");

  // 2. ����� �Է� ���� �м�
  if ( (code = user_input()) < 0) {
    printf("# input variable error\n");
    return -1;
  }

  // 3. �ڷ� ���
  disp_meta();
 
  alarm(0);
  return 0;
}

/******************************************************************************
 *  ����� ��û�ڷ� �м�
 ******************************************************************************/
int user_input()
{
  char *qs;
  char tmp[256], item[32], value[32], tm[30], fname[120];
  int  YY, MM, DD, HH, MI, SS;
  int  seq, seq1, i, j;

  // 1. ���� �ʱ�ȭ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "");
  strcpy(var.stn_cd, "");
  strcpy(var.qcd, "RAW");
  var.disp = 'A';
  var.help = 1;

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');
    if (strlen(value) <= 0) continue;

    if      ( !strcmp(item,"tm")) strcpy(tm,value);
    else if ( !strcmp(item,"stn")) strcpy(var.stn_cd,value);
    else if ( !strcmp(item,"qcd")) strcpy(var.qcd,value);
    else if ( !strcmp(item,"disp")) var.disp = value[0];
    else if ( !strcmp(item,"help")) var.help = atoi(value);
  }
  if (strlen(var.stn_cd) < 3) return -1;

  // 3. ��û�ð� �� ���� ����ð� ����
  if (strlen(tm) >= 12) {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  YY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  MM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  DD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  HH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  MI = atoi(tmp);
    var.seq = time2seq(YY, MM, DD, HH, MI, 'm');
  }
  else {
    return -2;
  }
  return 0;
}

/******************************************************************************
 *  �������� ����
 ******************************************************************************/
int disp_meta()
{
  Radar  *radar;
  Volume *volume;
  Sweep  *sweep;
  Ray    *ray;
  float  ec, az1, az2, diff_az;
  int    YY, MM, DD, HH, MI;
  int    first, ok;
  int    i, j, k, n;

  // 1. �ڷ������� �ִ��� Ȯ��
  if (rdr_uf_file() < 0) {
    printf("# No Data file (%s)\n", var.fname);
    return -1;
  }

  // 2. �ʱ�ȭ
  for (k = 0; k < MAX_SWPN; k++) {
    meta[k].swpn = -1;
    meta[k].elev = -99;
    meta[k].num_vol = 0;
    meta[k].num_ray = 0;
    meta[k].num_diff_ray = 0;
    meta[k].num_bin = 0;
    meta[k].num_DZ = 0;
    meta[k].num_CZ = 0;
    meta[k].num_VR = 0;
    meta[k].num_SW = 0;
    meta[k].num_DR = 0;
    meta[k].num_RH = 0;
    meta[k].num_PH = 0;
    meta[k].num_KD = 0;
    meta[k].num_DZ_24dbz = 0;
    meta[k].num_CZ_24dbz = 0;
  }

  // 3. ���� ����
  radar = RSL_uf_to_radar(var.fname);
  if (radar == NULL) {
    printf("# radar rsl open error (%s)\n", var.fname);
    return -1;
  }

  // 4. �������� ����
  for (first = 0, n = 0; n < radar->h.nvolumes; n++) {
    if ((volume = radar->v[n]) == NULL) continue;
    first++;

    for (k = 0; k < volume->h.nsweeps; k++) {
      if ((sweep = volume->sweep[k]) == NULL) continue;

      if (first == 1) {
        meta[k].swpn = k;
        meta[k].elev = sweep->h.elev;
      }
      meta[k].num_vol += 1;

      for (j = 0; j < sweep->h.nrays; j++) {
        if ((ray = sweep->ray[j]) == NULL) continue;

        if (first == 1) meta[k].num_ray += 1;
        if (meta[k].num_bin < ray->h.nbins) meta[k].num_bin = ray->h.nbins;

        // ����ray�� ���̰� ������ ���� ���� �̻��̸� ī��Ʈ
        if (first == 1) {
          az2 = ray->h.azimuth;
          if (j > 0) {
            if ((diff_az = az2 - az1) < 0) diff_az += 360;
            diff_az -= 1.0;
            if (fabs(diff_az) > 0.2) {
              meta[k].num_diff_ray += 1;
            }
          }
          az1 = az2;
        }

        // �ȼ��� ����
        for (i = 0; i < ray->h.nbins; i++) {
          ec = ray->h.f(ray->range[i]);
          if (ec < 131000)
            ok = 1;
          else
            ok = 0;

          switch (n) {
            case 0:  meta[k].num_DZ += ok;  break;
            case 3:  meta[k].num_CZ += ok;  break;
            case 1:  meta[k].num_VR += ok;  break;
            case 2:  meta[k].num_SW += ok;  break;
            case 5:  meta[k].num_DR += ok;  break;
            case 9:  meta[k].num_RH += ok;  break;
            case 10:  meta[k].num_PH += ok;  break;
            case 17:  meta[k].num_KD += ok;  break;
          }

          if (ok && (n == 0 || n == 3) && ec >= 24) {
            if      (n == 0) meta[k].num_DZ_24dbz += 1;
            else if (n == 3) meta[k].num_CZ_24dbz += 1;
          }
        }
      }
    }
  }

  // 5. ���� �ݱ�
  RSL_free_radar(radar);

  // 9. ��� ���
  printf("#    TM(KST), STN, QCD,SWP,      ELEV,VOL#,RAY#,D_R#,BIN#,     DZ#,     CZ#,     VR#,     SW#,     DR#,     RH#,     PH#,     KD#,   DZ24#,   CZ24#,=\n");

  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  for (k = 0; k < MAX_SWPN; k++) {
    if (meta[k].swpn < 0) continue;

    if (var.disp == 'A') {
      printf("%04d%02d%02d%02d%02d,", YY, MM, DD, HH, MI);
      printf("%4s,", var.stn_cd);
      printf("%4s,", var.qcd);
      printf("%3d,", meta[k].swpn);
      printf("%10.6f,", meta[k].elev);
      printf("%4d,", meta[k].num_vol);
      printf("%4d,", meta[k].num_ray);
      printf("%4d,", meta[k].num_diff_ray);
      printf("%4d,", meta[k].num_bin);
      printf("%8d,", meta[k].num_DZ);
      printf("%8d,", meta[k].num_CZ);
      printf("%8d,", meta[k].num_VR);
      printf("%8d,", meta[k].num_SW);
      printf("%8d,", meta[k].num_DR);
      printf("%8d,", meta[k].num_RH);
      printf("%8d,", meta[k].num_PH);
      printf("%8d,", meta[k].num_KD);
      printf("%8d,", meta[k].num_DZ_24dbz);
      printf("%8d,", meta[k].num_CZ_24dbz);
      printf("=\n");
    }
    else {
      printf("%04d%02d%02d%02d%02d,", YY, MM, DD, HH, MI);
      printf("%s,", var.stn_cd);
      printf("%s,", var.qcd);
      printf("%d,", meta[k].swpn);
      printf("%.6f,", meta[k].elev);
      printf("%d,", meta[k].num_vol);
      printf("%d,", meta[k].num_ray);
      printf("%d,", meta[k].num_diff_ray);
      printf("%d,", meta[k].num_bin);
      printf("%d,", meta[k].num_DZ);
      printf("%d,", meta[k].num_CZ);
      printf("%d,", meta[k].num_VR);
      printf("%d,", meta[k].num_SW);
      printf("%d,", meta[k].num_DR);
      printf("%d,", meta[k].num_RH);
      printf("%d,", meta[k].num_PH);
      printf("%d,", meta[k].num_KD);
      printf("%d,", meta[k].num_DZ_24dbz);
      printf("%d,", meta[k].num_CZ_24dbz);
      printf("=\n");
    }
  }
  return 0;
}

/*=============================================================================*
 *  ���̴� UF�ڷ� ���� ���� Ȯ��
 *=============================================================================*/
int rdr_uf_file()
{
  struct stat st;
  int    YY, MM, DD, HH, MI;
  int    code;

  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  if (!strcmp(var.qcd,"QCD") || !strcmp(var.qcd,"FQC"))
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_%s_%04d%02d%02d%02d%02d.uf",
            RDR_UF_QCD_DIR, YY, MM, DD, var.stn_cd, var.qcd, YY, MM, DD, HH, MI);
  else
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_%04d%02d%02d%02d%02d.uf",
            RDR_UF_RAW_DIR, YY, MM, DD, var.stn_cd, YY, MM, DD, HH, MI);

  code = stat(var.fname, &st);
  var.size = st.st_size;
  if (code < 0 || st.st_size <= 100) return -1;
  return 0;
}
