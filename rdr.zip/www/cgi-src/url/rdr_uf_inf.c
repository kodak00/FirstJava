/******************************************************************************
**
**  UF RADAR �ڷ� Header ���� ��ȸ�� CGI ���α׷�
**
**============================================================================*
**
**     o �ۼ��� : ����ȯ (2010. 8. 2)
**
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "cgiutil.h"
#include "rsl_wrc.h"

#define  RDR_UF_RAW_DIR  "/DATA/RDR/RAW"
#define  RDR_UF_QCD_DIR  "/DATA/RDR/QCD"
#define  RDR_UF_HSR_DIR  "/DATA/RDR/HSR"
#define  RDR_UF_LNG_DIR  "/DATA/RDR/LNG"

struct INPUT_VAR {
  int  seq;
  int  YY;
  int  MM;
  int  DD;
  int  HH;
  int  MI;
  char stn_cd[16];
  int  qcd;
  int  help;
  char fname[120];
  int  size;
} var;

/******************************************************************************
 *
 *  MAIN
 *
 ******************************************************************************/
int main()
{
  int  code;

  // 1. ��� �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(30);

  printf("HTTP/1.0 200 OK\n");
  printf("Server: Netscape-Enterprise/3.0\n");

  // 2. ����� �Է� ���� �м�
  printf("Content-type: text/plain\n\n");
  if ( (code = user_input()) < 0) {
    if (code == -2)
      printf("# no file\n");
    else
      printf("# input variable error\n");
    return -1;
  }

  // 3. �ڷ� ���
  disp_inf();
 
  alarm(0);
  return 0;
}

/******************************************************************************
 *
 *  ����� ��û�ڷ� �м�
 *
 ******************************************************************************/
int user_input()
{
  char *qs;
  char tmp[256], item[32], value[32], tm[30], fname[120];
  int  YY, MM, DD, HH, MI, SS;
  int  seq, seq1, i, j;

  // 1. ���� �ʱ�ȭ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "");
  strcpy(var.stn_cd, "");
  var.help = 1;

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"tm"))   strcpy(tm,value);
    else if ( !strcmp(item,"stn"))  strcpy(var.stn_cd,value);
    else if ( !strcmp(item,"qcd"))  var.qcd = atoi(value);
    else if ( !strcmp(item,"help")) var.help = atoi(value);
  }
  if (strlen(var.stn_cd) < 3) return -1;

  // 3. ��û�ð� �� ���� ����ð� ����
  if (strlen(tm) >= 12) {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  YY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  MM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  DD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  HH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  MI = atoi(tmp);
    seq = time2seq(YY, MM, DD, HH, MI, 'm');
  }
  else {
    get_time(&YY, &MM, &DD, &HH, &MI, &SS);
    seq = time2seq(YY, MM, DD, HH, MI, 'm');
  }

  // 4. ���� ����� �ð����� UF �ڷḦ ã��
  for (var.seq = -1, j = 0; j <= 20; j++) {
    for (i = 0; i < 2; i++) {
      if (i == 0)
        seq1 = seq + j;
      else
        seq1 = seq - j;

      seq2time(seq1, &(var.YY), &(var.MM), &(var.DD), &(var.HH), &(var.MI), 'm', 'n');
      if (rdr_uf_file() >= 0) {
        var.seq = seq1;
        break;
      }
    }
    if (var.seq > 0) break;
  }
  if (var.seq < 0) return -2;

  return 0;
}

/******************************************************************************
 *
 *  HTML mode
 *
 ******************************************************************************/
int disp_inf()
{
  Radar  *radar;
  Volume *volume;
  Sweep  *sweep;
  Ray    *ray;
  float  beam_width, nyq_vel;
  int    nbins, range_bin1, gate_size;
  int    seq, YY, MM, DD, HH, MI, SS;
  int    i, j, k;

  // 1. ���� 
  if (var.help == 1) {
    printf("#--------------------------------------------------------------------------------------------------\n");
    printf("#  [�Է��μ�����][��] ?tm=201001051200&stn=KWK&qcd=1&help=1\n");
    printf("#--------------------------------------------------------------------------------------------------\n");
    printf("#   filename : UF���ϸ� (���ϸ����� �ð��� KST)\n");
    printf("#   filesize : UF����ũ�� (bytes)\n");
    printf("#       time : UF���� ����� ��ϵ� �������� �ð� : ��.��.��.��.��.��(KST) : ���� UF���Ͽ��� UTC�� ��ϵǾ� ����\n");
    printf("# radar_type : �� ������ ���� : uf\n");
    printf("#   nvolumes : �� ���Ͽ� ���Ե� �� �ִ� �ִ� �����ڷ�� (���� ��ϵ� �ڷ���ʹ� Ʋ��)\n");
    printf("#   latitude : ���̴������� ���� (��.��.��)\n");
    printf("#  longitude : ���̴������� �浵 (��.��.��)\n");
    printf("#     height : ���̴� ���׳� �ع߰��� (m)\n");
    printf("#--------------------------------------------------------------------------------------------------\n");
  }

  // 2. ���� ����
  radar = RSL_uf_to_radar(var.fname);
  if (radar == NULL) {
    printf("# radar rsl open error (%s)\n", var.fname);
    return -1;
  }

  // 3. ���� ����
  YY = radar->h.year;
  MM = radar->h.month;
  DD = radar->h.day;
  HH = radar->h.hour;
  MI = radar->h.minute;
  SS = (int)(radar->h.sec + 0.5);

  seq = time2seq(YY, MM, DD, HH, MI, 'm');
  seq2time(seq+9*60, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  //printf("    filename : RDR_%s_%04d%02d%02d%02d%02d.uf \n", var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
  printf("    filename : %s \n", var.fname);
  printf("    filesize : %d\n", var.size);
  printf("        time : %04d.%02d.%02d.%02d.%02d.%02d \n", YY, MM, DD, HH, MI, SS);
  printf("  radar_type : %s \n", radar->h.radar_type);
  printf("    nvolumes : %d \n", radar->h.nvolumes);
  printf("      number : %d \n", radar->h.number);
  printf("        name : %s \n", radar->h.name);
  printf("  radar_name : %s \n", radar->h.radar_name);
  printf("     project : %s \n", radar->h.project);
  printf("        city : %s \n", radar->h.city);
  printf("       state : %s \n", radar->h.state);
  printf("    latitude : %3d.%02d.%02d \n", radar->h.latd, radar->h.latm, radar->h.lats);
  printf("   longitude : %3d.%02d.%02d \n", radar->h.lond, radar->h.lonm, radar->h.lons);
  printf("      height : %d \n", radar->h.height);
  printf("      spulse : %d \n", radar->h.spulse);
  printf("      lpulse : %d \n", radar->h.lpulse);

  // 4. �ڷ��� ����
  if (var.help == 1) {
    printf("#--------------------------------------------------------------------------------------------------\n");
    printf("#         Vn : Volume Number\n");
    printf("#        nsw : number of sweeps\n");
    printf("#         sw : sweep number\n");
    printf("#       evel : �ش� sweep�� ������ (degree)\n");
    printf("#       nray : �ش� sweep�� ��(ray)�� ��\n");
    printf("#       nbin : Number of array elements for 'Range' \n");
    printf("#       gate : gate_size : Data gate size (meters)\n");
    printf("#       bin1 : range_bin1 : Range to first gate.(meters)\n");
    printf("#      width : Beamwidth (degree)\n");
    printf("#    nyq_vel : Nyquist velocity (m/s)\n");
    printf("#--------------------------------------------------------------------------------------------------\n");
  }
  printf("#Vn nsw  sw     evel  nray  nbin  gate  bin1   width nyq_vel\n");

  for (k = 0; k < radar->h.nvolumes; k++) {
    if ((volume = radar->v[k]) == NULL) continue;

    for (j = 0; j < volume->h.nsweeps; j++) {
      if ((sweep = volume->sweep[j]) == NULL) continue;

      for (i = 0; i < sweep->h.nrays; i++) {
        if ((ray = sweep->ray[i]) != NULL) {
          nbins = ray->h.nbins;
          gate_size = ray->h.gate_size;
          range_bin1 = ray->h.range_bin1;
          beam_width = ray->h.beam_width;
          nyq_vel = ray->h.nyq_vel;
          break;
        }
      }
      printf("%3d %3d %3d %8.4f %5d %5d %5d %5d %7.3f %7.3f\n",
          k, volume->h.nsweeps,
          j, sweep->h.elev, sweep->h.nrays,
          nbins, gate_size, range_bin1, beam_width, nyq_vel);
    }
  }

  // 5. ���� �ݱ�
  RSL_free_radar(radar);

  return 0;
}

/*=============================================================================*
 *  ���̴� UF�ڷ� ���� ���� Ȯ��
 *=============================================================================*/
int rdr_uf_file()
{
  struct stat st;
  int    code;

  if (var.qcd == 5) {
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_HSR2_%04d%02d%02d%02d%02d.uf",
        RDR_UF_HSR_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
    code = stat(var.fname, &st);
    if (code < 0) {
      sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_HSR1_%04d%02d%02d%02d%02d.uf",
          RDR_UF_HSR_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
      code = stat(var.fname, &st);
    }
    if (code < 0) return -1;
    var.size = st.st_size;
    if (st.st_size <= 100) return -1;
  }
  else {
    if (var.qcd == 1)
      sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_QCD_%04d%02d%02d%02d%02d.uf",
          RDR_UF_QCD_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
    else if (var.qcd == 2)
      sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_FQC_%04d%02d%02d%02d%02d.uf",
          RDR_UF_QCD_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
    else if (var.qcd == 3)
      sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_NQS_%04d%02d%02d%02d%02d.uf",
          RDR_UF_RAW_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
    else if (var.qcd == 6)
      sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_LNG_%04d%02d%02d%02d%02d.uf",
          RDR_UF_LNG_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
    else if (var.qcd == 7)
      sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_LNG_FQC_%04d%02d%02d%02d%02d.uf",
          RDR_UF_LNG_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
    else if (var.qcd == 99)
      sprintf(var.fname, "/rdr/REF/HSR/RDR_%s_REAL_TIME_BK.uf", var.stn_cd);
    else
      sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_%04d%02d%02d%02d%02d.uf",
          RDR_UF_RAW_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);

    code = stat(var.fname, &st);
    var.size = st.st_size;
    if (code < 0 || st.st_size <= 100) return -1;
  }
  return 0;
}
