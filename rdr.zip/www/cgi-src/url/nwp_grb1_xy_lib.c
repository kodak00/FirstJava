/*******************************************************************************
**
**  URL �Լ� �̿��� ���� ��ġ�� GRIB ���� �ص� �� ���� CGI ���α׷�
**     o ��� : ��ǥ�ð�, �����ð�, ����, ������ ���� ������ �����ڷ�
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2013.07.01)
**
********************************************************************************/
#include "nwp_grib.h"
#include "nwp_grib_xy.h"

extern struct INPUT_VAR var;
extern struct VAR_DATA  vars[3];
extern float  *dg;

/*******************************************************************************
 *
 *  1�� ����, 1�� ������ 2���� ���ڰ����� ����
 *  (���Ĵ� 2�� ������ ������ ����� 1�� ���̶� �ǹ�)
 *
 *******************************************************************************/
int nwp_grb1_xy() {
  float *p1, *p2, b1;
  int   err;
  int   i, j, k;

  // 1. �ڷ� ����
  if ( (err = nwp_grb1_xy_data()) < 0 ) return err;

  if (var.num_vars != var.num_ok) {
    err = -25;
    return err;
  }
  if ( (err = map_sub_area()) < 0 ) return err;

  // 2. ��-������ ����� ���� ��-������ ��ȯ
  for (k = 0; k < var.num_vars; k++) {
    if (vars[k].scan[1] == '0') {
      p1 = &(vars[k].buf[0]);
      p2 = &(vars[k].buf[ (vars[k].ny-1)*vars[k].nx ]);

      for (j = 0; j < vars[k].ny/2; j++, p2 -= (vars[k].nx*2)) {
        for (i = 0; i < vars[k].nx; i++, p1++, p2++) {
          b1 = *p1;
          *p1 = *p2;
          *p2 = b1;
        }
      }
    }
  }

  // 3. �ڷ� ��ȯ
  if (var.map == 'R' || var.map == 'K' || var.map == 'G')
    nwp_grib_map_conv();
  else
    nwp_grib_xy_conv();

  // 4. ��Ȱȭ
  if (var.sm > 0) nwp_grib_filter();

  // 5. �۾����� ����
  for (k = 0; k < var.num_vars; k++)
    free((char*) (vars[k].buf));
  return 0;
}

/*******************************************************************************
 *
 *  �ҿ��� ���� (�Ϻ� ������ ����� ���, ������ ��ü����)
 *
 *******************************************************************************/
int map_sub_area() {
  char  tmp[120];
  int   i, j, k;

  if (var.map == 'S') {
    for (k = 0, i = 0; i < strlen(var.sub); i++) {
      if (var.sub[i] == ',') k++;
    }

    if (k == 3) {
      getword (tmp, var.sub, ',');  var.x_min = atoi(tmp);
      getword (tmp, var.sub, ',');  var.y_min = atoi(tmp);
      getword (tmp, var.sub, ',');  var.x_max = atoi(tmp);
      getword (tmp, var.sub, ',');  var.y_max = atoi(tmp);
    }
    else
      return -11;
    if (var.x_min < 1 || var.y_min < 1 || var.x_max > var.nx || var.y_max > var.ny) return -12;
  }
  else if (var.map == 'R') {
    var.x_min = 1;
    var.y_min = 1;
    var.x_max = UMRG_NX;
    var.y_max = UMRG_NY;
  }
  else if (var.map == 'K') {
    var.x_min = 1;
    var.y_min = 1;
    var.x_max = UMKR_NX;
    var.y_max = UMKR_NY;
  }
  else if (var.map == 'G') {
    var.x_min = 1;
    var.y_min = 1;
    var.x_max = 149;
    var.y_max = 253;
  }
  else {
    var.map = 'F';
    var.x_min = 1;
    var.y_min = 1;
    var.x_max = var.nx;
    var.y_max = var.ny;
  }
  return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� ��Ȱȭ
 *
 *******************************************************************************/
int nwp_grib_filter()
{
  float *p1, *p2, *p3, d;
  int   length_sub = (var.y_max-var.y_min+1)*(var.x_max-var.x_min+1);
  int   nx = var.x_max - var.x_min + 1;
  int   on_bit = 0;
  int   i, j, k;

  // 1. �񿬼����� ������ ��Ȱȭ�� ���� ����
  for (i = 0; i < var.num_varn*var.num_level; i++) {
    if (vars[i].on_bit == 1) {
      on_bit = 1;
      break;
    }
  }

  if (on_bit) {
    var.sm = 0;
    return 0;
  }

  // 2. 9-point ��Ȱȭ
  for (k = 0; k < var.sm; k++) {
    if (k % 2 == 0) {
      dg += (length_sub + nx*2 - 1);
      p3 = dg - nx;
      p2 = dg - nx*2;
      p1 = dg - nx*3;

      for (j = var.y_max; j >= var.y_min; j--) {
        for (i = var.x_max; i >= var.x_min; i--, dg--, p1--, p2--, p3--) {
          if (j == var.y_min) {
            if (i == var.x_min)
              *dg = (*p2 + *(p2+1) + *p3 + *(p3+1)) / 4.0;
            else if (i == var.x_max)
              *dg = (*p2 + *(p2-1) + *p3 + *(p3-1)) / 4.0;
            else
              *dg = (*(p2-1) + *p2 + *(p2+1) + *(p3-1) + *p3 + *(p3+1)) / 6.0;
          }
          else if (j == var.y_max) {
            if (i == var.x_min)
              *dg = (*p2 + *(p2+1) + *p1 + *(p1+1)) / 4.0;
            else if (i == var.x_max)
              *dg = (*p2 + *(p2-1) + *p1 + *(p1-1)) / 4.0;
            else
              *dg = (*(p2-1) + *p2 + *(p2+1) + *(p1-1) + *p1 + *(p1+1)) / 6.0;
          }
          else {
            if (i == var.x_min)
              *dg = (*p1 + *(p1+1) + *p2 + *(p2+1) + *p3 + *(p3+1)) / 6.0;
            else if (i == var.x_max)
              *dg = (*p1 + *(p1-1) + *p2 + *(p2-1) + *p3 + *(p3-1)) / 6.0;
            else
              *dg = (*(p1-1) + *p1 + *(p1+1) + *(p2-1) + *p2 + *(p2+1) + *(p3-1) + *p3 + *(p3+1)) / 9.0;
          }
        }
      }
      dg += 1;
    }
    else {
      dg -= (nx*2);
      p3 = dg + nx*3;
      p2 = dg + nx*2;
      p1 = dg + nx;

      for (j = var.y_min; j <= var.y_max; j++) {
        for (i = var.x_min; i <= var.x_max; i++, dg++, p1++, p2++, p3++) {
          if (j == var.y_min) {
            if (i == var.x_min)
              *dg = (*p2 + *(p2+1) + *p3 + *(p3+1)) / 4.0;
            else if (i == var.x_max)
              *dg = (*p2 + *(p2-1) + *p3 + *(p3-1)) / 4.0;
            else
              *dg = (*(p2-1) + *p2 + *(p2+1) + *(p3-1) + *p3 + *(p3+1)) / 6.0;
          }
          else if (j == var.y_max) {
            if (i == var.x_min)
              *dg = (*p2 + *(p2+1) + *p1 + *(p1+1)) / 4.0;
            else if (i == var.x_max)
              *dg = (*p2 + *(p2-1) + *p1 + *(p1-1)) / 4.0;
            else
              *dg = (*(p2-1) + *p2 + *(p2+1) + *(p1-1) + *p1 + *(p1+1)) / 6.0;
          }
          else {
            if (i == var.x_min)
              *dg = (*p1 + *(p1+1) + *p2 + *(p2+1) + *p3 + *(p3+1)) / 6.0;
            else if (i == var.x_max)
              *dg = (*p1 + *(p1-1) + *p2 + *(p2-1) + *p3 + *(p3-1)) / 6.0;
            else
              *dg = (*(p1-1) + *p1 + *(p1+1) + *(p2-1) + *p2 + *(p2+1) + *(p3-1) + *p3 + *(p3+1)) / 9.0;
          }
        }
      }
      dg -= length_sub;
    }
  }
  return 0;
}

/*******************************************************************************
 *
 *  Lambert Conformal Conic Projection ���� �ڷ� ��ȯ
 *  (���ɿ��δ� ������ �Ǵ� �ʿ�)
 *
 *******************************************************************************/
int nwp_grib_map_conv()
{
  struct lamc_parameter  map;
  double dx = 360.0/var.nx, dy = 180.0/(var.ny-1);
  double di, dj, d1, d2, d3, d4;
  float  *p1, *p2, lon, lat, x1, y1;
  float  u, v, t, td, rh, e, es;
  int    length_sub = (var.y_max-var.y_min+1)*(var.x_max-var.x_min+1);
  int    i, j, k, i1, j1, k1, k2, k3, k4;

  // 1. ���� ����
  map.Re    = 6371.229;
  map.slat1 = 30.0;
  map.slat2 = 60.0;
  map.olon  = 126.0;
  map.olat  = 38.0;
  map.first = 0;

  if (var.map == 'R') {        // UM���� ����
    map.grid  = 12.0;
    map.xo = 246.144823;
    map.yo = 210.123204;
    map.first = 0;
  }
  else if (var.map == 'K') {   // UM���� ����
    map.grid  = 1.5;
    map.xo = 259.652595;
    map.yo = 412.242644;
    map.first = 0;
  }
  else if (var.map == 'G') {   // ���׿��� ����
    map.grid  = 5;
    map.xo = 210.0/map.grid;
    map.yo = 675.0/map.grid;
    map.first = 0;
  }

  // 2. ������� �Ҵ�
  // main���� ȣ���ϴ� ������ �̸� ����� ������ �Ҵ��ϴ� ������ ����(��ȣ��� ���� �ذ��� ����)
  //dg = (float *)malloc((unsigned) (length_sub+(var.x_max-var.x_min+1)*2)*sizeof(float));

  p1 = &(vars[0].buf[0]);
  if (var.num_vars > 1) p2 = &(vars[1].buf[0]);

  // 3. ���ں��� ó��
  for (j = var.y_min; j <= var.y_max; j++) {
    for (i = var.x_min; i <= var.x_max; i++, dg++) {
      y1 = j - 1;
      x1 = i - 1;
      lamcproj(&lon, &lat, &x1, &y1, 1, &map);
      if (lon < 0) lon += 360.0;
      lat += 90.0;

      // 3.1. ������ ������ 1��
      if (var.num_vars == 1) {
        if (vars[0].Cgrid == 0) {
          if (var.num_bit > 0) {   // BIT MAP�� ���� ����� ������ ���� ���
            i1 = (int)(lon / dx + 0.5);   j1 = (int)(lat / dy + 0.5);
            k1 = j1*var.nx + i1;
            *dg = *(p1 + k1);
          }
          else {
            i1 = (int)(lon / dx);   j1 = (int)(lat / dy);
            di = lon/dx - i1;       dj = lat/dy - j1;

            k1 = j1*var.nx + i1;
            k2 = k1 + var.nx;
            if (k1 % var.nx == 0) k2 = k1 - var.nx + 1;

            d1 = ( *(p1+k1)*(1.0-di) + *(p1+k1+1)*di );
            d2 = ( *(p1+k2)*(1.0-di) + *(p1+k2+1)*di );

            *dg = ( d1*(1.0-dj) + d2*dj );
          }
        }
        else if (vars[0].Cgrid == 1) {
          lon -= 0.5*dx;
          if (lon < 0) lon += 360.0;

          i1 = (int)(lon / dx);   j1 = (int)(lat / dy);
          di = lon/dx - i1;       dj = lat/dy - j1;

          k1 = j1*var.nx + i1;
          k2 = k1 + var.nx;
          if (k1 % var.nx == 0) k2 = k1 - var.nx + 1;

          d1 = ( *(p1+k1)*(1.0-di) + *(p1+k1+1)*di );
          d2 = ( *(p1+k2)*(1.0-di) + *(p1+k2+1)*di );

          *dg = ( d1*(1.0-dj) + d2*dj );
        }
        else if (vars[0].Cgrid == 2) {
          lat -= 0.5*dy;

          i1 = (int)(lon / dx);   j1 = (int)(lat / dy);
          di = lon/dx - i1;       dj = lat/dy - j1;

          if (j1 < 0) {
            k1 = i1;
            *dg = *(p1+k1);
          }
          else {
            k1 = j1*var.nx + i1;
            k2 = k1 + var.nx;
            if (k1 % var.nx == 0) k2 = k1 - var.nx + 1;

            d1 = ( *(p1+k1)*(1.0-di) + *(p1+k1+1)*di );
            d2 = ( *(p1+k2)*(1.0-di) + *(p1+k2+1)*di );

            *dg = ( d1*(1.0-dj) + d2*dj );
          }
        }
      }

      // 3.2 ������ ������ 2�� �̻�
      else {
        // 3.2.1. ����
        if (var.varn == 3012) {
          i1 = (int)(lon / dx);   j1 = (int)(lat / dy);
          di = lon/dx - i1;       dj = lat/dy - j1;

          k1 = j1*var.nx + i1;
          k2 = k1 + var.nx;
          if (k1 % var.nx == 0) k2 = k1 - var.nx + 1;

          d1 = ( *(p1+k1)*(1.0-di) + *(p1+k1+1)*di );
          d2 = ( *(p1+k2)*(1.0-di) + *(p1+k2+1)*di );
          d3 = ( *(p2+k1)*(1.0-di) + *(p2+k1+1)*di );
          d4 = ( *(p2+k2)*(1.0-di) + *(p2+k2+1)*di );

          *dg = ( d1*(1.0-dj) + d2*dj ) - ( d3*(1.0-dj) + d4*dj );
        }

        // 3.2.2 �̽��� �µ�(6), ����(1254), ���(1000), ȥ�պ�(1002)
        else if (var.varn == 6 || var.varn == 1254 || var.varn == 1000 || var.varn == 1002) {
          i1 = (int)(lon / dx);   j1 = (int)(lat / dy);
          di = lon/dx - i1;       dj = lat/dy - j1;

          k1 = j1*var.nx + i1;
          k2 = k1 + var.nx;
          if (k1 % var.nx == 0) k2 = k1 - var.nx + 1;

          d1 = ( *(p1+k1)*(1.0-di) + *(p1+k1+1)*di );
          d2 = ( *(p1+k2)*(1.0-di) + *(p1+k2+1)*di );
          t  = d1*(1.0-dj) + d2*dj - 273.15;

          d3 = ( *(p2+k1)*(1.0-di) + *(p2+k1+1)*di );
          d4 = ( *(p2+k2)*(1.0-di) + *(p2+k2+1)*di );
          rh = d3*(1.0-dj) + d4*dj;

          es = 6.112 * exp((17.67 * t)/(t + 243.5));
          e  = es * (rh * 0.01);
          td = log(e/6.112) * 243.5 / (17.67 - log(e/6.112));

          if (var.varn == 6)
            *dg = td + 273.15;
          else if (var.varn == 1254)
            *dg = t - td;
          else if (var.varn == 1000)
            *dg = (0.622 * es) / (var.level*0.01 - (0.378 * es));
          else if (var.varn == 1002)
            *dg = (0.622 * es) / (var.level*0.01 - es);
        }

        // 3.2.3. ǳ��(2000), ǳ��(2001)
        else if (var.varn == 2000 || var.varn == 2001) {
          i1 = (int)(lon / dx);   j1 = (int)(lat / dy);
          di = lon/dx - i1;       dj = lat/dy - j1;

          k1 = j1*var.nx + i1;
          k2 = k1 + var.nx;
          if (k1 % var.nx == 0) k2 = k1 - var.nx + 1;

          // 3.2.3.1. U-wind
          d1 = ( *(p1+k1)*(1.0-di) + *(p1+k1+1)*di );
          d2 = ( *(p1+k2)*(1.0-di) + *(p1+k2+1)*di );
          u = ( d1*(1.0-dj) + d2*dj );

          // 3.2.3.2. V-wind
          d1 = ( *(p2+k1)*(1.0-di) + *(p2+k1+1)*di );
          d2 = ( *(p2+k2)*(1.0-di) + *(p2+k2+1)*di );
          u = ( d1*(1.0-dj) + d2*dj );

          // 3.2.3.3. ǳ��
          if (var.varn == 2000) {
            *dg = atan2(-v, -u) * RAD2DEG;
            if (*dg < 0) *dg += 360.0;
          }

          // 3.2.3.4. ǳ��
          if (var.varn == 2001) {
            *dg = u*u + v*v;

            if (*dg < 0.00001)
              *dg = 0;
            else
              *dg = sqrt(*dg);
          }
        }
      }
    }
  }
  dg -= length_sub;

  return 0;
}

/*******************************************************************************
 *
 *  �ڷ� ��ȯ
 *
 *******************************************************************************/
int nwp_grib_xy_conv()
{
  float *p1, *p2, b1;
  float u, v, t, td, rh, es, e;
  int   length_sub, start_sub;
  int   Cgrid, i, j, k;

  // 1. �Ϻ� ���ڸ� ������ ��츦 ����, ������ڿ��� ����
  length_sub = (var.y_max-var.y_min+1)*(var.x_max-var.x_min+1);
  start_sub = (var.y_min)*(var.x_min-1);

  // main���� ȣ���ϴ� ������ �̸� ����� ������ �Ҵ��ϴ� ������ ����(��ȣ��� ���� �ذ��� ����)
  //dg = (float *)malloc((unsigned) (length_sub+(var.x_max-var.x_min+1)*2)*sizeof(float));

  // 2. ���� ������ ���� ������ ���
  if (var.num_vars == 1) {
    p1 = &(vars[0].buf[start_sub]);

    if (vars[0].Cgrid == 0) {
      for (j = var.y_min; j <= var.y_max; j++) {
        for (i = var.x_min; i <= var.x_max; i++, dg++, p1++)
          *dg = *p1;
        p1 += (var.nx - (var.x_max - var.x_min + 1));
      }
    }
    else if (vars[0].Cgrid == 1) {
      for (j = var.y_min; j <= var.y_max; j++) {
        for (i = var.x_min; i <= var.x_max; i++, dg++, p1++) {
          if (i == 1)
            *dg = (*(p1+var.nx-1) + *p1) * 0.5;
          else if (i == var.nx)
            *dg = (*p1 + *(p1-var.nx+1)) * 0.5;
          else
            *dg = (*(p1-1) + *p1) * 0.5;
        }
        p1 += (var.nx - (var.x_max - var.x_min + 1));
      }
    }
    else if (vars[0].Cgrid == 2) {
      for (j = var.y_min; j <= var.y_max; j++) {
        if (j == 1 || j == var.ny) {
          for (i = var.x_min; i <= var.x_max; i++, dg++)
            *dg = 0;
        }
        else {
          for (i = var.x_min; i <= var.x_max; i++, dg++, p1++)
            *dg = (*p1 + *(p1+var.nx)) * 0.5;
          p1 += (var.nx - (var.x_max - var.x_min + 1));
        }
      }
    }
  }

  // 3. ǳ��(2000), ǳ��(2001)
  else if (var.varn == 2000 || var.varn == 2001) {
    p1 = &(vars[0].buf[start_sub]);
    p2 = &(vars[1].buf[start_sub]);

    if (vars[1].Cgrid == 0) {
      for (j = var.y_min; j <= var.y_max; j++) {
        for (i = var.x_min; i <= var.x_max; i++, dg++, p1++, p2++) {
          u = *p1;
          v = *p2;

          if (var.varn == 2000) {
            *dg = atan2(-v, -u) * RAD2DEG;
            if (*dg < 0) *dg += 360.0;
          }
          else if (var.varn == 2001) {
            *dg = u*u + v*v;

            if (*dg < 0.00001)
              *dg = 0;
            else
              *dg = sqrt(*dg);
          }
        }
        p1 += (var.nx - (var.x_max - var.x_min + 1));
        p2 += (var.nx - (var.x_max - var.x_min + 1));
      }
    }
    else if (vars[1].Cgrid == 2) {
      for (j = var.y_min; j <= var.y_max; j++) {
        if (j == 1 || j == var.ny) {
          for (i = var.x_min; i <= var.x_max; i++, dg++, p1++) {
            if (var.varn == 2000)
              *dg = 0;
            else if (var.varn == 2001)
              *dg = *p1;
          }
          if (j == 1) p1 += (var.nx - (var.x_max - var.x_min + 1));
        }
        else {
          for (i = var.x_min; i <= var.x_max; i++, dg++, p1++, p2++) {
            if (i == 1)
              u = (*(p1+var.nx-1) + *p1) * 0.5;
            else if (i == var.nx)
              u = (*p1 + *(p1-var.nx+1)) * 0.5;
            else
              u = (*(p1-1) + *p1) * 0.5;

            v = (*p1 + *(p1+var.nx)) * 0.5;

            if (var.varn == 2000) {
              *dg = atan2(-v, -u) * RAD2DEG;
              if (*dg < 0) *dg += 360.0;
            }
            else if (var.varn == 2001) {
              *dg = u*u + v*v;

              if (*dg < 0.00001)
                *dg = 0;
              else
                *dg = sqrt(*dg);
            }
          }
          p1 += (var.nx - (var.x_max - var.x_min + 1));
          p2 += (var.nx - (var.x_max - var.x_min + 1));
        }
      }
    }
  }

  // 4. ����
  else if (var.varn == 3012) {
    p1 = &(vars[0].buf[start_sub]);
    p2 = &(vars[1].buf[start_sub]);

    for (j = var.y_min; j <= var.y_max; j++) {
      for (i = var.x_min; i <= var.x_max; i++, dg++, p1++, p2++)
        *dg = *p1 - *p2;

      p1 += (var.nx - (var.x_max - var.x_min + 1));
      p2 += (var.nx - (var.x_max - var.x_min + 1));
    }
  }

  // 5. �̽��� �µ�(6), ����(1254), ���(1000), ȥ�պ�(1002)
  else if (var.varn == 6 || var.varn == 1254 || var.varn == 1000 || var.varn == 1002) {
    p1 = &(vars[0].buf[start_sub]);
    p2 = &(vars[1].buf[start_sub]);

    for (j = var.y_min; j <= var.y_max; j++) {
      for (i = var.x_min; i <= var.x_max; i++, dg++, p1++, p2++) {
        t = *p1 - 273.15;
        rh = *p2;

        es = 6.112 * exp((17.67 * t)/(t + 243.5));
        e  = es * (rh * 0.01);
        td = log(e/6.112) * 243.5 / (17.67 - log(e/6.112));

        if (var.varn == 6)
          *dg = td + 273.15;
        else if (var.varn == 1254)
          *dg = t - td;
        else if (var.varn == 1000)
          *dg = (0.622 * es) / (var.level*0.01 - (0.378 * es));
        else if (var.varn == 1002)
          *dg = (0.622 * es) / (var.level*0.01 - es);
      }

      p1 += (var.nx - (var.x_max - var.x_min + 1));
      p2 += (var.nx - (var.x_max - var.x_min + 1));
    }
  }

  // 6. ó�� ��ġ�� �̵�
  dg -= length_sub;

  return 0;
}

/*=============================================================================*
 *  BIT ����
 *=============================================================================*/
int getbits(unsigned char a, char *s)
{
  unsigned short  x = a;
  int  i;

  for (i = 0; i < 8; i++) {
    if (x%2 == 0)
      s[7-i] = '0';
    else
      s[7-i] = '1';
    x /= 2;
  }
  return 0;
}

/*******************************************************************************
 *
 *  �ڷ� �б�
 *
 *******************************************************************************/
int nwp_grb1_xy_data()
{
  static FILE  *fp;
  static char  fname[120];
  static int   fsize;
  static unsigned long total_length = 0;

  struct stat st;
  unsigned char buf[MAX_BUF], bit_map[MAX_BIT_MAP], bit, b1;
  unsigned int  S, RE, RM;
  char   bit_code[9];
  float  d1, Scale_E, Scale_D, Refv_R;
  int    num_grib = 0;        // ���� GRIB ������
  int    vars_num;
  int    seq_fc, seq_ef, YY, MM, DD, HH, MI;
  int    bsize, length, GB, varn, level, nx, ny;
  int    on, on_varn, on_level, on_member, on_bit, on_data;
  int    A, B, v, sbyte, sbit, num_bits, member;
  int    code, mode;
  int    i, j, k, k1, k2, n;

  // 1. �ʱ�ȭ
  var.num_ok = 0;

  // 2. ���� ����
  if (fp == NULL) {
    code = stat(var.fname, &st);
    if (code != 0) return -22;
    var.fsize = st.st_size;

    if ((fp = fopen(var.fname, "rb")) == NULL) return -23;

    strcpy(fname, var.fname);
    fsize = var.fsize;
    total_length = 0;
  }
  else {
    if (strcmp(var.fname, fname) == 0 && fsize == var.fsize)
      rewind(fp);
    else {
      fclose(fp);
      if ((fp = fopen(var.fname, "rb")) == NULL) return -23;

      strcpy(fname, var.fname);
      fsize = var.fsize;
    }
    total_length = 0;
  }

  // 3. �ش� �ڷḸ �б�
  while ((fsize -= total_length) > 0) {
    // 3.1. Section-0
    if (fread(buf, 1, 4, fp) <= 0) return -24;

    // 3.1.1. GRIB ���� ��ġ ã��
    for (mode = 0, i = 0; i < fsize; i++) {
      buf[4] = '\0';

      if (strncmp(buf, "GRIB", 4) == 0) {
        mode = 1;
        break;
      }
      else {
        for (j = 0; j < 3; j++)
          buf[j] = buf[j+1];
        buf[3] = fgetc(fp);
      }
    }
    fsize -= i;
    if (mode != 1) return -25;

    // 3.1.2. ��ü ���� Ȯ��
    fread(buf, 1, 4, fp);
    total_length = (buf[0]*256 + buf[1])*256 + buf[2];

    // 3.2. Section-1 (PDS)
    fread(buf, 1, 3, fp);
    length = (buf[0]*256 + buf[1])*256 + buf[2];
    fread(buf, 1, length-3, fp);

    // 3.2.1. GDS, BMS ���� ���� Ȯ��
    GB = 0;
    if ((buf[4]&128) > 0) GB = 10;  // GDS ���� ����
    if ((buf[4]&64)  > 0) GB += 1;  // BMS ���� ����

    // 3.2.2. ������ȣ �� ������ Ȯ��
    varn = buf[5];       // ������
    switch (buf[6]) {    // ������
      case 101:  case 104:  case 106:  case 108:  case 110:  case 112:  case 114:  case 121:  case 128:  case 141:
        level = buf[7]*1000 + buf[8];
        break;
      default:
        level = buf[7]*256 + buf[8];
    }

    // 3.2.3. �ӻ�� ��� Ȯ��
    if (var.member >= 0 && length > 50)
      member = buf[46];   // ECMWF �ӻ���� ����� ��ġ
    else
      member = -1;

    // 3.2.4. ��ǥ�ð� Ȯ��
    YY = ((int)buf[21]-1)*100 + (int)buf[9];
    MM = (int)buf[10];
    DD = (int)buf[11];
    HH = (int)buf[12];
    MI = (int)buf[13];
    seq_fc = time2seq(YY, MM, DD, HH, MI, 'm');

    // 3.2.5. ��ȿ�ð� Ȯ��
    if (buf[16] > 0)
      seq_ef = seq_fc + 60*(unsigned int)buf[16];
    else
      seq_ef = seq_fc + 60*(unsigned int)buf[15];

    // 3.2.6. ã�� ����*���� ��Ͽ� �ִ��� Ȯ��
    if (var.tmfc.seq == seq_fc && var.tmef.seq == seq_ef) {
      // 3.2.6.1. ����, ���� ��ġ�� �˻�
      for (on_varn = 0, on_level = 0, k = 0; k < var.num_varn*var.num_level; k++) {
        if (vars[k].varn == varn && vars[k].level == level) {
          on_varn = 1;
          on_level = 1;
          vars_num = k;
          break;
        }
      }

      // 3.2.6.2. �ӻ�� ��� ��ġ�� �˻�
      if (var.member < 0)     // ����� ��������� ����
        on_member = 1;
      else if (var.member == member)
        on_member = 1;
      else
        on_member = 0;

      // 3.2.6.3. ��ǥ�ð�, ��ȿ�ð�, ����, ����, �⺸�� ��ġ�ϸ� ó��
      if (on_varn && on_level && on_member)
        on = 1;
      else
        on = 0;
    }
    else
      on = 0;

    // 3.2.7. ��ġ�ϸ� D�� Ȯ��
    if (on) {
      Scale_D = (float)( (buf[23]&127)*256 + buf[24] );
      if (buf[23]&128 > 0) Scale_D *= -1;
      Scale_D = pow(10.0, Scale_D);
    }

    // 3.3. Section-2 (GDS)
    if (GB >= 10) {
      fread(buf, 1, 3, fp);
      length = (buf[0]*256 + buf[1])*256 + buf[2];

      if (on) {
        fread(buf, 1, length-3, fp);

        // 3.3.1. ���� ũ�� Ȯ��
        var.nx = buf[3]*256 + buf[4];
        var.ny = buf[5]*256 + buf[6];
        vars[vars_num].nx = var.nx;
        vars[vars_num].ny = var.ny;

        // 3.3.2. �ڷ� ���� ���� Ȯ��
        strcpy(vars[vars_num].scan, "000");
        if (buf[24] & 128) vars[vars_num].scan[0] = '1';
        if (buf[24] & 64)  vars[vars_num].scan[1] = '1';
        if (buf[24] & 32)  vars[vars_num].scan[2] = '1';
      }
      else
        fseek(fp, (long)(length-3), SEEK_CUR);
    }

    // 3.4. Section-3 (BMS)
    if (GB % 10 == 0)
      on_bit = 0;
    else {
      fread(buf, 1, 6, fp);
      length = (buf[0]*256 + buf[1])*256 + buf[2];

      if (on) {
        fread(bit_map, 1, length-6, fp);
        on_bit = 1;
        var.num_bit += 1;
      }
      else
        fseek(fp, (long)(length-6), SEEK_CUR);
    }

    // 3.5. Section-4 (BDS)
    fread(buf, 1, 11, fp);
    length = (buf[0]*256 + buf[1])*256 + buf[2];

    if (on) {
      // 3.5.1. E �� Ȯ��
      Scale_E = (buf[4]&127)*256 + buf[5];
      if ((buf[4]&128) > 0) Scale_E *= -1;
      Scale_E = pow(2.0, Scale_E);

      // 3.5.2. R �� Ȯ��
      A = buf[6]&127;
      B = (buf[7]*256 + buf[8])*256 + buf[9];
      Refv_R = (float)( pow(2,-24) * B * pow(16,(A-64)) );
      if ((buf[6] & 128) > 0) Refv_R *= -1.0;

      // 3.5.3. ���� BIT�� Ȯ��
      num_bits = buf[10];
    }
    else
      fseek(fp, (long)(length-11), SEEK_CUR);

    // 3.5.4. �ڷ� ����
    if (on) {
      vars[vars_num].buf = (float *)malloc((unsigned) (vars[vars_num].ny*vars[vars_num].nx)*sizeof(float));
      fread(buf, 1, length-11, fp);

      sbyte = 0;
      sbit = 8;

      k1 = 0;
      k2 = 0;

      for (i = 1; i <= vars[vars_num].ny*vars[vars_num].nx; i++) {
        if (on_bit) {
          if (k1 == 0) getbits(bit_map[k2], bit_code);
          if (bit_code[k1] == '1')
            on_data = 1;
          else
            on_data = 0;
          k1++;

          if (k1 == 8) {
            k1 = 0;
            k2++;
          }
        }
        else
          on_data = 1;

        if (on_data) {
          v = bit_decode(buf, &sbyte, &sbit, num_bits);
          d1 = ((float)v * Scale_E + Refv_R) / Scale_D;
        }
        else
          d1 = -99999;
        vars[vars_num].buf[i-1] = d1;
        if (i >= vars[vars_num].ny*vars[vars_num].nx) break;
        if ((length-sbyte) <= 1) break;
      }
      vars[vars_num].ok = 1;
      vars[vars_num].on_bit = on_bit;
      var.num_ok += 1;
    }

    // 3.6. Section-5
    fseek(fp, 4, SEEK_CUR);

    // 3.7. ��� ���θ� �Ǵ�
    if (var.num_vars == var.num_ok) break;
  }
  return 0;
}

/*============================================================================*
 *  �ڷ�κ� �ص�
 *============================================================================*/
int
bit_decode
(
  unsigned char *buf,      /* data */
  int   *sbyte,            /* start byte number */
  int   *sbit,             /* start bit number in 'sbyte' (0~7) */
  int   width              /* width of data (1~) */
)
{
  unsigned char m[9] = {0x00, 0x01, 0x03, 0x07, 0x0F, 0x1F, 0x3F, 0x7F, 0xFF};
  int  s[9] = {0, 2, 4, 8, 16, 32, 64, 128, 256};
  unsigned char q;
  unsigned char v1;
  int  v = 0, w1;

  if (*sbyte < 0 || *sbit < 1 || *sbit > 8 || width < 0) return -99999;
  if (width == 0) return 0;

  while (width > 0) {
    q = buf[*sbyte];
    v1 = q & m[*sbit];
    w1 = *sbit - width;

    if (w1 <= 0) {
      w1 = *sbit;
      v = v*s[w1] + v1;
      width -= w1;
      *sbyte += 1;
      *sbit = 8;
    }
    else {
      v1 = v1 >> w1;
      v = v*s[width] + v1;
      *sbit -= width;
      width = 0;
    }
  }
  return v;
}

