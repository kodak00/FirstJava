/*******************************************************************************
**
**  URL �Լ� �̿��� ���� ��ġ�� GRIB ���� �ص� �� ���� CGI ���α׷�
**     o ��� : ��ǥ�ð�, �����ð�, ����, ������ ���� ������ �����ڷ�
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2013.08.24)
**
********************************************************************************/
#include "nwp_grib.h"
#include "nwp_grib_xy.h"

struct INPUT_VAR var;
struct VAR_DATA  vars[3];
float  *dg;
struct timeval tv1, tv2;

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main() {
  int    err;

  // 1. ��� �ʱ�ȭ
  gettimeofday(&tv1, NULL);
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(30);

  printf("HTTP/1.0 200 OK\n");
  printf("Server: Netscape-Enterprise/3.0\n");
  if (var.disp == 'B')
    printf("Content-type: application/octet-stream\n\n");
  else
    printf("Content-type: text/plain\n\n");

  // 2. ����� �Է� ���� Ȯ��
  if ( (err = user_input()) < 0 ) {
    print_error(err);
    exit(err);
  }

  // 3. ���� �����Ҵ� (�뷫������ ����� �޸� ������ ������ ���´�)
  dg = (float *)malloc((unsigned) (1500*1500+1500*2)*sizeof(float));

  // 4. ���� �����ڷ� ����
  if ( (err = nwp_grb1_xy()) < 0 ) {
    print_error(err);
    exit(err);
  }

  // 5. �ڷ� ���
  nwp_grib_xy_txt();

  // 6. ���� ����
  free((char*) dg);
  alarm(0);

  return 0;
}

/*******************************************************************************
 *
 *  ��� ǥ�� (�����ڷ�)
 *
 *******************************************************************************/
int nwp_grib_xy_txt() {
  int    nx, ny;
  int    i, j;

  gettimeofday(&tv2, NULL);

  // 1. ���ú�
  if (var.disp == 'A')
    printf("# �ڷ�ó�� �ҿ�ð� = %f\n", (double)((tv2.tv_sec-tv1.tv_sec)*1000000+(tv2.tv_usec-tv1.tv_usec))/1000000.0);

  // 2. ������ ��
  nx = var.x_max - var.x_min + 1;
  ny = var.y_max - var.y_min + 1;

  if (var.disp == 'B') {
    fwrite(&nx, 4, 1, stdout);
    fwrite(&ny, 4, 1, stdout);
  }
  else
    printf("%8d %8d\n", nx, ny);

  // 3. �������� ��
  if (var.disp == 'B')
    fwrite(dg, 4, nx*ny, stdout);
  else {
    for (j = 1; j <= ny; j++) {
      for (i = 1; i <= nx; i++, dg++) {
        printf("%12.5e ", *dg);
        if (i % 10 == 0) printf("\n");
      }
      if (nx % 10 != 0) printf("\n");
    }
  }

  gettimeofday(&tv2, NULL);
  if (var.disp == 'A')
    printf("# �ڷ� ǥ��ð� ���� �ҿ�ð� = %f\n", (double)((tv2.tv_sec-tv1.tv_sec)*1000000+(tv2.tv_usec-tv1.tv_usec))/1000000.0);
  return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
  char  *qs_org, qs[400];
  char  tmp[256], item[120], value[120], tmfc[30], tmef[30], level[30], sub[30];
  char  lvl_lst[500];
  float lvl[500], lvl1;
  int   varn[10];
  int   iYY, iMM, iDD, iHH, iMI, iSS;
  int   seq, iseq, seq_fc, seq_ef;
  int   i, j, k;

  // 1. ���� �ʱ�ȭ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(level, "");
  strcpy(tmfc, "");
  strcpy(tmef, "");
  var.hf = 0;

  strcpy(var.group, "");
  strcpy(var.nwp, "");
  var.data  = 'P';
  var.member = -1;
  var.varn  = -1;
  var.level = -1;
  var.x_min = -1;
  var.y_min = -1;
  var.x_max = -1;
  var.y_max = -1;
  var.map   = 'F';
  var.sm    = 0;
  var.lon1  = -99999;
  var.lat1  = -99999;
  var.x1    = -99999;
  var.y1    = -99999;
  var.lon2  = -99999;
  var.lat2  = -99999;
  var.x2    = -99999;
  var.y2    = -99999;
  var.disp  = 'A';
  var.help  = 0;
  var.num_ok  = 0;
  var.num_bit = 0;
  var.num_lvl = -1;
  strcpy(sub, "");

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs_org = getenv ("QUERY_STRING");
  if (qs_org == NULL) return -1;
  strcpy(qs, qs_org);

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"group" )) strcpy(var.group, value);
    else if ( !strcmp(item,"nwp"   )) strcpy(var.nwp, value);
    else if ( !strcmp(item,"data"  )) var.data = value[0];
    else if ( !strcmp(item,"member")) var.member = atoi(value);
    else if ( !strcmp(item,"varn"  )) var.varn = atoi(value);
    else if ( !strcmp(item,"level" )) strcpy(level, value);
    else if ( !strcmp(item,"map"   )) var.map = value[0];
    else if ( !strcmp(item,"sub"   )) strcpy(var.sub, value);
    else if ( !strcmp(item,"lon1"  )) var.lon1 = atof(value);
    else if ( !strcmp(item,"lat1"  )) var.lat1 = atof(value);
    else if ( !strcmp(item,"lon2"  )) var.lon2 = atof(value);
    else if ( !strcmp(item,"lat2"  )) var.lat2 = atof(value);
    else if ( !strcmp(item,"x1"    )) var.x1 = atof(value);
    else if ( !strcmp(item,"y1"    )) var.y1 = atof(value);
    else if ( !strcmp(item,"x2"    )) var.x2 = atof(value);
    else if ( !strcmp(item,"y2"    )) var.y2 = atof(value);
    else if ( !strcmp(item,"tmfc"  )) strcpy(tmfc, value);
    else if ( !strcmp(item,"tmef"  )) strcpy(tmef, value);
    else if ( !strcmp(item,"hf"    )) var.hf = atoi(value);
    else if ( !strcmp(item,"sm"    )) var.sm = atoi(value);
    else if ( !strcmp(item,"disp"  )) var.disp = value[0];
    else if ( !strcmp(item,"help"  )) var.help = atoi(value);
    else if ( !strcmp(item,"lvl_lst")) strcpy(lvl_lst, value);
  }

  if (var.varn < 0) return -1;
  if (strlen(tmfc) < 10) return -1;
  if (var.disp != 'B') var.disp = 'A';

  // 3. ��ǥ�ð� Ȯ��
  strncpy(tmp, &tmfc[0], 4);  tmp[4] = '\0';  var.tmfc.YY = atoi(tmp);
  strncpy(tmp, &tmfc[4], 2);  tmp[2] = '\0';  var.tmfc.MM = atoi(tmp);
  strncpy(tmp, &tmfc[6], 2);  tmp[2] = '\0';  var.tmfc.DD = atoi(tmp);
  strncpy(tmp, &tmfc[8], 2);  tmp[2] = '\0';  var.tmfc.HH = atoi(tmp);
  var.tmfc.MI = 0;
  var.tmfc.seq = time2seq(var.tmfc.YY, var.tmfc.MM, var.tmfc.DD, var.tmfc.HH, var.tmfc.MI, 'm');

  // 4. �����ð� Ȯ��
  var.tmef.seq = var.tmfc.seq + var.hf*60;
  seq2time(var.tmef.seq, &(var.tmef.YY), &(var.tmef.MM), &(var.tmef.DD), &(var.tmef.HH), &(var.tmef.MI), 'm', 'n');

  // 5. ���ϸ��� ����ũ��
  var.fsize = nwp_grb1_fname(var.group, var.nwp, var.data, var.tmfc.seq, var.tmef.seq, var.fname);
  //printf("#%s (%d bytes)\n", var.fname, var.fsize);
  if (var.fsize <= 0) return var.fsize;

  // 6. �ܸ鵵�� ���, ���� ��� Ȯ��
  if (strlen(lvl_lst) != 0) {
    for (i = 0; lvl_lst[0] != '\0'; i++) {
      getword(tmp, lvl_lst, ',');
      var.lvl_lst[i] = atoi(tmp);
    }
    var.num_lvl = i;
  }

  // 7. ���� Ȯ�� (������ ��� 2�� ��, ���������� �ټ��� ��)
  if (strlen(level) > 0) {
    for (i = 0; level[0] != '\0'; i++) {
      getword (tmp, level, ',');
      lvl[i] = atof(tmp);
      if (i >= 499) break;
    }
    var.num_level = i;

    if (var.num_level > 1) {
      for (i = 0; i < var.num_level; i++) {
          for (j = i+1; j < var.num_level; j++) {
              if (lvl[i] > lvl[j]) {
                  lvl1 = lvl[i];
                  lvl[i] = lvl[j];
                  lvl[j] = lvl1;
              }
          }
      }
    }
  }
  else {
    var.num_level = 1;
    lvl[0] = -1;
  }

  // 8. ���� Ȯ�� �� Ȯ��
  switch (var.varn) {
    case 2000:              // ǳ��
    case 2001:              // ǳ��
    case 2012:              // ��� �͵�
    case 2013:              // ��� �߻�
      varn[0] = 2002;     // U-wind
      varn[1] = 2003;     // V-wind
      var.num_varn = 2;
      break;

    case 3012:              // ����
      varn[0] = 3005;     // ����
      var.num_varn = 1;
      break;
  
    case 6:                 // �̽���
    case 1254:              // ����
    case 1000:              // ���
    case 1002:              // ȥ�պ�
      varn[0] = 0;        // ���
      varn[1] = 1001;     // ������(��)
      var.num_varn = 2;
      break;

    default:
      varn[0] = var.varn;
      var.num_varn = 1;
  }

  // 9. ����+���� ���
  for (k = 0, j = 0; j < var.num_varn; j++) {
    for (i = 0; i < var.num_level; i++, k++) {
      vars[k].ok = 0;
      vars[k].varn = varn[j];
      vars[k].level = lvl[i];
      vars[k].Cgrid = 0;
    }
  }
  var.level = vars[0].level;

  // 10. ��ü �ڷ� ���� �� Ȯ��
  var.num_vars = var.num_varn * var.num_level;

  return 0;
}

/*******************************************************************************
 *
 *  ���� ���
 *
 *******************************************************************************/
int print_error(int err)
{
  printf("Content-type: text/plain\n\n");

  if      (err ==  -1) printf("# ERROR : Input variable error<p>\n");
  else if (err == -11) printf("# ERROR : Input variable error (%d)<p>\n", err);
  else if (err == -12) printf("# ERROR : Input variable error (%d)<p>\n", err);
  else if (err == -21) printf("# ERROR : file is not exist (%s)\n", var.fname);
  else if (err == -22) printf("# ERROR : file size is not correct (%s, %d bytes)\n", var.fname, var.fsize);
  else if (err == -23) printf("# ERROR : file is not opened (%s, %d bytes)\n", var.fname, var.fsize);
  else if (err == -24) printf("# ERROR : file is not readed (%s, %d bytes)\n", var.fname, var.fsize);
  else if (err == -25) printf("# ERROR : data is not readed (%s, %d bytes) (%d->%d)\n", var.fname, var.fsize, var.num_vars, var.num_ok);

  printf("# var.varn  = %d\n", var.varn);
  printf("# var.level = %d\n", var.level);
  printf("# var.tmfc  = %04d.%02d.%02d.%02d\n", var.tmfc.YY, var.tmfc.MM, var.tmfc.DD, var.tmfc.HH);
  printf("# var.tmef  = %04d.%02d.%02d.%02d (+%dH)\n", var.tmef.YY, var.tmef.MM, var.tmef.DD, var.tmef.HH, var.hf);
  printf("# var.disp  = %c\n", var.disp);
  printf("# var.help  = %c\n", var.help);

  return 0;
}
