/*******************************************************************************
**
**  URL�Լ��� : �ܸ鰪 �Ǵ� ������ �ܸ鰪 ���� (���Ϻ����� ����)
**
**  [ ��� ]
**     �ܸ����� ��, ����(Pa)
**     �Ϸù�ȣ, ��
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2013.08.28)
**
********************************************************************************/
#include "nwp_grib.h"
#include "nwp_grib_xy.h"

struct INPUT_VAR var;
struct VAR_DATA  vars[3];
struct VAR_XZ_POINTS  um_xz_pts;

float  *dg;
struct timeval tv1, tv2;

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int
main ()
{
    int    err, k;

    //
    // ��� �ʱ�ȭ
    //
    gettimeofday(&tv1, NULL);
    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(30);

    printf("HTTP/1.0 200 OK\n");
    printf("Server: Netscape-Enterprise/3.0\n");
    printf("Content-type: text/plain\n\n");

    //
    // ����� �Է� ���� Ȯ��
    //
    if ( (err = user_input()) < 0 )
    {
        print_error(err);
        exit(err);
    }

    //
    // ���� ���� ����� Ȯ��
    //
    if (var.varn == 3012)
    {
        var.num_lvl = 1;
    }
    else if (var.num_lvl <= 0)
    {
        um_level_lst();
    }

    //
    // �ܸ鼱 ���� �ܸ����� ��ġ ���
    //
    xz_points();

    //
    // �ܸ鵵�ڷ� ó��
    //
    for (k = 0; k < var.num_lvl; k++)
    {
        if (var.varn != 3012)       // ���İ� �ƴϸ�
        {
            var.level = var.lvl_lst[k];
            vars[0].level = var.level;
        }

        //
        // 2���� �����ڷ� ����
        //
        if ( (err = um_grib_xy()) < 0 )
        {
            print_error(err);
            exit(err);
        }

        //
        // �ܸ��������� ���� ���� �� �ڷ� ���
        //
        um_grib_xz_txt();
    }

    gettimeofday(&tv2, NULL);
    if (var.disp == 'A')
    {
        printf("# �ڷ� ǥ��ð� ���� �ҿ�ð� = %f\n", (double)((tv2.tv_sec-tv1.tv_sec)*1000000+(tv2.tv_usec-tv1.tv_usec))/1000000.0);
    }

    alarm(0);

    return 0;
}

/*******************************************************************************
 *
 *  UM�𵨺� �������� ���浵 -> ���� ��ȯ
 *
 *******************************************************************************/
int
um_level_lst()
{
    FILE  *fp;
    int   fsize;
    unsigned long total_length = 0;
    unsigned char buf[MAX_BUF];
    int   length, varn, level, err;
    int   i, k = 0;

    if ( (err = um_grib_fname()) < 0 ) return err;

    fp = fopen(var.fname, "rb");
    if (fp == NULL) return -23;

    fsize = var.fsize;
    total_length = 0;

    while ((fsize -= total_length) > 0)
    {
        // Section-0
        if (fread(buf, 1, 8, fp) <= 0) return -24;
        varn = buf[6]*100000;
        fread(buf, 1, 8, fp);

        for (total_length = 0, i = 0; i < 8; i++)
            total_length = total_length*256 + (unsigned long)buf[i];

        // Section-1
        fread(buf, 1, 4, fp);
        length = ((buf[0]*256 + buf[1])*256 + buf[2])*256 + buf[3];
        fseek(fp, (long)(length-4), SEEK_CUR);

        // Section-2
        fread(buf, 1, 4, fp);
        length = ((buf[0]*256 + buf[1])*256 + buf[2])*256 + buf[3];
        fseek(fp, (long)(length-4), SEEK_CUR);

        // Section-3
        fread(buf, 1, 4, fp);
        length = ((buf[0]*256 + buf[1])*256 + buf[2])*256 + buf[3];
        fread(buf, 1, length-4, fp);

        // Section-4 (�ش� �ڷ����� Ȯ��)
        fread(buf, 1, 4, fp);
        length = ((buf[0]*256 + buf[1])*256 + buf[2])*256 + buf[3];
        fread(buf, 1, length-4, fp);
        varn += buf[5]*1000 + buf[6];
        level = (buf[21]*256 + buf[22])*256 + buf[23];

        if (var.varn == varn)
        {
            var.lvl_lst[k] = level;
            k++;
        }

        // Section-5
        fread(buf, 1, 11, fp);
        length = ((buf[0]*256 + buf[1])*256 + buf[2])*256 + buf[3];
        fseek(fp, (long)(length-11), SEEK_CUR);

        // Section-6
        fread(buf, 1, 6, fp);
        length = ((buf[0]*256 + buf[1])*256 + buf[2])*256 + buf[3];
        fseek(fp, (long)(length-6), SEEK_CUR);

        // Section-7
        fread(buf, 1, 5, fp);
        length = ((buf[0]*256 + buf[1])*256 + buf[2])*256 + buf[3];
        fseek(fp, (long)(length-5), SEEK_CUR);

        // Section-8
        fseek(fp, 4, SEEK_CUR);
    }
    var.num_lvl = k;
    fclose(fp);

    return 0;
}

/*******************************************************************************
 *
 *  UM�𵨺� �������� ���浵 -> ���� ��ȯ
 *
 *******************************************************************************/
int
um_pnt_map_conv
(
    float lon,
    float lat,
    float *x,
    float *y
)
{
    struct lamc_parameter  map;
    float  x1, y1;

    if (strcmp(var.group,"UMGL") == 0)
    {
        if (lon < 0) lon += 360;
        *x = lon / (360.0/var.nx);
        *y = (lat + 90) / (180.0/(var.ny-1));
    }
    else if (strcmp(var.group,"UMRG") == 0)
    {
        //
        //  ���� ����
        //
        map.Re    = 6371.00877;
        map.grid  = 12.0;
        map.slat1 = 30.0;
        map.slat2 = 60.0;
        map.olon  = 126.0;
        map.olat  = 38.0;
        map.xo = 246.144823;
        map.yo = 210.123204;
        map.first = 0;

        //
        //  ��ȯ
        //
        lamcproj(&lon, &lat, &x1, &y1, 0, &map);

        *x = x1;
        *y = y1;
    }
    else if (strcmp(var.group,"UMKR") == 0)
    {
        //
        //  ���� ����
        //
        map.Re    = 6371.00877;
        map.grid  = 1.5;
        map.slat1 = 30.0;
        map.slat2 = 60.0;
        map.olon  = 126.0;
        map.olat  = 38.0;
        map.xo = 259.652595;
        map.yo = 412.242644;
        map.first = 0;

        //
        //  ��ȯ
        //
        lamcproj(&lon, &lat, &x1, &y1, 0, &map);

        *x = x1;
        *y = y1;
    }
    return 0;
}

/*******************************************************************************
 *
 *  �ܸ鼱 ���� �ܸ����� ��ġ ���
 *
 *******************************************************************************/
int
xz_points()
{
    float len, dd, x, y;
    int   nd, on = 1;
    int   i;

    //
    // �Է��� ���浵����, (X,Y)���� �Ǵ�
    //
    if (var.x1 < -9000 || var.y1 < -90000 || var.x2 < -9000 || var.y2 < -9000)
    {
        if (var.lon1 < -180 || var.lon1 > 180 || var.lat1 < -90 || var.lat1 > 90 ||
            var.lon2 < -180 || var.lon2 > 180 || var.lat2 < -90 || var.lat2 > 90)
            return -1;
        else
            on = 0;
    }

    //
    // ���浵�� ���, (X,Y)�� ��ȯ
    //
    if (on == 0)
    {
        um_pnt_map_conv(var.lon1, var.lat1, &(var.x1), &(var.y1));
        um_pnt_map_conv(var.lon2, var.lat2, &(var.x2), &(var.y2));
    }

    //
    // ���鰣�� ����(km) ����
    //
    if (strcmp(var.group, "UMGL") == 0)
    {
        dd = 20;
    }
    else if (strcmp(var.group, "UMRG") == 0)
    {
        dd = 10;
    }
    else if (strcmp(var.group, "UMKR") == 0)
    {
        dd = 1.0;
    }

    //
    // (X1,Y1)~(X2,Y2)���� ���� ����
    //
    len = sqrt( (var.x2-var.x1)*(var.x2-var.x1) + (var.y2-var.y1)*(var.y2-var.y1) );
    nd = (int)(len / dd) + 1;
    um_xz_pts.num_total = nd;

    for (i = 0; i <= nd; i++)
    {
        um_xz_pts.pts[i].x = (var.x2 - var.x1) * i / nd + var.x1;
        um_xz_pts.pts[i].y = (var.y2 - var.y1) * i / nd + var.y1;
    }

    return 0;
}

/*******************************************************************************
 *
 *  ��� ǥ�� (�ܸ鵵�ڷ�)
 *
 *******************************************************************************/
int
um_grib_xz_txt()
{
    float  *p1, *p2;
    float  v, v1, v2;
    float  x, y, dx, dy;
    int    i, j, k;

    printf("%4d, %8d\n", um_xz_pts.num_total+1, var.level);

    for (k = 0; k <= um_xz_pts.num_total; k++)
    {
        x = (var.x2 - var.x1) * k / um_xz_pts.num_total + var.x1;
        y = (var.y2 - var.y1) * k / um_xz_pts.num_total + var.y1;

        i = (int)x;
        j = (int)y;

        dx = x - i;
        dy = y - j;

        p1 = dg + var.nx*j + i;
        p2 = p1 + var.nx;

        v1 = (*p1)*(1-x+i) + (*(p1+1))*(x-i);
        v2 = (*p2)*(1-x+i) + (*(p2+1))*(x-i);

        v = v1*(1-y+j) + v2*(y-j);
        printf("%4d, %12.5e\n", k, v);
    }
    return 0;
}
