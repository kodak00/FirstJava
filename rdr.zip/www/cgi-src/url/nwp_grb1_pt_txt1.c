/*******************************************************************************
**
**  URL �Լ� �̿��� ���� ��ġ�� GRIB ���� �ص� �� ���� CGI ���α׷�
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2013.08.28)
**
********************************************************************************/
#include "nwp_grib.h"
#include "nwp_grb1_pt.h"

struct INPUT_VAR var;
struct timeval tv1, tv2;

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main() {
    int    err;

    // 1. ��� �ʱ�ȭ
    gettimeofday(&tv1, NULL);
    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(30);

    printf("HTTP/1.0 200 OK\n");
    printf("Server: Netscape-Enterprise/3.0\n");
    printf("Content-type: text/plain\n\n");
    printf("#START7777\n");

    // 2. ����� �Է� ���� Ȯ��
    if ( (err = user_input()) < 0 ) {
        print_error(err);
        exit(err);
    }

    // 3. �ڷ�ó�� �� ���
    disp_help();

    if ( (err = nwp_grb1_pt_data()) < 0 ) {
        print_error(err);
        exit(err);
    }

    // 4. ó���ҿ�ð� Ȯ��
    gettimeofday(&tv2, NULL);
    printf("# �ڷ� ǥ��ð� ���� �ҿ�ð� = %f\n", (double)((tv2.tv_sec-tv1.tv_sec)*1000000+(tv2.tv_usec-tv1.tv_usec))/1000000.0);
    printf("#7777END\n");

    alarm(0);

    return 0;
}

int disp_help() {
    printf("#---------------------------------------------------------------------------------------\n");
    printf("#  TMFC  : ���ؽð� ����Ͻ� (UTC)                                                      \n");
    printf("#  TMEF  : �����ð� ����Ͻ� (UTC)                                                      \n");
    printf("#  VARN  : ������ȣ                                                                     \n");
    printf("#  LEVEL : ���� (Pa)                                                                    \n");
    printf("#  VALUS : ��                                                                           \n");
    printf("#---------------------------------------------------------------------------------------\n");
    printf("#     TMFC       TMEF     VARN    LEVEL        VALUS                                    \n");
    printf("#1234567891---------2---------3---------4---------5---------6---------7---------8-------\n");
    return 0;
}

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
    struct lamc_parameter  map;
    char   *qs;
    char   item[32], value[256], str_var[256], str_lvl[256], tmp[256], tmfc[30], tmef[30];
    float  v1, lon, lat, x1, y1;
    int    iYY, iMM, iDD, iHH, iMI, iSS;
    int    seq, iseq;
    int    i, j, k;

    // 1. ���� �ʱ�ȭ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
    strcpy(var.group, "");
    strcpy(var.nwp, "");
    var.data  = 'P';
    var.member = -1;
    strcpy(tmfc, "");
    strcpy(tmef, "");
    var.hf = -1;
    var.num_ok  = 0;
    var.num_bit = 0;
    var.lon = -99999;
    var.lat = -99999;
    var.gl = 0;
    var.disp  = 'A';
    var.help  = 0;
    strcpy(str_var, "");
    strcpy(str_lvl, "");

    // 2. GET ������� ���޵� ����� �Էº������� �ص�
    qs = getenv("QUERY_STRING");
    if (qs == NULL) return -1;

    for (i = 0; qs[0] != '\0'; i++)
    {
        getword(value, qs, '&');
        getword(item, value, '=');

        if      ( !strcmp(item,"group" )) strcpy(var.group, value);
        else if ( !strcmp(item,"nwp"   )) strcpy(var.nwp, value);
        else if ( !strcmp(item,"data"  )) var.data = value[0];
        else if ( !strcmp(item,"member")) var.member = atoi(value);
        else if ( !strcmp(item,"varn"  )) strcpy(str_var, value);
        else if ( !strcmp(item,"level" )) strcpy(str_lvl, value);
        else if ( !strcmp(item,"lon"   )) var.lon = atof(value);
        else if ( !strcmp(item,"lat"   )) var.lat = atof(value);
        else if ( !strcmp(item,"X"     )) var.X = atoi(value);
        else if ( !strcmp(item,"Y"     )) var.Y = atoi(value);
        else if ( !strcmp(item,"tmfc"  )) strcpy(tmfc, value);
        else if ( !strcmp(item,"tmef"  )) strcpy(tmef, value);
        else if ( !strcmp(item,"hf"    )) var.hf = atoi(value);
        else if ( !strcmp(item,"disp"  )) var.disp = value[0];
        else if ( !strcmp(item,"help"  )) var.help = atoi(value);
    }
    if (strlen(tmfc) < 10) return -2;

    // 3. ��ǥ�ð� Ȯ��
    strncpy(tmp, &tmfc[0], 4);  tmp[4] = '\0';  var.tmfc.YY = atoi(tmp);
    strncpy(tmp, &tmfc[4], 2);  tmp[2] = '\0';  var.tmfc.MM = atoi(tmp);
    strncpy(tmp, &tmfc[6], 2);  tmp[2] = '\0';  var.tmfc.DD = atoi(tmp);
    strncpy(tmp, &tmfc[8], 2);  tmp[2] = '\0';  var.tmfc.HH = atoi(tmp);
    var.tmfc.MI = 0;
    var.tmfc.seq = time2seq(var.tmfc.YY, var.tmfc.MM, var.tmfc.DD, var.tmfc.HH, var.tmfc.MI, 'm');

    // 4. �����ð� Ȯ��
    if (var.hf >= 0) {
        var.tmef.seq = var.tmfc.seq + var.hf*60;
        seq2time(var.tmef.seq, &(var.tmef.YY), &(var.tmef.MM), &(var.tmef.DD), &(var.tmef.HH), &(var.tmef.MI), 'm', 'n');
    }
    else
        var.tmef.seq = -1;

    // 5. ���ϸ��� ����ũ��
    var.fsize = nwp_grb1_fname(var.group, var.nwp, var.data, var.tmfc.seq, var.tmef.seq, var.fname);
    if (var.fsize <= 0) return var.fsize;
    printf("#%s (%d bytes)\n", var.fname, var.fsize);

    // 6. ���� Ȯ��
    printf("#var(%s) : ", str_var);
    if (strlen(str_var) > 0) {
        for (i = 0; str_var[0] != '\0'; i++) {
            getword(tmp, str_var, ',');
            var.varn[i] = atoi(tmp);
            printf("%d,", var.varn[i]);
            if (i >= MAX_VARN) break;
        }
        var.num_varn = i;
        printf("(%d)\n", var.num_varn);
    }
    else {
        printf("(%d)\n", var.num_varn);
        return -1;
    }

    // 7. ���� Ȯ��
    printf("#level(%s) : ", str_lvl);
    if (strlen(str_lvl) > 0) {
        for (i = 0; str_lvl[0] != '\0'; i++) {
            getword (tmp, str_lvl, ',');
            var.level[i] = atoi(tmp);
            if (i >= MAX_LEVEL) break;
        }
        var.num_level = i;
        printf("(%d)\n", var.num_level);
    }
    else {
        var.num_level = 0;
        printf("(%d)\n", var.num_level);
    }

    // 8. ó���� GRIB ���� �� �뵵
    var.chk = 0;

    // 9. ���浵�� ��û�� ���, ���� ����� ���� ��ġ ����
    if (var.lon >= -180 && var.lon <= 360 && var.lat >= -90 && var.lat <= 90)
    {
        var.gl = 1;
        // ���浵���� ��ȯ�ϴ� ���� �𵨸��� Ʋ�� (����� �������ٵ� ���ڰ� Ʋ����)
        // ���߿� �����ϱ�� ��
    }
    return 0;
}

/*******************************************************************************
 *
 *  ���� ���
 *
 *******************************************************************************/
int print_error(int err) {
    int  i;

    printf("# ERROR(%d) : ", err);

    switch (err) {
      case  -1: printf("Input variable error");  break;
      case -11: printf("Input variable error");  break;
      case -12: printf("Input variable error");  break;
      case -21: printf("file is not exist(%s)", var.fname);  break;
      case -22: printf("file size is not correct (%s, %d bytes)", var.fname, var.fsize);  break;
      case -23: printf("file is not opened (%s, %d bytes)", var.fname, var.fsize);  break;
      case -24: printf("file is not readed (%s, %d bytes)", var.fname, var.fsize);  break;
      default:  printf("--");
    }
    printf("\n");

    printf("# var.group = %s\n", var.group);
    printf("# var.nwp   = %s\n", var.nwp);
    printf("# var.data  = %c\n", var.data);
    printf("# var.member = %d\n", var.member);
    printf("# var.num_varn = %d\n", var.num_varn);

    if (var.num_varn > 0) {
        printf("# var.varn = ");

        for (i = 0; i < var.num_varn; i++) {
            if (i > 0) printf(",");
            printf("%d", var.varn[i]);
        }
        printf("\n");
    }

    printf("# var.num_level = %d\n", var.num_level);

    if (var.num_level > 0) {
        printf("# var.level = ");

        for (i = 0; i < var.num_level; i++) {
            if (i > 0) printf(",");
            printf("%d", var.level[i]);
        }
        printf("\n");
    }

    printf("# var.tmfc  = %04d.%02d.%02d.%02d\n", var.tmfc.YY, var.tmfc.MM, var.tmfc.DD, var.tmfc.HH);
    printf("# var.tmef  = %04d.%02d.%02d.%02d (+%dH)\n", var.tmef.YY, var.tmef.MM, var.tmef.DD, var.tmef.HH, var.hf);
    printf("# X, Y      = %d, %d\n", var.X, var.Y);
    printf("# var.disp  = %c\n", var.disp);
    printf("# var.help  = %c\n", var.help);

    return 0;
}
