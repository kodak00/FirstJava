/*******************************************************************************
**
**  GTS ���� �����ص��ڷῡ�� �� �ڷ���� �Ի��Ͽ� �߰��ϰ� ������ Ȯ��
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.9.27)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>

#include "cgiutil.h"
#include "nrutil.h"
#include "map_ini.h"
#include "url_io.h"

#define  DEGRAD   3.1415927/180.0
#define  RADDEG   180.0/3.1415927
#define  MAX_DATA 1000

//------------------------------------------------------------------------------
// ����� �Է� ����
struct INPUT_VAR {
  int   seq_now;      // ����ð� SEQ(��)
  int   seq;          // �����ð� SEQ(��) UTC
  int   stn_id;       // GTS ������ȣ
  float pa_itv;       // Ȯ���� ��� ����(hPa)
  int   mode;         // ó�� ���
                      // (0:���� �״��, 1:������ ������ ���� ���,
                      //  2:Ȯ���� ��а��ݰ� ���� ������� ���̰� 10% �̳��̸� Ȯ������ ����
                      //  3:ȭ���� ��а����� ���� ������ �߰���)
  int   num_obs;      // ������ ����
  int   num_data;     // Ȯ���� ������ �ڷ� ����
  char  disp;         // A(ASCII), B(����), C(csv)
} var;

// Ȯ���� �����ڷ�
struct STN_DATA_EXT {
  int   seq;  // UTC
  float pa;   // ���(hPa)
  float gh;   // ����(m)
  float ta;   // ���(C)
  float td;   // �̽����µ�(C)
  float wd;   // ǳ��(degree)
  float ws;   // ǳ��(m/s)
  float hm;   // ������(%)
  float ev;   // �������(0.01*hPa)
  float sh;   // ���(g/kg)
  float tv;   // ���µ�(C)
  float ht;   // �м��� GH(m)
  char  flag[10];
} data[MAX_DATA];

// �Լ� ����
float  vapor_pressure(float);
double hydrof1d(double, double, double);

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main()
{
  // 1. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(30);

  printf("HTTP/1.0 200 OK\n");
  printf("Content-type: text/plain\n\n");

  // 2. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    printf("# ����� �Էº��� ����\n");
    return -1;
  }
  printf("#START7777\n");
  printf("#--------------------------------------------------------------------------------------------------\n");
  printf("#  1. TIME : �����ð� (UTC)\n");
  printf("#  2. STN  : GTS ������ȣ\n");
  printf("#  3. PA   : ��� (hPa)\n");
  printf("#  4. GH   : ���հ��� (m)\n");
  printf("#  5. TA   : ��� (C)\n");
  printf("#  6. TD   : �̽����µ� (C)\n");
  printf("#  7. WD   : ǳ�� (degree)\n");
  printf("#  8. WS   : ǳ�� (m/s)\n");
  printf("#  9. HM   : ���� ������ (%)\n");
  printf("# 10. EV   : ���� ������� (hPa)\n");
  printf("# 11. SH   : ���� ��� (g/kg)\n");
  printf("# 12. TV   : ���� ���µ� (C)\n");
  printf("#  *) F�� ������ �ִ� ���̸� 1, ���� ���̸� 0\n");
  printf("#--------------------------------------------------------------------------------------------------\n");

  // 3. ���������ڷḦ �д´�.
  gts_temp_get();

  // 4. 10hPa�������� Ȯ���ϰ� �������� �����Ѵ�.
  gts_temp_ext();

  // 5. �߰� ���������� ����Ѵ�.
  gts_temp_humi_calc();

  // 6. ������ �����Ŀ� ���� ������ ����
  gts_temp_gh_calc();

  // 9. ���
  gts_temp_ext_print();
  printf("#7777END\n");
  return 0;
}

/*******************************************************************************
 *  ����� ��û �м� �κ�
 *******************************************************************************/
int user_input()
{
  char *qs;
  char tmp[256], item[32], value[32], tm[30];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, i, j;

  // 1. ���� �ʱⰪ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "0");
  var.mode = 2;
  var.pa_itv = 10;

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"tm")) strcpy(tm, value);
    else if ( !strcmp(item,"stn")) var.stn_id = atoi(value);
    else if ( !strcmp(item,"pa_itv")) var.pa_itv = atof(value);
    else if ( !strcmp(item,"mode")) var.mode = atoi(value);
    else if ( !strcmp(item,"disp")) var.disp = value[0];
  }

  // 3. �⺻�� ����
  if (var.pa_itv <= 0.01) var.pa_itv = 10;

  // 4. ����ð� �� ���� �����ð� ����
  get_time(&iYY, &iMM, &iDD, &iHH, &iMI, &iSS);
  iseq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  var.seq_now = iseq;

  // 5. ��û�ð� ����
  if (strlen(tm) < 10)
    var.seq = iseq;
  else {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
    var.seq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  }
  return 0;
}

/*******************************************************************************
 *  �����ڷ� �б�
 *******************************************************************************/
int gts_temp_get()
{
  URL_FILE *fr; 
  char   buf[1000], url[100], tmp[100], tm[32];
  float  pa, gh, ta, td, wd, ws;
  int    stn_id1;
  int    num_pnt = 0;
  int    YY, MM, DD, HH, MI;
  int    k;

  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(url, "http://172.20.134.91/url/gts_temp.php?tm=%04d%02d%02d%02d%02d&stn=%d&pa=0&help=0",
          YY, MM, DD, HH, MI, var.stn_id);
  if ((fr = url_fopen(url, "r")) == NULL) {
    printf("# �����ڷ� URL-API OPEN ERROR (%s)\n", url);
    return -1;
  }
  //printf("# %s\n", url);

  var.num_data = 0;
  while (!url_feof(fr)) {
    url_fgets(buf, sizeof(buf), fr);
    if (buf[0] == '#') continue;

    sscanf(buf,"%s %d %f %f %f %f %f %f", tm, &stn_id1, &pa, &gh, &ta, &td, &wd, &ws);
    strncpy(tmp, &tm[0], 4);  tmp[4]='\0';  YY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2]='\0';  MM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2]='\0';  DD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2]='\0';  HH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2]='\0';  MI = atoi(tmp);

    data[var.num_data].seq = time2seq(YY, MM, DD, HH, MI, 'm') + 9*60;
    data[var.num_data].pa = pa;

    // URL-API�� �ݿ��Ǿ�� ����
    //if (pa > 980) {
    //  if (gh >= 500)
    //    gh = -1*(gh-500);
    //  else if (gh >= 400)
    //    gh = gh - 500;
    //}

    data[var.num_data].gh = gh;
    data[var.num_data].ta = ta;
    data[var.num_data].td = td;
    data[var.num_data].wd = wd;
    data[var.num_data].ws = ws;
    strcpy(data[var.num_data].flag,"0000000000");

    if (data[var.num_data].gh > -90) data[var.num_data].flag[0] = '1';
    if (data[var.num_data].ta > -90) data[var.num_data].flag[1] = '1';
    if (data[var.num_data].td > -90) data[var.num_data].flag[2] = '1';
    if (data[var.num_data].wd > -90) data[var.num_data].flag[3] = '1';
    if (data[var.num_data].ws > -90) data[var.num_data].flag[4] = '1';

    var.num_data++;
  }
  url_fclose(fr);
  var.num_obs = var.num_data;
  printf("# �������� ���� ���� num_obs = %d\n", var.num_obs);
  return 0;
}

/*******************************************************************************
 *  �����ڷ� Ȯ�� (10hPa�������� �߰� Ȯ��)
 *******************************************************************************/
int gts_temp_ext()
{
  struct STN_DATA_EXT data1;
  int  itv_pa;
  int  pa1 = 10*(int)(data[0].pa*10)/10;   // �߰������ �߿��� ������ ��� (0.1hPa)
  int  pa2 = (int)(data[var.num_data-1].pa*10);   // �߰�����߿��� �ְ��� ���
  int  num_data = var.num_data, obs_num;
  int  ipa, ox, i, j, k;

  // Ȯ��
  if (var.mode >= 2) {
    itv_pa = (int)(10.0*var.pa_itv);

    for (ipa = pa1; ipa >= pa2; ipa -= itv_pa) {
      for (ox = 0, k = 0; k < num_data; k++) {
        if (var.mode == 2) {
          if (fabs(ipa - (int)(data[k].pa*10)) <= itv_pa*0.1) {
            ox = 1;
            break;
          }
        }
        else if (var.mode == 3) {
          if (ipa == (int)(data[k].pa*10)) {
            ox = 1;
            break;
          }
        }
      }

      if (ox == 0) {
        data[var.num_data].pa = 0.1*ipa;
        data[var.num_data].gh = -999;
        data[var.num_data].ta = -999;
        data[var.num_data].td = -999;
        data[var.num_data].wd = -999;
        data[var.num_data].ws = -999;
        strcpy(data[var.num_data].flag,"0000000000");
        var.num_data++;
      }
    }
    printf("# Ȯ�� ��  ���� ���� num_data = %d\n", var.num_data);
  }

  // ����
  for (i = 0; i < var.num_data-1; i++) {
    for (j = i+1; j < var.num_data; j++) {
      if (data[i].pa < data[j].pa) {
        data1 = data[i];
        data[i] = data[j];
        data[j] = data1;
      }
    }
  }

  // �����Ͽ� Ȯ��
  if (var.mode >= 1) {
    liner_interpolation(0);
    liner_interpolation(1);
    liner_interpolation(2);
    liner_interpolation(3);
    liner_interpolation(4);
    //data_obj1d_mq(0);
    //data_obj1d_mq(1);
    //data_obj1d_mq(2);
    //data_obj1d_mq(3);
    //data_obj1d_mq(4);

    // ǳ�� ����
    for (k = 0; k < var.num_data; k++) {
      if (data[k].wd < 0) data[k].wd += 360;
    }
  }
  return 0;
}

/*=============================================================================*
 *   ��������
 *=============================================================================*/
int liner_interpolation(
  int obs_num
)
{
  float wt1, wt2, v1, v2, vv;
  int   i, j, k, m, n, j1, j2;

  // ó���� �ڷᰡ ������, �ܻ������� ó��
  if (data[0].flag[obs_num] == '0') {
    j1 = j2 = -1;
    for (j = 0; j < var.num_data-1; j++) {
      if (data[j].flag[obs_num] == '1') {
        j1 = j;
        break;
      }
    }

    for (j = j1+1; j < var.num_data; j++) {
      if (data[j].flag[obs_num] == '1') {
        j2 = j;
        break;
      }
    }

    if (j1 > 0 && j2 > 0 && j1 < j2) {
      for (j = 0; j < j1; j++) {
        //wt1 = (log10(data[j].pa) - log10(data[j1].pa))/(log10(data[j2].pa) - log10(data[j1].pa));
        wt1 = log10(data[j].pa/data[j1].pa)/log10(data[j2].pa/data[j1].pa);

        if      (obs_num == 0) { v1 = data[j1].gh;  v2 = data[j2].gh; }
        else if (obs_num == 1) { v1 = data[j1].ta;  v2 = data[j2].ta; }
        else if (obs_num == 2) { v1 = data[j1].td;  v2 = data[j2].td; }
        else if (obs_num == 3) { v1 = data[j1].wd;  v2 = data[j2].wd; }
        else if (obs_num == 4) { v1 = data[j1].ws;  v2 = data[j2].ws; }

        vv = wt1*(v2-v1) + v1;

        if      (obs_num == 0) data[j].gh = vv;
        else if (obs_num == 1) data[j].ta = vv;
        else if (obs_num == 2) data[j].td = vv;
        else if (obs_num == 3) data[j].wd = vv;
        else if (obs_num == 4) data[j].ws = vv;
      }
    }
    else
      return -1;
  }

  // ������ ����
  for (j = 0; j < var.num_data-1; j++) {
    if (data[j].flag[obs_num] == '1') {
      for (m = 0, i = j+1; i < var.num_data; i++) {
        if (data[i].flag[obs_num] == '1') {
          if (i-j > 1 && m > 0) {
            for (k = j+1; k <= i-1; k++) {
              //wt1 = (log10(data[k].pa) - log10(data[j].pa))/(log10(data[i].pa) - log10(data[j].pa));
              //wt2 = (log10(data[i].pa) - log10(data[k].pa))/(log10(data[i].pa) - log10(data[j].pa));
              wt1 = log10(data[k].pa/data[j].pa)/log10(data[i].pa/data[j].pa);
              wt2 = log10(data[i].pa/data[k].pa)/log10(data[i].pa/data[j].pa);

              if      (obs_num == 0) data[k].gh = data[j].gh*wt2 + data[i].gh*wt1;
              else if (obs_num == 1) data[k].ta = data[j].ta*wt2 + data[i].ta*wt1;
              else if (obs_num == 2) data[k].td = data[j].td*wt2 + data[i].td*wt1;
              else if (obs_num == 3) data[k].wd = data[j].wd*wt2 + data[i].wd*wt1;
              else if (obs_num == 4) data[k].ws = data[j].ws*wt2 + data[i].ws*wt1;
            }
          }
          break;
        }
        else
          m++;
      }
    }
  }
  return 0;
}

/*******************************************************************************
 *  �߰� ���������� ���
 *******************************************************************************/
int gts_temp_humi_calc()
{
  float ew;
  int   k;

  for (k = 0; k < var.num_data; k++) {
    // 1. ��ȭ������� ���
    if (data[k].ta > -90)
      ew = vapor_pressure(data[k].ta);
    else
      ew = -9;

    // 2. ������� ���
    if (data[k].td > -90)
      data[k].ev = vapor_pressure(data[k].td);
    else
      data[k].ev = -9;

    // 3. ������ ���
    if (ew > 0 && data[k].ev >= 0)
      data[k].hm = 100*data[k].ev/ew;
    else
      data[k].hm = -999;

    // 4. ��� ���
    if (data[k].ev >= 0)
      data[k].sh = 1000*(0.622*data[k].ev)/(data[k].pa - 0.378*data[k].ev);
    else
      data[k].sh = -9;

    // 5. ���µ� ���
    if (data[k].ta > -90) {
      if (data[k].td > -90)
        data[k].tv = data[k].ta/(1.0-0.378*data[k].ev/data[k].pa);
      else
        data[k].tv = data[k].ta;
    }
    else
      data[k].tv = -999;
  }
  return 0;
}

/*=============================================================================*
 *   ������� (�Է�:���(C), ���:�з�(hPa)
 *=============================================================================*/
float vapor_pressure(float ta)
{
  float vp;
  vp = 6.112*exp((17.67*ta)/(ta+243.5));
  return vp;
}

/*******************************************************************************
 *  ������ �����Ŀ� ���� GH ���
 *******************************************************************************/
int gts_temp_gh_calc()
{
  int  seq1, seq2, stn_ht;
  int  mode = 0;
  int  start, k;

  // ���� ��ġ Ȯ��
  for (k = 0; k < var.num_data; k++) {
    data[k].ht = data[k].gh;
    if (data[k].flag[0] == '1' && data[k].tv > -90) {
      start = k;
      break;
    }
  }

  // ���� ��ġ�� ó���� �ƴ� ���, �ܻ����� �տ� ���� ����
  if (start > 0) {
    for (k = start-1; k >= 0; k--) {
      if (data[k].flag[0] == '0') {
        if (data[k+1].ht > -900 && data[k+1].tv > -90 && data[k].tv > -90) {
          data[k].ht = data[k+1].ht + (287.05/9.81)*((data[k+1].tv + data[k].tv)*0.5 + 273.15)*log(data[k+1].pa/data[k].pa);
        }
      }
    }
  }

  // ���� ���� Ȯ��
  if (mode == 0) {
    for (k = start+1; k < var.num_data; k++) {
      if (data[k].flag[0] == '0') {
        if (data[k-1].ht > -900 && data[k-1].tv > -90 && data[k].tv > -90) {
          data[k].ht = data[k-1].ht + (287.05/9.81)*((data[k-1].tv + data[k].tv)*0.5 + 273.15)*log(data[k-1].pa/data[k].pa);
        }
      }
      else
        data[k].ht = data[k].gh;
    }
  }
  else {
    for (k = start+1; k < var.num_data; k++) {
      if (data[k-1].ht > -900 && data[k-1].tv > -90 && data[k].tv > -90) {
        data[k].ht = data[k-1].ht + (287.05/9.81)*((data[k-1].tv + data[k].tv)*0.5 + 273.15)*log(data[k-1].pa/data[k].pa);
        //printf("k = %d, %.1f = %.1f + (%.1f+%.1f)*0.5 + 273.15, log(%.1f/%.1f)\n",
        //  k, data[k].ht, data[k-1].ht, data[k-1].tv, data[k].tv, data[k-1].pa, data[k].pa);
      }
    }
  }

  // ����, ������ ���, �ع߰��� ���� ���� (URL-API���� �ݿ��Ǿ����Ƿ� ����)
  /*
  if (var.stn_id == 47122 || var.stn_id == 47158) {
    if (var.stn_id == 47122) {
      seq1 = time2seq(2017, 10, 29, 0, 'm');
      stn_ht = 52;
    }
    else {
      seq1 = time2seq(2017, 10, 31, 6, 'm');
      stn_ht = 13;
    }
    seq2 = time2seq(2018, 6, 27, 18, 0, 'm');

    if (var.seq >= seq1 && var.seq <= seq2) {
      for (k = 0; k < var.num_data; k++)
        data[k].ht += stn_ht;
    }
  }
  */
  return 0;
}

/*******************************************************************************
 *  ���
 *******************************************************************************/
int gts_temp_ext_print()
{
  int  YY, MM, DD, HH, MI;
  int  k;

  printf("#  TIME(UTC),   STN,      PA,      GH, F,      TA, F,      TD, F,      WD, F,      WS, F,      HM,      EV,      SH,      TV,=\n");
  printf("#YYYMMDDHHMI,    ID,   (hPa),     (m), 1,     (C), 1,     (C), 1,   (deg), 1,   (m/s), 1,     (%),   (hPa),  (g/kg),     (C),=\n");
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  if (var.disp == 'A') {
    for (k = 0; k < var.num_data; k++) {
      printf("%04d%02d%02d%02d%02d, %5d,", YY, MM, DD, HH, MI, var.stn_id);
      printf(" %7.1f,", data[k].pa);
      printf(" %7.1f, %c,", data[k].ht, data[k].flag[0]);
      //printf(" %7.1f, %7.1f,", data[k].gh, data[k].ht-data[k].gh);
      printf(" %7.1f, %c,", data[k].ta, data[k].flag[1]);
      printf(" %7.1f, %c,", data[k].td, data[k].flag[2]);
      printf(" %7.1f, %c,", data[k].wd, data[k].flag[3]);
      printf(" %7.1f, %c,", data[k].ws, data[k].flag[4]);
      printf(" %7.1f,", data[k].hm);
      printf(" %7.3f,", data[k].ev);
      printf(" %7.3f,", data[k].sh);
      printf(" %7.1f,", data[k].tv);
      printf("=\n");
    }
  }
  else {
    for (k = 0; k < var.num_data; k++) {
      printf("%04d%02d%02d%02d%02d,%d,", YY, MM, DD, HH, MI, var.stn_id);
      printf("%.1f,", data[k].pa);
      printf("%.1f,%c,", data[k].ht, data[k].flag[0]);
      //printf(" %7.1f, %7.1f,", data[k].gh, data[k].ht-data[k].gh);
      printf("%.1f,%c,", data[k].ta, data[k].flag[1]);
      printf("%.1f,%c,", data[k].td, data[k].flag[2]);
      printf("%.1f,%c,", data[k].wd, data[k].flag[3]);
      printf("%.1f,%c,", data[k].ws, data[k].flag[4]);
      printf("%.1f,", data[k].hm);
      printf("%.3f,", data[k].ev);
      printf("%.3f,", data[k].sh);
      printf("%.1f,", data[k].tv);
      printf("=\n");
    }
  }
  return 0;
}

/*******************************************************************************
 *
 *  �����м� (MQ ���)
 *
 *******************************************************************************/
int data_obj1d_mq(
  int obs_num
)
{
  double *x, *v, *s, mq_mp = 1.0, mq_sm = 1.0, cc;    // ���� mp=0.0005
  double x1, q1;
  float  data_min, data_max, data_avg, d1;
  int    num_data, num_obs;
  int    i, j, k;

  // 1. �����м� ��� �����鿡�� �ִ�,�ּҰ� Ȯ��
  data_min = 99999;  data_max = -99999;  data_avg = 0;
  for (num_obs = 0, k = 0; k < var.num_data; k++) {
    if      (obs_num == 0) d1 = data[k].gh;
    else if (obs_num == 1) d1 = data[k].ta;
    else if (obs_num == 2) d1 = data[k].td;
    else if (obs_num == 3) d1 = data[k].wd;
    else if (obs_num == 4) d1 = data[k].ws;
    else break;

    if (data[k].flag[obs_num] == '1') {
      if (data_min > d1) data_min = d1;
      if (data_max < d1) data_max = d1;
      data_avg += d1;
      num_obs++;
    }
  }
  data_avg /= (float)num_obs;
  printf("#obs_num = %d, num_obs = %d, min = %f, max = %f, avg = %f\n", obs_num, num_obs, data_min, data_max, data_avg);

  // 2. �ӽù迭����
  x = dvector(0, num_obs);
  v = dvector(0, num_obs);
  s = dvector(0, num_obs);

  // 3. MQ�� �°� ����ȭ�۾� ����
  for (num_data = 0, k = 0; k < var.num_data; k++) {
    if      (obs_num == 0) d1 = data[k].gh;
    else if (obs_num == 1) d1 = data[k].ta;
    else if (obs_num == 2) d1 = data[k].td;
    else if (obs_num == 3) d1 = data[k].wd;
    else if (obs_num == 4) d1 = data[k].ws;
    else break;

    if (data[k].flag[obs_num] == '1') {
      //x[num_data] = data[k].pa/1000.0;
      x[num_data] = log10(data[k].pa)-2.0;
      if (data_max != data_min) {
        v[num_data] = (d1-data_min)/(data_max-data_min);
        s[num_data] = mq_sm*num_obs*(0.1/(data_max-data_min))*(0.1/(data_max-data_min));
      }
      else {
        v[num_data] = d1;
        s[num_data] = mq_sm*num_obs*(0.1*0.1);
      }
      num_data++;
    }
  }

  // 4. �����м��� ���� ���� ���
  mq_mp /= (double)(num_obs*num_obs);
  cc = 1.0/(mq_mp*mq_mp);
  mq_obj1d(x, v, s, cc, num_data);

  // 5. ��ȯ
  for (k = 0; k < var.num_data; k++) {
    if (data[k].flag[obs_num] == '0') {
      //x1 = data[k].pa/1000.0;
      x1 = log10(data[k].pa) - 2.0;

      for (q1 = 0.0, i = 0 ; i < num_data; i++)
        q1 += v[i]*hydrof1d(x1, x[i], cc);
      q1 = q1*(data_max-data_min) + data_min;

      if      (obs_num == 0) data[k].gh = q1;
      else if (obs_num == 1) data[k].ta = q1;
      else if (obs_num == 2) data[k].td = q1;
      else if (obs_num == 3) data[k].wd = q1;
      else if (obs_num == 4) data[k].ws = q1;
      else break;
    }
  }

  // 6. �ӽù迭����
  free_dvector(s, 0, num_obs);
  free_dvector(v, 0, num_obs);
  free_dvector(x, 0, num_obs);

  return 0;
}

/*=============================================================================*
 *  < LU decomposition >    from  Numerical Recips
 *=============================================================================*/
#define TINY 1.0e-20;

int ludcmp(double **a, int n, int *indx, float *d)
{
  int i,imax,j,k;
  double big,dum,sum,temp;
  double *vv;

  vv=dvector(0,n-1);
  *d=1.0;
  for (i=0;i<n;i++) {
    big=0.0;
    for (j=0;j<n;j++)
      if ((temp=fabs(a[i][j])) > big) big=temp;
    if (big == 0.0) printf("Singular matrix in routine LUDCMP");
    vv[i]=1.0/big;
  }
  for (j=0;j<n;j++) {
    for (i=0;i<j;i++) {
      sum=a[i][j];
      for (k=0;k<i;k++) sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
    }
    big=0.0;
    for (i=j;i<n;i++) {
      sum=a[i][j];
      for (k=0;k<j;k++) sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
      if ( (dum=vv[i]*fabs(sum)) >= big) {
        big=dum;
        imax=i;
      }
    }
    if (j != imax) {
      for (k=0;k<n;k++) {
        dum=a[imax][k];
        a[imax][k]=a[j][k];
        a[j][k]=dum;
      }
      *d = -(*d);
      vv[imax]=vv[j];
    }
    indx[j]=imax;
    if (a[j][j] == 0.0) a[j][j]=TINY;
    if (j != n-1) {
      dum=1.0/(a[j][j]);
      for (i=j+1;i<n;i++) a[i][j] *= dum;
    }
  }
  free_dvector(vv,0,n-1);
  return 0;
}

/*=============================================================================*
 *  < A * X = B  calculation >    from  Numerical Recips
 *=============================================================================*/
int lubksb(double **a, int n, int *indx, double b[])
{
  int i,ii=-1,ip,j;
  double sum;

  for (i=0;i<n;i++) {
    ip=indx[i];
    sum=b[ip];
    b[ip]=b[i];
    if (ii >= 0)
      for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
    else if (sum) ii=i;
      b[i]=sum;
  }
  for (i=n-1;i>=0;i--) {
    sum=b[i];
    for (j=i+1;j<n;j++) sum -= a[i][j]*b[j];
    b[i]=sum/a[i][i];
  }
  return 0;
}

/*=============================================================================*
 *  hydroboloid fuction as the basis function for m-q interpolation
 *       - input -
 *           (x1,y1) : Normalized coordinate of pistion 1
 *           (x2,y2) : Normalized coordinate of pistion 2
 *=============================================================================*/
double hydrof1d(double x1, double x2, double cc)
{
  double dx=x2-x1, hf;
  hf = -sqrt( (dx*dx)*cc + 1.0 );
  return hf;
}

/*=============================================================================*
 *   Multi-quadric interpolation
 *
 *       - input -
 *           v(n) : observation value of the stations  (destroyed)
 *           s(n) : smooting value
 *                   ( = n * smooting parameter
 *                         * mean-squared observation error )
 *           cc   : 1/multiquadric parameter^2
 *           num_stn : ������
 *=============================================================================*/
int mq_obj1d(double *x, double *v, double *s, double cc, int num_stn)
{
  double x1, q1, **q;
  float  d;
  int    *indx;
  int    i, j, k;

  // 1. �޸� �Ҵ�
  q = dmatrix(0, num_stn-1, 0, num_stn-1);
  indx = ivector(0, num_stn-1);

  // 2. Q-matrix ���
  for (i = 0; i < num_stn; i++) {
    for (j = i+1; j < num_stn; j++)
      q[i][j] = hydrof1d(x[i], x[j], cc);
  }
  for (i = 1; i < num_stn; i++) {
    for (j = 0; j < i; j++)
      q[i][j] = q[j][i];
  }
  for (i = 0; i < num_stn; i++)   // Smooting parameter
    q[i][i] = -1.0 + s[i];

  // 3. LU decomposition of Q
  ludcmp(q, num_stn, indx, &d);

  // 4. (Invers matrix of Q)*v
  lubksb(q, num_stn, indx, v);

  // 5. �޸� �ݳ�
  free_dmatrix(q,0,num_stn-1,0,num_stn-1);
  free_ivector(indx,0,num_stn-1);

  return 0;
}
