/*******************************************************************************
**
**  URL �Լ� �̿��� ���� ��ġ�� GRIB ���� �ص� �� ���� CGI ���α׷�
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2013.08.28)
**
********************************************************************************/
#include "nwp_grib.h"
#include "nwp_grb1_pt.h"

extern struct INPUT_VAR var;

/*=============================================================================*
 *
 *  �ڷ� �б�
 *
 *=============================================================================*/
int nwp_grb1_pt_data() {
    static FILE  *fp;
    static char  fname[120];
    static int   fsize;
    static unsigned long total_length = 0;
    unsigned long left_length;

    struct stat st;
    unsigned char buf[MAX_BUF], bit_map[MAX_BIT_MAP], scan[3], bit, b1;
    unsigned int  S, RE, RM;
    float  d1, Scale_E, Scale_D, Refv_R;
    long   skip;
    int    num_data = 0;
    int    seq_fc, seq_ef, YY, MM, DD, HH, MI;
    int    GB, bsize, length, varn, level, nx, ny;
    int    on, on_tmef, on_varn, on_level, on_member, on_bit, on_data;
    int    A, B, D, E, v, skip_bytes, sbyte, sbit, num_bits, member;
    int    code, mode;
    int    i, j, k, k1, k2, n, ii, jj, kk = 0;

    // 1. �ʱ�ȭ �� ���� ����
    var.num_ok = 0;

    if (fp == NULL) {
        code = stat(var.fname, &st);
        if (code != 0) return -22;
        var.fsize = st.st_size;

        fp = fopen(var.fname, "rb");
        if (fp == NULL) return -23;

        strcpy(fname, var.fname);
        fsize = var.fsize;
        total_length = 0;
    }
    else {
        if (strcmp(var.fname, fname) == 0 && fsize == var.fsize)
            rewind(fp);
        else {
            fclose(fp);
            fp = fopen(var.fname, "rb");
            if (fp == NULL) return -23;

            strcpy(fname, var.fname);
            fsize = var.fsize;
        }
        total_length = 0;
    }

    // 2. �ش� �ڷḸ �б�
    while ((fsize -= total_length) > 0) {
        // 2.1. Section-0 (GRIB ���� ��ġ ã��)
        if (fread(buf, 1, 4, fp) <= 0) return -24;

        for (mode = 0, i = 0; i < fsize; i++) {
            buf[4] = '\0';

            if (strncmp(buf, "GRIB", 4) == 0) {
                mode = 1;
                break;
            }
            else {
                for (j = 0; j < 3; j++)
                    buf[j] = buf[j+1];
                buf[3] = fgetc(fp);
            }
        }
        fsize -= i;
        if (mode != 1) return 0;

        fread(buf, 1, 4, fp);       // ��ü ���� Ȯ��
        total_length = (buf[0]*256 + buf[1])*256 + buf[2];
        left_length = total_length - 8;

        // 2.2. Section-1 (PDS)
        fread(buf, 1, 3, fp);
        length = (buf[0]*256 + buf[1])*256 + buf[2];
        fread(buf, 1, length-3, fp);
        left_length -= length;

        GB = 0;
        if ((buf[4]&128) > 0) GB = 10;  // GDS ���� ����
        if ((buf[4]&64)  > 0) GB += 1;  // BMS ���� ����

        varn = buf[5];      // ������

        switch (buf[6]) {   // ������
          case 101:  case 104:  case 106:  case 108:  case 110:  case 112:  case 114:  case 121:  case 128:  case 141:
            level = buf[7]*1000 + buf[8];
            break;
          default:
            level = buf[7]*256 + buf[8];
        }

        // 2.2.2. ��� Ȯ��
        if (var.member >= 0 && length > 50)
            member = buf[46];   // ECMWF �ӻ���� ����� �� ������ġ
        else
            member = -1;

        // 2.2.3. ��ǥ�ð�
        YY = ((int)buf[21]-1)*100 + (int)buf[9];
        MM = (int)buf[10];
        DD = (int)buf[11];
        HH = (int)buf[12];
        MI = (int)buf[13];
        seq_fc = time2seq(YY, MM, DD, HH, MI, 'm');

        // 2.2.4. ��ȿ�ð�
        if (buf[16] > 0)
            seq_ef = seq_fc + 60*(unsigned int)buf[16];
        else
            seq_ef = seq_fc + 60*(unsigned int)buf[15];

        // 2.2.5. ã�� ����*���� ��Ͽ� �ִ��� Ȯ��
        on = 1;
        // 2.2.5.1. ��ǥ�ð��� �´��� �˻�
        if (var.tmfc.seq != seq_fc) on = 0;

        // 2.2.5.2. ��ȿ�ð� �˻�
        if (on) {
            if (var.tmef.seq <= 0)
                on_tmef = 1;
            else if (var.tmef.seq == seq_ef)
                on_tmef = 1;
            else
                on_tmef = 0;
            on = on_tmef;
        }

        // 2.2.5.3. ���� ��ġ�� �˻�
        if (on) {
            for (on_varn = 0, i = 0; i < var.num_varn; i++) {
                if (varn == var.varn[i]) {
                    on_varn = 1;
                    break;
                }
            }
            on = on_varn;
        }

        // 2.2.5.4. ���� ��ġ�� �˻�
        if (on) {
            if (var.num_level <= 0)     // ��ü �����̸� ����
                on_level = 1;
            else {
                for (on_level = 0, j = 0; j < var.num_level; j++) {
                    if (level == var.level[j]) {
                        on_level = 1;
                        break;
                    }
                }
            }
            on = on_level;
        }

        // 2.2.5.5. ��� ��ġ�� �˻�
        if (on) {
            if (var.member < 0)     // ����� ��������� ����
                on_member = 1;
            else if (var.member == member)
                on_member = 1;
            else
                on_member = 0;
            on = on_member;
        }

        // 2.2.5.6. ��ġ���� ������ �������� skip
        if (on == 0) {
          fseek(fp, left_length, SEEK_CUR);
          continue;
        }

        // 2.2.6. D�� Ȯ��
        if (on) {
            Scale_D = (buf[23]&127)*256 + buf[24];
            if (buf[23]&128 > 0) Scale_D *= -1;
            Scale_D = pow(10.0, Scale_D);
        }

        // 2.3. Section-2 (GDS)
        if (GB >= 10) {
            fread(buf, 1, 3, fp);
            length = (buf[0]*256 + buf[1])*256 + buf[2];

            if (on == 0)
                fseek(fp, (long)(length-3), SEEK_CUR);
            else {
                fread(buf, 1, length-3, fp);
                if ( xy_calc(buf) < 0 ) return -30;
            }
        }

        // 2.4. Section-3 (BMS)
        if (GB % 10 == 0)
            on_bit = 0;
        else {
            fread(buf, 1, 6, fp);
            length = (buf[0]*256 + buf[1])*256 + buf[2];

            if (on) {
                fread(bit_map, 1, length-6, fp);
                on_bit = 1;
                var.num_bit += 1;
            }
            else
                fseek(fp, (long)(length-6), SEEK_CUR);
        }

        // 2.5. Section-4 (BDS)
        fread(buf, 1, 11, fp);
        length = (buf[0]*256 + buf[1])*256 + buf[2];

        if (on) {
            // 2.5.1. E �� Ȯ��
            Scale_E = (buf[4]&127)*256 + buf[5];
            if ((buf[4]&128) > 0) Scale_E *= -1;
            Scale_E = pow(2.0, Scale_E);

            // 2.5.2. R �� Ȯ��
            A = buf[6]&127;
            B = (buf[7]*256 + buf[8])*256 + buf[9];
            Refv_R = (float)( pow(2,-24) * B * pow(16,(A-64)) );
            if ((buf[6]&128) > 0) Refv_R *= -1.0;

            // 2.5.3. ���� BIT�� Ȯ��
            num_bits = buf[10];
        }
        else
            fseek(fp, (long)(length-11), SEEK_CUR);

        // 2.6. �ڷ� ����
        if (on) {
            // 2.6.1. �ڷ� ��ġ���� �̵�
            skip = (var.Y - 1)*var.nx + var.X - 1;

            if (on_bit == 1) {      // bit_map�� ���Ǿ�����, �ش� ���ڱ��� ��ġ �����
                k1 = k2 = 0;

                for (num_data = 0, i = 0; i <= skip; i++) {
                    if (k1 == 0) bit = bit_map[k2];
                    on_data = bit & 1;
                    if (on_data == 1) num_data++;

                    bit >> 1;
                    k1++;

                    if (k1 == 8) {
                        k1 = 0;
                        k2++;
                    }
                }
                if (on_data == 1) num_data--;
            }
            else {
                num_data = skip;
                on_data = 1;
            }

            // 2.6.2. �ڷ� ����
            if (on_data == 1) {
                skip_bytes = num_data*num_bits/8;
                fseek(fp, skip_bytes, SEEK_CUR);
                fread(buf, 1, length-11-skip_bytes, fp);

                sbyte = 0;
                sbit = 8 - (skip*num_bits - skip_bytes*8);

                v = bit_decode(buf, &sbyte, &sbit, num_bits);
                d1 = ((float)v * Scale_E + Refv_R) / Scale_D;
            }
            else {
                d1 = -99999;
                fseek(fp, (long)(length-5), SEEK_CUR);
            }

            // 2.6.3. ��� ǥ��
            if (var.disp == 'A') {
                printf("%04d%02d%02d%02d ", var.tmfc.YY, var.tmfc.MM, var.tmfc.DD, var.tmfc.HH);
                printf("%04d%02d%02d%02d ", var.tmef.YY, var.tmef.MM, var.tmef.DD, var.tmef.HH);
                printf("%8d ", varn);
                printf("%8d ", level);
                printf("%12.5e\n", d1);
            }
            else {
                printf("%04d%02d%02d%02d,", var.tmfc.YY, var.tmfc.MM, var.tmfc.DD, var.tmfc.HH);
                printf("%04d%02d%02d%02d,", var.tmef.YY, var.tmef.MM, var.tmef.DD, var.tmef.HH);
                printf("%d,", varn);
                printf("%d,", level);
                printf("%.5e\n", d1);
            }

            var.chk += 1;
        }

        // 2.7. Section-5
        fseek(fp, 4, SEEK_CUR);

        // 2.8. ��� ���θ� �Ǵ�
        if (var.num_level > 0) {
            if (var.chk == (var.num_varn * var.num_level)) break;
        }
    }
    return 0;
}

/*============================================================================*
 *  ������ ��ġ Ȯ��
 *============================================================================*/
int xy_calc(unsigned char *buf) {
    int  lon, lat;
    int  Lo1, Lo2, La1, La2, Dx, Dy;
    char scan[4];

    // 1. ���� ũ��
    var.nx = buf[3]*256 + buf[4];
    var.ny = buf[5]*256 + buf[6];

    // 2. ���浵 ü���� ���
    if (buf[2] == 0) {
        La1 = ((buf[7]&127)*256 + buf[8])*256 + buf[9];     if (buf[7]&128)  La1 *= -1;
        Lo1 = ((buf[10]&127)*256 + buf[11])*256 + buf[12];  if (buf[10]&128) Lo1 *= -1;
        La2 = ((buf[14]&127)*256 + buf[15])*256 + buf[16];  if (buf[14]&128) La2 *= -1;
        Lo2 = ((buf[17]&127)*256 + buf[18])*256 + buf[19];  if (buf[17]&128) Lo2 *= -1;
        Dx  = buf[20]*256 + buf[21];  Dy  = buf[22]*256 + buf[23];

        if (Lo1 < 0) Lo1 += 360000;
        if (Lo2 < 0) Lo2 += 360000;

        strcpy(scan, "000");    // �ڷ� ���� ����
        if (buf[24] & 128) scan[0] = '1';   // 0(��->��), 1(��->��)
        if (buf[24] & 64)  scan[1] = '1';   // 0(��->��), 1(��->��)
        if (buf[24] & 32)  scan[2] = '1';   // 0(I,J), 1(J,I)
    }

    // 3. �ٸ� �������� ���
    else {
        if (var.gl == 1) {
            printf("# ���� �������� �����浵�� �ƴ�<br>\n");
            return -1;
        }
    }

    // 4. �ľ���
    if (var.gl == 1) {
        lon = var.lon*1000 + 0.5;
        lat = var.lat*1000 + 0.5;
        if (lon < 0) lon += 360000;

        if (scan[0] == '1') Dx *= -1;
        if (scan[1] == '0') Dy *= -1;

        var.X = (int)( (lon - Lo1)/Dx + 0.5 );
        var.Y = (int)( (lat - La1)/Dy + 0.5 );
    }
    else {
        if (scan[1] == '0') var.Y = var.ny - var.Y + 1;
    }
//    printf("#X = %d, Y = %d<br>\n", var.X, var.Y);
    return 0;
}

/*============================================================================*
 *  �ڷ�κ� �ص�
 *============================================================================*/
int
bit_decode
(
    unsigned char *buf,      /* data */
    int   *sbyte,            /* start byte number */
    int   *sbit,             /* start bit number in 'sbyte' (0~7) */
    int   width              /* width of data (1~) */
)
{
    unsigned char m[9] = {0x00, 0x01, 0x03, 0x07, 0x0F, 0x1F, 0x3F, 0x7F, 0xFF};
    int  s[9] = {0, 2, 4, 8, 16, 32, 64, 128, 256};
    unsigned char q;
    unsigned char v1;
    int  v = 0, w1;

    if (*sbyte < 0 || *sbit < 1 || *sbit > 8 || width < 0) return -99999;
    if (width == 0) return 0;

    while (width > 0)
    {
        q = buf[*sbyte];
        v1 = q & m[*sbit];
        w1 = *sbit - width;

        if (w1 <= 0)
        {
            w1 = *sbit;
            v = v*s[w1] + v1;
            width -= w1;
            *sbyte += 1;
            *sbit = 8;
        }
        else
        {
            v1 = v1 >> w1;
            v = v*s[width] + v1;
            *sbit -= width;
            width = 0;
        }
    }
    return v;
}
