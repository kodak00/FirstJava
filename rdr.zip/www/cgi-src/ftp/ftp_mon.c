/******************************************************************************
**
**  ��ü NIC�� ���� ����ڷ� ó�� ��Ȳ ����
**
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include "/comis/src/include/cgiutil.h"
#include "/comis/src/include/comn.h"

#define DST_INI_FILE "/comis/REF/INI/dst_main.ini"  /* ���� ���� */
#define DST_INI_MAX  1000       /* max. child process's */
#define DST_FILE_MAX 100        /* max. file number per child process */

struct DST_INF dst[DST_INI_MAX];
struct NIC_INF
{
    char nic[16];
    int  nic_num;
    int  num[DST_FILE_MAX];
    int  stop[DST_FILE_MAX];
    char name[DST_FILE_MAX][32];
} nic[100];
int    nic_max = 0;
int    num_dst = 0;
int    num_nic = 0;


int main(int argc, char *argv[])
{
    int code, n = 0;

    /*--------------------------------------------------------------*/
    /* initial */

    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(30);

    printf("HTTP/1.0 200 OK\n");
    printf("Server: Netscape-Enterprise/3.0\n");
    printf("Content-type: text/html\n\n");

    /*--------------------------------------------------------------*/
    /* display */

    if ( INI_read() >= 0 )
    {
        if (num_dst > 0)
        {
            nic_lst();
            disp_html();
        }
    }
    else
    {
        printf(" Read Error : %s\n", DST_INI_FILE);
    }
    alarm(0);
	return 0;
}

/*============================================================================*
 *
 *  INI file read
 *
 *============================================================================*/
int INI_read()
{
    FILE   *fd;
    char   buf[256];
    int    n = 0;
    int    i = 0, k, m;

    fd = fopen(DST_INI_FILE, "r");
    if (fd == NULL) return -1;

    while (fgets(buf,256,fd) != NULL)
    {
        if ( dst_inf_dec(buf, &dst[n]) >= 0 )
        {
            if (dst[n].stop < 9) n++;
            if (n >= DST_INI_MAX) break;
        }
        i++;
    }
    fclose(fd);

    if (n == 0) return -1;

    num_dst = n;
    return 0;
}

/*============================================================================*
 *
 *  NIC List
 *
 *============================================================================*/
int nic_lst()
{
    int  i, j;

    strcpy(nic[0].nic, dst[0].nic);
    nic[0].nic_num = 1;
    nic[0].num[0] = dst[0].num;
    strcpy(nic[0].name[0], dst[0].name);
    num_nic = 1;
    j = 1;

    for (i = 1; i < num_dst; i++)
    {
        if (strcmp(nic[num_nic-1].nic, dst[i].nic) != 0)
        {
            strcpy(nic[num_nic].nic, dst[i].nic);
            nic[num_nic].nic_num = 1;
            nic[num_nic].num[0] = dst[i].num;
            nic[num_nic].stop[0] = dst[i].stop;
            strcpy(nic[num_nic].name[0], dst[i].name);
            num_nic++;
            j = 1;
        }
        else
        {
            nic[num_nic-1].nic_num += 1;
            nic[num_nic-1].num[j] = dst[i].num;
            nic[num_nic-1].stop[j] = dst[i].stop;
            strcpy(nic[num_nic-1].name[j], dst[i].name);
            j++;
        }
    }

    nic_max = 0;
    for (i = 0; i < num_nic; i++)
    {
        if (nic_max < nic[i].nic_num) nic_max = nic[i].nic_num;
    }
    return num_nic;
}

/*============================================================================*
 *
 *  HTML mode
 *
 *============================================================================*/
int disp_html()
{
    struct COM_IPC s1;
    struct COM_BIN b1;
    struct COM_OPC o1;
    struct COM_OUT t1;
    struct tm      *now;
    struct stat    st;
    time_t tp;
    char   dir[250], iname[250], *p;
    int    num_tot = 0, num_norm = 0, num_send = 0, num_stop = 0, num_err = 0;
    int    YY, MM, DD, HH, MI, SS;
    int    seq1, seq2, dsec;
    int    code;
    int    i, j;

    /*---------------------------------------------------------------*/
    /* HEAD */

    printf("<HTML><HEAD>\n");

    printf("<META http-equiv='Refresh' content=200>\n");

    printf("<style type='text/css'>\n");
    printf("<!--\n");
    printf(".head  {font-family: '����','Verdana'; font-size:11pt; color: #000000; font-weight:bold;}\n");
    printf(".ehead {font-family: '����','Verdana'; font-size:10pt; color: #0000ff;}\n");
    printf(".name  {font-family: '����ü','Verdana'; font-size: 9pt; color: #000000;}\n");
    printf(".text  {font-family: '����ü','Verdana'; font-size: 9pt; color: #000000;}\n");
    printf("-->\n");
    printf("</style>\n");

    printf("</HEAD>\n");

    /*---------------------------------------------------------------*/

    printf("<BODY bgcolor=#ffffff TOPMARGIN=2 LEFTMARGIN=2 marginwidth=2 marginheight=2>\n");

    time( &tp );
    now  = localtime( &tp );
    YY = (now -> tm_year) + 1900;
    MM = (now -> tm_mon) + 1;
    DD = now -> tm_mday;
    HH = now -> tm_hour;
    MI = now -> tm_min;
    SS = now -> tm_sec;

    printf("<span class=head>��ȸ�ð� : %04d.%02d.%02d.%02d:%02d:%02d</span>", YY, MM, DD, HH, MI, SS);
    printf("&nbsp; &nbsp; &nbsp; <span class=ehead>[����] ������(�����), �Ͻ�����(ȸ��), �ߴ�(������)</span><br>\n");

    printf("<table border=0 cellspacing=0 cellpadding=0>\n");
    printf("<tr><td bgcolor=#AAAAAA>\n");
    printf("<table border=0 cellspacing=1 cellpadding=2>\n");

    /*  NIC ���� ���پ� ǥ��  */

    for (i = 0; i < num_nic; i++)
    {
        /*  ��� ���� �Ǵ� ���μ��� ��Ī  */

        printf("<tr bgcolor=#ddffdd align=left class=text>");
        printf("<td align=center>%s</td>", nic[i].nic);

        code = com_ipc_io(nic[i].nic, &s1, 'r');

        now = localtime(&s1.tm);
        YY = (now -> tm_year) + 1900;
        MM = (now -> tm_mon) + 1;
        DD = now -> tm_mday;
        HH = now -> tm_hour;
        MI = now -> tm_min;
        SS = now -> tm_sec;

        dsec = (int)difftime(tp, s1.tm);
        if (dsec > 12*60*60)
            printf("<td rowspan=2 bgcolor=#ffdddd>");
        else
            printf("<td rowspan=2 bgcolor=#DBF3FF>");

        printf("%02d.%02d<br>%02d:%02d</td>", MM, DD, HH, MI);

        for (j = 0; j < nic_max; j++)
        {
            if (nic[i].stop[j] == 0)
                printf("<td>");
            else if (nic[i].stop[j] == 1)
                printf("<td bgcolor=#ffffdd>");
            else
                printf("<td bgcolor=#dddddd>");

            if (j < nic[i].nic_num)
                printf("%d:%s", nic[i].num[j], nic[i].name[j]);
            else
                printf("&nbsp;");

            printf("</td>");
        }
        printf("</tr>\n");

        /*  �������� ��ȣ  */

        printf("<tr bgcolor=#FFFFFF align=center class=text>");
        if (code < 0)
            printf("<td>-</td>");
        else
            printf("<td>%d</td>", s1.seq);

        for (j = 0; j < nic_max; j++)
        {
            if (j < nic[i].nic_num)
            {
                code = com_opc_io(nic[i].nic, nic[i].num[j], &o1, 'r');
                if (code < 0)
                    printf("<td>-</td>");
                else
                {
                    if (nic[i].stop[j] != 0)
                    {
                        printf("<td bgcolor=#dddddd>%d</td>", o1.seq_out);
                        num_stop++;
                    }
                    else if (o1.seq_out == s1.seq)
                    {
                        printf("<td>%d</td>", o1.seq_out);
                        num_norm++;
                    }
                    else
                    {
                        if ((dsec = difftime(s1.tm, o1.tm_out)) > 10*60*60)
                        {
                            printf("<td bgcolor=#ffdddd>%d</td>", o1.seq_out);
                            num_err++;
                        }
                        else
                        {
                            printf("<td bgcolor=#ffffdd>%d</td>", o1.seq_out);
                            num_send++;
                        }
                    }
                }
                num_tot++;
            }
            else
                printf("<td>&nbsp;</td>");  // �� ���߱� ��ĭ
        }
        printf("</tr>\n");
    }
    printf("</table></td></tr>\n");
    printf("</table>\n");

    /*  ��� ���  */

    printf("<div ID=sum STYLE='position:absolute; left:600px; top:0px; visibility:visible;'>\n");
    printf("<table border=1 cellpadding=2 cellspacing=0 bordercolor=#9d9c9c bordercolordark=#ffffff>\n");
    printf("<tr class=text>\n");
    printf("  <td nowrap>��ü</td><td nowrap>&nbsp;%d&nbsp;</td>", num_tot);
    printf("  <td nowrap>�Ϸ�</td><td nowrap>&nbsp;%d&nbsp;</td>", num_norm);
    printf("  <td nowrap bgcolor=#ffffdd>������</td><td nowrap>&nbsp;%d&nbsp;</td>", num_send);
    printf("  <td nowrap bgcolor=#dddddd>�Ͻ�����</td><td nowrap>&nbsp;%d&nbsp;</td>", num_stop);
    printf("  <td nowrap bgcolor=#ffdddd>����</td><td nowrap>&nbsp;%d&nbsp;</td>", num_err);
    printf("</tr>\n");
    printf("</table>\n");
    printf("</div>\n");

    printf("</BODY></HTML>\n");
    return 0;
}
