/*********************************************************************
**
**  NIC�� ��ϵ� �ڷ� ���� �� ó�� ����� ������ ��ȸ�ϴ� ���α׷�
**
**********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <fnmatch.h>
#include <errno.h>
#include "cgiutil.h"
#include "comn.h"

#define  NUM_REC_DISP  500

struct DST_INF  dst[DST_INI_MAX];
int    num_dst = 0;

struct INPUT_VAR
{
    char  nic[32];              /* �ڷ����� */
    int   seq;                  /* �˻��� ��ġ */
    int   iseq;                 /* ����ð� */
    int   num;                  /* ����ȣ */
    int   dst;                  /* ���� */
    char  find[120];            /* ã�� ���ϸ� ���ڿ� */
    char  auto_man;             /* �ڵ�/���� */
} var;


int main(int argc, char *argv[])
{
    int code, n = 0;

    /*--------------------------------------------------------------*/
    /* initial */

    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(30);

    printf("HTTP/1.0 200 OK\n");
    printf("Server: Netscape-Enterprise/3.0\n");
    printf("Content-type: text/html\n\n");

    /*--------------------------------------------------------------*/
    /* user input decode */

    if ( (code = Input()) < 0 )
    {
        printf(" input variable error (%d)<p>\n", code);
        input_print();
        return -1;
    }

    /*--------------------------------------------------------------*/
    /* display */

    if ( (n = INI_read()) >= 0 )
    {
        disp_html(num_dst);
    }
    else
    {
        printf(" Read Error(%d) : %s\n", n, DST_INI_FILE);
    }
    alarm(0);
	return 0;
}

/*********************************************************************
 *
 *  ����� ��û�ڷ� �м�
 *
 *********************************************************************/
int Input()
{
    char *qs;
    char item[120], value[120];
    int  iYY, iMM, iDD, iHH, imin, sec;
    int  iseq, i;

    /*--------------------------------------------------------------*/
    /* Now time */

    get_time(&iYY, &iMM, &iDD, &iHH, &imin, &sec);
    iseq = time2seq(iYY, iMM, iDD, iHH, imin, 'm');
    var.iseq = iseq;

    /*--------------------------------------------------------------*/
    /* input from env */

    qs = getenv("QUERY_STRING");
    if (qs == NULL) return -1;

    for (i=0; qs[0] != '\0'; i++)
    {
        getword (value, qs, '&');
        getword (item, value, '=');

        if      ( !strcmp(item,"nic"))  strcpy(var.nic, value);
        else if ( !strcmp(item,"seq"))  var.seq = atoi(value);
        else if ( !strcmp(item,"num"))  var.num = atoi(value);
        else if ( !strcmp(item,"find")) strcpy(var.find, value);
    }

    if (strlen(var.find) <= 0)
    {
        return -2;
    }
    else
    {
        if (strchr(var.find,'*') == NULL && strchr(var.find,'?') == NULL)
        {
            sprintf(value, "*%s*", var.find);
            strcpy(var.find, value);
        }
    }
    return 0;
}

/*********************************************************************
 *
 *  INI file read
 *
 *********************************************************************/
int INI_read()
{
    FILE   *fp;
    char   buf[4000];
    int    n = 0, i= 0;

    fp = fopen(DST_INI_FILE, "r");
    if (fp == NULL) return -1;

    memset(buf, 0x00, sizeof(buf));

    while (fgets(buf,4000,fp) != NULL)
    {
        if ( dst_inf_dec(buf, &dst[n]) >= 0 )
        {
            if (strcmp(var.nic, dst[n].nic) == 0) n++;
            if (n >= DST_INI_MAX) break;
        }
        i++;

        memset(buf, 0x00, sizeof(buf));
    }
    fclose(fp);

    if (n == 0) return -2;

    num_dst = n;
    return 0;
}

/*********************************************************************
 *
 *  HTML mode
 *
 *********************************************************************/
int disp_html(int n)
{
    struct COM_IPC s1;
    struct COM_BIN b1;
    struct COM_OPC o1;
    struct COM_OUT t1;
    struct tm      *now;
    struct stat    st;
    char   dir[250], iname[250], size_str[30], tmp[30], *p;
    int    YY, MM, DD, HH, MI, SS;
    int    YY1, MM1, DD1, HH1, MI1, SS1;
    int    YY2, MM2, DD2, HH2, MI2, SS2;
    int    seq, seq1, seq2, i_num, j_num, day_old = 0;
    int    code, sz1, sz2, check = 1;
    int    i, j, k, m, lst;

    /*---------------------------------------------------------------*/
    /* IPC ���� */

    code = com_ipc_io(var.nic, &s1, 'r');
    if (code < 0)
    {
        printf("error : ipc (%d)<br>\n", code);
        return -1;
    }

    /*---------------------------------------------------------------*/
    /* HEAD */

    printf("<HTML><HEAD>\n");

    if (var.seq < 0) printf("<META http-equiv='Refresh' content=100>\n");

    printf("<style type='text/css'>\n");
    printf("<!--\n");
    printf(".title { font-family:'���� ����'; font-size:16pt; color:#000000; font-weight:bold;}\n");
    printf(".ehead { font-family:'���� ����'; font-size:11pt; color:#000000; font-weight:bold;}\n");
    printf(".stn   { font-family:'���� ����'; font-size:10pt; color:#000000; font-weight:bold;}\n");
    printf(".date  { font-family:'���� ����'; font-size:10pt; color:#000000;}\n");
    printf(".name  { font-family:'���� ����'; font-size: 9pt; color:#000000;}\n");
    printf(".texts { font-family:'���� ����'; font-size: 9pt; color:#333333;}\n");
    printf(".text1 { font-family:'Courier New','���� ����'; font-size: 8pt; color:#333333;}\n");
    printf(".text2 { font-family:'Arial Narrow','���� ����'; font-size:10pt; color:#333333;}\n");
    printf(".textb { font-family:'���� ����'; font-size: 9pt; color:#0000FF;}\n");
    printf(".textt { font-family:'���� ����'; font-size: 9pt; color:#992222;}\n");
    printf("-->\n");
    printf("</style>\n");

    printf("<SCRIPT LANGUAGE='JavaScript'>\n");
    printf("<!--\n");

    if (var.seq < 0)
        seq1 = s1.seq;
    else
        seq1 = var.seq;

    printf("parent.menu.frm.seqpt.value = %d\n", seq1);
    printf("parent.menu.frm.seqmax.value = %d\n", s1.max);
    printf("parent.menu.frm.num.value = %d\n", var.num);

    printf("function view_win(page) \n");
    printf("{ \n");
    printf("  url = page; \n");
    printf("  window.open(url,\"\",\"location=no,width=650,height=450,resizable=yes,scollbars=no\"); \n");
    printf("} \n");

    printf("// -->\n");
    printf("</SCRIPT>\n");
    printf("</HEAD>\n");

    /*---------------------------------------------------------------*/
    /* BODY */

    printf("<BODY bgcolor=#ffffff topmargin=2 leftmargin=2 marginwidth=2 marginheight=2>\n");

    if (seq1 >= s1.max)
    {
        printf("[%s] error : max �ʰ� (max = %d, seq = %d)<br>\n", var.nic, s1.max, s1.seq);
        return -2;
    }

    printf("<table border=0 cellspacing=0 cellpadding=0>\n");
    printf("<tr><td bgcolor=#AAAAAA>\n");
    printf("<table border=0 cellspacing=1 cellpadding=0>\n");
    printf("<tr height=15 bgcolor=#99ee99 style='cursor:hand;'>\n");

    i_num = seq1 * 100 / s1.max;
    j_num = s1.seq * 100 / s1.max;

    for (i = 0; i < 100; i++)
    {
        seq = s1.max / 100 * (i+1) - 1;
        printf("<td width=8 onClick='javascript:parent.menu.seq_jump(%d);'", seq);

        if (i == j_num)
            printf(" bgcolor=#ffaaff");
        else if (i == i_num)
            printf(" bgcolor=#ffffaa");
        printf("></td>");
    }
    printf("</tr>\n");
    printf("</table></td></tr></table>\n");

    /*---------------------------------------------------------------*/
    /* ���� */

    printf("<table border=0 cellspacing=0 cellpadding=0>\n");
    printf("<tr><td bgcolor=#ffffff class=ehead>< ���� ></td></tr>\n");
    printf("<tr><td bgcolor=#AAAAAA>\n");
    printf("<table border=0 cellspacing=1 cellpadding=3>\n");
    printf("<tr bgcolor=#ddffdd align=center class=name>");
    printf("<td>NIC</td><td>���� ó�� �ð�</td><td>���� SEQ</td><td>�ִ� SEQ</td><td>��ȸ�ð�</td></tr>\n");

    printf("<tr bgcolor=#ffffff align=center class=texts>");
    printf("<td>%s</td>", var.nic);

    now = localtime(&s1.tm);
    YY = (now -> tm_year) + 1900;
    MM = (now -> tm_mon) + 1;
    DD = now -> tm_mday;
    HH = now -> tm_hour;
    MI = now -> tm_min;
    SS = now -> tm_sec;

    printf("<td>%04d.%02d.%02d.<font color=blue>%02d:%02d:%02d</font></td>", YY, MM, DD, HH, MI, SS);
    printf("<td>%d</td><td>%d</td>", s1.seq, s1.max);

    get_time(&YY, &MM, &DD, &HH, &MI, &SS);
    printf("<td>%04d.%02d.%02d.<font color=#992222>%02d:%02d:%02d</font></td></tr>\n", YY, MM, DD, HH, MI, SS);
    printf("</table></td></tr></table><br>\n");

    /*---------------------------------------------------------------*/
    /* �۽� */

    printf("<table border=0 cellspacing=0 cellpadding=0>\n");
    printf("<tr><td bgcolor=#ffffff class=ehead>< �۽� ></td></tr>\n");
    printf("<tr><td bgcolor=#AAAAAA>\n");
    printf("<table border=0 cellspacing=1 cellpadding=3>\n");
    printf("<tr bgcolor=#ddffdd align=center class=name>");
    printf("<td onClick='javascript:parent.menu.num_select(-1);'><font color=blue>��ü</font><br>��ȣ</td><td>���и�</td><td>IP</td><td>����</td>");
    printf("<td bgcolor=#ddffff>����</td><td bgcolor=#ddffff>����</td><td bgcolor=#ddffff>����</td>");
    printf("<td>��� ���丮</td><td>���α׷�</td><td>1ȸ<br>���ϼ�</td><td>1ȸ<br>���ð�</td>");
    printf("<td onclick=\"view_win('/ftp/ftp_mode.html');\" style=\"cursor:hand;\"><font color=blue>������</font></td>");
    printf("<td bgcolor=#ffddff>���ۿϷ�<br>SEQ/�ð�</td>\n");
    printf("<td bgcolor=#ffddff>������<br>/���۽ð�</td>\n");
    printf("</tr>\n");

    for (j = 0; j < n; j++)
    {
        if (strcmp(dst[j].nic, var.nic) != 0) continue;

        if (dst[j].stop == 0)
            printf("<tr bgcolor=#ffffff align=center class=text1>");
        else if (dst[j].stop == 1)
            printf("<tr bgcolor=#ffffdd align=center class=text1>");
        else if (dst[j].stop == 2)
            printf("<tr bgcolor=#e6e6e6 align=center class=text1>");
        else
            continue;

        printf("<td bgcolor=#ffddff onClick='javascript:parent.menu.num_select(%d);'><<font color=blue>%d</font>></td>", dst[j].num, dst[j].num);
        printf("<td bgcolor=#ffddff>%s</td>", dst[j].name);
        printf("<td>%s</td>", dst[j].ip);
        printf("<td>%s</td>", dst[j].id);

        printf("<td>");
        for (i = 0; i < 32; i++)
        {
            if (strlen(dst[j].head[i]) <= 0) break;
            if (i > 0) printf(",");
            printf("%s", dst[j].head[i]);
        }
        printf("</td>");

        printf("<td>");
        for (i = 0; i < 32; i++)
        {
            if (strlen(dst[j].tail[i]) <= 0) break;
            if (i > 0) printf(",");
            printf("%s", dst[j].tail[i]);
        }
        printf("</td>");

        printf("<td>");
        for (i = 0; i < 32; i++)
        {
            if (strlen(dst[j].excp[i]) <= 0) break;
            if (i > 0) printf(",");
            printf("%s", dst[j].excp[i]);
        }
        printf("</td>");

        printf("<td align=left>%s</td>", dst[j].dir);
        printf("<td align=left>%s</td>", dst[j].prg);
        printf("<td>%d ��</td>", dst[j].fn);
        printf("<td>%d ��</td>", dst[j].limit);
        printf("<td>%d</td>", dst[j].mode);

        code = com_opc_io(var.nic, dst[j].num, &o1, 'r');

        now = localtime(&o1.tm_out);
        YY = (now -> tm_year) + 1900;
        MM = (now -> tm_mon) + 1;
        DD = now -> tm_mday;
        HH = now -> tm_hour;
        MI = now -> tm_min;
        SS = now -> tm_sec;
        printf("<td nowrap>%d / %04d.%02d.<br>%02d.<font color=#992222>%02d:%02d:%02d</font></td>", o1.seq_out, YY, MM, DD, HH, MI, SS);

        if (o1.tm_st == o1.tm_out)
        {
            printf("<td>&nbsp;</td>");
        }
        else
        {
            now = localtime(&o1.tm_st);
            YY = (now -> tm_year) + 1900;
            MM = (now -> tm_mon) + 1;
            DD = now -> tm_mday;
            HH = now -> tm_hour;
            MI = now -> tm_min;
            SS = now -> tm_sec;
            printf("<td nowrap>%d~%d /<br>%04d.%02d.%02d.%02d:%02d:%02d</td>", o1.seq1, o1.seq2, YY, MM, DD, HH, MI, SS);
        }
        printf("</tr>\n");
    }
    printf("</table></td></tr></table><p>\n");

    /*---------------------------------------------------------------*/
    /* �α� */

    printf("<table border=0 cellspacing=0 cellpadding=0>\n");
    printf("<tr><td bgcolor=#ffffff class=ehead>\n");
    if (var.num < 0)
        printf("< ��ȣ : ��ü >");
    else
    {
        for (j = 0; j < n; j++)
        {
            if (var.num == dst[j].num)
            {
                printf("< ��ȣ : %d > %s", var.num, dst[j].name);
                break;
            }
        }
    }
    printf("</td>\n");

    printf("<tr><td bgcolor=#aaaaaa>\n");
    printf("<table border=0 cellspacing=1 cellpadding=1>\n");
    printf("<tr bgcolor=#ddffff align=center class=name>\n");
    printf("<td>SEQ</td><td>���Žð�</td><td>���ϸ�</td><td nowrap>ũ��(bytes)</td>");

    for (j = 0; j < n; j++)
    {
        if (dst[j].stop <= 1 && (var.num == -1 || var.num == dst[j].num))
        {
            printf("<td bgcolor=#ffddff><%d></td>", dst[j].num);
            if (var.num == dst[j].num) var.dst = j;
        }
    }
    printf("</tr>\n");

    /*---------------------------------------------------------------*/

    lst = 1;

    for (k = 0; k < NUM_REC_DISP*10; k++)
    {
        // �����̸��� ����

        seq2 = (seq1 - k + s1.max) % s1.max;
        code = com_bin_io(var.nic, seq2, &b1, 'r');
        if (code < 0) continue;

        // ���丮�� ���ϸ����� �и�

        strcpy(dir, b1.fname);
        p = strrchr(dir, '/');
        if (p != NULL)
        {
            strcpy(iname, p+1);
            *(p+1) = '\0';
        }
        else
        {
            strcpy(iname, b1.fname);
            dir[0] = '\0';
        }

        // ���ϸ��� ����� �˻�

        if ( fnmatch(var.find, iname, 0) == 0)
            check = 1;
        else
            check = 0;

        // ����� ���, ǥ��

        if (check)
        {
            // �ش� ����

            printf("<tr bgcolor=#ffffff align=center class=text1>\n");
            printf("<td>%d</td>", seq2);

            if (b1.tm < 100)
            {
                printf("<td>&nbsp;</td>");
            }
            else
            {
                now = localtime(&b1.tm);
                YY1 = (now -> tm_year) + 1900;
                MM1 = (now -> tm_mon) + 1;
                DD1 = now -> tm_mday;
                HH1 = now -> tm_hour;
                MI1 = now -> tm_min;
                SS1 = now -> tm_sec;

                if (day_old != (YY1*100+MM1)*100+DD1)
                    printf("<td nowrap>%04d.%02d.%02d.<br><font color=blue>%02d:%02d:%02d</font></td>", YY1, MM1, DD1, HH1, MI1, SS1);
                else
                    printf("<td nowrap><font color=blue>%02d:%02d:%02d</font></td>", HH1, MI1, SS1);
                day_old = (YY1*100+MM1)*100+DD1;
            }

            printf("<td nowrap align=left>&nbsp;%s<font color=blue>%s</font>&nbsp;</td>", dir, iname);

            for (sz1=b1.size, size_str[0]='\0', tmp[0]='\0', i = 0; i < 5; i++)
            {
                sz2 = sz1 % 1000;
                sz1 /= 1000;

                if (sz1 == 0)
                {
                    sprintf(size_str, "%d%s", sz2, tmp);
                    break;
                }
                else
                {
                    sprintf(tmp, ",%03d%s", sz2, size_str);
                    strcpy(size_str, tmp);
                }
            }
            printf("<td align=right>%s</td>", size_str);

            //  �� ���

            for (j = 0; j < n; j++)
            {
                // �ش��� �ƴ� ��� ����

                if (dst[j].stop > 1) continue;
                if (var.num > -1)
                {
                    if (var.num < dst[j].num) break;
                    else if (var.num > dst[j].num) continue;
                }

                // ó�� ��� ǥ��

                code = com_out_io(var.nic, seq2, dst[j].num, &t1, 'r');

                if (code >= 0)
                {
                    if (t1.tm_out < -1)
                        printf("<td>X</td>");
                    else if (t1.tm_out <= 0)
                        printf("<td>-</td>");
                    else
                    {
                        if (b1.tm == t1.tm)
                        {
                            now = localtime(&t1.tm_out);
                            YY2 = (now -> tm_year) + 1900;
                            MM2 = (now -> tm_mon) + 1;
                            DD2 = now -> tm_mday;
                            HH2 = now -> tm_hour;
                            MI2 = now -> tm_min;
                            SS2 = now -> tm_sec;
                            if (day_old == (YY2*100+MM2)*100+DD2)
                                printf("<td nowrap><font color=#992222>%02d:%02d:%02d</font></td>", HH2, MI2, SS2);
                            else
                                printf("<td nowrap>%04d.%02d.%02d.<br><font color=#992222>%02d:%02d:%02d</font></td>",
                                        YY2, MM2, DD2, HH2, MI2, SS2);
                        }
                        else
                        {
                            printf("<td>&nbsp;</td>");
                        }
                    }
                }
                else
                {
                    printf("<td>error</td>");
                }
            }
            printf("</tr>\n");

            if ( lst++ > NUM_REC_DISP ) break;
        }
    }
    printf("</table></td></tr>\n");
    printf("</table>\n");
    printf("</BODY></HTML>\n");
    return 0;
}

int input_print()
{
    printf("nic = %s<br>\n", var.nic);

    return 0;
}
