/******************************************************************************
**
**  UF ���̴��ڷ� ���� ǥ���
**
**============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.04.24)
**
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "cgiutil.h"
#include "rsl_wrc.h"

// �ڷ� ���丮
#define  RDR_UF_RAW_DIR  "/AION/DATA/TEMP/KSN_SSP_TEST"
#define  RDR_UF_QCD_DIR  "/DATA/RDR/QCD"
#define  RDR_UF_HSR_DIR  "/DATA/RDR/HSR"
#define  RDR_UF_HCI_DIR  "/DATA/RDR/HCI"
#define  RDR_UF_LNG_DIR  "/AION/DATA/TEMP/KSN_SSP_TEST"
#define  RDR_UF_VER_DIR  "/AION/DATA/TEMP/KSN_SSP_TEST"

// ��û �� ���� ����
struct INPUT_VAR {
  int  seq;
  int  YY;
  int  MM;
  int  DD;
  int  HH;
  int  MI;
  char stn_cd[8];   // �����ڵ�
  char rdr[8];      // UF���� ����
  int  voln;        // Volume Number
  int  swpn;        // Sweep Number
  int  rayn;        // Ray Number
  int  disp;        // 1(csv) 0(html)
  int  help;
  char fname[120];
  int  size;
} var;

// UF ����
Radar  *radar;
Volume *volume;
Sweep  *sweep;
Ray    *ray;

// Volume ���
struct VOL_LIST {
  int  voln;
  char vol_cd[4];
} vol_inf[47] = {
  { 0, "DZ"},{ 1, "VR"},{ 2, "SW"},{ 3, "CZ"},{ 4, "ZT"},
  { 5, "DR"},{ 6, "LR"},{ 7, "ZD"},{ 8, "DM"},{ 9, "RH"},
  {10, "PH"},{11, "XZ"},{12, "CD"},{13, "MZ"},{14, "MD"},
  {15, "ZE"},{16, "VE"},{17, "KD"},{18, "TI"},{19, "DX"},
  {20, "CH"},{21, "AH"},{22, "CV"},{23, "AV"},{24, "SQ"},
  {25, "VS"},{26, "VL"},{27, "VG"},{28, "VT"},{29, "NP"},
  {30, "HC"},{31, "VC"},{32, "V2"},{33, "S2"},{34, "V3"},
  {35, "S3"},{36, "CR"},{37, "CC"},{38, "PR"},{39, "SD"},
  {40, "ZZ"},{41, "RD"},{42, "ET"},{43, "EZ"},{44, "TV"},
  {45, "ZV"},{46, "SN"}
};

/******************************************************************************
 *
 *  MAIN
 *
 ******************************************************************************/
int main()
{
  // ��� �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(120);

  // ����� �Է� ���� �м�
  if (user_input() < 0) {
    printf("# input variable error\n");
    return -1;
  }

  printf("HTTP/1.0 200 OK\n");
  if (var.disp != 1)
    printf("Content-type: text/html\n\n");
  else
    printf("Content-type: text/data\n\n");

  // ���ϸ� Ȯ��
  if (rdr_uf_file() < 0) {
    printf("# ������ �����ϴ�.\n");
    return -2;
  }

  // HTML Head ���
  if (var.disp != 1) disp_head();

  // UF ����, �б�
  radar = RSL_uf_to_radar(var.fname);

  // ���
  if (var.disp != 1) printf("<body class=text1 topmargin=2 leftmargin=2 marginwidth=2 marginheight=2>\n");
  if (radar == NULL) printf("# radar error\n");

  if (var.swpn < 0)
    disp_uf();
  else {
    if (var.rayn < 0)
      disp_sweep();
    else
      disp_ray();
  }
  if (var.disp != 1) printf("</body></html>\n");

  // UF���� �ݱ�
  RSL_free_radar(radar);
  alarm(0);
  return 0;
}

/******************************************************************************
 *
 *  ����� ��û�ڷ� �м�
 *
 ******************************************************************************/
int user_input()
{
  char *qs;
  char tmp[256], item[32], value[32], tm[30], fname[120];
  int  YY, MM, DD, HH, MI, SS;
  int  seq, seq1, i, j;

  // ���� �ʱ�ȭ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "");
  strcpy(var.stn_cd,"KWK");
  strcpy(var.rdr,"RAW");
  var.voln = 0;
  var.swpn = 0;
  var.rayn = 0;
  var.help = 1;

  // GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"tm"))   strcpy(tm,value);
    else if ( !strcmp(item,"stn"))  strcpy(var.stn_cd,value);
    else if ( !strcmp(item,"rdr"))  strcpy(var.rdr,value);
    else if ( !strcmp(item,"voln")) var.voln = atoi(value);
    else if ( !strcmp(item,"swpn")) var.swpn = atoi(value);
    else if ( !strcmp(item,"rayn")) var.rayn = atoi(value);
    else if ( !strcmp(item,"help")) var.help = atoi(value);
    else if ( !strcmp(item,"disp")) var.disp = atoi(value);
  }
  if (strlen(var.stn_cd) < 3) return -1;

  // ��û�ð� ����
  if (strlen(tm) >= 12) {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  var.YY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  var.MM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  var.DD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  var.HH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  var.MI = atoi(tmp);
    var.seq = time2seq(var.YY, var.MM, var.DD, var.HH, var.MI, 'm');
  }
  else {
    return -1;
  }
  return 0;
}

/*=============================================================================*
 *  HTML Header ���
 *=============================================================================*/
int disp_head()
{
  printf("<html>\n");
  printf("<head>\n");
  printf("<style type='text/css'>\n");
  printf("<!--\n");
  printf("a:link    {color: #0000ff; text-decoration: none;}\n");
  printf("a:visited {color: #0000ff; text-decoration: none;}\n");
  printf("a:active  {color: #ff0000; text-decoration: none;}\n");
  printf("a:hover   {color: #0000ff; text-decoration: underline;}\n");
  printf(".head  {font-family:'����','Verdana'; font-size:11pt; color: #222222; font-weight:bold;}\n");
  printf(".ehead {font-family:'���� ����','����','Verdana'; font-size:10pt; color:#000000; font-weight:bold;}\n");
  printf(".name  {font-family:'���� ����','����','Verdana'; font-size:10pt; color:#000000; font-weight:bold;}\n");
  printf(".text1 {font-family:'Courier New','����ü','Verdana'; font-size:9pt; color:#000000;}\n");
  printf(".text2 {font-family:'Courier New','����ü','Verdana'; font-size:9pt; color:#333333;}\n");
  printf(".text3 {font-family:'Courier New','����ü','Verdana'; font-size:9pt; color:#0000ff; font-weight:bold; cursor:hand;}\n");
  printf(".point {font-family:'����','Verdana'; font-size:9pt; color:#000000; font-weight:bold;}\n");
  printf("-->\n");
  printf("</style>\n");

  printf("<SCRIPT LANGUAGE='JavaScript'>\n");
  printf("<!--\n");
  // ���ŵ� ���̴� ����Ʈ ���� Ȯ��
  printf("function rdr_uf_view(tm, stn, rdr, voln, swpn, rayn) {\n");
  printf("  url = \"/cgi-bin/rdr_test/nph-rdr_file_uf_test?tm=\" + tm + \"&stn=\" + stn + \"&rdr=\" + rdr;\n");
  printf("  url += \"&voln=\" + voln + \"&swpn=\" + swpn + \"&rayn=\" + rayn;\n");
  printf("  window.open(url,\"\",\"location=yes,left=30,top=30,width=900,height=800,scrollbars=yes,resizable=yes\");\n");
  printf("}\n");

  printf("// -->\n");
  printf("</SCRIPT>\n");
  printf("</head>\n");
  return 0;
}

/******************************************************************************
 *  UF ���� �⺻ ���� ǥ��
 ******************************************************************************/
int disp_uf()
{
  int    first;
  int    i, j, k;

  // 1. HTML ���·� ǥ��
  if (var.disp != 1) {
    // 1.1. ���ϸ�
    printf("<span class=name>���� : %s</span>\n", var.fname);

    // 1.2. �⺻ ����
    printf("<table border=1 cellspacing=0 cellpadding=2 bordercolor=#9d9c9c bordercolordark=#ffffff>\n");
    printf("<tr class=name align=center bgcolor=#ffffaa>\n");
    printf("  <td width=60>����</td>\n");
    printf("  <td width=400>����</td>\n");
    printf("</tr>\n");

    printf("<tr class=text1><td align=right>�ð�</td><td align=left>%04d.%02d.%02d.%02d:%02d:%f</td></tr>\n",
      radar->h.year, radar->h.month, radar->h.day, radar->h.hour, radar->h.minute, radar->h.sec);
    printf("<tr class=text1><td align=right>���� ����</td><td align=left>%s</td></tr>\n",
      radar->h.radar_type);
    printf("<tr class=text1><td align=right>����</td><td align=left>%3d�� %02d�� %02d��</td></tr>\n",
      radar->h.latd, radar->h.latm, radar->h.lats);
    printf("<tr class=text1><td align=right>�浵</td><td align=left>%3d�� %02d�� %02d��</td></tr>\n",
      radar->h.lond, radar->h.lonm, radar->h.lons);
    printf("<tr class=text1><td align=right>�ع߰���</td><td align=left>%d m</td></tr>\n",
      radar->h.height);
    printf("</table><p>\n");

    // 1.3. ���� �� ���� ����
    printf("<table border=1 cellspacing=0 cellpadding=2 bordercolor=#9d9c9c bordercolordark=#ffffff>\n");
    printf("<tr class=name align=center bgcolor=#ffffaa>\n");
    printf("  <td width=50>Vol.</td>\n");
    printf("  <td width=50>Sweep<br>����</td>\n");
    printf("  <td width=50>Sweep<br>Num.</td>\n");
    printf("  <td width=70>������<br>(deg.)</td>\n");
    printf("  <td width=50>Ray<br>����</td>\n");
    printf("  <td width=50>bin<br>����</td>\n");
    printf("  <td width=50>gate<br>(m)</td>\n");
    printf("  <td width=50>bin1<br>(m)</td>\n");
    printf("  <td width=60>����<br>(deg.)</td>\n");
    printf("  <td width=60>nyq_vel<br>(m/s)</td>\n");
    printf("</tr>\n");

    for (k = 0; k < radar->h.nvolumes; k++) {
      if ((volume = radar->v[k]) == NULL) continue;

      // ���� ����
      for (first = 0, j = 0; j < volume->h.nsweeps; j++) {
        if ((sweep = volume->sweep[j]) == NULL) continue;

        // ���� �⺻���� �Ϻθ� ó�� ray���� ����
        for (i = 0; i < sweep->h.nrays; i++) {
          if ((ray = sweep->ray[i]) != NULL) break;
        }

        // ǥ��
        printf("<tr class=text1 align=center>\n");
        if (first == 0) {
          printf("  <td rowspan=%d>%d<br>%s</td>\n", volume->h.nsweeps, k, vol_inf[k].vol_cd);
          printf("  <td rowspan=%d>%d</td>\n", volume->h.nsweeps, volume->h.nsweeps);
        }
        printf("  <td><a class=text3 onClick=\"javascript:rdr_uf_view('%04d%02d%02d%02d%02d','%s','%s',%d,%d,-1);\">%d</a></td>\n",
          var.YY, var.MM, var.DD, var.HH, var.MI, var.stn_cd, var.rdr, k, j, j);
        printf("  <td>%.6f</td>\n", sweep->h.elev);
        printf("  <td>%d</td>\n", sweep->h.nrays);
        if (ray != NULL) {
          printf("  <td>%d</td>\n", ray->h.nbins);
          printf("  <td>%d</td>\n", ray->h.gate_size);
          printf("  <td>%d</td>\n", ray->h.range_bin1);
          printf("  <td>%.6f</td>\n", ray->h.beam_width);
          printf("  <td>%.2f</td>\n", ray->h.nyq_vel);
        }
        else {
          printf("  <td colspan=5>ray is NULL</td>\n");
        }
        if (first == 0) first = 1;
      }
      printf("</tr>\n");
    }
    printf("</table>\n");
  }

  // 2. CSV ���·� ���
  else {
    // 2..1 �⺻����
    printf("A,file,%s,=\n", var.fname);
    printf("A,time,%04d.%02d.%02d.%02d:%02d:%f,=\n",
            radar->h.year, radar->h.month, radar->h.day, radar->h.hour, radar->h.minute, radar->h.sec);
    printf("A,type,%s,=\n", radar->h.radar_type);
    printf("A,lat,%3d:%02d:%02d,=\n", radar->h.latd, radar->h.latm, radar->h.lats);
    printf("A,lon,%3d:%02d:%02d,=\n", radar->h.lond, radar->h.lonm, radar->h.lons);
    printf("A,ht,%d,=\n", radar->h.height);

    // 2.2. ���� �� ���� ����
    printf("C,VOL,SWEEP����,SWEEP_NUM,������(deg),Ray����,bin����,gate(m),bin1(m),����(deg),nyq_vel(m/s),=\n");

    for (k = 0; k < radar->h.nvolumes; k++) {
      if ((volume = radar->v[k]) == NULL) continue;

      // ���� ����
      for (first = 0, j = 0; j < volume->h.nsweeps; j++) {
        if ((sweep = volume->sweep[j]) == NULL) continue;

        // ���� �⺻���� �Ϻθ� ó�� ray���� ����
        for (i = 0; i < sweep->h.nrays; i++) {
          if ((ray = sweep->ray[i]) != NULL) break;
        }

        // ǥ��
        printf("B,%d,%s,", k, vol_inf[k].vol_cd);
        printf("%d,", volume->h.nsweeps);
        printf("%d,", j);
        printf("%.6f,", sweep->h.elev);
        printf("%d,", sweep->h.nrays);
        if (ray != NULL) {
          printf("%d,", ray->h.nbins);
          printf("%d,", ray->h.gate_size);
          printf("%d,", ray->h.range_bin1);
          printf("%.6f,", ray->h.beam_width);
          printf("%.2f,", ray->h.nyq_vel);
        }
        else {
          printf("%d,", -99);
          printf("%d,", -99);
          printf("%d,", -99);
          printf("%.6f,", -99);
          printf("%.2f,", -99);
        }
        printf("=\n");
        if (first == 0) first = 1;
      }
    }
  }
  return 0;
}

/******************************************************************************
 *  UF ���� ������ Sweep ���� ǥ��
 ******************************************************************************/
int disp_sweep()
{
  int  i;

  // 1. HTML ���·� ǥ��
  if (var.disp != 1) {
    printf("<span class=name>���� : %s , Voln = %d , Sweep = %d</span>\n", var.fname, var.voln, var.swpn);
    sweep = radar->v[var.voln]->sweep[var.swpn];
    if (sweep == NULL) {
      printf("sweep is NULL\n");
      return -1;
    }

    printf("<table border=1 cellspacing=0 cellpadding=2 bordercolor=#9d9c9c bordercolordark=#ffffff>\n");
    printf("<tr class=name align=center bgcolor=#ffffaa>\n");
    printf("  <td width=50>Ray<br>Num.</td>\n");
    printf("  <td width=80>������<br>(deg.)</td>\n");
    printf("  <td width=50>bin<br>����</td>\n");
    printf("  <td width=50>gate<br>(m)</td>\n");
    printf("  <td width=50>bin1<br>(m)</td>\n");
    printf("  <td width=70>����<br>(deg.)</td>\n");
    printf("  <td width=60>nyq_vel<br>(m/s)</td>\n");
    printf("  <td width=70>0 th</td>\n");
    printf("  <td width=70>50 th</td>\n");
    printf("  <td width=70>100 th</td>\n");
    printf("  <td width=70>200 th</td>\n");
    printf("  <td width=70>300 th</td>\n");
    printf("</tr>\n");

    for (i = 0; i < sweep->h.nrays; i++) {
      if ((ray = sweep->ray[i]) == NULL) continue;

      printf("<tr class=text1 align=center>\n");
      printf("  <td><a class=text3 onClick=\"javascript:rdr_uf_view('%04d%02d%02d%02d%02d','%s','%s',%d,%d,%d);\">%d</a></td>\n",
          var.YY, var.MM, var.DD, var.HH, var.MI, var.stn_cd, var.rdr, var.voln, var.swpn, i, ray->h.ray_num);
      //printf("  <td>%d</td>\n", ray->h.ray_num);
      printf("  <td>%.6f</td>\n", ray->h.azimuth);
      printf("  <td>%d</td>\n", ray->h.nbins);
      printf("  <td>%d</td>\n", ray->h.gate_size);
      printf("  <td>%d</td>\n", ray->h.range_bin1);
      printf("  <td>%.6f</td>\n", ray->h.beam_width);
      printf("  <td>%.2f</td>\n", ray->h.nyq_vel);
      printf("  <td align=right>%.2f</td>\n", ray->h.f(ray->range[0]));
      printf("  <td align=right>%.2f</td>\n", ray->h.f(ray->range[50]));
      printf("  <td align=right>%.2f</td>\n", ray->h.f(ray->range[100]));
      printf("  <td align=right>%.2f</td>\n", ray->h.f(ray->range[200]));
      printf("  <td align=right>%.2f</td>\n", ray->h.f(ray->range[300]));
      printf("</tr>\n");
    }
    printf("</table>\n");
  }

  // 2. CSV ���·� ���
  else {
    printf("A,file,%s,=\n", var.fname);
    printf("A,voln,%d,=\n", var.voln);
    printf("A,swpn,%d,=\n", var.swpn);
    sweep = radar->v[var.voln]->sweep[var.swpn];
    if (sweep == NULL) {
      printf("# sweep is NULL\n");
      return -1;
    }

    printf("C,Ray Num,������(deg),bin����,gate(m),bin1(m),����(deg),nyq_vel(m/s),0-th,50-th,100-th,200-th,300-th,=\n");

    for (i = 0; i < sweep->h.nrays; i++) {
      if ((ray = sweep->ray[i]) == NULL) continue;

      printf("%d,", ray->h.ray_num);
      printf("%.6f,", ray->h.azimuth);
      printf("%d,", ray->h.nbins);
      printf("%d,", ray->h.gate_size);
      printf("%d,", ray->h.range_bin1);
      printf("%.6f,", ray->h.beam_width);
      printf("%.2f,", ray->h.nyq_vel);
      printf("%.2f,", ray->h.f(ray->range[0]));
      printf("%.2f,", ray->h.f(ray->range[50]));
      printf("%.2f,", ray->h.f(ray->range[100]));
      printf("%.2f,", ray->h.f(ray->range[200]));
      printf("%.2f,", ray->h.f(ray->range[300]));
      printf("=\n");
    }
  }
  return 0;
}

/******************************************************************************
 *  UF ���� Sweep�� ray�� ǥ��
 ******************************************************************************/
int disp_ray()
{
  int  i;

  printf("<span class=name>���� : %s / Voln = %d / Sweep = %d / Ray = %d</span>\n", var.fname, var.voln, var.swpn, var.rayn);
  ray = radar->v[var.voln]->sweep[var.swpn]->ray[var.rayn];
  if (ray == NULL) {
    printf("Ray is NULL\n");
    return -1;
  }

  printf("<pre class=text1>\n");
  printf("     |");
  for (i = 0; i < 10; i++)
    printf(" %9d", i);
  printf("\n");

  for (i = 0; i < 106; i++)
    printf("-");
  printf("\n");

  for (i = 0; i < ray->h.nbins; i++) {
    if (i%10 == 0) printf("%4d |", i);
    printf(" %9.2f", ray->h.f(ray->range[i]));
    if ((i+1)%10 == 0) printf("\n");
  }
  if (ray->h.nbins%10 != 0) printf("\n");
  printf("</pre>\n");
  return 0;
}

/*=============================================================================*
 *  ���̴� UF�ڷ� ���� ���� Ȯ��
 *=============================================================================*/
int rdr_uf_file()
{
  struct stat st;
  int    code;

  if (strcmp(var.rdr,"QCD") == 0)
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_FQC_%04d%02d%02d%02d%02d.uf",
            RDR_UF_QCD_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
  else if (strcmp(var.rdr,"FQC") == 0)
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_FQC_%04d%02d%02d%02d%02d.uf",
            RDR_UF_QCD_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
  else if (strcmp(var.rdr,"NQS") == 0)
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_NQS_%04d%02d%02d%02d%02d.uf",
            RDR_UF_RAW_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
  else if (strcmp(var.rdr,"HSR") == 0)
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_HSR2_%04d%02d%02d%02d%02d.uf",
            RDR_UF_HSR_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
  else if (strcmp(var.rdr,"HCI") == 0)
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_HCI_%04d%02d%02d%02d%02d.uf",
            RDR_UF_HCI_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
  else if (strcmp(var.rdr,"LNG") == 0)
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_LNG_%04d%02d%02d%02d%02d.uf",
            RDR_UF_LNG_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
  else if (strcmp(var.rdr,"LNG_FQC") == 0)
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_LNG_FQC_%04d%02d%02d%02d%02d.uf",
            RDR_UF_LNG_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
  else if (strcmp(var.rdr,"VER") == 0)
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_VER_%04d%02d%02d%02d%02d.uf",
            RDR_UF_VER_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
  else if (strcmp(var.rdr,"BK") == 0)
    sprintf(var.fname, "/rdr/REF/HSR/RDR_%s_REAL_TIME_BK.uf", var.stn_cd);
  else if (strcmp(var.rdr,"RAW") == 0)
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_%04d%02d%02d%02d%02d.uf",
            RDR_UF_RAW_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
  code = stat(var.fname, &st);
  var.size = st.st_size;
  if (code < 0) {
    if (strcmp(var.rdr,"HSR") == 0) {
      sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_HSR1_%04d%02d%02d%02d%02d.uf",
              RDR_UF_HSR_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
      code = stat(var.fname, &st);
    }
    else if (strcmp(var.rdr,"QCD") == 0) {
      sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_QCD_%04d%02d%02d%02d%02d.uf",
              RDR_UF_QCD_DIR, var.YY, var.MM, var.DD, var.stn_cd, var.YY, var.MM, var.DD, var.HH, var.MI);
      code = stat(var.fname, &st);
    }
    if (code < 0) return -1;
    var.size = st.st_size;
    if (st.st_size <= 100) return -1;
  }
  else if (st.st_size <= 100)
    return -1;
  else
    return 0;
}
