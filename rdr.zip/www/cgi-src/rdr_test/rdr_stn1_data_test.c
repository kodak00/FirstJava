/*******************************************************************************
 *
 *  ���̴� �������ڷ� ǥ�⿡�� ���̴��ڷ� �д� �κ�
 *
 *******************************************************************************/
#include "rdr_stn1_img_test.h"

extern struct INPUT_VAR  var;
extern struct VOL_LIST vol_inf[];

extern Radar  *radar;
extern Volume *volume;
extern Sweep  *sweep;
extern Ray    *ray;

extern float  range_bin1[], gate_size[], range_max[], elev[];
extern float  *swp_h[];
extern short  *swp_bin[], *swp_ray[];
extern short  nbin_max[], swp_ec[], swp_ht[];

// �Լ� ����
int rdr_swp_bin(float, float, float, float, short, short *, float *);

/*=============================================================================*
 *  ���̴� �������ڷῡ�� Vol ���� ���� Ȯ��
 *=============================================================================*/
int rdr_stn_vol_chk()
{
  int    ok, i, j, k;

  // 1. ���� ��ȣ Ȯ��
  var.voln = -1;
  for (k = 0; k < 47; k++) {
    if (strcmp(vol_inf[k].vol_cd, var.obs) == 0) {
      var.voln = vol_inf[k].voln;
      break;
    }
  }

  // 2. UF���� ����
  radar = RSL_uf_to_radar(var.fname);
  if (radar == NULL) return -1;
  var.stn_lon = radar->h.lond + (radar->h.lonm + (radar->h.lons)/60.0)/60.0;
  var.stn_lat = radar->h.latd + (radar->h.latm + (radar->h.lats)/60.0)/60.0;
  var.stn_ht  = radar->h.height;

  // 3. �ش� ������ �ִ��� Ȯ��
  ok = -1;
  if (var.voln >= 0) {
    for (k = 0; k < radar->h.nvolumes; k++) {
      if ((volume = radar->v[k]) == NULL) continue;
      if (k == var.voln) {
        ok = 0;
        break;
      }
    }
  }
  if (ok < 0) return ok;

  // 4. ������ Ȯ��
  var.swp_deg = -99;
  if (ok == 0) {
    for (j = 0; j < volume->h.nsweeps; j++) {
      if ((sweep = volume->sweep[j]) == NULL) continue;
      if (j == var.swpn) {
        var.swp_deg = sweep->h.elev;
        ok = 1;
        break;
      }
    }
  }

  // 5. ���޹��� Ȯ��
  if (ok == 1 && var.area == 1) {
    for (i = 0; i < sweep->h.nrays; i++) {
      if ((ray = sweep->ray[i]) != NULL) {
        var.range  = ray->h.nbins*ray->h.gate_size + ray->h.range_bin1;
        break;
      }
    }
  }

  // 6. ����� ���� ��ȯ�迭 ���
  for (j = 0; j < radar->v[var.voln]->h.nsweeps; j++) {
    if ((sweep = radar->v[var.voln]->sweep[j]) == NULL) continue;

    // 6.1. ���� ������ ray��ġ �迭 ����
    swp_ray[j] = svector(0,3600);
    rdr_swp_ray(var.stn, sweep, swp_ray[j]);

    // 6.2. ����Ÿ� ��� ���� bin��ġ�� ������ �迭 ����
    for (i = 0; i < sweep->h.nrays; i++) {
      if ((ray = sweep->ray[i]) != NULL) {
        range_bin1[j] = ray->h.range_bin1;
        gate_size[j]  = ray->h.gate_size;
        nbin_max[j]   = ray->h.nbins;
        break;
      }
    }
    if (strcmp(var.cmp,"HSR") == 0 || strcmp(var.cmp,"VER") == 0 ||
        strcmp(var.cmp,"LNG") == 0 || strcmp(var.cmp,"LNG_FQC") == 0)
      elev[j] = 0;
    else
      elev[j] = sweep->h.elev;

    swp_bin[j] = svector(0,nbin_max[j]*4);
    swp_h[j] = vector(0,nbin_max[j]*4);
    rdr_swp_bin(elev[j], var.stn_ht, range_bin1[j], gate_size[j], nbin_max[j], swp_bin[j], swp_h[j]);
  }
  return ok;
}

/*=============================================================================*
 *  ���� ������ ray��ġ�� ����� �迭 ����(0.1�� �������� ��)
 *=============================================================================*/
int rdr_swp_ray(
  char  *stn_cd,    // �����ڵ�
  Sweep *sweep,     // ���̴� �����ڷ�
  short *swp_ray    // �������� ray ��ġ
)
{
  Ray    *ray;
  float  az0, az1, az2, az3, az4;
  int    i, j, k, i1, i2;

  if (strcmp(stn_cd,"IIA") == 0)  // ��õ������ �ںϱ���
    az4 = -7.53;
  else
    az4 = 0.0;

  for (i = 0; i < 3600; i++)
    swp_ray[i] = -1;

  for (j = 0; j < sweep->h.nrays; j++) {
    if ((ray = sweep->ray[j]) == NULL) continue;
    if (ray->h.beam_width == 0) ray->h.beam_width = 1.0;

    az0 = ray->h.azimuth + az4;
    if (az0 < 0) az0 += 360;
    if (az0 >= 360) az0 -= 360;

    az1 = (az0 - 0.65*ray->h.beam_width)*10;
    az2 = (az0 + 0.65*ray->h.beam_width)*10;

    i1 = floor(az1);
    i2 = ceil(az2);

    if (i1 >= 0 && i2 < 3600) {
      for (i = i1; i <= i2; i++) {
        az3 = i;
        if (az3 >= az1 && az3 < az2) swp_ray[i] = j;
      }
    }
    else if (i1 < 0) {
      for (i = 0; i <= i2; i++) {
        az3 = i;
        if (az3 >= az1 && az3 < az2) swp_ray[i] = j;
      }
      for (i = 3600+i1-1; i < 3600; i++) {
        az3 = i;
        if (az3 >= az1+3600 && az3 < 3600) swp_ray[i] = j;
      }
    }
    else if (i2 >= 3600) {
      for (i = i1; i < 3600; i++) {
        az3 = i;
        if (az3 >= az1 && az3 < az2) swp_ray[i] = j;
      }
      for (i = 0; i <= i2-3600; i++) {
        az3 = i;
        if (az3 >= 0 && az3 < az2-3600) swp_ray[i] = j;
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  ����Ÿ� ��� ���� bin��ġ�� ������ �迭 ����(�ػ� 4��� ��)
 *=============================================================================*/
int rdr_swp_bin(
  float elev,       // ������(degree)
  float stn_ht,     // ���׳� �ع߰���(m)
  float range_bin1, // 1th ���� ��ġ(m)
  float gate_size,  // gate ũ��(m)
  short nbin_max,   // gate ����
  short *swp_bin,   // [���] ��ġ
  float *swp_h      // [���] ����(m)
)
{
  double alpha, cs, ss, re1, s, r;
  double range_max = gate_size*nbin_max + range_bin1;   // �ִ�Ÿ�(m)
  int    nbin_max1 = nbin_max*4;
  int    i, i1;

  re1 = 4.0*(RE + stn_ht)/3.0;
  cs = cos(elev*DEGRAD);
  ss = sin(elev*DEGRAD);

  for (i = 0; i < nbin_max1; i++) {
    swp_bin[i] = -1;
    swp_h[i] = -1;

    s = 0.25*gate_size*i;
    alpha = 1 - pow((double)(cs/sin(s/re1)), (double)(2.0));
    r = -(re1/alpha)*(sqrt(ss*ss - alpha) + ss);
    if (r >= range_max || r <= 0) continue;

    i1 = (int)((r - range_bin1)/gate_size);   // �� ������ s��ġ�� �ش��ϴ� gate��ġ
    if (i1 >= nbin_max-1) continue;

    swp_bin[i] = i1;
    swp_h[i] = sqrt(r*r + re1*re1 + 2.0*ss*r*re1) - re1 + stn_ht;
  }
  return 0;
}

/*=============================================================================*
 *  ���̴� �������ڷ� ���� ���� Ȯ��
 *=============================================================================*/
int rdr_stn_file()
{
  struct stat st;
  int    YY, MM, DD, HH, MI;
  int    code, rtn;

  // 1. �ڷ� �ð�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  // 2. ���ϸ�
  if (strcmp(var.cmp,"RAW") == 0) {
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_%04d%02d%02d%02d%02d.uf",
            RDR_RAW_DIR, YY, MM, DD, var.stn, YY, MM, DD, HH, MI);
  }
  else if (strcmp(var.cmp,"QCD") == 0) {
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_FQC_%04d%02d%02d%02d%02d.uf",
            RDR_QCD_DIR, YY, MM, DD, var.stn, YY, MM, DD, HH, MI);
  }
  else if (strcmp(var.cmp,"HSR") == 0) {
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_HSR2_%04d%02d%02d%02d%02d.uf",
            RDR_HSR_DIR, YY, MM, DD, var.stn, YY, MM, DD, HH, MI);
  }
  else if (strcmp(var.cmp,"HCI") == 0) {
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_HCI_%04d%02d%02d%02d%02d.uf",
            RDR_HCI_DIR, YY, MM, DD, var.stn, YY, MM, DD, HH, MI);
  }
  else if (strcmp(var.cmp,"LNG") == 0) {
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_LNG_%04d%02d%02d%02d%02d.uf",
            RDR_LNG_DIR, YY, MM, DD, var.stn, YY, MM, DD, HH, MI);
  }
  else if (strcmp(var.cmp,"LNG_FQC") == 0) {
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_LNG_FQC_%04d%02d%02d%02d%02d.uf",
            RDR_LNG_DIR, YY, MM, DD, var.stn, YY, MM, DD, HH, MI);
  }
  else if (strcmp(var.cmp,"VER") == 0) {
    sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_VER_%04d%02d%02d%02d%02d.uf",
            RDR_VER_DIR, YY, MM, DD, var.stn, YY, MM, DD, HH, MI);
  }

  // 3. ���� ���� ���� Ȯ��
  code = stat(var.fname, &st);
  if (code < 0 || st.st_size <= 100) {
    if (strcmp(var.cmp,"HSR") == 0) {
      sprintf(var.fname, "%s/%04d%02d/%02d/RDR_%s_HSR1_%04d%02d%02d%02d%02d.uf",
              RDR_HSR_DIR, YY, MM, DD, var.stn, YY, MM, DD, HH, MI);
      code = stat(var.fname, &st);
      if (code < 0 || st.st_size <= 100)
        rtn = -1;
      else
        rtn = 0;
    }
    else
      rtn = -1;
  }
  else
    rtn = 0;
  return rtn;
}

/*=============================================================================*
 *  Z-R �����
 *     - mode : 0(dBZ->������), 1(������->dBZ)
 *=============================================================================*/
int dbz_rain_conv(float *dbz, float *rain, int mode)
{
  static int first = 0;
  static float za, zb;

  if (first == 0) {
    za = 0.1/var.ZRb;
    zb = log10(var.ZRa)/var.ZRb;
    first = 1;
  }

  if (mode == 0) {
    //*rain = (*dbz*0.1 - log10(var.ZRa) )/var.ZRb;
    *rain = *dbz*za - zb;
    *rain = pow(10.0, *rain);
  }
  else if (mode == 1) {
    *dbz = 10.0 * log10( var.ZRa * pow(*rain, var.ZRb) );
  }
  return 0;
}
