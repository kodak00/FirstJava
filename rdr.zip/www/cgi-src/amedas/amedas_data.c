/*******************************************************************************
**
**  URL �Լ� �̿��� ���� AWS+AMEDAS �ڷῡ �ִ� �����м��� CGI ���α׷�
**
**=============================================================================*
**
**   o �ۼ��� : ����ȯ (2018.7.3)
**
********************************************************************************/
#include "amedas_img.h"

extern struct INPUT_VAR var;       // ����� �Է� ����
extern struct STN_VAL stn_data[];  // ���� �ڷ�
extern float  **g;                 // �����м����

/*******************************************************************************
 *
 *  �����ڷ� �� �̹��� ǥ��� ����� ��û �м� �κ�
 *
 *******************************************************************************/
int user_input() {
  char *qs;
  char tmp[256], item[32], value[32], tm[30], tm_st[30];
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, bn_set = 0, zr, i, j;

  // 1. ���� �ʱⰪ : �ڷẰ ó�� ���α׷����� ���� ��Ȳ�� �°� ����
  strcpy(tm, "0");    // ����ð�
  strcpy(var.obs, "ta");  // ���
  strcpy(var.map, "HD");  // HD����
  strcpy(var.obj, "mq");  // MQ������� �����м�
  var.grid = 4.0;         // km ����
  var.itv  = 1;
  var.sms  = 0;
  var.stn  = 9;         // �ִ��ְ��� ����
  var.zoom_level = 0;   // ��ü����
  var.zoom_rate = 2;    // 2�� Ȯ�밡 �⺻
  var.mq_mp = 0.0005;   // MQ: ����1
  var.mq_sm = 1.0;      // MQ: ����2
  var.bn_r1 = 30;       // Barnes: 1�� �ݰ� = 30km
  var.bn_r2 = 10;       // Barnes: 2�� �ݰ� = 10km
  var.title = 1;        // ���� ǥ�� ����(1:ǥ��, 0:ǥ�� ����)
  strcpy(var.color, "C4");  // ����ǥ
  var.disp = 0;
  var.help = 0;

  // 2. GET ������� ���޵� ����� �Էº������� �ص�
  qs = getenv ("QUERY_STRING");
  if (qs == NULL) return -1;

  for (i = 0; qs[0] != '\0'; i++) {
    getword (value, qs, '&');
    getword (item, value, '=');

    if      ( !strcmp(item,"ctg")) strcpy(var.ctg, value);
    else if ( !strcmp(item,"obs")) strcpy(var.obs, value);
    else if ( !strcmp(item,"gov")) {
      for (var.num_gov = 0, j = 0; value[0] != '\0'; j++) {
        getword (tmp, value, ':');
        if (strlen(tmp) >= 3) {
          strcpy(var.gov_cd[var.num_gov], tmp);
          var.num_gov++;
        }
      }
    }
    else if ( !strcmp(item,"map")) strcpy(var.map, value);
    else if ( !strcmp(item,"obj")) strcpy(var.obj, value);
    else if ( !strcmp(item,"stn")) var.stn = atoi(value);
    else if ( !strcmp(item,"tm"))  strcpy(tm, value);
    else if ( !strcmp(item,"tm_st")) strcpy(tm_st, value);
    else if ( !strcmp(item,"grid")) var.grid = atof(value);
    else if ( !strcmp(item,"itv")) var.itv = atoi(value);
    else if ( !strcmp(item,"sms")) var.sms = atoi(value);
    else if ( !strcmp(item,"zoom_level")) var.zoom_level = atoi(value);
    else if ( !strcmp(item,"zoom_rate"))  var.zoom_rate = atoi(value);
    else if ( !strcmp(item,"zoom_x")) strcpy(var.zoom_x, value);
    else if ( !strcmp(item,"zoom_y")) strcpy(var.zoom_y, value);
    else if ( !strcmp(item,"mp"))   var.mq_mp = atof(value);
    else if ( !strcmp(item,"sm"))   var.mq_sm = atof(value);
    else if ( !strcmp(item,"r1")) { var.bn_r1 = atof(value);  bn_set = 1; }
    else if ( !strcmp(item,"r2")) { var.bn_r1 = atof(value);  bn_set = 1; }
    else if ( !strcmp(item,"disp")) var.disp = atoi(value);
    else if ( !strcmp(item,"size")) var.size = atoi(value);
    else if ( !strcmp(item,"color")) strcpy(var.color, value);
    else if ( !strcmp(item,"legend")) var.legend = atoi(value);
    else if ( !strcmp(item,"title")) var.title = atoi(value);
    else if ( !strcmp(item,"help")) var.help = atoi(value);
  }
  if (var.grid < 0.001) var.grid = 4.0;
  if (var.num_gov == 0) {        // GOV�� ������ ���û�� ó��
    strcpy(var.gov_cd[0],"KMA");
    var.num_gov = 1;
  }

  // 3. ����ð� �� ���� �����ð� ����
  get_time(&iYY, &iMM, &iDD, &iHH, &iMI, &iSS);
  iseq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm') - 3;
  seq2time(iseq, &iYY, &iMM, &iDD, &iHH, &iMI, 'm', 'n');

  // 4. ��û�ð� ����
  if (strlen(tm) >= 10) {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
  }
  var.seq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  //if (var.itv > 1) var.seq = (int)(var.seq/var.itv)*var.itv;

  // 5. ���۽ð� ���� (�ִ� ���)
  if (strlen(tm_st) >= 10) {
    strncpy(tmp, &tm_st[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm_st[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm_st[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm_st[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm_st[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
  }
  var.seq_st = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');

  // 5. ��û�� ������ ��ȣ
  if      (!strcmp(var.obs, "rn_ex"))  { strcpy(var.obs_cd,"RE");  var.varn = 7;   var.missing = -1;  var.max = 1000; }
  else if (!strcmp(var.obs, "rn_15m")) { strcpy(var.obs_cd,"RN");  var.varn = 67;  var.missing = -1;  var.max = 1000; }
  else if (!strcmp(var.obs, "rn_15x")) { strcpy(var.obs_cd,"RN");  var.varn = 67;  var.missing = -1;  var.max = 1000; }
  else if (!strcmp(var.obs, "rn_15d")) { strcpy(var.obs_cd,"RN");  var.varn = 67;  var.missing = -1;  var.max = 1000; }
  else if (!strcmp(var.obs, "rn_60m")) { strcpy(var.obs_cd,"RN");  var.varn = 68;  var.missing = -1;  var.max = 1000; }
  else if (!strcmp(var.obs, "rn_03h")) { strcpy(var.obs_cd,"RN");  var.varn = 69;  var.missing = -1;  var.max = 1000; }
  else if (!strcmp(var.obs, "rn_06h")) { strcpy(var.obs_cd,"RN");  var.varn = 70;  var.missing = -1;  var.max = 1000; }
  else if (!strcmp(var.obs, "rn_12h")) { strcpy(var.obs_cd,"RN");  var.varn = 71;  var.missing = -1;  var.max = 1000; }
  else if (!strcmp(var.obs, "rn_day")) { strcpy(var.obs_cd,"RN");  var.varn = 5;   var.missing = -1;  var.max = 1000; }
  else if (!strcmp(var.obs, "sd_tot")) { strcpy(var.obs_cd,"SD");  var.varn = 8;   var.missing = -1;  var.max = 500;  }
  else if (!strcmp(var.obs, "sd_day")) { strcpy(var.obs_cd,"SD");  var.varn = 8;   var.missing = -1;  var.max = 500;  }
  else if (!strcmp(var.obs, "sd_3hr")) { strcpy(var.obs_cd,"SD");  var.varn = 8;   var.missing = -1;  var.max = 500;  }
  else if (!strcmp(var.obs, "sd_24h")) { strcpy(var.obs_cd,"SD");  var.varn = 8;   var.missing = -1;  var.max = 500;  }
  else if (!strcmp(var.obs, "ws_01m")) { strcpy(var.obs_cd,"WS");  var.varn = 2;   var.missing = -1;  var.max = 100;  }
  else if (!strcmp(var.obs, "wv_01m")) { strcpy(var.obs_cd,"WS");  var.varn = 2;   var.missing = -1;  var.max = 100;  }
  else if (!strcmp(var.obs, "ws_10m")) { strcpy(var.obs_cd,"WS");  var.varn = 66;  var.missing = -1;  var.max = 100;  }
  else if (!strcmp(var.obs, "wv_10m")) { strcpy(var.obs_cd,"WS");  var.varn = 66;  var.missing = -1;  var.max = 100;  }
  else if (!strcmp(var.obs, "wv_10x")) { strcpy(var.obs_cd,"WS");  var.varn = 66;  var.missing = -1;  var.max = 100;  }
  else if (!strcmp(var.obs, "ws_ins")) { strcpy(var.obs_cd,"WS");  var.varn = 4;   var.missing = -1;  var.max = 100;  }
  else if (!strcmp(var.obs, "wv_ins")) { strcpy(var.obs_cd,"WS");  var.varn = 4;   var.missing = -1;  var.max = 100;  }
  else if (!strcmp(var.obs, "ta"))     { strcpy(var.obs_cd,"TA");  var.varn = 0;   var.missing = -41; var.max = 45;   }
  else if (!strcmp(var.obs, "ta_tpo")) { strcpy(var.obs_cd,"TA");  var.varn = 0;   var.missing = -41; var.max = 45;   }
  else if (!strcmp(var.obs, "ta_now")) { strcpy(var.obs_cd,"TA");  var.varn = 0;   var.missing = -41; var.max = 45;   }
  else if (!strcmp(var.obs, "ta_dif")) { strcpy(var.obs_cd,"TA");  var.varn = 0;   var.missing = -49; var.max = 50;   }
  else if (!strcmp(var.obs, "tw"))     { strcpy(var.obs_cd,"HM");  var.varn = 9;   var.missing = -49; var.max = 45;   }
  else if (!strcmp(var.obs, "tw_tpo")) { strcpy(var.obs_cd,"TA");  var.varn = 0;   var.missing = -49; var.max = 45;   }
  else if (!strcmp(var.obs, "td"))     { strcpy(var.obs_cd,"HM");  var.varn = 9;   var.missing = -49; var.max = 45;   }
  else if (!strcmp(var.obs, "wn"))     { strcpy(var.obs_cd,"HM");  var.varn = 9;   var.missing = 0;   var.max = 50;   }
  else if (!strcmp(var.obs, "hm"))     { strcpy(var.obs_cd,"HM");  var.varn = 9;   var.missing = 4;   var.max = 101;  }
  else if (!strcmp(var.obs, "hm_tpo")) { strcpy(var.obs_cd,"TA");  var.varn = 0;   var.missing = -41; var.max = 45;   }
  else if (!strcmp(var.obs, "pv"))     { strcpy(var.obs_cd,"HM");  var.varn = 9;   var.missing = 0;   var.max = 101;  }
  else if (!strcmp(var.obs, "sh"))     { strcpy(var.obs_cd,"HM");  var.varn = 9;   var.missing = 0;   var.max = 101;  }
  else if (!strcmp(var.obs, "mr"))     { strcpy(var.obs_cd,"HM");  var.varn = 9;   var.missing = 0;   var.max = 101;  }
  else if (!strcmp(var.obs, "hm_dci")) { strcpy(var.obs_cd,"HM");  var.varn = 9;   var.missing = 4;   var.max = 101;  }
  else if (!strcmp(var.obs, "ta_chi")) { strcpy(var.obs_cd,"TA");  var.varn = 0;   var.missing = -41; var.max = 45;   }
  else if (!strcmp(var.obs, "ta_chd")) { strcpy(var.obs_cd,"TA");  var.varn = 0;   var.missing = -41; var.max = 1;    }
  else if (!strcmp(var.obs, "pa"))     { strcpy(var.obs_cd,"PA");  var.varn = 6;   var.missing = 600; var.max = 1200; }
  else if (!strcmp(var.obs, "ps1"))    { strcpy(var.obs_cd,"PA");  var.varn = 64;  var.missing = 600; var.max = 1200; }
  else if (!strcmp(var.obs, "ps2"))    { strcpy(var.obs_cd,"PA");  var.varn = 64;  var.missing = 600; var.max = 1200; }
  else if (!strcmp(var.obs, "ps3"))    { strcpy(var.obs_cd,"PA");  var.varn = 64;  var.missing = 600; var.max = 1200; }
  else if (!strcmp(var.obs, "si_60m")) { strcpy(var.obs_cd,"SI");  var.varn = 11;  var.missing =-0.1; var.max = 60000;}
  else if (!strcmp(var.obs, "ss_60m")) { strcpy(var.obs_cd,"SS");  var.varn = 12;  var.missing =-0.1; var.max = 60000;}
  else if (!strcmp(var.obs, "ts"))     { strcpy(var.obs_cd,"TS");  var.varn = 13;  var.missing = -49; var.max = 60;   }
  else if (!strcmp(var.obs, "tg"))     { strcpy(var.obs_cd,"TG");  var.varn = 14;  var.missing = -49; var.max = 60;   }
  else if (!strcmp(var.obs, "ts_ta"))  { strcpy(var.obs_cd,"TS");  var.varn = 13;  var.missing = -40; var.max = 40;   }
  else if (!strcmp(var.obs, "tg_ta"))  { strcpy(var.obs_cd,"TG");  var.varn = 14;  var.missing = -40; var.max = 40;   }
  else if (!strcmp(var.obs, "te_005")) { strcpy(var.obs_cd,"TE005");  var.varn = 15;  var.missing = -35; var.max = 40;  }
  else if (!strcmp(var.obs, "te_010")) { strcpy(var.obs_cd,"TE01");  var.varn = 16;  var.missing = -35; var.max = 40;   }
  else if (!strcmp(var.obs, "te_020")) { strcpy(var.obs_cd,"TE02");  var.varn = 17;  var.missing = -35; var.max = 40;   }
  else if (!strcmp(var.obs, "te_030")) { strcpy(var.obs_cd,"TE03");  var.varn = 18;  var.missing = -35; var.max = 40;   }
  else if (!strcmp(var.obs, "te_050")) { strcpy(var.obs_cd,"TE05");  var.varn = 19;  var.missing = -35; var.max = 40;   }
  else if (!strcmp(var.obs, "te_100")) { strcpy(var.obs_cd,"TE10");  var.varn = 20;  var.missing = -35; var.max = 40;   }
  else if (!strcmp(var.obs, "te_150")) { strcpy(var.obs_cd,"TE15");  var.varn = 21;  var.missing = -35; var.max = 40;   }
  else if (!strcmp(var.obs, "te_300")) { strcpy(var.obs_cd,"TE30");  var.varn = 22;  var.missing = -35; var.max = 40;   }
  else if (!strcmp(var.obs, "te_500")) { strcpy(var.obs_cd,"TE50");  var.varn = 23;  var.missing = -35; var.max = 40;   }
  else if (strstr(var.obs,  "ps_m"))   { strcpy(var.obs_cd,"PA");    var.varn = 64;  var.missing = 600; var.max = 1200; }
  else if (strstr(var.obs,  "ps_d"))   { strcpy(var.obs_cd,"PA");    var.varn = 64;  var.missing = 600; var.max = 1200; }
  else if (!strcmp(var.obs, "vs"))     { strcpy(var.obs_cd,"VS");    var.varn = 28;  var.missing = 0;   var.max = 60000;}
  else if (!strcmp(var.obs, "ca_tot")) { strcpy(var.obs_cd,"EM");    var.varn = 27;  var.missing = -1;  var.max = 11;   }
  else if (!strcmp(var.obs, "ca_mid")) { strcpy(var.obs_cd,"EM");    var.varn = 27;  var.missing = -1;  var.max = 11;   }
  else if (!strcmp(var.obs, "ca"))     { strcpy(var.obs_cd,"CH");    var.varn = 27;  var.missing = -1;  var.max = 11;   }
  else if (!strcmp(var.obs, "ch"))     { strcpy(var.obs_cd,"CH");    var.varn = 24;  var.missing = 0;   var.max = 7.620;}
  else if (!strcmp(var.obs, "pm10"))   { strcpy(var.obs_cd,"PM10");  var.varn = 29;  var.missing = 0;   var.max = 10000;}
  else if (!strcmp(var.obs, "me_10i")) { strcpy(var.obs_cd,"PM10");  var.varn = 29;  var.missing = 0;   var.max = 10000;}
  else if (!strcmp(var.obs, "moe"))    { strcpy(var.obs_cd,"PM10");  var.varn = 29;  var.missing = 0;   var.max = 10000;}
  else if (!strcmp(var.obs, "uw_10m")) { strcpy(var.obs_cd,"SW");    var.varn = 73;  var.missing = -1;  var.max = 100;  }
  else if (!strcmp(var.obs, "ww_lee")) { strcpy(var.obs_cd,"TA");  var.varn = 0;   var.missing = -49; var.max = 45;   }
  else if (!strcmp(var.obs, "ww_aws")) { strcpy(var.obs_cd,"TA");  var.varn = 0;   var.missing = -49; var.max = 45;   }

  // 6. Barnes����� ���, ��ҿ� ���� �⺻ �ݰ��� ���� (�⺻�� ����)
  if (!strcmp(var.obj,"bn") && bn_set == 0) {
    if (!strcmp(var.obs,"sd")) { var.bn_r1 = 50;  var.bn_r2 = 20; }
    if (!strcmp(var.obs,"hm")) { var.bn_r1 = 40;  var.bn_r2 = 15; }
    if (!strcmp(var.obs,"pv")) { var.bn_r1 = 40;  var.bn_r2 = 15; }
    if (!strcmp(var.obs,"sh")) { var.bn_r1 = 40;  var.bn_r2 = 15; }
    if (!strcmp(var.obs,"mr")) { var.bn_r1 = 40;  var.bn_r2 = 15; }
    if (!strcmp(var.obs,"ps")) { var.bn_r1 = 40;  var.bn_r2 = 15; }
    if (!strcmp(var.obs,"ts")) { var.bn_r1 = 50;  var.bn_r2 = 20; }
    if (!strcmp(var.obs,"tg")) { var.bn_r1 = 50;  var.bn_r2 = 20; }
    if (!strcmp(var.obs,"ca_tot")) { var.bn_r1 = 80;  var.bn_r2 = 30; }
    if (!strcmp(var.obs,"ca_mid")) { var.bn_r1 = 80;  var.bn_r2 = 30; }
    if (!strcmp(var.obs,"ca")) { var.bn_r1 = 80;  var.bn_r2 = 30; }
    if (!strcmp(var.obs,"ch")) { var.bn_r1 = 80;  var.bn_r2 = 30; }
    if (!strncmp(var.obs,"ss", 2)) { var.bn_r1 = 50;  var.bn_r2 = 20; }
    if (!strncmp(var.obs,"te", 2)) { var.bn_r1 = 80;  var.bn_r2 = 30; }
    if (!strncmp(var.obs,"si", 2)) { var.bn_r1 = 80;  var.bn_r2 = 30; }
    if (!strncmp(var.obs,"vs", 2)) { var.bn_r1 = 40;  var.bn_r2 = 15; }
    if (!strncmp(var.obs,"pm", 2)) { var.bn_r1 = 80;  var.bn_r2 = 30; }
    if (!strncmp(var.obs,"uw", 2)) { var.bn_r1 = 50;  var.bn_r2 = 20; }
  }
  return 0;
}

/*******************************************************************************
 *
 *  �ڷ� �б�
 *
 *******************************************************************************/
int data_get()
{
  int  YY, MM, DD, HH, MI;
  int  i, k, n;

  // 1. AWS �ڷ� �б�
  if      (!strcmp(var.obs, "rn_acc")) rain_get();
  else if (!strcmp(var.obs, "sd_tot")) snow_get();
  else if (!strcmp(var.obs, "sd_day")) snow_get();
  else if (!strcmp(var.obs, "sd_3hr")) snow_get();
  else if (!strcmp(var.obs, "sd_24h")) snow_get();
  else aws_get();

  // 2. AMEDAS �ڷ� �б�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  if (YY >= 2018)
    amedas4_get();
  else
    amedas_get();

  // 3. �ڷᰡ ���� ������ ��Ͽ��� ����.
  for (k = 0; k < var.num_stn_obj; k++) {
    if (stn_data[k].d < -90) {
      if (k < var.num_stn_obj-1) {
        for (i = k; i < var.num_stn_obj-1; i++)
          stn_data[i] = stn_data[i+1];
      }
      else {
        var.num_stn_obj--;
        break;
      }
      var.num_stn_obj--;
      k--;
    }
  }

  // 4. AMEDAS ������ Ȯ��
  for (n = 0, k = 0; k < var.num_stn_obj; k++) {
    if (stn_data[k].id >= NUM_AWS) n++;
  }
  var.num_stn_gov = n;

  return 0;
}

/*******************************************************************************
 *  AWS �ڷ� �б�
 *******************************************************************************/
int aws_get() {
  FILE   *fp;
  URL_FILE *fr; 
  struct AWS3_DATA aws[1];
  char   url[500], tmp[500];
  float  vv, wd, ws, u1, v1;
  float  es, e, ta, td, hm, pa;
  int  mm_dif, seq, seq1, seq2;
  int  YY, MM, DD, HH, MI;
  int  code, qc, i, j, k;

  // 1. ������ ������ �б�
  for (k = 0; k < var.num_stn_obj; k++) {
    qc = 0;

    // 1.1. �ڷ� �б�
    seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    code = AWS3_DATA_READ(YY, MM, DD, HH, MI, stn_data[k].id, aws, 'r');
    if (code == 0) {
      // 1.1.1. �ٶ������� ���, U,V�� ����
      if (!strcmp(var.obs, "wv_10m") || !strcmp(var.obs, "wv_10x")) {
        wd = aws[0].d[65]*0.1;
        ws = aws[0].d[66]*0.1;
        if (wd >= 0 && ws >= 0) {
          u1 = -ws * sin( DEGRAD * wd );
          v1 = -ws * cos( DEGRAD * wd );
          qc = 1;
        }
      }
      else if (!strcmp(var.obs, "wv_ins")) {
        wd = aws[0].d[3]*0.1;
        ws = aws[0].d[4]*0.1;
        if (wd >= 0 && ws >= 0) {
          u1 = -ws * sin( DEGRAD * wd );
          v1 = -ws * cos( DEGRAD * wd );
          qc = 1;
        }
      }

      // 1.1.2. �̽����µ�, ����, �����µ�, ��������
      else if (!strcmp(var.obs, "td") || !strcmp(var.obs, "wn") || !strcmp(var.obs, "pv") ||
               !strcmp(var.obs, "tw") || !strcmp(var.obs,"hm_dci")) {
        hm = aws[0].d[9]*0.1;
        ta = aws[0].d[0]*0.1;

        if (hm > 4 && hm <= 100 && ta > -40 && ta < 45) {
          if (!strcmp(var.obs, "tw"))
            vv = ta*atan(0.151977*sqrt(hm+8.313659)) + atan(ta+hm) - atan(hm-1.676331) + 0.00391838*pow(hm,1.5)*atan(0.023101*hm) - 4.68035;
          else if (!strcmp(var.obs,"hm_dci"))
            vv = ta*9.0/5.0 - 0.55*(1.0-hm*0.01)*(ta*9.0/5.0-26) + 32;
          else {
            es = 6.112*exp((17.67*ta)/(ta+243.5));
            e = es*hm*0.01;
            td = log(e/6.112)*243.5/(17.67-log(e/6.112));

            if (!strcmp(var.obs, "td"))
              vv  = td;
            else if (!strcmp(var.obs, "pv"))
              vv  = e;
            else if (!strcmp(var.obs, "wn"))
              vv  = ta - td;
          }
          qc = 1;
        }
      }

      // 1.1.3. ���
      else if (!strcmp(var.obs, "sh")) {
        hm = aws[0].d[9]*0.1;
        ta = aws[0].d[0]*0.1;
        pa = aws[0].d[6]*0.1;

        if (hm > 4 && hm <= 100 && ta > -40 && ta < 45 && pa > 100 && pa < 1200) {
          es = 6.112*exp((17.67*ta)/(ta+243.5));
          e = es*hm*0.01;
          vv = 1000.0*0.622*e/(pa-0.378*e);
          qc = 1;
        }
      }

      // 1.1.3.b ȥ�պ�
      else if (!strcmp(var.obs, "mr")) {
        hm = aws[0].d[9]*0.1;
        ta = aws[0].d[0]*0.1;
        pa = aws[0].d[6]*0.1;

        if (hm > 4 && hm <= 100 && ta > -40 && ta < 45 && pa > 100 && pa < 1200) {
          es = 6.112*exp((17.67*ta)/(ta+243.5));
          e = es*hm*0.01;
          vv = 1000.0*0.622*e/(pa-e);
          qc = 1;
        }
      }

      // 1.1.4. ü���µ�
      else if (!strcmp(var.obs, "ta_chi") || !strcmp(var.obs, "ta_chd")) {
        ta = aws[0].d[0]*0.1;
        ws = aws[0].d[66]*0.1;
        if (ta > -40 && ta < 45 && ws >= 0 && ws < 100) {
          ws *= 3.6;    // m/s -> km/h
          vv = 13.12 + 0.6215*ta - 11.37*pow(ws,0.16) + 0.3965*pow(ws,0.16)*ta;
          if (!strcmp(var.obs, "ta_chd")) vv = vv - ta;
          qc = 1;
        }
      }

      // 1.1.5. �������� �����
      else if (!strcmp(var.obs, "ta_dif")) {
        ta = aws[0].d[0]*0.1;
        if (ta > -40 && ta < 45) {
          seq2time(var.seq-1440, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
          code = AWS3_DATA_READ(YY, MM, DD, HH, MI, stn_data[k].id, aws, 'r');
          if (code == 0 && aws[0].d[0]*0.1 > -40 && aws[0].d[0]*0.1 < 45) {
            vv = ta - aws[0].d[0]*0.1;
            qc = 1;
          }
        }
      }

      // 1.1.6. ����µ�
      else if (!strcmp(var.obs, "ts")) {
        vv = aws[0].d[var.varn]*0.1;
        if (vv > var.missing && vv < var.max) qc = 1;
      }

      // 1.1.7. ����µ��� ��°��� ����
      else if (!strcmp(var.obs, "ts_ta")) {
        vv = aws[0].d[var.varn]*0.1;
        ta = aws[0].d[0]*0.1;
        if (vv > var.missing && vv < var.max && ta > -49 && ta < 45) {
          qc = 1;
          vv -= ta;
        }
      }

      // 1.1.8. �ʻ�µ�
      else if (!strcmp(var.obs, "tg")) {
        vv = aws[0].d[var.varn]*0.1;
        if (vv > var.missing && vv < var.max) qc = 1;
      }

      // 1.1.9. �ʻ�µ��� ��°��� ����
      else if (!strcmp(var.obs, "tg_ta")) {
        vv = aws[0].d[var.varn]*0.1;
        ta = aws[0].d[0]*0.1;
        if (vv > var.missing && vv < var.max && ta > -49 && ta < 45) {
          qc = 1;
          vv -= ta;
        }
      }

      // 1.1.10. ���߿µ�
      else if (strstr(var.obs, "te_")) {
        vv = aws[0].d[var.varn]*0.1;
        if (vv > var.missing && vv < var.max) qc = 1;
      }

      // 1.1.11. �������� : �������������� 15�а����� ������ �Ǵ�
      else if (!strcmp(var.obs, "rn_ex")) {
        if (aws[0].d[7] >= 0 && aws[0].d[67] >= 0) {
          if (aws[0].d[7] > 0 || aws[0].d[67] > 0)
            vv = 1;
          else
            vv = 0;
          qc = 1;
        }
      }

      // 1.1.12. 15m ������*4 �� ���
      else if (!strcmp(var.obs, "rn_15x")) {
        vv = aws[0].d[var.varn]*0.4;
        if (vv > var.missing) qc = 1;
      }

      // 1.1.13. ������ : 15m ������*4 - 60�� ������
      else if (!strcmp(var.obs, "rn_15d")) {
        if (aws[0].d[67] >= 0 && aws[0].d[68] >= 0) {
          vv = aws[0].d[67]*0.4 - aws[0].d[68]*0.1;
          qc = 1;
        }
      }

      // 1.1.14. �����
      else if (strstr(var.obs, "ps_m") || strstr(var.obs, "ps_d")) {
        vv = aws[0].d[var.varn]*0.1;
        if (vv > var.missing && vv < var.max) {
          strncpy(tmp, &(var.obs)[4], 2);  tmp[2] = '\0';  mm_dif = atoi(tmp);
          if (strstr(var.obs, "ps_d")) mm_dif *= 60;
          seq2time(var.seq-mm_dif, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
          code = AWS3_DATA_READ(YY, MM, DD, HH, MI, stn_data[k].id, aws, 'r');
          if (code == 0 && aws[0].d[var.varn]*0.1 > var.missing && aws[0].d[var.varn]*0.1 < var.max) {
            vv -= aws[0].d[var.varn]*0.1;
            qc = 1;
          }
        }
      }

      // 1.1.15. ����
      else if (strstr(var.obs, "vs")) {
        if (aws[0].d[var.varn] != -999) {
          vv = (unsigned short)(aws[0].d[var.varn])*0.001;
          if (vv > var.missing && vv < var.max) qc = 1;
        }
      }

      // 1.1.16. ���(����), ����(����), ����(����), �������� (��º��� ����)
      else if (!strcmp(var.obs, "ta_tpo") || !strcmp(var.obs, "hm_tpo") || !strcmp(var.obs, "tw_tpo") ||
               !strcmp(var.obs, "ww_lee") || !strcmp(var.obs, "ww_aws")) {
        ta = aws[0].d[0]*0.1;
        if (ta > -40 && ta < 45) {
          vv = ta;
          qc = 1;
        }
      }

      // 1.1.17. ��Ÿ
      else {
        vv = aws[0].d[var.varn]*0.1;
        if (vv > var.missing && vv < var.max) qc = 1;
      }
    }

    // 1.2. ������ ��ǥ��ȯ �� ������ ����
    if (qc) {
      if (!strncmp(var.obs,"wv_",3)) {
        stn_data[k].d = u1;
        stn_data[k].v = v1;
      }
      else {
        stn_data[k].d = vv;
      }
      stn_data[k].wd = aws[0].d[65]*0.1;
      stn_data[k].ws = aws[0].d[66]*0.1;
      stn_data[k].re = 0;
      if (aws[0].d[7] > 0 || aws[0].d[67] > 0) stn_data[k].re = 1;
    }
    else
      stn_data[k].d = -999;
  }
  return 0;
}

/*******************************************************************************
 *  ���������� �ڷ� ���
 *******************************************************************************/
int rain_get()
{
  FILE   *fp;
  URL_FILE *fr; 
  struct AWS3_DATA aws[1];
  char   url[500], tmp[500];
  float  vv, wd, ws, u1, v1, v2;
  float  es, e, ta, td, hm;
  int  seq, seq1, seq2, seq_day, seq1_day, seq2_day;
  int  YY, MM, DD, HH, MI;
  int  code, qc, i, j, k;

  // 1. ������ ������ �б�
  // 1.1. �����Ⱓ ������ �ϰ������� ��ģ��.
  seq2time(var.seq_st, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  seq1_day = time2seq(YY, MM, DD, 0, 0, 'd');
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'y');
  seq2_day = time2seq(YY, MM, DD, 0, 0, 'd');

  for (k = 0; k < var.num_stn_obj; k++)
    stn_data[k].d = 0;

  // �������� �ϰ������� �����Ͽ� ���������� ���������� �ϰ����� ���� ���
  for (seq_day = seq1_day+1; seq_day <= seq2_day; seq_day++) {
    seq2time(seq_day, &YY, &MM, &DD, &HH, &MI, 'd', 'n');
    seq1 = time2seq(YY, MM, DD, HH, MI, 'm');
    seq2 = seq1 - 5;

    // �ϰ����� �ʱ�ȭ
    for (k = 0; k < var.num_stn_obj; k++)
      stn_data[k].s = -99.9;

    // �������� �ϰ��������� ���(00:00�� ���� ������ -5�б��� ã��)
    for (seq = seq1; seq >= seq2; seq--) {
      seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
      for (k = 0; k < var.num_stn_obj; k++) {
        code = AWS3_DATA_READ(YY, MM, DD, HH, MI, stn_data[k].id, aws, 'r');
        if (code < 0) continue;
        v1 = 0.1*(float)(aws[0].d[5]);
        if (seq == seq1 || (stn_data[k].s < v1 && v1 >= 0)) stn_data[k].s = v1;
      }
    }

    // �������� �ϰ������� ����
    for (k = 0; k < var.num_stn_obj; k++) {
      if (seq_day == seq1_day)
        stn_data[k].d = stn_data[k].s;
      else {
        if (stn_data[k].d >= 0 && stn_data[k].s >= 0)
          stn_data[k].d += stn_data[k].s;
        else
          stn_data[k].d = -99.9;
      }
    }
  }

  // 1.2. ���� ���������� �Ⱓ�� �������� ��ģ��.
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  seq1 = var.seq;
  seq2 = seq1 - 5;
  if (HH*60+MI > 0 && HH*60+MI <= 5) seq2 = var.seq - MI + 1;

  for (k = 0; k < var.num_stn_obj; k++)
    stn_data[k].s = -99.9;

  for (seq = seq1; seq >= seq2; seq--) {
    seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    for (k = 0; k < var.num_stn_obj; k++) {
      code = AWS3_DATA_READ(YY, MM, DD, HH, MI, stn_data[k].id, aws, 'r');
      if (code < 0) continue;
      v1 = 0.1*(float)(aws[0].d[5]);
      if (seq == seq1 || (stn_data[k].s < 0 && v1 >= 0)) {
        stn_data[k].s = v1;
        stn_data[k].wd = aws[0].d[65]*0.1;
        stn_data[k].ws = aws[0].d[66]*0.1;
        stn_data[k].re = 0;
        if (aws[0].d[7] > 0 || aws[0].d[67] > 0) stn_data[k].re = 1;
      }
    }
  }

  for (k = 0; k < var.num_stn_obj; k++) {
    if (stn_data[k].s >= 0)
      stn_data[k].d += stn_data[k].s;
    else
      stn_data[k].d = -99.9;
  }

  // 1.3. ���� ���۳��� ������ �������� ����.
  seq2time(var.seq_st, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  if (HH*60+MI > 0) {
    seq1 = var.seq_st;
    seq2 = seq1 - 5;
    if (HH*60+MI <= 5) seq2 = var.seq - MI + 1;

    for (k = 0; k < var.num_stn_obj; k++)
      stn_data[k].s = -99.9;

    for (seq = seq1; seq >= seq2; seq--) {
      seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
      for (k = 0; k < var.num_stn_obj; k++) {
        code = AWS3_DATA_READ(YY, MM, DD, HH, MI, stn_data[k].id, aws, 'r');
        if (code < 0) continue;
        v1 = 0.1*(float)(aws[0].d[5]);
        if (seq == seq1 || (stn_data[k].s < 0 && v1 >= 0)) stn_data[k].s = v1;
      }
    }

    for (k = 0; k < var.num_stn_obj; k++) {
      if (stn_data[k].d >= 0 && stn_data[k].s >= 0)
        stn_data[k].d -= stn_data[k].s;
      else
        stn_data[k].d = -99.9;
    }
  }
  return 0;
}

/*******************************************************************************
 *  AMEDAS �ڷ� �б� (2018�� ����)
 *******************************************************************************/
int amedas_get()
{
  FILE   *fp;
  URL_FILE *fr; 
  struct lamc_parameter map;
  char   buf[1000], url[500], tmp[500], v[30][50];
  float  vv, xx, yy, u1, v1;
  float  rn, wd, ws, ta, pa, ps, vs, hm, rn_day, wd_ins, ws_ins, sd;
  float  lat, lon, ht, ht_pa, ht_ta, ht_wd, ht_rn;
  int    stn_id, wc;
  int  YY, MM, DD, HH, MI;
  int  seq, seq1;
  int  qc, code, rtn, now, i, j, k;
  int  GX, GY, SX, SY;

  // 1. MAP parameter
  grid_map_inf(var.map, &GX, &GY, &SX, &SY);
  map.Re  = 6371.00877;
  map.grid  = var.grid;
  map.slat1 = 30.0;  map.slat2 = 60.0;
  map.olon  = 126.0;   map.olat  = 38.0;
  map.xo = (float)SX/map.grid;   map.yo = (float)SY/map.grid;
  map.first = 0;

  // 2. ������ ������ �б�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(url, "http://172.20.134.91/url/amedas.php?tm=%04d%02d%02d%02d00&stn=0&help=0", YY, MM, DD, HH);

  if ((fr = url_fopen(url, "r"))) {
    while (!url_feof(fr)) {
      url_fgets(buf, sizeof(buf), fr);
      if (buf[0] == '#') continue;

      qc = 0;
      sscanf(buf, "%s %d %f %f %f %f %f",
        tmp, &stn_id, &rn, &wd, &ws, &ta, &sd);

      if (!strcmp(var.obs,"rn_60m")) {
        vv = rn;
        if (vv >= 0) qc = 1;
      }
      else if (!strcmp(var.obs,"ws_10m")) {
        vv = ws;
        if (vv >= 0) qc = 1;
      }
      else if (!strcmp(var.obs,"ta")) {
        vv = ta - 273;
        if (vv > -50) qc = 1;
      }
      else if (!strcmp(var.obs, "wv_10m") || !strcmp(var.obs, "wv_10x")) {
        if (wd >= 0 && ws >= 0) {
          u1 = -ws * sin( DEGRAD * wd );
          v1 = -ws * cos( DEGRAD * wd );
          qc = 1;
        }
      }
      else if (!strcmp(var.obs, "wv_ins")) {
        if (wd >= 0 && ws >= 0) {
          u1 = -ws * sin( DEGRAD * wd );
          v1 = -ws * cos( DEGRAD * wd );
          qc = 1;
        }
      }
      else
        break;

      if (qc) {
        for (i = 0; i < var.num_stn_obj; i++) {
          if (stn_data[i].id == stn_id) {
            if (!strncmp(var.obs,"wv_",3)) {
              stn_data[k].d = u1;
              stn_data[k].v = v1;
            }
            else {
              stn_data[k].d = vv;
            }
            stn_data[k].wd = wd;
            stn_data[k].ws = ws;
            break;
          }
        }
      }
    }
  }
  url_fclose(fr);
  return 0;
}

/*******************************************************************************
 *  AMEDAS4 �ڷ� �б� (2018�� ����)
 *******************************************************************************/
int amedas4_get()
{
  FILE   *fp;
  URL_FILE *fr; 
  struct lamc_parameter map;
  char   buf[1000], url[500], tmp[500], v[30][50];
  float  vv, xx, yy, u1, v1;
  float  rn, wd, ws, ta, pa, ps, vs, hm, rn_day, wd_ins, ws_ins;
  float  lat, lon, ht, ht_pa, ht_ta, ht_wd, ht_rn;
  int    stn_id, wc;
  int    YY, MM, DD, HH, MI;
  int    seq, seq1;
  int    qc, code, rtn, now, i, j, k;
  int    GX, GY, SX, SY;

  // 1. MAP parameter
  grid_map_inf(var.map, &GX, &GY, &SX, &SY);
  map.Re  = 6371.00877;
  map.grid  = var.grid;
  map.slat1 = 30.0;  map.slat2 = 60.0;
  map.olon  = 126.0;   map.olat  = 38.0;
  map.xo = (float)SX/map.grid;   map.yo = (float)SY/map.grid;
  map.first = 0;

  // 2. ������ ������ �б�
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(url, "http://172.20.134.91/url/amedas4.php?tm=%04d%02d%02d%02d00&stn=0&help=0", YY, MM, DD, HH);

  if ((fr = url_fopen(url, "r"))) {
    while (!url_feof(fr)) {
      url_fgets(buf, sizeof(buf), fr);
      if (buf[0] == '#') continue;

      qc = 0;
      sscanf(buf, "%s %d %f %f %f %f %d %f %f %f %f %f %f %f %f %f %f %f %f %f %f",
        tmp, &stn_id, &rn, &wd, &ws, &ta, &wc, &pa, &ps, &vs, &hm, &rn_day, &wd_ins, &ws_ins,
                      &lat, &lon, &ht, &ht_pa, &ht_ta, &ht_wd, &ht_rn);

      if (!strcmp(var.obs,"rn_60m")) {
        vv = rn;
        if (vv >= 0) qc = 1;
      }
      else if (!strcmp(var.obs,"ws_10m")) {
        vv = ws;
        if (vv >= 0) qc = 1;
      }
      else if (!strcmp(var.obs,"ta")) {
        vv = ta - 273;
        if (vv >= -50) qc = 1;
      }
      else if (!strcmp(var.obs,"pa")) {
        vv = pa;
        if (vv > 600 && vv < 1200) qc = 1;
      }
      else if (!strcmp(var.obs,"ps1") || !strcmp(var.obs,"ps2") || !strcmp(var.obs,"ps3")) {
        vv = ps;
        if (vv > 600 && vv < 1200) qc = 1;
      }
      else if (!strcmp(var.obs,"rn_day")) {
        vv = rn_day;
        if (vv >= 0) qc = 1;
      }
      else if (!strcmp(var.obs,"ws_ins")) {
        vv = ws_ins;
        if (vv >= 0) qc = 1;
      }
      else if (!strcmp(var.obs, "wv_10m") || !strcmp(var.obs, "wv_10x")) {
        if (wd >= 0 && ws >= 0) {
          u1 = -ws * sin( DEGRAD * wd );
          v1 = -ws * cos( DEGRAD * wd );
          qc = 1;
        }
      }
      else if (!strcmp(var.obs, "wv_ins")) {
        if (wd >= 0 && ws >= 0) {
          u1 = -ws * sin( DEGRAD * wd );
          v1 = -ws * cos( DEGRAD * wd );
          qc = 1;
        }
      }
      else
        break;

      if (qc) {
        lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);

        stn_data[var.num_stn_obj].id = stn_id;
        stn_data[var.num_stn_obj].x = xx;
        stn_data[var.num_stn_obj].y = yy;
        stn_data[var.num_stn_obj].ht = ht;
        if (!strncmp(var.obs,"wv_",3)) {
          stn_data[var.num_stn_obj].d = u1;
          stn_data[var.num_stn_obj].v = v1;
        }
        else {
          stn_data[var.num_stn_obj].d = vv;
        }
        stn_data[var.num_stn_obj].wd = wd;
        stn_data[var.num_stn_obj].ws = ws;
        var.num_stn_obj++;
      }
    }
  }
  url_fclose(fr);
  //printf("num_stn_obj = %d\n", var.num_stn_obj);
  return 0;
}

/*******************************************************************************
 *  ���� �ڷ� �б�
 *******************************************************************************/
int snow_get()
{
  FILE   *fp;
  URL_FILE *fr; 
  struct lamc_parameter map;
  char   buf[1000], url[500], tmp[500], name[32], stn_sp[16];
  float  lon, lat, xx, yy, vv;
  float  data_min = 99999, data_max = -99999, d1;
  int  stn_id;
  int  YY, MM, DD, HH, MI;
  int  seq, seq1;
  int  qc, code, rtn, now, i, j, k;
  int  GX, GY, SX, SY;

  // 1. MAP parameter
  grid_map_inf(var.map, &GX, &GY, &SX, &SY);
  map.Re  = 6371.00877;
  map.grid  = var.grid;
  map.slat1 = 30.0;  map.slat2 = 60.0;
  map.olon  = 126.0;   map.olat  = 38.0;
  map.xo = (float)SX/map.grid;   map.yo = (float)SY/map.grid;
  map.first = 0;

  // 2. ������ ������ �б�
  var.num_stn_obj = 0;
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  if (!strcmp(var.obs,"sd_tot"))
    sprintf(url, "http://cht.kma.go.kr/url/kma_snow1.php?sd=tot&tm=%04d%02d%02d%02d%02d&stn=0&help=0", YY, MM, DD, HH, MI);
  else if (!strcmp(var.obs,"sd_day"))
    sprintf(url, "http://cht.kma.go.kr/url/kma_snow1.php?sd=day&tm=%04d%02d%02d%02d%02d&stn=0&help=0", YY, MM, DD, HH, MI);
  else if (!strcmp(var.obs,"sd_3hr"))
    sprintf(url, "http://cht.kma.go.kr/url/kma_snow1.php?sd=3hr&tm=%04d%02d%02d%02d%02d&stn=0&help=0", YY, MM, DD, HH, MI);
  else if (!strcmp(var.obs,"sd_24h"))
    sprintf(url, "http://cht.kma.go.kr/url/kma_snow1.php?sd=24h&tm=%04d%02d%02d%02d%02d&stn=0&help=0", YY, MM, DD, HH, MI);

  if ((fr = url_fopen(url, "r"))) {
    while (!url_feof(fr)) {
      url_fgets(buf, sizeof(buf), fr);
      if (buf[0] == '#') continue;

      getword(tmp, buf, ',');             // �ð�
      getword(tmp, buf, ',');  stn_id = atoi(tmp);  // ������ȣ
      getword(tmp, buf, ',');  strcpy(name, tmp);   // ������
      getword(tmp, buf, ',');  lon = atof(tmp);   // �浵
      getword(tmp, buf, ',');  lat = atof(tmp);   // ����
      getword(tmp, buf, ',');  strcpy(stn_sp, tmp); // ����Ư��
      getword(tmp, buf, ',');  vv = atof(tmp);    // ��

      qc = 0;
      if (vv > var.missing && vv < var.max) qc = 1;

      if (qc) {
        lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);
        stn_data[var.num_stn_obj].id = stn_id;
        strcpy(stn_data[var.num_stn_obj].name, name);
        stn_data[var.num_stn_obj].x  = xx;
        stn_data[var.num_stn_obj].y  = yy;
        stn_data[var.num_stn_obj].d  = vv;
        stn_data[var.num_stn_obj].wd = 0;
        stn_data[var.num_stn_obj].ws = 0;
        stn_data[var.num_stn_obj].re = 0;
        var.num_stn_obj++;
      }
    }
  }
  url_fclose(fr);
  return 0;
}

/*******************************************************************************
 *
 *  ���û AWS + �Ϻ� AMEDAS �������� �б�
 *
 *******************************************************************************/
int stn_info_get()
{
  int  YY, MM, DD, HH, MI;

  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  // ���û AWS �������� �б�
  aws_inf_get();

  // �Ϻ� AMEDAS �������� �б� (2018����ʹ� �ڷῡ ���浵 ����)
  if (YY < 2018) amedas_inf_get();
  return 0;
}

/*******************************************************************************
 *  ���û AWS �������� �б�
 *******************************************************************************/
int aws_inf_get()
{
  URL_FILE *fr; 
  struct lamc_parameter map;
  char   buf[1000], url[1000], tmp[500], name[32], stn_sp[16], gov_lst[1000], obs[8];
  float  lon, lat, xx, yy, ht;
  int    GX, GY, SX, SY;
  int    stn_id, seq;
  int    YY, MM, DD, HH, MI;
  int    i, j, k;

  // 1. MAP parameter
  grid_map_inf(var.map, &GX, &GY, &SX, &SY);
  map.Re  = 6371.00877;
  map.grid  = var.grid;
  map.slat1 = 30.0;  map.slat2 = 60.0;
  map.olon  = 126.0;   map.olat  = 38.0;
  map.xo = (float)SX/map.grid;   map.yo = (float)SY/map.grid;
  map.first = 0;

  // 2. ������ ��ġ��
  for (strcpy(gov_lst,""), i = 0; i < var.num_gov; i++) {
    strcat(gov_lst, var.gov_cd[i]);
    if (i < var.num_gov-1) strcat(gov_lst, ":");
  }

  // 3. �������� �б�� URL-API �ۼ�
  seq2time((int)(var.seq/10)*10, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  //if (strcmp(var.obs,"rn_acc") == 0)
    strcpy(obs, "RN");
  //else
  //  strcpy(obs, var.obs_cd);
  sprintf(url, "http://172.20.134.147/url/stn_obs_inf.php?mode=3&gov=%s&obs=%s&tm=%04d%02d%02d%02d%02d&disp=0",
    gov_lst, obs, YY, MM, DD, HH, MI);

  // 4. �������� ����
  var.num_stn_obj = 0;
  if ((fr = url_fopen(url, "r"))) {
    while (!url_feof(fr)) {
      url_fgets(buf, sizeof(buf), fr);
      if (buf[0] == '#') continue;

      // �ص�
      getword(tmp, buf, ',');  stn_id = atoi(tmp);  // ������ȣ
      getword(tmp, buf, ',');  strcpy(name, tmp);   // ������
      getword(tmp, buf, ',');
      getword(tmp, buf, ',');  strcpy(stn_sp, tmp);   // �������
      getword(tmp, buf, ',');
      getword(tmp, buf, ',');
      getword(tmp, buf, ',');
      getword(tmp, buf, ',');  lon = atof(tmp);   // �浵
      getword(tmp, buf, ',');  lat = atof(tmp);   // ����
      getword(tmp, buf, ',');
      if (strlen(tmp) <= 0)   // �ع߰��� ��
        ht = -999;
      else
        ht = atof(tmp);

      // NUM_AWS3 ���� ū ������ ����
      if (stn_id < 0 || stn_id >= NUM_AWS3) continue;

      // ���浵�� ���� ������ ����
      if (lon < 120 || lon > 135 || lat < 30 || lat > 45) continue;

      // �������� ���ų�, �̻��� ���� ����
      if (var.topo == 1 && (ht < 0 || ht > 4000)) continue;

      // ���� ����
      if (strcmp(stn_sp,"SZ") == 0) continue;   // �ӽ����� ����
      if (strcmp(stn_sp,"PA") == 0) continue;   // ��âAWS ����
      if (strcmp(stn_sp,"PB") == 0) continue;   // ��â���ռ��� ����
      if (strcmp(stn_sp,"SO") == 0) continue;   // ����� ����

      // ���������� ��Ī
      stn_data[var.num_stn_obj].id = stn_id;
      strcpy(stn_data[var.num_stn_obj].name, name);

      lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);
      stn_data[var.num_stn_obj].x = xx;
      stn_data[var.num_stn_obj].y = yy;
      stn_data[var.num_stn_obj].ht = ht;

      stn_data[var.num_stn_obj].d = -999;
      strcpy(stn_data[var.num_stn_obj].name, name);
      strcpy(stn_data[var.num_stn_obj].sp, stn_sp);
      var.num_stn_obj++;
    }
    url_fclose(fr);
  }
  return 0;
}

/*******************************************************************************
 *  �Ϻ� AMEDAS �������� �б� (�ռ��� aws_inf_get() �� ���� ����Ǿ�� ��)
 *******************************************************************************/
int amedas_inf_get()
{
  URL_FILE *fr; 
  struct lamc_parameter map;
  char   buf[1000], url[1000], tmp[500], name[32], stn_sp[16], gov_lst[1000], obs[8];
  float  lon, lat, xx, yy, ht, ht_wd;
  int    GX, GY, SX, SY;
  int    stn_id, seq;
  int    YY, MM, DD, HH, MI;
  int    i, j, k;

  // 1. MAP parameter
  grid_map_inf(var.map, &GX, &GY, &SX, &SY);
  map.Re  = 6371.00877;
  map.grid  = var.grid;
  map.slat1 = 30.0;  map.slat2 = 60.0;
  map.olon  = 126.0;   map.olat  = 38.0;
  map.xo = (float)SX/map.grid;   map.yo = (float)SY/map.grid;
  map.first = 0;

  // 3. �������� �б�� URL-API �ۼ�
  seq2time((int)(var.seq/10)*10, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(url, "http://172.20.134.91/url/stn_amedas.php?tm=%04d%02d%02d%02d%02d&stn=0&raw=0&help=1", YY, MM, DD, HH, MI);

  // 4. �������� ����
  if ((fr = url_fopen(url, "r"))) {
    while (!url_feof(fr)) {
      url_fgets(buf, sizeof(buf), fr);
      if (buf[0] == '#') continue;

      // �ص�
      sscanf(buf, "%d %f %f %s %f %f %s", &stn_id, &lon, &lat, stn_sp, &ht, &ht_wd, name);

      // ���浵�� ���� ������ ����
      if (lon < 100 || lon > 150 || lat < 0 || lat > 60) continue;

      // �������� ���ų�, �̻��� ���� ����
      if (var.topo == 1 && (ht < 0 || ht > 5000)) continue;

      // ���������� ��Ī
      stn_data[var.num_stn_obj].id = stn_id;
      strcpy(stn_data[var.num_stn_obj].name, name);

      lamcproj_ellp(&lon, &lat, &xx, &yy, 0, &map);
      stn_data[var.num_stn_obj].x = xx;
      stn_data[var.num_stn_obj].y = yy;
      stn_data[var.num_stn_obj].ht = ht;

      stn_data[var.num_stn_obj].d = -999;
      strcpy(stn_data[var.num_stn_obj].name, name);
      strcpy(stn_data[var.num_stn_obj].sp, stn_sp);
      var.num_stn_obj++;
    }
    url_fclose(fr);
  }
  return 0;
}
