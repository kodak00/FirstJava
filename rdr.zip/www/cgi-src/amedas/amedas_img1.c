/*******************************************************************************
**
**  AWS + AMEDAS ����ڷ� ������ ǥ�� ���α׷�
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.7.3)
**
********************************************************************************/
#include "amedas_img.h"
char *fontttf = "/usr/share/fonts/korean/TrueType/gulim.ttf";   // ����� �ѱ�TTF

struct INPUT_VAR var;              // ����� �Է� ����
struct STN_VAL stn_data[MAX_STN];  // ���� �ڷ�
float  **g;     // �����м����
int    GX, GY, SX, SY;  // ��������(km)
FILE   *fp_log;

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main()
{
  int  i, j;

  // 0. �ʱ�ȭ
  setvbuf(stdout, NULL, _IONBF, 0);
  alarm(60);

  printf("HTTP/1.0 200 OK\n");
  printf("Server: Netscape-Enterprise/3.0\n");
  //printf("Content-type: text/plain\n\n");

  // 1. ����� �Է� ���� �м�
  if ( user_input() < 0 ) {
    printf("Content-type: text/plain\n\n");
    printf("# input variable error<p>\n");
    return -1;
  }

  // 1.1. �������� ���� ������ ĳ���� ������� ����
  if (strstr(var.obs,"ps") == NULL && strstr(var.obs,"pa") == NULL && var.stn != 3 && var.stn != 4) {
    if (reuse_img() >= 0) return 0;
  }

  // 2. ���ڿ��� �Ҵ� �� �ʱ�ȭ
  grid_map_inf(var.map, &GX, &GY, &SX, &SY);
  var.NX = (int)(GX/var.grid);   var.NY = (int)(GY/var.grid);

  g = matrix(0, var.NY, 0, var.NX);
  for (j = 0; j <= var.NY; j++) {
    for (i = 0; i <= var.NX; i++) {
      g[j][i] = -999;
    }
  }

  // 3. ������� �б�
  stn_info_get();

  // 4. �����ڷ� �б�
  data_get();

  // 5. �����м�
  // 5.1. �����м��� ������ ���� ����
  grid_masking();

  // 5.2. ����ǥ���� �ƴ� ���
  if (var.stn != 3 && var.stn != 4) {
    // 5.4. �����ڷ� �����м�
    data_obj();

    // 5.6. Ȯ���� ���, ���ڿ��� Ȯ��
    grid_zooming(g);
  }
  // 5.7. Ȯ���� ���, ���� ��ġ�� Ȯ��
  stn_zooming();

  // 6. �̹��� ���� �� ����
  aws_img();

  // 7. �޸� �ݳ�
  free_matrix(g, 0, var.NY, 0, var.NX);

  alarm(0);
  return 0;
}

/*******************************************************************************
 *
 *  ������ �̹��� ���� �� ����
 *
 *******************************************************************************/
int aws_img()
{
  gdImagePtr im;
  FILE   *fp;
  char   dname[120];
  int    color_lvl[256];
  float  data_lvl[256];

  // 1. �̹��� ���� ����
  if (var.title == 0)
    var.title_pixel = 0;
  else
    var.title_pixel = TITLE_pixel;

  var.NI = var.size;
  var.NJ = (int)((float)(var.NY)/(float)(var.NX)*var.NI);
  var.GI = var.NI;
  if (var.legend == 1) var.GI += LEG_pixel;
  var.GJ = var.NJ + var.title_pixel;

  // 2. �̹��� ����ü ���� �� ����ǥ �б�
  im = gdImageCreate(var.GI, var.GJ);
  color_table(im, color_lvl, data_lvl);
  gdImageFilledRectangle(im, 0, 0, var.GI, var.GJ, color_lvl[240]);

  // 3. �����ڷ� �׸���
  if (var.stn != 3 && var.stn != 4) grid_disp(im, color_lvl, data_lvl);

  // 4. ���� �׸���
  if (var.zoom_level >= 2) map_disp(im, color_lvl[249], 1);
  map_disp(im, color_lvl[242], 4);

  // 5. ���� �� ������ ǥ��
  if (var.stn == 3 || var.stn == 4)
    stn_pnt_disp(im, color_lvl, data_lvl);
  else
    stn_value_disp(im, color_lvl);

  // 5. ���� �׸���
  if (var.title != 0) title_disp(im, color_lvl);

  // 7. ���� �׸���
  legend_disp(im, color_lvl, data_lvl);
  gdImageRectangle(im, 0, var.title_pixel, var.NI-1, var.GJ-1, color_lvl[242]);

  // 8. �̹��� ����
  printf("Content-type: image/png\n\n");
  gdImagePng(im, stdout);

  // 9. �̹��� ���� (�������� ���� ������ ĳ���� ������� ����)
  if (strstr(var.obs,"ps") == NULL && strstr(var.obs,"pa") == NULL && var.stn != 3 && var.stn != 4) {
    if (image_filename() < 0) {
      sprintf(dname, "%s/%s", IMG_TMP_DIR, var.img_file);
      fp = fopen(dname, "wb");
      gdImagePng(im, fp);
      fclose(fp);
    }
  }
  gdImageDestroy(im);
  return 0;
}

/*=============================================================================*
 *  �̹��� ���ϸ�
 *=============================================================================*/
int image_filename()
{
  struct stat st;
  time_t tp;
  char   dname[120];
  int    YY, MM, DD, HH, MI;
  int    code, rtn = -1;

  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(var.img_file, "amedas_%s_%d_%s_%d_%s_%s_%04d%02d%02d%02d%02d.png",
          var.obs, var.stn, var.map, var.size, var.zoom_x, var.zoom_y, YY, MM, DD, HH, MI);
  sprintf(dname, "%s/%s", IMG_TMP_DIR, var.img_file);
  code = stat(dname, &st);
  time(&tp);
  if (code == 0 && difftime(tp, st.st_mtime) < 10*60 && st.st_size > 300) rtn = 0;
  return rtn;
}

/*=============================================================================*
 *  �̹��� ������ �ִ� ���, ��Ȱ��
 *=============================================================================*/
int reuse_img()
{
  gdImagePtr im;
  FILE  *fp;
  char   dname[120], buf[8000];
  int    n;

  // �̹��� ������ ������ �ٷ� return
  if (image_filename() < 0) return -1;

  // 2. ������ ������ ó��
  printf("Content-type: image/png\n\n");
  sprintf(dname, "%s/%s", IMG_TMP_DIR, var.img_file);
  fp = fopen(dname, "rb");
  while ((n = fread(buf, 1, 8000, fp)) > 0) {
    fwrite(buf, 1, n, stdout);
  }
  fclose(fp);
  return 0;
}

/*=============================================================================*
 *  ����ǥ
 *=============================================================================*/
int color_table(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  FILE  *fp;
  URL_FILE *fr; 
  char  color_file[120], url_file[240], buf[1000];
  int   num_color;
  int   R, G, B;
  int   YY, MM, DD, HH, MI, dseq;
  float v1, diff;
  float ta_min[12] = {-15,-15,-10, -5, 5,5,10,10, 0, -5,-10,-15};
  float td_min[12] = {-25,-20,-20,-10,-5,5,10,10,-5,-15,-20,-25};
  int   i, j, k;

  // 1. ��󺯼��� ����ǥ ���� ����
  strcpy(color_file, COLOR_SET_DIR);
  if (!strcmp(var.obs,"rn_acc")) {
    dseq = var.seq-var.seq_st;
    if (dseq <= 3*60) {
      if      (!strcmp(var.color,"C1")) strcat(color_file,"color_rn.rgb");
      else if (!strcmp(var.color,"C2")) strcat(color_file,"color_rn_yell.rgb");
      else if (!strcmp(var.color,"C3")) strcat(color_file,"color_rn_blue.rgb");
      else if (!strcmp(var.color,"C4")) strcat(color_file,"color_rn_echo.rgb");
    }
    else if (dseq <= 6*60) {
      if      (!strcmp(var.color,"C1")) strcat(color_file,"color_rn_03h.rgb");
      else if (!strcmp(var.color,"C2")) strcat(color_file,"color_rn_03h_yell.rgb");
      else if (!strcmp(var.color,"C3")) strcat(color_file,"color_rn_03h_blue.rgb");
      else if (!strcmp(var.color,"C4")) strcat(color_file,"color_rn_03h_echo.rgb");
    }
    else {
      if      (!strcmp(var.color,"C1")) strcat(color_file,"color_rn_12h.rgb");
      else if (!strcmp(var.color,"C2")) strcat(color_file,"color_rn_12h_yell.rgb");
      else if (!strcmp(var.color,"C3")) strcat(color_file,"color_rn_12h_blue.rgb");
      else if (!strcmp(var.color,"C4")) strcat(color_file,"color_rn_12h_echo.rgb");
    }
  }
  else if (!strcmp(var.obs,"rn_ex"))  strcat(color_file,"color_rn_ex.rgb");
  else if (!strcmp(var.obs,"rn_15m")) {
    if      (!strcmp(var.color,"C1")) strcat(color_file,"color_rn.rgb");
    else if (!strcmp(var.color,"C2")) strcat(color_file,"color_rn_yell.rgb");
    else if (!strcmp(var.color,"C3")) strcat(color_file,"color_rn_blue.rgb");
    else if (!strcmp(var.color,"C4")) strcat(color_file,"color_rn_echo.rgb");
  }
  else if (!strcmp(var.obs,"rn_15x")) {
    if      (!strcmp(var.color,"C1")) strcat(color_file,"color_rn.rgb");
    else if (!strcmp(var.color,"C2")) strcat(color_file,"color_rn_yell.rgb");
    else if (!strcmp(var.color,"C3")) strcat(color_file,"color_rn_blue.rgb");
    else if (!strcmp(var.color,"C4")) strcat(color_file,"color_rn_echo.rgb");
  }
  else if (!strcmp(var.obs,"rn_60m")) {
    if      (!strcmp(var.color,"C1")) strcat(color_file,"color_rn.rgb");
    else if (!strcmp(var.color,"C2")) strcat(color_file,"color_rn_yell.rgb");
    else if (!strcmp(var.color,"C3")) strcat(color_file,"color_rn_blue.rgb");
    else if (!strcmp(var.color,"C4")) strcat(color_file,"color_rn_echo.rgb");
  }
  else if (!strcmp(var.obs,"rn_15d")) strcat(color_file,"color_rn_dif.rgb");
  else if (!strcmp(var.obs,"rn_03h")) {
    if      (!strcmp(var.color,"C1")) strcat(color_file,"color_rn.rgb");
    else if (!strcmp(var.color,"C2")) strcat(color_file,"color_rn_yell.rgb");
    else if (!strcmp(var.color,"C3")) strcat(color_file,"color_rn_blue.rgb");
    else if (!strcmp(var.color,"C4")) strcat(color_file,"color_rn_echo.rgb");
    /*
    if      (!strcmp(var.color,"C1")) strcat(color_file,"color_rn_03h.rgb");
    else if (!strcmp(var.color,"C2")) strcat(color_file,"color_rn_03h_yell.rgb");
    else if (!strcmp(var.color,"C3")) strcat(color_file,"color_rn_03h_blue.rgb");
    else if (!strcmp(var.color,"C4")) strcat(color_file,"color_rn_03h_echo.rgb");
    */
  }
  else if (!strcmp(var.obs,"rn_06h")) {
    if      (!strcmp(var.color,"C1")) strcat(color_file,"color_rn_03h.rgb");
    else if (!strcmp(var.color,"C2")) strcat(color_file,"color_rn_03h_yell.rgb");
    else if (!strcmp(var.color,"C3")) strcat(color_file,"color_rn_03h_blue.rgb");
    else if (!strcmp(var.color,"C4")) strcat(color_file,"color_rn_03h_echo.rgb");
    /*
    if      (!strcmp(var.color,"C1")) strcat(color_file,"color_rn_12h.rgb");
    else if (!strcmp(var.color,"C2")) strcat(color_file,"color_rn_12h_yell.rgb");
    else if (!strcmp(var.color,"C3")) strcat(color_file,"color_rn_12h_blue.rgb");
    else if (!strcmp(var.color,"C4")) strcat(color_file,"color_rn_12h_echo.rgb");
    */
  }
  else if (!strcmp(var.obs,"rn_12h")) {
    if      (!strcmp(var.color,"C1")) strcat(color_file,"color_rn_12h.rgb");
    else if (!strcmp(var.color,"C2")) strcat(color_file,"color_rn_12h_yell.rgb");
    else if (!strcmp(var.color,"C3")) strcat(color_file,"color_rn_12h_blue.rgb");
    else if (!strcmp(var.color,"C4")) strcat(color_file,"color_rn_12h_echo.rgb");
    else if (!strcmp(var.color,"C4")) strcat(color_file,"color_rn_12h_echo.rgb");
  }
  else if (!strcmp(var.obs,"rn_day")) {
    if      (!strcmp(var.color,"C1")) strcat(color_file,"color_rn_12h.rgb");
    else if (!strcmp(var.color,"C2")) strcat(color_file,"color_rn_12h_yell.rgb");
    else if (!strcmp(var.color,"C3")) strcat(color_file,"color_rn_12h_blue.rgb");
    else if (!strcmp(var.color,"C4")) strcat(color_file,"color_rn_12h_echo.rgb");
  }
  else if (!strcmp(var.obs,"sd_tot")) strcat(color_file,"color_sd.rgb");
  else if (!strcmp(var.obs,"sd_day")) strcat(color_file,"color_sd.rgb");
  else if (!strcmp(var.obs,"sd_3hr")) strcat(color_file,"color_sd.rgb");
  else if (!strcmp(var.obs,"sd_24h")) strcat(color_file,"color_sd.rgb");
  else if (!strcmp(var.obs,"ws_01m")) strcat(color_file,"color_ws.rgb");
  else if (!strcmp(var.obs,"ws_10m")) strcat(color_file,"color_ws.rgb");
  else if (!strcmp(var.obs,"ws_ins")) strcat(color_file,"color_ws.rgb");
  else if (!strcmp(var.obs,"ta"))     strcat(color_file,"color_ta_e30.rgb");
  else if (!strcmp(var.obs,"ta_tpo")) strcat(color_file,"color_ta_e30.rgb");
  else if (!strcmp(var.obs,"ta_now")) strcat(color_file,"color_ta_e30.rgb");
  else if (!strcmp(var.obs,"ta_chi")) strcat(color_file,"color_ta_e30.rgb");
  else if (!strcmp(var.obs,"ta_chd")) strcat(color_file,"color_ta_chd.rgb");
  else if (!strcmp(var.obs,"ta_dif")) strcat(color_file,"color_ta_dif.rgb");
  else if (!strcmp(var.obs,"tw"))     strcat(color_file,"color_ta_e30.rgb");
  else if (!strcmp(var.obs,"tw_tpo")) strcat(color_file,"color_ta_e30.rgb");
  else if (!strcmp(var.obs,"td"))     strcat(color_file,"color_ta_e30.rgb");
  else if (!strcmp(var.obs,"wn"))     strcat(color_file,"color_wn.rgb");
  else if (!strcmp(var.obs,"hm"))     strcat(color_file,"color_hm.rgb");
  else if (!strcmp(var.obs,"hm_tpo")) strcat(color_file,"color_hm.rgb");
  else if (!strcmp(var.obs,"pv"))     strcat(color_file,"color_pv.rgb");
  else if (!strcmp(var.obs,"sh"))     strcat(color_file,"color_sh.rgb");
  else if (!strcmp(var.obs,"hm_dci")) strcat(color_file,"color_hm_dci.rgb");
  else if (!strcmp(var.obs,"pa"))     strcat(color_file,"color_pa.rgb");
  else if (!strcmp(var.obs,"ss_60m")) strcat(color_file,"color_ss.rgb");
  else if (!strcmp(var.obs,"si_60m")) strcat(color_file,"color_si.rgb");
  else if (!strcmp(var.obs,"vs"))     strcat(color_file,"color_vs.rgb");
  else if (!strcmp(var.obs,"ca_tot")) strcat(color_file,"color_sat_ca1.rgb");
  else if (!strcmp(var.obs,"ca_mid")) strcat(color_file,"color_sat_ca1.rgb");
  else if (!strcmp(var.obs,"ca"))     strcat(color_file,"color_sat_ca1.rgb");
//  else if (!strcmp(var.obs,"ca"))     strcat(color_file,"color_ca.rgb");
  else if (!strcmp(var.obs,"ch"))     strcat(color_file,"color_ch.rgb");
  else if (!strcmp(var.obs,"tg_ta"))  strcat(color_file,"color_ts_ta.rgb");
  else if (!strcmp(var.obs,"ts_ta"))  strcat(color_file,"color_ts_ta.rgb");
  else if (!strcmp(var.obs,"ts"))     strcat(color_file,"color_ta_e30.rgb");
  else if (!strcmp(var.obs,"tg"))     strcat(color_file,"color_ta_e30.rgb");
  else if (!strncmp(var.obs,"te",2))  strcat(color_file,"color_ta_e30.rgb");
  else if (!strncmp(var.obs,"ps_m",4))strcat(color_file,"color_ps_dif.rgb");
  else if (!strncmp(var.obs,"ps_d",4))strcat(color_file,"color_ps_dif.rgb");
  else if (!strncmp(var.obs,"ps",2))  strcat(color_file,"color_ps.rgb");
  else if (!strcmp(var.obs,"pm10"))   strcat(color_file,"color_pm10.rgb");
  else if (!strcmp(var.obs,"me_10i")) strcat(color_file,"color_pm10.rgb");
  else if (!strcmp(var.obs,"moe"))    strcat(color_file,"color_moe.rgb");
  else if (!strcmp(var.obs,"uw_10m")) strcat(color_file,"color_hm.rgb");
  else if (!strcmp(var.obs,"ww_lee")) strcat(color_file,"color_ww_lee.rgb");
  else if (!strcmp(var.obs,"ww_aws")) strcat(color_file,"color_ww_aws.rgb");

  // 2. ����ǥ ���ϰ� ������ �б�
  var.num_color = num_color = 0;
  if ((fp = fopen(color_file, "r")) != NULL) {
    while (fscanf(fp, "%d %d %d %f\n", &R, &G, &B, &v1) != EOF) {
      color_lvl[num_color] = gdImageColorAllocate(im, R, G, B);
      data_lvl[num_color] = v1;
      num_color++;
      if (num_color > 119) break;
    }
    fclose(fp);
  }
  else {
    num_color = -1;
  }
  var.num_color = num_color;

  // 3. ��Ÿ ����ǥ ����
  color_lvl[240] = gdImageColorAllocate(im, 210, 210, 210);   // ����1
  color_lvl[241] = gdImageColorAllocate(im, 255, 255, 255);   // ����2
  color_lvl[242] = gdImageColorAllocate(im, 30, 30, 30);      // ������
  color_lvl[243] = gdImageColorAllocate(im, 12, 28, 236);     // ����
  color_lvl[244] = gdImageColorAllocate(im, 0, 0, 0);         // ������
  color_lvl[245] = gdImageColorAllocate(im, 240, 240, 240);
  color_lvl[246] = gdImageColorAllocate(im, 255, 0, 0);
  color_lvl[247] = gdImageColorAllocate(im, 0, 0, 255);
  color_lvl[248] = gdImageColorAllocate(im, 160, 160, 160);   // ����3
  color_lvl[249] = gdImageColorAllocate(im, 90, 90, 90);      // �ñ����

  // 4. ��°� �̽����� ���, ������ �������� ����
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  if (!strcmp(var.obs,"ta") || !strcmp(var.obs,"ta_chi") || !strcmp(var.obs,"ts") ||
      !strcmp(var.obs,"tg") || !strncmp(var.obs,"te",2)  ||
      !strcmp(var.obs,"ta_tpo")) {
    diff = data_lvl[0] - ta_min[MM-1];
    for (k = 0; k < var.num_color; k++)
      data_lvl[k] -= diff;
  }
  else if (!strcmp(var.obs,"tw") || !strcmp(var.obs,"tw_tpo")) {
    diff = data_lvl[0] - ta_min[MM-1] - 1.0;
    for (k = 0; k < var.num_color; k++)
      data_lvl[k] -= diff;
  }
  else if (!strcmp(var.obs,"td")) {
    diff = data_lvl[0] - td_min[MM-1];
    for (k = 0; k < var.num_color; k++)
      data_lvl[k] -= diff;
  }
  else if (!strcmp(var.obs,"ps_m15") || !strcmp(var.obs,"ps_m30")) {
    for (k = 0; k < var.num_color; k++)
      data_lvl[k] /= 10.0;
  }
  else if (!strcmp(var.obs,"ps_d01")) {
    for (k = 0; k < var.num_color; k++)
      data_lvl[k] /= 5.0;
  }
  else if (!strcmp(var.obs,"ps_d03")) {
    for (k = 0; k < var.num_color; k++)
      data_lvl[k] *= (2.0/5.0);
  }

  // 5. �ظ����� ���, �ڷ� �ܰ踦 ���� ���ó���� ���Ͽ� �޴´�.
  if (!strcmp(var.obs,"ps1") || !strcmp(var.obs,"ps2") || !strcmp(var.obs,"ps3") || !strcmp(var.obs,"ta_now")) {
    sprintf(url_file, "http://cht.kma.go.kr/aws/alwais_afs_lvl.php?obs=%s&tm=%04d%02d%02d%02d%02d",
            var.obs, YY, MM, DD, HH, MI);
    k = 0;
    if ((fr = url_fopen(url_file, "r"))) {
      while (!url_feof(fr)) {
        url_fgets(buf, sizeof(buf), fr);
        sscanf(buf, "%d %d %d %f\n", &R, &G, &B, &v1);
        data_lvl[k] = v1;
        k++;
      }
      url_fclose(fr);
    }
  }
  return num_color;
}

/*=============================================================================*
 *  �����ڷ� ǥ��
 *=============================================================================*/
int grid_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  float x, y, dx, dy, d1, d2, dd;
  int   i, j, k, ix, iy, color1;

  // 0. ����ó��
  if (var.num_stn_obj <= 0) {
    gdImageString(im, gdFontLarge, 100, 100, "No Data", color_lvl[244]);
    return -1;
  }
  if (var.num_color <= 0) {
    gdImageString(im, gdFontLarge, 100, 100, "No Color Level", color_lvl[244]);
    return -1;
  }

  // 1. Y�� ����
  for (j = 1; j < var.NJ; j++) {
    y = (float)j*(float)(var.NY)/(float)(var.NJ);
    iy = (int)y;
    dy = y - iy;
    if (iy < 0 || iy > var.NY-1) continue;

    // 2. X������ ����
    for (i = 1; i < var.NI; i++) {
      x = (float)i*(float)(var.NX)/(float)(var.NI);
      ix = (int)x;
      dx = x - ix;
      if (ix < 0 || ix > var.NX-1) continue;

      // 3. �ش� �̹��� �ȼ� ��ġ�� ���� ���
      if (!strcmp(var.obs,"ww_lee") || !strcmp(var.obs,"ww_aws"))
        dd = g[iy][ix];
      else {
        if (g[iy][ix] > -90 && g[iy][ix+1] > -90 && g[iy+1][ix] > -90 && g[iy+1][ix+1] > -90) {
          d1 = (1.0-dx)*g[iy][ix] + dx*g[iy][ix+1];
          d2 = (1.0-dx)*g[iy+1][ix] + dx*g[iy+1][ix+1];
          dd = (1.0-dy)*d1 + dy*d2;
        }
        else
          dd = g[iy][ix];
      }

      // 4. �ڷᰡ �������� ������ ǥ��
      if (dd > -90) {
        //color1 = color_lvl[var.num_color-1];
        color1 = color_lvl[240];
        for (k = 0; k < var.num_color; k++) {
          if (dd <= data_lvl[k]) {
            color1 = color_lvl[k];
            break;
          }
        }
        gdImageSetPixel(im, i, var.GJ-j, color1);
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int map_disp(gdImagePtr im, int color_map, int kind)
{
  FILE  *fp;
  char  fname[120];
  float zm = 1.0, xo = 0.0, yo = 0.0, x1, y1, x2, y2;
  int   zx, zy, mode;
  int   i, j, k, n;

  // 1. Ȯ���, �߽���ġ�� Ȯ����� ���
  if (var.zoom_level > 0) {
    if (var.zoom_rate == 3) {
      for (i = 0; i < 2; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/9.0*(zx-1)/zm;
        yo += (float)(var.NY)/9.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
    else if (var.zoom_rate == 2) {
      for (i = 0; i < 7; i++) {
        zx = var.zoom_x[i]-'0';
        zy = var.zoom_y[i]-'0';
        if (zx == 0 || zy == 0) break;

        xo += (float)(var.NX)/8.0*(zx-1)/zm;
        yo += (float)(var.NY)/8.0*(zy-1)/zm;
        zm *= var.zoom_rate;
      }
    }
  }

  // 2. �ؾȼ� ǥ��
  sprintf(fname, "/DATA/GIS/MAP/dat/AFS_%s_map%d.dat", var.map, kind);
  if ((fp = fopen(fname, "r")) != NULL) {
    while (fscanf(fp, "%d %d\n", &n, &mode) != EOF) {
      for (i = 0; i < n; i++) {
        fscanf(fp, "%f %f\n", &x2, &y2);
        x2 /= var.grid;
        y2 /= var.grid;

        if (var.zoom_level > 0) {
          x2 = zm*(x2-xo);
          y2 = zm*(y2-yo);
        }
        x2 *= ((float)(var.NI)/(float)(var.NX));
        y2 *= ((float)(var.NI)/(float)(var.NX));
        if (i > 0) {
          gdImageLine(im, (int)x1, var.GJ-(int)y1, (int)x2, var.GJ-(int)y2, color_map);
          if (kind == 4 && var.zoom_level >= 0) gdImageLine(im, (int)x1, var.GJ-(int)y1-1, (int)x2, var.GJ-(int)y2-1, color_map);
        }
        x1 = x2;
        y1 = y2;
      }
    }
    fclose(fp);
  }

  return 0;
}

/*=============================================================================*
 *  EUC-KR���ڿ��� UTF-8�� ��ȯ
 *=============================================================================*/
int euckr2utf(char *str, char *out)
{
  iconv_t convp;
  size_t  ileft, oleft;
  int     err, len = strlen(str);

  ileft = len;
  oleft = len * 2;

  convp = iconv_open("UTF-8", "euc-kr");
  err = iconv(convp, &str, &ileft, &out, &oleft);
  iconv_close(convp);

  return err;
}

/*=============================================================================*
 *  ������ ǥ��
 *=============================================================================*/
int stn_value_disp(gdImagePtr im, int color_lvl[])
{
  char   str_utf[20], str[20], tmp[50];
  double font_size = 10.0;
  int    brect[8];
  float  wr, ang, ws, ang_s, wr_s;
  float  data_min = 99999, data_max = -99999, d1;
  int    x, y, x1, y1, x2, y2;
  int    stn_min = -1, stn_max = -1;
  int    color_dot, maxmin;
  int    i, j, k;

  // 1. ���� ǥ�⿩�� Ȯ��
  if (var.num_stn_obj <= 0 || var.stn == 0 || var.stn == 3 || !strcmp(var.obs,"rn_ex")) return 0;

  // 2. ���� ���� ǥ�� (ǥ�ð����� ������ ������ �Ǹ� ǥ��)
  if (var.stn == 2 || (var.stn == 9 && var.num_stn_area > 0 && var.size*var.size/var.num_stn_area > 30*30)) {
    // ��ü �������� Ȯ��
    for (k = 0; k < var.num_stn_obj; k++) {
      // 2.1. �������� �ִ��� Ȯ��
      if (stn_data[k].x <= 0 || stn_data[k].x >= var.NX || stn_data[k].y <= 0 || stn_data[k].y >= var.NY) continue;

      // 2.2. �̹��� ���� ��ġ Ȯ��
      x = stn_data[k].x*var.NI/var.NX;
      y = var.GJ - stn_data[k].y*var.NI/var.NX;

      // 2.3. ǳ��� ǥ�� (PM10�� ������ ǳ����� ǥ���Ҽ� ����)
      if (strcmp(var.obs,"pm10") != 0 && strcmp(var.obs,"me_10i") != 0 &&
          strcmp(var.obs,"moe") != 0 && strcmp(var.obs,"moe") != 0) {
        // 2.3.1. ǳ��� ǥ��
        wr = 30;
        if (stn_data[k].wd >= 0 && stn_data[k].ws > 0.2) {
          ang = stn_data[k].wd*DEGRAD;
          x1 = x + wr*sin(ang);
          y1 = y - wr*cos(ang);
          gdImageLine(im, x, y, x1, y1, color_lvl[244]);
        }

        // 2.3.2. ǳ�ӱ� ǥ��
        if (stn_data[k].wd >= 0 && stn_data[k].ws > 0.2) {
          ws = stn_data[k].ws;
          ang_s = (stn_data[k].wd + 60.0)*DEGRAD;

          while (ws > 0.0) {
            if (ws >= 5.0) wr_s = 20.0;
            else           wr_s = 4.0*ws;

            x2 = x1 + wr_s*sin(ang_s);
            y2 = y1 - wr_s*cos(ang_s);
            gdImageLine(im, x1, y1, x2, y2, color_lvl[244]);

            ws -= 5.0;
            wr -= 5.0;
            x1 = x + wr*sin(ang);
            y1 = y - wr*cos(ang);
          }
        }
      }

      // 2.4. �������� ǥ��
      color_dot = color_lvl[246];
      if (stn_data[k].re == 1) color_dot = color_lvl[247];
      gdImageFilledArc(im, x, y, 8, 8, 0, 360, color_lvl[245], gdArc);
      gdImageFilledArc(im, x, y, 5, 5, 0, 360, color_dot, gdArc);

      // 2.5. �� ǥ��
      x -= 15;  y += 3;
      sprintf(str, "%.1f", stn_data[k].d);
      /*
      for (i = 0; i < 20; i++)
        str_utf[i] = 0;
      euckr2utf(str, str_utf);
      gdImageStringFT(im, &brect[0], color_lvl[245], fontttf, font_size, 0.0, x-1, y1-1, str_utf);
      gdImageStringFT(im, &brect[0], color_lvl[245], fontttf, font_size, 0.0, x-1, y1+1, str_utf);
      gdImageStringFT(im, &brect[0], color_lvl[245], fontttf, font_size, 0.0, x+1, y1+1, str_utf);
      gdImageStringFT(im, &brect[0], color_lvl[245], fontttf, font_size, 0.0, x+1, y1-1, str_utf);
      gdImageStringFT(im, &brect[0], color_lvl[244], fontttf, font_size, 0.0, x,   y,    str_utf);
      */

      //gdImageString(im, gdFontLarge, x-1, y-1, str, color_lvl[245]);
      //gdImageString(im, gdFontLarge, x-1, y+1, str, color_lvl[245]);
      //gdImageString(im, gdFontLarge, x+1, y+1, str, color_lvl[245]);
      //gdImageString(im, gdFontLarge, x+1, y-1, str, color_lvl[245]);
      gdImageString(im, gdFontLarge, x,   y,   str, color_lvl[244]);
    }
  }

  // 3. �ִ밪 �ּҰ� ǥ�� (1:�ּҰ��� ǥ��, 2:�ִ밪�� ǥ��, 3:�Ѵ� ǥ��)
  if (var.size*(var.zoom_level+1) > 100) {
    // 3.1. ��󺯼��� ǥ�� ��� ����
    if (!strcmp(var.obs,"hm") || !strcmp(var.obs,"vs") || !strcmp(var.obs,"ch"))
      maxmin = 1;
    else if (!strcmp(var.obs,"rn_15d"))
      maxmin = 3;
    else if (!strcmp(var.obs,"wn") || !strcmp(var.obs,"pm10") || !strcmp(var.obs,"me_10i") || !strcmp(var.obs,"moe") ||
             !strncmp(var.obs,"rn",2) || !strncmp(var.obs,"sd",2) || !strncmp(var.obs,"ws",2) ||
             !strncmp(var.obs,"ss",2) || !strncmp(var.obs,"si",2))
      maxmin = 2;
    else 
      maxmin = 3;

    // 3.2. �ּ�,�ִ밪�� ���� Ȯ��
    for (k = 0; k < var.num_stn_obj; k++) {
      if (stn_data[k].x > 0 && stn_data[k].x < var.NX && stn_data[k].y > 0 && stn_data[k].y < var.NY) {
        d1 = stn_data[k].d;
        if (!strncmp(var.obs,"wv",2)) d1 = stn_data[k].ws;
        if (data_min > d1) { stn_min = k;  data_min = d1; }
        if (data_max < d1) { stn_max = k;  data_max = d1; }
      }
    }

    // 3.3. ���� ǥ��
    for (i = 1; i <= 2; i++) {
      if (maxmin == i || maxmin == 3) {
        if (i == 1) k = stn_min;
        if (i == 2) k = stn_max;

        // �ְ�,���������� ���� ��� ó��
        if (k < 0) continue;

        // �������� ���, �ּҳ� �ִ밪�� 0.0�̸� ���� ǥ������ �ʴ´�.
        if (strncmp(var.obs,"rn_",3) == 0 && stn_data[k].d <= 0.0) continue;

        // ��ġ ���
        x = stn_data[k].x*var.NI/var.NX;
        y = var.GJ - stn_data[k].y*var.NI/var.NX;

        // ���� ǥ��
        color_dot = color_lvl[246];
        if (stn_data[k].re == 1) color_dot = color_lvl[247];
        gdImageFilledArc(im, x, y, 8, 8, 0, 360, color_lvl[245], gdArc);
        gdImageFilledArc(im, x, y, 5, 5, 0, 360, color_lvl[246], gdArc);

        // �� ǥ��
        x -= 15;  y += 3;
        sprintf(str, "%.1f", stn_data[k].d);
        /*
        for (i = 0; i < 20; i++)
          str_utf[i] = 0;
        euckr2utf(str, str_utf);
        gdImageStringFT(im, &brect[0], color_lvl[245], fontttf, font_size, 0.0, x-1, y1-1, str_utf);
        gdImageStringFT(im, &brect[0], color_lvl[245], fontttf, font_size, 0.0, x-1, y1+1, str_utf);
        gdImageStringFT(im, &brect[0], color_lvl[245], fontttf, font_size, 0.0, x+2, y1+1, str_utf);
        gdImageStringFT(im, &brect[0], color_lvl[245], fontttf, font_size, 0.0, x+2, y1-1, str_utf);
        gdImageStringFT(im, &brect[0], color_lvl[246], fontttf, font_size, 0.0, x,   y,    str_utf);
        gdImageStringFT(im, &brect[0], color_lvl[246], fontttf, font_size, 0.0, x+1, y,    str_utf);
        */
        gdImageString(im, gdFontLarge, x-1, y-1, str, color_lvl[245]);
        gdImageString(im, gdFontLarge, x-1, y+1, str, color_lvl[245]);
        gdImageString(im, gdFontLarge, x+2, y+1, str, color_lvl[245]);
        gdImageString(im, gdFontLarge, x+2, y-1, str, color_lvl[245]);
        gdImageString(im, gdFontLarge, x+1, y,   str, color_lvl[246]);
        gdImageString(im, gdFontLarge, x,   y,   str, color_lvl[246]);
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  ���� ��ġ�� ǥ��(���� ���� ���� ���� ����)
 *=============================================================================*/
int stn_pnt_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  float  wr, ang, ws, ang_s, wr_s;
  float  data_min = 99999, data_max = -99999, d1;
  char   txt[20];
  int    x, y, x1, y1, x2, y2;
  int    stn_min = -1, stn_max = -1;
  int    color_dot, maxmin;
  int    i, j, k;

  // 1. ������ ���� ǥ��
  for (k = 0; k < var.num_stn_obj; k++) {
    // 1.1. �������� �ִ��� Ȯ��
    if (stn_data[k].x <= 0 || stn_data[k].x >= var.NX || stn_data[k].y <= 0 || stn_data[k].y >= var.NY) continue;

    // 1.2. �̹��� ���� ��ġ Ȯ��
    x = stn_data[k].x*var.NI/var.NX;
    y = var.GJ - stn_data[k].y*var.NI/var.NX;

    // 1.3. �ش� �������� ����
    d1 = stn_data[k].d;
    if (var.stn == 3) {
      if (d1 > -90) {
        color_dot = color_lvl[var.num_color-1];
        for (i = 0; i < var.num_color; i++) {
          if (d1 <= data_lvl[i]) {
            color_dot = color_lvl[i];
            break;
          }
        }
        gdImageFilledArc(im, x, y, 8, 8, 0, 360, color_dot, gdArc);
      }
    }
    else {
      gdImageFilledArc(im, x, y, 5, 5, 0, 360, color_lvl[246], gdArc);
      x -= 10;  y += 3;
      sprintf(txt, "%.1f", stn_data[k].d);
      gdImageString(im, gdFontLarge, x,   y,   txt, color_lvl[247]);
    }
  }

  // 2. �ذ� ǥ��
  // 2.1. ��󺯼��� ǥ�� ��� ����
  if (!strcmp(var.obs,"hm") || !strcmp(var.obs,"vs") || !strcmp(var.obs,"ch"))
    maxmin = 1;
  else if (!strcmp(var.obs,"rn_15d"))
    maxmin = 3;
  else if (!strcmp(var.obs,"wn") || !strcmp(var.obs,"pm10") || !strcmp(var.obs,"me_10i") || !strcmp(var.obs,"moe") ||
           !strncmp(var.obs,"rn",2) || !strncmp(var.obs,"sd",2) || !strncmp(var.obs,"ws",2) ||
           !strncmp(var.obs,"ss",2) || !strncmp(var.obs,"si",2))
    maxmin = 2;
  else 
    maxmin = 3;

  // 2.2. �ּ�,�ִ밪�� ���� Ȯ��
  for (k = 0; k < var.num_stn_obj; k++) {
    if (stn_data[k].x > 0 && stn_data[k].x < var.NX && stn_data[k].y > 0 && stn_data[k].y < var.NY) {
      d1 = stn_data[k].d;
      if (!strncmp(var.obs,"wv",2)) d1 = stn_data[k].ws;
      if (data_min > d1) { stn_min = k;  data_min = d1; }
      if (data_max < d1) { stn_max = k;  data_max = d1; }
    }
  }

  // 2.3. ���� ǥ��
  for (i = 1; i <= 2; i++) {
    if (maxmin == i || maxmin == 3) {
      if (i == 1) k = stn_min;
      if (i == 2) k = stn_max;

      // �ְ�,���������� ���� ��� ó��
      if (k < 0) continue;

      // �������� ���, �ּҳ� �ִ밪�� 0.0�̸� ���� ǥ������ �ʴ´�.
      if (strncmp(var.obs,"rn_",3) == 0 && stn_data[k].d <= 0.0) continue;

      // ��ġ ���
      x = stn_data[k].x*var.NI/var.NX;
      y = var.GJ - stn_data[k].y*var.NI/var.NX;

      // �� ǥ��
      x -= 10;  y += 3;
      sprintf(txt, "%.1f", stn_data[k].d);
      //gdImageString(im, gdFontLarge, x-1, y-1, txt, color_lvl[245]);
      //gdImageString(im, gdFontLarge, x-1, y+1, txt, color_lvl[245]);
      //gdImageString(im, gdFontLarge, x+1, y+1, txt, color_lvl[245]);
      //gdImageString(im, gdFontLarge, x+1, y-1, txt, color_lvl[245]);
      gdImageString(im, gdFontLarge, x,   y,   txt, color_lvl[246]);
    }
  }
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��(�ѱ�ó��)
 *=============================================================================*/
int title_disp(gdImagePtr im, int color_lvl[])
{
  char   title[80], gov_name[40], tm_fc_str[40], num_stn_str[10], tmp[50];
  char   title_utf[100], gov_utf[100];
  double font_size = 11.5;
  int    brect[8];
  int    YY, MM, DD, HH, MI;
  int    ok_kma, ok_tot, ok_oth;
  int    x, i, k;

  // 0. ���� ǥ�� ���� Ȯ��
  if (var.title == 0) return 0;

  // 1. ���񿵿��� ���� ó��
  gdImageFilledRectangle(im, 0, 0, var.GI, var.title_pixel, color_lvl[241]);

  // 2. ������
  if (!strcmp(var.obs,"rn_acc")) {
    if (var.seq-var.seq_st == 3*60)
      strcpy(title,"����(3H)");
    else
      strcpy(title,"����(����)");
  }
  else if (!strcmp(var.obs,"rn_ex"))  strcpy(title,"��������");
  else if (!strcmp(var.obs,"rn_15m")) strcpy(title,"����(15��)");
  else if (!strcmp(var.obs,"rn_15x")) strcpy(title,"����(15��)*4");
  else if (!strcmp(var.obs,"rn_60m")) strcpy(title,"����(60��)");
  else if (!strcmp(var.obs,"rn_15d")) strcpy(title,"����:15*4-60��");
  else if (!strcmp(var.obs,"rn_03h")) strcpy(title,"����(3H)");
  else if (!strcmp(var.obs,"rn_06h")) strcpy(title,"����(6H)");
  else if (!strcmp(var.obs,"rn_12h")) strcpy(title,"����(12H)");
  else if (!strcmp(var.obs,"rn_day")) strcpy(title,"����(��)");
  else if (!strcmp(var.obs,"sd_tot")) strcpy(title,"����");
  else if (!strcmp(var.obs,"sd_day")) strcpy(title,"������(��)");
  else if (!strcmp(var.obs,"sd_3hr")) strcpy(title,"������(3H)");
  else if (!strcmp(var.obs,"sd_24h")) strcpy(title,"������(24H)");
  else if (!strcmp(var.obs,"ws_01m")) strcpy(title,"ǳ��(1��)");
  else if (!strcmp(var.obs,"ws_10m")) strcpy(title,"ǳ��(10��)");
  else if (!strcmp(var.obs,"ws_ins")) strcpy(title,"���� ǳ��");
  else if (!strcmp(var.obs,"ta"))     strcpy(title,"���");
  else if (!strcmp(var.obs,"ta_tpo")) strcpy(title,"���(����)");
  else if (!strcmp(var.obs,"ta_now")) strcpy(title,"���");
  else if (!strcmp(var.obs,"ta_chi")) strcpy(title,"ü���µ�");
  else if (!strcmp(var.obs,"ta_chd")) strcpy(title,"ü���µ�-���");
  else if (!strcmp(var.obs,"ta_dif")) strcpy(title,"�����(����-����)");
  else if (!strcmp(var.obs,"tw"))     strcpy(title,"�����µ�");
  else if (!strcmp(var.obs,"tw_tpo")) strcpy(title,"�����µ�(����)");
  else if (!strcmp(var.obs,"td"))     strcpy(title,"�̽����µ�");
  else if (!strcmp(var.obs,"wn"))     strcpy(title,"����");
  else if (!strcmp(var.obs,"hm"))     strcpy(title,"����");
  else if (!strcmp(var.obs,"hm_tpo")) strcpy(title,"����(����)");
  else if (!strcmp(var.obs,"pv"))     strcpy(title,"�������");
  else if (!strcmp(var.obs,"sh"))     strcpy(title,"���");
  else if (!strcmp(var.obs,"hm_dci")) strcpy(title,"��������");
  else if (!strcmp(var.obs,"pa"))     strcpy(title,"�������");
  else if (!strcmp(var.obs,"ps1"))    strcpy(title,"�ظ���");
  else if (!strcmp(var.obs,"ps2"))    strcpy(title,"�ظ���");
  else if (!strcmp(var.obs,"ps3"))    strcpy(title,"�ظ���");
  else if (!strcmp(var.obs,"ps_m15")) strcpy(title,"�����(15��)");
  else if (!strcmp(var.obs,"ps_m30")) strcpy(title,"�����(30��)");
  else if (!strcmp(var.obs,"ps_d01")) strcpy(title,"�����(1H)");
  else if (!strcmp(var.obs,"ps_d03")) strcpy(title,"�����(3H)");
  else if (!strcmp(var.obs,"ca_tot")) strcpy(title,"���(����)");
  else if (!strcmp(var.obs,"ca_mid")) strcpy(title,"�������(����)");
  else if (!strcmp(var.obs,"vs"))     sprintf(title, "����(%d��)", var.itv);
  else if (!strcmp(var.obs,"ca"))     sprintf(title, "�(%d��)", var.itv);
  else if (!strcmp(var.obs,"ch"))     sprintf(title, "���� ����(%d��)", var.itv);
  else if (!strcmp(var.obs,"ss_60m")) sprintf(title, "����(%d��)", var.itv);
  else if (!strcmp(var.obs,"si_60m")) sprintf(title, "�ϻ�(%d��)", var.itv);
  else if (!strcmp(var.obs,"ts_ta"))  strcpy(title,"����µ�-���");
  else if (!strcmp(var.obs,"tg_ta"))  strcpy(title,"�ʻ�µ�-���");
  else if (!strcmp(var.obs,"ts"))     strcpy(title,"����µ�");
  else if (!strcmp(var.obs,"tg"))     strcpy(title,"�ʻ�µ�");
  else if (!strcmp(var.obs,"te_005")) strcpy(title,"���߿µ�(5cm)");
  else if (!strcmp(var.obs,"te_010")) strcpy(title,"���߿µ�(10cm)");
  else if (!strcmp(var.obs,"te_020")) strcpy(title,"���߿µ�(20cm)");
  else if (!strcmp(var.obs,"te_030")) strcpy(title,"���߿µ�(30cm)");
  else if (!strcmp(var.obs,"te_050")) strcpy(title,"���߿µ�(50cm)");
  else if (!strcmp(var.obs,"te_100")) strcpy(title,"���߿µ�(1.0m)");
  else if (!strcmp(var.obs,"te_150")) strcpy(title,"���߿µ�(1.5m)");
  else if (!strcmp(var.obs,"te_300")) strcpy(title,"���߿µ�(3.0m)");
  else if (!strcmp(var.obs,"te_500")) strcpy(title,"���߿µ�(5.0m)");
  else if (!strcmp(var.obs,"pm10"))   strcpy(title,"PM10(10m)    ");    // �� ������ �ѱ�ó�� ������  �Ϻη�����
  else if (!strcmp(var.obs,"me_10i")) sprintf(title, "ȯ���:PM10");
  else if (!strcmp(var.obs,"moe"))    sprintf(title, "ȯ���:PM10");
  else if (!strcmp(var.obs,"uw_10m")) sprintf(title, "������");
  else if (!strcmp(var.obs,"ww_lee")) sprintf(title, "����:�Ǻ�");
  else if (!strcmp(var.obs,"ww_aws")) sprintf(title, "����.�������");

  for (i = 0; i < 100; i++)
    title_utf[i] = 0;
  euckr2utf(title, title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, font_size, 0.0, 5, (int)(font_size+5), title_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, font_size, 0.0, 6, (int)(font_size+5), title_utf);

  // 3. �ð� ���ڿ� (������ 1�ð����� ����, �������� ���� ó��)
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'y');
  if (strncmp(var.obs,"sd_",3) == 0)
    sprintf(tm_fc_str, "%04d.%02d.%02d.%02d:00", YY, MM, DD, HH);
  else if (!strcmp(var.obs,"rn_acc") && var.seq-var.seq_st != 3*60) {
    sprintf(tmp, " ~ %02d.%02d:%02d", DD, HH, MI);
    seq2time(var.seq_st, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    sprintf(tm_fc_str, "%04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, MI);
    strcat(tm_fc_str, tmp);
  }
  else
    sprintf(tm_fc_str, "%04d.%02d.%02d.%02d:%02d", YY, MM, DD, HH, MI);

  if (!strcmp(var.obs,"rn_acc")) {
    gdImageString(im, gdFontLarge, 85, 1, tm_fc_str, color_lvl[244]);
    gdImageString(im, gdFontLarge, 86, 1, tm_fc_str, color_lvl[244]);
  }
  else {
    gdImageString(im, gdFontLarge, 125, 1, tm_fc_str, color_lvl[244]);
    gdImageString(im, gdFontLarge, 126, 1, tm_fc_str, color_lvl[244]);
  }

  // 4. ǥ�⿵���� ������ ǥ��
  sprintf(num_stn_str, "#%d", var.num_stn_area);
  gdImageFilledRectangle(im, var.NI-48, var.GJ-16, var.NI-2, var.GJ-2, color_lvl[241]);
  gdImageString(im, gdFontMediumBold, var.NI-45, var.GJ-15, num_stn_str, color_lvl[244]);

  // 5. ��� ǥ��
  /*
  if (!strcmp(var.obs,"uw_10m"))
    strcpy(gov_name, "[ ��������û ]");
  else {
    ok_kma = ok_tot = ok_oth = 0;
    for (i = 0; i < var.num_gov; i++) {
      if (strcmp(var.gov_cd[i],"KMA") == 0) ok_kma = 1;
      if (strcmp(var.gov_cd[i],"TOT") == 0) ok_tot = 1;
      if (strcmp(var.gov_cd[i],"OTH") == 0) ok_oth = 1;
    }

    if (ok_kma) {
      if (ok_tot == 1) {
        strcpy(gov_name, "[ ���û+���� ]");
      }
      else {
        if (var.num_gov == 1)
          strcpy(gov_name, "[ ���û ]");
        else
          strcpy(gov_name, "[ ���û+���� ]");
      }
    }
    else {
      if (ok_oth == 1) {
        strcpy(gov_name, "[ ��������� ]");
      }
      else {
        if (var.num_gov == 1)
          strcpy(gov_name, "[ ������� ]");
        else
          strcpy(gov_name, "[ ��������� ]");
      }
    }
  }
  gdImageFilledRectangle(im, 0, var.title_pixel+1, strlen(gov_name)*7, var.title_pixel*2-3, color_lvl[241]);

  for (i = 0; i < 100; i++)
    gov_utf[i] = 0;
  euckr2utf(gov_name, gov_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, 10.0, 0.0, 5, var.title_pixel*2-5, gov_utf);
  gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, 10.0, 0.0, 6, var.title_pixel*2-5, gov_utf);
  */
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
int legend_disp(gdImagePtr im, int color_lvl[], float data_lvl[])
{
  char   leg_utf[100];
  char   txt[20];
  double font_size = 9.5;
  float  dy = (float)(var.NJ)/(float)(var.num_color);
  int    brect[8], i;
  int    x, y, k;

  if (var.legend != 1) return 0;
  if (var.num_color <= 0) return -1;

  // 1. ���� ���� ǥ��
  for (k = 0; k < var.num_color; k++) {
    y = var.GJ - dy*k;
    gdImageFilledRectangle(im, var.NI, y-dy, var.NI+8, y, color_lvl[k]);
  }
  gdImageRectangle(im, var.NI-1, var.title_pixel, var.NI+8, var.GJ-1, color_lvl[242]);

  // 2. ���ʰ� ǥ��
  gdImageFilledRectangle(im, var.NI+9, 0, var.GI-1, var.GJ, color_lvl[241]);
  if (!strncmp(var.obs,"ca",2)) {
    for (k = 0; k < var.num_color; k++) {
      y = var.GJ - k*dy - dy*0.5 - 5;
      sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontLarge, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (!strcmp(var.obs,"ch") || !strcmp(var.obs,"si_60m")) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.1f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (!strcmp(var.obs,"ta") || !strcmp(var.obs,"ta_now") || !strcmp(var.obs,"tw") ||
           !strcmp(var.obs,"td") || !strcmp(var.obs,"ts") || !strcmp(var.obs,"tg") || 
           !strcmp(var.obs,"ta_chi") || !strncmp(var.obs,"te",2) || !strcmp(var.obs,"pv") ||
           !strcmp(var.obs,"ta_tpo") || !strcmp(var.obs,"tw_tpo")) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (!strcmp(var.obs,"ta_dif") || !strcmp(var.obs,"rn_15d")) {
    for (k = 1; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy;
      sprintf(txt, "%.0f", data_lvl[k]-0.4);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (!strcmp(var.obs,"rn_acc") || !strcmp(var.obs,"rn_15m") || !strcmp(var.obs,"rn_15x") ||
           !strcmp(var.obs,"rn_60m") || !strcmp(var.obs,"rn_03h") || !strncmp(var.obs,"sd_",3)) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      if (data_lvl[k] > 5)
        sprintf(txt, "%.0f", data_lvl[k]);
      else
        sprintf(txt, "%.1f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (!strcmp(var.obs,"ws_10m") || !strcmp(var.obs,"wv_10m") || !strcmp(var.obs,"ws_ins")) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      if (data_lvl[k] >= 10)
        sprintf(txt, "%.0f", data_lvl[k]);
      else
        sprintf(txt, "%.1f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (!strcmp(var.obs,"ps1") || !strcmp(var.obs,"ps2") || !strcmp(var.obs,"ps3")) {
    for (k = 0; k < var.num_color-1; k+=2) {
      y = var.GJ - (k+1)*dy - 5;
      if (((int)(data_lvl[k]*10))%10 == 0) {
        sprintf(txt, "%.0f", data_lvl[k]);
        gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
      }
    }
  }
  else if (!strncmp(var.obs,"ps_m",4) || !strncmp(var.obs,"ps_d",4)) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.1f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (!strcmp(var.obs,"ta_chd")) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.1f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (!strcmp(var.obs,"vs")) {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      if (data_lvl[k] > 9)
        sprintf(txt, "%.0f", data_lvl[k]);
      else
        sprintf(txt, "%.1f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }
  else if (!strcmp(var.obs,"rn_ex")) {
    gdImageStringUp(im, gdFontSmall, var.NI+10, (int)(var.GJ-(float)(var.NJ)*2.0/3.0), "RAIN", color_lvl[244]);
  }
  else if (!strcmp(var.obs,"ww_lee")) {
    for (k = 0; k < var.num_color; k++) {
      y = var.GJ - k*dy - dy/2;

      if      (data_lvl[k] == 1) strcpy(txt,"��");
      else if (data_lvl[k] == 2) strcpy(txt,"����");
      else if (data_lvl[k] == 3) strcpy(txt,"��");

      for (i = 0; i < 100; i++)
        leg_utf[i] = 0;
      euckr2utf(txt, leg_utf);
      gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, font_size, 0.0, var.NI+12, y, leg_utf);
      gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, font_size, 0.0, var.NI+11, y, leg_utf);
    }
  }
  else if (!strcmp(var.obs,"ww_aws")) {
    for (k = 0; k < var.num_color; k++) {
      y = var.GJ - k*dy - dy/2;

      if      (data_lvl[k] == 1) strcpy(txt,"��");
      else if (data_lvl[k] == 2) strcpy(txt,"����");
      else if (data_lvl[k] == 3) strcpy(txt,"��");
      else if (data_lvl[k] == 4) strcpy(txt,"�Ȱ�");
      else if (data_lvl[k] == 5) strcpy(txt,"�ڹ�");
      else if (data_lvl[k] == 6) strcpy(txt,"����");
      else continue;

      for (i = 0; i < 100; i++)
        leg_utf[i] = 0;
      euckr2utf(txt, leg_utf);
      gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, font_size, 0.0, var.NI+12, y, leg_utf);
      gdImageStringFT(im, &brect[0], color_lvl[247], fontttf, font_size, 0.0, var.NI+11, y, leg_utf);
    }
  }
  else {
    for (k = 0; k < var.num_color-1; k++) {
      y = var.GJ - (k+1)*dy - 5;
      sprintf(txt, "%.0f", data_lvl[k]);
      gdImageString(im, gdFontSmall, var.NI+12, y, txt, color_lvl[244]);
    }
  }

  // 3. ���� ���� ǥ��
  if      (!strcmp(var.obs,"rn_ex"))  strcpy(txt,"");
  else if (!strcmp(var.obs,"hm_dci")) strcpy(txt,"");
  else if (!strcmp(var.obs,"me_10i")) strcpy(txt,"ug/m3");
  else if (!strcmp(var.obs,"moe"))    strcpy(txt,"ug/m3");
  else if (!strncmp(var.obs,"rn",2)) strcpy(txt,"mm");
  else if (!strncmp(var.obs,"sd",2)) strcpy(txt,"cm");
  else if (!strncmp(var.obs,"ws",2)) strcpy(txt,"m/s");
  else if (!strncmp(var.obs,"ta",2)) strcpy(txt,"C");
  else if (!strncmp(var.obs,"tw",2)) strcpy(txt,"C");
  else if (!strncmp(var.obs,"td",2)) strcpy(txt,"C");
  else if (!strncmp(var.obs,"wn",2)) strcpy(txt,"C");
  else if (!strncmp(var.obs,"hm",2)) strcpy(txt,"%");
  else if (!strncmp(var.obs,"pv",2)) strcpy(txt,"hPa");
  else if (!strncmp(var.obs,"sh",2)) strcpy(txt,"g/kg");
  else if (!strncmp(var.obs,"pa",2)) strcpy(txt,"hPa");
  else if (!strncmp(var.obs,"ps",2)) strcpy(txt,"hPa");
  else if (!strncmp(var.obs,"ss",2)) strcpy(txt,"min");
  else if (!strncmp(var.obs,"si",2)) strcpy(txt,"MJ");
  else if (!strncmp(var.obs,"ca",2)) strcpy(txt,"1/10");
  else if (!strncmp(var.obs,"ch",2)) strcpy(txt,"km");
  else if (!strncmp(var.obs,"vs",2)) strcpy(txt,"km");
  else if (!strncmp(var.obs,"ts",2)) strcpy(txt,"C");
  else if (!strncmp(var.obs,"tg",2)) strcpy(txt,"C");
  else if (!strncmp(var.obs,"te",2)) strcpy(txt,"C");
  else if (!strncmp(var.obs,"pm",2)) strcpy(txt,"ug/m3");
  else if (!strncmp(var.obs,"uw",2)) strcpy(txt,"%");
  else strcpy(txt,"");

  x = var.NI + 3;
  if (strlen(txt) > 4) x = var.NI - 5;
  if (var.title == 0) x -= 20;
  gdImageString(im, gdFontLarge, x, 4, txt, color_lvl[244]);

  return 0;
}
