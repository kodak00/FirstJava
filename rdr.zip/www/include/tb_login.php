<?
// TBERO ȯ�漳��
function TB_Login($mode_login)
{
  switch ($mode_login) {
    case  2: $comis_id = "mis_rdr";     $comis_pwd = "rdrmis17";   $comis_sid = "COMIS";    break;
    case  3: $comis_id = "mis_digital"; $comis_pwd = "dfs1app3";   $comis_sid = "SVC_DIGITAL";  break;
    case 12: $comis_id = "afs";         $comis_pwd = "afs";        $comis_sid = "COMIS_SDB";  break;
    case  7: $comis_id = "mis_obs";     $comis_pwd = "mis_obs123"; $comis_sid = "COMIS";  break;
    default: $comis_id = "afs";         $comis_pwd = "afs";        $comis_sid = "COMIS";  break;
  }
  $dbconn = odbc_connect($comis_sid, $comis_id, $comis_pwd);
  return $dbconn;
}

// $ip_addr = gethostbyname(gethostname());   // ������ IP�ּ� Ȯ��
?>
