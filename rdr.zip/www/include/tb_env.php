<?
//
//  TB ȯ�漳��
//
putenv("HOME=/home/rdr");
putenv("USER=rdr");
putenv("GROUP=kma");
//putenv("LOCAL=/usr/local");
putenv("TB_HOME=/home/tibero5_client/tibero5");
putenv("TB_SID=COMIS");
putenv("ORA_USER=MIS_RDR");
putenv("ORA_PW=RDRMIS17");
putenv("PATH=/home/tibero5_client/tibero5/bin:/home/tibero5_client/tibero5/client/bin:/usr/lib64/qt-3.3/bin:/usr/local/bin:/bin:/usr/bin:/sbin:/home/rdr/bin:/usr/local/php/bin:/rdr/bin:/rdr/php_bin:.");
putenv("LD_LIBRARY_PATH=/home/tibero5_client/tibero5/client/lib:/usr/lib:/usr/lib64:/usr/local/lib:/usr/local/trmm/lib:/DATA/LIB/trmm/lib");
putenv("LIBPATH=/home/tibero5_client/tibero5/client/lib");
putenv("MODULEPATH=/usr/share/Modules/modulefiles:/etc/modulefiles");

?>
