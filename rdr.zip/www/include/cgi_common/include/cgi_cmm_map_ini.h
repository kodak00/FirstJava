#ifndef CGI_CMM_MAP_INI_H
#define CGI_CMM_MAP_INI_H

/* ================================================================================ */
// DEFINE

#define MAP_XO                   400
#define MAP_YO                   800

#define PI_DFS                   (3.141592)
#define KMA_MAP_RE               (6371.00877f)
#define GIS_MAP_RE               (6378.13729f)

/* ================================================================================ */
// STRUCT

typedef struct {
	float	m_fRe;		  //VARIABLE 
	float	m_fGrid;	  //VARIABLE
	float	m_fSlat1;	  //VARIABLE
	float	m_fSlat2;	  //VARIABLE
	float	m_fOlon;      //VARIABLE
	float	m_fOlat;	  //VARIABLE
	float	m_fXo;		  //VARIABLE
	float	m_fYo;		  //VARIABLE
}st_LAMC_PARAMETER;

typedef struct
{
	int	    m_nFirst;     //VARIABLE
    double  m_sdPI;
    double  m_sdDEGRAD;
    double  m_sdRADDEG;
    double  m_sdRe;
    double  m_sdOlon;
    double  m_sdOlat;
    double  m_sdSn;
    double  m_sdSf;
    double  m_sdRo;
} st_LAMC_VAR;

typedef struct {
    float  m_fRe;          /* »ç¿ëÇÒ Áö±¸¹Ý°æ [ km ]      */
    float  m_fGrid;        /* °ÝÀÚ°£°Ý        [ km ]      */
    float  m_fSlon;        /* Áß½É°æµµ        [degree]    */
    float  m_fSlat;        /* Áß½ÉÀ§µµ        [degree]    */
    float  m_fOlon;        /* ±âÁØÁ¡ÀÇ °æµµ   [degree]    */
    float  m_fOlat;        /* ±âÁØÁ¡ÀÇ À§µµ   [degree]    */
    float  m_fXo;          /* ±âÁØÁ¡ÀÇ XÁÂÇ¥  [°ÝÀÚ°Å¸®]  */
    float  m_fYo;          /* ±âÁØÁ¡ÀÇ YÁÂÇ¥  [°ÝÀÚ°Å¸®]  */
}st_AzedParameter;

typedef struct {
    int     m_nFirst;       /* ½ÃÀÛ¿©ºÎ (0 = Ã³À½)         */
    double  m_dRe;
    double  m_dSlon;
    double  m_dSlat;
    double  m_dOlon;
    double  m_dOlat;
    double  m_dXo;
    double  m_dYo;
    double  m_dPI;
    double  m_dDegrad;
    double  m_dRaddeg;
}st_AzedVar;


/* ================================================================================ */
// FUNCTION PROTO

int fnCgiLamcproj(float *pLon, float *pLat, float *pX, float *pY, int nCode, st_LAMC_PARAMETER *p_Map, st_LAMC_VAR *p_Var);
st_LAMC_PARAMETER fnCgiGetMapInfo(float fRe, float fSlat1, float fSlat2, float fOriginLon, float fOriginLat, float fGridKm, int nOriginX, int nOriginY);
int fnCgiAzedProj(float *fLon,float *fLat, float *fX, float *fY , int nCode, st_AzedParameter Map, st_AzedVar *Mapv);
st_AzedParameter fnCgiGetMapInfoAzed(float fRe, float fCenterLon, float fCenterLat, float fOriginLon, float fOriginLat, float fGridKm, int nOriginX, int nOriginY);
    
/* ================================================================================ */

#endif /* CGI_CMM_MAP_INI_H */
