#ifndef CGI_CMM_UTIL_H
#define CGI_CMM_UTIL_H

/* ================================================================================ */
// DEFINE

#define CGI_DF_DEFAULT_ZR_A     (200.)
#define CGI_DF_DEFAULT_ZR_B     (1.6)
#define CGI_DF_SNOW_ZR_A        (2000.)
#define CGI_DF_SNOW_ZR_B        (2.0)

/* ================================================================================ */
// FUNCTION PROTO

float**  fnGetMatrixFloat(int nYDim, int nXDim);
int**    fnGetMatrixInt(int nYDim, int nXDim);
double*  fnGetAxisDataDouble(int nDim);
void     fnFreeMatrixFloat(float** pMatrix, int nXDim);
void     fnFreeMatrixInt(int** pMatrix, int nXDim);
void     fnFreeAxisDataFloat(float* pAxis);
int      fnDbzToRainrate(float** data, int nYDim, int nXDim, float fOutBound_f, float fBadValue_f, float fZr_a, float fZr_b);
int      fnRainrateToDbz(float** data, int nYDim, int nXDim, float fOutBound_f, float fBadValue_f, float fZr_a, float fZr_b);
double   fnDbz_To_R_f(double dDbz,float fZr_a,float fZr_b);
double   fnR_to_dBZ_f(double fRain, float fZr_a, float fZr_b);


// 시간 함수 추가
struct tm fnGetIncYear(struct tm tm_ptr, int nAddYear);
struct tm fnGetIncMonth(struct tm tm_ptr, int nAddMonth);
struct tm fnGetIncDay(struct tm tm_ptr, int nAddDay);
struct tm fnGetIncMin(struct tm tm_ptr, int nAddMin);

// 해당 년, 월의 마지막날 계산
int fnChkLeapYear(int nYear);
int fnGetLastDay(int nYear, int nMon);

//
void fnSwap2bytes(void *pWord);
void fnDumpDisp(void);

/* ================================================================================ */

#endif /* ALLOC_H */
