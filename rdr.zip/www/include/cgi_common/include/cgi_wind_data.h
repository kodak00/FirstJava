
#ifndef CGI_WIND_DATA_H    
#define CGI_WIND_DATA_H
float fnUV_To_S(float u, float v);
float fnUV_To_D(float u, float v);
float fnR_To_D(float r);
#endif
