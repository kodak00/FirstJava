#ifndef CGI_COMP_ECHO_H
#define CGI_COMP_ECHO_H

/* ================================================================================ */
// DEFINE


/* ================================================================================ */
// FUNCTION PROTO

int     fnComp480EchoDisp(int nImgXdim, int nImgYdim, char szUnit[], float** pImgData, gdImagePtr pImg, int rgnColor[], CGI_COLOR_TBL* pColor_ini);
int     fnCompEchoDisp(int nImgXdim, int nImgYdim, char szP_type[], char szUnit[], float** pImgData, gdImagePtr pImg, int rgnColor[], CGI_COLOR_TBL* pColor_ini);
int     fnCompCj3EchoDisp(int nImgXdim, int nImgYdim, char szP_type[], char szUnit[], float** pImgData, gdImagePtr pImg, int rgnColor[], CGI_COLOR_TBL* pColor_ini);
int     fnComp3dEchoDisp(int nImgXdim, int nImgYdim, char szP_type[], char szUnit[], float** pImgData, gdImagePtr pImg, int rgnColor[], CGI_COLOR_TBL* pColor_ini);
int     fnCompTitanDisp(int nImgXdim, int nImgYdim, char szUnit[], float** pImgData, gdImagePtr pImgTitan, int rgnColorTitan[], CGI_COLOR_TBL* pColor_ini);

/* ================================================================================ */

#endif /* CGI_COMP_ECHO_H */
