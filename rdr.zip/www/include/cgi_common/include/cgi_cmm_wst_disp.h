#ifndef CGI_CMM_WST_H
#define CGI_CMM_WST_H

/* ================================================================================ */
// DEFINE

#define  WST_BUF_MAX_STR     1024
#define  WST_FILE_SIZE       128
#define  WST_DATE_SIZE       13
#define  WST_FILE            "/DATA/INPUT/WST/%Y%m/%d/WST_%Y%m%d%H00.txt"

/* ================================================================================ */
// FUNCTION PROTO

int fnCompWstDisp(float fLU_lon, float fLU_lat, char szDate[], int nImgXdim, int nImgYdim, float fXDist, float fYDist, gdImagePtr pImg);
//char  *strptime(const char *s, const char *format, struct tm *tm);

/* ================================================================================ */

#endif /* CGI_COMP_WST_H */
