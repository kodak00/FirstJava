/* ================================================================================ */
//
// LGT Disp Header
//
// 2016.09.26 SnK 
//
/* ================================================================================ */

#ifndef CGI_LGT_DISP_H
#define CGI_LGT_DISP_H

/* ================================================================================ */
// Define

#define  FONT_PATH               "/srv/kres/cgi_project/resource/font"
#define  FONT_SIZE               137
#define  TEXT_SIZE               126
#define  DATE_SIZE               100
#define  BRECT_SIZE              8
#define  IMAGE_INDEX_RIGHT_SIZE  45
#define  LGT_AREA_COLOR_FILE     "/srv/kres/cgi_project/resource/color/kma_lgt_area_comis.col"
#define  LGT_TIME_COLOR_FILE     "/srv/kres/cgi_project/resource/color/kma_lgt_time_comis.col"
#define  LGT_POW_COLOR_FILE      "/srv/kres/cgi_project/resource/color/kma_lgt_pow_comis.col"
#define  LEVEL_TEXT_GAP          5
#define  LEVEL_MAX               6

/* ================================================================================ */
// Enum



/* ================================================================================ */
// Struct



/* ================================================================================ */
// Function

void fnImageCircle(gdImagePtr pImg, int nX, int nY, int nColor);
void fnImagePlus(gdImagePtr pImg, int nX, int nY, int nColor);
void fnImageFillArc(gdImagePtr pImg, int nX, int nY, int nWidth, int nHeight, int nColor);
int  fnCreateLevelColorImg(char szP_type[], int nImgYdim, char szEndTime[], int nLgt_intv); 
int  fnImgTopTextDisp(gdImagePtr pImg, char szP_type[], char szStartTime[], char szEndTime[], int nLgt_intv, int nImgXdim);

/* ================================================================================ */

#endif



