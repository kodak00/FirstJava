/* ================================================================================ */
//
// 2016.07.29
//
// SnK : Choi Hyun-Jun
//
/* ================================================================================ */
#ifndef CGI_SITE_CALC_H
#define CGI_SITE_CALC_H

float fnCalcRadarValue_Map(float** pData, int nDataXdim, int nDataYdim, int nDiff_x, int nDiff_y, int nXpoint, int nYpoint, float fGridScale);
float fnCalcRadarValue(float** pData, int nDataXdim, int nDataYdim, int nDiff_x, int nDiff_y, int nXpoint, int nYpoint, float fXGridScale, float fYGridScale);

#endif
