/* ================================================================================ */
//
// 2016.07.29
//
// SnK : Choi Hyun-Jun
//
/* ================================================================================ */
#ifndef CGI_SITE_DATA_H
#define CGI_SITE_DATA_H
#include <zlib.h>
/* ================================================================================ */
// DEFINE

typedef struct
{
    float   m_fElev;
    float   m_fSrange;
} st_CappiLoc;

typedef struct
{
    int     nX1;
    int     nY1;
    int     nX2;
    int     nY2;
    int     nDtype;
    float   fHeightFromRadar;
    st_Azimuth** table;
} st_Thr_Arg;

typedef enum {REAL_CAPPI, PSEUDO_CAPPI} CAPPI_TYPE;

typedef struct
{
    int      m_rgnValid[2];
    float    m_rgfDbz[2];//dBZ
    int      m_rgnBinNum[2];
    float    m_rgfR[2];//meter
} st_CloestValues;

typedef struct
{
    int      m_rgnValid[2];
    int      m_rgnAzim[2];
    float    m_rgfTheta[2];
    st_CloestValues m_tValues[2];
} st_CloestAzims;


typedef struct
{
    int     m_rgnValid[2];
    int     m_rgnS[2];
    float   m_rgfPhi[2];//elevation
    st_CloestAzims m_tAzims[2];
} st_CloestSweeps;

#define VIL_MAX_THR     (4)
typedef struct
{
    ST_UF_DATA  *m_pUf;
    int         m_nHeight;
    st_Azimuth  **m_ppTable;
    int         m_nXdim;
    int         m_nYdim;
    int         m_nRange;
    float       *m_pData;
    int         m_nIdx;
    float       **m_ppData;
} st_VilCappiThrArg;

typedef struct
{
    float       **m_ppData;
    int         m_nHeight;
    int         m_nStartIdx;
    int         m_nEndIdx;
    float       *m_pVilData;
} st_VilThrArg;

/* ================================================================================ */
// FUNCTION PROTO

float fnGetGridKm(int nMapLevel);
int fnDel_Indenpent_Echo(float *pfImsiData, int nXdim, int nYdim);
float* fnVolumeToBASE(ST_UF_DATA *pUf, int nXdim, int nYdim, int nRange, st_Azimuth** table);
float* fnVolumeToVIL(ST_UF_DATA *pUf, int nXdim, int nYdim, int nRange, int nTop_h_km, int nBottom_h_km, st_Azimuth** table);
float* fnVolumeToCMAX(ST_UF_DATA *pUf, int nXdim, int nYdim, int nRange, st_Azimuth** table);

float* fnVolumeToETOP(ST_UF_DATA *pUf, int xdim, int ydim, int range, int radar_height, float etop_min_threshold, float grid_km, st_Azimuth** table);

ST_UF_DATA* fnReadUfFile(char *szFilename, char *szField, float fAzimuthCorrection);
st_Azimuth* fnMakeHashTable(ST_UF_DATA *pUf, int nSweepNo);

float *fnKRL_SweepToCart(ST_UF_DATA *pUf, int nSweepNo, int nXdim, int nYdim, float fRange, st_Azimuth* table);
//float* fnKRL_SweepToCart_CAPPI(ST_UF_DATA *pUf, int nXdim, int nYdim, float nRange, st_Azimuth* table);

float fnCAPPI_At_h_Cart(ST_UF_DATA *pUf, float fHeight_Km, int nXdim, int nYdim, float fGridSize_Km, int nXIdx, int nYIdx, CAPPI_TYPE pseudo_cappi, int nIs_Dbz, int nIsCross, st_Azimuth** table);

float* fnMakeMohrCappi(ST_UF_DATA *pUf, int nIs_Dbz, int nYdim, int nXdim, float fSiteGridKm, int nY1, int nY2, int nX1, int nX2, float fHeightFromRadar, st_Azimuth** table);

float* fnMakeMohrCappi_Cross(ST_UF_DATA *pUf, int nIs_Dbz, int nYdim, int nXdim, float fSiteGridKm, int nY1, int nY2, int nX1, int nX2, float fHeightFromRadar, st_Azimuth** table);

float fnUV_To_S(float u, float v);
float fnR_To_D(float r);
float fnUV_To_d(float u, float v);

/* ================================================================================ */
#endif //DATA_H_
