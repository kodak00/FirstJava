#ifndef CGI_COMP_WST_H
#define CGI_COMP_WST_H

/* ================================================================================ */
// DEFINE

#define  WST_BUF_MAX_STR     1024
#define  WST_FILE_SIZE       128
#define  WST_DATE_SIZE       13
#define  WST_FILE            "/DATA/INPUT/WST/%Y%m/%d/WST_%Y%m%d%H00.txt"

/* ================================================================================ */
// FUNCTION PROTO

int fnCompWstDisp(float fImgGridKm, float fLU_lon, float fLU_lat, char szDate[], int nImgXdim, int nImgYdim, float fDataLon, float fDataLat, float fXDist, float fYDist, float fCompGridKm, int nDataYdim, gdImagePtr pImg);

/* ================================================================================ */

#endif /* CGI_COMP_WST_H */
