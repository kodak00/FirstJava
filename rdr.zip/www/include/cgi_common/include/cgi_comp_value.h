#ifndef CGI_COMP_VALUE_H
#define CGI_COMP_VALUE_H

/* ================================================================================ */
// DEFINE

#define  BAD_VALUE_C            (-127.0)
#define  BAD_VALUE_F            (-9999.0)
#define  BAD_VALUE_S            (-32767.0)
#define  BOUND_VALUE_C          (-128.0)
#define  BOUND_VALUE_F          (-9998.0)
#define  BOUND_VALUE_S          (-32768.0)

/* ================================================================================ */
#endif /* CGI_COMP_VALUE_H */
