/* ================================================================================ */
//
// 2016.07.29
//
// SnK : Choi Hyun-Jun
//
/* ================================================================================ */
#ifndef CGI_WIND_DRAW_H
#define CGI_WIND_DRAW_H

void fnNoDataDisp(int nImgYdim, int nImgXdim);
int fnWindDraw(gdImagePtr pImg, WIND w, int nLine_Color, int nSize, int nWing, int nImgXdim, int nImgYdim); 

#endif
