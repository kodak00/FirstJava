
#ifndef CGI_SITE_UF_H
#define CGI_SITE_UF_H

#define MAX_NUM_TILTS           20
#define MAX_NUM_AZIMUTH         1000
#define MAX_NUM_GATES           2000
#define MAX_FIELDS              10


#define BADVAL  (float)0x20000
#define RFVAL (BADVAL-1) /* Range folded value.  See rfival. */
#define APFLAG (BADVAL-2)
#define NOTFOUND_H (BADVAL-3)
#define NOTFOUND_V (BADVAL-4)
#define NOECHO (BADVAL-5)


/*  Basis of this file is http://www.atd.ucar.edu/documents/univ_format.txt,
    much of the file is included as comments here.

The original report for the format can be found in:

	Barnes, Stanley L, 1980: Report on a meeting to establish a
	common Doppler radar data exchange format.
	The Bulletin of the American Meteorological Society, Vol 61,
	    No. 11, pp1401-1404. Nov 1980


                  Universal Format Radar Tape Structure
		  =====================================
                  

Universal format tapes conform to the following five specification:

 1. 9 track tapes, 1600 or 6250 cpi density. [Now extended to other media]
 2. 16-bit words, signed integers, 2's complement.
           [Note that words are "big-endian" (most significant byte at end of word)]
 3. Physical records, length <= 4095 words.  [Record lengths now < 65536 bytes.]
 4. File marks between volume scans (volumes).
 5. ASCII words are left justified, blank filled.

*/


typedef short int int16;

                                /* MANDATORY HEADER BLOCK */
#pragma pack(push, 1)
typedef struct {
    char uf_name[2];			/* UF (ASCII) */
    int16 record_length;			/* 16 bit words */
    int16 first_word_position;	/* Position of first word of nonmandatory header block.  (If no
         							nonmandatory header block exists, this points to the first
         							existing header block following the mandatory.  In this way,
        								word (3) always gives 1 + the length of the mandatory header. */
    int16 first_word_local;		/*Position of first word of local use header block.  (If no local
           							use headers exist, this points to the start of the data
           							header block.) */
    int16 first_word_data_header; /*Position of first word of data header block */
    int16 physical_record_number; /*Physical record number relative to beginning of file */
    int16 volume_scan_number;     /*Volume scan number relative to beginning of tape */
    int16 ray_number;			  /*Ray number within volume scan */
    int16 physical_record_number_for_ray; /* Physical record number within the ray (one for the first
                                                physical record of each ray) */
    int16 sweep_number;           /*Sweep number within this volume scan */
    char  radar_name[8];          /*Radar name (8ASCII characters, includes processor ID.) */
    char  site_name[8];
    int16 degrees_latitude;       /*(North is positive, South is negative) */
    int16 minutes_latitude;
    int16 seconds_latitude;       /*Seconds (x64) of latitude */
    int16 degrees_longitude;      /*(East is positive, West is negative) */
    int16 minutes_longitude;
    int16 seconds_longitude;      /*Seconds (x64) of longitude (Note:  minutes and seconds have same sign as degrees.) */
    int16 height;                 /*Height of antenna above sea level (meters) */
    int16 year;                   /*Year (of data)  (last 2 digits) */
    int16 month;
    int16 day;
    int16 hour;
    int16 minute;
    int16 second;
    char time_zone[2];           /*Time zone (2 ASCII -- UT, CS, MS, etc.) */
    int16 azimuth;               /*Azimuth (degrees x 64) to midpoint of sample */
    int16 elevation;             /*Elevation (degrees x 64) */
    int16 sweep_mode;            /*0 - Calibration
                                    1 - PPI (Constant elevation)
                                    2 - Coplane
                                    3 - RHI (Constant azimuth)
                                    4 - Vertical
                                    5 - Target (stationary)
                                    6 - Manual
                                    7 - Idle (out of control) */
    int16 fixed_angle;         /*Fixed angle (degrees x 64) (e.g., elevation of PPI; azimuth
                                    of RHI; coplane angle) */
    int16 sweep_rate;         /*sweep rate (degrees/seconds x 64) */
    int16 generation_year;    /*Generation date of common format - Year */
    int16 generation_month;
    int16 generation_day;
    char facility[8];         /*Tape generator facility name (8 character ASCII) */
    int16 deleted_data;       /*Deleted of missing data flag (Suggest 100000 octal)*/

} mandatory_header_block;
#pragma pack(pop)

typedef struct {char bufferarea [65536]; } bigbuffer;
typedef struct {int16 data[32767]; } databuffer;

//typedef union
//{
//	bigbuffer buffer_area;
//    mandatory_header_block header;
//    databuffer data_area;
//}  uf_input_buffer;
        /*

OPTIONAL HEADER BLOCK

  Word
  1-4   Project name (8 ASCII)
    5   Baseline azimuth (degrees x 64)
    6   Baseline elevation (degrees x 64)
    7   Hour (start of current volume scan)
    8   Minute (start of current volume scan)
    9   Second (start of current volume scan)
10-13   Field tape name (8 ASCII)
   14   Flag (= 0 if number of range gates, R min, and spacing are the
          same for all data within this volume scan; = 1 if these are
          the same only within each sweep; = 2 if these are the same
          only within each ray).


LOCAL USE HEADER BLOCK

  Any use, any contents


DATA HEADER

  Word
    1   Total number of fields this ray
    2   Total number of records this ray
    3   Total number of fields this record
    4   1st field name (2 ASCII): e.g., VE - velocity (m/s)
                                        SW - spectral width (m/s)
                                        DM - reflected power dB(mW)
                                        DZ - dB(Z)
                                        etc.
    5   Position of 1st word of 1st field header
    6   2nd field name
    7   Position of 1st word of 2nd field header
   etc.
*/

#pragma pack(push, 1)
//typedef struct
//{
//    int16 fields_this_ray;
//	int16 records_this_ray;
//	int16 fields_this_record;
//
//	char  field_name1[2];
//	int16 first_word_field1;
//
//	char  field_name2[2];
//	int16 first_word_field2;
//
//	char  field_name3[2];		// ???
//	int16 first_word_field3;	// ???
//
//} uf_data_header;
#pragma pack(pop)


/*
FIELD HEADER

  Word
    1   Position of first data word
    2   Scale factor (meteorological units = tape value divided by
         scale factor)
    3   Range to first gate (km)
    4   Adjustment to center of first gate (m)
    5   Sample Volume spacing (m)
    6   Number of sample volumes
    7   Sample volume depth (m)
    8   Horizontal beam width (degrees x 64)
    9   Vertical beam width (degrees x 64)
   10   Receiver bandwidth (MHz)
   11   Polarization transmitted (0 = horizontal; 1 =vertical;
         2 = circular; >2 = elliptical)
   12   Wavelength (cm x 64)
   13   Number of samples used in field estimate
   14   Threshold field (e.g., DM) (2 ASCII)
   15   Threshold value
   16   Scale
   17   Edit code (2 ASCII)
   18   Pulse repetition time (microseconds)
   19   Bits per sample volume (16 for exchanged tape)
 20-?   Words for individual fields, as follows

  for VF, VE, VR, VT, VP:
  word
   20   Nyquist velocity (scaled)
   21   FL (2 ASCII) if flagged in least significant bit with
         NCAR bad velocity flag (1 = good, 0 = bad)

  for DM:
  word
   20   Radar constant = RC, such that dB(Z) = [ (RC + DATA/SCALE] +
          20log(range in km)
   21   Noise power (dB(mW) x scale)
   22   Receiver gain (dB x scale)
   23   Peak power (dB(mW) x scale)
   24   Antenna gain (dB x scale)
   25   Pulse duration (microseconds x 64)
   
   */
#pragma pack(push, 1)
typedef struct
{
	int16 first_word_data;
	int16 scale_factor;
	int16 range_first_gate;
	int16 adj_to_center;
	int16 sample_volume_spacing;
	int16 number_of_sample_volumes;
	int16 sample_volume_depth;
	int16 horizontal_beam_width;
	int16 vertical_beam_width;
	int16 receiver_bandwidth;
	int16 polarization_transmitted;
	int16 wavelength;
	int16 samples_in_field_estimate;
	char  threshold_field[2];
	int16 threshold_value;
	int16 scale;
	char  edit_code[2];
	int16 prt;
	int16 bits_per_sample_volume;
	//       int16 radar_constant;
	//       int16 noise_power;
	//       int16 receiver_gain;
	//       int16 peak_power;
	//       int16 antenna_gain;
	//       int16 pulse_duration;
} uf_ref_field_header;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct
{
	int16 first_word_data;
	int16 scale_factor;
	int16 range_first_gate;
	int16 adj_to_center;
	int16 sample_volume_spacing;
	int16 number_of_sample_volumes;
	int16 sample_volume_depth;
	int16 horizontal_beam_width;
	int16 vertical_beam_width;
	int16 receiver_bandwidth;
	int16 polarization_transmitted;
	int16 wavelength;
	int16 samples_in_field_estimate;
	char  threshold_field[2];
	int16 threshold_value;
	int16 scale;
	char  edit_code[2];
	int16 prt;
	int16 bits_per_sample_volume;
	int16 nyquist_velocity;
	char  flag[2];

} uf_vel_field_header;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct
{
	int16 first_word_data;
	int16 scale_factor;
	int16 range_first_gate;
	int16 adj_to_center;
	int16 sample_volume_spacing;
	int16 number_of_sample_volumes;
	int16 sample_volume_depth;
	int16 horizontal_beam_width;
	int16 vertical_beam_width;
	int16 receiver_bandwidth;
	int16 polarization_transmitted;
	int16 wavelength;
	int16 samples_in_field_estimate;
	char  threshold_field[2];
	int16 threshold_value;
	int16 scale;
	char  edit_code[2];
	int16 prt;
	int16 bits_per_sample_volume;
} uf_sw_field_header;
#pragma pack(pop)


//*****************************************************************************
// UNKNOWN HEARDER
//*****************************************************************************
#pragma pack(push, 1)
typedef struct
{
	int16 first_word_data;
	int16 scale_factor;
	int16 range_first_gate;
	int16 adj_to_center;
	int16 sample_volume_spacing;
	int16 number_of_sample_volumes;
	int16 sample_volume_depth;
	int16 horizontal_beam_width;
	int16 vertical_beam_width;
	int16 receiver_bandwidth;
	int16 polarization_transmitted;
	int16 wavelength;
	int16 samples_in_field_estimate;
	char  threshold_field[2];
	int16 threshold_value;
	int16 scale;
	char  edit_code[2];
	int16 prt;
	int16 bits_per_sample_volume;
	
} uf_un_field_header;
#pragma pack(pop)



#define SHORT_BSWAP(a) ((((a) & 0xff) << 8) | (((a) >> 8) & 0xff))
#define INT_BSWAP(a) ((((a) & 0xff) << 24) | (((a) & 0xff00) << 8) | \
                                        (((a) >> 8) & 0xff00) | (((a) >> 24) & 0xff))
#define INT_SSWAP(a) ((((a) & 0xffff) << 16) | (((a) >> 16) & 0xffff))

#define SHORT_SSWAP(a) {short z; z = a[0]; a[0] = a[1]; a[1] = z;}
#define FLOAT_BSWAP(a) {char *z, t; z = (char *)&a; t = z[0]; z[0] = z[3]; \
                                z[3] = t; t = z[1]; z[1] = z[2]; z[2] = t;}
#define MISSING                 -32768
#define DEG_COEFF               64.0f
#define ROUND_OFF               0.49f

//#define MAX_FIELDS              10      // MAX FIELD
//#define MAX_NUM_TILTS           20      // MAX SWEEP
//#define MAX_NUM_AZIMUTH         1000     // MAX RAY
//#define MAX_NUM_RAY             500
//#define MAX_NUM_GATES           2000    // MAX GATE

typedef struct
{
    float   m_fElev;
    float   m_fSrange;
} CAPPI_LOC;

typedef struct
{
    float m_fAzimuth;
    int m_nCon;
    int m_nHigh;
    int m_nLow;
} st_Azimuth;

typedef struct
{
    float               m_fNyqVel;
    float               m_fBeamWidth;
    float               m_fV_BeamWidth;
    float               m_fSiteLon;
    float               m_fSiteLat;
    int                 m_nSweeps;
    int                 m_nHeight;

    float               m_fData[MAX_NUM_TILTS][MAX_NUM_AZIMUTH][MAX_NUM_GATES];
    float               m_AZIM[MAX_NUM_TILTS][MAX_NUM_AZIMUTH];
    float               m_fUfElevation[MAX_NUM_TILTS];
    int                 m_rgnRays[MAX_NUM_TILTS];
    int                 m_nBins[MAX_NUM_TILTS][MAX_NUM_AZIMUTH];
    int                 m_nGateSize[MAX_NUM_TILTS][MAX_NUM_AZIMUTH];
    int                 m_nRangeBin[MAX_NUM_TILTS][MAX_NUM_AZIMUTH];
    
    // 고도각 임시파일 저장용
    int                 m_nFieldCnt;
    char                szField_Name[MAX_FIELDS][2+1];

    // CAPPI 생산용
//    CAPPI_LOC           m_cappi_loc[MAX_NUM_GATES];
//    float               m_CappiData[MAX_NUM_AZIMUTH][MAX_NUM_GATES];
} ST_UF_DATA;

//extern float uf_elevation[MAX_NUM_TILTS];
//
//extern float g_data[MAX_NUM_TILTS][MAX_NUM_AZIMUTH][MAX_NUM_GATES];
//
//extern float g_AZIM[MAX_NUM_TILTS][MAX_NUM_AZIMUTH];
//
//extern int g_nbins[MAX_NUM_TILTS][MAX_NUM_AZIMUTH];
//extern int g_gate_size[MAX_NUM_TILTS][MAX_NUM_AZIMUTH];
//extern int g_range_bin1[MAX_NUM_TILTS][MAX_NUM_AZIMUTH];

// CAPPI 추가
//extern float g_cappi_data[MAX_NUM_AZIMUTH][MAX_NUM_GATES];
//extern CAPPI_LOC g_cappi_loc[MAX_NUM_GATES];
// CAPPI 추가

//#define     M_PI      3.14159265358979323846
//#define BADVAL  (float)0x20000
//#define NOTFOUND_H (BADVAL-3)
//#define NOTFOUND_V (BADVAL-4)

#endif
