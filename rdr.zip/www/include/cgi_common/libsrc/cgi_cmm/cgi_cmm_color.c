/* ================================================================================ */
//
// Radar Image Color Function
//
// 2016.08.25 SnK 
//
/* ================================================================================ */
// Include

#include <stdlib.h>
#include <string.h>
#include <gd.h>

#include "cgi_cmm_color.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function



/* ================================================================================ */
// Function
 
CGI_COLOR_TBL *fnReadColorTable(char *szFile)
{
    CGI_COLOR_TBL   *pColorTbl                  = NULL;
    FILE            *pFp                        = NULL;
    char            szPathFile[CGI_DF_STR_LENGTH_MAX]  = "";
    char            szLine[CGI_DF_STR_LENGTH_MAX]      = "";
    int             iColorIdx                   = 0;
    int             iColorCnt                   = 0;
    int             iDispColorIdx               = 0;
    int             iNum                        = 0;
    int             iR                          = 0;
    int             iG                          = 0;
    int             iB                          = 0;
    float           fRain                       = 0.0;
    float           fUnit                       = 0.0;

    if(szFile == NULL)
        return NULL;

    pColorTbl = (CGI_COLOR_TBL *)calloc(1, sizeof(CGI_COLOR_TBL));
    if(pColorTbl == NULL)
        return NULL;

    snprintf(szPathFile, sizeof(szPathFile), "%s", szFile);
    if((pFp = fopen(szPathFile, "rt")) == NULL)
    {   free(pColorTbl); return NULL; }

    memset(szLine, 0x00, sizeof(szLine));
    if(fgets(szLine, sizeof(szLine), pFp) == NULL)
    {   free(pColorTbl); fclose(pFp); return NULL; }
    iColorCnt = atoi(szLine);

    memset(szLine, 0x00, sizeof(szLine));
    if(fgets(szLine, sizeof(szLine), pFp) == NULL)
    {   free(pColorTbl); fclose(pFp); return NULL; }
    szLine[strlen(szLine)-1] = '\0';
    snprintf(pColorTbl->m_szRainTitle, sizeof(pColorTbl->m_szRainTitle), "%s", szLine);
    
    memset(szLine, 0x00, sizeof(szLine));
    if(fgets(szLine, sizeof(szLine), pFp) == NULL)
    {   free(pColorTbl); fclose(pFp); return NULL; }
    szLine[strlen(szLine)-1] = '\0';
    snprintf(pColorTbl->m_szUnitTitle, sizeof(pColorTbl->m_szUnitTitle), "%s", szLine);

    for(iColorIdx = 0; iColorIdx < iColorCnt; iColorIdx++)
    {
        memset(szLine, 0x00, sizeof(szLine));
        if(fgets(szLine, sizeof(szLine), pFp) == NULL)
        {   free(pColorTbl); fclose(pFp); return NULL; }

        if(sscanf(szLine, "%d %d %d %d %f %f", &iNum, &iR, &iG, &iB, &fRain, &fUnit) != 6)
        {   free(pColorTbl); fclose(pFp); return NULL; }

        iDispColorIdx = -1;
        if     (fRain == CGI_DF_SKIP_COLOR)      continue;
        else if(fRain == CGI_DF_LINE_COLOR)      iDispColorIdx = CGI_EN_LINE_COLOR;
        else if(fRain == CGI_DF_FONT_COLOR)      iDispColorIdx = CGI_EN_FONT_COLOR;
        else if(fRain == CGI_DF_IN_BOUND_COLOR)  iDispColorIdx = CGI_EN_IN_BOUND_COLOR;
        else if(fRain == CGI_DF_OUT_BOUND_COLOR) iDispColorIdx = CGI_EN_OUT_BOUND_COLOR;
        else if(fRain == CGI_DF_AWS_COLOR)       iDispColorIdx = CGI_EN_AWS_COLOR;
        
        if(iDispColorIdx >= 0 && iDispColorIdx < CGI_EN_DISP_COLOR_MAX)
        {
                pColorTbl->m_dispColorTbl[iDispColorIdx].m_iNum  = iNum;
                pColorTbl->m_dispColorTbl[iDispColorIdx].m_iR    = iR;
                pColorTbl->m_dispColorTbl[iDispColorIdx].m_iG    = iG;
                pColorTbl->m_dispColorTbl[iDispColorIdx].m_iB    = iB;
                pColorTbl->m_dispColorTbl[iDispColorIdx].m_fRain = fRain;
                pColorTbl->m_dispColorTbl[iDispColorIdx].m_fUnit = fUnit;
        }
        else
        {
            if(pColorTbl->m_iEchoColorCnt < CGI_DF_COLOR_MAX)
            {
                pColorTbl->m_echoColorTbl[pColorTbl->m_iEchoColorCnt].m_iNum  = iNum;
                pColorTbl->m_echoColorTbl[pColorTbl->m_iEchoColorCnt].m_iR    = iR;
                pColorTbl->m_echoColorTbl[pColorTbl->m_iEchoColorCnt].m_iG    = iG;
                pColorTbl->m_echoColorTbl[pColorTbl->m_iEchoColorCnt].m_iB    = iB;
                pColorTbl->m_echoColorTbl[pColorTbl->m_iEchoColorCnt].m_fRain = fRain;
                pColorTbl->m_echoColorTbl[pColorTbl->m_iEchoColorCnt].m_fUnit = fUnit;
                pColorTbl->m_iEchoColorCnt++;
            }
        }
    }
    fclose(pFp);

    return pColorTbl;
}

int fnAllocColorTbl(gdImagePtr pImg, CGI_COLOR_TBL *pColorTbl, int echoColorBar[CGI_DF_COLOR_MAX], int dispColorBar[CGI_EN_DISP_COLOR_MAX])
{
    int     iColorIdx   = 0;

    if(pImg == NULL || pColorTbl == NULL)
        return -1;

    for(iColorIdx = 0; iColorIdx < pColorTbl->m_iEchoColorCnt; iColorIdx++)
    {
        echoColorBar[iColorIdx] = gdImageColorAllocate(pImg, pColorTbl->m_echoColorTbl[iColorIdx].m_iR,
                                                             pColorTbl->m_echoColorTbl[iColorIdx].m_iG,
                                                             pColorTbl->m_echoColorTbl[iColorIdx].m_iB);
    }

    dispColorBar[CGI_EN_LINE_COLOR]      = gdImageColorAllocate(pImg, pColorTbl->m_dispColorTbl[CGI_EN_LINE_COLOR].m_iR,
                                                                      pColorTbl->m_dispColorTbl[CGI_EN_LINE_COLOR].m_iG,
                                                                      pColorTbl->m_dispColorTbl[CGI_EN_LINE_COLOR].m_iB);
    dispColorBar[CGI_EN_FONT_COLOR]      = gdImageColorAllocate(pImg, pColorTbl->m_dispColorTbl[CGI_EN_FONT_COLOR].m_iR,
                                                                      pColorTbl->m_dispColorTbl[CGI_EN_FONT_COLOR].m_iG,
                                                                      pColorTbl->m_dispColorTbl[CGI_EN_FONT_COLOR].m_iB);
    dispColorBar[CGI_EN_IN_BOUND_COLOR]  = gdImageColorAllocate(pImg, pColorTbl->m_dispColorTbl[CGI_EN_IN_BOUND_COLOR].m_iR,
                                                                      pColorTbl->m_dispColorTbl[CGI_EN_IN_BOUND_COLOR].m_iG,
                                                                      pColorTbl->m_dispColorTbl[CGI_EN_IN_BOUND_COLOR].m_iB);
    dispColorBar[CGI_EN_OUT_BOUND_COLOR] = gdImageColorAllocate(pImg, pColorTbl->m_dispColorTbl[CGI_EN_OUT_BOUND_COLOR].m_iR,
                                                                      pColorTbl->m_dispColorTbl[CGI_EN_OUT_BOUND_COLOR].m_iG,
                                                                      pColorTbl->m_dispColorTbl[CGI_EN_OUT_BOUND_COLOR].m_iB);
    dispColorBar[CGI_EN_AWS_COLOR]       = gdImageColorAllocate(pImg, pColorTbl->m_dispColorTbl[CGI_EN_AWS_COLOR].m_iR,
                                                                      pColorTbl->m_dispColorTbl[CGI_EN_AWS_COLOR].m_iG,
                                                                      pColorTbl->m_dispColorTbl[CGI_EN_AWS_COLOR].m_iB);

    return 0;
}

int fnGetColorLevel(float fData, CGI_COLOR_TBL *pColorTbl, int iColorKind, float fMinValue, int nMinDiffType, int nDiffType)
{
    int         iEchoColorIdx   = 0;
    int         iColorLevel     = 0;
    float       fCompareValue   = 0.0;

    if(pColorTbl == NULL)
        return -1;

    if(nMinDiffType == 0)
    {
        if(fData < fMinValue)
            return -1;
    }
    else if(nMinDiffType == 1)
    {
        if(fData <= fMinValue)
            return -1;
    }

    if(nDiffType == 0)
    {
        for(iEchoColorIdx = 0; iEchoColorIdx < pColorTbl->m_iEchoColorCnt; iEchoColorIdx++)
        {
            if(iColorKind == CGI_EN_COLOR_UNIT)
                fCompareValue = pColorTbl->m_echoColorTbl[iEchoColorIdx].m_fUnit;
            else if(iColorKind == CGI_EN_COLOR_RAIN)
                fCompareValue = pColorTbl->m_echoColorTbl[iEchoColorIdx].m_fRain;
            else
                return -1;

            if(fData < fCompareValue)
            {
                iColorLevel = iEchoColorIdx;
                break;
            }
        }
        if(iEchoColorIdx == pColorTbl->m_iEchoColorCnt && fData >= fCompareValue)
            iColorLevel = pColorTbl->m_iEchoColorCnt -1;
    }
    else if(nDiffType == 1)
    {
        for(iEchoColorIdx = 0; iEchoColorIdx < pColorTbl->m_iEchoColorCnt; iEchoColorIdx++)
        {
            if(iColorKind == CGI_EN_COLOR_UNIT)
                fCompareValue = pColorTbl->m_echoColorTbl[iEchoColorIdx].m_fUnit;
            else if(iColorKind == CGI_EN_COLOR_RAIN)
                fCompareValue = pColorTbl->m_echoColorTbl[iEchoColorIdx].m_fRain;
            else
                return -1;

            if(fData <= fCompareValue)
            {
                iColorLevel = iEchoColorIdx;
                break;
            }
        }
        if(iEchoColorIdx == pColorTbl->m_iEchoColorCnt && fData >= fCompareValue)
            iColorLevel = pColorTbl->m_iEchoColorCnt -1;
    }
    else if(nDiffType == 2)
    {
        for(iEchoColorIdx = pColorTbl->m_iEchoColorCnt-1; iEchoColorIdx >= 0; iEchoColorIdx--)
        {
            if(iColorKind == CGI_EN_COLOR_UNIT)
                fCompareValue = pColorTbl->m_echoColorTbl[iEchoColorIdx].m_fUnit;
            else if(iColorKind == CGI_EN_COLOR_RAIN)
                fCompareValue = pColorTbl->m_echoColorTbl[iEchoColorIdx].m_fRain;
            else
                return -1;

            if(fData > fCompareValue)
            {
                iColorLevel = iEchoColorIdx;
                break;
            }
        }
        if(iEchoColorIdx == 0 && fData <= fCompareValue)
            iColorLevel = 0;
    }

    return iColorLevel;
}

/* ================================================================================ */



