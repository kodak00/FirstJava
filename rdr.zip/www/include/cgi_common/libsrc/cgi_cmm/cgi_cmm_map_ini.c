/* ================================================================================ */
//
// 레이더 에코 영상 GIS - map_ini.c (맵정보, 위경도 -> 좌표)
//
// 2016.07.29
//
// SnK
//
//  **********************************************************************
//  *                                                                    *
//  *  [ Lambert Conformal Conic Projection ]                            *
//  *                                                                    *
//  *      o lon, lat : (longitude,latitude) at earth  [degree]          *
//  *      o x, y     : (x,y) cordinate in map  [grid]                   *
//  *      o code = 0 : (lon,lat) --> (x,y)                              *
//  *               1 : (x,y) --> (lon,lat)                              *
//  *                                                                    *
//  **********************************************************************
//
/* ================================================================================ */
// INCLUDE

#include <stdio.h>
#include <math.h>

#include "cgi_cmm_map_ini.h"

/* ================================================================================ */
// FUNCTION

int fnCgiLamcproj(pLon, pLat, pX, pY, nCode, p_Map, p_Var)
float                  *pLon, *pLat;     //VARIABLE     /* Longitude, Latitude [degree]  */
float                  *pX, *pY;         //VARIABLE     /* Coordinate in Map   [grid]    */
int                    nCode;            //VARIABLE     /* (0) lon,lat -> x,y  (1) x,y -> lon,lat */
st_LAMC_PARAMETER  *p_Map;
st_LAMC_VAR        *p_Var;
{
    double         dSlat1, dSlat2, dAlon, dAlat, dXn, dYn, dRa, dTheta;              //VARIABLE

    if (p_Var->m_nFirst == 0) 
    {
        p_Var->m_sdPI       = asin(1.0)*2.0;
        p_Var->m_sdDEGRAD   = p_Var->m_sdPI/180.0;
        p_Var->m_sdRADDEG   = 180.0/p_Var->m_sdPI;


        p_Var->m_sdRe       = p_Map->m_fRe/p_Map->m_fGrid;
        dSlat1              = p_Map->m_fSlat1 * p_Var->m_sdDEGRAD;
        dSlat2              = p_Map->m_fSlat2 * p_Var->m_sdDEGRAD;
        p_Var->m_sdOlon     = p_Map->m_fOlon * p_Var->m_sdDEGRAD;
        p_Var->m_sdOlat     = p_Map->m_fOlat * p_Var->m_sdDEGRAD;

        p_Var->m_sdSn       = tan(p_Var->m_sdPI*0.25 + dSlat2*0.5)/tan(p_Var->m_sdPI*0.25 + dSlat1*0.5);
        p_Var->m_sdSn       = log(cos(dSlat1)/cos(dSlat2))/log(p_Var->m_sdSn);
        p_Var->m_sdSf       = tan(p_Var->m_sdPI*0.25 + dSlat1*0.5);
        p_Var->m_sdSf       = pow(p_Var->m_sdSf, p_Var->m_sdSn)*cos(dSlat1)/p_Var->m_sdSn;
        p_Var->m_sdRo       = tan(p_Var->m_sdPI*0.25 + p_Var->m_sdOlat*0.5);
        p_Var->m_sdRo       = p_Var->m_sdRe*p_Var->m_sdSf/pow(p_Var->m_sdRo,p_Var->m_sdSn);
           
        dRa                 = tan(p_Var->m_sdPI*0.25+(*pLat)*p_Var->m_sdDEGRAD*0.5);
        dRa                 = p_Var->m_sdRe*p_Var->m_sdSf/pow(dRa,p_Var->m_sdSn);
        dTheta              = (*pLon)*p_Var->m_sdDEGRAD - p_Var->m_sdOlon;
        p_Var->m_nFirst = 1;
    }
    
    if (nCode == 0) 
    {
        dRa      = tan(p_Var->m_sdPI*0.25+(*pLat)*p_Var->m_sdDEGRAD*0.5);
        dRa      = p_Var->m_sdRe*p_Var->m_sdSf/pow(dRa,p_Var->m_sdSn);
        dTheta   = (*pLon)*p_Var->m_sdDEGRAD - p_Var->m_sdOlon;
        
        if (dTheta > p_Var->m_sdPI)
        {       
            dTheta -= 2.0*p_Var->m_sdPI;
        }
        if (dTheta < -(p_Var->m_sdPI))
        {
            dTheta += 2.0*p_Var->m_sdPI;
        }
            
        dTheta   *= p_Var->m_sdSn;
        *pX      = (float)(dRa*sin(dTheta)) + p_Map->m_fXo;
        *pY      = (float)(p_Var->m_sdRo - dRa*cos(dTheta)) + p_Map->m_fYo;
    }
    else
    {
        dXn = *pX - p_Map->m_fXo;
        dYn = p_Var->m_sdRo - *pY + p_Map->m_fYo;
        dRa = sqrt(dXn*dXn+dYn*dYn);
        dAlat = pow((p_Var->m_sdRe*p_Var->m_sdSf/dRa),(1.0/p_Var->m_sdSn));
        dAlat = 2.0*atan(dAlat) - p_Var->m_sdPI*0.5;
        if(fabs(dXn) <= 0.0) 
        {
            dTheta = 0.0;
        } 
        else 
        {
            if(fabs(dYn) <= 0.0) 
            {
                dTheta = p_Var->m_sdPI*0.5;
            } 
            else
            {
                dTheta = atan2(dXn,dYn);
            }
        }
        dAlon = dTheta/p_Var->m_sdSn + p_Var->m_sdOlon;
        *pLat = (float)(dAlat*p_Var->m_sdRADDEG);
        *pLon = (float)(dAlon*p_Var->m_sdRADDEG); 
    }   

    return 0;
}

st_LAMC_PARAMETER fnCgiGetMapInfo(float fRe, float fSlat1, float fSlat2, float fOriginLon, float fOriginLat, float fGridKm, int nOriginX, int nOriginY)
{
    st_LAMC_PARAMETER st_Map;  //VARIABLE

    st_Map.m_fRe    = fRe;
    st_Map.m_fSlat1 = fSlat1;
    st_Map.m_fSlat2 = fSlat2;
    st_Map.m_fOlon  = fOriginLon;
    st_Map.m_fOlat  = fOriginLat;
    st_Map.m_fGrid  = fGridKm;
    st_Map.m_fXo    = nOriginX;
    st_Map.m_fYo    = nOriginY;

    return st_Map;
}

st_AzedParameter fnCgiGetMapInfoAzed(float fRe, float fCenterLon, float fCenterLat, float fOriginLon, float fOriginLat, float fGridKm, int nOriginX, int nOriginY)
{
    st_AzedParameter  AzedParameter;
    
    AzedParameter.m_fRe   = fRe;
    AzedParameter.m_fSlon = fCenterLon;
    AzedParameter.m_fSlat = fCenterLat;
    AzedParameter.m_fOlon = fOriginLon;
    AzedParameter.m_fOlat = fOriginLat;
    AzedParameter.m_fXo   = nOriginX;
    AzedParameter.m_fYo   = nOriginY;
    AzedParameter.m_fGrid = fGridKm;
    
    return AzedParameter;
}


int  fnCgiAzedProj(float *fLon, float *fLat, float *fX, float *fY, int nCode, st_AzedParameter Map, st_AzedVar *Mapv)
{
    double dAlon    = 0.0;
    double dAlat    = 0.0;
    double dAk      = 0.0;
    double dXn      = 0.0;
    double dYn      = 0.0;
    double dRa      = 0.0;
    double dTheta   = 0.0;
    double dAc      = 0.0;
    double dA1      = 0.0;
    double dA2      = 0.0;

	if ((*Mapv).m_nFirst == 0)
	{
		(*Mapv).m_dPI       = PI_DFS;//asin(1.0)*2.0;
        (*Mapv).m_dDegrad   = (*Mapv).m_dPI/180.0;
        (*Mapv).m_dRaddeg   = 180.0/(*Mapv).m_dPI;
        (*Mapv).m_dRe       = Map.m_fRe/Map.m_fGrid;
        (*Mapv).m_dSlon     = Map.m_fSlon * (*Mapv).m_dDegrad;
        (*Mapv).m_dSlat     = Map.m_fSlat * (*Mapv).m_dDegrad;
        (*Mapv).m_dOlon     = Map.m_fOlon * (*Mapv).m_dDegrad;
        (*Mapv).m_dOlat =    Map.m_fOlat * (*Mapv).m_dDegrad;
        
        dAk = sin((*Mapv).m_dSlat)*sin((*Mapv).m_dOlat) + cos((*Mapv).m_dSlat)*cos((*Mapv).m_dOlat)*cos((*Mapv).m_dOlon-(*Mapv).m_dSlon);
        
        if (dAk < -0.99999) return -1;
        else if (dAk > 0.99999)
        {
            dAk = 1.0;
        }
        else
        {
            dAk = acos(dAk);
            dAk = dAk / sin(dAk);
        }
        (*Mapv).m_dXo = (*Mapv).m_dRe*dAk*cos((*Mapv).m_dOlat)*sin((*Mapv).m_dOlon-(*Mapv).m_dSlon) - Map.m_fXo;
        (*Mapv).m_dYo = (*Mapv).m_dRe*dAk*(cos((*Mapv).m_dSlat)*sin((*Mapv).m_dOlat) - sin((*Mapv).m_dSlat)*cos((*Mapv).m_dOlat)*cos((*Mapv).m_dOlon-(*Mapv).m_dSlon)) - Map.m_fYo;
        (*Mapv).m_nFirst = 1;
    }

    if (nCode == 0) {			//(lon,lat) --> (x,y)
        dAlat = (*fLat)*(*Mapv).m_dDegrad;
        dAlon = (*fLon)*(*Mapv).m_dDegrad - (*Mapv).m_dSlon;
        dAk   = sin((*Mapv).m_dSlat)*sin(dAlat) + cos((*Mapv).m_dSlat)*cos(dAlat)*cos(dAlon);

        if (dAk < -0.99999) return -1;
        if (dAk > 0.99999)
        {
            dAk = 1.0;
        }
        else
        {
            dAk = acos(dAk);
            dAk = dAk / sin(dAk);
        }
        
        *fX = (*Mapv).m_dRe*dAk*cos(dAlat)*sin(dAlon) - (*Mapv).m_dXo;
        *fY = (*Mapv).m_dRe*dAk*(cos((*Mapv).m_dSlat)*sin(dAlat) - sin((*Mapv).m_dSlat)*cos(dAlat)*cos(dAlon)) - (*Mapv).m_dYo;
    }
    else {					//(x,y) --> (lon,lat)
        dXn = *fX + (*Mapv).m_dXo;
        dYn = *fY + (*Mapv).m_dYo;
        dRa = dXn*dXn + dYn*dYn;
        if (dRa <= 0.0)
        {
            dAlat = (*Mapv).m_dSlat;
        }
        else
        {
            dRa   = sqrt(dRa);
            dAc   = dRa/(*Mapv).m_dRe;
            dAlat = cos(dAc)*sin((*Mapv).m_dSlat) + dYn*sin(dAc)*cos((*Mapv).m_dSlat)/dRa;
            dAlat = asin(dAlat);
        }

        *fLat = dAlat*(*Mapv).m_dRaddeg;
        dA1   = dXn*sin(dAc);
        dA2   = dRa*cos((*Mapv).m_dSlat)*cos(dAc) - dYn*sin((*Mapv).m_dSlat)*sin(dAc);

        if (fabs(dA2) <= 0.0)
        {
            dTheta = (*Mapv).m_dPI*0.5;
            if (dA2 < 0.0) dTheta = -dTheta;
        }
        else
        {
            dTheta = atan2(dA1, dA2);
        }
        *fLon = (dTheta + (*Mapv).m_dSlon)*(*Mapv).m_dRaddeg;
    }
    return 0;
}
/* ================================================================================ */

