/* ================================================================================ */
//
// Radar Image Make Function
//
// 2016.08.30 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"
#include "rdr_image.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function

static int fnGetSiteImgComment(char* szProduct, char *szSiteCode, time_t tConvertTime, int iUnit, RDR_DISP_INFO_TBL dispInfo, char *pBuf, int iBufLen)
{
    char            szDateTime[32]  = "";
    struct  tm      tm;

    if(szProduct == NULL || szSiteCode == NULL || pBuf == NULL || iBufLen <= 0)
        return FALSE;

    memset(&tm, 0x00, sizeof(struct tm));
    localtime_r(&tConvertTime, &tm);
    strftime(szDateTime, sizeof(szDateTime), "%Y.%m.%d. %H:%M(KST)", &tm);

    if(!strcmp(szProduct, "PPI")  || !strcmp(szProduct, "CAPPI") || !strcmp(szProduct, "BASE") || !strcmp(szProduct, "CMAX"))
    {
        if(iUnit == RDR_EN_DBZ_TO_RAIN)
            snprintf(pBuf, iBufLen, "%s Radar %s(Rain) %s", szSiteCode, szProduct, szDateTime);
        else
            snprintf(pBuf, iBufLen, "%s Radar %s(%s) %s", szSiteCode, szProduct, dispInfo.m_szFieldName, szDateTime);
    }
    else if(!strcmp(szProduct, "VIL"))
    {
        snprintf(pBuf, iBufLen, "%s Radar %s(Rain) %s", szSiteCode, szProduct, szDateTime);
    }
    else if(!strcmp(szProduct, "ETOP"))
    {
        snprintf(pBuf, iBufLen, "%s Radar %s(%s) %s", szSiteCode, szProduct, dispInfo.m_szFieldName, szDateTime);
    }

    return TRUE;
}

static int fnGetCompImgComment(char *szImgKind, char *szProduct, time_t tConvertTime, char *szQcStr, RDR_DISP_INFO_TBL dispInfo, char *pBuf, int iBufLen)
{
    char            szDateTime[32]  = "";
    struct  tm      tm;

    if(szProduct == NULL || szQcStr == NULL || pBuf == NULL || iBufLen <= 0)
        return FALSE;

    memset(&tm, 0x00, sizeof(struct tm));
    localtime_r(&tConvertTime, &tm);
    strftime(szDateTime, sizeof(szDateTime), "%Y.%m.%d. %H:%M(KST)", &tm);

    if(!strcmp(szImgKind, "COMP_240"))
    {
        if(!strcmp(szProduct, "PPI")  || !strcmp(szProduct, "CAPPI") || 
           !strcmp(szProduct, "BASE") || !strcmp(szProduct, "CMAX"))
        {
            snprintf(pBuf, iBufLen, "%s(%s) %s Rain Rate", szProduct, szQcStr, szDateTime);
        }
        else if(!strcmp(szProduct, "VIL"))
        {
            snprintf(pBuf, iBufLen, "%s(%s) %s", szProduct, szQcStr, szDateTime);
        }
        else if(!strcmp(szProduct, "ETOP"))
        {
            snprintf(pBuf, iBufLen, "%s(%s) %s", szProduct, szQcStr, szDateTime);
        }
    }
    else if(!strcmp(szImgKind, "COMP_480"))
    {
        snprintf(pBuf, iBufLen, "PPI0 480km Rainrate %s", szDateTime);
    }
    else if(!strcmp(szImgKind, "COMP_KCJ"))
    {
        snprintf(pBuf, iBufLen, "PPI0 %s %s Rainrate", szQcStr, szDateTime);
    }

    return TRUE;
}

static gdImagePtr fnMakeSiteImageTop(char* szProduct, char *szSiteCode, time_t tConvertTime, int iUnit, RDR_COLOR_TBL *pColorTbl, RDR_DISP_INFO_TBL dispInfo, RDR_IMG_INFO_TBL imgInfo)
{
    gdImagePtr      pImg                    = NULL;
    int             iBlackColor             = 0;
    int             iWhiteColor             = 0;
    int             iWidth                  = 0;
    int             iHeight                 = 0;
    char            szComment[256]          = "";
    char            szUnit[32]              = "";
    char            szFont[STR_LENGTH_MAX]  = "";
    double          dFontSize               = 0.0;

    if(szProduct == NULL || szSiteCode == NULL || pColorTbl == NULL)
        return NULL;

    iWidth  = imgInfo.m_iRightWidth + imgInfo.m_iImgXdim;
    iHeight = imgInfo.m_iTopHeight;
    
    if((pImg = gdImageCreateTrueColor(iWidth, iHeight)) == NULL)
        return NULL;

    iBlackColor = gdImageColorAllocate(pImg,   0,   0,   0);
    iWhiteColor = gdImageColorAllocate(pImg, 255, 255, 255);

    gdImageFilledRectangle(pImg, 0, 0, iWidth, iHeight, iWhiteColor);

    if(fnGetSiteImgComment(szProduct, szSiteCode, tConvertTime, iUnit, dispInfo, szComment, sizeof(szComment)) == FALSE)
    {
        gdImageDestroy(pImg);
        return NULL;
    }

    if(dispInfo.m_iColorKind == RDR_EN_COLOR_UNIT)
        snprintf(szUnit, sizeof(szUnit), pColorTbl->m_szUnitTitle);
    else if(dispInfo.m_iColorKind == RDR_EN_COLOR_RAIN)
        snprintf(szUnit, sizeof(szUnit), pColorTbl->m_szRainTitle);

    snprintf(szFont, sizeof(szFont), "%s/resource/font/%s", RDR_DF_APP_ROOT_PATH, RDR_DF_COMMENT_FONT_FILE);
    dFontSize = RDR_DF_COMMENT_FONT_SIZE;
    gdImageStringTTF(pImg, NULL, iBlackColor, szFont, dFontSize, 0.0, 
                     0, iHeight - RDR_DF_COMMENT_UPPER_SPACE, szComment);

    dFontSize = RDR_DF_UNIT_FONT_SIZE;
    gdImageStringTTF(pImg, NULL, iBlackColor, szFont, dFontSize, 0.0, 
                     iWidth - RDR_DF_UNIT_STR_WIDTH, iHeight - RDR_DF_COMMENT_UPPER_SPACE, szUnit);

    return pImg;
}

static gdImagePtr fnMakeCompImageTop(char *szImgKind, char* szProduct, time_t tConvertTime, char* szQcStr, RDR_COLOR_TBL *pColorTbl, RDR_DISP_INFO_TBL dispInfo, RDR_IMG_INFO_TBL imgInfo)
{
    gdImagePtr      pImg                    = NULL;
    int             iBlackColor             = 0;
    int             iWhiteColor             = 0;
    int             iWidth                  = 0;
    int             iHeight                 = 0;
    char            szComment[256]          = "";
    char            szUnit[32]              = "";
    char            szFont[STR_LENGTH_MAX]  = "";
    double          dFontSize               = 0.0;

    if(szProduct == NULL || pColorTbl == NULL)
        return NULL;

    iWidth  = imgInfo.m_iRightWidth + imgInfo.m_iImgXdim;
    iHeight = imgInfo.m_iTopHeight;
    
    if((pImg = gdImageCreateTrueColor(iWidth, iHeight)) == NULL)
        return NULL;

    iBlackColor = gdImageColorAllocate(pImg,   0,   0,   0);
    iWhiteColor = gdImageColorAllocate(pImg, 255, 255, 255);

    gdImageFilledRectangle(pImg, 0, 0, iWidth, iHeight, iWhiteColor);

    if(fnGetCompImgComment(szImgKind, szProduct, tConvertTime, szQcStr, dispInfo, szComment, sizeof(szComment)) == FALSE)
    {
        gdImageDestroy(pImg);
        return NULL;
    }

    if(dispInfo.m_iColorKind == RDR_EN_COLOR_UNIT)
        snprintf(szUnit, sizeof(szUnit), pColorTbl->m_szUnitTitle);
    else if(dispInfo.m_iColorKind == RDR_EN_COLOR_RAIN)
        snprintf(szUnit, sizeof(szUnit), pColorTbl->m_szRainTitle);

    snprintf(szFont, sizeof(szFont), "%s/resource/font/%s", RDR_DF_APP_ROOT_PATH, RDR_DF_COMMENT_FONT_FILE);
    dFontSize = RDR_DF_COMMENT_FONT_SIZE;
    gdImageStringTTF(pImg, NULL, iBlackColor, szFont, dFontSize, 0.0, 
                     0, iHeight - RDR_DF_COMMENT_UPPER_SPACE, szComment);

    dFontSize = RDR_DF_UNIT_FONT_SIZE;
    gdImageStringTTF(pImg, NULL, iBlackColor, szFont, dFontSize, 0.0, 
                     iWidth - RDR_DF_UNIT_STR_WIDTH, iHeight - RDR_DF_COMMENT_UPPER_SPACE, szUnit);

    return pImg;
} 

static int fnDispColorBarBox(gdImagePtr pImg, int iEchoColorCnt, int colorBar[RDR_DF_COLOR_MAX], int iHeight)
{
    int             iBlackColor                 = 0;
    int             iYpos                       = 0;
    int             iColorIdx                   = 0;
    float           fCell_Ydim                  = 0.0;
    int             iDispCount                  = 0;

    if(pImg == NULL)
        return FALSE;

    fCell_Ydim = (float)iHeight/(float)iEchoColorCnt;
    iDispCount = 0;

    iBlackColor = gdImageColorAllocate(pImg,   0,   0,   0);

    for(iColorIdx = iEchoColorCnt-1; iColorIdx >= 0; iColorIdx--)
    {
        iYpos = fCell_Ydim * iDispCount;

        if(iColorIdx > 0)
            gdImageFilledRectangle(pImg, 0, iYpos, RDR_DF_COLOR_BAR_WIDTH, iYpos+fCell_Ydim, colorBar[iColorIdx]);
        else
            gdImageFilledRectangle(pImg, 0, iYpos, RDR_DF_COLOR_BAR_WIDTH, iHeight, colorBar[iColorIdx]);

        iDispCount++;
    }

    gdImageRectangle(pImg, 0, 0, RDR_DF_COLOR_BAR_WIDTH, iHeight-1, iBlackColor);

    return TRUE;
}

static int fnDispColorBarStr(char *szProduct, gdImagePtr pImg, RDR_COLOR_TBL *pColorTbl, RDR_DISP_INFO_TBL dispInfo, int iHeight)
{
    int             iBlackColor                 = 0;
    int             iXpos                       = 0;
    int             iYpos                       = 0;
    int             iColorIdx                   = 0;
    float           fCell_Ydim                  = 0.0;
    int             iDispCount                  = 0;
    char            szUnit[32]                  = "";
    char            szFormat[8]                 = "";

    if(pImg == NULL)
        return FALSE;

    fCell_Ydim = (float)iHeight/(float)pColorTbl->m_iEchoColorCnt;

    iBlackColor = gdImageColorAllocate(pImg,   0,   0,   0);

    iXpos = RDR_DF_COLOR_BAR_WIDTH + RDR_DF_LEGEND_STR_SPACE;

    for(iColorIdx = pColorTbl->m_iEchoColorCnt-2; iColorIdx >= 0; iColorIdx--)
    {
        if(dispInfo.m_iColorKind == RDR_EN_COLOR_RAIN || !strcmp(szProduct, "ETOP"))
        {
            if(pColorTbl->m_echoColorTbl[iColorIdx].m_fRain < 10) // 강수량 10 미만은 소수점 표현
                strcpy(szFormat, "%.1f");
            else
                strcpy(szFormat, "%.0f");
        }
        else
            strcpy(szFormat, dispInfo.m_szDispFormat);

        if(dispInfo.m_iColorKind == RDR_EN_COLOR_RAIN)
            snprintf(szUnit, sizeof(szUnit), szFormat, pColorTbl->m_echoColorTbl[iColorIdx].m_fRain);
        else
            snprintf(szUnit, sizeof(szUnit), szFormat, pColorTbl->m_echoColorTbl[iColorIdx].m_fUnit);

        iYpos  = fCell_Ydim * iDispCount;
        iYpos += fCell_Ydim - gdFontGetSmall()->h/2;

        gdImageString(pImg, gdFontGetSmall(), iXpos, iYpos, (unsigned char *)szUnit, iBlackColor);

        iDispCount++;
    }

    return TRUE;
}

static gdImagePtr fnMakeSiteImageRight(char* szProduct, RDR_COLOR_TBL *pColorTbl, RDR_DISP_INFO_TBL dispInfo, RDR_IMG_INFO_TBL imgInfo)
{
    gdImagePtr      pImg                                = NULL;
    int             iWhiteColor                         = 0;
    int             iWidth                              = 0;
    int             iHeight                             = 0;
    int             echoColorBar[RDR_DF_COLOR_MAX]      = { 0, };
    int             dispColorBar[RDR_EN_DISP_COLOR_MAX] = { 0, };

    if(szProduct == NULL || pColorTbl == NULL)
        return NULL;

    iWidth  = imgInfo.m_iRightWidth;
    iHeight = imgInfo.m_iImgYdim;
    
    if((pImg = gdImageCreateTrueColor(iWidth, iHeight)) == NULL)
        return NULL;

    iWhiteColor = gdImageColorAllocate(pImg, 255, 255, 255);

    if(fnAllocColorTbl(pImg, pColorTbl, echoColorBar, dispColorBar) == FALSE)
    {
        gdImageDestroy(pImg);
        return NULL;
    }

    gdImageFilledRectangle(pImg, 0, 0, iWidth, iHeight, iWhiteColor);

    // Color bar Disp
    if(fnDispColorBarBox(pImg, pColorTbl->m_iEchoColorCnt, echoColorBar, iHeight) == FALSE)
    {
        gdImageDestroy(pImg);
        return NULL;
    }

    if(fnDispColorBarStr(szProduct, pImg, pColorTbl, dispInfo, iHeight) == FALSE)
    {
        gdImageDestroy(pImg);
        return NULL;
    }

    return pImg;
}

static gdImagePtr fnMakeCompImageRight(char *szProduct, RDR_COLOR_TBL *pColorTbl, RDR_DISP_INFO_TBL dispInfo, RDR_IMG_INFO_TBL imgInfo)
{
    gdImagePtr      pImg                                = NULL;
    int             iWhiteColor                         = 0;
    int             iWidth                              = 0;
    int             iHeight                             = 0;
    int             echoColorBar[RDR_DF_COLOR_MAX]      = { 0, };
    int             dispColorBar[RDR_EN_DISP_COLOR_MAX] = { 0, };

    if(szProduct == NULL || pColorTbl == NULL)
        return NULL;

    iWidth  = imgInfo.m_iRightWidth;
    iHeight = imgInfo.m_iImgYdim;
    
    if((pImg = gdImageCreateTrueColor(iWidth, iHeight)) == NULL)
        return NULL;

    iWhiteColor = gdImageColorAllocate(pImg, 255, 255, 255);

    if(fnAllocColorTbl(pImg, pColorTbl, echoColorBar, dispColorBar) == FALSE)
    {
        gdImageDestroy(pImg);
        return NULL;
    }

    gdImageFilledRectangle(pImg, 0, 0, iWidth, iHeight, iWhiteColor);

    // Color bar Disp
    if(fnDispColorBarBox(pImg, pColorTbl->m_iEchoColorCnt, echoColorBar, iHeight) == FALSE)
    {
        gdImageDestroy(pImg);
        return NULL;
    }

    if(fnDispColorBarStr(szProduct, pImg, pColorTbl, dispInfo, iHeight) == FALSE)
    {
        gdImageDestroy(pImg);
        return NULL;
    }

    return pImg;
}

static gdImagePtr fnMakeSiteImageBottom(char* szProduct, double dProductArg1, double dProductArg2, double dNi, RDR_DISP_INFO_TBL dispInfo, RDR_IMG_INFO_TBL imgInfo)
{
    gdImagePtr      pImg            = NULL;
    int             iWhiteColor     = 0;
    int             iBlackColor     = 0;
    int             iWidth          = 0;
    int             iHeight         = 0;
    char            szComment[256]  = "";
    char            szTempStr1[128] = "";
    char            szTempStr2[128] = "";
    char            szTempStr3[128] = "";

    if(szProduct == NULL)
        return NULL;

    iWidth  = imgInfo.m_iImgXdim + imgInfo.m_iRightWidth;
    iHeight = imgInfo.m_iBottomHeight;
    
    if((pImg = gdImageCreateTrueColor(iWidth, iHeight)) == NULL)
        return NULL;

    iBlackColor = gdImageColorAllocate(pImg,   0,   0,   0);
    iWhiteColor = gdImageColorAllocate(pImg, 255, 255, 255);

    gdImageFilledRectangle(pImg, 0, 0, iWidth, iHeight, iWhiteColor);
    gdImageRectangle(pImg, 0, 0, imgInfo.m_iImgXdim + RDR_DF_COLOR_BAR_WIDTH, iHeight-1, iBlackColor);

    if(!strcmp(szProduct, "PPI"))
        snprintf(szTempStr1, sizeof(szTempStr1), "Elevation:%.2f", dProductArg1);
    else if(!strcmp(szProduct, "CAPPI"))
        snprintf(szTempStr1, sizeof(szTempStr1), "Height:%.1f", dProductArg1);

    if(!strcmp(dispInfo.m_szFieldName, "VR"))
        snprintf(szTempStr2, sizeof(szTempStr2), "Nyq.Vel:%.2fm/s", dNi);

    snprintf(szComment, sizeof(szComment), "%s %s %s", szTempStr1, szTempStr2, szTempStr3);

    gdImageString(pImg, gdFontGetSmall(),
                  RDR_DF_BOTTOM_LEFT_SPACE, RDR_DF_BOTTOM_UPPER_SPACE, 
                  (unsigned char*)szComment, iBlackColor);

    return pImg;
}

static gdImagePtr fnMakeSiteImageEcho(char* szProduct, int iDbzToRain, float **ppData, int iYdim, int iXdim, float fSiteLon, float fSiteLat, float fSiteGridKm, int iUnit, int iSmoothNum, int iDrawAws, int iDrawRing, int iDrawDirection, RDR_COLOR_TBL *pColorTbl, RDR_DISP_INFO_TBL dispInfo, RDR_IMG_INFO_TBL imgInfo)
{
    gdImagePtr      pImg                                = NULL;
    int             iBlackColor                         = 0;
    int             iWidth                              = 0;
    int             iHeight                             = 0;
    int             echoColorBar[RDR_DF_COLOR_MAX]      = { 0, };
    int             dispColorBar[RDR_EN_DISP_COLOR_MAX] = { 0, };
    float           fImgGridKm                          = 0.0;
    float           **ppImgData                         = NULL;

    if(szProduct == NULL || ppData == NULL || pColorTbl == NULL)
        return NULL;

    iWidth  = imgInfo.m_iImgXdim;
    iHeight = imgInfo.m_iImgYdim;
    
    if((pImg = gdImageCreateTrueColor(iWidth, iHeight)) == NULL)
        return NULL;

    if(fnAllocColorTbl(pImg, pColorTbl, echoColorBar, dispColorBar) == FALSE)
    {   gdImageDestroy(pImg); return NULL; }

    if((imgInfo.m_iImgXdim * imgInfo.m_iImgGridKm) < (iYdim * fSiteGridKm))
        fImgGridKm = (iYdim * fSiteGridKm) / imgInfo.m_iImgXdim;
    else if(imgInfo.m_iImgGridKm == RDR_DF_IMG_GRID_AUTO)
        fImgGridKm = (iYdim * fSiteGridKm) / imgInfo.m_iImgXdim;
    else
        fImgGridKm = imgInfo.m_iImgGridKm;

    if((ppImgData = fnMakeSiteImageData(ppData, iYdim, iXdim, fSiteGridKm, iWidth, iHeight, fImgGridKm)) == NULL)
    {   gdImageDestroy(pImg); return NULL; }

    if(fnKmaCmpSmooth(ppImgData, iHeight, iWidth, iSmoothNum) == FALSE)
    {   fnFreeMatrix2D((void **)ppImgData, iHeight); gdImageDestroy(pImg); return NULL; }

    if(!strcmp(dispInfo.m_szFieldName, "RN") && iDbzToRain == TRUE)
    {
        if(fnDbzToRainrate(ppImgData, iHeight, iWidth, iUnit) == FALSE)
        {   fnFreeMatrix2D((void **)ppImgData, iHeight); return NULL; }
    }

    if(fnDrawRadarImgBound(pImg, ppImgData, iWidth, iHeight, RDR_DF_OUT_BOUND_F, 
                          dispColorBar[RDR_EN_IN_BOUND_COLOR], dispColorBar[RDR_EN_OUT_BOUND_COLOR]) == FALSE)
    {   fnFreeMatrix2D((void **)ppImgData, iHeight); gdImageDestroy(pImg); return NULL; }

    if(fnDrawRadarEcho(pImg, ppImgData, iWidth, iHeight, pColorTbl, dispInfo.m_iColorKind, 
                       dispInfo.m_fMinValue, imgInfo.m_iMinDiffType, imgInfo.m_iEchoDIffType, echoColorBar) == FALSE)
    {   fnFreeMatrix2D((void **)ppImgData, iHeight); gdImageDestroy(pImg); return NULL; }

    if(fnDrawSiteImgMap(pImg, iWidth, iHeight, fImgGridKm, fSiteLon, fSiteLat, 
                        (float)(iWidth/2), (float)(iHeight/2), dispColorBar[RDR_EN_LINE_COLOR]) == FALSE)
    {   fnFreeMatrix2D((void **)ppImgData, iHeight); gdImageDestroy(pImg); return NULL; }

    if(iDrawRing == TRUE)
    {
        if(fnDrawSiteImgRing(pImg, iWidth, iHeight, fImgGridKm, dispColorBar[RDR_EN_LINE_COLOR]) == FALSE)
        {   fnFreeMatrix2D((void **)ppImgData, iHeight); gdImageDestroy(pImg); return NULL; }
    }

    if(iDrawDirection == TRUE)
    {
        if(fnDrawSiteImgDirection(pImg, iWidth, iHeight, dispColorBar[RDR_EN_LINE_COLOR]) == FALSE)
        {   fnFreeMatrix2D((void **)ppImgData, iHeight); gdImageDestroy(pImg); return NULL; }
    }

    if(iDrawAws == TRUE)
    {
        if(fnDrawSiteImgAws(pImg, iWidth, iHeight, fImgGridKm, fSiteLon, fSiteLat, 
                            (float)(iWidth/2), (float)(iHeight/2), 
                            dispColorBar[RDR_EN_AWS_COLOR], dispColorBar[RDR_EN_FONT_COLOR]) == FALSE)
        {   fnFreeMatrix2D((void **)ppImgData, iHeight); gdImageDestroy(pImg); return NULL; }
    }

    iBlackColor = gdImageColorAllocate(pImg,   0,   0,   0);
    gdImageRectangle(pImg, 0, 0, iWidth, iHeight, iBlackColor);

    fnFreeMatrix2D((void **)ppImgData, iHeight);

    return pImg;
}

static gdImagePtr fnMakeCompImageEcho(char *szImgKind, char *szProduct, int iDbzToRain, float **ppData, int iYdim, int iXdim, float fCompGridKm, int iUnit, int iSmoothNum, int iDrawAws, RDR_COLOR_TBL *pColorTbl, RDR_DISP_INFO_TBL dispInfo, RDR_IMG_INFO_TBL imgInfo)
{
    gdImagePtr      pImg                                = NULL;
    int             iBlackColor                         = 0;
    int             iWidth                              = 0;
    int             iHeight                             = 0;
    int             echoColorBar[RDR_DF_COLOR_MAX]      = { 0, };
    int             dispColorBar[RDR_EN_DISP_COLOR_MAX] = { 0, };
    float           fImgGridKm                          = 0.0;
    float           **ppImgData                         = NULL;

    if(ppData == NULL || szProduct == NULL || pColorTbl == NULL)
        return NULL;

    iWidth  = imgInfo.m_iImgXdim;
    iHeight = imgInfo.m_iImgYdim;
    
    if((pImg = gdImageCreateTrueColor(iWidth, iHeight)) == NULL)
        return NULL;

    if(fnAllocColorTbl(pImg, pColorTbl, echoColorBar, dispColorBar) == FALSE)
    {   gdImageDestroy(pImg); return NULL; }

    fImgGridKm = imgInfo.m_iImgGridKm;

    if((ppImgData = fnMakeCompImageData(szImgKind, ppData, iYdim, iXdim, fCompGridKm, 
                                        iWidth, iHeight, fImgGridKm)) == NULL)
    {   gdImageDestroy(pImg); return NULL; }

    if(!strcmp(dispInfo.m_szFieldName, "RN") && iDbzToRain == TRUE)
    {
        if(fnDbzToRainrate(ppImgData, iHeight, iWidth, iUnit) == FALSE)
        {   fnFreeMatrix2D((void **)ppImgData, iHeight); return NULL; }
    }

    if(iSmoothNum > 0)
    {
//        if(fnCompSmooth(ppImgData, iHeight, iWidth) == FALSE)
//        {   fnFreeMatrix2D((void **)ppImgData, iHeight); gdImageDestroy(pImg); return NULL; }
    }

    if(fnDrawRadarImgBound(pImg, ppImgData, iWidth, iHeight, RDR_DF_OUT_BOUND_F, 
                          dispColorBar[RDR_EN_IN_BOUND_COLOR], dispColorBar[RDR_EN_OUT_BOUND_COLOR]) == FALSE)
    {   fnFreeMatrix2D((void **)ppImgData, iHeight); gdImageDestroy(pImg); return NULL; }

    if(fnDrawRadarEcho(pImg, ppImgData, iWidth, iHeight, pColorTbl, dispInfo.m_iColorKind, 
                       dispInfo.m_fMinValue, imgInfo.m_iMinDiffType, imgInfo.m_iEchoDIffType, echoColorBar) == FALSE)
    {   fnFreeMatrix2D((void **)ppImgData, iHeight); gdImageDestroy(pImg); return NULL; }

    if(fnDrawCompImgMap(szImgKind, pImg, iWidth, iHeight, fImgGridKm, 
                        imgInfo.m_iCompOrgX, imgInfo.m_iCompOrgY, 0, 0, dispColorBar[RDR_EN_LINE_COLOR]) == FALSE)
    {   fnFreeMatrix2D((void **)ppImgData, iHeight); gdImageDestroy(pImg); return NULL; }

    iBlackColor = gdImageColorAllocate(pImg,   0,   0,   0);
    gdImageRectangle(pImg, 0, 0, iWidth, iHeight-1, iBlackColor);

    fnFreeMatrix2D((void **)ppImgData, iHeight);

    return pImg;
}

static gdImagePtr fnMergeSiteImg(gdImagePtr pTopImg, gdImagePtr pRightImg, gdImagePtr pBottomImg, gdImagePtr pEchoImg, int iImgWidth, int iImgHeight, RDR_IMG_INFO_TBL imgInfo)
{
    gdImagePtr      pImg        = NULL;
    gdImagePtr      pResizeImg  = NULL;
    int             iWidth      = 0;
    int             iHeight     = 0;

    if(pTopImg == NULL || pRightImg == NULL || pBottomImg == NULL || pEchoImg == NULL)
        return NULL;
    
    iWidth  = imgInfo.m_iImgXdim + imgInfo.m_iRightWidth;
    iHeight = imgInfo.m_iImgYdim + imgInfo.m_iTopHeight + imgInfo.m_iBottomHeight;

    if((pImg = gdImageCreateTrueColor(iWidth, iHeight)) == NULL)
        return NULL;

    gdImageCopy(pImg, pTopImg,    0, 0, 0, 0, imgInfo.m_iImgXdim + imgInfo.m_iRightWidth, imgInfo.m_iTopHeight);

    gdImageCopy(pImg, pRightImg,  imgInfo.m_iImgXdim, imgInfo.m_iTopHeight, 0, 0, imgInfo.m_iRightWidth, imgInfo.m_iImgYdim);

    gdImageCopy(pImg, pBottomImg, 0, imgInfo.m_iTopHeight + imgInfo.m_iImgYdim, 0, 0, 
                                  imgInfo.m_iImgXdim + imgInfo.m_iRightWidth, imgInfo.m_iBottomHeight);

    gdImageCopy(pImg, pEchoImg,   0, imgInfo.m_iTopHeight, 0, 0, imgInfo.m_iImgXdim, imgInfo.m_iImgYdim);

    if(iImgWidth > 0 && iImgHeight > 0)
    {
        if((pResizeImg = gdImageCreateTrueColor(iImgWidth, iImgHeight)) == NULL)
        {
            gdImageDestroy(pImg);
            return NULL;
        }

        gdImageCopyResampled(pResizeImg, pImg, 0, 0, 0, 0, iImgWidth, iImgHeight, iWidth, iHeight);

        gdImageDestroy(pImg);

        return pResizeImg;
    }

    return pImg;
}

static gdImagePtr fnMergeCompImg(gdImagePtr pTopImg, gdImagePtr pRightImg, gdImagePtr pEchoImg, int iImgWidth, int iImgHeight, RDR_IMG_INFO_TBL imgInfo)
{
    gdImagePtr      pImg        = NULL;
    gdImagePtr      pResizeImg  = NULL;
    int             iWidth      = 0;
    int             iHeight     = 0;

    if(pTopImg == NULL || pRightImg == NULL || pEchoImg == NULL)
        return NULL;
    
    iWidth  = imgInfo.m_iImgXdim + imgInfo.m_iRightWidth;
    iHeight = imgInfo.m_iImgYdim + imgInfo.m_iTopHeight;

    if((pImg = gdImageCreateTrueColor(iWidth, iHeight)) == NULL)
        return NULL;

    gdImageCopy(pImg, pTopImg,    0, 0, 0, 0, imgInfo.m_iImgXdim + imgInfo.m_iRightWidth, imgInfo.m_iTopHeight);

    gdImageCopy(pImg, pRightImg,  imgInfo.m_iImgXdim, imgInfo.m_iTopHeight, 0, 0, imgInfo.m_iRightWidth, imgInfo.m_iImgYdim);

    gdImageCopy(pImg, pEchoImg,   0, imgInfo.m_iTopHeight, 0, 0, imgInfo.m_iImgXdim, imgInfo.m_iImgYdim);

    if(iImgWidth > 0 && iImgHeight > 0)
    {
        if((pResizeImg = gdImageCreateTrueColor(iImgWidth, iImgHeight)) == NULL)
        {
            gdImageDestroy(pImg);
            return NULL;
        }

        gdImageCopyResampled(pResizeImg, pImg, 0, 0, 0, 0, iImgWidth, iImgHeight, iWidth, iHeight);

        gdImageDestroy(pImg);

        return pResizeImg;
    }

    return pImg;
}

static int fnSaveImg(gdImagePtr pImg, int iImgType, char *szOutFile)
{
    FILE*           pFp     = NULL;

    if(pImg == NULL || szOutFile == NULL)
        return FALSE;

    if((pFp = fopen(szOutFile, "w")) == NULL)
        return FALSE;

    if     (iImgType == RDR_EN_IMG_TYPE_PNG)
        gdImagePng(pImg, pFp);
    else if(iImgType == RDR_EN_IMG_TYPE_GIF)
        gdImageGif(pImg, pFp);
    else if(iImgType == RDR_EN_IMG_TYPE_JPEG)
        gdImageJpeg(pImg, pFp, 100); // 100 is highest quality
    else
    {
        fclose(pFp);
        return FALSE;
    }

    fclose(pFp);

    return TRUE;
}

/* ================================================================================ */
// Function

int fnMakeSiteImageToStdProductByIdx(char *szImgKind, char *szSiteCode, STD_PRODUCT *pStdProduct, char *szProduct, int iProductIdx, char *szFieldName, RDR_IMG_MAKE_OPTION imgOption, char *szOutFile)
{
#define FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_IDX(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(ppData     != NULL) { fnFreeMatrix2D((void **)ppData, (int)pStdProduct->m_product_hdr.m_lYsize); } \
    if(pBackImg   != NULL) { gdImageDestroy(pBackImg); } \
    if(pTopImg    != NULL) { gdImageDestroy(pTopImg); } \
    if(pRightImg  != NULL) { gdImageDestroy(pRightImg); } \
    if(pBottomImg != NULL) { gdImageDestroy(pBottomImg); } \
    if(pEchoImg   != NULL) { gdImageDestroy(pEchoImg); } \
    if(pColorTbl  != NULL) { free(pColorTbl); }

    gdImagePtr          pBackImg                    = NULL;
    gdImagePtr          pTopImg                     = NULL;
    gdImagePtr          pRightImg                   = NULL;
    gdImagePtr          pBottomImg                  = NULL;
    gdImagePtr          pEchoImg                    = NULL;
    float               **ppData                    = NULL;
    int                 iUnit                       = 0;
    int                 iDbzToRain                  = FALSE;
    double              dProductArg1                = 0.0;
    double              dProductArg2                = 0.0;
    char                szColorFile[STR_LENGTH_MAX] = "";
    RDR_COLOR_TBL       *pColorTbl                  = NULL;
    RDR_DISP_INFO_TBL   dispInfo;
    RDR_IMG_INFO_TBL    imgInfo;

    if(pStdProduct == NULL || szProduct == NULL || iProductIdx < 0 || szFieldName == NULL || szOutFile == NULL)
        return FALSE;

    if(!strcmp(szFieldName, "RN"))
    {
        ppData = fnGetStdProductDataByIdx(pStdProduct, szProduct, iProductIdx, szFieldName);
        if(ppData == NULL)
        {
            ppData = fnGetStdProductDataByIdxDBZ(pStdProduct, szProduct, iProductIdx);
            iDbzToRain = TRUE;
        }
    }
    else
        ppData = fnGetStdProductDataByIdx(pStdProduct, szProduct, iProductIdx, szFieldName);

    if(ppData == NULL)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_IDX("fnGetStdProductDataByIdx fail"); return FALSE; }
    
    if(fnGetStdProductProdpar(pStdProduct, szProduct, iProductIdx, &dProductArg1, &dProductArg2) == FALSE)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_IDX("fnGetStdProductProdpar fail"); return FALSE; }

    if(fnGetImgSizeInfo(szImgKind, &imgInfo) == FALSE) 
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_IDX("fnGetImgSizeInfo fail"); return FALSE; }

    if(!strcmp(szProduct, "VIL") || !strcmp(szFieldName, "RN"))
        iUnit = RDR_EN_DBZ_TO_RAIN;
    else
        iUnit = RDR_EN_UNIT_DEFAULT;

    if(fnGetColorFileInfo(szFieldName, &dispInfo) == FALSE)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_IDX("fnGetColorFileInfo fail"); return FALSE; }

    snprintf(szColorFile, sizeof(szColorFile), "%s/resource/color/%s", RDR_DF_APP_ROOT_PATH, dispInfo.m_szColorFIle);
    if((pColorTbl = fnReadColorTable(szColorFile)) == NULL)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_IDX("fnReadColorTable fail"); return FALSE; }

    if((pTopImg = fnMakeSiteImageTop(szProduct, szSiteCode, pStdProduct->m_product_hdr.m_tConvertTime, 
                                     iUnit, pColorTbl, dispInfo, imgInfo)) == NULL)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_IDX("pTopImg fnMakeSiteImageTop fail"); return FALSE; }

    if((pRightImg = fnMakeSiteImageRight(szProduct, pColorTbl, dispInfo, imgInfo)) == NULL)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_IDX("pRightImg fnMakeSiteImageRight fail"); return FALSE; }

    if((pBottomImg = fnMakeSiteImageBottom(szProduct, dProductArg1, dProductArg2, 
                                           pStdProduct->m_product_hdr.m_dNi, dispInfo, imgInfo)) == NULL)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_IDX("pBottomImg fnMakeSiteImageBottom fail"); return FALSE; }

    if((pEchoImg = fnMakeSiteImageEcho(szProduct, iDbzToRain, ppData, 
                                       (int)pStdProduct->m_product_hdr.m_lYsize,   (int)pStdProduct->m_product_hdr.m_lXsize,
                                       (float)pStdProduct->m_product_hdr.m_dLon,   (float)pStdProduct->m_product_hdr.m_dLat,
                                       (float)pStdProduct->m_product_hdr.m_dXscale, iUnit, imgOption.m_iSmoothNum,
                                       imgOption.m_iDrawAws, imgOption.m_iDrawRing, imgOption.m_iDrawDirection,
                                       pColorTbl, dispInfo, imgInfo)) == NULL)

    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_IDX("pEchoImg fnMakeSiteImageEcho fail"); return FALSE; }

    if((pBackImg = fnMergeSiteImg(pTopImg, pRightImg, pBottomImg, pEchoImg, 
                                  imgOption.m_iImgWidth, imgOption.m_iImgHeight, imgInfo)) == NULL)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_IDX("pBackImg fnMergeSiteImg fail"); return FALSE; }

    if(fnSaveImg(pBackImg, imgOption.m_iImgType, szOutFile) == FALSE)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_IDX("fnSaveImg fail"); return FALSE; }

    fnFreeMatrix2D((void **)ppData, (int)pStdProduct->m_product_hdr.m_lYsize);
    free(pColorTbl);
    gdImageDestroy(pBackImg);
    gdImageDestroy(pTopImg);
    gdImageDestroy(pRightImg);
    gdImageDestroy(pBottomImg);
    gdImageDestroy(pEchoImg);

    return TRUE;
}

int fnMakeSiteImageToStdProductByArg(char *szImgKind, char *szSiteCode, STD_PRODUCT *pStdProduct, char *szProduct, double dProductArg1, double dProductArg2, char *szFieldName, RDR_IMG_MAKE_OPTION imgOption, char *szOutFile)
{
#define FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_ARG(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(ppData     != NULL) { fnFreeMatrix2D((void **)ppData, (int)pStdProduct->m_product_hdr.m_lYsize); } \
    if(pBackImg   != NULL) { gdImageDestroy(pBackImg); } \
    if(pTopImg    != NULL) { gdImageDestroy(pTopImg); } \
    if(pRightImg  != NULL) { gdImageDestroy(pRightImg); } \
    if(pBottomImg != NULL) { gdImageDestroy(pBottomImg); } \
    if(pEchoImg   != NULL) { gdImageDestroy(pEchoImg); } \
    if(pColorTbl  != NULL) { free(pColorTbl); }

    gdImagePtr          pBackImg                    = NULL;
    gdImagePtr          pTopImg                     = NULL;
    gdImagePtr          pRightImg                   = NULL;
    gdImagePtr          pBottomImg                  = NULL;
    gdImagePtr          pEchoImg                    = NULL;
    int                 iUnit                       = 0;
    int                 iDbzToRain                  = FALSE;
    float               **ppData                    = NULL;
    char                szColorFile[STR_LENGTH_MAX] = "";
    RDR_COLOR_TBL       *pColorTbl                  = NULL;
    RDR_DISP_INFO_TBL   dispInfo;
    RDR_IMG_INFO_TBL    imgInfo;

    if(pStdProduct == NULL || szProduct == NULL || szFieldName == NULL || szOutFile == NULL)
        return FALSE;

    if(!strcmp(szFieldName, "RN"))
    {
        ppData = fnGetStdProductDataByArg(pStdProduct, szProduct, dProductArg1, dProductArg2, szFieldName);
        if(ppData == NULL)
        {
            ppData = fnGetStdProductDataByArgDBZ(pStdProduct, szProduct, dProductArg1, dProductArg2);
            iDbzToRain = TRUE;
        }
    }
    else
        ppData = fnGetStdProductDataByArg(pStdProduct, szProduct, dProductArg1, dProductArg2, szFieldName);

    if(ppData == NULL)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_ARG("fnGetStdProductDataByArg fail"); return FALSE; }
    
    if(fnGetImgSizeInfo(szImgKind, &imgInfo) == FALSE) 
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_ARG("fnGetImgSizeInfo fail"); return FALSE; }

    if(!strcmp(szProduct, "VIL") || !strcmp(szFieldName, "RN"))
        iUnit = RDR_EN_DBZ_TO_RAIN;
    else
        iUnit = RDR_EN_UNIT_DEFAULT;

    if(fnGetColorFileInfo(szFieldName, &dispInfo) == FALSE)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_IDX("fnGetColorFileInfo fail"); return FALSE; }

    snprintf(szColorFile, sizeof(szColorFile), "%s/resource/color/%s", RDR_DF_APP_ROOT_PATH, dispInfo.m_szColorFIle);
    if((pColorTbl = fnReadColorTable(szColorFile)) == NULL)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_ARG("fnReadColorTable fail"); return FALSE; }

    if((pTopImg = fnMakeSiteImageTop(szProduct, szSiteCode, pStdProduct->m_product_hdr.m_tConvertTime, 
                                     iUnit, pColorTbl, dispInfo, imgInfo)) == NULL)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_ARG("pTopImg fnMakeSiteImageTop fail"); return FALSE; }

    if((pRightImg = fnMakeSiteImageRight(szProduct, pColorTbl, dispInfo, imgInfo)) == NULL)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_ARG("pRightImg fnMakeSiteImageRight fail"); return FALSE; }

    if((pBottomImg = fnMakeSiteImageBottom(szProduct, dProductArg1, dProductArg2, 
                                           pStdProduct->m_product_hdr.m_dNi, dispInfo, imgInfo)) == NULL)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_ARG("pBottomImg fnMakeSiteImageBottom fail"); return FALSE; }

    if((pEchoImg = fnMakeSiteImageEcho(szProduct, iDbzToRain, ppData, 
                                       (int)pStdProduct->m_product_hdr.m_lYsize,   (int)pStdProduct->m_product_hdr.m_lXsize,
                                       (float)pStdProduct->m_product_hdr.m_dLon,   (float)pStdProduct->m_product_hdr.m_dLat,
                                       (float)pStdProduct->m_product_hdr.m_dXscale, iUnit, imgOption.m_iSmoothNum,
                                       imgOption.m_iDrawAws, imgOption.m_iDrawRing, imgOption.m_iDrawDirection,
                                       pColorTbl, dispInfo, imgInfo)) == NULL)

    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_ARG("pEchoImg fnMakeSiteImageEcho fail"); return FALSE; }

    if((pBackImg = fnMergeSiteImg(pTopImg, pRightImg, pBottomImg, pEchoImg, 
                                  imgOption.m_iImgWidth, imgOption.m_iImgHeight, imgInfo)) == NULL)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_ARG("pBackImg fnMergeSiteImg fail"); return FALSE; }

    if(fnSaveImg(pBackImg, imgOption.m_iImgType, szOutFile) == FALSE)
    {   FN_MAKE_SITE_IMAGE_TO_STD_PRODUCT_BY_ARG("fnSaveImg fail"); return FALSE; }

    fnFreeMatrix2D((void **)ppData, (int)pStdProduct->m_product_hdr.m_lYsize);
    free(pColorTbl);
    gdImageDestroy(pBackImg);
    gdImageDestroy(pTopImg);
    gdImageDestroy(pRightImg);
    gdImageDestroy(pBottomImg);
    gdImageDestroy(pEchoImg);

    return TRUE;
}

int fnMakeCompImageToStdProductByIdx(char *szImgKind, STD_PRODUCT *pStdProduct, char *szProduct, int iProductIdx, char *szFieldName, RDR_IMG_MAKE_OPTION imgOption, char* szQcStr, char *szOutFile)
{
#define FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_IDX(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(ppData     != NULL) { fnFreeMatrix2D((void **)ppData, (int)pStdProduct->m_product_hdr.m_lYsize); } \
    if(pBackImg   != NULL) { gdImageDestroy(pBackImg); } \
    if(pTopImg    != NULL) { gdImageDestroy(pTopImg); } \
    if(pRightImg  != NULL) { gdImageDestroy(pRightImg); } \
    if(pEchoImg   != NULL) { gdImageDestroy(pEchoImg); } \
    if(pColorTbl  != NULL) { free(pColorTbl); }

    gdImagePtr          pBackImg                    = NULL;
    gdImagePtr          pTopImg                     = NULL;
    gdImagePtr          pRightImg                   = NULL;
    gdImagePtr          pEchoImg                    = NULL;
    float               **ppData                    = NULL;
    int                 iUnit                       = 0;
    int                 iDbzToRain                  = FALSE;
    char                szColorFile[STR_LENGTH_MAX] = "";
    RDR_COLOR_TBL       *pColorTbl                  = NULL;
    RDR_DISP_INFO_TBL   dispInfo;
    RDR_IMG_INFO_TBL    imgInfo;

    if(pStdProduct == NULL || szProduct == NULL || iProductIdx < 0 || szFieldName == NULL || szOutFile == NULL)
        return FALSE;

    if(!strcmp(szFieldName, "RN"))
    {
        ppData = fnGetStdProductDataByIdx(pStdProduct, szProduct, iProductIdx, szFieldName);
        if(ppData == NULL)
        {
            ppData = fnGetStdProductDataByIdxDBZ(pStdProduct, szProduct, iProductIdx);
            iDbzToRain = TRUE;
        }
    }
    else
        ppData = fnGetStdProductDataByIdx(pStdProduct, szProduct, iProductIdx, szFieldName);

    if(ppData == NULL)
    {   FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_IDX("fnGetStdProductDataByIdx fail"); return FALSE; }
    
    if(fnGetImgSizeInfo(szImgKind, &imgInfo) == FALSE) 
    {   FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_IDX("fnGetImgSizeInfo fail"); return FALSE; }

    if(!strcmp(szProduct, "VIL") || !strcmp(szFieldName, "RN"))
        iUnit = RDR_EN_DBZ_TO_RAIN;
    else
        iUnit = RDR_EN_UNIT_DEFAULT;

    if(fnGetColorFileInfo(szFieldName, &dispInfo) == FALSE)
    {   FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_IDX("fnGetColorFileInfo fail"); return FALSE; }

    snprintf(szColorFile, sizeof(szColorFile), "%s/resource/color/%s", RDR_DF_APP_ROOT_PATH, dispInfo.m_szColorFIle);
    if((pColorTbl = fnReadColorTable(szColorFile)) == NULL)
        return FALSE;

    if((pTopImg = fnMakeCompImageTop(szImgKind, szProduct, pStdProduct->m_product_hdr.m_tConvertTime, 
                                     szQcStr, pColorTbl, dispInfo, imgInfo)) == NULL)
    {   FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_IDX("pTopImg fnMakeCompImageTop fail"); return FALSE; }

    if((pRightImg = fnMakeCompImageRight(szProduct, pColorTbl, dispInfo, imgInfo)) == NULL)
    {   FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_IDX("pRightImg fnMakeCompImageRight fail"); return FALSE; }

    if((pEchoImg = fnMakeCompImageEcho(szImgKind, szProduct, iDbzToRain, ppData, 
                                       (int)pStdProduct->m_product_hdr.m_lYsize,   (int)pStdProduct->m_product_hdr.m_lXsize,
                                       (float)pStdProduct->m_product_hdr.m_dXscale, iUnit, imgOption.m_iSmoothNum,
                                       imgOption.m_iDrawAws, pColorTbl, dispInfo, imgInfo)) == NULL)
    {   FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_IDX("pEchoImg fnMakeCompImageEcho fail"); return FALSE; }

    if((pBackImg = fnMergeCompImg(pTopImg, pRightImg, pEchoImg, 
                                  imgOption.m_iImgWidth, imgOption.m_iImgHeight, imgInfo)) == NULL)
    {   FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_IDX("pBackImg fnMergeCompImg fail"); return FALSE; }

    if(fnSaveImg(pBackImg, imgOption.m_iImgType, szOutFile) == FALSE)
    {   FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_IDX("fnSaveImg fail"); return FALSE; }

    fnFreeMatrix2D((void **)ppData, (int)pStdProduct->m_product_hdr.m_lYsize);
    free(pColorTbl);
    gdImageDestroy(pBackImg);
    gdImageDestroy(pTopImg);
    gdImageDestroy(pRightImg);
    gdImageDestroy(pEchoImg);

    return TRUE;
}

int fnMakeCompImageToStdProductByArg(char *szImgKind, STD_PRODUCT *pStdProduct, char *szProduct, double dProductArg1, double dProductArg2, char *szFieldName, RDR_IMG_MAKE_OPTION imgOption, char* szQcStr, char *szOutFile)
{
#define FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_ARG(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(ppData     != NULL) { fnFreeMatrix2D((void **)ppData, (int)pStdProduct->m_product_hdr.m_lYsize); } \
    if(pBackImg   != NULL) { gdImageDestroy(pBackImg); } \
    if(pTopImg    != NULL) { gdImageDestroy(pTopImg); } \
    if(pRightImg  != NULL) { gdImageDestroy(pRightImg); } \
    if(pEchoImg   != NULL) { gdImageDestroy(pEchoImg); } \
    if(pColorTbl  != NULL) { free(pColorTbl); }

    gdImagePtr          pBackImg                    = NULL;
    gdImagePtr          pTopImg                     = NULL;
    gdImagePtr          pRightImg                   = NULL;
    gdImagePtr          pEchoImg                    = NULL;
    float               **ppData                    = NULL;
    int                 iUnit                       = 0;
    int                 iDbzToRain                  = FALSE;
    char                szColorFile[STR_LENGTH_MAX] = "";
    RDR_COLOR_TBL       *pColorTbl                  = NULL;
    RDR_DISP_INFO_TBL   dispInfo;
    RDR_IMG_INFO_TBL    imgInfo;

    if(pStdProduct == NULL || szProduct == NULL || szFieldName == NULL || szOutFile == NULL)
        return FALSE;

    if(!strcmp(szFieldName, "RN"))
    {
        ppData = fnGetStdProductDataByArg(pStdProduct, szProduct, dProductArg1, dProductArg2, szFieldName);
        if(ppData == NULL);
        {
            ppData = fnGetStdProductDataByArgDBZ(pStdProduct, szProduct, dProductArg1, dProductArg2);
            iDbzToRain = TRUE;
        }
    }
    else
        ppData = fnGetStdProductDataByArg(pStdProduct, szProduct, dProductArg1, dProductArg2, szFieldName);

    if(ppData == NULL)
    {   FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_ARG("fnGetStdProductDataByArg fail"); return FALSE; }
    
    if(fnGetImgSizeInfo(szImgKind, &imgInfo) == FALSE) 
    {   FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_ARG("fnGetImgSizeInfo fail"); return FALSE; }

    if(!strcmp(szProduct, "VIL") || !strcmp(szFieldName, "RN"))
        iUnit = RDR_EN_DBZ_TO_RAIN;
    else
        iUnit = RDR_EN_UNIT_DEFAULT;

    if(fnGetColorFileInfo(szFieldName, &dispInfo) == FALSE)
    {   FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_ARG("fnGetColorFileInfo fail"); return FALSE; }

    snprintf(szColorFile, sizeof(szColorFile), "%s/resource/color/%s", RDR_DF_APP_ROOT_PATH, dispInfo.m_szColorFIle);
    if((pColorTbl = fnReadColorTable(szColorFile)) == NULL)
        return FALSE;

    if((pTopImg = fnMakeCompImageTop(szImgKind, szProduct, pStdProduct->m_product_hdr.m_tConvertTime, 
                                     szQcStr, pColorTbl, dispInfo, imgInfo)) == NULL)
    {   FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_ARG("pTopImg fnMakeCompImageTop fail"); return FALSE; }

    if((pRightImg = fnMakeCompImageRight(szProduct, pColorTbl, dispInfo, imgInfo)) == NULL)
    {   FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_ARG("pRightImg fnMakeCompImageRight fail"); return FALSE; }

    if((pEchoImg = fnMakeCompImageEcho(szImgKind, szProduct, iDbzToRain, ppData, 
                                       (int)pStdProduct->m_product_hdr.m_lYsize,   (int)pStdProduct->m_product_hdr.m_lXsize,
                                       (float)pStdProduct->m_product_hdr.m_dXscale, iUnit, imgOption.m_iSmoothNum,
                                       imgOption.m_iDrawAws, pColorTbl, dispInfo, imgInfo)) == NULL)
    {   FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_ARG("pEchoImg fnMakeCompImageEcho fail"); return FALSE; }

    if((pBackImg = fnMergeCompImg(pTopImg, pRightImg, pEchoImg, 
                                  imgOption.m_iImgWidth, imgOption.m_iImgHeight, imgInfo)) == NULL)
    {   FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_ARG("pBackImg fnMergeCompImg fail"); return FALSE; }

    if(fnSaveImg(pBackImg, imgOption.m_iImgType, szOutFile) == FALSE)
    {   FN_MAKE_COMP_IMAGE_TO_STD_PRODUCT_BY_ARG("fnSaveImg fail"); return FALSE; }

    fnFreeMatrix2D((void **)ppData, (int)pStdProduct->m_product_hdr.m_lYsize);
    free(pColorTbl);
    gdImageDestroy(pBackImg);
    gdImageDestroy(pTopImg);
    gdImageDestroy(pRightImg);
    gdImageDestroy(pEchoImg);

    return TRUE;
}

/* ================================================================================ */





