/* ================================================================================ */
//
// Radar Image Map Function
//
// 2016.08.25 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"
#include "rdr_image.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function



/* ================================================================================ */
// Function

int fnDrawSiteImgMap(gdImagePtr pImg, int iWidth, int iHeight, float fImgGridKm, float fSiteLon, float fSiteLat, float fSiteXo, float fSiteYo, int iMapColor)
{
    char        szMapFile[STR_LENGTH_MAX]   = "";
    FILE*       pFp                         = NULL;
    int         iLoopIdx                    = 0;
    int         iLineNum                    = 0;
    int         iLineType                   = 0;
    int         iLineIdx                    = 0;
    float       fLon                        = 0, fLat = 0;
    float       fX1                         = 0, fY1  = 0;
    float       fX2                         = 0, fY2  = 0;

    AZED_PARAMETER  map_param;
    AZED_VAR        map_var;

    if(pImg == NULL)
        return FALSE;

    map_var.m_iFirst = 0;
    map_param = fnGetAzedMapInfo(RDR_DF_KMA_MAP_RE, fImgGridKm, fSiteLon, fSiteLat, fSiteLon, fSiteLat, fSiteXo, fSiteYo);
    
    snprintf(szMapFile, sizeof(szMapFile), "%s/resource/map/%s", 
             RDR_DF_APP_ROOT_PATH, RDR_DF_SITE_KR_MAP_FILE);

    if((pFp = fopen(szMapFile, "r")) == NULL)
        return FALSE;
    
    while(fread(&iLineNum, sizeof(iLineNum), 1, pFp) == 1 && iLoopIdx++ < LOOP_CNT_MAX)
    {
        if(fread(&iLineType, sizeof(iLineType), 1, pFp) != 1)   break;
        if(fread(&fLat, sizeof(fLat), 1, pFp) != 1)             break;
        if(fread(&fLon, sizeof(fLon), 1, pFp) != 1)             break;

        fnAzedProj(&fLon, &fLat, &fX1, &fY1, 0, &map_param, &map_var);
        fX2 = fX1; fY2 = fY1;

        gdImageSetThickness(pImg, 1);
        if(fImgGridKm > 0.5)
            gdImageSetThickness(pImg, 1);
        else
        {
            if(iLineType == 3)
                gdImageSetThickness(pImg, 1);
            else
                gdImageSetThickness(pImg, 2);
        }

        for(iLineIdx = 1; iLineIdx < iLineNum; iLineIdx++)
        {
            if(fread(&fLat, sizeof(fLat), 1, pFp) != 1) break;
            if(fread(&fLon, sizeof(fLon), 1, pFp) != 1) break;

            if(fImgGridKm > 0.5 && iLineType == 3) continue;

            fnAzedProj(&fLon, &fLat, &fX1, &fY1, 0, &map_param, &map_var);
            gdImageLine(pImg, (int)(fX1+0.5), iHeight-(int)(fY1+0.5)-1, 
                              (int)(fX2+0.5), iHeight-(int)(fY2+0.5)-1, iMapColor);
            fX2 = fX1; fY2 = fY1;
        }
    }
    fclose(pFp);

    return TRUE;
}

int fnDrawSiteImgAws(gdImagePtr pImg, int iWidth, int iHeight, float fImgGridKm, float fSiteLon, float fSiteLat, float fSiteXo, float fSiteYo, int iAwsColor, int iFontColor)
{
    char        szAwsFile[STR_LENGTH_MAX]   = "";
    FILE*       pFp                         = NULL;
    int         iAwsNum                     = 0;
    int         iAwsIdx                     = 0;
    int         iAwsX                       = 0;
    int         iAwsY                       = 0;
    char        szAwsName[STR_LENGTH_MAX]   = "";
    float       fAwsLon                     = 0.0;
    float       fAwsLat                     = 0.0;
    float       fAwsX                       = 0.0;
    float       fAwsY                       = 0.0;
    char        szFontFile[STR_LENGTH_MAX]  = "";
    double      dFontSize                   = 0.0;

    AZED_PARAMETER  map_param;
    AZED_VAR        map_var;

    if(pImg == NULL)
        return FALSE;

    map_var.m_iFirst = 0;
    map_param = fnGetAzedMapInfo(RDR_DF_KMA_MAP_RE, fImgGridKm, fSiteLon, fSiteLat, fSiteLon, fSiteLat, fSiteXo, fSiteYo);
    
    snprintf(szFontFile, sizeof(szFontFile), "%s/resource/font/%s", RDR_DF_APP_ROOT_PATH, RDR_DF_AWS_FONT_FILE);
    dFontSize = RDR_DF_AWS_FONT_SIZE;

    if(fImgGridKm > 0.5)
        snprintf(szAwsFile, sizeof(szAwsFile), "%s/resource/aws/%s", RDR_DF_APP_ROOT_PATH, RDR_DF_AWS_1_FILE);
    else
        snprintf(szAwsFile, sizeof(szAwsFile), "%s/resource/aws/%s", RDR_DF_APP_ROOT_PATH, RDR_DF_AWS_2_FILE);

    if((pFp = fopen(szAwsFile, "rt")) == NULL)
        return FALSE;
    
    if(fscanf(pFp, "%d", &iAwsNum) != 1) 
    {   fclose(pFp); return FALSE; }

    for(iAwsIdx = 0; iAwsIdx < iAwsNum; iAwsIdx++)
    {
        memset(szAwsName, 0x00, sizeof(szAwsName));
        if(fscanf(pFp, "%s %f %f", szAwsName, &fAwsLat, &fAwsLon) != 3)
            break;

        fnAzedProj(&fAwsLon, &fAwsLat, &fAwsX, &fAwsY, 0, &map_param, &map_var);
        iAwsX = (int)fAwsX+1;
        iAwsY = iHeight- (int)fAwsY-1;
        if(iAwsX < 0 || iAwsX > iWidth || iAwsY < 0 || iAwsY > iHeight) continue;

        gdImageFilledEllipse(pImg, iAwsX, iAwsY, 4, 4, iAwsColor);

        iAwsX -= RDR_DF_AWS_NAME_MV_POSITION_X;
        iAwsY -= RDR_DF_AWS_NAME_MV_POSITION_Y;

        gdImageStringTTF(pImg, NULL, iFontColor, szFontFile, dFontSize, 0.0, iAwsX, iAwsY, szAwsName);
    }

    fclose(pFp);

    return TRUE;
}

int fnDrawCompImgMap(char* szImgKind, gdImagePtr pImg, int iWidth, int iHeight, float fImgGridKm, float fOrgX, float fOrgY, int iMoveX, int iMoveY, int iMapColor)
{
    char    szMapFile[STR_LENGTH_MAX]   = "";
    FILE*   pFp                         = NULL;
    float   fNum                        = 0.0;       //VARIABLE
    float   fCode                       = 0.0;       //VARIABLE
    float   rgfTmp[2]                   = { 0.0, };  //VARIABLE
    float   rgfBuf[2]                   = { 0.0, };  //VARIABLE
    int     iTemp_I                     = 0;         //VARIABLE
    int     iX_start                    = 0;         //VARIABLE
    int     iX_finish                   = 0;         //VARIABLE
    int     iY_start                    = 0;         //VARIABLE
    int     iY_finish                   = 0;         //VARIABLE
    float   fGridScale                  = 0.0;

    if(szImgKind == NULL || pImg == NULL)
        return -1;

    fGridScale = RDR_DF_BIN_MAP_GRID/fImgGridKm;

    if(!strcmp(szImgKind, "COMP_240"))
        snprintf(szMapFile, sizeof(szMapFile), "%s/resource/map/%s",
                 RDR_DF_APP_ROOT_PATH, RDR_DF_COMP_KR_MAP_FILE);
    else
        snprintf(szMapFile, sizeof(szMapFile), "%s/resource/map/%s",
                 RDR_DF_APP_ROOT_PATH, RDR_DF_COMP_F2R_MAP_FILE);

    if((pFp = fopen(szMapFile, "rb")) != NULL )
    {
        while(fread(rgfTmp, sizeof(float), 2, pFp) > 0)
        {
            fNum  = rgfTmp[0];
            fCode = rgfTmp[1];
            fread(rgfBuf, sizeof(float), 2, pFp);

            iX_start = (int)((fGridScale * (rgfBuf[0] - fOrgX)) + iMoveX);
            iY_start = (int)((iHeight - (fGridScale * (rgfBuf[1] + fOrgY))) - iMoveY);

            for(iTemp_I = 1; iTemp_I < fNum; iTemp_I++)
            {
                fread(rgfBuf, sizeof(float), 2, pFp);

                iX_finish = (int)((fGridScale * (rgfBuf[0] - fOrgX)) + iMoveX);
                iY_finish = (int)((iHeight - (fGridScale * (rgfBuf[1] + fOrgY))) - iMoveY);

                //sea
                if(fCode == 0 || fCode == 1 || fCode == 6 || fCode == 7 || fCode == 8)
                {
                    gdImageLine(pImg, iX_start, iY_start, iX_finish, iY_finish, iMapColor);
                }

                //district
                if(fCode == 2 || fCode == 5)
                {
                    gdImageLine(pImg, iX_start, iY_start, iX_finish, iY_finish, iMapColor);
                }

                iX_start = iX_finish;
                iY_start = iY_finish;
            }
        }
        fclose(pFp);
    }

    return TRUE;
}

/* ================================================================================ */



