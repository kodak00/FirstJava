/* ================================================================================ */
//
// Radar Image Common Function
//
// 2016.08.30 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"
#include "rdr_product.h"
#include "rdr_image.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function

static void fnInsertionSort(float *rgfBuff, int iBufSize)
{
    int    iIdx_1 = 0;    //VARIABLE
    int    iIdx_2 = 0;    //VARIABLE
    float  fTmp   = 0.0;  //VARIABLE

    if(rgfBuff == NULL)
        return;

    for(iIdx_1 = 1; iIdx_1 < iBufSize; iIdx_1++)
    {
        fTmp = rgfBuff[iIdx_1];
        for(iIdx_2 = iIdx_1-1; iIdx_2 >= 0 && rgfBuff[iIdx_2] > fTmp; iIdx_2--)
        {
            rgfBuff[iIdx_2+1] = rgfBuff[iIdx_2];
        }
        rgfBuff[iIdx_2+1] = fTmp;
    }
}

static void fnMedianFilter(float** pImgData, int iImgXdim, int iImgYdim)
{
    int   iXIdx                    = 0;         //VARIABLE
    int   iYIdx                    = 0;         //VARIABLE
    float rgfBuff[9]               = { 0.0, };  //VARIABLE

    for(iYIdx = 1; iYIdx < iImgYdim-1; iYIdx++)
    {
        for(iXIdx = 1; iXIdx < iImgXdim-1; iXIdx++)
        {
            rgfBuff[0] = pImgData[iYIdx-1][iXIdx-1];
            rgfBuff[1] = pImgData[iYIdx-1][iXIdx];
            rgfBuff[2] = pImgData[iYIdx-1][iXIdx+1];
            rgfBuff[3] = pImgData[iYIdx][iXIdx-1];
            rgfBuff[4] = pImgData[iYIdx][iXIdx];
            rgfBuff[5] = pImgData[iYIdx][iXIdx+1];
            rgfBuff[6] = pImgData[iYIdx+1][iXIdx-1];
            rgfBuff[7] = pImgData[iYIdx+1][iXIdx];
            rgfBuff[8] = pImgData[iYIdx+1][iXIdx+1];
            fnInsertionSort(rgfBuff, 9);

            pImgData[iYIdx][iXIdx] = rgfBuff[4];
        }
    }
}


/* ================================================================================ */
// Function

float** fnMakeSiteImageData(float **ppData, int iYdim, int iXdim, float fDataGridKm, int iWidth, int iHeight, float fImgGridKm)
{
    int             iYidx                       = 0;
    int             iXidx                       = 0;
    int             iDiff_xy                    = 0;
    float           **ppImgData                 = NULL;
    float           fGridScale                  = 0.0;

    if(ppData == NULL || iWidth != iHeight)
        return NULL;

    if((ppImgData = (float **)calloc(iHeight, sizeof(float *))) == NULL)
        return NULL;

    for(iYidx = 0; iYidx < iHeight; iYidx++)
    {
        if((ppImgData[iYidx] = (float *)calloc(iWidth, sizeof(float))) == NULL)
        {   
            fnFreeMatrix2D((void **)ppImgData, iYidx);
            return NULL; 
        }
        for(iXidx = 0; iXidx < iWidth; iXidx++)
            ppImgData[iYidx][iXidx] = RDR_DF_OUT_BOUND_F;
    }

    fGridScale = fDataGridKm/fImgGridKm;

    iDiff_xy = (iWidth - (iXdim*fGridScale))/2;

    for(iYidx = 0; iYidx < iHeight; iYidx++)
    {
        for(iXidx = 0; iXidx < iWidth; iXidx++)
        {
            ppImgData[iYidx][iXidx] = fnGetRadarValue(ppData, iYdim, iXdim, 
                                                      iDiff_xy, iDiff_xy, 
                                                      iYidx, iXidx, 
                                                      fGridScale,
                                                      fGridScale);
        }
    }

    return ppImgData;
}

float** fnMakeCompImageData(char *szImgKind, float **ppData, int iYdim, int iXdim, float fDataGridKm, int iWidth, int iHeight, float fImgGridKm)
{
    int             iYidx                       = 0;
    int             iXidx                       = 0;
    float           **ppImgData                 = NULL;
    float           fGridScale                  = 0.0;

    if(ppData == NULL)
        return NULL;

    if((ppImgData = (float **)calloc(iHeight, sizeof(float *))) == NULL)
        return NULL;

    for(iYidx = 0; iYidx < iHeight; iYidx++)
    {
        if((ppImgData[iYidx] = (float *)calloc(iWidth, sizeof(float))) == NULL)
        {   
            fnFreeMatrix2D((void **)ppImgData, iYidx);
            return NULL; 
        }
        for(iXidx = 0; iXidx < iWidth; iXidx++)
            ppImgData[iYidx][iXidx] = RDR_DF_OUT_BOUND_F;
    }

    fGridScale = fDataGridKm/fImgGridKm;

    for(iYidx = 0; iYidx < iHeight; iYidx++)
    {
        for(iXidx = 0; iXidx < iWidth; iXidx++)
        {
            ppImgData[iYidx][iXidx] = fnGetRadarValue(ppData, iYdim, iXdim, 
                                                      0, 0, iYidx, iXidx, 
                                                      fGridScale,
                                                      fGridScale);
        }
    }
 
    return ppImgData;
}

float fnGetRadarValue(float **ppData, int iYdim, int iXdim, int iDiff_x, int iDiff_y, int iYPoint, int iXPoint, float fXGridScale, float fYGridScale)
{
    float       fValue  = 0.0;
    double      dCalcY  = 0.0;
    double      dCalcX  = 0.0;
    int         iCalcY  = 0.0;
    int         iCalcX  = 0.0;

    dCalcX = (double)((iXPoint - iDiff_x) / fXGridScale);
    dCalcY = (double)((iYPoint - iDiff_y) / fYGridScale);

    iCalcX = (int)dCalcX;
    iCalcY = (int)dCalcY;

    if((iCalcX >= 0 && iCalcX < iXdim) && (iCalcY >= 0 && iCalcY < iYdim))
    {
        fValue = ppData[iCalcY][iCalcX];
    }
    else
    {
        fValue = RDR_DF_OUT_BOUND_F;
    }

    return fValue;
}

int fnDrawRadarImgBound(gdImagePtr pImg, float **ppImgData, int iWidth, int iHeight, float fOutBound, int iInBoundColor, int iOutBoundColor)
{
    int     iYIdx           = 0;
    int     iXIdx           = 0;

    if(pImg == NULL || ppImgData == NULL)
        return FALSE;

//    gdImageFilledRectangle(pImg, 0, 0, iWidth, iHeight, iOutBoundColor);

    for(iYIdx = 0; iYIdx < iHeight; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iWidth; iXIdx++)
        {
            if(ppImgData[iYIdx][iXIdx] != fOutBound)
                gdImageSetPixel(pImg, iXIdx, iYIdx, iInBoundColor);
            else
                gdImageSetPixel(pImg, iXIdx, iYIdx, iOutBoundColor);
        }
    }

    return TRUE;
}

int fnDrawRadarEcho(gdImagePtr pImg, float **ppImgData, int iWidth, int iHeight, RDR_COLOR_TBL *pColorTbl, int iColorKind, float fMinValue, int iMinDiffType, int iEchoDiffType, int echoColorBar[RDR_DF_COLOR_MAX])
{
    int     iYIdx           = 0;
    int     iXIdx           = 0;
    int     iColorLevel     = 0;

    if(pImg == NULL || ppImgData == NULL || pColorTbl == NULL)
        return FALSE;

    for(iYIdx = 0; iYIdx < iHeight; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iWidth; iXIdx++)
        {
            iColorLevel = fnGetColorLevel(ppImgData[iYIdx][iXIdx], pColorTbl, 
                                          iColorKind, fMinValue, iMinDiffType, iEchoDiffType);
            if(iColorLevel >= 0 && iColorLevel < pColorTbl->m_iEchoColorCnt)
                gdImageSetPixel(pImg, iXIdx, iYIdx, echoColorBar[iColorLevel]);
        }
    }

    return TRUE;
}

int fnDbzToRainrate(float **ppData, int iYdim, int iXdim, int iUnit)
{
    int     iYIdx           = 0;
    int     iXIdx           = 0;
    float   fZr_a           = RDR_DF_DFLT_ZR_A;
    float   fZr_b           = RDR_DF_DFLT_ZR_B;

    if(ppData == NULL)
        return FALSE;

    if(iUnit == RDR_EN_DBZ_TO_RAIN)
    {
        fZr_a = RDR_DF_DFLT_ZR_A;
        fZr_b = RDR_DF_DFLT_ZR_B;
    }

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            if(fabs(ppData[iYIdx][iXIdx] - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F || 
               fabs(ppData[iYIdx][iXIdx] - RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
            {
                continue;
            }
            else if(ppData[iYIdx][iXIdx] <= 0.0f)
            {
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
            }
            else
            {
                ppData[iYIdx][iXIdx] 
                = (float)fnDbzToRainF((double)ppData[iYIdx][iXIdx], fZr_a, fZr_b);
            }
        }
    }

    return TRUE;
}

int fnKmaCmpSmooth(float **ppData, int iYdim, int iXdim, int iSmoothNum)
{
    int     iYIdx       = 0;
    int     iXIdx       = 0;
    int     iSmIdx      = 0;
    float   fE[4]       = { 0.0, };
    float   fE1         = 0.0;
    float   fE2         = 0.0;

    if(ppData == NULL)
        return FALSE;

    for(iSmIdx = 0; iSmIdx < iSmoothNum; iSmIdx++)
    {
        for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
        {
            fE1   = ppData[iYIdx][0];
            fE[0] = ppData[iYIdx][0];
            fE[1] = ppData[iYIdx][1];
            for(iXIdx = 1; iXIdx < iXdim-1; iXIdx++)
            {
                fE[2] = ppData[iYIdx][iXIdx+1];
                if (fE[0] > -50 && fE[1] > -50 && fE[2] > -50)
                    fE2 = (fE[0] + 2.0*fE[1] + fE[2]) * 0.25;
                else if (fE[0] > -50 && fE[1] <= -50 && fE[2] > -50)
                    fE2 = (fE[0] + fE[2]) * 0.5;
                else
                    fE2 = fE[1];

                ppData[iYIdx][iXIdx-1] = fE1;
                fE1   = fE2;
                fE[0] = fE[1];
                fE[1] = fE[2];
            }
            ppData[iYIdx][iXIdx-1] = fE1;
        }
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            fE1 = ppData[0][iXIdx];
            fE[0] = ppData[0][iXIdx];
            fE[1] = ppData[1][iXIdx];
            for (iYIdx = 1; iYIdx < iYdim-1; iYIdx++)
            {
                fE[2] = ppData[iYIdx+1][iXIdx];
                if (fE[0] > -50 && fE[1] > -50 && fE[2] > -50)
                    fE2 = (fE[0] + 2.0*fE[1] + fE[2]) * 0.25;
                else if (fE[0] > -50 && fE[1] <= -50 && fE[2] > -50)
                    fE2 = (fE[0] + fE[2]) * 0.5;
                else
                    fE2 = fE[1];

                ppData[iYIdx-1][iXIdx] = fE1;
                fE1 = fE2;
                fE[0] = fE[1];
                fE[1] = fE[2];
            }
            ppData[iYIdx-1][iXIdx] = fE1;
        }
    }

    return TRUE;
}

int fnCompSmooth(float **ppData, int iYdim, int iXdim)
{
    if(ppData == NULL)
        return FALSE;

    fnMedianFilter(ppData, iXdim, iYdim);

    return TRUE;
}

int fnDrawSiteImgRing(gdImagePtr pImg, int iWidth, int iHeight, float fImgGridKm, int iLineColor)
{
    int     iRingSize   = 0;
    int     iLoopCnt    = 0;

    if(pImg == NULL)
        return FALSE;

    iRingSize = (RDR_DF_RING_RADIUS * (2/fImgGridKm));

    while(iLoopCnt++ < LOOP_CNT_MAX)
    {
        if(iWidth < iHeight)
        {
            if(iRingSize > iWidth) break;
        }
        else
        {
            if(iRingSize > iHeight) break;
        }

        gdImageArc(pImg, iWidth/2, iHeight/2, iRingSize, iRingSize, 0, 360, iLineColor);

        iRingSize += (RDR_DF_RING_RADIUS * (2/fImgGridKm));
    }

    return TRUE;
}

int fnDrawSiteImgDirection(gdImagePtr pImg, int iWidth, int iHeight, int iLineColor)
{
    if(pImg == NULL)
        return FALSE;

    gdImageLine(pImg, 0, 0, iWidth-1, iHeight-1, iLineColor);
    gdImageLine(pImg, iWidth-1, 0, 0, iHeight-1, iLineColor);
    gdImageLine(pImg, iWidth/2,  0, iWidth/2, iHeight-1, iLineColor);
    gdImageLine(pImg, 0, iHeight/2, iWidth-1, iHeight/2, iLineColor);

    return TRUE;
}

/* ================================================================================ */



