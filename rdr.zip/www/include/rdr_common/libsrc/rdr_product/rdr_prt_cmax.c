/* ================================================================================ */
//
// Radar Create CMAX ( Use Standard Format )
//
// 2016.08.12 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"
#include "rdr_product.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function



/* ================================================================================ */
// Function

float* fnCreateCmax(STD_RADAR *pStd, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, char* szFieldName, STD_AZIMUTH_TBL **ppTable)
{
#define FN_CREATE_CMAX_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(ppPpi != NULL) { fnFreeMatrix2D((void **)ppPpi, pStd->m_iMaxSweep); } \
    if(pCmax != NULL) { free(pCmax); };

    STD_RAY *pRay       = NULL;     // VARIABLE
    float   **ppPpi     = NULL;
    float   *pCmax      = NULL;
    float   fTempData   = 0.0;
    int     iCmaxIdx    = 0;
    int     iSweepIdx   = 0;

    if(pStd == NULL || ppTable == NULL || szFieldName == NULL)
        return NULL;

    pRay = pStd->m_ppSweep[0]->m_ppRay[0];
    if(fnGetFieldIdxRay(pRay, szFieldName) == -1)
    {   FN_CREATE_CMAX_ERROR("no moment") return NULL; }

    if((ppPpi = (float **)calloc(pStd->m_iMaxSweep, sizeof(float *))) == NULL)
    {   FN_CREATE_CMAX_ERROR("alloc fail") return NULL; }

    if((pCmax = (float *)calloc(iXdim*iYdim, sizeof(float))) == NULL)
    {   FN_CREATE_CMAX_ERROR("alloc fail") return NULL; }

    for(iCmaxIdx = 0; iCmaxIdx < iXdim*iYdim; iCmaxIdx++)
        pCmax[iCmaxIdx] = RDR_DF_BAD_VALUE_F;

    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        ppPpi[iSweepIdx] = fnCreatePPI(pStd, iSweepIdx, iXdim, iYdim, 
                                       fMaxRangeKm, fGridKm, szFieldName, ppTable[iSweepIdx]);
    }

    for(iCmaxIdx = 0; iCmaxIdx < iXdim*iYdim; iCmaxIdx++)
    {
        fTempData = RDR_DF_BAD_VALUE_F;
        for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
        {
            if(ppPpi[iSweepIdx] != NULL)
            {
                if(fTempData < ppPpi[iSweepIdx][iCmaxIdx])
                    fTempData = ppPpi[iSweepIdx][iCmaxIdx];
            }
        }

        if(fTempData != RDR_DF_BAD_VALUE_F)
            pCmax[iCmaxIdx] = fTempData;
    }

    fnFreeMatrix2D((void **)ppPpi, pStd->m_iMaxSweep);

    return pCmax;
}

float* fnCreateCmaxQIToDbz(STD_RADAR *pStd, STD_RADAR *pQiStd, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, STD_AZIMUTH_TBL **ppTable, STD_AZIMUTH_TBL **ppQiTable)
{
    float   *pCmax      = NULL;

    pCmax = fnCreateCmaxQI(pStd, pQiStd, iXdim, iYdim, fMaxRangeKm, fGridKm, "CZ", ppTable, ppQiTable);
    if(pCmax == NULL)
        pCmax = fnCreateCmaxQI(pStd, pQiStd, iXdim, iYdim, fMaxRangeKm, fGridKm, "DZ", ppTable, ppQiTable);

    return pCmax;
}

float* fnCreateCmaxQI(STD_RADAR *pStd, STD_RADAR *pQiStd, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, char* szFieldName, STD_AZIMUTH_TBL **ppTable, STD_AZIMUTH_TBL **ppQiTable)
{
#define FN_CREATE_CMAX_QI_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(ppPpi   != NULL) { fnFreeMatrix2D((void **)ppPpi,   pStd->m_iMaxSweep); } \
    if(ppQiPpi != NULL) { fnFreeMatrix2D((void **)ppQiPpi, pQiStd->m_iMaxSweep); } \
    if(pCmax   != NULL) { free(pCmax); };

    STD_RAY *pRay       = NULL;     // VARIABLE
    float   **ppPpi     = NULL;
    float   **ppQiPpi   = NULL;
    float   *pCmax      = NULL;
    float   fTempData   = 0.0;
    int     iSweepNo    = 0;
    int     iCmaxIdx    = 0;
    int     iSweepIdx   = 0;

    if(pStd == NULL || pQiStd == NULL || ppTable == NULL || ppQiTable == NULL || szFieldName == NULL)
        return NULL;

    if(pStd->m_iMaxSweep != pQiStd->m_iMaxSweep)
        return NULL;

    pRay = pStd->m_ppSweep[0]->m_ppRay[0];
    if(fnGetFieldIdxRay(pRay, szFieldName) == -1)
    {   FN_CREATE_CMAX_QI_ERROR("no moment") return NULL; }

    if((ppPpi = (float **)calloc(pStd->m_iMaxSweep, sizeof(float *))) == NULL)
    {   FN_CREATE_CMAX_QI_ERROR("alloc fail") return NULL; }

    if((ppQiPpi = (float **)calloc(pQiStd->m_iMaxSweep, sizeof(float *))) == NULL)
    {   FN_CREATE_CMAX_QI_ERROR("alloc fail") return NULL; }

    if((pCmax = (float *)calloc(iXdim*iYdim, sizeof(float))) == NULL)
    {   FN_CREATE_CMAX_QI_ERROR("alloc fail") return NULL; }

    for(iCmaxIdx = 0; iCmaxIdx < iXdim*iYdim; iCmaxIdx++)
        pCmax[iCmaxIdx] = RDR_DF_BAD_VALUE_F;

    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        ppPpi[iSweepIdx] = fnCreatePPI(pStd, iSweepIdx, iXdim, iYdim, 
                                       fMaxRangeKm, fGridKm, szFieldName, ppTable[iSweepIdx]);
    }

    for(iSweepIdx = 0; iSweepIdx < pQiStd->m_iMaxSweep; iSweepIdx++)
    {
        ppQiPpi[iSweepIdx] = fnCreatePPI(pQiStd, iSweepIdx, iXdim, iYdim, 
                                         fMaxRangeKm, fGridKm, "QI", ppQiTable[iSweepIdx]);
    }

    for(iCmaxIdx = 0; iCmaxIdx < iXdim*iYdim; iCmaxIdx++)
    {
        fTempData = RDR_DF_BAD_VALUE_F;
        iSweepNo = -1;
        for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
        {
            if(ppPpi[iSweepIdx] != NULL)
            {
                if(fTempData < ppPpi[iSweepIdx][iCmaxIdx])
                {
                    fTempData = ppPpi[iSweepIdx][iCmaxIdx];
                    iSweepNo = iSweepIdx;
                }
            }
        }

        if(iSweepNo >= 0)
            pCmax[iCmaxIdx] = ppQiPpi[iSweepNo][iCmaxIdx];
    }

    fnFreeMatrix2D((void **)ppPpi,   pStd->m_iMaxSweep);
    fnFreeMatrix2D((void **)ppQiPpi, pQiStd->m_iMaxSweep);

    return pCmax;
}

/* ================================================================================ */










