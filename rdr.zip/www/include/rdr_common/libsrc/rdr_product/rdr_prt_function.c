/* ================================================================================ */
//
// Radar STD Function
//
// 2016.08.09 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"
#include "rdr_product.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable

static float fKdpWaveLen = 0.5;

/* ================================================================================ */
// Static Function

static float fnKD_F(unsigned short sVal)
{
    if(sVal >= RDR_DF_F_OFFSET) 
    {
        sVal -= RDR_DF_F_OFFSET;
        if(fabs(fKdpWaveLen - 0.0) < RDR_DF_ERR_RANGE_F)
            return RDR_DF_BADVAL;

        if(sVal < 128)
            return (float)(-0.25 * pow((double)600.0,(double)((127-sVal)/126.0)))/fKdpWaveLen;
        else if(sVal > 128)
            return (float)(0.25 * pow((double)600.0,(double)((sVal-129)/126.0)))/fKdpWaveLen;
        else
            return 0.0;
    }

    if(sVal == 0) return RDR_DF_BADVAL;
    if(sVal == 1) return RDR_DF_RFVAL;
    if(sVal == 2) return RDR_DF_APFLAG;
    if(sVal == 3) return RDR_DF_NOECHO;

    return RDR_DF_BADVAL;
}

static unsigned short fnKD_INVF(float fVal)
{
    if(fVal == RDR_DF_BADVAL) return (unsigned short)0;
    if(fVal == RDR_DF_RFVAL)  return (unsigned short)1;
    if(fVal == RDR_DF_APFLAG) return (unsigned short)2;
    if(fVal == RDR_DF_NOECHO) return (unsigned short)3;

    if(fKdpWaveLen == 0.0) return (unsigned short)0;

    if(fVal < 0) 
    {
        fVal = 127 - 126 * (log((double)-fVal) - log((double)(0.25/fKdpWaveLen))) 
               / log((double)600.0) + 0.5;
    }
    else if (fVal > 0)
    {
        fVal = 129 + 126 * (log((double)fVal) - log((double)0.25/fKdpWaveLen)) 
               / log((double)600.0) + 0.5;
    }
    else 
        fVal = 128;

    fVal += RDR_DF_F_OFFSET;

    return (unsigned short)fVal;
}

static float fnConvertRadarValue(short sStdData, char* szFieldName, int iScaleFactor)
{
    if(szFieldName == NULL)
        return RDR_DF_BADVAL;

    if(!strcmp(szFieldName, "KD"))
        return fnKD_F(fnKD_INVF((float)sStdData/(float)iScaleFactor));
    else
        return (float)sStdData/(float)iScaleFactor;
}

/* ================================================================================ */
// Function

float fnCalcAzimuthToXY(int iYIdx, int iXIdx)
{
    float       fAzim   = 0.0f;

    if(iXIdx != 0)
        fAzim = (float)atan((double)iYIdx/(double)iXIdx)*180.0/3.14159;
    else
    {
        if(iYIdx < 0)   fAzim = -90.0;
        else            fAzim =  90.0;
    }
    if(iYIdx < 0 && iXIdx < 0)
        fAzim -= 180;
    else if (iYIdx >= 0 && iXIdx < 0)
        fAzim += 180;

    fAzim = -fAzim;
    fAzim -= 90.0;
    if(fAzim < 0) fAzim += 360.0;

    return fAzim;
}

float fnGetAzimuth(float fPointX, float fPointY)
{
    float   fAzim   = 0.0f;

    if(fPointX < 0.0)
    {
        fAzim = (atan(fPointY/fPointX)*180.0/RDR_DF_PI_DFS)+270.0;
    }
    else if(fPointX > 0.0)
    {
        fAzim = (atan(fPointY/fPointX)*180.0/RDR_DF_PI_DFS)+90;
    }
    else if((fabs(fPointX - 0.0) < RDR_DF_ERR_RANGE_F) && (fPointY <= 0.0))
    {
        fAzim = 0.0;
    }
    else
    {
        fAzim = 180.0;
    }

    return fAzim;
}

int fnSearchRayToAzim(STD_SWEEP *pSweep, float fRes, float fAzim, STD_AZIMUTH_TBL *pTable)
{
    int         iHashIdx    = 0;
    int         iLoopCnt    = 0;
    int         iRayIdx     = 0;

    if(pSweep == NULL || pTable == NULL)
        return -1;

    iHashIdx = fnGetRayHashIndex(fRes, fAzim);

    iHashIdx = iHashIdx % pSweep->m_iMaxRay;

    iLoopCnt = 0;
    while(pTable[iHashIdx].m_iCon == -1 && iLoopCnt < pSweep->m_iMaxRay)
    {
        iHashIdx = (iHashIdx + 1) % pSweep->m_iMaxRay;
        iLoopCnt++;
    }

    if(iLoopCnt == pSweep->m_iMaxRay)
        return -1;

    iRayIdx = fnTheClosestRay(pSweep, pTable, iHashIdx, fAzim);

    return iRayIdx;
}

float fnGetBinValueToRay(STD_RAY *pRay, int iFieldIdx, float fRangeKm, int iNoDataValue)
{
    STD_FIELD   *pField      = NULL;     // VARIABLE
    float       fRangeM      = 0.0f;
    float       fStartRangeM = 0.0f;
    int         iBinIdx      = 0;

    if(pRay == NULL)
        return RDR_DF_BADVAL;

    if(iFieldIdx >= pRay->m_iMaxField)
        return RDR_DF_BADVAL;

    fRangeM      = fRangeKm * 1000.0f;
    fStartRangeM = (pRay->m_hdr.m_iStartRangeKm + pRay->m_hdr.m_iStartRangeMeter/1000.0f)*1000.0f;
    iBinIdx = (int)((fRangeM - fStartRangeM) / pRay->m_hdr.m_iBinSpacing);
    if(pRay->m_ppField != NULL)
    {
        pField = pRay->m_ppField[iFieldIdx];
        if(pField != NULL && pField->m_pData != NULL && iBinIdx < pField->m_iMaxBin)
        {
            if(pField->m_pData[iBinIdx] == (short)RDR_DF_UF_NO_DATA)
                return RDR_DF_BADVAL;
            else if((int)(pField->m_pData[iBinIdx]) == iNoDataValue)
                return RDR_DF_BADVAL;
            else
                return fnConvertRadarValue(pField->m_pData[iBinIdx], 
                                           pField->m_hdr.m_szFieldName,  
                                           pField->m_hdr.m_iScaleFactor);
        }
        else
            return RDR_DF_BADVAL;
    }
    return RDR_DF_BADVAL;
}

int fnProcOutBound(float *pData, int iYdim, int iXdim, float fGridKm, float fMaxRange)
{
    int     iYIdx   = 0;
    int     iXIdx   = 0;
    float   fRange  = 0.0;

    if(pData == NULL)
        return FALSE;

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            fRange = sqrt(pow(iYIdx-(iYdim/2), 2) + pow(iXIdx-(iXdim/2), 2)) * fGridKm;

            if(fRange > fMaxRange)
                pData[iYIdx*iXdim+iXIdx] = RDR_DF_OUT_BOUND_F;
        }
    }

    return TRUE;
}

int fnDeleteIndenpentEcho(float *pData, int iYdim, int iXdim)
{
    int     iYIdx       = 0;
    int     iXIdx       = 0;
    int     iLoop_YIdx  = 0;
    int     iLoop_XIdx  = 0;
    int     iY_point    = 0;
    int     iX_point    = 0;
    int     iCheckCnt   = 0;
    float   *pTempData  = NULL;

    if(pData == NULL)
        return FALSE;

    if((pTempData = (float *)calloc(iYdim*iXdim, sizeof(float))) == NULL)
        return FALSE;

    memcpy(pTempData, pData, iYdim*iXdim*sizeof(float));

    for(iYIdx = 1; iYIdx < iYdim-1; iYIdx++)
    {
        for(iXIdx = 1; iXIdx < iXdim-1; iXIdx++)
        {
            iCheckCnt = 0;
            for(iLoop_YIdx = iYIdx-1; iLoop_YIdx <= iYIdx+1; iLoop_YIdx++)
            {
                for(iLoop_XIdx = iXIdx-1; iLoop_XIdx <= iXIdx+1; iLoop_XIdx++)
                {
                    if(pTempData[iLoop_YIdx*iXdim+iLoop_XIdx] != RDR_DF_BAD_VALUE_F &&
                       pTempData[iLoop_YIdx*iXdim+iLoop_XIdx] != RDR_DF_OUT_BOUND_F)
                    {
                        iCheckCnt++;
                        iY_point = iLoop_YIdx;
                        iX_point = iLoop_XIdx;
                    }
                }
            }

            if(iCheckCnt < RDR_DF_DEL_INDEPENT_ECHO_CNT)
                pData[iY_point*iXdim+iX_point] = RDR_DF_BAD_VALUE_F;
        }
    }

    free(pTempData);

    return TRUE;
}

int fnFillSpaceData(float *pData, int iYdim, int iXdim)
{
    int     iYIdx       = 0;
    int     iXIdx       = 0;
    float   fCurData    = 0.0;
    float   fW_Data     = 0.0;
    float   fE_Data     = 0.0;
    float   fN_Data     = 0.0;
    float   fS_Data     = 0.0;

    if(pData == NULL)
        return FALSE;

    for(iYIdx = 1; iYIdx < iYdim-1; iYIdx++)
    {
        for(iXIdx = 1; iXIdx < iXdim-1; iXIdx++)
        {
            fCurData    = pData[iYIdx*iXdim+iXIdx];
            fW_Data     = pData[iYIdx*iXdim+(iXIdx-1)];
            fE_Data     = pData[iYIdx*iXdim+(iXIdx+1)];
            fN_Data     = pData[(iYIdx+1)*iXdim+iXIdx];
            fS_Data     = pData[(iYIdx-1)*iXdim+iXIdx];

            if(fabs(fCurData - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
            {
                if(fabs(fW_Data - RDR_DF_BAD_VALUE_F) >= RDR_DF_ERR_RANGE_F && 
                   fabs(fE_Data - RDR_DF_BAD_VALUE_F) >= RDR_DF_ERR_RANGE_F)
                {
                    pData[iYIdx*iXdim+iXIdx] = fW_Data;
                }
                if(fabs(fN_Data - RDR_DF_BAD_VALUE_F) >= RDR_DF_ERR_RANGE_F && 
                   fabs(fS_Data - RDR_DF_BAD_VALUE_F) >= RDR_DF_ERR_RANGE_F)
                {
                    pData[iYIdx*iXdim+iXIdx] = fS_Data;
                }
            }
        }
    }

    return TRUE;
}

/* ================================================================================ */









