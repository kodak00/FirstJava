/* ================================================================================ */
//
// Radar Create ETOP ( Use Standard Format )
//
// 2016.08.12 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"
#include "rdr_product.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function



/* ================================================================================ */
// Function

float* fnCreateEtop(STD_RADAR *pStd, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, float fEtopMinThreshold, char* szFieldName, STD_AZIMUTH_TBL **ppTable)
{
#define FN_CREATE_ETOP_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(ppPpi != NULL) { fnFreeMatrix2D((void **)ppPpi, pStd->m_iMaxSweep); } \
    if(pEtop != NULL) { free(pEtop); };

    STD_RAY *pRay           = NULL;     // VARIABLE
    float   **ppPpi         = NULL;
    float   *pEtop          = NULL;
    float   fHeightKm       = 0.0f;
    float   fPlaneDistKm    = 0.0f;
    float   fElev           = 0.0f;
    float   fRadar_h_km     = 0.0f;
    double  dAe             = 0.0;
    double  dR              = 0.0;
    int     iEtopIdx        = 0;
    int     iXIdx           = 0;
    int     iYIdx           = 0;
    int     iSweepIdx       = 0;
    int     iCenterPos      = 0;

    if(pStd == NULL || ppTable == NULL || szFieldName == NULL)
        return NULL;

    pRay = pStd->m_ppSweep[0]->m_ppRay[0];
    if(fnGetFieldIdxRay(pRay, szFieldName) == -1)
    {   FN_CREATE_ETOP_ERROR("no moment") return NULL; }

    if((ppPpi = (float **)calloc(pStd->m_iMaxSweep, sizeof(float *))) == NULL)
    {   FN_CREATE_ETOP_ERROR("alloc fail") return NULL; }

    if((pEtop = (float *)calloc(iXdim*iYdim, sizeof(float))) == NULL)
    {   FN_CREATE_ETOP_ERROR("alloc fail") return NULL; }

    for(iEtopIdx = 0; iEtopIdx < iXdim*iYdim; iEtopIdx++)
        pEtop[iEtopIdx] = RDR_DF_BAD_VALUE_F;

    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        ppPpi[iSweepIdx] = fnCreatePPI(pStd, iSweepIdx, iXdim, iYdim, 
                                       fMaxRangeKm, fGridKm, szFieldName, ppTable[iSweepIdx]);
    }

    dAe         = RDR_DF_KMA_MAP_RE*4./3;
    fRadar_h_km = pStd->m_hdr.m_iAnteHeight/1000.;
    iCenterPos  = (int)((iXdim-1)/2);

    iEtopIdx = 0;
    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            fHeightKm = RDR_DF_BAD_VALUE_F;
            for(iSweepIdx = pStd->m_iMaxSweep - 1; iSweepIdx >= 0; iSweepIdx--)
            {
                if(ppPpi[iSweepIdx] != NULL)
                {
                    if(ppPpi[iSweepIdx][iEtopIdx] > fEtopMinThreshold)
                    {
                        fElev        = pStd->m_ppSweep[iSweepIdx]->m_ppRay[0]->m_hdr.m_fFixedAngle;
                        fPlaneDistKm = sqrt(pow((iCenterPos - iYIdx)*fGridKm,2.) 
                                       + pow((iCenterPos - iXIdx)*fGridKm,2.));
                        dR           = fPlaneDistKm/cos(RDR_DF_PI_DFS/180. * fElev);
                        fHeightKm    = sqrt(dR*dR + dAe*dAe + 2*dR*dAe*sin(RDR_DF_PI_DFS/180.*fElev)) 
                                       - dAe + fRadar_h_km;
                        break;
                    }
                }
            }

            if(fHeightKm > 0) 
                pEtop[iEtopIdx] = fHeightKm;

            iEtopIdx++;
        }
    }

    fnFreeMatrix2D((void **)ppPpi, pStd->m_iMaxSweep);

    return pEtop;
}

float* fnCreateEtopQIToDbz(STD_RADAR *pStd, STD_RADAR *pQiStd, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, float fEtopMinThreshold, STD_AZIMUTH_TBL **ppTable, STD_AZIMUTH_TBL **ppQiTable)
{
    float   *pEtop          = NULL;

    pEtop = fnCreateEtopQI(pStd, pQiStd, iXdim, iYdim, fMaxRangeKm, 
                           fGridKm, fEtopMinThreshold, "CZ", ppTable, ppQiTable);
    if(pEtop == NULL)
    {
        pEtop = fnCreateEtopQI(pStd, pQiStd, iXdim, iYdim, fMaxRangeKm, 
                               fGridKm, fEtopMinThreshold, "DZ", ppTable, ppQiTable);
    }

    return pEtop;
}

float* fnCreateEtopQI(STD_RADAR *pStd, STD_RADAR *pQiStd, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, float fEtopMinThreshold, char* szFieldName, STD_AZIMUTH_TBL **ppTable, STD_AZIMUTH_TBL **ppQiTable)
{
#define FN_CREATE_ETOP_QI_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(ppPpi   != NULL) { fnFreeMatrix2D((void **)ppPpi,   pStd->m_iMaxSweep); } \
    if(ppQiPpi != NULL) { fnFreeMatrix2D((void **)ppQiPpi, pQiStd->m_iMaxSweep); } \
    if(pEtop   != NULL) { free(pEtop); }; \

    STD_RAY *pRay           = NULL;     // VARIABLE
    float   **ppPpi         = NULL;
    float   **ppQiPpi       = NULL;
    float   *pEtop          = NULL;
    int     iSweepNo        = 0;
    int     iEtopIdx        = 0;
    int     iXIdx           = 0;
    int     iYIdx           = 0;
    int     iSweepIdx       = 0;

    if(pStd == NULL || pQiStd == NULL || ppTable == NULL || ppQiTable == NULL || szFieldName == NULL)
        return NULL;

    pRay = pStd->m_ppSweep[0]->m_ppRay[0];
    if(fnGetFieldIdxRay(pRay, szFieldName) == -1)
    {   FN_CREATE_ETOP_QI_ERROR("no moment") return NULL; }

    if(pStd->m_iMaxSweep != pQiStd->m_iMaxSweep)
        return NULL;

    if((ppPpi = (float **)calloc(pStd->m_iMaxSweep, sizeof(float *))) == NULL)
    {   FN_CREATE_ETOP_QI_ERROR("alloc fail") return NULL; }

    if((ppQiPpi = (float **)calloc(pQiStd->m_iMaxSweep, sizeof(float *))) == NULL)
    {   FN_CREATE_ETOP_QI_ERROR("alloc fail") return NULL; }

    if((pEtop = (float *)calloc(iXdim*iYdim, sizeof(float))) == NULL)
    {   FN_CREATE_ETOP_QI_ERROR("alloc fail") return NULL; }

    for(iEtopIdx = 0; iEtopIdx < iXdim*iYdim; iEtopIdx++)
        pEtop[iEtopIdx] = RDR_DF_BAD_VALUE_F;

    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        ppPpi[iSweepIdx] = fnCreatePPI(pStd, iSweepIdx, iXdim, iYdim, fMaxRangeKm, 
                                       fGridKm, szFieldName, ppTable[iSweepIdx]);
    }

    for(iSweepIdx = 0; iSweepIdx < pQiStd->m_iMaxSweep; iSweepIdx++)
    {
        ppQiPpi[iSweepIdx] = fnCreatePPI(pQiStd, iSweepIdx, iXdim, iYdim, fMaxRangeKm, 
                                         fGridKm, "QI", ppQiTable[iSweepIdx]);
    }

    iEtopIdx = 0;
    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            iSweepNo = -1;
            for(iSweepIdx = pStd->m_iMaxSweep - 1; iSweepIdx >= 0; iSweepIdx--)
            {
                if(ppPpi[iSweepIdx] != NULL && ppQiPpi[iSweepIdx] != NULL)
                {
                    if(ppPpi[iSweepIdx][iEtopIdx] > fEtopMinThreshold)
                    {
                        iSweepNo     = iSweepIdx;
                        break;
                    }
                }
            }

            if(iSweepNo >= 0) 
                pEtop[iEtopIdx] = ppQiPpi[iSweepNo][iEtopIdx];

            iEtopIdx++;
        }
    }

    fnFreeMatrix2D((void **)ppPpi,   pStd->m_iMaxSweep);
    fnFreeMatrix2D((void **)ppQiPpi, pQiStd->m_iMaxSweep);

    return pEtop;
}

/* ================================================================================ */








