/* ================================================================================ */
//
// Radar Create VIL ( Use Standard Format )
//
// 2016.08.12 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"
#include "rdr_product.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function



/* ================================================================================ */
// Function

float* fnCreateVil(STD_RADAR *pStd, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, int iTop_h_km, int iBottom_h_km, char* szFieldName, STD_AZIMUTH_TBL **ppTable)
{
#define FN_CREATE_VIL_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(ppCappi!= NULL) { fnFreeMatrix2D((void **)ppCappi, pStd->m_iMaxSweep); } \
    if(pVil   != NULL) { free(pVil); };

    STD_RAY *pRay       = NULL;     // VARIABLE
    float   **ppCappi   = NULL;
    float   *pVil       = NULL;
    float   fZ_i        = 0.0f;
    float   fZ_ip1      = 0.0f;
    float   fDh         = 0.0f;
    double  dSum        = 0.0;
    int     iVil_idx    = 0;
    int     iCappi_idx  = 0;
    int     iCappiCnt   = 0;

    if(pStd == NULL || ppTable == NULL || szFieldName == NULL)
        return NULL;

    pRay = pStd->m_ppSweep[0]->m_ppRay[0];
    if(fnGetFieldIdxRay(pRay, szFieldName) == -1)
    {   FN_CREATE_VIL_ERROR("no moment") return NULL; }

    iCappiCnt = iTop_h_km - iBottom_h_km;
    if(iCappiCnt <= 0)
        return NULL;

    if((ppCappi = (float **)calloc(iCappiCnt, sizeof(float *))) == NULL)
    {   FN_CREATE_VIL_ERROR("alloc fail") return NULL; }

    if((pVil = (float *)calloc(iXdim*iYdim, sizeof(float))) == NULL)
    {   FN_CREATE_VIL_ERROR("alloc fail") return NULL; }

    for(iVil_idx = 0; iVil_idx < iXdim*iYdim; iVil_idx++)
        pVil[iVil_idx] = RDR_DF_BAD_VALUE_F;

    for(iCappi_idx = 0; iCappi_idx < iCappiCnt; iCappi_idx++)
    {
        ppCappi[iCappi_idx] = fnCreateCappiReal(pStd, (iBottom_h_km + iCappi_idx), 
                                                iXdim, iYdim, fMaxRangeKm, fGridKm, 
                                                szFieldName, ppTable);
    }

    fDh = 1000.;
    for(iVil_idx = 0; iVil_idx < iXdim*iYdim; iVil_idx++)
    {
        dSum = 0.0;
        for(iCappi_idx = 0; iCappi_idx < iCappiCnt; iCappi_idx++)
        {
            if(ppCappi[iCappi_idx] != NULL)
            {
                if(iCappi_idx == iCappiCnt-1)
                {
                    if(ppCappi[iCappi_idx][iVil_idx] > 0)
                    {
                        fZ_i  = fnDbzToZeF(ppCappi[iCappi_idx][iVil_idx]);
                        dSum += 3.44 * pow(10.,-6.) * pow(fZ_i,4./7.) * fDh;
                    }
                }
                else
                {
                    if(ppCappi[iCappi_idx][iVil_idx] > 0 &&
                       ppCappi[iCappi_idx+1][iVil_idx] > 0)
                    {
                        fZ_i   = (float)fnDbzToZeF(ppCappi[iCappi_idx][iVil_idx]);
                        fZ_ip1 = (float)fnDbzToZeF(ppCappi[iCappi_idx+1][iVil_idx]);
                        dSum += 3.44 * pow(10.,-6) * pow((fZ_i+fZ_ip1)/2.,4./7.) * fDh;
                    }
                    else if(ppCappi[iCappi_idx][iVil_idx] > 0)
                    {
                        // 원 소스에 없었음 fZ_i 부분 버그일듯
                        fZ_i  = (float)fnDbzToZeF(ppCappi[iCappi_idx][iVil_idx]); 
                        dSum += 3.44 * pow(10.,-6) * pow(fZ_i,4./7.) * fDh;
                    }
                }
            }
        }
        
        if(dSum > 0.)
            pVil[iVil_idx] = dSum;
    }

    fnFreeMatrix2D((void **)ppCappi, iCappiCnt);

    return pVil;
}

/* ================================================================================ */



