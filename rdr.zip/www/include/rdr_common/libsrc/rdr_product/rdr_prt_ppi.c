/* ================================================================================ */
//
// Radar Create PPI ( Use Standard Format )
//
// 2016.08.09 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"
#include "rdr_product.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function



/* ================================================================================ */
// Function

float* fnCreatePPI(STD_RADAR *pStd, int iSweepIdx, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, char* szFieldName, STD_AZIMUTH_TBL *pTable)
{
#define FN_CREATE_PPI_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pPpi != NULL) { free(pPpi); }

    STD_SWEEP   *pSweep         = NULL;     // VARIABLE
    STD_RAY     *pRay           = NULL;     // VARIABLE
    int         iXIdx           = 0,    iYIdx       = 0;
    int         iRayIdx         = 0,    iFieldIdx   = 0;
    int         iPpiIdx         = 0;
    float       fRes            = 0.0f, fAzim       = 0.0f;
    float       fRangeKm        = 0.0f, fVal        = 0.0f;
    float       *pPpi           = NULL;

    if(pStd == NULL || pStd->m_iMaxSweep <= iSweepIdx || iXdim != iYdim || 
       iXdim < 0 || iYdim < 0 || szFieldName == NULL || pTable == NULL)
    {   FN_CREATE_PPI_ERROR("Invalid arg") return NULL; }

    if((pSweep = pStd->m_ppSweep[iSweepIdx]) == NULL || pSweep->m_ppRay == NULL)
    {   FN_CREATE_PPI_ERROR("sweep is null or m_ppRay is null") return NULL; }

    pRay = pSweep->m_ppRay[0];
    if((iFieldIdx = fnGetFieldIdxRay(pRay, szFieldName)) == -1)
    {   FN_CREATE_PPI_ERROR("no moment") return NULL; }

    if((pPpi = (float *)calloc(iXdim*iYdim, sizeof(float))) == NULL)
    {   FN_CREATE_PPI_ERROR("calloc fail") return NULL; }

    for(iPpiIdx = 0; iPpiIdx < iXdim*iYdim; iPpiIdx++)
        pPpi[iPpiIdx] = RDR_DF_BAD_VALUE_F;

    fRes = 360.0/pSweep->m_iMaxRay;

    for(iYIdx = -iYdim/2; iYIdx < iYdim/2; iYIdx++)
    {
        for(iXIdx = -iXdim/2; iXIdx < iXdim/2; iXIdx++)
        {
            iPpiIdx = (iYIdx + iYdim/2)*iYdim + (iXdim - 1) - (iXIdx + iXdim/2);

            fRangeKm = (float)sqrt((double)(iXIdx*iXIdx) + (double)(iYIdx*iYIdx));
            fRangeKm *= fGridKm;

            if(fRangeKm > fMaxRangeKm) fVal = RDR_DF_BADVAL;
            else 
            {
                fAzim     = fnCalcAzimuthToXY(iYIdx, iXIdx);

                if((iRayIdx = fnSearchRayToAzim(pSweep, fRes, fAzim, pTable)) == -1)
                {    pPpi[iPpiIdx] = RDR_DF_BAD_VALUE_F; continue; }

                pRay = pSweep->m_ppRay[iRayIdx];

                //if(fnDiffDegree(fAzim, pRay->m_hdr.m_fAzimuth) > 
                //   (pStd->m_hdr.m_fBeamWidthH)*0.6)
                if(fnDiffDegree(fAzim, pRay->m_hdr.m_fAzimuth) > 1.0)
                {    pPpi[iPpiIdx] = RDR_DF_BAD_VALUE_F; continue; }

                fVal = fnGetBinValueToRay(pRay, iFieldIdx, fRangeKm, 
                                          pStd->m_hdr.m_iNoDataValue);
            }

            if((fabs(fVal - RDR_DF_BADVAL    ) < RDR_DF_ERR_RANGE_F) || 
               (fabs(fVal - RDR_DF_NOTFOUND_V) < RDR_DF_ERR_RANGE_F) || 
               (fabs(fVal - RDR_DF_NOTFOUND_H) < RDR_DF_ERR_RANGE_F))
                pPpi[iPpiIdx] = RDR_DF_BAD_VALUE_F;
            else
                pPpi[iPpiIdx] = fVal;
        }
    }

    return pPpi;
}

/* ================================================================================ */


