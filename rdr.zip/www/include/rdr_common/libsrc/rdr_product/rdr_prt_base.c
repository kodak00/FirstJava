/* ================================================================================ */
//
// Radar Create BASE ( Use Standard Format )
//
// 2016.08.12 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"
#include "rdr_product.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function



/* ================================================================================ */
// Function

float* fnCreateBase(STD_RADAR *pStd, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, char* szFieldName, STD_AZIMUTH_TBL **ppTable)
{
#define FN_CREATE_BASE_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(ppPpi != NULL) { fnFreeMatrix2D((void **)ppPpi, pStd->m_iMaxSweep); } \
    if(pBase != NULL) { free(pBase); };

    STD_RAY *pRay       = NULL;     // VARIABLE
    float   **ppPpi     = NULL;
    float   *pBase      = NULL;
    int     iBaseIdx    = 0;
    int     iSweepIdx   = 0;

    if(pStd == NULL || ppTable == NULL || iXdim < 0 || iYdim < 0 || szFieldName == NULL)
        return NULL;

    pRay = pStd->m_ppSweep[0]->m_ppRay[0];
    if(fnGetFieldIdxRay(pRay, szFieldName) == -1)
    {   FN_CREATE_BASE_ERROR("no moment") return NULL; }

    if((ppPpi = (float **)calloc(pStd->m_iMaxSweep, sizeof(float *))) == NULL)
    {   FN_CREATE_BASE_ERROR("alloc fail") return NULL; }

    if((pBase = (float *)calloc(iXdim*iYdim, sizeof(float))) == NULL)
    {   FN_CREATE_BASE_ERROR("alloc fail") return NULL; }

    for(iBaseIdx = 0; iBaseIdx < iXdim*iYdim; iBaseIdx++)
        pBase[iBaseIdx] = RDR_DF_BAD_VALUE_F;

    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        ppPpi[iSweepIdx] = fnCreatePPI(pStd, iSweepIdx, iXdim, iYdim, 
                                       fMaxRangeKm, fGridKm, szFieldName, ppTable[iSweepIdx]);
    }

    for(iBaseIdx = 0; iBaseIdx < iXdim*iYdim; iBaseIdx++)
    {
        for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
        {
            if(ppPpi[iSweepIdx] != NULL)
            {
                if(ppPpi[iSweepIdx][iBaseIdx] != RDR_DF_BAD_VALUE_F)
                {
                    pBase[iBaseIdx] = ppPpi[iSweepIdx][iBaseIdx];
                    break;
                }
            }
        }
    }

    fnFreeMatrix2D((void **)ppPpi, pStd->m_iMaxSweep);

    return pBase;
}

float* fnCreateBaseQIToDbz(STD_RADAR *pStd, STD_RADAR *pQiStd, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, STD_AZIMUTH_TBL **ppTable, STD_AZIMUTH_TBL **ppQiTable)
{
    float   *pBase      = NULL;

    pBase = fnCreateBaseQI(pStd, pQiStd, iXdim, iYdim, fMaxRangeKm, fGridKm, "CZ", ppTable, ppQiTable);
    if(pBase == NULL)
        pBase = fnCreateBaseQI(pStd, pQiStd, iXdim, iYdim, fMaxRangeKm, fGridKm, "DZ", ppTable, ppQiTable);

    return pBase;
}

float* fnCreateBaseQI(STD_RADAR *pStd, STD_RADAR *pQiStd, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, char* szFieldName, STD_AZIMUTH_TBL **ppTable, STD_AZIMUTH_TBL **ppQiTable)
{
#define FN_CREATE_BASE_QI_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(ppPpi   != NULL) { fnFreeMatrix2D((void **)ppPpi,   pStd->m_iMaxSweep); } \
    if(ppQiPpi != NULL) { fnFreeMatrix2D((void **)ppQiPpi, pQiStd->m_iMaxSweep); } \
    if(pBase   != NULL) { free(pBase); };

    STD_RAY *pRay       = NULL;     // VARIABLE
    float   **ppPpi     = NULL;
    float   **ppQiPpi   = NULL;
    float   *pBase      = NULL;
    int     iBaseIdx    = 0;
    int     iSweepIdx   = 0;

    if(pStd == NULL || pQiStd == NULL || ppQiTable == NULL || ppTable == NULL || szFieldName == NULL)
        return NULL;

    pRay = pStd->m_ppSweep[0]->m_ppRay[0];
    if(fnGetFieldIdxRay(pRay, szFieldName) == -1)
    {   FN_CREATE_BASE_QI_ERROR("no moment") return NULL; }

    if(pStd->m_iMaxSweep != pQiStd->m_iMaxSweep)
        return NULL;

    if((ppPpi = (float **)calloc(pStd->m_iMaxSweep, sizeof(float *))) == NULL)
    {   FN_CREATE_BASE_QI_ERROR("alloc fail") return NULL; }

    if((ppQiPpi = (float **)calloc(pQiStd->m_iMaxSweep, sizeof(float *))) == NULL)
    {   FN_CREATE_BASE_QI_ERROR("alloc fail") return NULL; }

    if((pBase = (float *)calloc(iXdim*iYdim, sizeof(float))) == NULL)
    {   FN_CREATE_BASE_QI_ERROR("alloc fail") return NULL; }

    for(iBaseIdx = 0; iBaseIdx < iXdim*iYdim; iBaseIdx++)
        pBase[iBaseIdx] = RDR_DF_BAD_VALUE_F;

    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        ppPpi[iSweepIdx] = fnCreatePPI(pStd, iSweepIdx, iXdim, iYdim, 
                                       fMaxRangeKm, fGridKm, szFieldName, ppTable[iSweepIdx]);
    }

    for(iSweepIdx = 0; iSweepIdx < pQiStd->m_iMaxSweep; iSweepIdx++)
    {
        ppQiPpi[iSweepIdx] = fnCreatePPI(pQiStd, iSweepIdx, iXdim, iYdim, 
                                         fMaxRangeKm, fGridKm, "QI", ppQiTable[iSweepIdx]);
    }

    for(iBaseIdx = 0; iBaseIdx < iXdim*iYdim; iBaseIdx++)
    {
        for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
        {
            if(ppPpi[iSweepIdx] != NULL && ppQiPpi[iSweepIdx] != NULL)
            {
                if(ppPpi[iSweepIdx][iBaseIdx] != RDR_DF_BAD_VALUE_F)
                {
                    pBase[iBaseIdx] = ppQiPpi[iSweepIdx][iBaseIdx];
                    break;
                }
            }
        }
    }

    fnFreeMatrix2D((void **)ppPpi, pStd->m_iMaxSweep);
    fnFreeMatrix2D((void **)ppQiPpi, pStd->m_iMaxSweep);

    return pBase;
}

/* ================================================================================ */










