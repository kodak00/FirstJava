/* ================================================================================ */
//
// Radar Create CAPPI ( Use Standard Format )
//
// 2016.08.09 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"
#include "rdr_product.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function

static CLOEST_SWEEPS fnInitCloestSweep(void)
{
    int             iSweepIdx   = 0;
    int             iRayIdx     = 0;
    int             iBinIdx     = 0;
    CLOEST_SWEEPS   cloest_sweeps;

    for(iSweepIdx = 0; iSweepIdx < 2; iSweepIdx++)
    {
        cloest_sweeps.m_valid[iSweepIdx] = FALSE;
        cloest_sweeps.m_sweep[iSweepIdx] = NULL;
        for(iRayIdx = 0; iRayIdx < 2; iRayIdx++)
        {
            cloest_sweeps.m_azims[iSweepIdx].m_valid[iRayIdx] = FALSE;
            cloest_sweeps.m_azims[iSweepIdx].m_ray[iRayIdx]   = NULL;
            for(iBinIdx = 0; iBinIdx < 2; iBinIdx++)
            {
                cloest_sweeps.m_azims[iSweepIdx].m_values[iRayIdx].m_valid[iBinIdx]   = FALSE;
                cloest_sweeps.m_azims[iSweepIdx].m_values[iRayIdx].m_dBZ[iBinIdx]     = -127;
                cloest_sweeps.m_azims[iSweepIdx].m_values[iRayIdx].m_bin_num[iBinIdx] = -1;
                cloest_sweeps.m_azims[iSweepIdx].m_values[iRayIdx].m_R[iBinIdx]       = -1.0f;
            }
        }
    }

    return cloest_sweeps;
}

static int fnGetCloestSweepToIndex(STD_RADAR *pStd, float fElev, int *pSweepIndex1, int *pSweepIndex2)
{
    int             iSweepIdx       = 0;
    int             iSweepIndex1    = -1;
    int             iSweepIndex2    = -1;
    float           fDeltaAngle     = 91.f;
    float           fCheckAngle     = 0.0f;

    if(pStd == NULL)
        return FALSE;

    fDeltaAngle = 91.f;
    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        fCheckAngle 
        = fnDiffDegree(pStd->m_ppSweep[iSweepIdx]->m_ppRay[0]->m_hdr.m_fFixedAngle, fElev);

        if(pStd->m_ppSweep[iSweepIdx]->m_ppRay[0]->m_hdr.m_fFixedAngle > fElev)
            break;

        if(fCheckAngle <= fDeltaAngle)
        {
            fDeltaAngle  = fCheckAngle;
            iSweepIndex1 = iSweepIdx;
        }
    }

    fDeltaAngle = 91.f;
    for(iSweepIdx = pStd->m_iMaxSweep-1; iSweepIdx >= 0; iSweepIdx--)
    {
        if(iSweepIndex1 == iSweepIdx)
            continue;

        fCheckAngle 
        = fnDiffDegree(pStd->m_ppSweep[iSweepIdx]->m_ppRay[0]->m_hdr.m_fFixedAngle, fElev);

        if(pStd->m_ppSweep[iSweepIdx]->m_ppRay[0]->m_hdr.m_fFixedAngle < fElev)
            break;

        if(fCheckAngle <= fDeltaAngle)
        {
            fDeltaAngle  = fCheckAngle;
            iSweepIndex2 = iSweepIdx;
        }
    }

    if((iSweepIndex1 - iSweepIndex2) < 0)
    {
        if(pSweepIndex1 != NULL) *pSweepIndex1 = iSweepIndex1;
        if(pSweepIndex2 != NULL) *pSweepIndex2 = iSweepIndex2;
    }
    else
    {
        if(pSweepIndex1 != NULL) *pSweepIndex1 = iSweepIndex2;
        if(pSweepIndex2 != NULL) *pSweepIndex2 = iSweepIndex1;
    }

    return TRUE;
}

static CLOEST_SWEEPS fnGetCloestToSweeps(STD_RADAR *pStd, float fElev, float fElevLimit)
{
    int             iSweepIndex1    = -1;
    int             iSweepIndex2    = -1;
    float           fSweepElev1     = 0.0f;
    float           fSweepElev2     = 0.0f;
    CLOEST_SWEEPS   cloest_sweeps;

    cloest_sweeps.m_sweep[0] = NULL;
    cloest_sweeps.m_sweep[1] = NULL;
    cloest_sweeps.m_swIdx[0] = -1;
    cloest_sweeps.m_swIdx[1] = -1;
    cloest_sweeps.m_valid[0] = FALSE;
    cloest_sweeps.m_valid[1] = FALSE;
    cloest_sweeps.m_phi[0]   = -250.0f;
    cloest_sweeps.m_phi[1]   = -250.0f;

    if(pStd == NULL)
    {
        return cloest_sweeps;
    }

    if(fnGetCloestSweepToIndex(pStd, fElev, &iSweepIndex1, &iSweepIndex2) == FALSE)
    {
        cloest_sweeps.m_valid[0] = FALSE;
        cloest_sweeps.m_valid[1] = FALSE;
        return cloest_sweeps;
    }

    if(iSweepIndex1 >= 0)
    {
        fSweepElev1 = pStd->m_ppSweep[iSweepIndex1]->m_ppRay[0]->m_hdr.m_fFixedAngle;
        if(fnDiffDegree(fElev, fSweepElev1) <= fElevLimit)
        {
            cloest_sweeps.m_sweep[0] = pStd->m_ppSweep[iSweepIndex1];
            cloest_sweeps.m_swIdx[0] = iSweepIndex1;
            cloest_sweeps.m_valid[0] = TRUE;
            cloest_sweeps.m_phi[0]   = fSweepElev1;
        }
    }

    if(iSweepIndex2 >= 0)
    {
        fSweepElev2 = pStd->m_ppSweep[iSweepIndex2]->m_ppRay[0]->m_hdr.m_fFixedAngle;
        if(fnDiffDegree(fElev, fSweepElev2) <= fElevLimit)
        {
            cloest_sweeps.m_sweep[1] = pStd->m_ppSweep[iSweepIndex2];
            cloest_sweeps.m_swIdx[1] = iSweepIndex2;
            cloest_sweeps.m_valid[1] = TRUE;
            cloest_sweeps.m_phi[1]   = fSweepElev2;
        }
    }

    return cloest_sweeps;
}

static CLOEST_AZIMS fnGetClosestToAzims(STD_SWEEP *pSweep, float fAzim, float fAzimLimit, STD_AZIMUTH_TBL *pTable)
{
    STD_RAY         *pRay           = NULL;                             // VARIABLE;
    STD_RAY         *pCwRay         = NULL, *pCcwRay        = NULL;     // VARIABLE;
    int             iRayIdx         = 0;
    int             iCwRay          = 0,    iCcwRay         = 0;
    int             iRayTemp1       = 0,    iRayTemp2       = 0;
    float           fCwDiff         = 0.0f, fCcwDiff        = 0.0f;
    float           fRes            = 0.0f;
    CLOEST_AZIMS    cloest_azims;

    iRayTemp1 = iRayTemp2 = -1;
    cloest_azims.m_valid[0] = cloest_azims.m_valid[1] = FALSE;
    cloest_azims.m_ray[0]   = cloest_azims.m_ray[1]   = NULL;
    cloest_azims.m_theta[0] = cloest_azims.m_theta[1] = -250.0f;

    if(pSweep == NULL || pTable == NULL)
    {
        return cloest_azims;
    }

    fRes = 360.0/pSweep->m_iMaxRay;

    if((iRayIdx = fnSearchRayToAzim(pSweep, fRes, fAzim, pTable)) == -1)
        return cloest_azims;

    if((pRay = pSweep->m_ppRay[iRayIdx]) == NULL) 
        return cloest_azims;

    if(fnDiffDegree(fAzim, pRay->m_hdr.m_fAzimuth) <= fAzimLimit)
    {
        iRayTemp1 = iRayIdx;
        iCwRay    = pTable[iRayIdx].m_iHigh;
        iCcwRay   = pTable[iRayIdx].m_iLow;
    }
    else return cloest_azims;

    if(iCwRay != -1) 
    {
        if((pCwRay = pSweep->m_ppRay[iCwRay]) != NULL)
            fCwDiff = fnDiffDegree(pCwRay->m_hdr.m_fAzimuth, fAzim);
    }
    if(iCcwRay != -1) 
    {
        if((pCcwRay = pSweep->m_ppRay[iCcwRay]) != NULL)
            fCcwDiff = fnDiffDegree(pCcwRay->m_hdr.m_fAzimuth, fAzim);
    }

    if((iCwRay  != -1) && (fCwDiff  <= fAzimLimit) && 
       (iCcwRay != -1) && (fCcwDiff <= fAzimLimit))
    {
        if(fCwDiff > fCcwDiff) iRayTemp2 = iCcwRay;
        else                   iRayTemp2 = iCwRay;
    }
    else if((iCwRay  != -1) && (fCwDiff <= fAzimLimit))  iRayTemp2 = iCwRay;
    else if((iCcwRay != -1) && (fCcwDiff <= fAzimLimit)) iRayTemp2 = iCcwRay;

    if(iRayTemp1 != -1 && pSweep->m_ppRay[iRayTemp1] != NULL)
    {
        if(fnMinusDegree(pSweep->m_ppRay[iRayTemp1]->m_hdr.m_fAzimuth, fAzim) < 0)
        {
            cloest_azims.m_ray[0]  = pSweep->m_ppRay[iRayTemp1];
            cloest_azims.m_valid[0] = TRUE;
            cloest_azims.m_theta[0] = pSweep->m_ppRay[iRayTemp1]->m_hdr.m_fAzimuth;
        }
        else
        {
            cloest_azims.m_ray[1]  = pSweep->m_ppRay[iRayTemp1];
            cloest_azims.m_valid[1] = TRUE;
            cloest_azims.m_theta[1] = pSweep->m_ppRay[iRayTemp1]->m_hdr.m_fAzimuth;
        }
    }

    if(iRayTemp2 != -1 && pSweep->m_ppRay[iRayTemp2] != NULL)
    {
        if(fnMinusDegree(pSweep->m_ppRay[iRayTemp2]->m_hdr.m_fAzimuth, fAzim) < 0)
        {
            cloest_azims.m_ray[0]  = pSweep->m_ppRay[iRayTemp2];
            cloest_azims.m_valid[0] = TRUE;
            cloest_azims.m_theta[0] = pSweep->m_ppRay[iRayTemp2]->m_hdr.m_fAzimuth;
        }
        else
        {
            cloest_azims.m_ray[1]  = pSweep->m_ppRay[iRayTemp2];
            cloest_azims.m_valid[1] = TRUE;
            cloest_azims.m_theta[1] = pSweep->m_ppRay[iRayTemp2]->m_hdr.m_fAzimuth;
        }
    }

    return cloest_azims;
}

static CLOEST_VALUES fnGetCloestToBins(STD_RADAR *pStd, STD_RAY *pRay, int iFieldIndex, float fSlantRangeM)
{
    float           fStartRangeKm   = 0.0f;     // VARIABLE
    float           fSlantRangeM2   = 0.0f;
    float           fVal            = 0.0f;
    CLOEST_VALUES   cloest_values;

    cloest_values.m_dBZ[0]     = cloest_values.m_dBZ[1]     = RDR_DF_BAD_VALUE_F;
    cloest_values.m_valid[0]   = cloest_values.m_valid[1]   = FALSE;
    cloest_values.m_bin_num[0] = cloest_values.m_bin_num[1] = -1;
    cloest_values.m_R[0]       = cloest_values.m_R[1]       = -1.0f;

    if(pStd == NULL || pRay == NULL)
    {
        return cloest_values;
    }

    fStartRangeKm = pRay->m_hdr.m_iStartRangeKm + pRay->m_hdr.m_iStartRangeMeter/1000.;
    fSlantRangeM2 = fSlantRangeM+pRay->m_hdr.m_iBinSpacing;

    if((fVal = fnGetBinValueToRay(pRay, iFieldIndex, fSlantRangeM/1000., 
                                  pStd->m_hdr.m_iNoDataValue)) != RDR_DF_BADVAL)
    {
        cloest_values.m_dBZ[0]     = fVal;
        cloest_values.m_valid[0]   = TRUE;
        cloest_values.m_bin_num[0] = (int)((fSlantRangeM - fStartRangeKm*1000.) 
                                           / pRay->m_hdr.m_iBinSpacing);
        cloest_values.m_R[0]       = fSlantRangeM;
    }

    if((fVal = fnGetBinValueToRay(pRay, iFieldIndex, fSlantRangeM2/1000., 
                                  pStd->m_hdr.m_iNoDataValue)) != RDR_DF_BADVAL)
    {
        cloest_values.m_dBZ[1]     = fVal;
        cloest_values.m_valid[1]   = TRUE;
        cloest_values.m_bin_num[1] = (int)((fSlantRangeM2 - fStartRangeKm*1000.) 
                                           / pRay->m_hdr.m_iBinSpacing);
        cloest_values.m_R[1]       = fSlantRangeM2;
    }

    return cloest_values;
}

static float fnCalMohrCappiValue(CLOEST_SWEEPS cloest_sweeps, float fAzim, float fElev, float fSlantRangeM, int iCappiKind, int iYesDbz)
{
    int             iSweepIdx       = 0;
    int             iCalCnt         = 0;
    float           fVal            = 0.0f;
    float           fDr             = 0.0f;
    float           fDt             = 0.0f;
    float           fDp             = 0.0;
    float           fR_Ri           = 0.0f;
    float           fR_Rip1         = 0.0f;
    float           fT_Tj           = 0.0f;
    float           fT_Tjp1         = 0.0f;
    float           fZe_i_j         = 0.0f;
    float           fZe_ip1_j       = 0.0f;
    float           fZe_i_jp1       = 0.0f;
    float           fZe_ip1_jp1     = 0.0f;
    float           fZe_R_T[2]      = { 0.0f, };
    float           fZe_R_T_temp1   = 0.0f;
    float           fZe_R_T_temp2   = 0.0f;
    float           fP_Pk           = 0.0f;
    float           fP_Pkp1         = 0.0f;

    if(cloest_sweeps.m_azims[0].m_values[0].m_valid[0] == FALSE && 
       cloest_sweeps.m_azims[0].m_values[0].m_valid[1] == FALSE &&
       cloest_sweeps.m_azims[0].m_values[1].m_valid[0] == FALSE &&
       cloest_sweeps.m_azims[0].m_values[1].m_valid[1] == FALSE &&
       cloest_sweeps.m_azims[1].m_values[0].m_valid[0] == FALSE &&
       cloest_sweeps.m_azims[1].m_values[0].m_valid[1] == FALSE &&
       cloest_sweeps.m_azims[1].m_values[1].m_valid[0] == FALSE &&
       cloest_sweeps.m_azims[1].m_values[1].m_valid[1] == FALSE)
        return RDR_DF_BAD_VALUE_F;

    switch(iCappiKind)
    {
        case RDR_EN_PSEUDO_CAPPI: 
        break;
        case RDR_EN_REAL_CAPPI:
        {
            if(cloest_sweeps.m_valid[1] == TRUE  && 
               cloest_sweeps.m_valid[0] == FALSE && 
               cloest_sweeps.m_swIdx[1] == 0)
            {
                if(fElev < cloest_sweeps.m_sweep[1]->m_ppRay[0]->m_hdr.m_fFixedAngle)
                    return RDR_DF_BAD_VALUE_F;
            }
        }
        break;
        default:
            return RDR_DF_BAD_VALUE_F;
    }

    fVal = RDR_DF_BAD_VALUE_F;
    fDr = fDt = 1.;

    for(iSweepIdx = 0; iSweepIdx < 2; iSweepIdx++)
    {
        fR_Ri              = 0.5;
        fR_Rip1            = -0.5;
        fT_Tj              = 1.;
        fT_Tjp1            = -1.;
        fZe_i_j            = 0.;
        fZe_ip1_j          = 0.;
        fZe_i_jp1          = 0.;
        fZe_ip1_jp1        = 0;
        fZe_R_T[iSweepIdx] = 0.;

        if(cloest_sweeps.m_valid[iSweepIdx] == FALSE) continue;

        if(cloest_sweeps.m_sweep[iSweepIdx]->m_ppRay[0] != NULL)
        {
            fDr     = cloest_sweeps.m_sweep[iSweepIdx]->m_ppRay[0]->m_hdr.m_iBinSpacing / 1000.;
            fR_Ri   = fDr / 2.;
            fR_Rip1 = -1 * fR_Ri;
        }

        if(cloest_sweeps.m_sweep[iSweepIdx]->m_ppRay[0] != NULL && 
           cloest_sweeps.m_sweep[iSweepIdx]->m_ppRay[1] != NULL)
        {
            fDt     = fnDiffDegree(cloest_sweeps.m_sweep[iSweepIdx]->m_ppRay[0]->m_hdr.m_fAzimuth,
                                   cloest_sweeps.m_sweep[iSweepIdx]->m_ppRay[1]->m_hdr.m_fAzimuth);
            fT_Tj   = fDt / 2.;
            fT_Tjp1 = -1 * fT_Tj;
        }

        if(cloest_sweeps.m_azims[iSweepIdx].m_valid[0] == TRUE)
            fT_Tj   = fnMinusDegree(fAzim, cloest_sweeps.m_azims[iSweepIdx].m_ray[0]->m_hdr.m_fAzimuth);

        if(cloest_sweeps.m_azims[iSweepIdx].m_valid[1] == TRUE)
            fT_Tjp1 = fnMinusDegree(fAzim, cloest_sweeps.m_azims[iSweepIdx].m_ray[1]->m_hdr.m_fAzimuth);

        if(cloest_sweeps.m_azims[iSweepIdx].m_valid[0] == TRUE)
        {
            if(cloest_sweeps.m_azims[iSweepIdx].m_values[0].m_valid[0] == TRUE)
            {
                if(iYesDbz == TRUE)
                    fZe_i_j = (float)fnDbzToZeF(cloest_sweeps.m_azims[iSweepIdx].m_values[0].m_dBZ[0]);
                else
                    fZe_i_j = cloest_sweeps.m_azims[iSweepIdx].m_values[0].m_dBZ[0];
            }
            if(cloest_sweeps.m_azims[iSweepIdx].m_values[0].m_valid[1] == TRUE)
            {
                if(iYesDbz == TRUE)
                    fZe_ip1_j = (float)fnDbzToZeF(cloest_sweeps.m_azims[iSweepIdx].m_values[0].m_dBZ[1]);
                else
                    fZe_ip1_j = cloest_sweeps.m_azims[iSweepIdx].m_values[0].m_dBZ[1];
            }
        }

        if(cloest_sweeps.m_azims[iSweepIdx].m_valid[1] == TRUE)
        {
            if(cloest_sweeps.m_azims[iSweepIdx].m_values[1].m_valid[0] == TRUE)
            {
                if(iYesDbz == TRUE)
                    fZe_i_jp1 = (float)fnDbzToZeF(cloest_sweeps.m_azims[iSweepIdx].m_values[1].m_dBZ[0]);
                else
                    fZe_i_jp1 = cloest_sweeps.m_azims[iSweepIdx].m_values[1].m_dBZ[0];
            }
            if(cloest_sweeps.m_azims[iSweepIdx].m_values[1].m_valid[1] == TRUE)
            {
                if(iYesDbz == TRUE)
                    fZe_ip1_jp1 = (float)fnDbzToZeF(cloest_sweeps.m_azims[iSweepIdx].m_values[1].m_dBZ[1]);
                else
                    fZe_ip1_jp1 = cloest_sweeps.m_azims[iSweepIdx].m_values[1].m_dBZ[1];
            }
        }

        if(cloest_sweeps.m_azims[iSweepIdx].m_values[0].m_valid[0] == TRUE)
        {
            fR_Ri = (fSlantRangeM - cloest_sweeps.m_azims[iSweepIdx].m_values[0].m_R[0]) / 1000.;
            fDr   = cloest_sweeps.m_azims[iSweepIdx].m_ray[0]->m_hdr.m_iBinSpacing / 1000.;
        }
        else if(cloest_sweeps.m_azims[iSweepIdx].m_values[1].m_valid[0] == TRUE)
        {
            fR_Ri = (fSlantRangeM - cloest_sweeps.m_azims[iSweepIdx].m_values[1].m_R[0]) / 1000.;
            fDr   = cloest_sweeps.m_azims[iSweepIdx].m_ray[1]->m_hdr.m_iBinSpacing / 1000.;
        }

        if(cloest_sweeps.m_azims[iSweepIdx].m_values[0].m_valid[1] == TRUE)
        {
            fR_Rip1 = (fSlantRangeM - cloest_sweeps.m_azims[iSweepIdx].m_values[0].m_R[1]) / 1000.;
            fDr     = cloest_sweeps.m_azims[iSweepIdx].m_ray[0]->m_hdr.m_iBinSpacing / 1000.;
        }
        else if(cloest_sweeps.m_azims[iSweepIdx].m_values[1].m_valid[1] == TRUE)
        {
            fR_Rip1 = (fSlantRangeM - cloest_sweeps.m_azims[iSweepIdx].m_values[1].m_R[1]) / 1000.;
            fDr     = cloest_sweeps.m_azims[iSweepIdx].m_ray[1]->m_hdr.m_iBinSpacing / 1000.;
        }

        if(cloest_sweeps.m_azims[iSweepIdx].m_valid[0] == TRUE && 
           cloest_sweeps.m_azims[iSweepIdx].m_valid[1] == TRUE)
        {
            fDt = fnDiffDegree(cloest_sweeps.m_azims[iSweepIdx].m_theta[1], 
                               cloest_sweeps.m_azims[iSweepIdx].m_theta[0]);
            fZe_R_T_temp1 = fR_Ri * ((fT_Tj * fZe_ip1_jp1) - (fT_Tjp1 * fZe_ip1_j));
            fZe_R_T_temp2 = fR_Rip1 * ((fT_Tj * fZe_i_jp1) - (fT_Tjp1 * fZe_i_j));

            fZe_R_T[iSweepIdx] = (1/(fDr*fDt)) * (fZe_R_T_temp1 - fZe_R_T_temp2);
        }
        else if(cloest_sweeps.m_azims[iSweepIdx].m_valid[0] == TRUE)
            fZe_R_T[iSweepIdx] = (1/fDr) * (fR_Ri * fZe_ip1_j - fR_Rip1 * fZe_i_j);
        else if(cloest_sweeps.m_azims[iSweepIdx].m_valid[1] == TRUE)
            fZe_R_T[iSweepIdx] = (1/fDr) * (fR_Ri * fZe_i_jp1 - fR_Rip1 * fZe_ip1_jp1);
        else
            return RDR_DF_BAD_VALUE_F;

        iCalCnt++;
    }

    if(iCalCnt <= 0)
        return RDR_DF_BAD_VALUE_F;

    fDp     = 1.;
    fP_Pk   = 0.5;
    fP_Pkp1 = 0.5;

    if(cloest_sweeps.m_valid[0] == TRUE && cloest_sweeps.m_valid[1] == TRUE)
    {
        if(fElev == cloest_sweeps.m_phi[0])      fVal = fZe_R_T[0];
        else if(fElev == cloest_sweeps.m_phi[1]) fVal = fZe_R_T[1];
        else
        {
            fDp     = fnDiffDegree(cloest_sweeps.m_phi[1], cloest_sweeps.m_phi[0]);
            fP_Pk   = fnMinusDegree(fElev, cloest_sweeps.m_phi[0]);
            fP_Pkp1 = fnMinusDegree(fElev, cloest_sweeps.m_phi[1]);
            fVal    = (1/fDp) * (fP_Pk * fZe_R_T[1] - fP_Pkp1 * fZe_R_T[0]);
        }
    }
    else if(cloest_sweeps.m_valid[0] == TRUE  && cloest_sweeps.m_valid[1] == FALSE) fVal = fZe_R_T[0];
    else if(cloest_sweeps.m_valid[0] == FALSE && cloest_sweeps.m_valid[1] == TRUE ) fVal = fZe_R_T[1];
    else return RDR_DF_BAD_VALUE_F;

    if(iYesDbz == TRUE)
        return fnZeToDbzF(fVal);
    else
        return fVal;
}

static float fnCappi_at_h_cart(STD_RADAR *pStd, float fHeightToRadarKm, float fPointX, float fPointY, float fGridKm, int iCappiKind, int iYesCross, int iYesDbz, char* szFieldName, STD_AZIMUTH_TBL **ppTable)
{
    int             iSweepIdx       = 0;
    int             iRayIdx         = 0;
    int             iFieldIdx       = 0;
    float           fVal            = 0.0f;
    float           fGridM          = 0.0f;
    float           fHeightM        = 0.0f;
    float           fElev           = 0.0f;
    float           fAzim           = 0.0f;
    float           fSlantRangeM    = 0.0f;
    float           fElevLimit      = 0.0f;
    float           fAzimLimit      = 0.0f;
    CLOEST_SWEEPS   cloest_sweeps;

    if(pStd == NULL || szFieldName == NULL || ppTable == NULL)
        return RDR_DF_BAD_VALUE_F;

    if(iYesCross == TRUE)
    {
        fElevLimit = RDR_DF_CROSS_ELEV_LIMIT;
        fAzimLimit = RDR_DF_CROSS_AZIM_LIMIT;
    }
    else
    {
        fElevLimit = RDR_DF_ELEV_LIMIT;
        fAzimLimit = RDR_DF_AZIM_LIMIT;
    }

    fGridM   = fGridKm * 1000.;
    fHeightM = fHeightToRadarKm * 1000.;

    cloest_sweeps = fnInitCloestSweep();

    fSlantRangeM = fnGetSlantRange(fPointX, fPointY, fHeightM, fGridM);
    fElev        = fnGetElevation(fSlantRangeM, fHeightM);
    fAzim        = fnGetAzimuth(fPointX, fPointY);

    if((iFieldIdx = fnGetFieldIdxRay(pStd->m_ppSweep[0]->m_ppRay[0], szFieldName)) < 0)
        return RDR_DF_BAD_VALUE_F;

    cloest_sweeps = fnGetCloestToSweeps(pStd, fElev, fElevLimit);

    for(iSweepIdx = 0; iSweepIdx < 2; iSweepIdx++)
    {
        cloest_sweeps.m_azims[iSweepIdx] 
        = fnGetClosestToAzims(cloest_sweeps.m_sweep[iSweepIdx], fAzim, fAzimLimit, 
                              ppTable[cloest_sweeps.m_swIdx[iSweepIdx]]);

        for(iRayIdx = 0; iRayIdx < 2; iRayIdx++)
        {
            cloest_sweeps.m_azims[iSweepIdx].m_values[iRayIdx]
            = fnGetCloestToBins(pStd, 
                                cloest_sweeps.m_azims[iSweepIdx].m_ray[iRayIdx],
                                iFieldIdx,
                                fSlantRangeM);
        }
    }

    fVal = fnCalMohrCappiValue(cloest_sweeps, fAzim, fElev, fSlantRangeM, iCappiKind, iYesDbz);

    return fVal;
}

static CAPPI_LOC fnGetSlantrAndElev(float fGrangeKm, float fHeightToRadarKm)
{
    double      dRe         = (RDR_DF_KMA_MAP_RE*4.0/3.0);
    double      dElev       = 0.0;
    double      dSlant_r    = 0.0;
    double      dSlant_r_2  = 0.0;
    CAPPI_LOC   cappi_loc   = { 0.0f, 0.0f };

    if(fabs(fGrangeKm - 0.0f) < RDR_DF_ERR_RANGE_F)
        return cappi_loc;

    fHeightToRadarKm += dRe;

    dSlant_r_2  = pow(dRe, 2.0) + pow(fHeightToRadarKm, 2.0) 
                  - (2*dRe*fHeightToRadarKm*cos(fGrangeKm/dRe));
    dSlant_r    = sqrt(dSlant_r_2);

    dElev       = acos((pow(dRe, 2.0) + dSlant_r_2 - pow(fHeightToRadarKm, 2.0)) / (2*dRe*dSlant_r));
    dElev       *= 180.0/RDR_DF_PI_DFS;
    dElev       -= 90.0;

    cappi_loc.m_fElev   = dElev;
    cappi_loc.m_fSrange = dSlant_r;

    return cappi_loc;
}

static CAPPI_LOC* fnMakeCappiLoc(STD_RAY *pRay, float fHeightToRadarKm)
{
    CAPPI_LOC   *pCappiLoc      = NULL;
    int         iBinIdx         = 0;
    int         iBinNum         = 0;
    float       fStartRangeKm   = 0.0f;
    float       fGateSizeKm     = 0.0f;
    float       fGrangeKm       = 0.0f;

    if(pRay == NULL)
        return NULL;

    iBinNum       = pRay->m_ppField[0]->m_iMaxBin;
    fStartRangeKm = pRay->m_hdr.m_iStartRangeKm + pRay->m_hdr.m_iStartRangeMeter/1000.;
    fGateSizeKm   = pRay->m_hdr.m_iBinSpacing/1000.;

    pCappiLoc = (CAPPI_LOC *)calloc(iBinNum, sizeof(CAPPI_LOC));
    if(pCappiLoc == NULL)
        return NULL;

    for(iBinIdx = 0; iBinIdx < iBinNum; iBinIdx++)
    {
        fGrangeKm = fStartRangeKm + (iBinIdx * fGateSizeKm);
        pCappiLoc[iBinIdx] = fnGetSlantrAndElev(fGrangeKm, fHeightToRadarKm);
    }

    return pCappiLoc;
}

static int fnGetSweepIndex(STD_RADAR *pStd, float fElev)
{
    int         iResult         = -1;
    int         iSweepIdx       = 0;
    float       fDeltaAngle     = 91.0f;
    float       fCheckAngle     = 0.0f;

    if(pStd == NULL)
        return -1;

    fDeltaAngle = 91.f;
    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        fCheckAngle = fnDiffDegree(pStd->m_ppSweep[iSweepIdx]->m_ppRay[0]->m_hdr.m_fFixedAngle, fElev);

        if(fCheckAngle <= fDeltaAngle)
        {
            fDeltaAngle = fCheckAngle;
            iResult     = iSweepIdx;
        }
    }

    return iResult;
}

/* ================================================================================  */
// Function

float* fnCreateCappiMohr(STD_RADAR *pStd, float fCappiHeightKm, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, int iCappiKind, int iYesCross, char* szFieldName, STD_AZIMUTH_TBL **ppTable)
{
#define FN_CREATE_CAPPI_MOHR_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG);

    STD_SWEEP   *pSweep             = NULL;     // VARIABLE
    STD_RAY     *pRay               = NULL;     // VARIABLE
    float       *pCappi             = NULL;
    float       fHeightToRadarKm    = 0.0f;
    float       fPointX             = 0.0f;
    float       fPointY             = 0.0f;
    int         iFieldIdx           = 0;
    int         iXIdx               = 0;
    int         iYIdx               = 0;
    int         iCappiIdx           = 0;
    int         iYesDbz             = 0;

    if(pStd == NULL || szFieldName == NULL || ppTable == NULL)
        return NULL;

    if(iXdim <= 0 || iYdim <= 0)
        return NULL;

    if((pSweep = pStd->m_ppSweep[0]) == NULL || pSweep->m_ppRay == NULL)
    {   FN_CREATE_CAPPI_MOHR_ERROR("sweep is null or m_ppRay is null") return NULL; }

    pRay = pSweep->m_ppRay[0];
    if((iFieldIdx = fnGetFieldIdxRay(pRay, szFieldName)) == -1)
    {   FN_CREATE_CAPPI_MOHR_ERROR("no moment") return NULL; }

    pCappi = (float *)calloc(iXdim*iYdim, sizeof(float));
    if(pCappi == NULL)
        return NULL;

    fHeightToRadarKm = fCappiHeightKm - (float)(pStd->m_hdr.m_iAnteHeight/1000.f);

    if(!strcmp(szFieldName, "DZ"))
        iYesDbz = TRUE;
    else if(!strcmp(szFieldName, "CZ"))
        iYesDbz = TRUE;

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            iCappiIdx = (iYIdx*iXdim)+iXIdx;
            fPointY = iYIdx - (iYdim-1)/2.;
            fPointX = iXIdx - (iXdim-1)/2.;

            pCappi[iCappiIdx] = fnCappi_at_h_cart(pStd, fHeightToRadarKm, fPointX, fPointY, 
                                                  fGridKm, iCappiKind, iYesCross, iYesDbz, 
                                                  szFieldName, ppTable);
        }
    }

    return pCappi;
}

float* fnCreateCappiReal(STD_RADAR *pStd, float fCappiHeightKm, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, char* szFieldName, STD_AZIMUTH_TBL **ppTable)
{
#define FN_CREATE_CAPPI_REAL_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pCappi    != NULL)  { free(pCappi); } \
    if(pCappiLoc != NULL)  { free(pCappiLoc); } 

    STD_SWEEP   *pSweep             = NULL;                                 // VARIABLE
    STD_RAY     *pRay               = NULL;                                 // VARIABLE
    CAPPI_LOC   *pCappiLoc          = NULL;                                 // VARIABLE
    float       *pCappi             = NULL;                                 // VARIABLE
    float       fRangeKm            = 0.0f;                                 // VARIABLE
    float       fAzim               = 0.0f, fVal                = 0.0f;     // VARIABLE
    float       fRes                = 0.0f, fStartRangeKm       = 0.0f;     // VARIABLE
    int         iXIdx               = 0,    iYIdx               = 0;
    int         iCappiIdx           = 0,    iSweepIdx           = 0;
    int         iRayIdx             = 0,    iFieldIdx           = 0;
    int         iBinIdx             = 0;

    if(pStd == NULL || ppTable == NULL)
    {   FN_CREATE_CAPPI_REAL_ERROR("Invalid arg") return NULL; }

    pRay = pStd->m_ppSweep[0]->m_ppRay[0];
    if((iFieldIdx = fnGetFieldIdxRay(pRay, szFieldName)) == -1)
    {   FN_CREATE_CAPPI_REAL_ERROR("no moment") return NULL; }

    pCappi = (float *)calloc(iXdim*iYdim, sizeof(float));
    if(pCappi == NULL)
    {   FN_CREATE_CAPPI_REAL_ERROR("calloc fail") return NULL; }

    for(iCappiIdx = 0; iCappiIdx < iXdim*iYdim; iCappiIdx++)
        pCappi[iCappiIdx] = RDR_DF_BAD_VALUE_F;

    fStartRangeKm = pRay->m_hdr.m_iStartRangeKm + pRay->m_hdr.m_iStartRangeMeter/1000.0f;

    pCappiLoc = fnMakeCappiLoc(pRay, fCappiHeightKm);
    if(pCappiLoc == NULL)
    {   FN_CREATE_CAPPI_REAL_ERROR("fnMakeCappiLoc fail") return NULL; }

    for(iYIdx = -iYdim/2; iYIdx < iYdim/2; iYIdx++)
    {
        for(iXIdx = -iXdim/2; iXIdx < iXdim/2; iXIdx++)
        {
            iCappiIdx = (iYIdx + iYdim/2)*iYdim + (iXdim - 1) - (iXIdx + iXdim/2);
            fAzim     = fnCalcAzimuthToXY(iYIdx, iXIdx);

            fRangeKm = (float)sqrt((double)(iXIdx*iXIdx) + (double)(iYIdx*iYIdx));
            if(iYdim < iXdim) fRangeKm *= fMaxRangeKm/(.5*iYdim);
            else              fRangeKm *= fMaxRangeKm/(.5*iXdim);

            if(fRangeKm > fMaxRangeKm) fVal = RDR_DF_BADVAL;
            else 
            {
                iBinIdx = (int)((fRangeKm - fStartRangeKm)*1000. / pRay->m_hdr.m_iBinSpacing);
                if((iSweepIdx = fnGetSweepIndex(pStd, pCappiLoc[iBinIdx].m_fElev)) == -1)
                {    pCappi[iCappiIdx] = RDR_DF_BAD_VALUE_F; continue; }

                pSweep = pStd->m_ppSweep[iSweepIdx];
                fRes = 360.0/pSweep->m_iMaxRay;

                if((iRayIdx = fnSearchRayToAzim(pSweep, fRes, fAzim, ppTable[iSweepIdx])) == -1)
                {    pCappi[iCappiIdx] = RDR_DF_BAD_VALUE_F; continue; }
                pRay = pSweep->m_ppRay[iRayIdx];

                if(fnDiffDegree(pCappiLoc[iBinIdx].m_fElev, pRay->m_hdr.m_fFixedAngle) 
                   > pStd->m_hdr.m_fBeamWidthV/2.0)
                {    pCappi[iCappiIdx] = RDR_DF_BAD_VALUE_F; continue; }

                if(fnDiffDegree(fAzim, pRay->m_hdr.m_fAzimuth) > pStd->m_hdr.m_fBeamWidthH)
                {    pCappi[iCappiIdx] = RDR_DF_BAD_VALUE_F; continue; }

                fVal = fnGetBinValueToRay(pRay, iFieldIdx, pCappiLoc[iBinIdx].m_fSrange, 
                                          pStd->m_hdr.m_iNoDataValue);
            }

            if((fabs(fVal - RDR_DF_BADVAL    ) < RDR_DF_ERR_RANGE_F) || 
               (fabs(fVal - RDR_DF_NOTFOUND_V) < RDR_DF_ERR_RANGE_F) || 
               (fabs(fVal - RDR_DF_NOTFOUND_H) < RDR_DF_ERR_RANGE_F))
                pCappi[iCappiIdx] = RDR_DF_BAD_VALUE_F;
            else
                pCappi[iCappiIdx] = fVal;
        }
    }

    free(pCappiLoc);

    return pCappi;
}

/* ================================================================================ */



