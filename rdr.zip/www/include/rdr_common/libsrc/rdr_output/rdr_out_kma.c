/* ================================================================================ */
//
// Radar Comp Kma Output Format & Output Function
//
// 2016.10.31 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function

static float fnCalcRadarValue(float** pData, int iDataXdim, int iDataYdim, int iDiff_x, int iDiff_y, int iXpoint, int iYpoint, float fXGridScale, float fYGridScale)
{
    float   fValue  = 0.0;
    double  dCalcY  = 0.0;
    double  dCalcX  = 0.0;
    int     iCalcY  = 0;
    int     iCalcX  = 0;

    dCalcX  = ((double)(iXpoint - (double)iDiff_x) / (double)fXGridScale);
    dCalcY  = ((double)(iYpoint - (double)iDiff_y) / (double)fYGridScale);

    iCalcX = (int)dCalcX;
    iCalcY = (int)dCalcY;

    if((iCalcX >= 0 && iCalcX < iDataXdim) && (iCalcY >= 0 && iCalcY < iDataYdim))
    {
        fValue = pData[iCalcY][iCalcX];
    }
    else
    {
        fValue = RDR_DF_OUT_BOUND_F;
    }

    return fValue;
}

/* ================================================================================ */
// Function

int fnWriteStdProductKmaComp240(STD_PRODUCT* pStdProduct, char* szProduct, char* szFieldName, char* szOutFile)
{
    gzFile  pFp                                 = NULL;
    float   **ppTemp                            = NULL;
    char    **ppData                            = NULL;
    char    buffer[RDR_DF_COMP_240_1KM_XDIM]    = { 0, };
    float   fData                               = 0.0;
    int     iCompYdim                           = 0;
    int     iCompXdim                           = 0;
    int     iYIdx                               = 0;
    int     iXIdx                               = 0;
    float   fXGridScale                         = 0.0;
    float   fYGridScale                         = 0.0;
    char    szTempFile[STR_LENGTH_MAX]          = "";

    if(pStdProduct == NULL || szProduct == NULL || szFieldName == NULL || szOutFile == NULL)
        return FALSE;

    iCompYdim = (int)pStdProduct->m_product_hdr.m_lYsize;
    iCompXdim = (int)pStdProduct->m_product_hdr.m_lXsize;
    if((ppTemp = fnGetStdProductDataByIdx(pStdProduct, szProduct, 0, szFieldName)) == NULL)
        return FALSE;

    if((ppData = fnMakeMatrix2D_C(RDR_DF_COMP_240_1KM_YDIM, RDR_DF_COMP_240_1KM_XDIM)) == NULL)
    {
        fnFreeMatrix2D((void **)ppTemp, iCompYdim);
        return FALSE;
    }

    fXGridScale = pStdProduct->m_product_hdr.m_dXscale/RDR_DF_COMP_240_1KM_GRID;
    fYGridScale = pStdProduct->m_product_hdr.m_dYscale/RDR_DF_COMP_240_1KM_GRID;

    for(iYIdx = 0; iYIdx < RDR_DF_COMP_240_1KM_YDIM; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < RDR_DF_COMP_240_1KM_XDIM; iXIdx++)
        {
            fData = fnCalcRadarValue(ppTemp, iCompXdim, iCompYdim, 0, 0,
                                     iXIdx, iYIdx, fXGridScale, fYGridScale);

            if(fabs(fData - RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
                ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_C;
            else if(fabs(fData - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_C;
            else
                ppData[iYIdx][iXIdx] = (char)fData;
        }
    }

    snprintf(szTempFile, sizeof(szTempFile), "%s.tmp", szOutFile);

    if((pFp = gzopen(szTempFile, "wb")) == NULL)
    {
        fnFreeMatrix2D((void **)ppTemp, iCompYdim);
        fnFreeMatrix2D((void **)ppData, RDR_DF_COMP_240_1KM_YDIM);
        return FALSE;
    }

    for(iYIdx = RDR_DF_COMP_240_1KM_YDIM-1; iYIdx >= 0; iYIdx--)
    {
        for(iXIdx = 0; iXIdx < RDR_DF_COMP_240_1KM_XDIM; iXIdx++)
        {
            if(!strcmp(szProduct, "VIL"))
                buffer[iXIdx] = ppData[iYIdx][iXIdx]+0.6;
            else
                buffer[iXIdx] = ppData[iYIdx][iXIdx];
        }
        gzwrite(pFp, buffer, sizeof(char)*RDR_DF_COMP_240_1KM_XDIM);
    }

    gzclose(pFp);

    rename(szTempFile, szOutFile);

    fnFreeMatrix2D((void **)ppTemp, iCompYdim);
    fnFreeMatrix2D((void **)ppData, RDR_DF_COMP_240_1KM_YDIM);

    return TRUE;
}

int fnWriteStdProductKmaComp480(STD_PRODUCT* pStdProduct, char* szProduct, char* szFieldName, char* szOutFile)
{
    gzFile          pFp                             = NULL;
    float           **ppTemp                        = NULL;
    float           **ppData                        = NULL;
    unsigned char   **ppBound                       = NULL;
    float           fData                           = 0.0;
    int             iCompYdim                       = 0;
    int             iCompXdim                       = 0;
    int             iYIdx                           = 0;
    int             iXIdx                           = 0;
    float           fXGridScale                     = 0.0;
    float           fYGridScale                     = 0.0;
    char            szTempFile[STR_LENGTH_MAX]      = "";

    if(pStdProduct == NULL || szProduct == NULL || szFieldName == NULL || szOutFile == NULL)
        return FALSE;

    iCompYdim = (int)pStdProduct->m_product_hdr.m_lYsize;
    iCompXdim = (int)pStdProduct->m_product_hdr.m_lXsize;
    if((ppTemp = fnGetStdProductDataByIdx(pStdProduct, szProduct, 0, szFieldName)) == NULL)
        return FALSE;

    if((ppData = fnMakeMatrix2D_F(RDR_DF_COMP_480_3KM_YDIM, RDR_DF_COMP_480_3KM_XDIM)) == NULL)
    {
        fnFreeMatrix2D((void **)ppTemp, iCompYdim);
        return FALSE;
    }

    if((ppBound = fnMakeMatrix2D_UC(RDR_DF_COMP_480_3KM_YDIM, RDR_DF_COMP_480_3KM_XDIM)) == NULL)
    {
        fnFreeMatrix2D((void **)ppTemp, iCompYdim);
        fnFreeMatrix2D((void **)ppData, RDR_DF_COMP_480_3KM_YDIM);
        return FALSE;
    }

    fXGridScale = pStdProduct->m_product_hdr.m_dXscale/RDR_DF_COMP_480_3KM_GRID;
    fYGridScale = pStdProduct->m_product_hdr.m_dYscale/RDR_DF_COMP_480_3KM_GRID;

    for(iYIdx = 0; iYIdx < RDR_DF_COMP_480_3KM_YDIM; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < RDR_DF_COMP_480_3KM_XDIM; iXIdx++)
        {
            fData = fnCalcRadarValue(ppTemp, iCompXdim, iCompYdim, 0, 0,
                                     iXIdx, iYIdx, fXGridScale, fYGridScale);

            if(fabs(fData - RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
            {
                ppData[iYIdx][iXIdx]  = fData;
                ppBound[iYIdx][iXIdx] = RDR_EN_OUT_BOUND;
            }
            else if(fabs(fData - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
            {
                ppData[iYIdx][iXIdx]  = fData;
                ppBound[iYIdx][iXIdx] = RDR_EN_IN_BOUND;
            }
            else
            {
                if(!strcmp(szFieldName, "CZ") || !strcmp(szFieldName, "DZ"))
                {
                    ppData[iYIdx][iXIdx] = (float)fnDbzToRainF((double)fData,
                                                               RDR_DF_DFLT_ZR_A,
                                                               RDR_DF_DFLT_ZR_B);
                }
                else
                    ppData[iYIdx][iXIdx] = fData;

                ppBound[iYIdx][iXIdx] = RDR_EN_IN_BOUND;
            }
        }
    }

    snprintf(szTempFile, sizeof(szTempFile), "%s.tmp", szOutFile);

    if((pFp = gzopen(szTempFile, "wb")) == NULL)
    {
        fnFreeMatrix2D((void **)ppTemp,  iCompYdim);
        fnFreeMatrix2D((void **)ppData,  RDR_DF_COMP_480_3KM_YDIM);
        fnFreeMatrix2D((void **)ppBound, RDR_DF_COMP_480_3KM_YDIM);
        return FALSE;
    }

    for(iYIdx = RDR_DF_COMP_480_3KM_YDIM-1; iYIdx >= 0; iYIdx--)
        gzwrite(pFp, ppData[iYIdx], sizeof(float)*RDR_DF_COMP_480_3KM_XDIM);

    for(iYIdx = RDR_DF_COMP_480_3KM_YDIM-1; iYIdx >= 0; iYIdx--)
        gzwrite(pFp, ppBound[iYIdx], sizeof(unsigned char)*RDR_DF_COMP_480_3KM_XDIM);

    gzclose(pFp);

    rename(szTempFile, szOutFile);

    fnFreeMatrix2D((void **)ppTemp,  iCompYdim);
    fnFreeMatrix2D((void **)ppData,  RDR_DF_COMP_480_3KM_YDIM);
    fnFreeMatrix2D((void **)ppBound, RDR_DF_COMP_480_3KM_YDIM);

    return TRUE;
}

int fnWriteStdProductKmaCompKCJ(STD_PRODUCT* pStdProduct, char* szProduct, char* szFieldName, char* szOutFile)
{
    gzFile          pFp                             = NULL;
    float           **ppTemp                        = NULL;
    short           **ppData                        = NULL;
    float           fData                           = 0.0;
    float           fRain                           = 0.0;
    int             iCompYdim                       = 0;
    int             iCompXdim                       = 0;
    int             iYIdx                           = 0;
    int             iXIdx                           = 0;
    float           fXGridScale                     = 0.0;
    float           fYGridScale                     = 0.0;
    char            szTempFile[STR_LENGTH_MAX]      = "";

    if(pStdProduct == NULL || szProduct == NULL || szFieldName == NULL || szOutFile == NULL)
        return FALSE;

    iCompYdim = (int)pStdProduct->m_product_hdr.m_lYsize;
    iCompXdim = (int)pStdProduct->m_product_hdr.m_lXsize;
    if((ppTemp = fnGetStdProductDataByIdx(pStdProduct, szProduct, 0, szFieldName)) == NULL)
        return FALSE;

    if((ppData = fnMakeMatrix2D_S(RDR_DF_COMP_KCJ_3KM_YDIM, RDR_DF_COMP_KCJ_3KM_XDIM)) == NULL)
    {
        fnFreeMatrix2D((void **)ppTemp, iCompYdim);
        return FALSE;
    }

    fXGridScale = pStdProduct->m_product_hdr.m_dXscale/RDR_DF_COMP_KCJ_3KM_GRID;
    fYGridScale = pStdProduct->m_product_hdr.m_dYscale/RDR_DF_COMP_KCJ_3KM_GRID;

    for(iYIdx = 0; iYIdx < RDR_DF_COMP_KCJ_3KM_YDIM; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < RDR_DF_COMP_KCJ_3KM_XDIM; iXIdx++)
        {
            fData = fnCalcRadarValue(ppTemp, iCompXdim, iCompYdim, 0, 0,
                                     iXIdx, iYIdx, fXGridScale, fYGridScale);

            if(fabs(fData - RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
                ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_S;
            else if(fabs(fData - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_S;
            else
            {
                if(!strcmp(szFieldName, "CZ") || !strcmp(szFieldName, "DZ"))
                {
                    fRain = (float)fnDbzToRainF((double)fData, RDR_DF_DFLT_ZR_A, RDR_DF_DFLT_ZR_B);
                    ppData[iYIdx][iXIdx] = (short)(fRain * RDR_DF_KMA_SHORT_SCALE + 0.5);
                }
                else
                    ppData[iYIdx][iXIdx] = (short)(fData * RDR_DF_KMA_SHORT_SCALE + 0.5);
            }

            if(fnIsLittleEndian() == TRUE)
                fnSwap2Byte(&ppData[iYIdx][iXIdx]);
        }
    }

    snprintf(szTempFile, sizeof(szTempFile), "%s.tmp", szOutFile);

    if((pFp = gzopen(szTempFile, "wb")) == NULL)
    {
        fnFreeMatrix2D((void **)ppTemp,  iCompYdim);
        fnFreeMatrix2D((void **)ppData,  RDR_DF_COMP_KCJ_3KM_YDIM);
        return FALSE;
    }

    for(iYIdx = RDR_DF_COMP_KCJ_3KM_YDIM-1; iYIdx >= 0; iYIdx--)
        gzwrite(pFp, ppData[iYIdx], sizeof(short)*RDR_DF_COMP_KCJ_3KM_XDIM);

    gzclose(pFp);

    rename(szTempFile, szOutFile);

    fnFreeMatrix2D((void **)ppTemp,  iCompYdim);
    fnFreeMatrix2D((void **)ppData,  RDR_DF_COMP_KCJ_3KM_YDIM);

    return TRUE;
}

int fnWriteStdProductKmaComp3D(STD_PRODUCT* pStdProduct, char* szProduct, char* szFieldName, int iCappiCnt, char* szOutFile)
{
    gzFile          pFp                         = NULL;
    int             iCappiIdx                   = 0;
    float           **ppTemp                    = NULL;
    char            **ppData                    = NULL;
    unsigned char   **ppBound                   = NULL;
    float           fData                       = 0.0;
    int             iCompYdim                   = 0;
    int             iCompXdim                   = 0;
    int             iYIdx                       = 0;
    int             iXIdx                       = 0;
    float           fXGridScale                 = 0.0;
    float           fYGridScale                 = 0.0;
    char            szTempFile[STR_LENGTH_MAX]  = "";

    if(pStdProduct == NULL || szProduct == NULL || szFieldName == NULL || szOutFile == NULL)
        return FALSE;

    snprintf(szTempFile, sizeof(szTempFile), "%s.tmp", szOutFile);

    if((pFp = gzopen(szTempFile, "wb")) == NULL)
        return FALSE;

    iCompYdim = (int)pStdProduct->m_product_hdr.m_lYsize;
    iCompXdim = (int)pStdProduct->m_product_hdr.m_lXsize;

    fXGridScale = pStdProduct->m_product_hdr.m_dXscale/RDR_DF_COMP_240_1KM_GRID;
    fYGridScale = pStdProduct->m_product_hdr.m_dYscale/RDR_DF_COMP_240_1KM_GRID;

    ppData = NULL;
    if((ppData = fnMakeMatrix2D_C(RDR_DF_COMP_240_1KM_YDIM, RDR_DF_COMP_240_1KM_XDIM)) == NULL)
    {
        gzclose(pFp);
        return FALSE;
    }

    if((ppBound = fnMakeMatrix2D_UC(RDR_DF_COMP_240_1KM_YDIM, RDR_DF_COMP_240_1KM_XDIM)) == NULL)
    {
        fnFreeMatrix2D((void **)ppData, RDR_DF_COMP_240_1KM_YDIM);
        gzclose(pFp);
        return FALSE;
    }

    for(iCappiIdx = 0; iCappiIdx < iCappiCnt; iCappiIdx++)
    {
        ppTemp = NULL;
        if((ppTemp = fnGetStdProductDataByIdx(pStdProduct, szProduct, iCappiIdx, szFieldName)) == NULL)
        {
            fnFreeMatrix2D((void **)ppData,  RDR_DF_COMP_240_1KM_YDIM);
            fnFreeMatrix2D((void **)ppBound, RDR_DF_COMP_240_1KM_YDIM);
            gzclose(pFp);
            return FALSE;
        }

        for(iYIdx = 0; iYIdx < RDR_DF_COMP_240_1KM_YDIM; iYIdx++)
        {
            for(iXIdx = 0; iXIdx < RDR_DF_COMP_240_1KM_XDIM; iXIdx++)
            {
                fData = fnCalcRadarValue(ppTemp, iCompXdim, iCompYdim, 0, 0,
                                         iXIdx, iYIdx, fXGridScale, fYGridScale);

                if(fabs(fData - RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
                {
                    ppData[iYIdx][iXIdx]    = 0;
                    ppBound[iYIdx][iXIdx]   = RDR_EN_OUT_BOUND;
                }
                else if(fabs(fData - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
                {
                    ppData[iYIdx][iXIdx]    = 0;
                    ppData[iYIdx][iXIdx]    = RDR_DF_BAD_VALUE_C;
                    ppBound[iYIdx][iXIdx]   = RDR_EN_IN_BOUND;
                }
                else
                {
                    ppData[iYIdx][iXIdx]    = (char)fData;
                    ppBound[iYIdx][iXIdx]   = RDR_EN_IN_BOUND;
                }
            }
        }

        for(iYIdx = RDR_DF_COMP_240_1KM_YDIM-1; iYIdx >= 0; iYIdx--)
            gzwrite(pFp, ppData[iYIdx], sizeof(char)*RDR_DF_COMP_240_1KM_XDIM);

        fnFreeMatrix2D((void **)ppTemp, iCompYdim);
    }

    for(iYIdx = RDR_DF_COMP_240_1KM_YDIM-1; iYIdx >= 0; iYIdx--)
        gzwrite(pFp, ppBound[iYIdx], sizeof(unsigned char)*RDR_DF_COMP_240_1KM_XDIM);

    gzclose(pFp);

    rename(szTempFile, szOutFile);

    fnFreeMatrix2D((void **)ppData,  RDR_DF_COMP_240_1KM_YDIM);
    fnFreeMatrix2D((void **)ppBound, RDR_DF_COMP_240_1KM_YDIM);

    return TRUE;
}


