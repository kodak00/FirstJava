/* ================================================================================ */
//
// Radar HDF Output Format & Output Function
//
// 2016.08.19 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"

#include <hdf5.h>
#include <hdf5_hl.h>

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function

static void fnFreeHdfDataset(HDF_PRODUCT_DATASET **ppHdfDataset, int iMaxDataset, int iYdim)
{
    int                 iDatasetIdx         = 0;
    int                 iFieldIdx           = 0;
    int                 iMaxField           = 0;

    if(ppHdfDataset != NULL)
    {
        for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
        {
            if(ppHdfDataset[iDatasetIdx] != NULL)
            {
                if(ppHdfDataset[iDatasetIdx]->m_ppProductData != NULL)
                {
                    iMaxField = ppHdfDataset[iDatasetIdx]->m_iMaxField;
                    for(iFieldIdx = 0; iFieldIdx < iMaxField; iFieldIdx++)
                    {
                        if(ppHdfDataset[iDatasetIdx]->m_ppProductData[iFieldIdx] != NULL)
                        {
                            if(ppHdfDataset[iDatasetIdx]->
                               m_ppProductData[iFieldIdx]->m_ppData_c != NULL)
                            {
                                fnFreeMatrix2D((void **)ppHdfDataset[iDatasetIdx]->
                                               m_ppProductData[iFieldIdx]->m_ppData_c, iYdim);
                            }
                            if(ppHdfDataset[iDatasetIdx]->
                               m_ppProductData[iFieldIdx]->m_ppData_s != NULL)
                            {
                                fnFreeMatrix2D((void **)ppHdfDataset[iDatasetIdx]->
                                               m_ppProductData[iFieldIdx]->m_ppData_s, iYdim);
                            }
                            if(ppHdfDataset[iDatasetIdx]->
                               m_ppProductData[iFieldIdx]->m_ppData_f != NULL)
                            {
                                fnFreeMatrix2D((void **)ppHdfDataset[iDatasetIdx]->
                                               m_ppProductData[iFieldIdx]->m_ppData_f, iYdim);
                            }
                            free(ppHdfDataset[iDatasetIdx]->m_ppProductData[iFieldIdx]);
                        }
                    }
                    free(ppHdfDataset[iDatasetIdx]->m_ppProductData);
                }
                free(ppHdfDataset[iDatasetIdx]);
            }
        }
        free(ppHdfDataset);
    }
}

static HDF_PRODUCT_DATASET** fnInitHdfDataset(char *szProduct, int iMaxDataset, int iMaxField)
{
    HDF_PRODUCT_DATASET **ppHdfDataset = NULL;
    int                 iDatasetIdx     = 0;
    int                 iFieldIdx       = 0;

    if(szProduct == NULL || iMaxDataset <= 0 || iMaxField <= 0)
        return NULL;

    ppHdfDataset = (HDF_PRODUCT_DATASET **)calloc(iMaxDataset, sizeof(HDF_PRODUCT_DATASET *));
    if(ppHdfDataset == NULL)
        return NULL;

    for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
    {
        ppHdfDataset[iDatasetIdx] 
        = (HDF_PRODUCT_DATASET *)calloc(1, sizeof(HDF_PRODUCT_DATASET));
        if(ppHdfDataset[iDatasetIdx] == NULL)
        {
            fnFreeHdfDataset(ppHdfDataset, iMaxDataset, 0);
            return NULL;
        }
        snprintf(ppHdfDataset[iDatasetIdx]->m_what.m_szProduct,
                 sizeof(ppHdfDataset[iDatasetIdx]->m_what.m_szProduct), "%s", szProduct);
        ppHdfDataset[iDatasetIdx]->m_iMaxField = iMaxField;

        ppHdfDataset[iDatasetIdx]->m_ppProductData 
        = (HDF_PRODUCT_DATA **)calloc(iMaxField, sizeof(HDF_PRODUCT_DATA *));
        if(ppHdfDataset[iDatasetIdx]->m_ppProductData == NULL)
        {
            fnFreeHdfDataset(ppHdfDataset, iMaxDataset, 0);
            return NULL;
        }
        for(iFieldIdx = 0; iFieldIdx < iMaxField; iFieldIdx++)
        {
            ppHdfDataset[iDatasetIdx]->m_ppProductData[iFieldIdx]
            = (HDF_PRODUCT_DATA *)calloc(1, sizeof(HDF_PRODUCT_DATA));
            if(ppHdfDataset[iDatasetIdx]->m_ppProductData[iFieldIdx] == NULL)
            {
                fnFreeHdfDataset(ppHdfDataset, iMaxDataset, 0);
                return NULL;
            }
        }
    }

    return ppHdfDataset;
}

static HDF_PRODUCT_DATASET** fnInitHdfDatasetToStdDataset(STD_PRODUCT_DATASET **ppStdDataset, int iMaxDataset)
{
    HDF_PRODUCT_DATASET **ppHdfDataset = NULL;
    int                 iDatasetIdx     = 0;
    int                 iFieldIdx       = 0;

    if(ppStdDataset == NULL || iMaxDataset <= 0)
        return NULL;

    ppHdfDataset = (HDF_PRODUCT_DATASET **)calloc(iMaxDataset, sizeof(HDF_PRODUCT_DATASET *));
    if(ppHdfDataset == NULL)
        return NULL;

    for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
    {
        ppHdfDataset[iDatasetIdx] 
        = (HDF_PRODUCT_DATASET *)calloc(1, sizeof(HDF_PRODUCT_DATASET));
        if(ppHdfDataset[iDatasetIdx] == NULL)
        {
            fnFreeHdfDataset(ppHdfDataset, iMaxDataset, 0);
            return NULL;
        }
        ppHdfDataset[iDatasetIdx]->m_iMaxField = ppStdDataset[iDatasetIdx]->m_iMaxField;

        ppHdfDataset[iDatasetIdx]->m_ppProductData 
        = (HDF_PRODUCT_DATA **)calloc(ppHdfDataset[iDatasetIdx]->m_iMaxField, 
                                      sizeof(HDF_PRODUCT_DATA *));
        if(ppHdfDataset[iDatasetIdx]->m_ppProductData == NULL)
        {
            fnFreeHdfDataset(ppHdfDataset, iMaxDataset, 0);
            return NULL;
        }
        for(iFieldIdx = 0; iFieldIdx < ppHdfDataset[iDatasetIdx]->m_iMaxField; iFieldIdx++)
        {
            ppHdfDataset[iDatasetIdx]->m_ppProductData[iFieldIdx]
            = (HDF_PRODUCT_DATA *)calloc(1, sizeof(HDF_PRODUCT_DATA));
            if(ppHdfDataset[iDatasetIdx]->m_ppProductData[iFieldIdx] == NULL)
            {
                fnFreeHdfDataset(ppHdfDataset, iMaxDataset, 0);
                return NULL;
            }
        }
    }

    return ppHdfDataset;
}

static int fnHdfCreateAttr(hid_t hGroup, char* szName, hid_t hMemType, void *pData, int iDataLen) 
{
    hid_t       hAttr       = -1;
    hid_t       hStrType    = -1;

    if(hGroup < 0 || szName == NULL || pData == NULL)
        return FALSE;

    if(hMemType == H5T_NATIVE_CHAR && iDataLen > 0) // STRING
    {
        if((hStrType = H5Tcopy(H5T_C_S1)) < 0)
            return FALSE;

        if((H5Tset_size(hStrType, strlen(pData)+1) < 0))
        {
            H5Tclose(hStrType);
            return FALSE;
        }

        if((hAttr = H5Acreate1(hGroup, szName, hStrType, H5Screate(H5S_SCALAR), H5P_DEFAULT)) < 0)
        {
            H5Tclose(hStrType);
            return FALSE;
        }
        if(H5Awrite(hAttr, hStrType, pData) < 0)
        {
            H5Tclose(hStrType);
            H5Aclose(hAttr);
            return FALSE;
        }

        H5Tclose(hStrType);
        H5Aclose(hAttr);
    }
    else
    {
        if((hAttr = H5Acreate1(hGroup, szName, hMemType, H5Screate(H5S_SCALAR), H5P_DEFAULT)) < 0)
            return FALSE;

        if(H5Awrite(hAttr, hMemType, pData) < 0)
        {
            H5Aclose(hAttr);
            return FALSE;
        }

        H5Aclose(hAttr);
    }

    return TRUE;
}

static int fnHdfCreateData1D(hid_t hGroup, char* szName, hid_t hMemType, void *pData, int iXdim)
{
    hid_t       hDataspace  = -1;
    hid_t       hData       = -1;
    hid_t       hPlist      = -1;
    hsize_t     dims[1];

    if(hGroup < 0 || szName == NULL || pData == NULL || iXdim <= 0)
        return FALSE;

    dims[0] = iXdim;

    if((hDataspace = H5Screate_simple(1, dims, NULL)) < 0)
        return FALSE;

    if((hPlist = H5Pcreate(H5P_DATASET_CREATE)) < 0)
    {
        H5Sclose(hDataspace);
        return FALSE;
    }

    if(H5Pset_chunk(hPlist, 1, dims) < 0)
    {
        H5Sclose(hDataspace);
        H5Pclose(hPlist); 
        return FALSE;
    }

    if(H5Pset_deflate(hPlist, 6) < 0)
    {
        H5Sclose(hDataspace);
        H5Pclose(hPlist); 
        return FALSE;
    }

    if((hData = H5Dcreate1(hGroup, szName, hMemType, hDataspace, hPlist)) < 0)
    {
        H5Sclose(hDataspace);
        H5Pclose(hPlist); 
        return FALSE;
    }

    if(H5Dwrite(hData, hMemType, H5S_ALL, H5S_ALL, H5P_DEFAULT, pData) < 0)
    {
        H5Sclose(hDataspace);
        H5Pclose(hPlist); 
        H5Dclose(hData);
        return FALSE;
    }

    H5Sclose(hDataspace);
    H5Pclose(hPlist); 
    H5Dclose(hData);

    return TRUE;
}

static int fnHdfCreateData2D(hid_t hGroup, char* szName, hid_t hDataType, void *pData, int iYdim, int iXdim, char *szClass, size_t classSize, char *szVersion, size_t versionSize)
{
    hid_t       hDataspace  = -1;
    hid_t       hData       = -1;
    hid_t       hPlist      = -1;
    hsize_t     dims[2];

    if(hGroup < 0 || szName == NULL || pData == NULL || iXdim <= 0 || iYdim <= 0)
        return FALSE;

    dims[0] = iYdim;
    dims[1] = iXdim;

    if((hDataspace = H5Screate_simple(2, dims, NULL)) < 0)
        return FALSE;

    if((hPlist = H5Pcreate(H5P_DATASET_CREATE)) < 0)
    {
        H5Sclose(hDataspace);
        return FALSE;
    }

    dims[0] = iYdim/10;
    dims[1] = iXdim/10;

    if(H5Pset_chunk(hPlist, 2, dims) < 0)
    {
        H5Sclose(hDataspace);
        H5Pclose(hPlist); 
        return FALSE;
    }

    if(H5Pset_deflate(hPlist, 6) < 0)
    {
        H5Sclose(hDataspace);
        H5Pclose(hPlist); 
        return FALSE;
    }

    if((hData = H5Dcreate1(hGroup, szName, hDataType, hDataspace, hPlist)) < 0)
    {
        H5Sclose(hDataspace);
        H5Pclose(hPlist); 
        return FALSE;
    }

    if(H5Dwrite(hData, hDataType, H5S_ALL, H5S_ALL, H5P_DEFAULT, pData) < 0)
    {
        H5Sclose(hDataspace);
        H5Pclose(hPlist); 
        H5Dclose(hData);
        return FALSE;
    }

    fnHdfCreateAttr(hData, "CLASS", H5T_NATIVE_CHAR, szClass, classSize);
    fnHdfCreateAttr(hData, "IMAGE_VERSION", H5T_NATIVE_CHAR, szVersion, versionSize);

    H5Sclose(hDataspace);
    H5Pclose(hPlist); 
    H5Dclose(hData);

    return TRUE;
}

static int fnSaveHdfProductTopWhat(hid_t hRoot, HDF_PRODUCT *pHdfProduct)
{
    hid_t       hWhat  = -1;

    if(hRoot < 0 || pHdfProduct == NULL)
        return FALSE;

    // HDF TOP WHAT
    if((hWhat = H5Gcreate1(hRoot, "what", 0)) < 0)
        return FALSE;

    fnHdfCreateAttr(hWhat, "object",  H5T_NATIVE_CHAR, 
                    pHdfProduct->m_what.m_szObject,  sizeof(pHdfProduct->m_what.m_szObject));
    fnHdfCreateAttr(hWhat, "version", H5T_NATIVE_CHAR, pHdfProduct->m_what.m_szVersion, 
                    sizeof(pHdfProduct->m_what.m_szVersion));
    fnHdfCreateAttr(hWhat, "date",    H5T_NATIVE_CHAR, pHdfProduct->m_what.m_szDate,    
                    sizeof(pHdfProduct->m_what.m_szDate));
    fnHdfCreateAttr(hWhat, "time",    H5T_NATIVE_CHAR, pHdfProduct->m_what.m_szTime,    
                    sizeof(pHdfProduct->m_what.m_szTime));
    fnHdfCreateAttr(hWhat, "source",  H5T_NATIVE_CHAR, pHdfProduct->m_what.m_szSource,  
                    sizeof(pHdfProduct->m_what.m_szSource));

    H5Gclose(hWhat);

    return TRUE;
}

static int fnSaveHdfProductTopWhere(hid_t hRoot, HDF_PRODUCT *pHdfProduct)
{
    hid_t       hWhere  = -1;
    double      dValue  = 0.0;
    long        lValue  = 0;

    if(hRoot < 0 || pHdfProduct == NULL)
        return FALSE;

    // HDF TOP WHERE
    if((hWhere = H5Gcreate1(hRoot, "where", 0)) < 0)
        return FALSE;
    
    if(pHdfProduct->m_iHdfProductType == HDF_EN_PRODUCT_SITE)
    {
        dValue = pHdfProduct->m_where.m_polar_where.m_dLon;
        fnHdfCreateAttr(hWhere, "lon",     H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
        dValue = pHdfProduct->m_where.m_polar_where.m_dLat;
        fnHdfCreateAttr(hWhere, "lat",     H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    }

    fnHdfCreateAttr(hWhere, "projdef", H5T_NATIVE_CHAR, 
                     pHdfProduct->m_where.m_image_where.m_szProjdef, 
                     sizeof(pHdfProduct->m_where.m_image_where.m_szProjdef));
    lValue = pHdfProduct->m_where.m_image_where.m_lXsize;
    fnHdfCreateAttr(hWhere, "xsize",   H5T_NATIVE_LONG,   (void *)&lValue, 0);
    lValue = pHdfProduct->m_where.m_image_where.m_lYsize;
    fnHdfCreateAttr(hWhere, "ysize",   H5T_NATIVE_LONG,   (void *)&lValue, 0);
    dValue = pHdfProduct->m_where.m_image_where.m_dXscale;
    fnHdfCreateAttr(hWhere, "xscale",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdfProduct->m_where.m_image_where.m_dYscale;
    fnHdfCreateAttr(hWhere, "yscale",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdfProduct->m_where.m_image_where.m_LL_lon;
    fnHdfCreateAttr(hWhere, "LL_lon",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdfProduct->m_where.m_image_where.m_LL_lat;
    fnHdfCreateAttr(hWhere, "LL_lat",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdfProduct->m_where.m_image_where.m_UL_lon;
    fnHdfCreateAttr(hWhere, "UL_lon",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdfProduct->m_where.m_image_where.m_UL_lat;
    fnHdfCreateAttr(hWhere, "UL_lat",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdfProduct->m_where.m_image_where.m_UR_lon;
    fnHdfCreateAttr(hWhere, "UR_lon",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdfProduct->m_where.m_image_where.m_UR_lat;
    fnHdfCreateAttr(hWhere, "UR_lat",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdfProduct->m_where.m_image_where.m_LR_lon;
    fnHdfCreateAttr(hWhere, "LR_lon",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdfProduct->m_where.m_image_where.m_LR_lat;
    fnHdfCreateAttr(hWhere, "LR_lat",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);

    H5Gclose(hWhere);

    return TRUE;
}

static int fnSaveHdfProductTopHow(hid_t hRoot, HDF_PRODUCT *pHdfProduct)
{
    hid_t       hHow  = -1;
    double      dValue  = 0.0;

    if(hRoot < 0 || pHdfProduct == NULL)
        return FALSE;

    // HDF TOP HOW
    if((hHow = H5Gcreate1(hRoot, "how", 0)) < 0)
        return FALSE;

    if(pHdfProduct->m_iHdfProductType == HDF_EN_PRODUCT_SITE)
    {
        dValue = pHdfProduct->m_how.m_radar_how.m_dNi;
        fnHdfCreateAttr(hHow, "NI", H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    }
    else if(pHdfProduct->m_iHdfProductType == HDF_EN_PRODUCT_COMP)
    {
        fnHdfCreateAttr(hHow, "camethod", H5T_NATIVE_CHAR, 
                         pHdfProduct->m_how.m_image_how.m_szCamethod, 
                         sizeof(pHdfProduct->m_how.m_image_how.m_szCamethod));
    }

    H5Gclose(hHow);

    return TRUE;
}

static int fnSaveHdfPrtDatasetWhat(hid_t hDataset, HDF_PRODUCT_DATASET *pHdfDataset, int iHdfProductType)
{
    hid_t   hWhat  = -1;

    if(hDataset < 0 || pHdfDataset == NULL)
        return FALSE;

    // HDF DATASET WHAT
    if((hWhat = H5Gcreate1(hDataset, "what", 0)) < 0)
        return FALSE;

    fnHdfCreateAttr(hWhat, "product", H5T_NATIVE_CHAR, 
                    pHdfDataset->m_what.m_szProduct, sizeof(pHdfDataset->m_what.m_szProduct));

    if(!strcmp(pHdfDataset->m_what.m_szProduct, "PPI"))
    {
        if(iHdfProductType == HDF_EN_PRODUCT_SITE)
            fnHdfCreateData1D(hWhat, "prodpar", H5T_NATIVE_DOUBLE, pHdfDataset->m_what.m_dProdpar, 1);
    }
    else if(!strcmp(pHdfDataset->m_what.m_szProduct, "CAPPI")  || 
            !strcmp(pHdfDataset->m_what.m_szProduct, "PCAPPI") ||
            !strcmp(pHdfDataset->m_what.m_szProduct, "ETOP"))
    {
        fnHdfCreateData1D(hWhat, "prodpar", H5T_NATIVE_DOUBLE, pHdfDataset->m_what.m_dProdpar, 1);
    }
    else if(!strcmp(pHdfDataset->m_what.m_szProduct, "VIL"))
    {
        fnHdfCreateData1D(hWhat, "prodpar", H5T_NATIVE_DOUBLE, pHdfDataset->m_what.m_dProdpar, 2);
    }

    H5Gclose(hWhat);

    return TRUE;
}

static int fnSaveHdfPrtDataWhat(hid_t hData, HDF_PRODUCT_DATA* pHdfData)
{
    hid_t   hWhat  = -1;
    double  dValue  = 0.0;

    if(hData < 0 || pHdfData == NULL)
        return FALSE;

    // HDF DATASET WHAT
    if((hWhat = H5Gcreate1(hData, "what", 0)) < 0)
        return FALSE;

    fnHdfCreateAttr(hWhat, "quantity", H5T_NATIVE_CHAR, 
                    pHdfData->m_what.m_szQuantity, sizeof(pHdfData->m_what.m_szQuantity));
    dValue = pHdfData->m_what.m_dGain;
    fnHdfCreateAttr(hWhat, "gain",     H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdfData->m_what.m_dOffset;
    fnHdfCreateAttr(hWhat, "offset",   H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdfData->m_what.m_dNodata;
    fnHdfCreateAttr(hWhat, "nodata",   H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdfData->m_what.m_dUndetect;
    fnHdfCreateAttr(hWhat, "undetect", H5T_NATIVE_DOUBLE, (void *)&dValue, 0);

    H5Gclose(hWhat);

    return TRUE;
}

static int fnSaveHdfPrtDataChar(hid_t hData, HDF_PRODUCT_DATA *pHdfData, int iYdim, int iXdim)
{
    char                *pData          = NULL;
    int                 iYIdx           = 0;
    int                 iXIdx           = 0;
    FIELD_MEM_INFO_TBL  memInfo;

    if(hData < 0 || pHdfData == NULL || iYdim <= 0 || iXdim <= 0)
        return FALSE;

    memset(&memInfo, 0x00, sizeof(memInfo));
    if(fnGetFieldMemInfo(pHdfData->m_szFieldName, &memInfo) == FALSE)
        return FALSE;

    pData = (char *)calloc(iYdim*iXdim, sizeof(char));
    if(pData == NULL)
        return FALSE;

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            pData[(iYIdx*iXdim)+iXIdx] = pHdfData->m_ppData_c[iYIdx][iXIdx];
        }
    }

    if(fnHdfCreateData2D(hData, "data", H5T_NATIVE_CHAR, (void *)pData, iYdim, iXdim, 
                         pHdfData->m_szClass, sizeof(pHdfData->m_szClass), 
                         pHdfData->m_szVersion, sizeof(pHdfData->m_szVersion)) < 0)
    {
        free(pData);
        return FALSE;
    }

    free(pData);

    return TRUE;
}

static int fnSaveHdfPrtDataShort(hid_t hData, HDF_PRODUCT_DATA *pHdfData, int iYdim, int iXdim)
{
    short               *pData          = NULL;
    int                 iYIdx           = 0;
    int                 iXIdx           = 0;
    FIELD_MEM_INFO_TBL  memInfo;

    if(hData < 0 || pHdfData == NULL || iYdim <= 0 || iXdim <= 0)
        return FALSE;

    memset(&memInfo, 0x00, sizeof(memInfo));
    if(fnGetFieldMemInfo(pHdfData->m_szFieldName, &memInfo) == FALSE)
        return FALSE;

    pData = (short *)calloc(iYdim*iXdim, sizeof(short));
    if(pData == NULL)
        return FALSE;

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            pData[(iYIdx*iXdim)+iXIdx] = pHdfData->m_ppData_s[iYIdx][iXIdx];
        }
    }

    if(fnHdfCreateData2D(hData, "data", H5T_NATIVE_SHORT, (void *)pData, iYdim, iXdim,
                         pHdfData->m_szClass, sizeof(pHdfData->m_szClass), 
                         pHdfData->m_szVersion, sizeof(pHdfData->m_szVersion)) < 0)
    {
        free(pData);
        return FALSE;
    }

    free(pData);

    return TRUE;
}

static int fnSaveHdfPrtDataFloat(hid_t hData, HDF_PRODUCT_DATA *pHdfData, int iYdim, int iXdim)
{
    float               *pData          = NULL;
    int                 iYIdx           = 0;
    int                 iXIdx           = 0;
    FIELD_MEM_INFO_TBL  memInfo;

    if(hData < 0 || pHdfData == NULL || iYdim <= 0 || iXdim <= 0)
        return FALSE;

    memset(&memInfo, 0x00, sizeof(memInfo));
    if(fnGetFieldMemInfo(pHdfData->m_szFieldName, &memInfo) == FALSE)
        return FALSE;

    pData = (float *)calloc(iYdim*iXdim, sizeof(float));
    if(pData == NULL)
        return FALSE;

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            pData[(iYIdx*iXdim)+iXIdx] = pHdfData->m_ppData_f[iYIdx][iXIdx];
        }
    }

    if(fnHdfCreateData2D(hData, "data", H5T_NATIVE_FLOAT, (void *)pData, iYdim, iXdim, 
                         pHdfData->m_szClass, sizeof(pHdfData->m_szClass), 
                         pHdfData->m_szVersion, sizeof(pHdfData->m_szVersion)) < 0)
    {
        free(pData);
        return FALSE;
    }

    free(pData);

    return TRUE;
}

static int fnSaveHdfPrtData(hid_t hDataset, HDF_PRODUCT_DATA *pHdfData, int iDataSeq, int iYdim, int iXdim)
{
    hid_t       hData           = -1;
    char        szDataNm[16]    = "";

    if(hDataset < 0 || pHdfData == NULL)
        return -1;

    if(pHdfData->m_ppData_c == NULL && 
       pHdfData->m_ppData_s == NULL && 
       pHdfData->m_ppData_f == NULL)
        return 0;

    snprintf(szDataNm, sizeof(szDataNm), "data%d", iDataSeq);
    if((hData = H5Gcreate1(hDataset, szDataNm, 0)) < 0)
        return -1;

    if(fnSaveHdfPrtDataWhat(hData, pHdfData) == FALSE) 
    {   
        H5Gclose(hData); 
        return -1;
    }

    if(pHdfData->m_iMemType == RDR_EN_MEM_CHAR && pHdfData->m_ppData_c != NULL)
    {
        if(fnSaveHdfPrtDataChar(hData, pHdfData, iYdim, iXdim) == FALSE)
        {
            H5Gclose(hData); 
            return -1;
        }
    }
    else if(pHdfData->m_iMemType == RDR_EN_MEM_SHORT && pHdfData->m_ppData_s != NULL)
    {
        if(fnSaveHdfPrtDataShort(hData, pHdfData, iYdim, iXdim) == FALSE)
        {
            H5Gclose(hData); 
            return -1;
        }
    }
    else if(pHdfData->m_iMemType == RDR_EN_MEM_FLOAT && pHdfData->m_ppData_f != NULL)
    {
        if(fnSaveHdfPrtDataFloat(hData, pHdfData, iYdim, iXdim) == FALSE)
        {
            H5Gclose(hData); 
            return -1;
        }
    }

    H5Gclose(hData);

    return 1;
}

static int fnCountHdfProductData(HDF_PRODUCT_DATASET *pDataset)
{
    int         iFieldIdx       = 0;
    int         iDataCnt        = 0;

    if(pDataset == NULL)
        return -1;

    if(pDataset->m_ppProductData == NULL)
        return 0;

    for(iFieldIdx = 0; iFieldIdx < pDataset->m_iMaxField; iFieldIdx++)
    {
        if(pDataset->m_ppProductData[iFieldIdx] == NULL)
            continue;

        if(pDataset->m_ppProductData[iFieldIdx]->m_ppData_c == NULL &&
           pDataset->m_ppProductData[iFieldIdx]->m_ppData_s == NULL && 
           pDataset->m_ppProductData[iFieldIdx]->m_ppData_f == NULL)
            continue;

        iDataCnt++;
    }

    return iDataCnt;
}

static int fnSaveHdfPrtDataset(hid_t hRoot, HDF_PRODUCT_DATASET **ppDataset, int iMaxDataset, int iDatasetSeq, int iYdim, int iXdim, int iHdfProductType)
{
    hid_t       hDataset        = -1;
    int         iDatasetIdx     = 0;
    int         iDatasetCnt     = 0;
    int         iFieldIdx       = 0;
    int         iDataSeq        = 0;
    int         iDataResult     = 0;
    char        szDatasetNm[16] = "";

    if(ppDataset == NULL)
        return -1;

    for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
    {
        if(ppDataset[iDatasetIdx] == NULL)
            continue;

        if(fnCountHdfProductData(ppDataset[iDatasetIdx]) <= 0)
            continue;

        snprintf(szDatasetNm, sizeof(szDatasetNm), "dataset%d", iDatasetSeq+iDatasetCnt);
        if((hDataset = H5Gcreate1(hRoot, szDatasetNm, 0)) < 0)
            return iDatasetCnt;

        if(fnSaveHdfPrtDatasetWhat(hDataset, ppDataset[iDatasetIdx], iHdfProductType) == FALSE)
        {
            H5Gclose(hDataset);
            return iDatasetCnt;
        }

        iDataSeq = 1;
        for(iFieldIdx = 0; iFieldIdx < ppDataset[iDatasetIdx]->m_iMaxField; iFieldIdx++)
        {
            if((iDataResult = fnSaveHdfPrtData(hDataset, 
                                               ppDataset[iDatasetIdx]->m_ppProductData[iFieldIdx], 
                                               iDataSeq, iYdim, iXdim)) < 0)
            {
                H5Gclose(hDataset);
                return iDatasetCnt;
            }
            iDataSeq += iDataResult;
        }

        H5Gclose(hDataset);

        iDatasetCnt++;
    }

    return iDatasetCnt;
}

static int fnSaveHdfProductDataset(hid_t hRoot, HDF_PRODUCT *pHdfProduct)
{
    int     iDatasetSeq     = 1;
    int     iDatasetResult  = 0;

    if(hRoot < 0 || pHdfProduct == NULL)
        return FALSE;

    if(pHdfProduct->m_totalProduct.m_iMaxPpi > 0)
    {
        if((iDatasetResult = fnSaveHdfPrtDataset(hRoot, pHdfProduct->m_totalProduct.m_ppPpi, 
                                                 pHdfProduct->m_totalProduct.m_iMaxPpi, iDatasetSeq,
                                                 (int)pHdfProduct->m_where.m_image_where.m_lYsize, 
                                                 (int)pHdfProduct->m_where.m_image_where.m_lXsize, 
                                                 pHdfProduct->m_iHdfProductType)) < 0)
        {   fprintf(stderr, "%s : fnSaveHdfPrtDataset PPI fail\n", __func__); return FALSE; }
        iDatasetSeq += iDatasetResult;
    }
    if(pHdfProduct->m_totalProduct.m_iMaxCappi > 0)
    {
        if((iDatasetResult = fnSaveHdfPrtDataset(hRoot, pHdfProduct->m_totalProduct.m_ppCappi,  
                                                 pHdfProduct->m_totalProduct.m_iMaxCappi, iDatasetSeq,
                                                 (int)pHdfProduct->m_where.m_image_where.m_lYsize, 
                                                 (int)pHdfProduct->m_where.m_image_where.m_lXsize, 
                                                 pHdfProduct->m_iHdfProductType)) < 0)
        {   fprintf(stderr, "%s : fnSaveHdfPrtDataset CAPPI fail\n", __func__); return FALSE; }
        iDatasetSeq += iDatasetResult;
    }
    if(pHdfProduct->m_totalProduct.m_iMaxBase > 0)
    {
        if((iDatasetResult = fnSaveHdfPrtDataset(hRoot, pHdfProduct->m_totalProduct.m_ppBase,  
                                                 pHdfProduct->m_totalProduct.m_iMaxBase, iDatasetSeq,
                                                 (int)pHdfProduct->m_where.m_image_where.m_lYsize, 
                                                 (int)pHdfProduct->m_where.m_image_where.m_lXsize, 
                                                 pHdfProduct->m_iHdfProductType)) < 0)
        {   fprintf(stderr, "%s : fnSaveHdfPrtDataset BASE fail\n", __func__); return FALSE; }

        iDatasetSeq += iDatasetResult;
    }
    if(pHdfProduct->m_totalProduct.m_iMaxCmax > 0)
    {
        if((iDatasetResult = fnSaveHdfPrtDataset(hRoot, pHdfProduct->m_totalProduct.m_ppCmax,  
                                                 pHdfProduct->m_totalProduct.m_iMaxCmax, iDatasetSeq,
                                                 (int)pHdfProduct->m_where.m_image_where.m_lYsize, 
                                                 (int)pHdfProduct->m_where.m_image_where.m_lXsize, 
                                                 pHdfProduct->m_iHdfProductType)) < 0)
        {   fprintf(stderr, "%s : fnSaveHdfPrtDataset CMAX fail\n", __func__); return FALSE; }
        iDatasetSeq += iDatasetResult;
    }
    if(pHdfProduct->m_totalProduct.m_iMaxVil > 0)
    {
        if((iDatasetResult = fnSaveHdfPrtDataset(hRoot, pHdfProduct->m_totalProduct.m_ppVil,  
                                                 pHdfProduct->m_totalProduct.m_iMaxVil, iDatasetSeq,
                                                 (int)pHdfProduct->m_where.m_image_where.m_lYsize, 
                                                 (int)pHdfProduct->m_where.m_image_where.m_lXsize, 
                                                 pHdfProduct->m_iHdfProductType)) < 0)
        {   fprintf(stderr, "%s : fnSaveHdfPrtDataset VIL fail\n", __func__); return FALSE; }
        iDatasetSeq += iDatasetResult;
    }
    if(pHdfProduct->m_totalProduct.m_iMaxEtop > 0)
    {
        if((iDatasetResult = fnSaveHdfPrtDataset(hRoot, pHdfProduct->m_totalProduct.m_ppEtop,  
                                                 pHdfProduct->m_totalProduct.m_iMaxEtop, iDatasetSeq, 
                                                 (int)pHdfProduct->m_where.m_image_where.m_lYsize, 
                                                 (int)pHdfProduct->m_where.m_image_where.m_lXsize, 
                                                 pHdfProduct->m_iHdfProductType)) < 0)
        {   fprintf(stderr, "%s : fnSaveHdfPrtDataset ETOP fail\n", __func__); return FALSE; }
        iDatasetSeq += iDatasetResult;
    }

    return TRUE;
}

// WRITE HDF

static int fnSaveHdfTopWhat(hid_t hRoot, HDF_RADAR *pHdf)
{
    hid_t       hWhat  = -1;

    if(hRoot < 0 || pHdf == NULL)
        return FALSE;

    // HDF TOP WHAT
    if((hWhat = H5Gcreate1(hRoot, "what", 0)) < 0)
        return FALSE;

    fnHdfCreateAttr(hWhat, "object",  H5T_NATIVE_CHAR, 
                    pHdf->m_what.m_szObject,  sizeof(pHdf->m_what.m_szObject));
    fnHdfCreateAttr(hWhat, "version", H5T_NATIVE_CHAR, pHdf->m_what.m_szVersion, 
                    sizeof(pHdf->m_what.m_szVersion));
    fnHdfCreateAttr(hWhat, "date",    H5T_NATIVE_CHAR, pHdf->m_what.m_szDate,    
                    sizeof(pHdf->m_what.m_szDate));
    fnHdfCreateAttr(hWhat, "time",    H5T_NATIVE_CHAR, pHdf->m_what.m_szTime,    
                    sizeof(pHdf->m_what.m_szTime));
    fnHdfCreateAttr(hWhat, "source",  H5T_NATIVE_CHAR, pHdf->m_what.m_szSource,  
                    sizeof(pHdf->m_what.m_szSource));

    H5Gclose(hWhat);

    return TRUE;
}

static int fnSaveHdfTopWhere(hid_t hRoot, HDF_RADAR *pHdf)
{
    hid_t       hWhere  = -1;
    double      dValue  = 0.0;

    if(hRoot < 0 || pHdf == NULL)
        return FALSE;

    // HDF TOP WHERE
    if((hWhere = H5Gcreate1(hRoot, "where", 0)) < 0)
        return FALSE;
    
    dValue = pHdf->m_where.m_polar_where.m_dLon;
    fnHdfCreateAttr(hWhere, "lon",     H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdf->m_where.m_polar_where.m_dLat;
    fnHdfCreateAttr(hWhere, "lat",     H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdf->m_where.m_polar_where.m_dHeightM;
    fnHdfCreateAttr(hWhere, "height",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);

    H5Gclose(hWhere);

    return TRUE;
}

static int fnSaveHdfTopHow(hid_t hRoot, HDF_RADAR *pHdf)
{
    hid_t       hHow  = -1;
    double      dValue  = 0.0;

    if(hRoot < 0 || pHdf == NULL)
        return FALSE;

    // HDF TOP HOW
    if((hHow = H5Gcreate1(hRoot, "how", 0)) < 0)
        return FALSE;

    fnHdfCreateAttr(hHow,  "task",  H5T_NATIVE_CHAR, pHdf->m_how.m_general_how.m_szTask,
                    sizeof(pHdf->m_how.m_general_how.m_szTask));

    dValue = pHdf->m_how.m_radar_how.m_dPulseWidth;
    fnHdfCreateAttr(hHow, "pulsewidth",     H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdf->m_how.m_radar_how.m_dBeamwH;
    fnHdfCreateAttr(hHow, "beamwH",         H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdf->m_how.m_radar_how.m_dBeamwV;
    fnHdfCreateAttr(hHow, "beamwV",         H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdf->m_how.m_radar_how.m_dRXbandWidth;
    fnHdfCreateAttr(hHow, "RXbandwidth",    H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdf->m_how.m_radar_how.m_dWaveLength;
    fnHdfCreateAttr(hHow, "wavelength",     H5T_NATIVE_DOUBLE, (void *)&dValue, 0);

    H5Gclose(hHow);

    return TRUE;
}

static int fnSaveHdfDatasetWhat(hid_t hDataset, HDF_DATASET *pHdfDset)
{
    hid_t       hWhat   = -1;

    if(hDataset < 0 || pHdfDset == NULL)
        return FALSE;

    if((hWhat = H5Gcreate1(hDataset, "what", 0)) < 0)
        return FALSE;

    fnHdfCreateAttr(hWhat, "product",   H5T_NATIVE_CHAR,
                    pHdfDset->m_what.m_szProduct,   sizeof(pHdfDset->m_what.m_szProduct));
    fnHdfCreateAttr(hWhat, "startdate", H5T_NATIVE_CHAR,
                    pHdfDset->m_what.m_szStartDate, sizeof(pHdfDset->m_what.m_szStartDate));
    fnHdfCreateAttr(hWhat, "starttime", H5T_NATIVE_CHAR,
                    pHdfDset->m_what.m_szStartTime, sizeof(pHdfDset->m_what.m_szStartTime));
    fnHdfCreateAttr(hWhat, "enddate",   H5T_NATIVE_CHAR,
                    pHdfDset->m_what.m_szEndDate,   sizeof(pHdfDset->m_what.m_szEndDate));
    fnHdfCreateAttr(hWhat, "endtime",   H5T_NATIVE_CHAR,
                    pHdfDset->m_what.m_szEndTime,   sizeof(pHdfDset->m_what.m_szEndTime));

    H5Gclose(hWhat);

    return TRUE;
}

static int fnSaveHdfDatasetWhere(hid_t hDataset, HDF_DATASET *pHdfDset)
{
    hid_t       hWhere  = -1;
    double      dValue  = 0.0;
    long        lValue  = 0;

    if(hDataset < 0 || pHdfDset == NULL)
        return FALSE;

    if((hWhere = H5Gcreate1(hDataset, "where", 0)) < 0)
        return FALSE;

    dValue = pHdfDset->m_where.m_polar_where.m_dElangle;
    fnHdfCreateAttr(hWhere, "elangle",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    lValue = pHdfDset->m_where.m_polar_where.m_nBins;
    fnHdfCreateAttr(hWhere, "nbins",    H5T_NATIVE_LONG,   (void *)&lValue, 0);
    dValue = pHdfDset->m_where.m_polar_where.m_dRstart;
    fnHdfCreateAttr(hWhere, "rstart",   H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdfDset->m_where.m_polar_where.m_dRScale;
    fnHdfCreateAttr(hWhere, "rscale",   H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    lValue = pHdfDset->m_where.m_polar_where.m_nRays;
    fnHdfCreateAttr(hWhere, "nrays",    H5T_NATIVE_LONG,   (void *)&lValue, 0);
    lValue = pHdfDset->m_where.m_polar_where.m_lA1gate;
    fnHdfCreateAttr(hWhere, "a1gate",   H5T_NATIVE_LONG,   (void *)&lValue, 0);

    H5Gclose(hWhere);

    return TRUE;
}

static int fnSaveHdfDatasetHow(hid_t hDataset, HDF_DATASET *pHdfDset)
{
    hid_t       hHow    = -1;
    double      dValue  = 0.0;

    if(hDataset < 0 || pHdfDset == NULL)
        return FALSE;

    if((hHow = H5Gcreate1(hDataset, "how", 0)) < 0)
        return FALSE;

    dValue = pHdfDset->m_how.m_radar_how.m_dNi;
    fnHdfCreateAttr(hHow, "NI",         H5T_NATIVE_DOUBLE, (void *)&dValue, 0);

    H5Gclose(hHow);

    return TRUE;
}

static int fnSaveHdfDataWhat(hid_t hData, HDF_DATA* pHdfData)
{
    hid_t   hWhat  = -1;
    double  dValue  = 0.0;

    if(hData < 0 || pHdfData == NULL)
        return FALSE;

    // HDF DATASET WHAT
    if((hWhat = H5Gcreate1(hData, "what", 0)) < 0)
        return FALSE;

    fnHdfCreateAttr(hWhat, "quantity", H5T_NATIVE_CHAR, 
                    pHdfData->m_what.m_szQuantity, sizeof(pHdfData->m_what.m_szQuantity));
    dValue = pHdfData->m_what.m_dGain;
    fnHdfCreateAttr(hWhat, "gain",     H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdfData->m_what.m_dOffset;
    fnHdfCreateAttr(hWhat, "offset",   H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdfData->m_what.m_dNodata;
    fnHdfCreateAttr(hWhat, "nodata",   H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
    dValue = pHdfData->m_what.m_dUndetect;
    fnHdfCreateAttr(hWhat, "undetect", H5T_NATIVE_DOUBLE, (void *)&dValue, 0);

    H5Gclose(hWhat);

    return TRUE;
}

static int fnSaveHdfData(hid_t hDataset, HDF_DATA *pHdfData, int iDataSeq, int nRays, int nBins)
{
    hid_t       hData           = -1;
    char        szDataNm[16]    = "";
    short       *pData          = NULL;
    int         iYIdx           = 0;
    int         iXIdx           = 0;

    if(hDataset < 0 || pHdfData == NULL)
        return FALSE;

    snprintf(szDataNm, sizeof(szDataNm), "data%d", iDataSeq);
    if((hData = H5Gcreate1(hDataset, szDataNm, 0)) < 0)
        return -1;

    if(fnSaveHdfDataWhat(hData, pHdfData) == FALSE)
    {   H5Gclose(hData); return FALSE; }

    pData = (short *)calloc(nRays*nBins, sizeof(short));
    if(pData == NULL)
    {   H5Gclose(hData); return FALSE; }

    for(iYIdx = 0; iYIdx < nRays; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < nBins; iXIdx++)
        {
            pData[(iYIdx*nBins)+iXIdx] = pHdfData->m_ppData[iYIdx][iXIdx];
        }
    }

    if(fnHdfCreateData2D(hData, "data", H5T_NATIVE_SHORT, (void *)pData, nRays, nBins,
                         pHdfData->m_szClass, sizeof(pHdfData->m_szClass),
                         pHdfData->m_szVersion, sizeof(pHdfData->m_szVersion)) < 0)
    {
        H5Gclose(hData);
        free(pData);
        return FALSE;
    }

    H5Gclose(hData);
    free(pData);

    return TRUE;
}

static int fnSaveHdfDataset(hid_t hRoot, HDF_RADAR *pHdf)
{
    HDF_DATASET     *pHdfDset           = NULL;
    HDF_DATA        *pHdfData           = NULL;
    hid_t           hDataset            = -1;
    char            szDatasetNm[16]     = "";
    int             iDsetSeq            = 0;
    int             iDsetIdx            = 0;
    int             iDataIdx            = 0;
    int             iDataSeq            = 0;

    if(hRoot < 0 || pHdf == NULL)
        return FALSE;

    if(pHdf->m_ppDataset == NULL)
        return FALSE;

    iDsetSeq = 1;
    for(iDsetIdx = 0; iDsetIdx < pHdf->m_iMaxDataset; iDsetIdx++)
    {
        pHdfDset = pHdf->m_ppDataset[iDsetIdx];

        if(pHdfDset == NULL) continue;

        if(pHdfDset->m_ppData == NULL) continue;

        snprintf(szDatasetNm, sizeof(szDatasetNm), "dataset%d", iDsetSeq);
        if((hDataset = H5Gcreate1(hRoot, szDatasetNm, 0)) < 0)
            return FALSE;

        if(fnSaveHdfDatasetWhat(hDataset, pHdfDset) == FALSE)
        {   H5Gclose(hDataset); return FALSE; }

        if(fnSaveHdfDatasetWhere(hDataset, pHdfDset) == FALSE)
        {   H5Gclose(hDataset); return FALSE; }

        if(fnSaveHdfDatasetHow(hDataset, pHdfDset) == FALSE)
        {   H5Gclose(hDataset); return FALSE; }

        iDataSeq = 1;
        for(iDataIdx = 0; iDataIdx < pHdfDset->m_iMaxData; iDataIdx++)
        {
            pHdfData = pHdfDset->m_ppData[iDataIdx];

            if(pHdfData == NULL) continue;

            if(pHdfData->m_ppData == NULL) continue;

            if(fnSaveHdfData(hDataset, pHdfData, iDataSeq, 
                             (int)pHdfDset->m_where.m_polar_where.m_nRays, 
                             (int)pHdfDset->m_where.m_polar_where.m_nBins) == FALSE)
            {   H5Gclose(hDataset); return FALSE; }

            iDataSeq++;
        }

        H5Gclose(hDataset);

        iDsetSeq++;
    }

    return TRUE;
}
/* ================================================================================ */
// Function

HDF_PRODUCT* fnInitHdfProduct(int iMaxField, int iMaxPpi, int iMaxCappi, int iMaxBase, int iMaxCmax, int iMaxVil, int iMaxEtop)
{
#define FN_INIT_HDF_PRODUCT_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pHdfProduct != NULL) { fnFreeHdfProduct(pHdfProduct); }

    HDF_PRODUCT*    pHdfProduct    = NULL;     // VARIABLE
    
    if(iMaxField <= 0)
        return NULL;

    pHdfProduct = (HDF_PRODUCT *)calloc(1, sizeof(HDF_PRODUCT));
    if(pHdfProduct == NULL)
        return NULL;

    if(iMaxPpi > 0 && iMaxPpi < RDR_DF_HDF_PRODUCT_MAX)
    {
        pHdfProduct->m_totalProduct.m_iMaxPpi = iMaxPpi;
        pHdfProduct->m_totalProduct.m_ppPpi   = fnInitHdfDataset("", iMaxPpi, iMaxField);
        if(pHdfProduct->m_totalProduct.m_ppPpi == NULL)
        {   FN_INIT_HDF_PRODUCT_ERROR("fnInitHdfDataset free"); }
    }
    if(iMaxCappi > 0 && iMaxCappi < RDR_DF_HDF_PRODUCT_MAX)
    {
        pHdfProduct->m_totalProduct.m_iMaxCappi = iMaxCappi;
        pHdfProduct->m_totalProduct.m_ppCappi   = fnInitHdfDataset("", iMaxCappi, iMaxField);
        if(pHdfProduct->m_totalProduct.m_ppCappi == NULL)
        {   FN_INIT_HDF_PRODUCT_ERROR("fnInitHdfDataset free"); }
    }
    if(iMaxBase > 0 && iMaxBase < RDR_DF_HDF_PRODUCT_MAX)
    {
        pHdfProduct->m_totalProduct.m_iMaxBase = iMaxBase;
        pHdfProduct->m_totalProduct.m_ppBase   = fnInitHdfDataset("", iMaxBase, iMaxField);
        if(pHdfProduct->m_totalProduct.m_ppBase == NULL)
        {   FN_INIT_HDF_PRODUCT_ERROR("fnInitHdfDataset free"); }
    }
    if(iMaxCmax > 0 && iMaxCmax < RDR_DF_HDF_PRODUCT_MAX)
    {
        pHdfProduct->m_totalProduct.m_iMaxCmax = iMaxCmax;
        pHdfProduct->m_totalProduct.m_ppCmax   = fnInitHdfDataset("", iMaxCmax, iMaxField);
        if(pHdfProduct->m_totalProduct.m_ppCmax == NULL)
        {   FN_INIT_HDF_PRODUCT_ERROR("fnInitHdfDataset free"); }
    }
    if(iMaxVil > 0 && iMaxVil < RDR_DF_HDF_PRODUCT_MAX)
    {
        pHdfProduct->m_totalProduct.m_iMaxVil = iMaxVil;
        pHdfProduct->m_totalProduct.m_ppVil   = fnInitHdfDataset("", iMaxVil, iMaxField);
        if(pHdfProduct->m_totalProduct.m_ppVil == NULL)
        {   FN_INIT_HDF_PRODUCT_ERROR("fnInitHdfDataset free"); }
    }
    if(iMaxEtop > 0 && iMaxEtop < RDR_DF_HDF_PRODUCT_MAX)
    {
        pHdfProduct->m_totalProduct.m_iMaxEtop = iMaxEtop;
        pHdfProduct->m_totalProduct.m_ppEtop   = fnInitHdfDataset("", iMaxEtop, iMaxField);
        if(pHdfProduct->m_totalProduct.m_ppEtop == NULL)
        {   FN_INIT_HDF_PRODUCT_ERROR("fnInitHdfDataset free"); }
    }

    return pHdfProduct;
}

void fnFreeHdfProduct(HDF_PRODUCT *pHdfProduct)
{
    if(pHdfProduct != NULL)
    {
        if(pHdfProduct->m_totalProduct.m_iMaxPpi > 0)
        {
            fnFreeHdfDataset(pHdfProduct->m_totalProduct.m_ppPpi, 
                             pHdfProduct->m_totalProduct.m_iMaxPpi,
                             pHdfProduct->m_where.m_image_where.m_lYsize);
        }
        if(pHdfProduct->m_totalProduct.m_iMaxCappi > 0)
        {
            fnFreeHdfDataset(pHdfProduct->m_totalProduct.m_ppCappi,
                             pHdfProduct->m_totalProduct.m_iMaxCappi,
                             pHdfProduct->m_where.m_image_where.m_lYsize);
        }
        if(pHdfProduct->m_totalProduct.m_iMaxBase > 0)
        {
            fnFreeHdfDataset(pHdfProduct->m_totalProduct.m_ppBase,
                             pHdfProduct->m_totalProduct.m_iMaxBase,
                             pHdfProduct->m_where.m_image_where.m_lYsize);
        }
        if(pHdfProduct->m_totalProduct.m_iMaxCmax > 0)
        {
            fnFreeHdfDataset(pHdfProduct->m_totalProduct.m_ppCmax,
                             pHdfProduct->m_totalProduct.m_iMaxCmax,
                             pHdfProduct->m_where.m_image_where.m_lYsize);
        }
        if(pHdfProduct->m_totalProduct.m_iMaxVil > 0)
        {
            fnFreeHdfDataset(pHdfProduct->m_totalProduct.m_ppVil,
                             pHdfProduct->m_totalProduct.m_iMaxVil,
                             pHdfProduct->m_where.m_image_where.m_lYsize);
        }
        if(pHdfProduct->m_totalProduct.m_iMaxEtop > 0)
        {
            fnFreeHdfDataset(pHdfProduct->m_totalProduct.m_ppEtop,
                             pHdfProduct->m_totalProduct.m_iMaxEtop,
                             pHdfProduct->m_where.m_image_where.m_lYsize);
        }

        free(pHdfProduct);
    }
}

HDF_PRODUCT* fnInitHdfProductToStdProduct(void *pStdPtr)
{
#define FN_INIT_HDF_PRODUCT_TO_STD_PRODUCT_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pHdfProduct != NULL) { fnFreeHdfProduct(pHdfProduct); }

    STD_PRODUCT*    pStdProduct = NULL;     // VARIABLE
    HDF_PRODUCT*    pHdfProduct = NULL;     // VARIABLE

    if(pStdPtr == NULL)
        return NULL;

    pStdProduct = (STD_PRODUCT *)pStdPtr;

    pHdfProduct = (HDF_PRODUCT *)calloc(1, sizeof(HDF_PRODUCT));
    if(pHdfProduct == NULL)
        return NULL;

    if(pStdProduct->m_totalProduct.m_iMaxPpi > 0 && 
       pStdProduct->m_totalProduct.m_iMaxPpi < RDR_DF_HDF_PRODUCT_MAX)
    {
        pHdfProduct->m_totalProduct.m_iMaxPpi = pStdProduct->m_totalProduct.m_iMaxPpi;
        pHdfProduct->m_totalProduct.m_ppPpi 
        = fnInitHdfDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppPpi, 
                                       pStdProduct->m_totalProduct.m_iMaxPpi);
        if(pHdfProduct->m_totalProduct.m_ppPpi == NULL)
        {   FN_INIT_HDF_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitHdfDatasetToStdDataset fail"); }
    }
    if(pStdProduct->m_totalProduct.m_iMaxCappi > 0 && 
       pStdProduct->m_totalProduct.m_iMaxCappi < RDR_DF_HDF_PRODUCT_MAX)
    {
        pHdfProduct->m_totalProduct.m_iMaxCappi = pStdProduct->m_totalProduct.m_iMaxCappi;
        pHdfProduct->m_totalProduct.m_ppCappi 
        = fnInitHdfDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppCappi,
                                       pStdProduct->m_totalProduct.m_iMaxCappi);
        if(pHdfProduct->m_totalProduct.m_ppCappi == NULL)
        {   FN_INIT_HDF_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitHdfDatasetToStdDataset fail"); }
    }
    if(pStdProduct->m_totalProduct.m_iMaxBase > 0 && 
       pStdProduct->m_totalProduct.m_iMaxBase < RDR_DF_HDF_PRODUCT_MAX)
    {
        pHdfProduct->m_totalProduct.m_iMaxBase = pStdProduct->m_totalProduct.m_iMaxBase;
        pHdfProduct->m_totalProduct.m_ppBase 
        = fnInitHdfDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppBase,
                                       pStdProduct->m_totalProduct.m_iMaxBase);
        if(pHdfProduct->m_totalProduct.m_ppBase == NULL)
        {   FN_INIT_HDF_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitHdfDatasetToStdDataset fail"); }
    }
    if(pStdProduct->m_totalProduct.m_iMaxCmax > 0 && 
       pStdProduct->m_totalProduct.m_iMaxCmax < RDR_DF_HDF_PRODUCT_MAX)
    {
        pHdfProduct->m_totalProduct.m_iMaxCmax = pStdProduct->m_totalProduct.m_iMaxCmax;
        pHdfProduct->m_totalProduct.m_ppCmax 
        = fnInitHdfDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppCmax,
                                       pStdProduct->m_totalProduct.m_iMaxCmax);
        if(pHdfProduct->m_totalProduct.m_ppCmax == NULL)
        {   FN_INIT_HDF_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitHdfDatasetToStdDataset fail"); }
    }
    if(pStdProduct->m_totalProduct.m_iMaxVil > 0 && 
       pStdProduct->m_totalProduct.m_iMaxVil < RDR_DF_HDF_PRODUCT_MAX)
    {
        pHdfProduct->m_totalProduct.m_iMaxVil = pStdProduct->m_totalProduct.m_iMaxVil;
        pHdfProduct->m_totalProduct.m_ppVil 
        = fnInitHdfDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppVil,
                                       pStdProduct->m_totalProduct.m_iMaxVil);
        if(pHdfProduct->m_totalProduct.m_ppVil == NULL)
        {   FN_INIT_HDF_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitHdfDatasetToStdDataset fail"); }
    }
    if(pStdProduct->m_totalProduct.m_iMaxEtop > 0 && 
       pStdProduct->m_totalProduct.m_iMaxEtop < RDR_DF_HDF_PRODUCT_MAX)
    {
        pHdfProduct->m_totalProduct.m_iMaxEtop = pStdProduct->m_totalProduct.m_iMaxEtop;
        pHdfProduct->m_totalProduct.m_ppEtop 
        = fnInitHdfDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppEtop,
                                       pStdProduct->m_totalProduct.m_iMaxEtop);
        if(pHdfProduct->m_totalProduct.m_ppEtop == NULL)
        {   FN_INIT_HDF_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitHdfDatasetToStdDataset fail"); }
    }

    return pHdfProduct;
}

int fnWriteHdfProduct(HDF_PRODUCT *pHdfProduct, char* szFileName)
{
#define FN_WRITE_HDF_PRODUCT_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(hFile >= 0) { H5Fclose(hFile); } \
    if(hRoot >= 0) { H5Gclose(hRoot); }

    hid_t       hFile                       = -1;
    hid_t       hRoot                       = -1;
    char        szTempFile[STR_LENGTH_MAX]  = "";

    if(pHdfProduct == NULL || szFileName == NULL)
        return FALSE;

    snprintf(szTempFile, sizeof(szTempFile), "%s.tmp", szFileName);

    if((hFile = H5Fcreate(szTempFile, H5F_ACC_TRUNC, H5P_DEFAULT, H5P_DEFAULT)) < 0)
    {   FN_WRITE_HDF_PRODUCT_ERROR("H5Fcreate fall")  return FALSE; }

    if((hRoot = H5Gopen1(hFile, "/")) < 0)
    {   FN_WRITE_HDF_PRODUCT_ERROR("ROOT Group H5Gopen1 fail") return FALSE; }

    fnHdfCreateAttr(hRoot, "Conventions", H5T_NATIVE_CHAR, 
                    pHdfProduct->m_szConventions, sizeof(pHdfProduct->m_szConventions));

    if(fnSaveHdfProductTopWhat(hRoot, pHdfProduct) == FALSE)
    {   FN_WRITE_HDF_PRODUCT_ERROR("fnSaveHdfProductTopWhat fail") return FALSE; }

    if(fnSaveHdfProductTopWhere(hRoot, pHdfProduct) == FALSE)
    {   FN_WRITE_HDF_PRODUCT_ERROR("fnSaveHdfProductTopWhere fail") return FALSE; }

    if(fnSaveHdfProductTopHow(hRoot, pHdfProduct) == FALSE)
    {   FN_WRITE_HDF_PRODUCT_ERROR("fnSaveHdfProductTopHow fail") return FALSE; }

    if(fnSaveHdfProductDataset(hRoot, pHdfProduct) == FALSE)
    {   FN_WRITE_HDF_PRODUCT_ERROR("fnSaveHdfproductDataset fail") return FALSE; }

    H5Gclose(hRoot);
    H5Fclose(hFile);

    rename(szTempFile, szFileName);

    return TRUE;
}

int fnGetMaxCountHdfProduct(HDF_PRODUCT *pHdfProduct, int *pMaxField, int *pMaxPpi, int *pMaxCappi, int *pMaxBase, int *pMaxCmax, int *pMaxVil, int *pMaxEtop)
{
    int     iDatasetIdx = 0;
    int     iMaxField   = 0;

    if(pHdfProduct == NULL)
        return FALSE;

    if(pHdfProduct->m_totalProduct.m_iMaxPpi > 0 && pHdfProduct->m_totalProduct.m_ppPpi != NULL)
    {
        for(iDatasetIdx = 0; iDatasetIdx < pHdfProduct->m_totalProduct.m_iMaxPpi; iDatasetIdx++)
        {
            if((pHdfProduct->m_totalProduct.m_ppPpi[iDatasetIdx] != NULL) && 
               (iMaxField < pHdfProduct->m_totalProduct.m_ppPpi[iDatasetIdx]->m_iMaxField))
                iMaxField = pHdfProduct->m_totalProduct.m_ppPpi[iDatasetIdx]->m_iMaxField;
        }
    }
    if(pHdfProduct->m_totalProduct.m_iMaxCappi > 0 && pHdfProduct->m_totalProduct.m_ppCappi != NULL)
    {
        for(iDatasetIdx = 0; iDatasetIdx < pHdfProduct->m_totalProduct.m_iMaxCappi; iDatasetIdx++)
        {
            if((pHdfProduct->m_totalProduct.m_ppCappi[iDatasetIdx] != NULL) && 
               (iMaxField < pHdfProduct->m_totalProduct.m_ppCappi[iDatasetIdx]->m_iMaxField))
                iMaxField = pHdfProduct->m_totalProduct.m_ppCappi[iDatasetIdx]->m_iMaxField;
        }
    }
    if(pHdfProduct->m_totalProduct.m_iMaxBase > 0 && pHdfProduct->m_totalProduct.m_ppBase != NULL)
    {
        for(iDatasetIdx = 0; iDatasetIdx < pHdfProduct->m_totalProduct.m_iMaxBase; iDatasetIdx++)
        {
            if((pHdfProduct->m_totalProduct.m_ppBase[iDatasetIdx] != NULL) && 
               (iMaxField < pHdfProduct->m_totalProduct.m_ppBase[iDatasetIdx]->m_iMaxField))
                iMaxField = pHdfProduct->m_totalProduct.m_ppBase[iDatasetIdx]->m_iMaxField;
        }
    }
    if(pHdfProduct->m_totalProduct.m_iMaxCmax > 0 && pHdfProduct->m_totalProduct.m_ppCmax != NULL)
    {
        for(iDatasetIdx = 0; iDatasetIdx < pHdfProduct->m_totalProduct.m_iMaxCmax; iDatasetIdx++)
        {
            if((pHdfProduct->m_totalProduct.m_ppCmax[iDatasetIdx] != NULL) && 
               (iMaxField < pHdfProduct->m_totalProduct.m_ppCmax[iDatasetIdx]->m_iMaxField))
                iMaxField = pHdfProduct->m_totalProduct.m_ppCmax[iDatasetIdx]->m_iMaxField;
        }
    }
    if(pHdfProduct->m_totalProduct.m_iMaxVil > 0 && pHdfProduct->m_totalProduct.m_ppVil != NULL)
    {
        for(iDatasetIdx = 0; iDatasetIdx < pHdfProduct->m_totalProduct.m_iMaxVil; iDatasetIdx++)
        {
            if((pHdfProduct->m_totalProduct.m_ppVil[iDatasetIdx] != NULL) && 
               (iMaxField < pHdfProduct->m_totalProduct.m_ppVil[iDatasetIdx]->m_iMaxField))
                iMaxField = pHdfProduct->m_totalProduct.m_ppVil[iDatasetIdx]->m_iMaxField;
        }
    }
    if(pHdfProduct->m_totalProduct.m_iMaxEtop > 0 && pHdfProduct->m_totalProduct.m_ppEtop != NULL)
    {
        for(iDatasetIdx = 0; iDatasetIdx < pHdfProduct->m_totalProduct.m_iMaxEtop; iDatasetIdx++)
        {
            if((pHdfProduct->m_totalProduct.m_ppEtop[iDatasetIdx] != NULL) && 
               (iMaxField < pHdfProduct->m_totalProduct.m_ppEtop[iDatasetIdx]->m_iMaxField))
                iMaxField = pHdfProduct->m_totalProduct.m_ppEtop[iDatasetIdx]->m_iMaxField;
        }
    }

    if(pMaxPpi   != NULL) *pMaxPpi   = pHdfProduct->m_totalProduct.m_iMaxPpi;
    if(pMaxCappi != NULL) *pMaxCappi = pHdfProduct->m_totalProduct.m_iMaxCappi;
    if(pMaxBase  != NULL) *pMaxBase  = pHdfProduct->m_totalProduct.m_iMaxBase;
    if(pMaxCmax  != NULL) *pMaxCmax  = pHdfProduct->m_totalProduct.m_iMaxCmax;
    if(pMaxVil   != NULL) *pMaxVil   = pHdfProduct->m_totalProduct.m_iMaxVil;
    if(pMaxEtop  != NULL) *pMaxEtop  = pHdfProduct->m_totalProduct.m_iMaxEtop;
    if(pMaxField != NULL) *pMaxField = iMaxField;

    return TRUE;
}

int fnWriteHdfRadar(HDF_RADAR *pHdf, char *szFileName)
{
#define FN_WRITE_HDF_RADAR_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(hFile >= 0) { H5Fclose(hFile); } \
    if(hRoot >= 0) { H5Gclose(hRoot); }

    hid_t       hFile                       = -1;
    hid_t       hRoot                       = -1;
    char        szTempFile[STR_LENGTH_MAX]  = "";

    if(pHdf == NULL || szFileName == NULL)
        return FALSE;

    snprintf(szTempFile, sizeof(szTempFile), "%s.tmp", szFileName);

    if((hFile = H5Fcreate(szTempFile, H5F_ACC_TRUNC, H5P_DEFAULT, H5P_DEFAULT)) < 0)
    {   FN_WRITE_HDF_RADAR_ERROR("H5Fcreate fall")  return FALSE; }

    if((hRoot = H5Gopen1(hFile, "/")) < 0)
    {   FN_WRITE_HDF_RADAR_ERROR("ROOT Group H5Gopen1 fail") return FALSE; }

    fnHdfCreateAttr(hRoot, "Conventions", H5T_NATIVE_CHAR, 
                    pHdf->m_szConventions, sizeof(pHdf->m_szConventions));

    if(fnSaveHdfTopWhat(hRoot, pHdf) == FALSE)
    {   FN_WRITE_HDF_RADAR_ERROR("fnSaveHdfTopWhat fail") return FALSE; }

    if(fnSaveHdfTopWhere(hRoot, pHdf) == FALSE)
    {   FN_WRITE_HDF_RADAR_ERROR("fnSaveHdfTopWhere fail") return FALSE; }

    if(fnSaveHdfTopHow(hRoot, pHdf) == FALSE)
    {   FN_WRITE_HDF_RADAR_ERROR("fnSaveHdfTopHow fail") return FALSE; }

    if(fnSaveHdfDataset(hRoot, pHdf) == FALSE)
    {   FN_WRITE_HDF_RADAR_ERROR("fnSaveHdfDataset fail") return FALSE; }

    H5Gclose(hRoot);
    H5Fclose(hFile);

    rename(szTempFile, szFileName);

    return TRUE;
}


