/* ================================================================================ */
//
// Radar BUFR Output Format & Output Function
//
// 2016.11.10 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"

/* Interface for the PROJ library of geographic projections */
#include <proj_api.h>

/* bufr */
#include <desc.h>
#include <bufr.h>
#include <bitio.h>
#include <rlenc.h>

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function

static unsigned char *fnCompress(varfl *pBuf, int iLen, int *pNcomp)
{
    int             iCompIdx        = 0;
    int             iVarIdx         = 0;
    int             iNChar          = 0;
    unsigned char   *pCompDataBuf   = NULL;
    unsigned char   *pTempBuf       = NULL;
    unsigned char   *pPtr           = NULL;
    unsigned long   lDestBufSize    = 0;
    int             iLittleEndian   = TRUE;

    if(pBuf == NULL)
        return NULL;

    iNChar = iLen*sizeof(varfl);

    lDestBufSize = compressBound(iNChar);

    if((pTempBuf = (unsigned char *)calloc(iNChar, sizeof(unsigned char))) == NULL)
        return NULL;

    if((pCompDataBuf = (unsigned char *)calloc(lDestBufSize, sizeof(unsigned char))) == NULL)
    {
        free(pTempBuf);
        return NULL;
    }

    iLittleEndian = fnIsLittleEndian();

    for(iCompIdx = 0; iCompIdx < iNChar/sizeof(varfl); iCompIdx++)
    {
        pPtr = (unsigned char *)(&pBuf[iCompIdx]);
        for(iVarIdx = 0; iVarIdx < sizeof(varfl); iVarIdx++)
        {
            if(iLittleEndian == FALSE)
            {
                pTempBuf[iCompIdx*sizeof(varfl)+iVarIdx] = pPtr[sizeof(varfl)-1-iVarIdx];
            }
            else
            {
                pTempBuf[iCompIdx*sizeof(varfl)+iVarIdx] = pPtr[iVarIdx];
            }
        }
    }

    if(compress(pCompDataBuf, &lDestBufSize, pTempBuf, iNChar) != Z_OK)
    {
        free(pTempBuf);
        free(pCompDataBuf);
        return NULL;
    }

    *pNcomp = lDestBufSize;
    free(pTempBuf);
    return pCompDataBuf;
}

static void fnFreeBufrDataset(BUFR_PRODUCT_DATASET **ppBufrDataset, int iMaxDataset, int iYdim)
{
    int                 iDatasetIdx         = 0;
    int                 iFieldIdx           = 0;
    int                 iMaxField           = 0;

    if(ppBufrDataset != NULL)
    {
        for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
        {
            if(ppBufrDataset[iDatasetIdx] != NULL)
            {
                if(ppBufrDataset[iDatasetIdx]->m_ppProductData != NULL)
                {
                    iMaxField = ppBufrDataset[iDatasetIdx]->m_iMaxField;

                    for(iFieldIdx = 0; iFieldIdx < iMaxField; iFieldIdx++)
                    {
                        if(ppBufrDataset[iDatasetIdx]->m_ppProductData[iFieldIdx] != NULL)
                        {
                            if(ppBufrDataset[iDatasetIdx]->
                               m_ppProductData[iFieldIdx]->m_ppData_c != NULL)
                            {
                                fnFreeMatrix2D((void **)ppBufrDataset[iDatasetIdx]->
                                               m_ppProductData[iFieldIdx]->m_ppData_c, iYdim);
                            }
                            if(ppBufrDataset[iDatasetIdx]->
                               m_ppProductData[iFieldIdx]->m_ppData_s != NULL)
                            {
                                fnFreeMatrix2D((void **)ppBufrDataset[iDatasetIdx]->
                                               m_ppProductData[iFieldIdx]->m_ppData_s, iYdim);
                            }
                            if(ppBufrDataset[iDatasetIdx]->
                               m_ppProductData[iFieldIdx]->m_ppData_f != NULL)
                            {
                                fnFreeMatrix2D((void **)ppBufrDataset[iDatasetIdx]->
                                               m_ppProductData[iFieldIdx]->m_ppData_f, iYdim);
                            }
                            free(ppBufrDataset[iDatasetIdx]->m_ppProductData[iFieldIdx]);
                        }
                    }
                    free(ppBufrDataset[iDatasetIdx]->m_ppProductData);
                }
                free(ppBufrDataset[iDatasetIdx]);
            }
        }
        free(ppBufrDataset);
    }
}

static BUFR_PRODUCT_DATASET** fnInitBufrDataset(char *szProduct, int iMaxDataset, int iMaxField)
{
    BUFR_PRODUCT_DATASET **ppBufrDataset = NULL;
    int                 iDatasetIdx     = 0;
    int                 iFieldIdx       = 0;

    if(szProduct == NULL || iMaxDataset <= 0 || iMaxField <= 0)
        return NULL;

    ppBufrDataset 
    = (BUFR_PRODUCT_DATASET **)calloc(iMaxDataset, sizeof(BUFR_PRODUCT_DATASET *));
    if(ppBufrDataset == NULL)
        return NULL;

    for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
    {
        ppBufrDataset[iDatasetIdx] 
        = (BUFR_PRODUCT_DATASET *)calloc(1, sizeof(BUFR_PRODUCT_DATASET));
        if(ppBufrDataset[iDatasetIdx] == NULL)
        {
            fnFreeBufrDataset(ppBufrDataset, iMaxDataset, 0);
            return NULL;
        }
        snprintf(ppBufrDataset[iDatasetIdx]->m_what.m_szProduct,
                 sizeof(ppBufrDataset[iDatasetIdx]->m_what.m_szProduct), "%s", szProduct);
        ppBufrDataset[iDatasetIdx]->m_iMaxField = iMaxField;

        ppBufrDataset[iDatasetIdx]->m_ppProductData 
        = (BUFR_PRODUCT_DATA **)calloc(iMaxField, sizeof(BUFR_PRODUCT_DATA *));
        if(ppBufrDataset[iDatasetIdx]->m_ppProductData == NULL)
        {
            fnFreeBufrDataset(ppBufrDataset, iMaxDataset, 0);
            return NULL;
        }
        for(iFieldIdx = 0; iFieldIdx < iMaxField; iFieldIdx++)
        {
            ppBufrDataset[iDatasetIdx]->m_ppProductData[iFieldIdx]
            = (BUFR_PRODUCT_DATA *)calloc(1, sizeof(BUFR_PRODUCT_DATA));
            if(ppBufrDataset[iDatasetIdx]->m_ppProductData[iFieldIdx] == NULL)
            {
                fnFreeBufrDataset(ppBufrDataset, iMaxDataset, 0);
                return NULL;
            }
        }
    }

    return ppBufrDataset;
}

static BUFR_PRODUCT_DATASET** fnInitBufrDatasetToStdDataset(STD_PRODUCT_DATASET **ppStdDataset, int iMaxDataset)
{
    BUFR_PRODUCT_DATASET    **ppBufrDataset = NULL;
    int                     iDatasetIdx     = 0;
    int                     iFieldIdx       = 0;

    if(ppStdDataset == NULL || iMaxDataset <= 0)
        return NULL;

    ppBufrDataset 
    = (BUFR_PRODUCT_DATASET **)calloc(iMaxDataset, sizeof(BUFR_PRODUCT_DATASET *));
    if(ppBufrDataset == NULL)
        return NULL;

    for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
    {
        ppBufrDataset[iDatasetIdx] 
        = (BUFR_PRODUCT_DATASET *)calloc(1, sizeof(BUFR_PRODUCT_DATASET));
        if(ppBufrDataset[iDatasetIdx] == NULL)
        {
            fnFreeBufrDataset(ppBufrDataset, iMaxDataset, 0);
            return NULL;
        }
        ppBufrDataset[iDatasetIdx]->m_iMaxField = ppStdDataset[iDatasetIdx]->m_iMaxField;

        ppBufrDataset[iDatasetIdx]->m_ppProductData 
        = (BUFR_PRODUCT_DATA **)calloc(ppBufrDataset[iDatasetIdx]->m_iMaxField, 
                                       sizeof(BUFR_PRODUCT_DATA *));
        if(ppBufrDataset[iDatasetIdx]->m_ppProductData == NULL)
        {
            fnFreeBufrDataset(ppBufrDataset, iMaxDataset, 0);
            return NULL;
        }
        for(iFieldIdx = 0; iFieldIdx < ppBufrDataset[iDatasetIdx]->m_iMaxField; iFieldIdx++)
        {
            ppBufrDataset[iDatasetIdx]->m_ppProductData[iFieldIdx]
            = (BUFR_PRODUCT_DATA *)calloc(1, sizeof(BUFR_PRODUCT_DATA));
            if(ppBufrDataset[iDatasetIdx]->m_ppProductData[iFieldIdx] == NULL)
            {
                fnFreeBufrDataset(ppBufrDataset, iMaxDataset, 0);
                return NULL;
            }
        }
    }

    return ppBufrDataset;
}


static int fnCountBufrProductData(BUFR_PRODUCT_DATASET **ppDataset, int iMaxDset)
{
    int         iDsetIdx        = 0;
    int         iFieldIdx       = 0;
    int         iDataCnt        = 0;

    if(ppDataset == NULL || iMaxDset <= 0)
        return 0;

    for(iDsetIdx = 0; iDsetIdx < iMaxDset; iDsetIdx++)
    {
        if(ppDataset[iDsetIdx]->m_ppProductData == NULL)
            continue;

        for(iFieldIdx = 0; iFieldIdx < ppDataset[iDsetIdx]->m_iMaxField; iFieldIdx++)
        {
            if(ppDataset[iDsetIdx]->m_ppProductData[iFieldIdx] == NULL)
                continue;

            if(ppDataset[iDsetIdx]->m_ppProductData[iFieldIdx]->m_ppData_c == NULL &&
               ppDataset[iDsetIdx]->m_ppProductData[iFieldIdx]->m_ppData_s == NULL && 
               ppDataset[iDsetIdx]->m_ppProductData[iFieldIdx]->m_ppData_f == NULL)
                continue;

            iDataCnt++;
        }
    }

    return iDataCnt;
}

static int fnGetBufrProductMaxData(BUFR_PRODUCT *pBufrProduct)
{
    int iMaxData    = 0;

    if(pBufrProduct == NULL)
        return 0;

    iMaxData = fnCountBufrProductData(pBufrProduct->m_totalProduct.m_ppPpi, 
                                      pBufrProduct->m_totalProduct.m_iMaxPpi)   + 
               fnCountBufrProductData(pBufrProduct->m_totalProduct.m_ppCappi, 
                                      pBufrProduct->m_totalProduct.m_iMaxCappi) + 
               fnCountBufrProductData(pBufrProduct->m_totalProduct.m_ppBase, 
                                      pBufrProduct->m_totalProduct.m_iMaxBase)  +
               fnCountBufrProductData(pBufrProduct->m_totalProduct.m_ppCmax, 
                                      pBufrProduct->m_totalProduct.m_iMaxCmax)  +
               fnCountBufrProductData(pBufrProduct->m_totalProduct.m_ppVil, 
                                      pBufrProduct->m_totalProduct.m_iMaxVil)   +
               fnCountBufrProductData(pBufrProduct->m_totalProduct.m_ppEtop, 
                                      pBufrProduct->m_totalProduct.m_iMaxEtop);

    return iMaxData;
}

static varfl* fnMakeBufrSaveData(BUFR_PRODUCT_DATA *pBufrData, int iYdim, int iXdim)
{
    varfl                   *pTempData  = NULL;
    int                     iYIdx       = 0;
    int                     iXIdx       = 0;
    char                    cData       = 0;
    short                   sData       = 0;
    float                   fData       = 0.0;
    FIELD_MEM_INFO_TBL      memInfo;

    if(pBufrData == NULL)
        return NULL;

    if(pBufrData->m_ppData_c == NULL && 
       pBufrData->m_ppData_s == NULL &&
       pBufrData->m_ppData_f == NULL)
        return NULL;

    memset(&memInfo, 0x00, sizeof(memInfo));
    if(fnGetFieldMemInfo(pBufrData->m_szFieldName, &memInfo) == FALSE)
        return NULL;

    if((pTempData = (varfl *)calloc(iYdim*iXdim, sizeof(varfl))) == NULL)
        return NULL;

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            if(pBufrData->m_iMemType == RDR_EN_MEM_CHAR)
            {
                cData = pBufrData->m_ppData_c[iYIdx][iXIdx];

                if(fabs(cData - memInfo.m_fOutBound) < RDR_DF_ERR_RANGE_F)
                    pTempData[iYIdx*iXdim+iXIdx] = pBufrData->m_what.m_dNodata;
                else if(fabs(cData - memInfo.m_fBadValue) < RDR_DF_ERR_RANGE_F)
                    pTempData[iYIdx*iXdim+iXIdx] = pBufrData->m_what.m_dUndetect;
                else
                {
                    pTempData[iYIdx*iXdim+iXIdx] 
                    = (varfl)((cData/memInfo.m_fScale) - memInfo.m_fOffset);
                }
            }
            else if(pBufrData->m_iMemType == RDR_EN_MEM_SHORT)
            {
                sData = pBufrData->m_ppData_s[iYIdx][iXIdx];

                if(fabs(sData - memInfo.m_fOutBound) < RDR_DF_ERR_RANGE_F)
                    pTempData[iYIdx*iXdim+iXIdx] = pBufrData->m_what.m_dNodata;
                else if(fabs(sData - memInfo.m_fBadValue) < RDR_DF_ERR_RANGE_F)
                    pTempData[iYIdx*iXdim+iXIdx] = pBufrData->m_what.m_dUndetect;
                else
                {
                    pTempData[iYIdx*iXdim+iXIdx] 
                    = (varfl)((sData/memInfo.m_fScale) - memInfo.m_fOffset);
                }
            }
            else if(pBufrData->m_iMemType == RDR_EN_MEM_FLOAT)
            {
                fData = pBufrData->m_ppData_f[iYIdx][iXIdx];

                if(fabs(fData - memInfo.m_fOutBound) < RDR_DF_ERR_RANGE_F)
                    pTempData[iYIdx*iXdim+iXIdx] = pBufrData->m_what.m_dNodata;
                else if(fabs(fData - memInfo.m_fBadValue) < RDR_DF_ERR_RANGE_F)
                    pTempData[iYIdx*iXdim+iXIdx] = pBufrData->m_what.m_dUndetect;
                else
                {
                    pTempData[iYIdx*iXdim+iXIdx] 
                    = (varfl)((fData/memInfo.m_fScale) -memInfo.m_fOffset);
                }
            }
        }
    }

    return pTempData;
}

static void fnFILL_DESC(dd descr[MAX_DESCS], int ff, int xx, int yy, int *pOut)
{
    int iOut_desc   = 0;
    dd  dds;

    if(pOut == NULL)
        return;

    iOut_desc = *pOut;

    dds.f = ff; 
    dds.x = xx; 
    dds.y = yy;

    if(bufr_desc_to_array(descr, dds, &iOut_desc) != 1)
        fprintf(stderr, "%s : bufr_desc_to_array fail\n", __func__);

    *pOut = iOut_desc;
}

static void fnFILL_VV(varfl **ppVV, varfl val, int *pOut)
{
    varfl   *pVV    = NULL;
    int     iOut_vv = 0;
    
    if(ppVV == NULL || pOut == NULL)
        return;
    
    pVV     = *ppVV;
    iOut_vv = *pOut;

    if(bufr_val_to_array(&pVV, val, &iOut_vv) != 1)
        fprintf(stderr, "%s : bufr_val_to_array fail\n", __func__);

    *ppVV = pVV;
    *pOut = iOut_vv;
}

static int fnSaveBufrProductDataset(BUFR_PRODUCT_DATASET **ppBufrDset, int iMaxDset, int iYdim, int iXdim, varfl **ppVV, int *pOut_vv)
{
    BUFR_PRODUCT_DATASET    *pBufrDset              = NULL;
    BUFR_PRODUCT_DATA       *pBufrData              = NULL;
    int                     iDsetIdx                = 0;
    int                     iDataIdx                = 0;
    int                     iByteIdx                = 0;

    varfl                   *pTempData              = NULL;
    unsigned char           *pCompData              = NULL;
    int                     iNcomp                  = 0;
    int                     iIterIdx                = 0;
    int                     iCompIdx                = 0;

    if(ppBufrDset == NULL || ppVV == NULL || pOut_vv == NULL)
        return -1;

    for(iDsetIdx = 0; iDsetIdx < iMaxDset; iDsetIdx++)
    {
        if(ppBufrDset[iDsetIdx] == NULL)
            continue;

        pBufrDset = ppBufrDset[iDsetIdx];

        for(iDataIdx = 0; iDataIdx < pBufrDset->m_iMaxField; iDataIdx++)
        {
            if(pBufrDset->m_ppProductData == NULL)
                continue;

            if(pBufrDset->m_ppProductData[iDataIdx] == NULL)
                continue;

            pBufrData = pBufrDset->m_ppProductData[iDataIdx];

            pTempData = NULL;
            if((pTempData = fnMakeBufrSaveData(pBufrData, iYdim, iXdim)) == NULL)
                continue;

            for(iByteIdx = 0; iByteIdx < 6; iByteIdx++)
                fnFILL_VV(ppVV, pBufrDset->m_what.m_szProduct[iByteIdx], pOut_vv);

            if(!strcmp(pBufrDset->m_what.m_szProduct, "PPI") ||
               !strcmp(pBufrDset->m_what.m_szProduct, "PCAPPI"))
                fnFILL_VV(ppVV, pBufrDset->m_what.m_dProdpar[0]*1000., pOut_vv);
            else
                fnFILL_VV(ppVV, 0.0, pOut_vv);

            for(iByteIdx = 0; iByteIdx < 6; iByteIdx++)
                fnFILL_VV(ppVV, pBufrData->m_what.m_szQuantity[iByteIdx], pOut_vv);

            fnFILL_VV(ppVV, 0, pOut_vv); /* zlib compression */
            
            if((pCompData = fnCompress(pTempData, iYdim*iXdim, &iNcomp)) == NULL)
            {
                free(pTempData);
                continue;
            }

            fnFILL_VV(ppVV, iNcomp/RDR_DF_BUFR_ITER_SIZE + 1, pOut_vv);
            for(iIterIdx = 0; iIterIdx < iNcomp/RDR_DF_BUFR_ITER_SIZE; iIterIdx++)
            {
                fnFILL_VV(ppVV, RDR_DF_BUFR_ITER_SIZE, pOut_vv);
                for(iCompIdx = 0; iCompIdx < RDR_DF_BUFR_ITER_SIZE; iCompIdx++)
                {
                    fnFILL_VV(ppVV, pCompData[iCompIdx+iIterIdx*RDR_DF_BUFR_ITER_SIZE], pOut_vv);
                }
            }
            fnFILL_VV(ppVV, iNcomp%RDR_DF_BUFR_ITER_SIZE, pOut_vv);
            for(iCompIdx = 0; iCompIdx < iNcomp%RDR_DF_BUFR_ITER_SIZE; iCompIdx++)
            {
                fnFILL_VV(ppVV, 
                          pCompData[iCompIdx+(iNcomp/RDR_DF_BUFR_ITER_SIZE)*RDR_DF_BUFR_ITER_SIZE], 
                          pOut_vv);
            }
            free(pTempData);
        }
    }

    return 0;
}

static int fnWriteBufr(sect_1_t *pS1, dd *descr, int iOut_desc, varfl *pVV, char *szFileName)
{
    char        szTablePath[STR_LENGTH_MAX] = "";
    char        szTempFile[STR_LENGTH_MAX]  = "";
    sect_1_t    s1;
    bufr_t      msg;

    if(pS1 == NULL || pVV == NULL || szFileName == NULL)
        return FALSE;

    memset(&s1,     0x00, sizeof(sect_1_t));
    memset(&msg,    0x00, sizeof(bufr_t));

    s1.year     = pS1->year;
    s1.mon      = pS1->mon;
    s1.day      = pS1->day;
    s1.hour     = pS1->hour;
    s1.min      = pS1->min;
    s1.sec      = pS1->sec;
    s1.mtab     = pS1->mtab;      /* master table used */
    s1.subcent  = 0;
    s1.gencent  = 247;
    s1.updsequ  = pS1->updsequ;   /* original BUFR message */
    s1.opsec    = pS1->opsec;     /* no optional section */
    s1.dcat     = pS1->dcat;      /* message type */
    s1.dcatst   = pS1->dcatst;    /* message subtype */
    s1.idcatst  = pS1->idcatst;
    s1.vmtab    = 16;             /* version number of master table used */
    s1.vltab    = 9;              /* version number of local table used */

    _bufr_edition = 4;

    snprintf(szTablePath, sizeof(szTablePath), "%s/resource/bufr_table", RDR_DF_APP_ROOT_PATH);
    if(read_tables(szTablePath, s1.vmtab, s1.vltab, s1.subcent, s1.gencent) < 0)
    {
        bufr_free_data(&msg);
        return FALSE;
    }

    if(bufr_encode_sections34(descr, iOut_desc, pVV, &msg) == 0)
    {
        bufr_free_data(&msg);
        return FALSE;
    }

    if(bufr_encode_sections0125(&s1, &msg) == 0)
    {
        bufr_free_data(&msg);
        return FALSE;
    }

    snprintf(szTempFile, sizeof(szTempFile), "%s.tmp", szFileName);

    if(bufr_write_file(&msg, szTempFile) == 0)
    {
        bufr_free_data(&msg);
        return FALSE;
    }

    rename(szTempFile, szFileName);

    bufr_free_data(&msg);

    return TRUE;
}

static int fnRecodeBufrProducts(BUFR_PRODUCT *pBufrProduct, char *szFileName, sect_1_t *pS1)
{
    char                    szTemp[STR_LENGTH_MAX]  = "";
    struct tm               tempTm;

    int                     iWmoFlag                = FALSE;
    int                     iOut_desc               = 0;
    int                     iOut_vv                 = 0;
    varfl                   *pVV                    = NULL;
    dd                      descr[MAX_DESCS];

    int                     iSpCnt                  = 0;
    int                     iSpIdx                  = 0;
    int                     iByteIdx                = 0;
    char                    *ppSp[32]               = { NULL, };
    char                    *ppSp2[2]               = { NULL, };

    int                     iMaxData                = 0;
    int                     iYdim                   = 0;
    int                     iXdim                   = 0;

    if(pBufrProduct == NULL || szFileName == NULL || pS1 == NULL)
        return FALSE;

    memset(&descr, 0x00, sizeof(descr));

    snprintf(szTemp, sizeof(szTemp), "%s%s", 
             pBufrProduct->m_what.m_szDate, pBufrProduct->m_what.m_szTime);
    strptime(szTemp, "%Y%m%d%H%M%S", &tempTm);

    fnFILL_DESC(descr, 3,1,11, &iOut_desc);
    fnFILL_VV(&pVV, tempTm.tm_year+1900, &iOut_vv);
    fnFILL_VV(&pVV, tempTm.tm_mon+1, &iOut_vv);
    fnFILL_VV(&pVV, tempTm.tm_mday, &iOut_vv);
    fnFILL_DESC(descr, 3,1,13, &iOut_desc);
    fnFILL_VV(&pVV, tempTm.tm_hour,      &iOut_vv);
    fnFILL_VV(&pVV, tempTm.tm_min, &iOut_vv);
    fnFILL_VV(&pVV, tempTm.tm_sec, &iOut_vv);

    snprintf(szTemp, sizeof(szTemp), pBufrProduct->m_what.m_szSource);
    iSpCnt = fnSplit(szTemp, ppSp, 32, ',');
    for(iSpIdx = 0; iSpIdx < iSpCnt; iSpIdx++)
    {
        if(!strncmp(ppSp[iSpIdx], "WMO", strlen("WMO")))
        {
            iWmoFlag = TRUE;
            break;
        }
    }

    fnFILL_DESC(descr, 3,21,204, &iOut_desc);
    if(iWmoFlag == TRUE)
        fnFILL_VV(&pVV, iSpCnt-1, &iOut_vv);
    else
        fnFILL_VV(&pVV, iSpCnt, &iOut_vv);

    for(iSpIdx = 0; iSpIdx < iSpCnt; iSpIdx++)
    {
        ppSp2[0] = ppSp2[1] = NULL;
        fnSplit(ppSp[iSpIdx], ppSp2, 2, ':');
        if(strcmp(ppSp2[0], "WMO"))
        {
            if(ppSp2[0] != NULL && ppSp2[1] != NULL)
            {
                for(iByteIdx = 0; iByteIdx < 3; iByteIdx++)
                {
                    fnFILL_VV(&pVV, ppSp2[0][iByteIdx], &iOut_vv);
                }
                for(iByteIdx = 0; iByteIdx < strlen(ppSp2[1]); iByteIdx++)
                {
                    fnFILL_VV(&pVV, ppSp2[1][iByteIdx], &iOut_vv);
                }
                for(iByteIdx = strlen(ppSp2[1]); iByteIdx < 16; iByteIdx++)
                {
                    fnFILL_VV(&pVV, 0, &iOut_vv);
                }
            }
            else
            {
                for(iByteIdx = 0; iByteIdx < 3; iByteIdx++)
                {
                    fnFILL_VV(&pVV, 0, &iOut_vv);
                }
                for(iByteIdx = 0; iByteIdx < 16; iByteIdx++)
                {
                    fnFILL_VV(&pVV, 0, &iOut_vv);
                }
            }
        }
    }

    fnFILL_DESC(descr, 0,29,205, &iOut_desc);
    for(iByteIdx = 0; iByteIdx < 100; iByteIdx++)
    {
        fnFILL_VV(&pVV, pBufrProduct->m_where.m_image_where.m_szProjdef[iByteIdx], &iOut_vv);
    }

    fnFILL_DESC(descr, 0,5,33, &iOut_desc);
    fnFILL_VV(&pVV, pBufrProduct->m_where.m_image_where.m_dXscale*1000., &iOut_vv);
    fnFILL_DESC(descr, 0,6,33, &iOut_desc);
    fnFILL_VV(&pVV, pBufrProduct->m_where.m_image_where.m_dYscale*1000., &iOut_vv);
    fnFILL_DESC(descr, 2,1,129, &iOut_desc);
    fnFILL_DESC(descr, 0,30,21, &iOut_desc);
    fnFILL_VV(&pVV, pBufrProduct->m_where.m_image_where.m_lXsize, &iOut_vv);
    fnFILL_DESC(descr, 0,30,22, &iOut_desc);
    fnFILL_VV(&pVV, pBufrProduct->m_where.m_image_where.m_lYsize, &iOut_vv);
    fnFILL_DESC(descr, 2,1,0, &iOut_desc);

    fnFILL_DESC(descr, 3,1,21, &iOut_desc);
    fnFILL_VV(&pVV, pBufrProduct->m_where.m_image_where.m_UL_lat, &iOut_vv);
    fnFILL_VV(&pVV, pBufrProduct->m_where.m_image_where.m_UL_lon, &iOut_vv);
    fnFILL_DESC(descr, 3,1,21, &iOut_desc);
    fnFILL_VV(&pVV, pBufrProduct->m_where.m_image_where.m_UR_lat, &iOut_vv);
    fnFILL_VV(&pVV, pBufrProduct->m_where.m_image_where.m_UR_lon, &iOut_vv);
    fnFILL_DESC(descr, 3,1,21, &iOut_desc);
    fnFILL_VV(&pVV, pBufrProduct->m_where.m_image_where.m_LR_lat, &iOut_vv);
    fnFILL_VV(&pVV, pBufrProduct->m_where.m_image_where.m_LR_lon, &iOut_vv);
    fnFILL_DESC(descr, 3,1,21, &iOut_desc);
    fnFILL_VV(&pVV, pBufrProduct->m_where.m_image_where.m_LL_lat, &iOut_vv);
    fnFILL_VV(&pVV, pBufrProduct->m_where.m_image_where.m_LL_lon, &iOut_vv);

    fnFILL_DESC(descr, 0,29,193, &iOut_desc);
    fnFILL_VV(&pVV, pBufrProduct->m_where.m_polar_where.m_dLon, &iOut_vv);
    fnFILL_DESC(descr, 0,29,194, &iOut_desc);
    fnFILL_VV(&pVV, pBufrProduct->m_where.m_polar_where.m_dLat, &iOut_vv);

    iMaxData = fnGetBufrProductMaxData(pBufrProduct);

    fnFILL_DESC(descr, 1,4,0, &iOut_desc);
    fnFILL_DESC(descr, 0,31,1, &iOut_desc);
    fnFILL_VV(&pVV, iMaxData, &iOut_vv);

    fnFILL_DESC(descr, 0,30,199, &iOut_desc); // PRODUCT
    fnFILL_DESC(descr, 0,21,200, &iOut_desc); // Height of CAPPI ( PPI 고도각 CAPPI 고도 )
    fnFILL_DESC(descr, 0,30,200, &iOut_desc); // QUANTITY
    fnFILL_DESC(descr, 3,21,206, &iOut_desc); // DATA

    iYdim = pBufrProduct->m_where.m_image_where.m_lYsize;
    iXdim = pBufrProduct->m_where.m_image_where.m_lXsize;

    fnSaveBufrProductDataset(pBufrProduct->m_totalProduct.m_ppPpi, 
                             pBufrProduct->m_totalProduct.m_iMaxPpi,
                             iYdim, iXdim, &pVV, &iOut_vv);

    fnSaveBufrProductDataset(pBufrProduct->m_totalProduct.m_ppCappi, 
                             pBufrProduct->m_totalProduct.m_iMaxCappi,
                             iYdim, iXdim, &pVV, &iOut_vv);

    fnSaveBufrProductDataset(pBufrProduct->m_totalProduct.m_ppBase, 
                             pBufrProduct->m_totalProduct.m_iMaxBase,
                             iYdim, iXdim, &pVV, &iOut_vv);

    fnSaveBufrProductDataset(pBufrProduct->m_totalProduct.m_ppCmax, 
                             pBufrProduct->m_totalProduct.m_iMaxCmax,
                             iYdim, iXdim, &pVV, &iOut_vv);

    fnSaveBufrProductDataset(pBufrProduct->m_totalProduct.m_ppVil, 
                             pBufrProduct->m_totalProduct.m_iMaxVil,
                             iYdim, iXdim, &pVV, &iOut_vv);

    fnSaveBufrProductDataset(pBufrProduct->m_totalProduct.m_ppEtop, 
                             pBufrProduct->m_totalProduct.m_iMaxEtop,
                             iYdim, iXdim, &pVV, &iOut_vv);

    if(fnWriteBufr(pS1, descr, iOut_desc, pVV, szFileName) == FALSE)
        return FALSE;

    free_descs();
    free(pVV);

    return TRUE;
}

/* ================================================================================ */
// Function

BUFR_PRODUCT* fnInitBufrProduct(int iMaxField, int iMaxPpi, int iMaxCappi, int iMaxBase, int iMaxCmax, int iMaxVil, int iMaxEtop)
{
#define FN_INIT_BUFR_PRODUCT_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pBufrProduct != NULL) { fnFreeBufrProduct(pBufrProduct); }

    BUFR_PRODUCT*    pBufrProduct    = NULL;     // VARIABLE
    
    if(iMaxField <= 0)
        return NULL;

    pBufrProduct = (BUFR_PRODUCT *)calloc(1, sizeof(BUFR_PRODUCT));
    if(pBufrProduct == NULL)
        return NULL;

    if(iMaxPpi > 0 && iMaxPpi < RDR_DF_BUFR_PRODUCT_MAX)
    {
        pBufrProduct->m_totalProduct.m_iMaxPpi = iMaxPpi;
        pBufrProduct->m_totalProduct.m_ppPpi = fnInitBufrDataset("", iMaxPpi, iMaxField);
        if(pBufrProduct->m_totalProduct.m_ppPpi == NULL)
        {   FN_INIT_BUFR_PRODUCT_ERROR("fnInitBufrDataset free"); }
    }
    if(iMaxCappi > 0 && iMaxCappi < RDR_DF_BUFR_PRODUCT_MAX)
    {
        pBufrProduct->m_totalProduct.m_iMaxCappi = iMaxCappi;
        pBufrProduct->m_totalProduct.m_ppCappi = fnInitBufrDataset("", iMaxCappi, iMaxField);
        if(pBufrProduct->m_totalProduct.m_ppCappi == NULL)
        {   FN_INIT_BUFR_PRODUCT_ERROR("fnInitBufrDataset free"); }
    }
    if(iMaxBase > 0 && iMaxBase < RDR_DF_BUFR_PRODUCT_MAX)
    {
        pBufrProduct->m_totalProduct.m_iMaxBase = iMaxBase;
        pBufrProduct->m_totalProduct.m_ppBase = fnInitBufrDataset("", iMaxBase, iMaxField);
        if(pBufrProduct->m_totalProduct.m_ppBase == NULL)
        {   FN_INIT_BUFR_PRODUCT_ERROR("fnInitBufrDataset free"); }
    }
    if(iMaxCmax > 0 && iMaxCmax < RDR_DF_BUFR_PRODUCT_MAX)
    {
        pBufrProduct->m_totalProduct.m_iMaxCmax = iMaxCmax;
        pBufrProduct->m_totalProduct.m_ppCmax = fnInitBufrDataset("", iMaxCmax, iMaxField);
        if(pBufrProduct->m_totalProduct.m_ppCmax == NULL)
        {   FN_INIT_BUFR_PRODUCT_ERROR("fnInitBufrDataset free"); }
    }
    if(iMaxVil > 0 && iMaxVil < RDR_DF_BUFR_PRODUCT_MAX)
    {
        pBufrProduct->m_totalProduct.m_iMaxVil = iMaxVil;
        pBufrProduct->m_totalProduct.m_ppVil = fnInitBufrDataset("", iMaxVil, iMaxField);
        if(pBufrProduct->m_totalProduct.m_ppVil == NULL)
        {   FN_INIT_BUFR_PRODUCT_ERROR("fnInitBufrDataset free"); }
    }
    if(iMaxEtop > 0 && iMaxEtop < RDR_DF_BUFR_PRODUCT_MAX)
    {
        pBufrProduct->m_totalProduct.m_iMaxEtop = iMaxEtop;
        pBufrProduct->m_totalProduct.m_ppEtop = fnInitBufrDataset("", iMaxEtop, iMaxField);
        if(pBufrProduct->m_totalProduct.m_ppEtop == NULL)
        {   FN_INIT_BUFR_PRODUCT_ERROR("fnInitBufrDataset free"); }
    }

    return pBufrProduct;
}

void fnFreeBufrProduct(BUFR_PRODUCT *pBufrProduct)
{
    if(pBufrProduct != NULL)
    {
        if(pBufrProduct->m_totalProduct.m_iMaxPpi > 0)
        {
            fnFreeBufrDataset(pBufrProduct->m_totalProduct.m_ppPpi, 
                              pBufrProduct->m_totalProduct.m_iMaxPpi,
                              pBufrProduct->m_where.m_image_where.m_lYsize);
        }
        if(pBufrProduct->m_totalProduct.m_iMaxCappi > 0)
        {
            fnFreeBufrDataset(pBufrProduct->m_totalProduct.m_ppCappi,
                              pBufrProduct->m_totalProduct.m_iMaxCappi,
                              pBufrProduct->m_where.m_image_where.m_lYsize);
        }
        if(pBufrProduct->m_totalProduct.m_iMaxBase > 0)
        {
            fnFreeBufrDataset(pBufrProduct->m_totalProduct.m_ppBase,
                              pBufrProduct->m_totalProduct.m_iMaxBase,
                              pBufrProduct->m_where.m_image_where.m_lYsize);
        }
        if(pBufrProduct->m_totalProduct.m_iMaxCmax > 0)
        {
            fnFreeBufrDataset(pBufrProduct->m_totalProduct.m_ppCmax,
                              pBufrProduct->m_totalProduct.m_iMaxCmax,
                              pBufrProduct->m_where.m_image_where.m_lYsize);
        }
        if(pBufrProduct->m_totalProduct.m_iMaxVil > 0)
        {
            fnFreeBufrDataset(pBufrProduct->m_totalProduct.m_ppVil,
                              pBufrProduct->m_totalProduct.m_iMaxVil,
                              pBufrProduct->m_where.m_image_where.m_lYsize);
        }
        if(pBufrProduct->m_totalProduct.m_iMaxEtop > 0)
        {
            fnFreeBufrDataset(pBufrProduct->m_totalProduct.m_ppEtop,
                              pBufrProduct->m_totalProduct.m_iMaxEtop,
                              pBufrProduct->m_where.m_image_where.m_lYsize);
        }

        free(pBufrProduct);
    }
}

BUFR_PRODUCT* fnInitBufrProductToStdProduct(void *pStdPtr)
{
#define FN_INIT_BUFR_PRODUCT_TO_STD_PRODUCT_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pBufrProduct != NULL) { fnFreeBufrProduct(pBufrProduct); }

    STD_PRODUCT*    pStdProduct    = NULL;     // VARIABLE
    BUFR_PRODUCT*    pBufrProduct    = NULL;     // VARIABLE

    if(pStdPtr == NULL)
        return NULL;

    pStdProduct = (STD_PRODUCT *)pStdPtr;

    pBufrProduct = (BUFR_PRODUCT *)calloc(1, sizeof(BUFR_PRODUCT));
    if(pBufrProduct == NULL)
        return NULL;

    if(pStdProduct->m_totalProduct.m_iMaxPpi > 0 && 
       pStdProduct->m_totalProduct.m_iMaxPpi < RDR_DF_BUFR_PRODUCT_MAX)
    {
        pBufrProduct->m_totalProduct.m_iMaxPpi = pStdProduct->m_totalProduct.m_iMaxPpi;
        pBufrProduct->m_totalProduct.m_ppPpi 
        = fnInitBufrDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppPpi, 
                                        pStdProduct->m_totalProduct.m_iMaxPpi);
        if(pBufrProduct->m_totalProduct.m_ppPpi == NULL)
        {   FN_INIT_BUFR_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitBufrDatasetToStdDataset fail"); }
    }
    if(pStdProduct->m_totalProduct.m_iMaxCappi > 0 && 
       pStdProduct->m_totalProduct.m_iMaxCappi < RDR_DF_BUFR_PRODUCT_MAX)
    {
        pBufrProduct->m_totalProduct.m_iMaxCappi = pStdProduct->m_totalProduct.m_iMaxCappi;
        pBufrProduct->m_totalProduct.m_ppCappi 
        = fnInitBufrDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppCappi,
                                        pStdProduct->m_totalProduct.m_iMaxCappi);
        if(pBufrProduct->m_totalProduct.m_ppCappi == NULL)
        {   FN_INIT_BUFR_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitBufrDatasetToStdDataset fail"); }
    }
    if(pStdProduct->m_totalProduct.m_iMaxBase > 0 && 
       pStdProduct->m_totalProduct.m_iMaxBase < RDR_DF_BUFR_PRODUCT_MAX)
    {
        pBufrProduct->m_totalProduct.m_iMaxBase = pStdProduct->m_totalProduct.m_iMaxBase;
        pBufrProduct->m_totalProduct.m_ppBase 
        = fnInitBufrDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppBase,
                                        pStdProduct->m_totalProduct.m_iMaxBase);
        if(pBufrProduct->m_totalProduct.m_ppBase == NULL)
        {   FN_INIT_BUFR_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitBufrDatasetToStdDataset fail"); }
    }
    if(pStdProduct->m_totalProduct.m_iMaxCmax > 0 && 
       pStdProduct->m_totalProduct.m_iMaxCmax < RDR_DF_BUFR_PRODUCT_MAX)
    {
        pBufrProduct->m_totalProduct.m_iMaxCmax = pStdProduct->m_totalProduct.m_iMaxCmax;
        pBufrProduct->m_totalProduct.m_ppCmax 
        = fnInitBufrDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppCmax,
                                        pStdProduct->m_totalProduct.m_iMaxCmax);
        if(pBufrProduct->m_totalProduct.m_ppCmax == NULL)
        {   FN_INIT_BUFR_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitBufrDatasetToStdDataset fail"); }
    }
    if(pStdProduct->m_totalProduct.m_iMaxVil > 0 && 
       pStdProduct->m_totalProduct.m_iMaxVil < RDR_DF_BUFR_PRODUCT_MAX)
    {
        pBufrProduct->m_totalProduct.m_iMaxVil = pStdProduct->m_totalProduct.m_iMaxVil;
        pBufrProduct->m_totalProduct.m_ppVil 
        = fnInitBufrDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppVil,
                                        pStdProduct->m_totalProduct.m_iMaxVil);
        if(pBufrProduct->m_totalProduct.m_ppVil == NULL)
        {   FN_INIT_BUFR_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitBufrDatasetToStdDataset fail"); }
    }
    if(pStdProduct->m_totalProduct.m_iMaxEtop > 0 && 
       pStdProduct->m_totalProduct.m_iMaxEtop < RDR_DF_BUFR_PRODUCT_MAX)
    {
        pBufrProduct->m_totalProduct.m_iMaxEtop = pStdProduct->m_totalProduct.m_iMaxEtop;
        pBufrProduct->m_totalProduct.m_ppEtop 
        = fnInitBufrDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppEtop,
                                        pStdProduct->m_totalProduct.m_iMaxEtop);
        if(pBufrProduct->m_totalProduct.m_ppEtop == NULL)
        {   FN_INIT_BUFR_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitBufrDatasetToStdDataset fail"); }
    }

    return pBufrProduct;
}

int fnGetMaxCountBufrProduct(BUFR_PRODUCT *pBufrProduct, int *pMaxField, int *pMaxPpi, int *pMaxCappi, int *pMaxBase, int *pMaxCmax, int *pMaxVil, int *pMaxEtop)
{
    int     iDatasetIdx     = 0;
    int     iMaxDataset     = 0;
    int     iMaxField       = 0;

    if(pBufrProduct == NULL)
        return FALSE;

    if(pBufrProduct->m_totalProduct.m_iMaxPpi > 0 && 
       pBufrProduct->m_totalProduct.m_ppPpi != NULL)
    {
        iMaxDataset = pBufrProduct->m_totalProduct.m_iMaxPpi;
        for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
        {
            if((pBufrProduct->m_totalProduct.m_ppPpi[iDatasetIdx] != NULL) && 
               (iMaxField < pBufrProduct->m_totalProduct.m_ppPpi[iDatasetIdx]->m_iMaxField))
                iMaxField = pBufrProduct->m_totalProduct.m_ppPpi[iDatasetIdx]->m_iMaxField;
        }
    }
    if(pBufrProduct->m_totalProduct.m_iMaxCappi > 0 && 
       pBufrProduct->m_totalProduct.m_ppCappi != NULL)
    {
        iMaxDataset = pBufrProduct->m_totalProduct.m_iMaxCappi;
        for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
        {
            if((pBufrProduct->m_totalProduct.m_ppCappi[iDatasetIdx] != NULL) && 
               (iMaxField < pBufrProduct->m_totalProduct.m_ppCappi[iDatasetIdx]->m_iMaxField))
                iMaxField = pBufrProduct->m_totalProduct.m_ppCappi[iDatasetIdx]->m_iMaxField;
        }
    }
    if(pBufrProduct->m_totalProduct.m_iMaxBase > 0 && 
       pBufrProduct->m_totalProduct.m_ppBase != NULL)
    {
        iMaxDataset = pBufrProduct->m_totalProduct.m_iMaxBase;
        for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
        {
            if((pBufrProduct->m_totalProduct.m_ppBase[iDatasetIdx] != NULL) && 
               (iMaxField < pBufrProduct->m_totalProduct.m_ppBase[iDatasetIdx]->m_iMaxField))
                iMaxField = pBufrProduct->m_totalProduct.m_ppBase[iDatasetIdx]->m_iMaxField;
        }
    }
    if(pBufrProduct->m_totalProduct.m_iMaxCmax > 0 && 
       pBufrProduct->m_totalProduct.m_ppCmax != NULL)
    {
        iMaxDataset = pBufrProduct->m_totalProduct.m_iMaxCmax;
        for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
        {
            if((pBufrProduct->m_totalProduct.m_ppCmax[iDatasetIdx] != NULL) && 
               (iMaxField < pBufrProduct->m_totalProduct.m_ppCmax[iDatasetIdx]->m_iMaxField))
                iMaxField = pBufrProduct->m_totalProduct.m_ppCmax[iDatasetIdx]->m_iMaxField;
        }
    }
    if(pBufrProduct->m_totalProduct.m_iMaxVil > 0 && 
       pBufrProduct->m_totalProduct.m_ppVil != NULL)
    {
        iMaxDataset = pBufrProduct->m_totalProduct.m_iMaxVil;
        for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
        {
            if((pBufrProduct->m_totalProduct.m_ppVil[iDatasetIdx] != NULL) && 
               (iMaxField < pBufrProduct->m_totalProduct.m_ppVil[iDatasetIdx]->m_iMaxField))
                iMaxField = pBufrProduct->m_totalProduct.m_ppVil[iDatasetIdx]->m_iMaxField;
        }
    }
    if(pBufrProduct->m_totalProduct.m_iMaxEtop > 0 && 
       pBufrProduct->m_totalProduct.m_ppEtop != NULL)
    {
        iMaxDataset = pBufrProduct->m_totalProduct.m_iMaxEtop;
        for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
        {
            if((pBufrProduct->m_totalProduct.m_ppEtop[iDatasetIdx] != NULL) && 
               (iMaxField < pBufrProduct->m_totalProduct.m_ppEtop[iDatasetIdx]->m_iMaxField))
                iMaxField = pBufrProduct->m_totalProduct.m_ppEtop[iDatasetIdx]->m_iMaxField;
        }
    }

    if(pMaxPpi   != NULL) *pMaxPpi   = pBufrProduct->m_totalProduct.m_iMaxPpi;
    if(pMaxCappi != NULL) *pMaxCappi = pBufrProduct->m_totalProduct.m_iMaxCappi;
    if(pMaxBase  != NULL) *pMaxBase  = pBufrProduct->m_totalProduct.m_iMaxBase;
    if(pMaxCmax  != NULL) *pMaxCmax  = pBufrProduct->m_totalProduct.m_iMaxCmax;
    if(pMaxVil   != NULL) *pMaxVil   = pBufrProduct->m_totalProduct.m_iMaxVil;
    if(pMaxEtop  != NULL) *pMaxEtop  = pBufrProduct->m_totalProduct.m_iMaxEtop;
    if(pMaxField != NULL) *pMaxField = iMaxField;

    return TRUE;
}

int fnWriteBufrProduct(BUFR_PRODUCT *pBufrProduct, char* szFileName)
{
#define FN_WRITE_BUFR_PRODUCT_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG);

    char        szTemp[STR_LENGTH_MAX]  = "";
    struct tm   tempTm;
    sect_1_t    s1;

    if(pBufrProduct == NULL || szFileName == NULL)
        return FALSE;

    memset(&s1,     0x00, sizeof(sect_1_t));
    memset(&tempTm, 0x00, sizeof(struct tm));

    snprintf(szTemp, sizeof(szTemp), "%s%s", 
             pBufrProduct->m_what.m_szDate, pBufrProduct->m_what.m_szTime);
    strptime(szTemp, "%Y%m%d%H%M", &tempTm);

    s1.year = tempTm.tm_year+1900;
    s1.mon  = tempTm.tm_mon+1;
    s1.day  = tempTm.tm_mday;
    s1.hour = tempTm.tm_hour;
    s1.min  = tempTm.tm_min;
    s1.sec  = tempTm.tm_sec;

    s1.mtab     = 0;    /* master table used */
    s1.updsequ  = 0;    /* original BUFR message */
    s1.opsec    = 0;    /* no optional section */
    s1.dcat     = 6;    /* message type */
    s1.dcatst   = 0;    /* message subtype */
    s1.idcatst  = 2;    /* message subtype */

    if(fnRecodeBufrProducts(pBufrProduct, szFileName, &s1) == FALSE)
    {   FN_WRITE_BUFR_PRODUCT_ERROR("fnRecodeBufrProducts fail") return FALSE;  }

    return TRUE;
}




