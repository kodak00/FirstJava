/* ================================================================================ */
//
// Radar Csv Output Format & Output Function
//
// 2016.11.02 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function

static void fnMakeSiteCsvName(char *pBuf, int iBufLen, char *szProduct, char *szCsvFormat, char *szFieldName, int iProductIdx, double dProdpar_1)
{
    if(pBuf == NULL || szProduct == NULL || szCsvFormat == NULL || szFieldName == NULL)
        return;

    if(!strcmp(szProduct, "PPI"))
    {
        // format : RDR_SNQ??_PP??_SSS_YYYYMMDD.csv
        snprintf(pBuf, iBufLen, szCsvFormat, szFieldName, iProductIdx);
    }
    else if(!strcmp(szProduct, "CAPPI"))
    {
        // format : RDR_SNQ??_CP??_SSS_YYYYMMDD.csv
        snprintf(pBuf, iBufLen, szCsvFormat, szFieldName, (int)(dProdpar_1*10));
    }
    else
    {
        // format : RDR_SNQ??_BA_SSS_YYYYMMDD.csv
        // format : RDR_SNQ??_MX_SSS_YYYYMMDD.csv
        // format : RDR_SNQ??_VL_SSS_YYYYMMDD.csv
        // format : RDR_SNQ??_ET_SSS_YYYYMMDD.csv
        snprintf(pBuf, iBufLen, szCsvFormat, szFieldName);
    }
}

/* ================================================================================ */
// Function

int fnWriteStdProductCsvSite(STD_PRODUCT *pStdProduct, char *szProduct, char *szCsvFormat, char *szOutFile)
{
    STD_PRODUCT_DATASET     **ppDset                    = NULL;
    STD_PRODUCT_DATA        *pData                      = NULL;
    int                     iMaxDset                    = 0;
    int                     iDsetIdx                    = 0;
    int                     iFieldIdx                   = 0;
    double                  dProdpar_1                  = 0.0;
    char                    szCsvFile[STR_LENGTH_MAX]   = "";
    FILE                    *pFp                        = NULL;
    float                   **ppTemp                    = NULL;
    int                     iSiteYdim                   = 0;
    int                     iSiteXdim                   = 0;
    int                     iYIdx                       = 0;
    int                     iXIdx                       = 0;
    char                    szCmd[STR_LENGTH_MAX]       = "";

    if(pStdProduct == NULL || szProduct == NULL || szOutFile == NULL)
        return FALSE;

    ppDset = fnFindDsetStdProduct(pStdProduct, szProduct, &iMaxDset);
    if(ppDset == NULL)
        return FALSE;

    iSiteYdim = (int)pStdProduct->m_product_hdr.m_lYsize;
    iSiteXdim = (int)pStdProduct->m_product_hdr.m_lXsize;

    for(iDsetIdx = 0; iDsetIdx < iMaxDset; iDsetIdx++)
    {
        if(ppDset[iDsetIdx] == NULL)                  continue;
        if(ppDset[iDsetIdx]->m_ppProductData == NULL) continue;

        fnGetStdProductProdpar(pStdProduct, szProduct, iDsetIdx, &dProdpar_1, NULL);

        for(iFieldIdx = 0; iFieldIdx < ppDset[iDsetIdx]->m_iMaxField; iFieldIdx++)
        {
            pData = ppDset[iDsetIdx]->m_ppProductData[iFieldIdx];
            if(pData == NULL) continue;

            ppTemp = NULL;
            ppTemp = fnGetStdProductDataByIdx(pStdProduct, szProduct, 
                                              iDsetIdx, pData->m_szFieldName);
            if(ppTemp == NULL) continue;

            fnMakeSiteCsvName(szCsvFile, sizeof(szCsvFile), szProduct, 
                              szCsvFormat, pData->m_szFieldName, iDsetIdx, dProdpar_1);

            pFp = NULL;
            if((pFp = fopen(szCsvFile, "wt")) == NULL)
            {
                fnFreeMatrix2D((void **)ppTemp, iSiteYdim);
                continue;
            }
            
            // HEAD
            fprintf(pFp, "product=%s\r\n",          szProduct);
            fprintf(pFp, "data_type=%s\r\n",        pData->m_szFieldName);
            fprintf(pFp, "xdim=%d\r\n",             iSiteXdim);
            fprintf(pFp, "ydim=%d\r\n",             iSiteYdim);
            fprintf(pFp, "lat=%f\r\n",              pStdProduct->m_product_hdr.m_dLat);
            fprintf(pFp, "lon=%f\r\n",              pStdProduct->m_product_hdr.m_dLon);
            fprintf(pFp, "grid=%f\r\n",             pStdProduct->m_product_hdr.m_dXscale);
            fprintf(pFp, "no_echo_val=%f\r\n",      RDR_DF_BAD_VALUE_F);
            fprintf(pFp, "out_bound_val=%f\r\n",    RDR_DF_OUT_BOUND_F);
            fprintf(pFp, "\r\n");
            
            for(iYIdx = 0; iYIdx < iSiteYdim; iYIdx++)
            {
                for(iXIdx = 0; iXIdx < iSiteXdim; iXIdx++)
                {
                    if(iXIdx < iSiteXdim-1)
                        fprintf(pFp, "%.2f,", ppTemp[iYIdx][iXIdx]);
                    else
                        fprintf(pFp, "%.2f\r\n", ppTemp[iYIdx][iXIdx]);
                }
            }
            fclose(pFp);
            fnFreeMatrix2D((void **)ppTemp, iSiteYdim);

            snprintf(szCmd, sizeof(szCmd), "zip -j %s.zip %s", szOutFile, szCsvFile);
            fprintf(stdout, "%s : %s\n", __func__, szCmd);
            system(szCmd);

            snprintf(szCmd, sizeof(szCmd), "rm %s", szCsvFile);
            fprintf(stdout, "%s : %s\n", __func__, szCmd);
            system(szCmd);
        }
    }

    return TRUE;
}

int fnWriteStdProductCsvSite3D(STD_PRODUCT *pStdProduct, char *szProduct, char *szFieldName, int iCappiCnt, float fCrossGridKm, char *szOutFile)
{
    FILE            *pFp                    = NULL;
    float           **ppTemp                = NULL;
    int             iCappiIdx               = 0;
    int             iSiteYdim               = 0;
    int             iSiteXdim               = 0;
    int             iYIdx                   = 0;
    int             iXIdx                   = 0;
    char            szCmd[STR_LENGTH_MAX]   = "";

    if(pStdProduct == NULL || szProduct == NULL || szFieldName == NULL || szOutFile == NULL)
        return FALSE;

    iSiteYdim = (int)pStdProduct->m_product_hdr.m_lYsize;
    iSiteXdim = (int)pStdProduct->m_product_hdr.m_lXsize;

    if((pFp = fopen(szOutFile, "wt")) == NULL)
        return FALSE;

    // HEAD
    fprintf(pFp, "xdim=%ld\r\n",            pStdProduct->m_product_hdr.m_lXsize);
    fprintf(pFp, "ydim=%ld\r\n",            pStdProduct->m_product_hdr.m_lYsize);
    fprintf(pFp, "zdim=%d\r\n",             iCappiCnt);
    fprintf(pFp, "lat=%f\r\n",              pStdProduct->m_product_hdr.m_dLat);
    fprintf(pFp, "lon=%f\r\n",              pStdProduct->m_product_hdr.m_dLon);
    fprintf(pFp, "xy_grid_km=%f\r\n",       pStdProduct->m_product_hdr.m_dXscale);
    fprintf(pFp, "z_grid_km=%f\r\n",        fCrossGridKm);
    fprintf(pFp, "no_echo_val=%f\r\n",      RDR_DF_BAD_VALUE_F);
    fprintf(pFp, "out_bound_val=%f\r\n",    RDR_DF_OUT_BOUND_F);
    fprintf(pFp, "\r\n");

    for(iCappiIdx = 0; iCappiIdx < iCappiCnt; iCappiIdx++)
    {
        ppTemp = fnGetStdProductDataByIdx(pStdProduct, szProduct, iCappiIdx, szFieldName);
        if(ppTemp == NULL)
        {
            fclose(pFp);
            return FALSE;
        }

        for(iYIdx = 0; iYIdx < iSiteYdim; iYIdx++)
        {
            for(iXIdx = 0; iXIdx < iSiteXdim; iXIdx++)
            {
                if(iXIdx < iSiteXdim-1)
                    fprintf(pFp, "%.2f,", ppTemp[iYIdx][iXIdx]);
                else
                    fprintf(pFp, "%.2f\r\n", ppTemp[iYIdx][iXIdx]);
            }
        }
        fprintf(pFp, "\r\n");

        fnFreeMatrix2D((void **)ppTemp,  iSiteYdim);
        ppTemp = NULL;
    }

    fclose(pFp);

    snprintf(szCmd, sizeof(szCmd), "zip -j %s.zip %s", szOutFile, szOutFile);
    fprintf(stdout, "%s : %s\n", __func__, szCmd);
    system(szCmd);

    snprintf(szCmd, sizeof(szCmd), "rm %s", szOutFile);
    fprintf(stdout, "%s : %s\n", __func__, szCmd);
    system(szCmd);

    return TRUE;
}

int fnWriteStdProductCsvComp240(STD_PRODUCT *pStdProduct, char *szProduct, char *szFieldName, char *szOutFile)
{
    FILE    *pFp                    = NULL;
    float   **ppTemp                = NULL;
    char    **ppData                = NULL;
    int     iCompYdim               = 0;
    int     iCompXdim               = 0;
    int     iYIdx                   = 0;
    int     iXIdx                   = 0;
    char    szCmd[STR_LENGTH_MAX]   = "";

    if(pStdProduct == NULL || szProduct == NULL || szFieldName == NULL || szOutFile == NULL)
        return FALSE;

    iCompYdim = (int)pStdProduct->m_product_hdr.m_lYsize;
    iCompXdim = (int)pStdProduct->m_product_hdr.m_lXsize;
    if((ppTemp = fnGetStdProductDataByIdx(pStdProduct, szProduct, 0, szFieldName)) == NULL)
        return FALSE;

    if((ppData = fnMakeMatrix2D_C(iCompYdim, iCompXdim)) == NULL)
    {
        fnFreeMatrix2D((void **)ppTemp, iCompYdim);
        return FALSE;
    }

    for(iYIdx = 0; iYIdx < iCompYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iCompXdim; iXIdx++)
        {
            if(fabs(ppTemp[iYIdx][iXIdx] - RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
                ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_C;
            else if(fabs(ppTemp[iYIdx][iXIdx] - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_C;
            else
            {
                if(!strcmp(szProduct, "VIL"))
                    ppData[iYIdx][iXIdx] = (char)(ppTemp[iYIdx][iXIdx]+0.6);
                else
                    ppData[iYIdx][iXIdx] = (char)ppTemp[iYIdx][iXIdx];
            }
        }
    }

    if((pFp = fopen(szOutFile, "wt")) == NULL)
    {
        fnFreeMatrix2D((void **)ppTemp, iCompYdim);
        fnFreeMatrix2D((void **)ppData, iCompYdim);
        return FALSE;
    }

    // HEAD
    fprintf(pFp, "xdim=%ld\r\n",            pStdProduct->m_product_hdr.m_lXsize);
    fprintf(pFp, "ydim=%ld\r\n",            pStdProduct->m_product_hdr.m_lYsize);
    fprintf(pFp, "lat=%f\r\n",              pStdProduct->m_product_hdr.m_LL_lat);
    fprintf(pFp, "lon=%f\r\n",              pStdProduct->m_product_hdr.m_LL_lon);
    fprintf(pFp, "grid=%f\r\n",             pStdProduct->m_product_hdr.m_dXscale);
    fprintf(pFp, "no_echo_val=%d\r\n",      RDR_DF_BAD_VALUE_C);
    fprintf(pFp, "out_bound_val=%d\r\n",    RDR_DF_OUT_BOUND_C);
    fprintf(pFp, "\r\n");

    for(iYIdx = iCompYdim-1; iYIdx >= 0; iYIdx--)
    {
        for(iXIdx = 0; iXIdx < iCompXdim; iXIdx++)
        {
            if(iXIdx < iCompXdim-1)
                fprintf(pFp, "%d,", ppData[iYIdx][iXIdx]);
            else
                fprintf(pFp, "%d\r\n", ppData[iYIdx][iXIdx]);
        }
    }

    fclose(pFp);

    snprintf(szCmd, sizeof(szCmd), "zip -j %s.zip %s", szOutFile, szOutFile);
    fprintf(stdout, "%s : %s\n", __func__, szCmd);
    system(szCmd);

    snprintf(szCmd, sizeof(szCmd), "rm %s", szOutFile);
    fprintf(stdout, "%s : %s\n", __func__, szCmd);
    system(szCmd);

    fnFreeMatrix2D((void **)ppTemp, iCompYdim);
    fnFreeMatrix2D((void **)ppData, iCompYdim);

    return TRUE;
}

int fnWriteStdProductCsvComp480(STD_PRODUCT *pStdProduct, char *szProduct, char *szFieldName, char *szOutFile)
{
    FILE            *pFp                    = NULL;
    float           **ppTemp                = NULL;
    float           **ppData                = NULL;
    unsigned char   **ppBound               = NULL;
    int             iCompYdim               = 0;
    int             iCompXdim               = 0;
    int             iYIdx                   = 0;
    int             iXIdx                   = 0;
    char            szCmd[STR_LENGTH_MAX]   = "";

    if(pStdProduct == NULL || szProduct == NULL || szFieldName == NULL || szOutFile == NULL)
        return FALSE;

    iCompYdim = (int)pStdProduct->m_product_hdr.m_lYsize;
    iCompXdim = (int)pStdProduct->m_product_hdr.m_lXsize;
    if((ppTemp = fnGetStdProductDataByIdx(pStdProduct, szProduct, 0, szFieldName)) == NULL)
        return FALSE;

    if((ppData = fnMakeMatrix2D_F(iCompYdim, iCompXdim)) == NULL)
    {
        fnFreeMatrix2D((void **)ppTemp, iCompYdim);
        return FALSE;
    }

    if((ppBound = fnMakeMatrix2D_UC(iCompYdim, iCompXdim)) == NULL)
    {
        fnFreeMatrix2D((void **)ppTemp, iCompYdim);
        fnFreeMatrix2D((void **)ppData, iCompYdim);
        return FALSE;
    }

    for(iYIdx = 0; iYIdx < iCompYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iCompXdim; iXIdx++)
        {
            if(fabs(ppTemp[iYIdx][iXIdx] - RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
            {
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
                ppBound[iYIdx][iXIdx] = RDR_EN_OUT_BOUND;
            }
            else if(fabs(ppTemp[iYIdx][iXIdx] - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
            {
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
                ppBound[iYIdx][iXIdx] = RDR_EN_IN_BOUND;
            }
            else
            {
                if(!strcmp(szFieldName, "CZ") || !strcmp(szFieldName, "DZ"))
                {
                    ppData[iYIdx][iXIdx] = (float)fnDbzToRainF((double)ppTemp[iYIdx][iXIdx],
                                                               RDR_DF_DFLT_ZR_A,
                                                               RDR_DF_DFLT_ZR_B);
                }
                else
                    ppData[iYIdx][iXIdx] = ppTemp[iYIdx][iXIdx];

                ppBound[iYIdx][iXIdx] = RDR_EN_IN_BOUND;
            }
        }
    }

    if((pFp = fopen(szOutFile, "wt")) == NULL)
    {
        fnFreeMatrix2D((void **)ppTemp,  iCompYdim);
        fnFreeMatrix2D((void **)ppData,  iCompYdim);
        fnFreeMatrix2D((void **)ppBound, iCompYdim);
        return FALSE;
    }

    // HEAD
    fprintf(pFp, "xdim=%ld\r\n",            pStdProduct->m_product_hdr.m_lXsize);
    fprintf(pFp, "ydim=%ld\r\n",            pStdProduct->m_product_hdr.m_lYsize);
    fprintf(pFp, "lat=%f\r\n",              pStdProduct->m_product_hdr.m_LL_lat);
    fprintf(pFp, "lon=%f\r\n",              pStdProduct->m_product_hdr.m_LL_lon);
    fprintf(pFp, "grid=%f\r\n",             pStdProduct->m_product_hdr.m_dXscale);
    fprintf(pFp, "no_echo_val=%f\r\n",      RDR_DF_BAD_VALUE_F);
    fprintf(pFp, "in_bound_pos=%d\r\n",     RDR_EN_IN_BOUND);
    fprintf(pFp, "out_bound_pos=%d\r\n",    RDR_EN_OUT_BOUND);
    fprintf(pFp, "radar_center=%d\r\n",     RDR_EN_RADAR_POSITION);
    fprintf(pFp, "\r\n");

    for(iYIdx = iCompYdim-1; iYIdx >= 0; iYIdx--)
    {
        for(iXIdx = 0; iXIdx < iCompXdim; iXIdx++)
        {
            if(iXIdx < iCompXdim-1)
                fprintf(pFp, "%.2f,", ppData[iYIdx][iXIdx]);
            else
                fprintf(pFp, "%.2f\r\n", ppData[iYIdx][iXIdx]);
        }
    }
    fprintf(pFp, "\r\n");
    for(iYIdx = iCompYdim-1; iYIdx >= 0; iYIdx--)
    {
        for(iXIdx = 0; iXIdx < iCompXdim; iXIdx++)
        {
            if(iXIdx < iCompXdim-1)
                fprintf(pFp, "%d,", ppBound[iYIdx][iXIdx]);
            else
                fprintf(pFp, "%d\r\n", ppBound[iYIdx][iXIdx]);
        }
    }

    fclose(pFp);

    snprintf(szCmd, sizeof(szCmd), "zip -j %s.zip %s", szOutFile, szOutFile);
    fprintf(stdout, "%s : %s\n", __func__, szCmd);
    system(szCmd);

    snprintf(szCmd, sizeof(szCmd), "rm %s", szOutFile);
    fprintf(stdout, "%s : %s\n", __func__, szCmd);
    system(szCmd);

    fnFreeMatrix2D((void **)ppTemp,  iCompYdim);
    fnFreeMatrix2D((void **)ppData,  iCompYdim);
    fnFreeMatrix2D((void **)ppBound, iCompYdim);

    return TRUE;
}

int fnWriteStdProductCsvCompKCJ(STD_PRODUCT *pStdProduct, char *szProduct, char *szFieldName, char *szOutFile)
{
    FILE            *pFp                    = NULL;
    float           **ppTemp                = NULL;
    float           **ppData                = NULL;
    int             iCompYdim               = 0;
    int             iCompXdim               = 0;
    int             iYIdx                   = 0;
    int             iXIdx                   = 0;
    char            szCmd[STR_LENGTH_MAX]   = "";

    if(pStdProduct == NULL || szProduct == NULL || szFieldName == NULL || szOutFile == NULL)
        return FALSE;

    iCompYdim = (int)pStdProduct->m_product_hdr.m_lYsize;
    iCompXdim = (int)pStdProduct->m_product_hdr.m_lXsize;
    if((ppTemp = fnGetStdProductDataByIdx(pStdProduct, szProduct, 0, szFieldName)) == NULL)
        return FALSE;

    if((ppData = fnMakeMatrix2D_F(iCompYdim, iCompXdim)) == NULL)
    {
        fnFreeMatrix2D((void **)ppTemp, iCompYdim);
        return FALSE;
    }

    for(iYIdx = 0; iYIdx < iCompYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iCompXdim; iXIdx++)
        {
            if(fabs(ppTemp[iYIdx][iXIdx] - RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
                ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
            else if(fabs(ppTemp[iYIdx][iXIdx] - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
            else
            {
                if(!strcmp(szFieldName, "CZ") || !strcmp(szFieldName, "DZ"))
                {
                    ppData[iYIdx][iXIdx] = (float)fnDbzToRainF((double)ppTemp[iYIdx][iXIdx],
                                                               RDR_DF_DFLT_ZR_A,
                                                               RDR_DF_DFLT_ZR_B);
                }
                else
                    ppData[iYIdx][iXIdx] = ppTemp[iYIdx][iXIdx];
            }
        }
    }

    if((pFp = fopen(szOutFile, "wt")) == NULL)
    {
        fnFreeMatrix2D((void **)ppTemp,  iCompYdim);
        fnFreeMatrix2D((void **)ppData,  iCompYdim);
        return FALSE;
    }

    // HEAD
    fprintf(pFp, "xdim=%ld\r\n",            pStdProduct->m_product_hdr.m_lXsize);
    fprintf(pFp, "ydim=%ld\r\n",            pStdProduct->m_product_hdr.m_lYsize);
    fprintf(pFp, "lat=%f\r\n",              pStdProduct->m_product_hdr.m_LL_lat);
    fprintf(pFp, "lon=%f\r\n",              pStdProduct->m_product_hdr.m_LL_lon);
    fprintf(pFp, "grid=%f\r\n",             pStdProduct->m_product_hdr.m_dXscale);
    fprintf(pFp, "no_echo_val=%f\r\n",      RDR_DF_BAD_VALUE_F);
    fprintf(pFp, "out_bound_val=%f\r\n",    RDR_DF_OUT_BOUND_F);
    fprintf(pFp, "\r\n");

    for(iYIdx = iCompYdim-1; iYIdx >= 0; iYIdx--)
    {
        for(iXIdx = 0; iXIdx < iCompXdim; iXIdx++)
        {
            if(iXIdx < iCompXdim-1)
                fprintf(pFp, "%.2f,", ppData[iYIdx][iXIdx]);
            else
                fprintf(pFp, "%.2f\r\n", ppData[iYIdx][iXIdx]);
        }
    }
    fclose(pFp);

    snprintf(szCmd, sizeof(szCmd), "zip -j %s.zip %s", szOutFile, szOutFile);
    fprintf(stdout, "%s : %s\n", __func__, szCmd);
    system(szCmd);

    snprintf(szCmd, sizeof(szCmd), "rm %s", szOutFile);
    fprintf(stdout, "%s : %s\n", __func__, szCmd);
    system(szCmd);

    fnFreeMatrix2D((void **)ppTemp,  iCompYdim);
    fnFreeMatrix2D((void **)ppData,  iCompYdim);

    return TRUE;
}

int fnWriteStdProductCsvComp3D(STD_PRODUCT *pStdProduct, char *szProduct, char *szFieldName, int iCappiCnt, float fCrossGridKm, char *szOutFile)
{
    FILE            *pFp                    = NULL;
    float           **ppTemp                = NULL;
    char            **ppData                = NULL;
    unsigned char   **ppBound               = NULL;
    int             iCappiIdx               = 0;
    int             iCompYdim               = 0;
    int             iCompXdim               = 0;
    int             iYIdx                   = 0;
    int             iXIdx                   = 0;
    char            szCmd[STR_LENGTH_MAX]   = "";

    if(pStdProduct == NULL || szProduct == NULL || szFieldName == NULL || szOutFile == NULL)
        return FALSE;

    iCompYdim = (int)pStdProduct->m_product_hdr.m_lYsize;
    iCompXdim = (int)pStdProduct->m_product_hdr.m_lXsize;

    if((ppData = fnMakeMatrix2D_C(iCompYdim, iCompXdim)) == NULL)
    {
        return FALSE;
    }

    if((ppBound = fnMakeMatrix2D_UC(iCompYdim, iCompXdim)) == NULL)
    {
        fnFreeMatrix2D((void **)ppData, iCompYdim);
        return FALSE;
    }

    if((pFp = fopen(szOutFile, "wt")) == NULL)
    {
        fnFreeMatrix2D((void **)ppData,  iCompYdim);
        fnFreeMatrix2D((void **)ppBound, iCompYdim);
        return FALSE;
    }

    // HEAD
    fprintf(pFp, "xdim=%ld\r\n",            pStdProduct->m_product_hdr.m_lXsize);
    fprintf(pFp, "ydim=%ld\r\n",            pStdProduct->m_product_hdr.m_lYsize);
    fprintf(pFp, "zdim=%d\r\n",             iCappiCnt);
    fprintf(pFp, "lat=%f\r\n",              pStdProduct->m_product_hdr.m_LL_lat);
    fprintf(pFp, "lon=%f\r\n",              pStdProduct->m_product_hdr.m_LL_lon);
    fprintf(pFp, "xy_grid_km=%f\r\n",       pStdProduct->m_product_hdr.m_dXscale);
    fprintf(pFp, "z_grid_km=%f\r\n",        fCrossGridKm);
    fprintf(pFp, "no_echo_val=%d\r\n",      RDR_DF_BAD_VALUE_C);
    fprintf(pFp, "in_bound_pos=%d\r\n",     RDR_EN_IN_BOUND);
    fprintf(pFp, "out_bound_pos=%d\r\n",    RDR_EN_OUT_BOUND);
    fprintf(pFp, "radar_center=%d\r\n",     RDR_EN_RADAR_POSITION);
    fprintf(pFp, "\r\n");

    for(iCappiIdx = 0; iCappiIdx < iCappiCnt; iCappiIdx++)
    {
        ppTemp = fnGetStdProductDataByIdx(pStdProduct, szProduct, iCappiIdx, szFieldName);
        if(ppTemp == NULL)
        {
            fnFreeMatrix2D((void **)ppData,  iCompYdim);
            fnFreeMatrix2D((void **)ppBound, iCompYdim);
            fclose(pFp);
            return FALSE;
        }

        for(iYIdx = 0; iYIdx < iCompYdim; iYIdx++)
        {
            for(iXIdx = 0; iXIdx < iCompXdim; iXIdx++)
            {
                if(fabs(ppTemp[iYIdx][iXIdx] - RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
                {
                    ppData[iYIdx][iXIdx]  = RDR_DF_BAD_VALUE_C;
                    ppBound[iYIdx][iXIdx] = RDR_EN_OUT_BOUND;
                }
                else if(fabs(ppTemp[iYIdx][iXIdx] - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
                {
                    ppData[iYIdx][iXIdx]  = RDR_DF_BAD_VALUE_C;
                    ppBound[iYIdx][iXIdx] = RDR_EN_IN_BOUND;
                }
                else
                {
                    ppData[iYIdx][iXIdx]  = (char)ppTemp[iYIdx][iXIdx];
                    ppBound[iYIdx][iXIdx] = RDR_EN_IN_BOUND;
                }
            }
        }

        for(iYIdx = iCompYdim-1; iYIdx >= 0; iYIdx--)
        {
            for(iXIdx = 0; iXIdx < iCompXdim; iXIdx++)
            {
                if(iXIdx < iCompXdim-1)
                    fprintf(pFp, "%d,", ppData[iYIdx][iXIdx]);
                else
                    fprintf(pFp, "%d\r\n", ppData[iYIdx][iXIdx]);
            }
        }
        fprintf(pFp, "\r\n");
        fnFreeMatrix2D((void **)ppTemp,  iCompYdim);
        ppTemp = NULL;
    }

    fprintf(pFp, "\r\n");

    for(iYIdx = iCompYdim-1; iYIdx >= 0; iYIdx--)
    {
        for(iXIdx = 0; iXIdx < iCompXdim; iXIdx++)
        {
            if(iXIdx < iCompXdim-1)
                fprintf(pFp, "%d,", ppBound[iYIdx][iXIdx]);
            else
                fprintf(pFp, "%d\r\n", ppBound[iYIdx][iXIdx]);
        }
    }

    fclose(pFp);

    snprintf(szCmd, sizeof(szCmd), "zip -j %s.zip %s", szOutFile, szOutFile);
    fprintf(stdout, "%s : %s\n", __func__, szCmd);
    system(szCmd);

    snprintf(szCmd, sizeof(szCmd), "rm %s", szOutFile);
    fprintf(stdout, "%s : %s\n", __func__, szCmd);
    system(szCmd);

    fnFreeMatrix2D((void **)ppData,  iCompYdim);
    fnFreeMatrix2D((void **)ppBound, iCompYdim);

    return TRUE;
}


