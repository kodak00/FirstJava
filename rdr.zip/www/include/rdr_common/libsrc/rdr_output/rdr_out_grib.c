/* ================================================================================ */
//
// Radar GRIB2 Output Format & Output Function
//
// 2016.10.31 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"

#include <grib_api.h>

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function

static void fnFreeGribDataset(GRIB_PRODUCT_DATASET **ppGribDataset, int iMaxDataset, int iYdim)
{
    int                 iDatasetIdx         = 0;
    int                 iMaxField           = 0;
    int                 iFieldIdx           = 0;

    if(ppGribDataset != NULL)
    {
        for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
        {
            if(ppGribDataset[iDatasetIdx] != NULL)
            {
                if(ppGribDataset[iDatasetIdx]->m_ppProductData != NULL)
                {
                    iMaxField = ppGribDataset[iDatasetIdx]->m_iMaxField;

                    for(iFieldIdx = 0; iFieldIdx < iMaxField; iFieldIdx++)
                    {
                        if(ppGribDataset[iDatasetIdx]->m_ppProductData[iFieldIdx] != NULL)
                        {
                            if(ppGribDataset[iDatasetIdx]->
                               m_ppProductData[iFieldIdx]->m_ppData_c != NULL)
                            {
                                fnFreeMatrix2D((void **)ppGribDataset[iDatasetIdx]->
                                               m_ppProductData[iFieldIdx]->m_ppData_c, iYdim);
                            }
                            if(ppGribDataset[iDatasetIdx]->
                               m_ppProductData[iFieldIdx]->m_ppData_s != NULL)
                            {
                                fnFreeMatrix2D((void **)ppGribDataset[iDatasetIdx]->
                                               m_ppProductData[iFieldIdx]->m_ppData_s, iYdim);
                            }
                            if(ppGribDataset[iDatasetIdx]->
                               m_ppProductData[iFieldIdx]->m_ppData_f != NULL)
                            {
                                fnFreeMatrix2D((void **)ppGribDataset[iDatasetIdx]->
                                               m_ppProductData[iFieldIdx]->m_ppData_f, iYdim);
                            }
                            free(ppGribDataset[iDatasetIdx]->m_ppProductData[iFieldIdx]);
                        }
                    }
                    free(ppGribDataset[iDatasetIdx]->m_ppProductData);
                }
                free(ppGribDataset[iDatasetIdx]);
            }
        }
        free(ppGribDataset);
    }
}

static GRIB_PRODUCT_DATASET** fnInitGribDatasetToStdDataset(STD_PRODUCT_DATASET **ppStdDataset, int iMaxDataset)
{
    GRIB_PRODUCT_DATASET    **ppGribDataset = NULL;
    int                     iDatasetIdx     = 0;
    int                     iFieldIdx       = 0;

    if(ppStdDataset == NULL || iMaxDataset <= 0)
        return NULL;

    ppGribDataset 
    = (GRIB_PRODUCT_DATASET **)calloc(iMaxDataset, sizeof(GRIB_PRODUCT_DATASET *));
    if(ppGribDataset == NULL)
        return NULL;

    for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
    {
        ppGribDataset[iDatasetIdx] 
        = (GRIB_PRODUCT_DATASET *)calloc(1, sizeof(GRIB_PRODUCT_DATASET));
        if(ppGribDataset[iDatasetIdx] == NULL)
        {
            fnFreeGribDataset(ppGribDataset, iMaxDataset, 0);
            return NULL;
        }
        ppGribDataset[iDatasetIdx]->m_iMaxField = ppStdDataset[iDatasetIdx]->m_iMaxField;

        ppGribDataset[iDatasetIdx]->m_ppProductData 
        = (GRIB_PRODUCT_DATA **)calloc(ppGribDataset[iDatasetIdx]->m_iMaxField, 
                                       sizeof(GRIB_PRODUCT_DATA *));
        if(ppGribDataset[iDatasetIdx]->m_ppProductData == NULL)
        {
            fnFreeGribDataset(ppGribDataset, iMaxDataset, 0);
            return NULL;
        }
        for(iFieldIdx = 0; iFieldIdx < ppGribDataset[iDatasetIdx]->m_iMaxField; iFieldIdx++)
        {
            ppGribDataset[iDatasetIdx]->m_ppProductData[iFieldIdx]
            = (GRIB_PRODUCT_DATA *)calloc(1, sizeof(GRIB_PRODUCT_DATA));
            if(ppGribDataset[iDatasetIdx]->m_ppProductData[iFieldIdx] == NULL)
            {
                fnFreeGribDataset(ppGribDataset, iMaxDataset, 0);
                return NULL;
            }
        }
    }

    return ppGribDataset;
}

static int fnGetGribProductDsetMaxData(GRIB_PRODUCT_DATASET **ppDset, int iMaxDset)
{
    int         iDsetIdx    = 0;
    int         iMaxData    = 0;

    if(ppDset == NULL)
        return -1;

    for(iDsetIdx = 0; iDsetIdx < iMaxDset; iDsetIdx++)
    {
        if(ppDset[iDsetIdx] == NULL)
            continue;

        if(iMaxData < ppDset[iDsetIdx]->m_iMaxField)
            iMaxData = ppDset[iDsetIdx]->m_iMaxField;
    }

    return iMaxData;
}

static GRIB_PRODUCT_DATASET** fnFindGribProduct(GRIB_PRODUCT *pGribProduct, char *szProduct, int *pMaxDset)
{
    GRIB_PRODUCT_DATASET    **ppDset                = NULL;
    int                     iMaxDset                = 0;

    if(pGribProduct == NULL || szProduct == NULL || pMaxDset == NULL)
        return NULL;

    if(!strcmp(szProduct, "PPI"))
    {
        ppDset      = pGribProduct->m_totalProduct.m_ppPpi;
        iMaxDset    = pGribProduct->m_totalProduct.m_iMaxPpi;
    }
    else if(!strcmp(szProduct, "CAPPI"))
    {
        ppDset      = pGribProduct->m_totalProduct.m_ppCappi;
        iMaxDset    = pGribProduct->m_totalProduct.m_iMaxCappi;
    }
    else if(!strcmp(szProduct, "BASE"))
    {
        ppDset      = pGribProduct->m_totalProduct.m_ppBase;
        iMaxDset    = pGribProduct->m_totalProduct.m_iMaxBase;
    }
    else if(!strcmp(szProduct, "CMAX"))
    {
        ppDset      = pGribProduct->m_totalProduct.m_ppCmax;
        iMaxDset    = pGribProduct->m_totalProduct.m_iMaxCmax;
    }
    else if(!strcmp(szProduct, "VIL"))
    {
        ppDset      = pGribProduct->m_totalProduct.m_ppVil;
        iMaxDset    = pGribProduct->m_totalProduct.m_iMaxVil;
    }
    else if(!strcmp(szProduct, "ETOP"))
    {
        ppDset      = pGribProduct->m_totalProduct.m_ppEtop;
        iMaxDset    = pGribProduct->m_totalProduct.m_iMaxEtop;
    }
    else
        return NULL;

    if(pMaxDset != NULL) *pMaxDset = iMaxDset;

    return ppDset;
}

static int fnWriteGribProductSetSection0(grib_handle *hGrib)
{
    if(hGrib == NULL)
        return FALSE;

    grib_set_long(hGrib, "parametersVersion",                   1);
    grib_set_long(hGrib, "truncateLaplacian",                   0);
    grib_set_long(hGrib, "truncateDegrees",                     0);
    grib_set_long(hGrib, "dummy",                               1);
    grib_set_long(hGrib, "changingPrecision",                   0);
    grib_set_long(hGrib, "unitsFactor",                         1);
    grib_set_long(hGrib, "unitsBias",                           0);
    grib_set_long(hGrib, "timeRangeIndicatorFromStepRange",     -1);
    grib_set_long(hGrib, "missingValue",                        -9999);
    grib_set_long(hGrib, "discipline",                          0);
    grib_set_long(hGrib, "editionNumber",                       2);

    return TRUE;
}

static int fnWriteGribProductSetSection1(grib_handle *hGrib, GRIB_PRODUCT *pGribProduct)
{
    char        szTemp[STR_LENGTH_MAX]  = "";
    int         dataDate                = 0;
    int         dataTime                = 0;
    struct tm   tm;

    if(hGrib == NULL || pGribProduct == NULL)
        return FALSE;

    memset(&tm, 0x00, sizeof(struct tm));

    snprintf(szTemp, sizeof(szTemp), "%s%s", 
             pGribProduct->m_what.m_szDate, pGribProduct->m_what.m_szTime);
    strptime(szTemp, "%Y%m%d%H%M%S", &tm);

    dataDate = atoi(pGribProduct->m_what.m_szDate);
    dataTime = (atoi(pGribProduct->m_what.m_szTime)/100);

    grib_set_long(hGrib, "centre",                              40);
    grib_set_long(hGrib, "subCentre",                           0);
    grib_set_long(hGrib, "tablesVersion",                       4);
    grib_set_long(hGrib, "localTablesVersion",                  0);
    grib_set_long(hGrib, "significanceOfReferenceTime",         3);
    grib_set_long(hGrib, "year",                                tm.tm_year);
    grib_set_long(hGrib, "month",                               tm.tm_mon);
    grib_set_long(hGrib, "day",                                 tm.tm_mday);
    grib_set_long(hGrib, "hour",                                tm.tm_hour);
    grib_set_long(hGrib, "minute",                              tm.tm_min);
    grib_set_long(hGrib, "second",                              tm.tm_sec);
    grib_set_long(hGrib, "dataDate",                            dataDate);
    grib_set_long(hGrib, "dataTime",                            dataTime);
    grib_set_long(hGrib, "productionStatusOfProcessedData",     0);
    grib_set_long(hGrib, "typeOfProcessedData",                 7);

    return TRUE;
}

static int fnWriteGribProductSetSection2(grib_handle *hGrib)
{
    if(hGrib == NULL)
        return FALSE;
    
    grib_set_long(hGrib, "grib2LocalSectionPresent",            1);
    grib_set_long(hGrib, "addEmptySection2",                    1);

    return TRUE;
}

static int fnWriteGribProductSetSection3(grib_handle *hGrib, GRIB_PRODUCT *pGribProduct, int iMaxData)
{
    long                lCx = 0;
    long                lCy = 0;


    if(hGrib == NULL || pGribProduct == NULL)
        return FALSE;
 
    lCx = pGribProduct->m_where.m_lXsize;
    lCy = pGribProduct->m_where.m_lYsize * iMaxData;

    grib_set_long(hGrib, "sourceOfGridDefinition",              0);
    grib_set_long(hGrib, "numberOfDataPoints",                  lCx*lCy);
    grib_set_long(hGrib, "numberOfOctectsForNumberOfPoints",    0);
    grib_set_long(hGrib, "interpretationOfNumberOfPoints",      0);
    grib_set_long(hGrib, "PLPresent",                           0);
    grib_set_long(hGrib, "gridDefinitionTemplateNumber",        110);
    grib_set_long(hGrib, "numberOfPointsAlongXAxis",            lCx);
    grib_set_long(hGrib, "numberOfPointsAlongYAxis",            lCy);

    return TRUE;
}

static int fnWriteGribProductSetSection4(grib_handle *hGrib, GRIB_PRODUCT *pGribProduct, GRIB_PRODUCT_DATASET **ppDset, int iMaxDset, int iMaxData)
{
    GRIB_PRODUCT_DATA   *pGribData              = NULL;
    long                lLon                    = 0;
    long                lLat                    = 0;
    int                 iElev                   = 0;
    long                lValue                  = 0;
    double              dValue                  = 0.0;
    size_t              len                     = 0;
    int                 off                     = 0;
    int                 iDataIdx                = 0;
    int                 iDsetIdx                = 0;
    double              *pProdPar               = NULL;
    char                szTemp[STR_LENGTH_MAX]  = "";

    if(hGrib == NULL || pGribProduct == NULL || ppDset == NULL)
        return FALSE;
 
    lLon    = (long)(pGribProduct->m_where.m_dLon * 1000000);
    lLat    = (long)(pGribProduct->m_where.m_dLat * 1000000);
    iElev   = (long)(pGribProduct->m_where.m_dHeightM);

    grib_set_long(hGrib, "timeRangeIndicator",                  0);
    grib_set_long(hGrib, "NV",                                  0);
    grib_set_long(hGrib, "neitherPresent",                      0);
    grib_set_long(hGrib, "productDefinitionTemplateNumber",     21);
    grib_set_long(hGrib, "parameterCategory",                   15);
    grib_set_long(hGrib, "parameterNumber",                     1);
    grib_set_long(hGrib, "typeOfGeneratingProcess",             8);
    grib_set_long(hGrib, "numberOfRadarSitesUsed",              0);
    grib_set_long(hGrib, "indicatorOfUnitOfTimeRange",          0);
    grib_set_long(hGrib, "stepUnits",                           1);
    grib_set_long(hGrib, "siteLatitude",                        lLat);
    grib_set_long(hGrib, "siteLongitude",                       lLon);
    grib_set_long(hGrib, "siteElevation",                       iElev);

    len = strlen(pGribProduct->m_where.m_szProjdef);
    grib_set_string(hGrib, "rdr_projdef", pGribProduct->m_where.m_szProjdef, &len);

    lValue = pGribProduct->m_where.m_lXsize;
    grib_set_long(hGrib, "rdr_xsize",                           lValue);

    lValue = pGribProduct->m_where.m_lYsize;
    grib_set_long(hGrib, "rdr_ysize",                           lValue);

    dValue = pGribProduct->m_where.m_dXscale;
    grib_set_double(hGrib, "rdr_xscale",                        dValue);

    dValue = pGribProduct->m_where.m_dYscale;
    grib_set_double(hGrib, "rdr_yscale",                        dValue);

    dValue = pGribProduct->m_where.m_LL_lon;
    grib_set_double(hGrib, "rdr_LL_Longitude",                  dValue);

    dValue = pGribProduct->m_where.m_LL_lat;
    grib_set_double(hGrib, "rdr_LL_Latitude",                   dValue);

    dValue = pGribProduct->m_where.m_UL_lon;
    grib_set_double(hGrib, "rdr_UL_Longitude",                  dValue);

    dValue = pGribProduct->m_where.m_UL_lat;
    grib_set_double(hGrib, "rdr_UL_Latitude",                   dValue);

    dValue = pGribProduct->m_where.m_UR_lon;
    grib_set_double(hGrib, "rdr_UR_Longitude",                  dValue);

    dValue = pGribProduct->m_where.m_UR_lat;
    grib_set_double(hGrib, "rdr_UR_Latitude",                   dValue);

    dValue = pGribProduct->m_where.m_LR_lon;
    grib_set_double(hGrib, "rdr_LR_Longitude",                  dValue);

    dValue = pGribProduct->m_where.m_LR_lat;
    grib_set_double(hGrib, "rdr_LR_Latitude",                   dValue);

    len = strlen(ppDset[0]->m_what.m_szProduct);
    grib_set_string(hGrib, "rdr_product", ppDset[0]->m_what.m_szProduct, &len);

    lValue = (long)iMaxDset;
    grib_set_long(hGrib, "rdr_max_product",                     lValue);

    lValue = (long)iMaxData;
    grib_set_long(hGrib, "rdr_max_data",                        lValue);

    lValue = (long)(iMaxDset*2);
    grib_set_long(hGrib, "rdr_prodpar_size",                    lValue);

    if((pProdPar = (double *)calloc(iMaxDset*2, sizeof(double))) == NULL)
        return FALSE;

    for(iDsetIdx = 0; iDsetIdx < iMaxDset; iDsetIdx++)
    {
        pProdPar[iDsetIdx]   = ppDset[iDsetIdx]->m_what.m_dProdpar[0];
        pProdPar[iDsetIdx+1] = ppDset[iDsetIdx]->m_what.m_dProdpar[1];
    }

    grib_set_double_array(hGrib, "rdr_prodpar", pProdPar, iMaxDset*2);
    free(pProdPar);

    len = 0;
    off = 0;
    for(iDsetIdx = 0; iDsetIdx < iMaxDset; iDsetIdx++)
    {
        if(ppDset[iDsetIdx] == NULL)
            return FALSE;

        for(iDataIdx = 0; iDataIdx < ppDset[iDsetIdx]->m_iMaxField; iDataIdx++)
        {
            pGribData = ppDset[iDsetIdx]->m_ppProductData[iDataIdx];

            if(pGribData == NULL)
                continue;

            if(pGribData->m_ppData_c == NULL && 
               pGribData->m_ppData_s == NULL &&
               pGribData->m_ppData_f == NULL)
                continue;

           len =  snprintf(&szTemp[off], sizeof(szTemp)-off, 
                           "%s,", pGribData->m_what.m_szQuantity);

            off += len;
        }

        szTemp[off-1] = 0;
        off--;

        if(iDsetIdx < iMaxDset - 1)
        {
            len = snprintf(&szTemp[off], sizeof(szTemp)-off, "/");
            off += len;
        }
    }

    len = strlen(szTemp);
    grib_set_string(hGrib, "rdr_quantity", szTemp, &len);

    grib_set_long(hGrib, "dummyc",                              0);
    grib_set_long(hGrib, "PVPresent",                           0);

    return TRUE;
}

static int fnWriteGribProductSetSection567(grib_handle *hGrib, grib_multi_handle *hMulti, GRIB_PRODUCT *pGribProduct, GRIB_PRODUCT_DATASET **ppDset, int iMaxDset, int iMaxData)
{
    GRIB_PRODUCT_DATA       *pGribData  = NULL;
    double                  *pBuf       = NULL;
    int                     iBufIdx     = 0;
    unsigned int            uiBufLen    = 0;
    int                     iYdim       = 0;
    int                     iXdim       = 0;
    int                     iYIdx       = 0;
    int                     iXIdx       = 0;
    int                     iDsetIdx    = 0;
    int                     iDataIdx    = 0;
    char                    cData       = 0;
    short                   sData       = 0;
    float                   fData       = 0.0;
    double                  dData       = 0.0;
    FIELD_MEM_INFO_TBL      memInfo;

    if(hGrib == NULL || pGribProduct == NULL || ppDset == NULL)
        return FALSE;

    iYdim = pGribProduct->m_where.m_lYsize;
    iXdim = pGribProduct->m_where.m_lXsize;

    uiBufLen = iYdim * iXdim * iMaxData;

    if((pBuf = (double *)calloc(uiBufLen, sizeof(double))) == NULL)
        return FALSE;

    for(iDsetIdx = 0; iDsetIdx < iMaxDset; iDsetIdx++)
    {
        if(ppDset[iDsetIdx] == NULL)
        {   free(pBuf); return FALSE; }

        iBufIdx = 0;
        for(iDataIdx = 0; iDataIdx < ppDset[iDsetIdx]->m_iMaxField; iDataIdx++)
        {
            pGribData = ppDset[iDsetIdx]->m_ppProductData[iDataIdx];

            if(pGribData == NULL)
                continue;

            if(pGribData->m_ppData_c == NULL && 
               pGribData->m_ppData_s == NULL &&
               pGribData->m_ppData_f == NULL)
                continue;
            
            memset(&memInfo, 0x00, sizeof(memInfo));
            if(fnGetFieldMemInfo(pGribData->m_szFieldName, &memInfo) == FALSE)
            {   free(pBuf); return FALSE; }

            for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
            {
                for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
                {
                    if(pGribData->m_iMemType == RDR_EN_MEM_CHAR)
                    {
                        cData = pGribData->m_ppData_c[iYIdx][iXIdx];

                        if(fabs(cData - memInfo.m_fOutBound) < RDR_DF_ERR_RANGE_F)
                            dData = pGribData->m_what.m_dNodata;
                        else if(fabs(cData - memInfo.m_fBadValue) < RDR_DF_ERR_RANGE_F)
                            dData = pGribData->m_what.m_dUndetect;
                        else
                            dData = ((cData/memInfo.m_fScale) - memInfo.m_fOffset);
                    }
                    else if(pGribData->m_iMemType == RDR_EN_MEM_SHORT)
                    {
                        sData = pGribData->m_ppData_s[iYIdx][iXIdx];

                        if(fabs(sData - memInfo.m_fOutBound) < RDR_DF_ERR_RANGE_F)
                            dData = pGribData->m_what.m_dNodata;
                        else if(fabs(sData - memInfo.m_fBadValue) < RDR_DF_ERR_RANGE_F)
                            dData = pGribData->m_what.m_dUndetect;
                        else
                            dData = ((sData/memInfo.m_fScale) - memInfo.m_fOffset);
                    }
                    else if(pGribData->m_iMemType == RDR_EN_MEM_FLOAT)
                    {
                        fData = pGribData->m_ppData_f[iYIdx][iXIdx];

                        if(fabs(fData - memInfo.m_fOutBound) < RDR_DF_ERR_RANGE_F)
                            dData = pGribData->m_what.m_dNodata;
                        else if(fabs(fData - memInfo.m_fBadValue) < RDR_DF_ERR_RANGE_F)
                            dData = pGribData->m_what.m_dUndetect;
                        else
                            dData = ((fData/memInfo.m_fScale) - memInfo.m_fOffset);
                    }

                    pBuf[iBufIdx++] = dData;
                }
            }
        }

        // SECTION 5
        grib_set_long(hGrib, "numberOfValues",                      uiBufLen);
        grib_set_long(hGrib, "dataRepresentationTemplateNumber",    0);
        grib_set_long(hGrib, "bitsPerValue",                        32);
        grib_set_long(hGrib, "typeOfOriginalFieldValues",           0);
        grib_set_long(hGrib, "representationMode",                  0);

        // SECTOIN 6
        grib_set_long(hGrib, "bitMapIndicator",                     255);
        grib_set_long(hGrib, "bitmapPresent",                       0);

        // SECTION 7
        grib_set_double_array(hGrib, "values", pBuf, uiBufLen);
        grib_set_long(hGrib, "bitsPerValue",                        32);
        grib_set_long(hGrib, "scaleValuesBy",                       1);
        grib_set_long(hGrib, "offsetValuesBy",                      0);

        grib_multi_handle_append(hGrib, 5, hMulti);
    }

    free(pBuf);

    return TRUE;
}

static GRIB_PRODUCT_DATASET** fnInitGribDataset(char *szProduct, int iMaxDataset, int iMaxField)
{
    GRIB_PRODUCT_DATASET **ppGribDataset = NULL;
    int                 iDatasetIdx     = 0;
    int                 iFieldIdx       = 0;

    if(szProduct == NULL || iMaxDataset <= 0 || iMaxField <= 0)
        return NULL;

    ppGribDataset = (GRIB_PRODUCT_DATASET **)calloc(iMaxDataset, sizeof(GRIB_PRODUCT_DATASET *));
    if(ppGribDataset == NULL)
        return NULL;

    for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
    {
        ppGribDataset[iDatasetIdx] 
        = (GRIB_PRODUCT_DATASET *)calloc(1, sizeof(GRIB_PRODUCT_DATASET));
        if(ppGribDataset[iDatasetIdx] == NULL)
        {
            fnFreeGribDataset(ppGribDataset, iMaxDataset, 0);
            return NULL;
        }
        snprintf(ppGribDataset[iDatasetIdx]->m_what.m_szProduct,
                 sizeof(ppGribDataset[iDatasetIdx]->m_what.m_szProduct), "%s", szProduct);
        ppGribDataset[iDatasetIdx]->m_iMaxField = iMaxField;

        ppGribDataset[iDatasetIdx]->m_ppProductData 
        = (GRIB_PRODUCT_DATA **)calloc(iMaxField, sizeof(GRIB_PRODUCT_DATA *));
        if(ppGribDataset[iDatasetIdx]->m_ppProductData == NULL)
        {
            fnFreeGribDataset(ppGribDataset, iMaxDataset, 0);
            return NULL;
        }
        for(iFieldIdx = 0; iFieldIdx < iMaxField; iFieldIdx++)
        {
            ppGribDataset[iDatasetIdx]->m_ppProductData[iFieldIdx]
            = (GRIB_PRODUCT_DATA *)calloc(1, sizeof(GRIB_PRODUCT_DATA));
            if(ppGribDataset[iDatasetIdx]->m_ppProductData[iFieldIdx] == NULL)
            {
                fnFreeGribDataset(ppGribDataset, iMaxDataset, 0);
                return NULL;
            }
        }
    }

    return ppGribDataset;
}

/* ================================================================================ */
// Function

GRIB_PRODUCT* fnInitGribProduct(int iMaxField, int iMaxPpi, int iMaxCappi, int iMaxBase, int iMaxCmax, int iMaxVil, int iMaxEtop)
{
#define FN_INIT_GRIB_PRODUCT_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pGribProduct != NULL) { fnFreeGribProduct(pGribProduct); }

    GRIB_PRODUCT*   pGribProduct    = NULL;     // VARIABLE
    
    if(iMaxField <= 0)
        return NULL;

    pGribProduct = (GRIB_PRODUCT *)calloc(1, sizeof(GRIB_PRODUCT));
    if(pGribProduct == NULL)
        return NULL;

    if(iMaxPpi > 0 && iMaxPpi < RDR_DF_GRIB_PRODUCT_MAX)
    {
        pGribProduct->m_totalProduct.m_iMaxPpi = iMaxPpi;
        pGribProduct->m_totalProduct.m_ppPpi   = fnInitGribDataset("", iMaxPpi, iMaxField);
        if(pGribProduct->m_totalProduct.m_ppPpi == NULL)
        {   FN_INIT_GRIB_PRODUCT_ERROR("fnInitGribDataset free"); }
    }
    if(iMaxCappi > 0 && iMaxCappi < RDR_DF_GRIB_PRODUCT_MAX)
    {
        pGribProduct->m_totalProduct.m_iMaxCappi = iMaxCappi;
        pGribProduct->m_totalProduct.m_ppCappi   = fnInitGribDataset("", iMaxCappi, iMaxField);
        if(pGribProduct->m_totalProduct.m_ppCappi == NULL)
        {   FN_INIT_GRIB_PRODUCT_ERROR("fnInitGribDataset free"); }
    }
    if(iMaxBase > 0 && iMaxBase < RDR_DF_GRIB_PRODUCT_MAX)
    {
        pGribProduct->m_totalProduct.m_iMaxBase = iMaxBase;
        pGribProduct->m_totalProduct.m_ppBase   = fnInitGribDataset("", iMaxBase, iMaxField);
        if(pGribProduct->m_totalProduct.m_ppBase == NULL)
        {   FN_INIT_GRIB_PRODUCT_ERROR("fnInitGribDataset free"); }
    }
    if(iMaxCmax > 0 && iMaxCmax < RDR_DF_GRIB_PRODUCT_MAX)
    {
        pGribProduct->m_totalProduct.m_iMaxCmax = iMaxCmax;
        pGribProduct->m_totalProduct.m_ppCmax   = fnInitGribDataset("", iMaxCmax, iMaxField);
        if(pGribProduct->m_totalProduct.m_ppCmax == NULL)
        {   FN_INIT_GRIB_PRODUCT_ERROR("fnInitGribDataset free"); }
    }
    if(iMaxVil > 0 && iMaxVil < RDR_DF_GRIB_PRODUCT_MAX)
    {
        pGribProduct->m_totalProduct.m_iMaxVil = iMaxVil;
        pGribProduct->m_totalProduct.m_ppVil   = fnInitGribDataset("", iMaxVil, iMaxField);
        if(pGribProduct->m_totalProduct.m_ppVil == NULL)
        {   FN_INIT_GRIB_PRODUCT_ERROR("fnInitGribDataset free"); }
    }
    if(iMaxEtop > 0 && iMaxEtop < RDR_DF_GRIB_PRODUCT_MAX)
    {
        pGribProduct->m_totalProduct.m_iMaxEtop = iMaxEtop;
        pGribProduct->m_totalProduct.m_ppEtop   = fnInitGribDataset("", iMaxEtop, iMaxField);
        if(pGribProduct->m_totalProduct.m_ppEtop == NULL)
        {   FN_INIT_GRIB_PRODUCT_ERROR("fnInitGribDataset free"); }
    }

    return pGribProduct;
}

void fnFreeGribProduct(GRIB_PRODUCT *pGribProduct)
{
    if(pGribProduct != NULL)
    {
        if(pGribProduct->m_totalProduct.m_iMaxPpi > 0)
        {
            fnFreeGribDataset(pGribProduct->m_totalProduct.m_ppPpi, 
                              pGribProduct->m_totalProduct.m_iMaxPpi,
                              pGribProduct->m_where.m_lYsize);
        }
        if(pGribProduct->m_totalProduct.m_iMaxCappi > 0)
        {
            fnFreeGribDataset(pGribProduct->m_totalProduct.m_ppCappi,
                              pGribProduct->m_totalProduct.m_iMaxCappi,
                              pGribProduct->m_where.m_lYsize);
        }
        if(pGribProduct->m_totalProduct.m_iMaxBase > 0)
        {
            fnFreeGribDataset(pGribProduct->m_totalProduct.m_ppBase,
                              pGribProduct->m_totalProduct.m_iMaxBase,
                              pGribProduct->m_where.m_lYsize);
        }
        if(pGribProduct->m_totalProduct.m_iMaxCmax > 0)
        {
            fnFreeGribDataset(pGribProduct->m_totalProduct.m_ppCmax,
                              pGribProduct->m_totalProduct.m_iMaxCmax,
                              pGribProduct->m_where.m_lYsize);
        }
        if(pGribProduct->m_totalProduct.m_iMaxVil > 0)
        {
            fnFreeGribDataset(pGribProduct->m_totalProduct.m_ppVil,
                              pGribProduct->m_totalProduct.m_iMaxVil,
                              pGribProduct->m_where.m_lYsize);
        }
        if(pGribProduct->m_totalProduct.m_iMaxEtop > 0)
        {
            fnFreeGribDataset(pGribProduct->m_totalProduct.m_ppEtop,
                              pGribProduct->m_totalProduct.m_iMaxEtop,
                              pGribProduct->m_where.m_lYsize);
        }

        free(pGribProduct);
    }
}

GRIB_PRODUCT* fnInitGribProductToStdProduct(void *pStdPtr)
{
#define FN_INIT_GRIB_PRODUCT_TO_STD_PRODUCT_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pGribProduct != NULL) { fnFreeGribProduct(pGribProduct); }

    STD_PRODUCT*    pStdProduct     = NULL;     // VARIABLE
    GRIB_PRODUCT*   pGribProduct    = NULL;     // VARIABLE

    if(pStdPtr == NULL)
        return NULL;

    pStdProduct = (STD_PRODUCT *)pStdPtr;

    pGribProduct = (GRIB_PRODUCT *)calloc(1, sizeof(GRIB_PRODUCT));
    if(pGribProduct == NULL)
        return NULL;

    if(pStdProduct->m_totalProduct.m_iMaxPpi > 0 && 
       pStdProduct->m_totalProduct.m_iMaxPpi < RDR_DF_GRIB_PRODUCT_MAX)
    {
        pGribProduct->m_totalProduct.m_iMaxPpi = pStdProduct->m_totalProduct.m_iMaxPpi;
        pGribProduct->m_totalProduct.m_ppPpi 
        = fnInitGribDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppPpi, 
                                        pStdProduct->m_totalProduct.m_iMaxPpi);
        if(pGribProduct->m_totalProduct.m_ppPpi == NULL)
        {   FN_INIT_GRIB_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitGribDatasetToStdDataset fail"); }
    }
    if(pStdProduct->m_totalProduct.m_iMaxCappi > 0 && 
       pStdProduct->m_totalProduct.m_iMaxCappi < RDR_DF_GRIB_PRODUCT_MAX)
    {
        pGribProduct->m_totalProduct.m_iMaxCappi = pStdProduct->m_totalProduct.m_iMaxCappi;
        pGribProduct->m_totalProduct.m_ppCappi 
        = fnInitGribDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppCappi,
                                        pStdProduct->m_totalProduct.m_iMaxCappi);
        if(pGribProduct->m_totalProduct.m_ppCappi == NULL)
        {   FN_INIT_GRIB_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitGribDatasetToStdDataset fail"); }
    }
    if(pStdProduct->m_totalProduct.m_iMaxBase > 0 && 
       pStdProduct->m_totalProduct.m_iMaxBase < RDR_DF_GRIB_PRODUCT_MAX)
    {
        pGribProduct->m_totalProduct.m_iMaxBase = pStdProduct->m_totalProduct.m_iMaxBase;
        pGribProduct->m_totalProduct.m_ppBase 
        = fnInitGribDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppBase,
                                        pStdProduct->m_totalProduct.m_iMaxBase);
        if(pGribProduct->m_totalProduct.m_ppBase == NULL)
        {   FN_INIT_GRIB_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitGribDatasetToStdDataset fail"); }
    }
    if(pStdProduct->m_totalProduct.m_iMaxCmax > 0 && 
       pStdProduct->m_totalProduct.m_iMaxCmax < RDR_DF_GRIB_PRODUCT_MAX)
    {
        pGribProduct->m_totalProduct.m_iMaxCmax = pStdProduct->m_totalProduct.m_iMaxCmax;
        pGribProduct->m_totalProduct.m_ppCmax 
        = fnInitGribDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppCmax,
                                        pStdProduct->m_totalProduct.m_iMaxCmax);
        if(pGribProduct->m_totalProduct.m_ppCmax == NULL)
        {   FN_INIT_GRIB_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitGribDatasetToStdDataset fail"); }
    }
    if(pStdProduct->m_totalProduct.m_iMaxVil > 0 && 
       pStdProduct->m_totalProduct.m_iMaxVil < RDR_DF_GRIB_PRODUCT_MAX)
    {
        pGribProduct->m_totalProduct.m_iMaxVil = pStdProduct->m_totalProduct.m_iMaxVil;
        pGribProduct->m_totalProduct.m_ppVil 
        = fnInitGribDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppVil,
                                        pStdProduct->m_totalProduct.m_iMaxVil);
        if(pGribProduct->m_totalProduct.m_ppVil == NULL)
        {   FN_INIT_GRIB_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitGribDatasetToStdDataset fail"); }
    }
    if(pStdProduct->m_totalProduct.m_iMaxEtop > 0 && 
       pStdProduct->m_totalProduct.m_iMaxEtop < RDR_DF_GRIB_PRODUCT_MAX)
    {
        pGribProduct->m_totalProduct.m_iMaxEtop = pStdProduct->m_totalProduct.m_iMaxEtop;
        pGribProduct->m_totalProduct.m_ppEtop 
        = fnInitGribDatasetToStdDataset(pStdProduct->m_totalProduct.m_ppEtop,
                                        pStdProduct->m_totalProduct.m_iMaxEtop);
        if(pGribProduct->m_totalProduct.m_ppEtop == NULL)
        {   FN_INIT_GRIB_PRODUCT_TO_STD_PRODUCT_ERROR("fnInitGribDatasetToStdDataset fail"); }
    }

    return pGribProduct;
}

int fnGetMaxCountGribProduct(GRIB_PRODUCT *pGribProduct, int *pMaxField, int *pMaxPpi, int *pMaxCappi, int *pMaxBase, int *pMaxCmax, int *pMaxVil, int *pMaxEtop)
{
    int     iDatasetIdx     = 0;
    int     iMaxDataset     = 0;
    int     iMaxField       = 0;

    if(pGribProduct == NULL)
        return FALSE;

    if(pGribProduct->m_totalProduct.m_iMaxPpi > 0 && 
       pGribProduct->m_totalProduct.m_ppPpi != NULL)
    {
        iMaxDataset = pGribProduct->m_totalProduct.m_iMaxPpi;
        for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
        {
            if((pGribProduct->m_totalProduct.m_ppPpi[iDatasetIdx] != NULL) && 
               (iMaxField < pGribProduct->m_totalProduct.m_ppPpi[iDatasetIdx]->m_iMaxField))
                iMaxField = pGribProduct->m_totalProduct.m_ppPpi[iDatasetIdx]->m_iMaxField;
        }
    }
    if(pGribProduct->m_totalProduct.m_iMaxCappi > 0 && 
       pGribProduct->m_totalProduct.m_ppCappi != NULL)
    {
        iMaxDataset = pGribProduct->m_totalProduct.m_iMaxCappi;
        for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
        {
            if((pGribProduct->m_totalProduct.m_ppCappi[iDatasetIdx] != NULL) && 
               (iMaxField < pGribProduct->m_totalProduct.m_ppCappi[iDatasetIdx]->m_iMaxField))
                iMaxField = pGribProduct->m_totalProduct.m_ppCappi[iDatasetIdx]->m_iMaxField;
        }
    }
    if(pGribProduct->m_totalProduct.m_iMaxBase > 0 && 
       pGribProduct->m_totalProduct.m_ppBase != NULL)
    {
        iMaxDataset = pGribProduct->m_totalProduct.m_iMaxBase;
        for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
        {
            if((pGribProduct->m_totalProduct.m_ppBase[iDatasetIdx] != NULL) && 
               (iMaxField < pGribProduct->m_totalProduct.m_ppBase[iDatasetIdx]->m_iMaxField))
                iMaxField = pGribProduct->m_totalProduct.m_ppBase[iDatasetIdx]->m_iMaxField;
        }
    }
    if(pGribProduct->m_totalProduct.m_iMaxCmax > 0 && 
       pGribProduct->m_totalProduct.m_ppCmax != NULL)
    {
        iMaxDataset = pGribProduct->m_totalProduct.m_iMaxCmax;
        for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
        {
            if((pGribProduct->m_totalProduct.m_ppCmax[iDatasetIdx] != NULL) && 
               (iMaxField < pGribProduct->m_totalProduct.m_ppCmax[iDatasetIdx]->m_iMaxField))
                iMaxField = pGribProduct->m_totalProduct.m_ppCmax[iDatasetIdx]->m_iMaxField;
        }
    }
    if(pGribProduct->m_totalProduct.m_iMaxVil > 0 && 
       pGribProduct->m_totalProduct.m_ppVil != NULL)
    {
        iMaxDataset = pGribProduct->m_totalProduct.m_iMaxVil;
        for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
        {
            if((pGribProduct->m_totalProduct.m_ppVil[iDatasetIdx] != NULL) && 
               (iMaxField < pGribProduct->m_totalProduct.m_ppVil[iDatasetIdx]->m_iMaxField))
                iMaxField = pGribProduct->m_totalProduct.m_ppVil[iDatasetIdx]->m_iMaxField;
        }
    }
    if(pGribProduct->m_totalProduct.m_iMaxEtop > 0 && 
       pGribProduct->m_totalProduct.m_ppEtop != NULL)
    {
        iMaxDataset = pGribProduct->m_totalProduct.m_iMaxEtop;
        for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
        {
            if((pGribProduct->m_totalProduct.m_ppEtop[iDatasetIdx] != NULL) && 
               (iMaxField < pGribProduct->m_totalProduct.m_ppEtop[iDatasetIdx]->m_iMaxField))
                iMaxField = pGribProduct->m_totalProduct.m_ppEtop[iDatasetIdx]->m_iMaxField;
        }
    }

    if(pMaxPpi   != NULL) *pMaxPpi   = pGribProduct->m_totalProduct.m_iMaxPpi;
    if(pMaxCappi != NULL) *pMaxCappi = pGribProduct->m_totalProduct.m_iMaxCappi;
    if(pMaxBase  != NULL) *pMaxBase  = pGribProduct->m_totalProduct.m_iMaxBase;
    if(pMaxCmax  != NULL) *pMaxCmax  = pGribProduct->m_totalProduct.m_iMaxCmax;
    if(pMaxVil   != NULL) *pMaxVil   = pGribProduct->m_totalProduct.m_iMaxVil;
    if(pMaxEtop  != NULL) *pMaxEtop  = pGribProduct->m_totalProduct.m_iMaxEtop;
    if(pMaxField != NULL) *pMaxField = iMaxField;

    return TRUE;
}

int fnWriteGribProduct(GRIB_PRODUCT *pGribProduct, char *szProduct, char *szFileName)
{
#define FN_WRITE_GRIB_PRODUCT_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(hGrib  != NULL) { grib_handle_delete(hGrib); } \
    if(hMulti != NULL) { grib_multi_handle_delete(hMulti); }  \
    if(pFp    != NULL) { fclose(pFp); }

    grib_handle             *hGrib                      = NULL;
    grib_multi_handle       *hMulti                     = NULL;
    GRIB_PRODUCT_DATASET    **ppDset                    = NULL;
    FILE                    *pFp                        = NULL;
    int                     iMaxDset                    = 0;
    int                     iMaxData                    = 0;
    char                    szEnv[STR_LENGTH_MAX]       = "";
    char                    szTempFile[STR_LENGTH_MAX]  = "";

    if(pGribProduct == NULL || szProduct == NULL || szFileName == NULL)
        return FALSE;

    snprintf(szEnv, sizeof(szEnv), "%s/resource/grib_api/definitions", RDR_DF_APP_ROOT_PATH);
    setenv("GRIB_DEFINITION_PATH", szEnv, 1);
    snprintf(szEnv, sizeof(szEnv), "%s/resource/grib_api/samples", RDR_DF_APP_ROOT_PATH);
    setenv("GRIB_SAMPLES_PATH", szEnv, 1);
    setenv("GRIB_TEMPLATES_PATH", szEnv, 1);

    if((ppDset = fnFindGribProduct(pGribProduct, szProduct, &iMaxDset)) == NULL)
    {   FN_WRITE_GRIB_PRODUCT_ERROR("fnFindGribProduct fail") return FALSE; }

    if(iMaxDset <= 0)
    {   FN_WRITE_GRIB_PRODUCT_ERROR("iMaxDset is 0") return FALSE; }

    if((iMaxData = fnGetGribProductDsetMaxData(ppDset, iMaxDset)) <= 0)
    {   FN_WRITE_GRIB_PRODUCT_ERROR("iMaxData is 0") return FALSE; }

    if((hMulti = grib_multi_handle_new(NULL)) == NULL)
    {   FN_WRITE_GRIB_PRODUCT_ERROR("grib_multi_handle_new fail") return FALSE; }
    
    if((hGrib = grib_handle_new_from_samples(NULL, "GRIB2")) == NULL)
    {   FN_WRITE_GRIB_PRODUCT_ERROR("grib_handle_new_from_samples fail") return FALSE; }

    if(fnWriteGribProductSetSection0(hGrib) == FALSE)
    {   FN_WRITE_GRIB_PRODUCT_ERROR("fnWriteGribProductSetSection0 fail") return FALSE; }

    if(fnWriteGribProductSetSection1(hGrib, pGribProduct) == FALSE)
    {   FN_WRITE_GRIB_PRODUCT_ERROR("fnWriteGribProductSetSection1 fail") return FALSE; }

    if(fnWriteGribProductSetSection2(hGrib) == FALSE)
    {   FN_WRITE_GRIB_PRODUCT_ERROR("fnWriteGribProductSetSection2 fail") return FALSE; }

    if(fnWriteGribProductSetSection3(hGrib, pGribProduct, iMaxData) == FALSE)
    {   FN_WRITE_GRIB_PRODUCT_ERROR("fnWriteGribProductSetSection3 fail") return FALSE; }

    if(fnWriteGribProductSetSection4(hGrib, pGribProduct, ppDset, iMaxDset, iMaxData) == FALSE)
    {   FN_WRITE_GRIB_PRODUCT_ERROR("fnWriteGribProductSetSection4 fail") return FALSE; }

    if(fnWriteGribProductSetSection567(hGrib, hMulti, pGribProduct, 
                                       ppDset, iMaxDset, iMaxData) == FALSE)
    {   FN_WRITE_GRIB_PRODUCT_ERROR("fnWriteGribProductSetSection567 fail") return FALSE; }

    snprintf(szTempFile, sizeof(szTempFile), "%s.tmp", szFileName);

    if((pFp = fopen(szTempFile, "wt")) == NULL)
    {   FN_WRITE_GRIB_PRODUCT_ERROR("fopen fail") return FALSE; }

    grib_multi_handle_write(hMulti, pFp);

    rename(szTempFile, szFileName);

    grib_handle_delete(hGrib);
    grib_multi_handle_delete(hMulti);
    fclose(pFp);

    return TRUE;
}









