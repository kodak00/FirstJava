/* ================================================================================ */
//
// Radar Site Standard Output Format & Output Function
//
// 2016.08.19 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function

static void fnFreeStdDataset(STD_PRODUCT_DATASET **ppStdDataset, int iMaxDataset, int iYdim)
{
    int                 iDatasetIdx = 0;
    int                 iFieldIdx   = 0;
    int                 iMaxField   = 0;
    
    if(ppStdDataset != NULL)
    {
        for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
        {
            if(ppStdDataset[iDatasetIdx] != NULL)
            {
                if(ppStdDataset[iDatasetIdx]->m_ppProductData != NULL)
                {
                    iMaxField = ppStdDataset[iDatasetIdx]->m_iMaxField;
                    for(iFieldIdx = 0; iFieldIdx < iMaxField; iFieldIdx++)
                    {
                        if(ppStdDataset[iDatasetIdx]->m_ppProductData[iFieldIdx] != NULL)
                        {
                            if(ppStdDataset[iDatasetIdx]->
                               m_ppProductData[iFieldIdx]->m_ppData_c != NULL)
                            {
                                fnFreeMatrix2D((void **)ppStdDataset[iDatasetIdx]->
                                               m_ppProductData[iFieldIdx]->m_ppData_c, iYdim);
                            }
                            if(ppStdDataset[iDatasetIdx]->
                               m_ppProductData[iFieldIdx]->m_ppData_s != NULL)
                            {
                                fnFreeMatrix2D((void **)ppStdDataset[iDatasetIdx]->
                                                m_ppProductData[iFieldIdx]->m_ppData_s, iYdim);
                            }
                            if(ppStdDataset[iDatasetIdx]
                               ->m_ppProductData[iFieldIdx]->m_ppData_f != NULL)
                            {
                                fnFreeMatrix2D((void **)ppStdDataset[iDatasetIdx]->
                                               m_ppProductData[iFieldIdx]->m_ppData_f, iYdim);
                            }
                            free(ppStdDataset[iDatasetIdx]->m_ppProductData[iFieldIdx]);
                        }
                    }
                    free(ppStdDataset[iDatasetIdx]->m_ppProductData);
                }
                free(ppStdDataset[iDatasetIdx]);
            }
        }
        free(ppStdDataset);
    }
}

static STD_PRODUCT_DATASET** fnInitStdDataset(char *szProduct, int iMaxDataset, int iMaxField)
{
    STD_PRODUCT_DATASET **ppStdDataset   = NULL;
    int                 iDatasetIdx     = 0;
    int                 iFieldIdx       = 0;

    if(szProduct == NULL || iMaxDataset <= 0 || iMaxField <= 0)
        return NULL;

    ppStdDataset = (STD_PRODUCT_DATASET **)calloc(iMaxDataset, sizeof(STD_PRODUCT_DATASET *));
    if(ppStdDataset == NULL)
        return NULL;

    for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
    {
        ppStdDataset[iDatasetIdx] 
        = (STD_PRODUCT_DATASET *)calloc(1, sizeof(STD_PRODUCT_DATASET));
        if(ppStdDataset[iDatasetIdx] == NULL)
        {
            fnFreeStdDataset(ppStdDataset, iMaxDataset, 0);
            return NULL;
        }
        snprintf(ppStdDataset[iDatasetIdx]->m_szProduct, 
                 sizeof(ppStdDataset[iDatasetIdx]->m_szProduct), "%s", szProduct);
        ppStdDataset[iDatasetIdx]->m_iMaxField = iMaxField;

        ppStdDataset[iDatasetIdx]->m_ppProductData 
        = (STD_PRODUCT_DATA **)calloc(iMaxField, sizeof(STD_PRODUCT_DATA *));
        if(ppStdDataset[iDatasetIdx]->m_ppProductData == NULL)
        {
           fnFreeStdDataset(ppStdDataset, iMaxDataset, 0); 
            return NULL;
        }
        for(iFieldIdx = 0; iFieldIdx < iMaxField; iFieldIdx++)
        {
            ppStdDataset[iDatasetIdx]->m_ppProductData[iFieldIdx]
            = (STD_PRODUCT_DATA *)calloc(1, sizeof(STD_PRODUCT_DATA));
            if(ppStdDataset[iDatasetIdx]->m_ppProductData[iFieldIdx] == NULL)
            {
                fnFreeStdDataset(ppStdDataset, iMaxDataset, 0);
                return NULL;
            }
        }
    }

    return ppStdDataset;
}

// StdProduct -> HdfProduct

static void fnConvertHdfTop(HDF_PRODUCT *pHdfProduct, STD_PRODUCT *pStdProduct)
{
    COMP_INFO_TBL   compInfo;
    time_t          tConvertTime    = 0;
    struct tm       tm;

    if(pHdfProduct == NULL || pStdProduct == NULL)
        return;

    if(pStdProduct->m_iStdProductType == STD_EN_PRODUCT_SITE)
    {
        pHdfProduct->m_iHdfProductType = HDF_EN_PRODUCT_SITE;
    }
    else if(pStdProduct->m_iStdProductType == STD_EN_PRODUCT_COMP)
    {
        pHdfProduct->m_iHdfProductType = HDF_EN_PRODUCT_COMP;
    }

    // HDF TOP WHAT
    memset(&tm, 0x00, sizeof(struct tm));
    tConvertTime = pStdProduct->m_product_hdr.m_tConvertTime - (60*60*9); // UTC
    localtime_r(&tConvertTime, &tm);

    if(pHdfProduct->m_iHdfProductType == HDF_EN_PRODUCT_SITE)
    {
        snprintf(pHdfProduct->m_what.m_szObject,  sizeof(pHdfProduct->m_what.m_szObject),  
                 "AZIM");
        snprintf(pHdfProduct->m_what.m_szSource,  sizeof(pHdfProduct->m_what.m_szSource),  
                 "NOD:%s", pStdProduct->m_product_hdr.m_szSiteName);
    }
    else if(pHdfProduct->m_iHdfProductType == HDF_EN_PRODUCT_COMP)
    {
        snprintf(pHdfProduct->m_what.m_szObject,  sizeof(pHdfProduct->m_what.m_szObject),  
                 "COMP");
        snprintf(pHdfProduct->m_what.m_szSource,  sizeof(pHdfProduct->m_what.m_szSource),  
                 "CTY:116");
    }

    snprintf(pHdfProduct->m_what.m_szVersion, sizeof(pHdfProduct->m_what.m_szVersion), 
             "%s", RDR_DF_HDF_VERSION_STR);
    strftime(pHdfProduct->m_what.m_szDate,    sizeof(pHdfProduct->m_what.m_szDate),    
             "%Y%m%d", &tm);
    strftime(pHdfProduct->m_what.m_szTime,    sizeof(pHdfProduct->m_what.m_szTime),    
             "%H%M%S", &tm);

    // HDF TOP WHERE
    pHdfProduct->m_where.m_polar_where.m_dLon   = pStdProduct->m_product_hdr.m_dLon;
    pHdfProduct->m_where.m_polar_where.m_dLat   = pStdProduct->m_product_hdr.m_dLat;

    if(pHdfProduct->m_iHdfProductType == HDF_EN_PRODUCT_SITE)
    {
        snprintf(pHdfProduct->m_where.m_image_where.m_szProjdef, 
                 sizeof(pHdfProduct->m_where.m_image_where.m_szProjdef), 
                 "proj=aeqd +lat_0=%f +lon_0=%f +x_0=0 +y_0=0", 
                 pHdfProduct->m_where.m_polar_where.m_dLon, 
                 pHdfProduct->m_where.m_polar_where.m_dLat);
    }
    else if(pHdfProduct->m_iHdfProductType == HDF_EN_PRODUCT_COMP)
    {
        snprintf(pHdfProduct->m_where.m_image_where.m_szProjdef, 
                 sizeof(pHdfProduct->m_where.m_image_where.m_szProjdef),
                 "+proj=lcc +lat_1=30 +lat_2=60 +lat_0=38 +lon_0=126 +x_0=0 +y_0=0 "
                 "+ellps=WGS84 +units=m +no_defs");
    }
    pHdfProduct->m_where.m_image_where.m_lXsize  = pStdProduct->m_product_hdr.m_lXsize;
    pHdfProduct->m_where.m_image_where.m_lYsize  = pStdProduct->m_product_hdr.m_lYsize;
    pHdfProduct->m_where.m_image_where.m_dXscale = pStdProduct->m_product_hdr.m_dXscale;
    pHdfProduct->m_where.m_image_where.m_dYscale = pStdProduct->m_product_hdr.m_dYscale;
    pHdfProduct->m_where.m_image_where.m_LL_lon  = pStdProduct->m_product_hdr.m_LL_lon;
    pHdfProduct->m_where.m_image_where.m_LL_lat  = pStdProduct->m_product_hdr.m_LL_lat;
    pHdfProduct->m_where.m_image_where.m_UL_lon  = pStdProduct->m_product_hdr.m_UL_lon;
    pHdfProduct->m_where.m_image_where.m_UL_lat  = pStdProduct->m_product_hdr.m_UL_lat;
    pHdfProduct->m_where.m_image_where.m_UR_lon  = pStdProduct->m_product_hdr.m_UR_lon;
    pHdfProduct->m_where.m_image_where.m_UR_lat  = pStdProduct->m_product_hdr.m_UR_lat;
    pHdfProduct->m_where.m_image_where.m_LR_lon  = pStdProduct->m_product_hdr.m_LR_lon;
    pHdfProduct->m_where.m_image_where.m_LR_lat  = pStdProduct->m_product_hdr.m_LR_lat;

    // HDF TOP HOW
    if(pHdfProduct->m_iHdfProductType == HDF_EN_PRODUCT_SITE)
    {
        pHdfProduct->m_how.m_radar_how.m_dNi = pStdProduct->m_product_hdr.m_dNi;
    }
    else if(pHdfProduct->m_iHdfProductType == HDF_EN_PRODUCT_COMP)
    {
        memset(&compInfo, 0x00, sizeof(COMP_INFO_TBL));
        if(fnGetStdCompInfo(pStdProduct->m_product_hdr.m_szCompMethod, &compInfo) == RDR_DF_TRUE)
        {
            snprintf(pHdfProduct->m_how.m_image_how.m_szCamethod, 
                     sizeof(pHdfProduct->m_how.m_image_how.m_szCamethod), 
                     "%s", compInfo.m_szHdfCompMethod);
        }
    }
}

static int fnConvertHdfData(HDF_PRODUCT_DATA **ppHdfData, STD_PRODUCT_DATA **ppStdData, char *szProduct, int iMaxField, int iYdim, int iXdim)
{
    int                 iFieldIdx       = 0;
    FIELD_INFO_TBL      fieldInfo;
    FIELD_MEM_INFO_TBL  memInfo;

    if(ppHdfData == NULL || ppStdData == NULL || iMaxField <= 0)
        return FALSE;

    for(iFieldIdx = 0; iFieldIdx < iMaxField; iFieldIdx++)
    {
        if(ppHdfData[iFieldIdx] == NULL || ppStdData[iFieldIdx] == NULL)
            return FALSE;

        if(ppStdData[iFieldIdx]->m_ppData_c == NULL &&
           ppStdData[iFieldIdx]->m_ppData_s == NULL && 
           ppStdData[iFieldIdx]->m_ppData_f == NULL)
            continue;

        // HDF PRODUCT DATA
        snprintf(ppHdfData[iFieldIdx]->m_szFieldName, 
                 sizeof(ppHdfData[iFieldIdx]->m_szFieldName), 
                 "%s", ppStdData[iFieldIdx]->m_szFieldName);

        snprintf(ppHdfData[iFieldIdx]->m_szClass, sizeof(ppHdfData[iFieldIdx]->m_szClass), 
                 "%s", RDR_DF_HDF_DATA_CLASS_STR);
        snprintf(ppHdfData[iFieldIdx]->m_szVersion, sizeof(ppHdfData[iFieldIdx]->m_szVersion), 
                 "%s", RDR_DF_HDF_DATA_VERSION_STR);

        memset(&fieldInfo, 0x00, sizeof(FIELD_INFO_TBL));
        if(fnGetStdFieldInfo(ppHdfData[iFieldIdx]->m_szFieldName, &fieldInfo) == FALSE)
        {
            fprintf(stderr, "%s : unknown %s\n", __func__, ppHdfData[iFieldIdx]->m_szFieldName);
            return FALSE;
        }

        memset(&memInfo, 0x00, sizeof(FIELD_MEM_INFO_TBL));
        if(fnGetFieldMemInfo(ppHdfData[iFieldIdx]->m_szFieldName, &memInfo) == FALSE)
            return FALSE;

        // HDF DATA WHAT
        snprintf(ppHdfData[iFieldIdx]->m_what.m_szQuantity, 
                 sizeof(ppHdfData[iFieldIdx]->m_what.m_szQuantity),
                 "%s", fieldInfo.m_szHdfQuantity);
        ppHdfData[iFieldIdx]->m_what.m_dGain     = 1.0/memInfo.m_fScale;
        ppHdfData[iFieldIdx]->m_what.m_dOffset   = -memInfo.m_fOffset;
        ppHdfData[iFieldIdx]->m_what.m_dNodata   = memInfo.m_fOutBound;
        ppHdfData[iFieldIdx]->m_what.m_dUndetect = memInfo.m_fBadValue;

        // HDF DATA
        // 메모리 사용량 문제로 포인터를 이동시킴
        ppHdfData[iFieldIdx]->m_iMemType = ppStdData[iFieldIdx]->m_iMemType;

        ppHdfData[iFieldIdx]->m_ppData_c = ppStdData[iFieldIdx]->m_ppData_c;
        ppStdData[iFieldIdx]->m_ppData_c  = NULL;

        ppHdfData[iFieldIdx]->m_ppData_s = ppStdData[iFieldIdx]->m_ppData_s;
        ppStdData[iFieldIdx]->m_ppData_s  = NULL;

        ppHdfData[iFieldIdx]->m_ppData_f = ppStdData[iFieldIdx]->m_ppData_f;
        ppStdData[iFieldIdx]->m_ppData_f  = NULL;
    }

    return TRUE;
}

static int fnConvertHdfDataset(HDF_PRODUCT_DATASET **ppHdfDataset, STD_PRODUCT_DATASET **ppStdDataset, int iMaxDataset, int iYdim, int iXdim)
{
    int                 iDatasetIdx     = 0;
    PRODUCT_INFO_TBL    productInfo;

    if(ppHdfDataset == NULL || ppStdDataset == NULL || iMaxDataset <= 0)
        return FALSE;

    for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
    {
        if(ppHdfDataset[iDatasetIdx] == NULL || ppStdDataset[iDatasetIdx] == NULL)
            return FALSE;

        if(ppHdfDataset[iDatasetIdx]->m_ppProductData == NULL || 
           ppStdDataset[iDatasetIdx]->m_ppProductData == NULL)
            return FALSE;

        // HDF DATASET WHAT
        if(fnGetStdProductInfo(ppStdDataset[iDatasetIdx]->m_szProduct, &productInfo) == FALSE)
            return FALSE;

        snprintf(ppHdfDataset[iDatasetIdx]->m_what.m_szProduct, 
                 sizeof(ppHdfDataset[iDatasetIdx]->m_what.m_szProduct), 
                 "%s", productInfo.m_szHdfProduct);
        ppHdfDataset[iDatasetIdx]->m_what.m_dProdpar[0] = ppStdDataset[iDatasetIdx]->m_dProdpar[0];
        ppHdfDataset[iDatasetIdx]->m_what.m_dProdpar[1] = ppStdDataset[iDatasetIdx]->m_dProdpar[1];

        // HDF DATA
        if(ppStdDataset[iDatasetIdx]->m_iMaxField > 0)
        {
            ppHdfDataset[iDatasetIdx]->m_iMaxField = ppStdDataset[iDatasetIdx]->m_iMaxField;
            if(fnConvertHdfData(ppHdfDataset[iDatasetIdx]->m_ppProductData, 
                                ppStdDataset[iDatasetIdx]->m_ppProductData,
                                ppHdfDataset[iDatasetIdx]->m_what.m_szProduct,
                                ppStdDataset[iDatasetIdx]->m_iMaxField, iYdim, iXdim) == FALSE)
                return FALSE;
        }
    }
    
    return TRUE;
}

// StdProduct -> BufrProduct

static void fnConvertBufrTop(BUFR_PRODUCT *pBufrProduct, STD_PRODUCT *pStdProduct)
{
    COMP_INFO_TBL   compInfo;
    time_t          tConvertTime    = 0;
    struct tm       tm;

    if(pBufrProduct == NULL || pStdProduct == NULL)
        return;

    if(pStdProduct->m_iStdProductType == STD_EN_PRODUCT_SITE)
    {
        pBufrProduct->m_iBufrProductType = BUFR_EN_PRODUCT_SITE;
    }
    else if(pStdProduct->m_iStdProductType == STD_EN_PRODUCT_COMP)
    {
        pBufrProduct->m_iBufrProductType = BUFR_EN_PRODUCT_COMP;
    }

    // BUFR TOP WHAT
    memset(&tm, 0x00, sizeof(struct tm));
    tConvertTime = pStdProduct->m_product_hdr.m_tConvertTime - (60*60*9); // UTC
    localtime_r(&tConvertTime, &tm);

    if(pBufrProduct->m_iBufrProductType == BUFR_EN_PRODUCT_SITE)
    {
        snprintf(pBufrProduct->m_what.m_szObject,  sizeof(pBufrProduct->m_what.m_szObject),  
                 "AZIM");
        snprintf(pBufrProduct->m_what.m_szSource,  sizeof(pBufrProduct->m_what.m_szSource),  
                 "NOD:%s", pStdProduct->m_product_hdr.m_szSiteName);
    }
    else if(pBufrProduct->m_iBufrProductType == BUFR_EN_PRODUCT_COMP)
    {
        snprintf(pBufrProduct->m_what.m_szObject,  sizeof(pBufrProduct->m_what.m_szObject),  
                 "COMP");
        snprintf(pBufrProduct->m_what.m_szSource,  sizeof(pBufrProduct->m_what.m_szSource),  
                 "CTY:116");
    }

    snprintf(pBufrProduct->m_what.m_szVersion, sizeof(pBufrProduct->m_what.m_szVersion), 
             "%s", RDR_DF_BUFR_VERSION_STR);
    strftime(pBufrProduct->m_what.m_szDate,    sizeof(pBufrProduct->m_what.m_szDate),    
             "%Y%m%d", &tm);
    strftime(pBufrProduct->m_what.m_szTime,    sizeof(pBufrProduct->m_what.m_szTime),    
             "%H%M%S", &tm);

    // BUFR TOP WHERE
    pBufrProduct->m_where.m_polar_where.m_dLon  = pStdProduct->m_product_hdr.m_dLon;
    pBufrProduct->m_where.m_polar_where.m_dLat  = pStdProduct->m_product_hdr.m_dLat;

    if(pBufrProduct->m_iBufrProductType == BUFR_EN_PRODUCT_SITE)
    {
        snprintf(pBufrProduct->m_where.m_image_where.m_szProjdef, 
                 sizeof(pBufrProduct->m_where.m_image_where.m_szProjdef), 
                 "proj=aeqd +lat_0=%f +lon_0=%f +x_0=0 +y_0=0", 
                 pBufrProduct->m_where.m_polar_where.m_dLon, 
                 pBufrProduct->m_where.m_polar_where.m_dLat);
    }
    else if(pBufrProduct->m_iBufrProductType == BUFR_EN_PRODUCT_COMP)
    {
        snprintf(pBufrProduct->m_where.m_image_where.m_szProjdef, 
                 sizeof(pBufrProduct->m_where.m_image_where.m_szProjdef),
                 "+proj=lcc +lat_1=30 +lat_2=60 +lat_0=38 +lon_0=126 +x_0=0 +y_0=0 "
                 "+ellps=WGS84 +units=m +no_defs");
    }
    pBufrProduct->m_where.m_image_where.m_lXsize  = pStdProduct->m_product_hdr.m_lXsize;
    pBufrProduct->m_where.m_image_where.m_lYsize  = pStdProduct->m_product_hdr.m_lYsize;
    pBufrProduct->m_where.m_image_where.m_dXscale = pStdProduct->m_product_hdr.m_dXscale;
    pBufrProduct->m_where.m_image_where.m_dYscale = pStdProduct->m_product_hdr.m_dYscale;
    pBufrProduct->m_where.m_image_where.m_LL_lon  = pStdProduct->m_product_hdr.m_LL_lon;
    pBufrProduct->m_where.m_image_where.m_LL_lat  = pStdProduct->m_product_hdr.m_LL_lat;
    pBufrProduct->m_where.m_image_where.m_UL_lon  = pStdProduct->m_product_hdr.m_UL_lon;
    pBufrProduct->m_where.m_image_where.m_UL_lat  = pStdProduct->m_product_hdr.m_UL_lat;
    pBufrProduct->m_where.m_image_where.m_UR_lon  = pStdProduct->m_product_hdr.m_UR_lon;
    pBufrProduct->m_where.m_image_where.m_UR_lat  = pStdProduct->m_product_hdr.m_UR_lat;
    pBufrProduct->m_where.m_image_where.m_LR_lon  = pStdProduct->m_product_hdr.m_LR_lon;
    pBufrProduct->m_where.m_image_where.m_LR_lat  = pStdProduct->m_product_hdr.m_LR_lat;

    // BUFR TOP HOW
    if(pBufrProduct->m_iBufrProductType == BUFR_EN_PRODUCT_SITE)
    {
        pBufrProduct->m_how.m_radar_how.m_dNi = pStdProduct->m_product_hdr.m_dNi;
    }
    else if(pBufrProduct->m_iBufrProductType == BUFR_EN_PRODUCT_COMP)
    {
        memset(&compInfo, 0x00, sizeof(COMP_INFO_TBL));
        if(fnGetStdCompInfo(pStdProduct->m_product_hdr.m_szCompMethod, &compInfo) == RDR_DF_TRUE)
        {
            snprintf(pBufrProduct->m_how.m_image_how.m_szCamethod, 
                     sizeof(pBufrProduct->m_how.m_image_how.m_szCamethod), 
                     "%s", compInfo.m_szBufrCompMethod);
        }
    }
}

static int fnConvertBufrData(BUFR_PRODUCT_DATA **ppBufrData, STD_PRODUCT_DATA **ppStdData, char *szProduct, int iMaxField, int iYdim, int iXdim)
{
    int                 iFieldIdx       = 0;
    FIELD_INFO_TBL      fieldInfo;
    FIELD_MEM_INFO_TBL  memInfo;

    if(ppBufrData == NULL || ppStdData == NULL || iMaxField <= 0)
        return FALSE;

    for(iFieldIdx = 0; iFieldIdx < iMaxField; iFieldIdx++)
    {
        if(ppBufrData[iFieldIdx] == NULL || ppStdData[iFieldIdx] == NULL)
            return FALSE;

        if(ppStdData[iFieldIdx]->m_ppData_c == NULL &&
           ppStdData[iFieldIdx]->m_ppData_s == NULL && 
           ppStdData[iFieldIdx]->m_ppData_f == NULL)
            continue;

        // BUFR PRODUCT DATA
        snprintf(ppBufrData[iFieldIdx]->m_szFieldName, 
                 sizeof(ppBufrData[iFieldIdx]->m_szFieldName), 
                 "%s", ppStdData[iFieldIdx]->m_szFieldName);

        memset(&fieldInfo, 0x00, sizeof(FIELD_INFO_TBL));
        if(fnGetStdFieldInfo(ppBufrData[iFieldIdx]->m_szFieldName, &fieldInfo) == FALSE)
        {
            fprintf(stderr, "%s : unknown %s\n", __func__, ppBufrData[iFieldIdx]->m_szFieldName);
            return FALSE;
        }

        memset(&memInfo, 0x00, sizeof(FIELD_MEM_INFO_TBL));
        if(fnGetFieldMemInfo(ppBufrData[iFieldIdx]->m_szFieldName, &memInfo) == FALSE)
            return FALSE;

        // BUFR DATA WHAT
        snprintf(ppBufrData[iFieldIdx]->m_what.m_szQuantity, 
                 sizeof(ppBufrData[iFieldIdx]->m_what.m_szQuantity),
                 "%s", fieldInfo.m_szBufrQuantity);
        ppBufrData[iFieldIdx]->m_what.m_dGain     = 1.0;
        ppBufrData[iFieldIdx]->m_what.m_dOffset   = 0;
        ppBufrData[iFieldIdx]->m_what.m_dNodata   = DBL_MAX;
        ppBufrData[iFieldIdx]->m_what.m_dUndetect = -DBL_MAX;

        // BUFR DATA
        // 메모리 사용량 문제로 포인터를 이동시킴
        ppBufrData[iFieldIdx]->m_iMemType = ppStdData[iFieldIdx]->m_iMemType;

        ppBufrData[iFieldIdx]->m_ppData_c = ppStdData[iFieldIdx]->m_ppData_c;
        ppStdData[iFieldIdx]->m_ppData_c  = NULL;

        ppBufrData[iFieldIdx]->m_ppData_s = ppStdData[iFieldIdx]->m_ppData_s;
        ppStdData[iFieldIdx]->m_ppData_s  = NULL;

        ppBufrData[iFieldIdx]->m_ppData_f = ppStdData[iFieldIdx]->m_ppData_f;
        ppStdData[iFieldIdx]->m_ppData_f  = NULL;
    }

    return TRUE;
}

static int fnConvertBufrDataset(BUFR_PRODUCT_DATASET **ppBufrDataset, STD_PRODUCT_DATASET **ppStdDataset, int iMaxDataset, int iYdim, int iXdim)
{
    int                 iDatasetIdx     = 0;
    PRODUCT_INFO_TBL    productInfo;

    if(ppBufrDataset == NULL || ppStdDataset == NULL || iMaxDataset <= 0)
        return FALSE;

    for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
    {
        if(ppBufrDataset[iDatasetIdx] == NULL || ppStdDataset[iDatasetIdx] == NULL)
            return FALSE;

        if(ppBufrDataset[iDatasetIdx]->m_ppProductData == NULL || 
           ppStdDataset[iDatasetIdx]->m_ppProductData == NULL)
            return FALSE;

        // BUFR DATASET WHAT
        if(fnGetStdProductInfo(ppStdDataset[iDatasetIdx]->m_szProduct, &productInfo) == FALSE)
            return FALSE;

        snprintf(ppBufrDataset[iDatasetIdx]->m_what.m_szProduct, 
                 sizeof(ppBufrDataset[iDatasetIdx]->m_what.m_szProduct), 
                 "%s", productInfo.m_szBufrProduct);
        ppBufrDataset[iDatasetIdx]->m_what.m_dProdpar[0] = ppStdDataset[iDatasetIdx]->m_dProdpar[0];
        ppBufrDataset[iDatasetIdx]->m_what.m_dProdpar[1] = ppStdDataset[iDatasetIdx]->m_dProdpar[1];

        // BUFR DATA
        if(ppStdDataset[iDatasetIdx]->m_iMaxField > 0)
        {
            ppBufrDataset[iDatasetIdx]->m_iMaxField = ppStdDataset[iDatasetIdx]->m_iMaxField;
            if(fnConvertBufrData(ppBufrDataset[iDatasetIdx]->m_ppProductData, 
                                 ppStdDataset[iDatasetIdx]->m_ppProductData,
                                 ppBufrDataset[iDatasetIdx]->m_what.m_szProduct,
                                 ppStdDataset[iDatasetIdx]->m_iMaxField, iYdim, iXdim) == FALSE)
                return FALSE;
        }
    }
    
    return TRUE;
}

// StdProduct -> GribProduct

static void fnConvertGribTop(GRIB_PRODUCT *pGribProduct, STD_PRODUCT *pStdProduct)
{
    time_t          tConvertTime    = 0;
    struct tm       tm;

    if(pGribProduct == NULL || pStdProduct == NULL)
        return;

    if(pStdProduct->m_iStdProductType == STD_EN_PRODUCT_SITE)
    {
        pGribProduct->m_iGribProductType = GRIB_EN_PRODUCT_SITE;
    }
    else if(pStdProduct->m_iStdProductType == STD_EN_PRODUCT_COMP)
    {
        pGribProduct->m_iGribProductType = GRIB_EN_PRODUCT_COMP;
    }

    // GRIB PRODUCT WHAT
    memset(&tm, 0x00, sizeof(struct tm));
    tConvertTime = pStdProduct->m_product_hdr.m_tConvertTime - (60*60*9); // UTC
    localtime_r(&tConvertTime, &tm);

    strftime(pGribProduct->m_what.m_szDate,    sizeof(pGribProduct->m_what.m_szDate),    
             "%Y%m%d", &tm);
    strftime(pGribProduct->m_what.m_szTime,    sizeof(pGribProduct->m_what.m_szTime),    
             "%H%M%S", &tm);

    // GRIB PRODUCT WHERE
    pGribProduct->m_where.m_dLon    = pStdProduct->m_product_hdr.m_dLon;
    pGribProduct->m_where.m_dLat    = pStdProduct->m_product_hdr.m_dLat;

    if(pGribProduct->m_iGribProductType == GRIB_EN_PRODUCT_SITE)
    {
        snprintf(pGribProduct->m_where.m_szProjdef, 
                 sizeof(pGribProduct->m_where.m_szProjdef), 
                 "proj=aeqd +lat_0=%f +lon_0=%f +x_0=0 +y_0=0", 
                 pGribProduct->m_where.m_dLon, 
                 pGribProduct->m_where.m_dLat);
    }
    else if(pGribProduct->m_iGribProductType == GRIB_EN_PRODUCT_COMP)
    {
        snprintf(pGribProduct->m_where.m_szProjdef, 
                 sizeof(pGribProduct->m_where.m_szProjdef),
                 "+proj=lcc +lat_1=30 +lat_2=60 +lat_0=38 +lon_0=126 +x_0=0 +y_0=0 "
                 "+ellps=WGS84 +units=m +no_defs");
    }
    pGribProduct->m_where.m_lXsize  = pStdProduct->m_product_hdr.m_lXsize;
    pGribProduct->m_where.m_lYsize  = pStdProduct->m_product_hdr.m_lYsize;
    pGribProduct->m_where.m_dXscale = pStdProduct->m_product_hdr.m_dXscale;
    pGribProduct->m_where.m_dYscale = pStdProduct->m_product_hdr.m_dYscale;
    pGribProduct->m_where.m_LL_lon  = pStdProduct->m_product_hdr.m_LL_lon;
    pGribProduct->m_where.m_LL_lat  = pStdProduct->m_product_hdr.m_LL_lat;
    pGribProduct->m_where.m_UL_lon  = pStdProduct->m_product_hdr.m_UL_lon;
    pGribProduct->m_where.m_UL_lat  = pStdProduct->m_product_hdr.m_UL_lat;
    pGribProduct->m_where.m_UR_lon  = pStdProduct->m_product_hdr.m_UR_lon;
    pGribProduct->m_where.m_UR_lat  = pStdProduct->m_product_hdr.m_UR_lat;
    pGribProduct->m_where.m_LR_lon  = pStdProduct->m_product_hdr.m_LR_lon;
    pGribProduct->m_where.m_LR_lat  = pStdProduct->m_product_hdr.m_LR_lat;
}

static int fnConvertGribData(GRIB_PRODUCT_DATA **ppGribData, STD_PRODUCT_DATA **ppStdData, char *szProduct, int iMaxField, int iYdim, int iXdim)
{
    int                 iFieldIdx       = 0;
    FIELD_INFO_TBL      fieldInfo;
    FIELD_MEM_INFO_TBL  memInfo;

    if(ppGribData == NULL || ppStdData == NULL || iMaxField <= 0)
        return FALSE;

    for(iFieldIdx = 0; iFieldIdx < iMaxField; iFieldIdx++)
    {
        if(ppGribData[iFieldIdx] == NULL || ppStdData[iFieldIdx] == NULL)
            return FALSE;

        if(ppStdData[iFieldIdx]->m_ppData_c == NULL &&
           ppStdData[iFieldIdx]->m_ppData_s == NULL && 
           ppStdData[iFieldIdx]->m_ppData_f == NULL)
            continue;

        // GRIB PRODUCT DATA
        snprintf(ppGribData[iFieldIdx]->m_szFieldName, 
                 sizeof(ppGribData[iFieldIdx]->m_szFieldName), 
                 "%s", ppStdData[iFieldIdx]->m_szFieldName);

        memset(&fieldInfo, 0x00, sizeof(FIELD_INFO_TBL));
        if(fnGetStdFieldInfo(ppGribData[iFieldIdx]->m_szFieldName, &fieldInfo) == FALSE)
        {
            fprintf(stderr, "%s : unknown %s\n", __func__, ppGribData[iFieldIdx]->m_szFieldName);
            return FALSE;
        }

        memset(&memInfo, 0x00, sizeof(FIELD_MEM_INFO_TBL));
        if(fnGetFieldMemInfo(ppGribData[iFieldIdx]->m_szFieldName, &memInfo) == FALSE)
            return FALSE;

        // GRIB DATA WHAT
        snprintf(ppGribData[iFieldIdx]->m_what.m_szQuantity, 
                 sizeof(ppGribData[iFieldIdx]->m_what.m_szQuantity),
                 "%s", fieldInfo.m_szGribQuantity);
        ppGribData[iFieldIdx]->m_what.m_dScale    = 1.0;
        ppGribData[iFieldIdx]->m_what.m_dOffset   = 0;
        ppGribData[iFieldIdx]->m_what.m_dNodata   = RDR_DF_OUT_BOUND_F;
        ppGribData[iFieldIdx]->m_what.m_dUndetect = RDR_DF_BAD_VALUE_F;

        // GRIB DATA
        // 메모리 사용량 문제로 포인터를 이동시킴
        ppGribData[iFieldIdx]->m_iMemType = ppStdData[iFieldIdx]->m_iMemType;

        ppGribData[iFieldIdx]->m_ppData_c = ppStdData[iFieldIdx]->m_ppData_c;
        ppStdData[iFieldIdx]->m_ppData_c  = NULL;

        ppGribData[iFieldIdx]->m_ppData_s = ppStdData[iFieldIdx]->m_ppData_s;
        ppStdData[iFieldIdx]->m_ppData_s  = NULL;

        ppGribData[iFieldIdx]->m_ppData_f = ppStdData[iFieldIdx]->m_ppData_f;
        ppStdData[iFieldIdx]->m_ppData_f  = NULL;
    }

    return TRUE;
}

static int fnConvertGribDataset(GRIB_PRODUCT_DATASET **ppGribDataset, STD_PRODUCT_DATASET **ppStdDataset, int iMaxDataset, int iYdim, int iXdim)
{
    int                 iDatasetIdx     = 0;
    PRODUCT_INFO_TBL    productInfo;

    if(ppGribDataset == NULL || ppStdDataset == NULL || iMaxDataset <= 0)
        return FALSE;

    for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
    {
        if(ppGribDataset[iDatasetIdx] == NULL || ppStdDataset[iDatasetIdx] == NULL)
            return FALSE;

        if(ppGribDataset[iDatasetIdx]->m_ppProductData == NULL || 
           ppStdDataset[iDatasetIdx]->m_ppProductData == NULL)
            return FALSE;

        // GRIB DATASET WHAT
        if(fnGetStdProductInfo(ppStdDataset[iDatasetIdx]->m_szProduct, &productInfo) == FALSE)
            return FALSE;

        snprintf(ppGribDataset[iDatasetIdx]->m_what.m_szProduct, 
                 sizeof(ppGribDataset[iDatasetIdx]->m_what.m_szProduct), 
                 "%s", productInfo.m_szGribProduct);
        ppGribDataset[iDatasetIdx]->m_what.m_dProdpar[0] = ppStdDataset[iDatasetIdx]->m_dProdpar[0];
        ppGribDataset[iDatasetIdx]->m_what.m_dProdpar[1] = ppStdDataset[iDatasetIdx]->m_dProdpar[1];

        // GRIB DATA
        if(ppStdDataset[iDatasetIdx]->m_iMaxField > 0)
        {
            ppGribDataset[iDatasetIdx]->m_iMaxField = ppStdDataset[iDatasetIdx]->m_iMaxField;
            if(fnConvertGribData(ppGribDataset[iDatasetIdx]->m_ppProductData, 
                                 ppStdDataset[iDatasetIdx]->m_ppProductData,
                                 ppGribDataset[iDatasetIdx]->m_what.m_szProduct,
                                 ppStdDataset[iDatasetIdx]->m_iMaxField, iYdim, iXdim) == FALSE)
                return FALSE;
        }
    }
    
    return TRUE;
}

static int fnGetStdDataIdx(STD_PRODUCT_DATASET *pStdDataset, char* szFieldName)
{
    int                 iStdDataIdx = 0;

    if(pStdDataset == NULL || szFieldName == NULL)
        return -1;

    if(pStdDataset->m_ppProductData == NULL)
        return -1;

    for(iStdDataIdx = 0; iStdDataIdx < pStdDataset->m_iMaxField; iStdDataIdx++)
    {
        if(!strcmp(pStdDataset->m_ppProductData[iStdDataIdx]->m_szFieldName, szFieldName))
            return -1;

        if(!strcmp(pStdDataset->m_ppProductData[iStdDataIdx]->m_szFieldName, ""))
            break;
    }

    if(iStdDataIdx >= pStdDataset->m_iMaxField)
        return -1;

    return iStdDataIdx;
}

static int fnAddStdDatasetToData(STD_PRODUCT_DATASET *pStdDataset, char* szFieldName, float *pData, int iYdim, int iXdim)
{
    STD_PRODUCT_DATA    *pStdData   = NULL;     // VARIABLE
    int                 iStdDataIdx = 0;
    int                 iYIdx       = 0;
    int                 iXIdx       = 0;
    int                 iDataIdx    = 0;
    FIELD_MEM_INFO_TBL  memInfo;

    if(pStdDataset == NULL || szFieldName == NULL || pData == NULL)
        return FALSE;

    iStdDataIdx = fnGetStdDataIdx(pStdDataset, szFieldName);
    if(iStdDataIdx < 0 || iStdDataIdx >= pStdDataset->m_iMaxField)
        return FALSE;

    pStdData = pStdDataset->m_ppProductData[iStdDataIdx];
 
    memset(&memInfo, 0x00, sizeof(FIELD_MEM_INFO_TBL));
    if(fnGetFieldMemInfo(szFieldName, &memInfo) == RDR_DF_FALSE)
        return FALSE;

    pStdData->m_iMemType = memInfo.m_iMemType;

    if(pStdData->m_iMemType == RDR_EN_MEM_CHAR)
    {
        pStdData->m_ppData_c = (char **)calloc(iYdim, sizeof(char *));
        if(pStdData->m_ppData_c == NULL)
            return FALSE;

        for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
        {
            pStdData->m_ppData_c[iYIdx] = (char *)calloc(iXdim, sizeof(char));
            if(pStdData->m_ppData_c[iYIdx] == NULL)
            {
                fnFreeMatrix2D((void **)pStdData->m_ppData_c, iYdim);
                return FALSE;
            }
            for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
            {
                if(fabs(pData[iDataIdx] - RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
                    pStdData->m_ppData_c[iYIdx][iXIdx] = (char)memInfo.m_fOutBound;
                else if(fabs(pData[iDataIdx] - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
                    pStdData->m_ppData_c[iYIdx][iXIdx] = (char)memInfo.m_fBadValue;
                else
                {
                    pStdData->m_ppData_c[iYIdx][iXIdx] 
                    = (char)((pData[iDataIdx] + memInfo.m_fOffset) * memInfo.m_fScale);
                }

                iDataIdx++;
            }
        }
    }
    else if(pStdData->m_iMemType == RDR_EN_MEM_SHORT)
    {
        pStdData->m_ppData_s = (short **)calloc(iYdim, sizeof(short *));
        if(pStdData->m_ppData_s == NULL)
            return FALSE;

        for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
        {
            pStdData->m_ppData_s[iYIdx] = (short *)calloc(iXdim, sizeof(short));
            if(pStdData->m_ppData_s[iYIdx] == NULL)
            {
                fnFreeMatrix2D((void **)pStdData->m_ppData_s, iYdim);
                return FALSE;
            }
            for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
            {
                if(fabs(pData[iDataIdx] - RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
                    pStdData->m_ppData_s[iYIdx][iXIdx] = (short)memInfo.m_fOutBound;
                else if(fabs(pData[iDataIdx] - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
                    pStdData->m_ppData_s[iYIdx][iXIdx] = (short)memInfo.m_fBadValue;
                else
                {
                    pStdData->m_ppData_s[iYIdx][iXIdx] 
                    = (short)((pData[iDataIdx] + memInfo.m_fOffset) * memInfo.m_fScale);
                }

                iDataIdx++;
            }
        }
    }
    else if(pStdData->m_iMemType == RDR_EN_MEM_FLOAT)
    {
        pStdData->m_ppData_f = (float **)calloc(iYdim, sizeof(float *));
        if(pStdData->m_ppData_f == NULL)
            return FALSE;

        for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
        {
            pStdData->m_ppData_f[iYIdx] = (float *)calloc(iXdim, sizeof(float));
            if(pStdData->m_ppData_f[iYIdx] == NULL)
            {
                fnFreeMatrix2D((void **)pStdData->m_ppData_f, iYdim);
                return FALSE;
            }
            for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
            {
                if(fabs(pData[iDataIdx] - RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
                    pStdData->m_ppData_f[iYIdx][iXIdx] = (float)memInfo.m_fOutBound;
                else if(fabs(pData[iDataIdx] - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
                    pStdData->m_ppData_f[iYIdx][iXIdx] = (float)memInfo.m_fBadValue;
                else
                {
                    pStdData->m_ppData_f[iYIdx][iXIdx] 
                    = (float)((pData[iDataIdx] + memInfo.m_fOffset) * memInfo.m_fScale);
                }

                iDataIdx++;
            }
        }
    }

    snprintf(pStdData->m_szFieldName, sizeof(pStdData->m_szFieldName), "%s", szFieldName);

    return TRUE;
}

//  STD -> HDF

static void fnStdToHdfTopWhat(STD_RADAR *pStd, HDF_RADAR *pHdf)
{
    time_t          tUtcTime    = 0;
    struct tm       tm;

    if(pStd == NULL || pHdf == NULL)
        return;

    snprintf(pHdf->m_what.m_szObject, sizeof(pHdf->m_what.m_szObject), 
             "%s", "PVOL");
    snprintf(pHdf->m_what.m_szVersion, sizeof(pHdf->m_what.m_szVersion), 
             "%s", RDR_DF_HDF_VERSION_STR);

    tUtcTime = pStd->m_hdr.m_tConvertTime - (60*60*9); // UTC
    memset(&tm, 0x00, sizeof(struct tm));
    localtime_r(&tUtcTime, &tm);

    strftime(pHdf->m_what.m_szDate, sizeof(pHdf->m_what.m_szDate),
             "%Y%m%d", &tm);
    strftime(pHdf->m_what.m_szTime, sizeof(pHdf->m_what.m_szTime),
             "%H%M%S", &tm);

    snprintf(pHdf->m_what.m_szSource, sizeof(pHdf->m_what.m_szSource), 
             "NOD:%s", pStd->m_hdr.m_szSiteName);
}

static void fnStdToHdfTopWhere(STD_RADAR *pStd, HDF_RADAR *pHdf)
{
    if(pStd == NULL || pHdf == NULL)
        return;

    pHdf->m_where.m_polar_where.m_dLon      = pStd->m_hdr.m_dLon;
    pHdf->m_where.m_polar_where.m_dLat      = pStd->m_hdr.m_dLat;
    pHdf->m_where.m_polar_where.m_dHeightM  = pStd->m_hdr.m_iAnteHeight;
}

static void fnStdToHdfTopHow(STD_RADAR *pStd, HDF_RADAR *pHdf)
{
    if(pStd == NULL || pHdf == NULL)
        return;

    snprintf(pHdf->m_how.m_general_how.m_szTask, sizeof(pHdf->m_how.m_general_how.m_szTask), 
             "%s", pStd->m_hdr.m_szConvertName);

    pHdf->m_how.m_radar_how.m_dPulseWidth 
    = (double)(pStd->m_hdr.m_iPulseWidth / (RDR_DF_SPEED_OF_LIGHT/1.0e6));

    pHdf->m_how.m_radar_how.m_dBeamwH       = (double)pStd->m_hdr.m_fBeamWidthH;
    pHdf->m_how.m_radar_how.m_dBeamwV       = (double)pStd->m_hdr.m_fBeamWidthV;
    pHdf->m_how.m_radar_how.m_dRXbandWidth  = (double)pStd->m_hdr.m_iBandWidth;
    pHdf->m_how.m_radar_how.m_dWaveLength   = (double)pStd->m_hdr.m_fWaveLength;
}

static void fnStdToHdfDsetWhat(STD_SWEEP *pStdSweep, HDF_DATASET *pHdfDset)
{
    STD_RAY         *pStdRay    = NULL;
    time_t          tUtcTime    = 0;
    struct tm       tm;

    if(pStdSweep == NULL || pHdfDset == NULL)
        return;

    snprintf(pHdfDset->m_what.m_szProduct, sizeof(pHdfDset->m_what.m_szProduct), 
             "%s", "SCAN");

    pStdRay = pStdSweep->m_ppRay[0];

    tUtcTime = pStdRay->m_hdr.m_tTime - (60*60*9); // UTC
    memset(&tm, 0x00, sizeof(struct tm));
    localtime_r(&tUtcTime, &tm);

    strftime(pHdfDset->m_what.m_szStartDate, sizeof(pHdfDset->m_what.m_szStartDate),
             "%Y%m%d", &tm);
    strftime(pHdfDset->m_what.m_szStartTime, sizeof(pHdfDset->m_what.m_szStartTime),
             "%H%M%S", &tm);

    pStdRay = pStdSweep->m_ppRay[pStdSweep->m_iMaxRay-1];

    tUtcTime = pStdRay->m_hdr.m_tTime - (60*60*9); // UTC
    memset(&tm, 0x00, sizeof(struct tm));
    localtime_r(&tUtcTime, &tm);

    strftime(pHdfDset->m_what.m_szEndDate, sizeof(pHdfDset->m_what.m_szEndDate),
             "%Y%m%d", &tm);
    strftime(pHdfDset->m_what.m_szEndTime, sizeof(pHdfDset->m_what.m_szEndTime),
             "%H%M%S", &tm);

}

static void fnStdToHdfDsetWhere(STD_SWEEP *pStdSweep, HDF_DATASET *pHdfDset)
{
    STD_RAY         *pStdRay    = NULL;
    int             iRayIdx     = 0;
    int             iA1gate     = 0;
    float           fMinAzimuth = 999.0;

    if(pStdSweep == NULL || pHdfDset == NULL)
        return;

    pStdRay = pStdSweep->m_ppRay[0];

    pHdfDset->m_where.m_polar_where.m_dElangle  = (double)pStdRay->m_hdr.m_fFixedAngle;
    pHdfDset->m_where.m_polar_where.m_nBins     = (long)pStdRay->m_ppField[0]->m_iMaxBin;
    pHdfDset->m_where.m_polar_where.m_dRstart  
    = (double)(pStdRay->m_hdr.m_iStartRangeKm + pStdRay->m_hdr.m_iStartRangeMeter/1000.);
    pHdfDset->m_where.m_polar_where.m_dRScale   = (double)pStdRay->m_hdr.m_iBinSpacing;
    pHdfDset->m_where.m_polar_where.m_nRays     = (long)pStdSweep->m_iMaxRay;

    for(iRayIdx = 0; iRayIdx < pStdSweep->m_iMaxRay; iRayIdx++)
    {
        pStdRay = pStdSweep->m_ppRay[iRayIdx];

        if(fMinAzimuth > pStdRay->m_hdr.m_fAzimuth)
        {
            fMinAzimuth = pStdRay->m_hdr.m_fAzimuth;
            iA1gate     = iRayIdx;
        }
    }
    pHdfDset->m_where.m_polar_where.m_lA1gate   = (long)iA1gate;
}

static void fnStdToHdfDsetHow(STD_SWEEP *pStdSweep, HDF_DATASET *pHdfDset)
{
    if(pStdSweep == NULL || pHdfDset == NULL)
        return;

    pHdfDset->m_how.m_radar_how.m_dNi = (double)pStdSweep->m_hdr.m_fNyquistVelocity;
}

static int fnStdToHdfDataWhat(STD_SWEEP *pStdSweep, int iFieldIdx, HDF_DATA *pHdfData, int iNoDataValue)
{
    STD_RAY         *pStdRay    = NULL;
    STD_FIELD       *pStdField  = NULL;
    FIELD_INFO_TBL  fieldInfo;

    if(pStdSweep == NULL || pHdfData == NULL)
        return FALSE;

    pStdRay = pStdSweep->m_ppRay[0];

    pStdField = pStdRay->m_ppField[iFieldIdx];

    snprintf(pHdfData->m_szClass, sizeof(pHdfData->m_szClass), 
             "%s", RDR_DF_HDF_DATA_CLASS_STR);
    snprintf(pHdfData->m_szVersion, sizeof(pHdfData->m_szVersion), 
             "%s", RDR_DF_HDF_DATA_VERSION_STR);

    memset(&fieldInfo, 0x00, sizeof(fieldInfo));
    if(fnGetStdFieldInfo(pStdField->m_hdr.m_szFieldName, &fieldInfo) == FALSE)
    {
        fprintf(stderr, "%s : unknown %s\n", __func__, pStdField->m_hdr.m_szFieldName);
        return FALSE;
    }

    snprintf(pHdfData->m_what.m_szQuantity, sizeof(pHdfData->m_what.m_szQuantity), 
             "%s", fieldInfo.m_szHdfQuantity);
    pHdfData->m_what.m_dGain        = (double)(1./pStdField->m_hdr.m_iScaleFactor);
    pHdfData->m_what.m_dOffset      = 0.;
    pHdfData->m_what.m_dNodata      = RDR_DF_HDF_NODATA;
    pHdfData->m_what.m_dUndetect    = iNoDataValue;

    return TRUE;
}

static int fnStdToHdfData(STD_SWEEP *pStdSweep, int iMaxRay, int iMaxBin, int iFieldIdx, HDF_DATA *pHdfData)
{
    STD_RAY         *pStdRay    = NULL;
    STD_FIELD       *pStdField  = NULL;
    int             iRayIdx     = 0;
    int             iBinIdx     = 0;

    if(pStdSweep == NULL || pHdfData == NULL)
        return FALSE;

    pHdfData->m_ppData = fnMakeMatrix2D_F(iMaxRay, iMaxBin);
    if(pHdfData->m_ppData == NULL)
        return FALSE;

    for(iRayIdx = 0; iRayIdx < iMaxRay; iRayIdx++)
    {
        pStdRay = pStdSweep->m_ppRay[iRayIdx];

        pStdField = pStdRay->m_ppField[iFieldIdx];

        for(iBinIdx = 0; iBinIdx < iMaxBin; iBinIdx++)
        {
           if(iBinIdx < pStdField->m_iMaxBin)
               pHdfData->m_ppData[iRayIdx][iBinIdx] = pStdField->m_pData[iBinIdx];
           else
               pHdfData->m_ppData[iRayIdx][iBinIdx] = (float)pHdfData->m_what.m_dNodata;
        }
    }

    return TRUE;
}

/* ================================================================================ */
// Function

STD_PRODUCT* fnInitStdProduct(int iMaxField, int iMaxPpi, int iMaxCappi, int iMaxBase, int iMaxCmax, int iMaxVil, int iMaxEtop)
{
#define FN_INIT_STD_PRODUCT_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    fnFreeStdProduct(pStdProduct);

    STD_PRODUCT     *pStdProduct         = NULL;     // VARIABLE

    if(iMaxField <= 0)
        return NULL;

    if((pStdProduct = (STD_PRODUCT *)calloc(1, sizeof(STD_PRODUCT))) == NULL)
        return NULL;

    if(iMaxPpi > 0 && iMaxPpi < RDR_DF_STD_PRODUCT_MAX) 
    {
        pStdProduct->m_totalProduct.m_iMaxPpi = iMaxPpi;
        pStdProduct->m_totalProduct.m_ppPpi   = fnInitStdDataset("PPI", iMaxPpi, iMaxField);
        if(pStdProduct->m_totalProduct.m_ppPpi == NULL)
        {   FN_INIT_STD_PRODUCT_ERROR("fnInitStdDataset fail"); return NULL; }
    }
    if(iMaxCappi > 0 && iMaxCappi < RDR_DF_STD_PRODUCT_MAX) 
    {
        pStdProduct->m_totalProduct.m_iMaxCappi = iMaxCappi;
        pStdProduct->m_totalProduct.m_ppCappi   = fnInitStdDataset("CAPPI", iMaxCappi, iMaxField);
        if(pStdProduct->m_totalProduct.m_ppCappi == NULL)
        {   FN_INIT_STD_PRODUCT_ERROR("fnInitStdDataset fail"); return NULL; }
    }
    if(iMaxBase > 0 && iMaxBase < RDR_DF_STD_PRODUCT_MAX) 
    {
        pStdProduct->m_totalProduct.m_iMaxBase = iMaxBase;
        pStdProduct->m_totalProduct.m_ppBase   = fnInitStdDataset("BASE", iMaxBase, iMaxField);
        if(pStdProduct->m_totalProduct.m_ppBase == NULL)
        {   FN_INIT_STD_PRODUCT_ERROR("fnInitStdDataset fail"); return NULL; }
    }
    if(iMaxCmax > 0 && iMaxCmax < RDR_DF_STD_PRODUCT_MAX) 
    {
        pStdProduct->m_totalProduct.m_iMaxCmax = iMaxCmax;
        pStdProduct->m_totalProduct.m_ppCmax   = fnInitStdDataset("CMAX", iMaxCmax, iMaxField);
        if(pStdProduct->m_totalProduct.m_ppCmax == NULL)
        {   FN_INIT_STD_PRODUCT_ERROR("fnInitStdDataset fail"); return NULL; }
    }
    if(iMaxVil > 0 && iMaxVil < RDR_DF_STD_PRODUCT_MAX)
    {
        pStdProduct->m_totalProduct.m_iMaxVil = iMaxVil;
        pStdProduct->m_totalProduct.m_ppVil   = fnInitStdDataset("VIL", iMaxVil, iMaxField);
        if(pStdProduct->m_totalProduct.m_ppVil == NULL)
        {   FN_INIT_STD_PRODUCT_ERROR("fnInitStdDataset fail"); return NULL; }
    }
    if(iMaxEtop > 0 && iMaxEtop < RDR_DF_STD_PRODUCT_MAX) 
    {
        pStdProduct->m_totalProduct.m_iMaxEtop = iMaxEtop;
        pStdProduct->m_totalProduct.m_ppEtop   = fnInitStdDataset("ETOP", iMaxEtop, iMaxField);
        if(pStdProduct->m_totalProduct.m_ppEtop == NULL)
        {   FN_INIT_STD_PRODUCT_ERROR("fnInitStdDataset fail"); return NULL; }
    }

    return pStdProduct;
}

void fnFreeStdProduct(STD_PRODUCT *pStdProduct)
{
    if(pStdProduct != NULL)
    {
        if(pStdProduct->m_totalProduct.m_iMaxPpi > 0)
        {
            fnFreeStdDataset(pStdProduct->m_totalProduct.m_ppPpi,
                             pStdProduct->m_totalProduct.m_iMaxPpi,
                             pStdProduct->m_product_hdr.m_lYsize);
        }
        if(pStdProduct->m_totalProduct.m_iMaxCappi > 0)
        {
            fnFreeStdDataset(pStdProduct->m_totalProduct.m_ppCappi,
                             pStdProduct->m_totalProduct.m_iMaxCappi,
                             pStdProduct->m_product_hdr.m_lYsize);
        }
        if(pStdProduct->m_totalProduct.m_iMaxBase > 0)
        {
            fnFreeStdDataset(pStdProduct->m_totalProduct.m_ppBase,
                             pStdProduct->m_totalProduct.m_iMaxBase,
                             pStdProduct->m_product_hdr.m_lYsize);
        }
        if(pStdProduct->m_totalProduct.m_iMaxCmax > 0)
        {
            fnFreeStdDataset(pStdProduct->m_totalProduct.m_ppCmax,
                             pStdProduct->m_totalProduct.m_iMaxCmax,
                             pStdProduct->m_product_hdr.m_lYsize);
        }
        if(pStdProduct->m_totalProduct.m_iMaxVil > 0)
        {
            fnFreeStdDataset(pStdProduct->m_totalProduct.m_ppVil,
                             pStdProduct->m_totalProduct.m_iMaxVil,
                             pStdProduct->m_product_hdr.m_lYsize);
        }
        if(pStdProduct->m_totalProduct.m_iMaxEtop > 0)
        {
            fnFreeStdDataset(pStdProduct->m_totalProduct.m_ppEtop,
                             pStdProduct->m_totalProduct.m_iMaxEtop,
                             pStdProduct->m_product_hdr.m_lYsize);
        }

        free(pStdProduct);
    }
}

int fnSetStdProductSiteHdr(STD_RADAR *pStd, STD_PRODUCT *pStdProduct, int iYdim, int iXdim, float fGridKm)
{
    float               fLon    = 0.0;
    float               fLat    = 0.0;
    float               fX      = 0.0;
    float               fY      = 0.0;
    AZED_PARAMETER      map;
    AZED_VAR            mapVar;

    if(pStd == NULL || pStdProduct == NULL)
        return FALSE;

    pStdProduct->m_iStdProductType = STD_EN_PRODUCT_SITE;

    pStdProduct->m_product_hdr.m_tConvertTime = pStd->m_hdr.m_tConvertTime;
    snprintf(pStdProduct->m_product_hdr.m_szSiteName, 
             sizeof(pStdProduct->m_product_hdr.m_szSiteName), 
             "%s", pStd->m_hdr.m_szSiteName);
    pStdProduct->m_product_hdr.m_dLon         = pStd->m_hdr.m_dLon;
    pStdProduct->m_product_hdr.m_dLat         = pStd->m_hdr.m_dLat;
    pStdProduct->m_product_hdr.m_iAnteHeightM = pStd->m_hdr.m_iAnteHeight;
    snprintf(pStdProduct->m_product_hdr.m_szTask, 
             sizeof(pStdProduct->m_product_hdr.m_szTask),
             "%s", pStd->m_hdr.m_szConvertName);
    snprintf(pStdProduct->m_product_hdr.m_szSystem, 
             sizeof(pStdProduct->m_product_hdr.m_szSystem),
             "%s", pStd->m_hdr.m_szRadarName);
    pStdProduct->m_product_hdr.m_dNi     = pStd->m_ppSweep[0]->m_hdr.m_fNyquistVelocity;
    pStdProduct->m_product_hdr.m_lXsize  = iXdim;
    pStdProduct->m_product_hdr.m_lYsize  = iYdim;
    pStdProduct->m_product_hdr.m_dXscale = fGridKm;
    pStdProduct->m_product_hdr.m_dYscale = fGridKm;

    memset(&mapVar, 0x00, sizeof(AZED_VAR));
    map = fnGetAzedMapInfo(RDR_DF_KMA_MAP_RE, fGridKm, 
                           pStdProduct->m_product_hdr.m_dLon, 
                           pStdProduct->m_product_hdr.m_dLat, 
                           pStdProduct->m_product_hdr.m_dLon, 
                           pStdProduct->m_product_hdr.m_dLat, 
                           (pStdProduct->m_product_hdr.m_lXsize)/2, 
                           (pStdProduct->m_product_hdr.m_lYsize)/2);

    fX = 0;
    fY = 0;
    fnAzedProj(&fLon, &fLat, &fX, &fY, 1, &map, &mapVar);
    pStdProduct->m_product_hdr.m_LL_lon = (double)fLon;
    pStdProduct->m_product_hdr.m_LL_lat = (double)fLat;

    fX = 0;
    fY = pStdProduct->m_product_hdr.m_lYsize;
    fnAzedProj(&fLon, &fLat, &fX, &fY, 1, &map, &mapVar);
    pStdProduct->m_product_hdr.m_UL_lon = (double)fLon;
    pStdProduct->m_product_hdr.m_UL_lat = (double)fLat;

    fX = pStdProduct->m_product_hdr.m_lXsize;
    fY = pStdProduct->m_product_hdr.m_lYsize;
    fnAzedProj(&fLon, &fLat, &fX, &fY, 1, &map, &mapVar);
    pStdProduct->m_product_hdr.m_UR_lon = (double)fLon;
    pStdProduct->m_product_hdr.m_UR_lat = (double)fLat;

    fX = pStdProduct->m_product_hdr.m_lXsize;
    fY = 0;
    fnAzedProj(&fLon, &fLat, &fX, &fY, 1, &map, &mapVar);
    pStdProduct->m_product_hdr.m_LR_lon = (double)fLon;
    pStdProduct->m_product_hdr.m_LR_lat = (double)fLat;

    return TRUE;
}

int fnSetStdProductCompHdr(STD_PRODUCT *pStdProduct, char *szCompMethod, char *szDateTime, int iYdim, int iXdim, float fGridKm, int iXo, int iYo)
{
    float               fLon    = 0.0;
    float               fLat    = 0.0;
    float               fX      = 0.0;
    float               fY      = 0.0;
    struct  tm          datetime;
    LAMC_PARAMETER      map;
    LAMC_VAR            var;

    if(pStdProduct == NULL)
        return FALSE;

    pStdProduct->m_iStdProductType = STD_EN_PRODUCT_COMP;

    memset(&datetime, 0x00, sizeof(struct tm));
    strptime(szDateTime, "%Y%m%d%H%M", &datetime);
    pStdProduct->m_product_hdr.m_tConvertTime = mktime(&datetime);
    pStdProduct->m_product_hdr.m_lXsize       = iXdim;
    pStdProduct->m_product_hdr.m_lYsize       = iYdim;
    pStdProduct->m_product_hdr.m_dXscale      = fGridKm;
    pStdProduct->m_product_hdr.m_dYscale      = fGridKm;

    snprintf(pStdProduct->m_product_hdr.m_szCompMethod, 
             sizeof(pStdProduct->m_product_hdr.m_szCompMethod), "%s", szCompMethod);

    var.m_iFirst = 0;
    map = fnGetLamcMapInfo(RDR_DF_KMA_MAP_RE, fGridKm, 
                           RDR_DF_LCC_SLAT1, RDR_DF_LCC_SLAT2, 
                           RDR_DF_LCC_OLON, RDR_DF_LCC_OLAT, iXo, iYo);

    fX = 0;
    fY = 0;
    fnLamcProj(&fLon, &fLat, &fX, &fY, 1, &map, &var);
    pStdProduct->m_product_hdr.m_LL_lon = (double)fLon;
    pStdProduct->m_product_hdr.m_LL_lat = (double)fLat;

    fX = 0;
    fY = pStdProduct->m_product_hdr.m_lYsize;
    fnLamcProj(&fLon, &fLat, &fX, &fY, 1, &map, &var);
    pStdProduct->m_product_hdr.m_UL_lon = (double)fLon;
    pStdProduct->m_product_hdr.m_UL_lat = (double)fLat;

    fX = pStdProduct->m_product_hdr.m_lXsize;
    fY = pStdProduct->m_product_hdr.m_lYsize;;
    fnLamcProj(&fLon, &fLat, &fX, &fY, 1, &map, &var);
    pStdProduct->m_product_hdr.m_UR_lon = (double)fLon;
    pStdProduct->m_product_hdr.m_UR_lat = (double)fLat;

    fX = pStdProduct->m_product_hdr.m_lXsize;
    fY = 0;
    fnLamcProj(&fLon, &fLat, &fX, &fY, 1, &map, &var);
    pStdProduct->m_product_hdr.m_LR_lon = (double)fLon;
    pStdProduct->m_product_hdr.m_LR_lat = (double)fLat;

    return TRUE;
}

int fnAddStdProductToData(STD_PRODUCT *pStdProduct, char *szProduct, int iProductIdx, double dProductArg1, double dProductArg2, char *szFieldName, float *pData, int iYdim, int iXdim)
{
    STD_PRODUCT_DATASET     **ppStdDataset  = NULL;     // VARIABLE
    int                     iMaxDataset     = 0;

    if(pStdProduct == NULL || szProduct == NULL || szFieldName == NULL || pData == NULL)
        return FALSE;

    if(pStdProduct->m_product_hdr.m_lXsize != iXdim || 
       pStdProduct->m_product_hdr.m_lYsize != iYdim)
        return FALSE;

    ppStdDataset = fnFindDsetStdProduct(pStdProduct, szProduct, &iMaxDataset);
    if(ppStdDataset == NULL || iMaxDataset <= iProductIdx)
        return FALSE;

    if(ppStdDataset[iProductIdx] == NULL)
        return FALSE;

    ppStdDataset[iProductIdx]->m_dProdpar[0] = dProductArg1;
    ppStdDataset[iProductIdx]->m_dProdpar[1] = dProductArg2;

    return fnAddStdDatasetToData(ppStdDataset[iProductIdx], szFieldName, pData, iYdim, iXdim);
}

HDF_PRODUCT* fnStdProductSyncDownHdf(STD_PRODUCT *pStdProduct)
{
#define FN_STD_PRODUCT_SYNC_DOWN_HDF_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pHdfProduct != NULL) { fnFreeHdfProduct(pHdfProduct); }

    HDF_PRODUCT*    pHdfProduct    = NULL;     // VARIABLE

    if(pStdProduct == NULL)
        return NULL;

    pHdfProduct = fnInitHdfProductToStdProduct(pStdProduct);
    if(pHdfProduct == NULL)
    {   FN_STD_PRODUCT_SYNC_DOWN_HDF_ERROR("fnInitHdfProductToStdProduct fail") return NULL; }

    if(pStdProduct->m_iStdProductType == STD_EN_PRODUCT_SITE)
        pHdfProduct->m_iHdfProductType = HDF_EN_PRODUCT_SITE;
    else if(pStdProduct->m_iStdProductType == STD_EN_PRODUCT_COMP)
        pHdfProduct->m_iHdfProductType = HDF_EN_PRODUCT_COMP;

    snprintf(pHdfProduct->m_szConventions, 
             sizeof(pHdfProduct->m_szConventions), RDR_DF_HDF_CONVENTIONS_STR);

    fnConvertHdfTop(pHdfProduct, pStdProduct);

    if(pStdProduct->m_totalProduct.m_iMaxPpi > 0)
    {
        pHdfProduct->m_totalProduct.m_iMaxPpi = pStdProduct->m_totalProduct.m_iMaxPpi;
        if(fnConvertHdfDataset(pHdfProduct->m_totalProduct.m_ppPpi, 
                               pStdProduct->m_totalProduct.m_ppPpi,
                               pStdProduct->m_totalProduct.m_iMaxPpi, 
                               (int)pStdProduct->m_product_hdr.m_lYsize,
                               (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_HDF_ERROR("fnConvertHdfDataset PPI fail") return NULL; }
    }

    if(pStdProduct->m_totalProduct.m_iMaxCappi > 0)
    {
        pHdfProduct->m_totalProduct.m_iMaxCappi = pStdProduct->m_totalProduct.m_iMaxCappi;
        if(fnConvertHdfDataset(pHdfProduct->m_totalProduct.m_ppCappi, 
                               pStdProduct->m_totalProduct.m_ppCappi,
                               pStdProduct->m_totalProduct.m_iMaxCappi, 
                               (int)pStdProduct->m_product_hdr.m_lYsize,
                               (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_HDF_ERROR("fnConvertHdfDataset CAPPI fail") return NULL; }
    }

    if(pStdProduct->m_totalProduct.m_iMaxBase > 0)
    {
        pHdfProduct->m_totalProduct.m_iMaxBase = pStdProduct->m_totalProduct.m_iMaxBase;
        if(fnConvertHdfDataset(pHdfProduct->m_totalProduct.m_ppBase, 
                               pStdProduct->m_totalProduct.m_ppBase,
                               pStdProduct->m_totalProduct.m_iMaxBase, 
                               (int)pStdProduct->m_product_hdr.m_lYsize,
                               (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_HDF_ERROR("fnConvertHdfDataset BASE fail") return NULL; }
    }

    if(pStdProduct->m_totalProduct.m_iMaxCmax > 0)
    {
        pHdfProduct->m_totalProduct.m_iMaxCmax = pStdProduct->m_totalProduct.m_iMaxCmax;
        if(fnConvertHdfDataset(pHdfProduct->m_totalProduct.m_ppCmax, 
                               pStdProduct->m_totalProduct.m_ppCmax,
                               pStdProduct->m_totalProduct.m_iMaxCmax, 
                               (int)pStdProduct->m_product_hdr.m_lYsize,
                               (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_HDF_ERROR("fnConvertHdfDataset CMAX fail") return NULL; }
    }

    if(pStdProduct->m_totalProduct.m_iMaxVil > 0)
    {
        pHdfProduct->m_totalProduct.m_iMaxVil = pStdProduct->m_totalProduct.m_iMaxVil;
        if(fnConvertHdfDataset(pHdfProduct->m_totalProduct.m_ppVil, 
                               pStdProduct->m_totalProduct.m_ppVil,
                               pStdProduct->m_totalProduct.m_iMaxVil, 
                               (int)pStdProduct->m_product_hdr.m_lYsize,
                               (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_HDF_ERROR("fnConvertHdfDataset VIL fail") return NULL; }
    }

    if(pStdProduct->m_totalProduct.m_iMaxEtop > 0)
    {
        pHdfProduct->m_totalProduct.m_iMaxEtop = pStdProduct->m_totalProduct.m_iMaxEtop;
        if(fnConvertHdfDataset(pHdfProduct->m_totalProduct.m_ppEtop, 
                               pStdProduct->m_totalProduct.m_ppEtop,
                               pStdProduct->m_totalProduct.m_iMaxEtop, 
                               (int)pStdProduct->m_product_hdr.m_lYsize,
                               (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_HDF_ERROR("fnConvertHdfDataset ETOP fail") return NULL; }
    }

    return pHdfProduct;
}

BUFR_PRODUCT* fnStdProductSyncDownBufr(STD_PRODUCT *pStdProduct)
{
#define FN_STD_PRODUCT_SYNC_DOWN_BUFR_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pBufrProduct != NULL) { fnFreeBufrProduct(pBufrProduct); }

    BUFR_PRODUCT*    pBufrProduct    = NULL;     // VARIABLE

    if(pStdProduct == NULL)
        return NULL;

    pBufrProduct = fnInitBufrProductToStdProduct(pStdProduct);
    if(pBufrProduct == NULL)
    {   FN_STD_PRODUCT_SYNC_DOWN_BUFR_ERROR("fnInitBufrProductToStdProduct fail") return NULL; }

    if(pStdProduct->m_iStdProductType == STD_EN_PRODUCT_SITE)
        pBufrProduct->m_iBufrProductType = BUFR_EN_PRODUCT_SITE;
    else if(pStdProduct->m_iStdProductType == STD_EN_PRODUCT_COMP)
        pBufrProduct->m_iBufrProductType = BUFR_EN_PRODUCT_COMP;

    snprintf(pBufrProduct->m_szConventions, 
             sizeof(pBufrProduct->m_szConventions), RDR_DF_BUFR_CONVENTIONS_STR);

    fnConvertBufrTop(pBufrProduct, pStdProduct);

    if(pStdProduct->m_totalProduct.m_iMaxPpi > 0)
    {
        pBufrProduct->m_totalProduct.m_iMaxPpi = pStdProduct->m_totalProduct.m_iMaxPpi;
        if(fnConvertBufrDataset(pBufrProduct->m_totalProduct.m_ppPpi, 
                                pStdProduct->m_totalProduct.m_ppPpi,
                                pStdProduct->m_totalProduct.m_iMaxPpi, 
                                (int)pStdProduct->m_product_hdr.m_lYsize,
                                (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_BUFR_ERROR("fnConvertBufrDataset PPI fail") return NULL; }
    }

    if(pStdProduct->m_totalProduct.m_iMaxCappi > 0)
    {
        pBufrProduct->m_totalProduct.m_iMaxCappi = pStdProduct->m_totalProduct.m_iMaxCappi;
        if(fnConvertBufrDataset(pBufrProduct->m_totalProduct.m_ppCappi, 
                                pStdProduct->m_totalProduct.m_ppCappi,
                                pStdProduct->m_totalProduct.m_iMaxCappi, 
                                (int)pStdProduct->m_product_hdr.m_lYsize,
                                (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_BUFR_ERROR("fnConvertBufrDataset CAPPI fail") return NULL; }
    }

    if(pStdProduct->m_totalProduct.m_iMaxBase > 0)
    {
        pBufrProduct->m_totalProduct.m_iMaxBase = pStdProduct->m_totalProduct.m_iMaxBase;
        if(fnConvertBufrDataset(pBufrProduct->m_totalProduct.m_ppBase, 
                                pStdProduct->m_totalProduct.m_ppBase,
                                pStdProduct->m_totalProduct.m_iMaxBase, 
                                (int)pStdProduct->m_product_hdr.m_lYsize,
                                (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_BUFR_ERROR("fnConvertBufrDataset BASE fail") return NULL; }
    }

    if(pStdProduct->m_totalProduct.m_iMaxCmax > 0)
    {
        pBufrProduct->m_totalProduct.m_iMaxCmax = pStdProduct->m_totalProduct.m_iMaxCmax;
        if(fnConvertBufrDataset(pBufrProduct->m_totalProduct.m_ppCmax, 
                                pStdProduct->m_totalProduct.m_ppCmax,
                                pStdProduct->m_totalProduct.m_iMaxCmax, 
                                (int)pStdProduct->m_product_hdr.m_lYsize,
                                (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_BUFR_ERROR("fnConvertBufrDataset CMAX fail") return NULL; }
    }

    if(pStdProduct->m_totalProduct.m_iMaxVil > 0)
    {
        pBufrProduct->m_totalProduct.m_iMaxVil = pStdProduct->m_totalProduct.m_iMaxVil;
        if(fnConvertBufrDataset(pBufrProduct->m_totalProduct.m_ppVil, 
                                pStdProduct->m_totalProduct.m_ppVil,
                                pStdProduct->m_totalProduct.m_iMaxVil, 
                                (int)pStdProduct->m_product_hdr.m_lYsize,
                                (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_BUFR_ERROR("fnConvertBufrDataset VIL fail") return NULL; }
    }

    if(pStdProduct->m_totalProduct.m_iMaxEtop > 0)
    {
        pBufrProduct->m_totalProduct.m_iMaxEtop = pStdProduct->m_totalProduct.m_iMaxEtop;
        if(fnConvertBufrDataset(pBufrProduct->m_totalProduct.m_ppEtop, 
                                pStdProduct->m_totalProduct.m_ppEtop,
                                pStdProduct->m_totalProduct.m_iMaxEtop, 
                                (int)pStdProduct->m_product_hdr.m_lYsize,
                                (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_BUFR_ERROR("fnConvertBufrDataset ETOP fail") return NULL; }
    }

    return pBufrProduct;
}

GRIB_PRODUCT* fnStdProductSyncDownGrib(STD_PRODUCT *pStdProduct)
{
#define FN_STD_PRODUCT_SYNC_DOWN_GRIB_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pGribProduct != NULL) { fnFreeGribProduct(pGribProduct); }

    GRIB_PRODUCT*    pGribProduct   = NULL;     // VARIABLE

    if(pStdProduct == NULL)
        return NULL;

    pGribProduct = fnInitGribProductToStdProduct(pStdProduct);
    if(pGribProduct == NULL)
    {   FN_STD_PRODUCT_SYNC_DOWN_GRIB_ERROR("fnInitGribProductToStdProduct fail") return NULL; }

    if(pStdProduct->m_iStdProductType == STD_EN_PRODUCT_SITE)
        pGribProduct->m_iGribProductType = GRIB_EN_PRODUCT_SITE;
    else if(pStdProduct->m_iStdProductType == STD_EN_PRODUCT_COMP)
        pGribProduct->m_iGribProductType = GRIB_EN_PRODUCT_COMP;

    fnConvertGribTop(pGribProduct, pStdProduct);

    if(pStdProduct->m_totalProduct.m_iMaxPpi > 0)
    {
        pGribProduct->m_totalProduct.m_iMaxPpi = pStdProduct->m_totalProduct.m_iMaxPpi;
        if(fnConvertGribDataset(pGribProduct->m_totalProduct.m_ppPpi, 
                                pStdProduct->m_totalProduct.m_ppPpi,
                                pStdProduct->m_totalProduct.m_iMaxPpi, 
                                (int)pStdProduct->m_product_hdr.m_lYsize,
                                (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_GRIB_ERROR("fnConvertGribDataset PPI fail") return NULL; }
    }

    if(pStdProduct->m_totalProduct.m_iMaxCappi > 0)
    {
        pGribProduct->m_totalProduct.m_iMaxCappi = pStdProduct->m_totalProduct.m_iMaxCappi;
        if(fnConvertGribDataset(pGribProduct->m_totalProduct.m_ppCappi, 
                                pStdProduct->m_totalProduct.m_ppCappi,
                                pStdProduct->m_totalProduct.m_iMaxCappi, 
                                (int)pStdProduct->m_product_hdr.m_lYsize,
                                (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_GRIB_ERROR("fnConvertGribDataset CAPPI fail") return NULL; }
    }

    if(pStdProduct->m_totalProduct.m_iMaxBase > 0)
    {
        pGribProduct->m_totalProduct.m_iMaxBase = pStdProduct->m_totalProduct.m_iMaxBase;
        if(fnConvertGribDataset(pGribProduct->m_totalProduct.m_ppBase, 
                                pStdProduct->m_totalProduct.m_ppBase,
                                pStdProduct->m_totalProduct.m_iMaxBase, 
                                (int)pStdProduct->m_product_hdr.m_lYsize,
                                (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_GRIB_ERROR("fnConvertGribDataset BASE fail") return NULL; }
    }

    if(pStdProduct->m_totalProduct.m_iMaxCmax > 0)
    {
        pGribProduct->m_totalProduct.m_iMaxCmax = pStdProduct->m_totalProduct.m_iMaxCmax;
        if(fnConvertGribDataset(pGribProduct->m_totalProduct.m_ppCmax, 
                                pStdProduct->m_totalProduct.m_ppCmax,
                                pStdProduct->m_totalProduct.m_iMaxCmax, 
                                (int)pStdProduct->m_product_hdr.m_lYsize,
                                (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_GRIB_ERROR("fnConvertGribDataset CMAX fail") return NULL; }
    }

    if(pStdProduct->m_totalProduct.m_iMaxVil > 0)
    {
        pGribProduct->m_totalProduct.m_iMaxVil = pStdProduct->m_totalProduct.m_iMaxVil;
        if(fnConvertGribDataset(pGribProduct->m_totalProduct.m_ppVil, 
                                pStdProduct->m_totalProduct.m_ppVil,
                                pStdProduct->m_totalProduct.m_iMaxVil, 
                                (int)pStdProduct->m_product_hdr.m_lYsize,
                                (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_GRIB_ERROR("fnConvertGribDataset VIL fail") return NULL; }
    }

    if(pStdProduct->m_totalProduct.m_iMaxEtop > 0)
    {
        pGribProduct->m_totalProduct.m_iMaxEtop = pStdProduct->m_totalProduct.m_iMaxEtop;
        if(fnConvertGribDataset(pGribProduct->m_totalProduct.m_ppEtop, 
                                pStdProduct->m_totalProduct.m_ppEtop,
                                pStdProduct->m_totalProduct.m_iMaxEtop, 
                                (int)pStdProduct->m_product_hdr.m_lYsize,
                                (int)pStdProduct->m_product_hdr.m_lXsize) == FALSE)
        {   FN_STD_PRODUCT_SYNC_DOWN_GRIB_ERROR("fnConvertGribDataset ETOP fail") return NULL; }
    }

    return pGribProduct;
}

float** fnGetStdProductDataByIdxDBZ(STD_PRODUCT *pStdProduct, char *szProduct, int iProductIdx)
{
    float                   **ppData            = NULL;

    ppData = fnGetStdProductDataByIdx(pStdProduct, szProduct, iProductIdx, "CZ");
    if(ppData == NULL)
        ppData = fnGetStdProductDataByIdx(pStdProduct, szProduct, iProductIdx, "DZ");

    return ppData;
}

float** fnGetStdProductDataByIdx(STD_PRODUCT *pStdProduct, char *szProduct, int iProductIdx, char *szFieldName)
{
    STD_PRODUCT_DATASET     **ppStdDataset      = NULL;
    STD_PRODUCT_DATASET     *pStdDataset        = NULL;
    STD_PRODUCT_DATA        *pStdProductData    = NULL;
    int                     iMaxDataset         = 0;
    int                     iFieldIdx           = 0;
    float                   **ppData            = NULL;
    int                     iYIdx               = 0;
    int                     iXIdx               = 0;
    char                    cData               = 0;
    short                   sData               = 0;
    float                   fData               = 0.0;
    FIELD_MEM_INFO_TBL      memInfo;

    if(pStdProduct == NULL || szProduct == NULL || szFieldName == NULL)
        return NULL;

    if(!strcmp(szFieldName, ""))
        return NULL;

    ppStdDataset = fnFindDsetStdProduct(pStdProduct, szProduct, &iMaxDataset);
    if(ppStdDataset == NULL || iMaxDataset <= iProductIdx)
        return NULL;

    pStdDataset = ppStdDataset[iProductIdx];
    if(pStdDataset == NULL || pStdDataset->m_ppProductData == NULL)
        return NULL;

    for(iFieldIdx = 0; iFieldIdx < pStdDataset->m_iMaxField; iFieldIdx++)
    {
        if(pStdDataset->m_ppProductData[iFieldIdx] == NULL)
            continue;

        if(!strcmp(pStdDataset->m_ppProductData[iFieldIdx]->m_szFieldName, ""))
            continue;

        if(!strcmp(szFieldName, pStdDataset->m_ppProductData[iFieldIdx]->m_szFieldName))
        {
            pStdProductData = pStdDataset->m_ppProductData[iFieldIdx];
            break;
        }
    }

    memset(&memInfo, 0x00, sizeof(FIELD_MEM_INFO_TBL));
    if(fnGetFieldMemInfo(szFieldName, &memInfo) == RDR_DF_FALSE)
        return NULL;

    if(pStdProductData != NULL)
    {
        ppData = fnMakeMatrix2D_F(pStdProduct->m_product_hdr.m_lYsize,
                                  pStdProduct->m_product_hdr.m_lXsize);
        if(ppData == NULL)
            return NULL;

        if(pStdProductData->m_iMemType == RDR_EN_MEM_CHAR && 
           pStdProductData->m_ppData_c != NULL)
        {
            for(iYIdx = 0; iYIdx < pStdProduct->m_product_hdr.m_lYsize; iYIdx++)
            {
                for(iXIdx = 0; iXIdx < pStdProduct->m_product_hdr.m_lXsize; iXIdx++)
                {
                    cData = pStdProductData->m_ppData_c[iYIdx][iXIdx];

                    if(fabs(cData - memInfo.m_fOutBound) < RDR_DF_ERR_RANGE_F)
                        ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
                    else if(fabs(cData - memInfo.m_fBadValue) < RDR_DF_ERR_RANGE_F)
                        ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
                    else
                    {
                        ppData[iYIdx][iXIdx] 
                        = (float)((cData/memInfo.m_fScale) - memInfo.m_fOffset);
                    }
                }
            }
        }
        else if(pStdProductData->m_iMemType == RDR_EN_MEM_SHORT && 
                pStdProductData->m_ppData_s != NULL)
        {
            for(iYIdx = 0; iYIdx < pStdProduct->m_product_hdr.m_lYsize; iYIdx++)
            {
                for(iXIdx = 0; iXIdx < pStdProduct->m_product_hdr.m_lXsize; iXIdx++)
                {
                    sData = pStdProductData->m_ppData_s[iYIdx][iXIdx];

                    if(fabs(sData - memInfo.m_fOutBound) < RDR_DF_ERR_RANGE_F)
                        ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
                    else if(fabs(sData - memInfo.m_fBadValue) < RDR_DF_ERR_RANGE_F)
                        ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
                    else
                    {
                        ppData[iYIdx][iXIdx] 
                        = (float)((sData/memInfo.m_fScale) - memInfo.m_fOffset);
                    }
                }
            }
        }
        else if(pStdProductData->m_iMemType == RDR_EN_MEM_FLOAT && 
                pStdProductData->m_ppData_f != NULL)
        {
            for(iYIdx = 0; iYIdx < pStdProduct->m_product_hdr.m_lYsize; iYIdx++)
            {
                for(iXIdx = 0; iXIdx < pStdProduct->m_product_hdr.m_lXsize; iXIdx++)
                {
                    fData = pStdProductData->m_ppData_f[iYIdx][iXIdx];

                    if(fabs(fData - memInfo.m_fOutBound) < RDR_DF_ERR_RANGE_F)
                        ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
                    else if(fabs(fData - memInfo.m_fBadValue) < RDR_DF_ERR_RANGE_F)
                        ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
                    else
                    {
                        ppData[iYIdx][iXIdx] 
                        = (float)((fData/memInfo.m_fScale) - memInfo.m_fOffset);
                    }
                }
            }
        }
    }

    return ppData;
}

float** fnGetStdProductDataByArgDBZ(STD_PRODUCT *pStdProduct, char *szProduct, double dProductArg1, double dProductArg2)
{
    float                   **ppData            = NULL;

    ppData = fnGetStdProductDataByArg(pStdProduct, szProduct, 
                                      dProductArg1, dProductArg2, "CZ");
    if(ppData == NULL)
    {
        ppData = fnGetStdProductDataByArg(pStdProduct, szProduct, 
                                          dProductArg1, dProductArg2, "DZ");
    }

    return ppData;
}

float** fnGetStdProductDataByArg(STD_PRODUCT *pStdProduct, char *szProduct, double dProductArg1, double dProductArg2, char *szFieldName)
{
    STD_PRODUCT_DATASET     **ppStdDataset      = NULL;
    STD_PRODUCT_DATASET     *pStdDataset        = NULL;
    STD_PRODUCT_DATA        *pStdProductData    = NULL;
    int                     iProductIdx         = 0;
    int                     iProductMax         = 0;
    int                     iFieldIdx           = 0;
    float                   **ppData            = NULL;
    int                     iYIdx               = 0;
    int                     iXIdx               = 0;
    char                    cData               = 0;
    short                   sData               = 0;
    float                   fData               = 0.0;
    FIELD_MEM_INFO_TBL      memInfo;

    if(pStdProduct == NULL || szProduct == NULL || szFieldName == NULL)
        return NULL;

    if(!strcmp(szFieldName, ""))
        return NULL;

    ppStdDataset = fnFindDsetStdProduct(pStdProduct, szProduct, &iProductMax);
    if(ppStdDataset == NULL)
        return NULL;

    for(iProductIdx = 0; iProductIdx < iProductMax; iProductIdx++)
    {
        if(ppStdDataset[iProductIdx] == NULL)
            continue;
        
        if(fabs(ppStdDataset[iProductIdx]->m_dProdpar[0]-dProductArg1) <= RDR_DF_ERR_RANGE_D &&
           fabs(ppStdDataset[iProductIdx]->m_dProdpar[1]-dProductArg2) <= RDR_DF_ERR_RANGE_D)
            break;
    }

    if(iProductIdx >= iProductMax)
        return NULL;

    pStdDataset = ppStdDataset[iProductIdx];
    if(pStdDataset->m_ppProductData == NULL)
        return NULL;

    for(iFieldIdx = 0; iFieldIdx < pStdDataset->m_iMaxField; iFieldIdx++)
    {
        if(pStdDataset->m_ppProductData[iFieldIdx] == NULL)
            continue;

        if(!strcmp(pStdDataset->m_ppProductData[iFieldIdx]->m_szFieldName, ""))
            continue;

        if(!strcmp(szFieldName, pStdDataset->m_ppProductData[iFieldIdx]->m_szFieldName))
        {
            pStdProductData = pStdDataset->m_ppProductData[iFieldIdx];
            break;
        }
    }

    memset(&memInfo, 0x00, sizeof(FIELD_MEM_INFO_TBL));
    if(fnGetFieldMemInfo(szFieldName, &memInfo) == RDR_DF_FALSE)
        return NULL;

    if(pStdProductData != NULL)
    {
        ppData = fnMakeMatrix2D_F(pStdProduct->m_product_hdr.m_lYsize,
                                  pStdProduct->m_product_hdr.m_lXsize);
        if(ppData == NULL)
            return NULL;

        if(pStdProductData->m_iMemType == RDR_EN_MEM_CHAR && 
           pStdProductData->m_ppData_c != NULL)
        {
            for(iYIdx = 0; iYIdx < pStdProduct->m_product_hdr.m_lYsize; iYIdx++)
            {
                for(iXIdx = 0; iXIdx < pStdProduct->m_product_hdr.m_lXsize; iXIdx++)
                {
                    cData = pStdProductData->m_ppData_c[iYIdx][iXIdx];

                    if(fabs(cData - memInfo.m_fOutBound) < RDR_DF_ERR_RANGE_F)
                        ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
                    else if(fabs(cData - memInfo.m_fBadValue) < RDR_DF_ERR_RANGE_F)
                        ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
                    else
                    {
                        ppData[iYIdx][iXIdx] 
                        = (float)((cData/memInfo.m_fScale) - memInfo.m_fOffset);
                    }
                }
            }
        }
        else if(pStdProductData->m_iMemType == RDR_EN_MEM_SHORT && 
                pStdProductData->m_ppData_s != NULL)
        {
            for(iYIdx = 0; iYIdx < pStdProduct->m_product_hdr.m_lYsize; iYIdx++)
            {
                for(iXIdx = 0; iXIdx < pStdProduct->m_product_hdr.m_lXsize; iXIdx++)
                {
                    sData = pStdProductData->m_ppData_s[iYIdx][iXIdx];

                    if(fabs(sData - memInfo.m_fOutBound) < RDR_DF_ERR_RANGE_F)
                        ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
                    else if(fabs(sData - memInfo.m_fBadValue) < RDR_DF_ERR_RANGE_F)
                        ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
                    else
                    {
                        ppData[iYIdx][iXIdx] 
                        = (float)((sData/memInfo.m_fScale) - memInfo.m_fOffset);
                    }
                }
            }
        }
        else if(pStdProductData->m_iMemType == RDR_EN_MEM_FLOAT && 
                pStdProductData->m_ppData_f != NULL)
        {
            for(iYIdx = 0; iYIdx < pStdProduct->m_product_hdr.m_lYsize; iYIdx++)
            {
                for(iXIdx = 0; iXIdx < pStdProduct->m_product_hdr.m_lXsize; iXIdx++)
                {
                    fData = pStdProductData->m_ppData_s[iYIdx][iXIdx];

                    if(fabs(fData - memInfo.m_fOutBound) < RDR_DF_ERR_RANGE_F)
                        ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
                    else if(fabs(fData - memInfo.m_fBadValue) < RDR_DF_ERR_RANGE_F)
                        ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
                    else
                    {
                        ppData[iYIdx][iXIdx] 
                        = (float)((fData/memInfo.m_fScale) - memInfo.m_fOffset);
                    }
                }
            }
        }
    }

    return ppData;
}

int fnGetStdProductProdpar(STD_PRODUCT *pStdProduct, char *szProduct, int iProductIdx, double *pProductArg1, double *pProductArg2)
{
    STD_PRODUCT_DATASET     **ppStdDataset      = NULL;
    int                     iMaxDataset         = 0;

    if(pStdProduct == NULL || szProduct == NULL || iProductIdx < 0)
        return FALSE;

    ppStdDataset = fnFindDsetStdProduct(pStdProduct, szProduct, &iMaxDataset);
    if(ppStdDataset == NULL || iMaxDataset <= iProductIdx)
        return FALSE;

    if(ppStdDataset == NULL || ppStdDataset[iProductIdx] == NULL)
        return FALSE;

    if(pProductArg1 != NULL) *pProductArg1 = ppStdDataset[iProductIdx]->m_dProdpar[0];
    if(pProductArg2 != NULL) *pProductArg2 = ppStdDataset[iProductIdx]->m_dProdpar[1];

    return TRUE;
}

STD_PRODUCT_DATASET** fnFindDsetStdProduct(STD_PRODUCT *pStdProduct, char *szProduct, int *pMaxDset)
{
    STD_PRODUCT_DATASET **ppStdDataset  = NULL;
    int                 iProductMax     = 0;

    if(pStdProduct == NULL || szProduct == NULL || pMaxDset == NULL)
        return NULL;

    if(!strcmp(szProduct, "PPI"))
    {
        ppStdDataset = pStdProduct->m_totalProduct.m_ppPpi;
        iProductMax  = pStdProduct->m_totalProduct.m_iMaxPpi;
    }
    else if(!strcmp(szProduct, "CAPPI"))
    {
        ppStdDataset = pStdProduct->m_totalProduct.m_ppCappi;
        iProductMax  = pStdProduct->m_totalProduct.m_iMaxCappi;
    }
    else if(!strcmp(szProduct, "BASE"))
    {
        ppStdDataset = pStdProduct->m_totalProduct.m_ppBase;
        iProductMax  = pStdProduct->m_totalProduct.m_iMaxBase;
    }
    else if(!strcmp(szProduct, "CMAX"))
    {
        ppStdDataset = pStdProduct->m_totalProduct.m_ppCmax;
        iProductMax  = pStdProduct->m_totalProduct.m_iMaxCmax;
    }
    else if(!strcmp(szProduct, "VIL"))
    {
        ppStdDataset = pStdProduct->m_totalProduct.m_ppVil;
        iProductMax  = pStdProduct->m_totalProduct.m_iMaxVil;
    }
    else if(!strcmp(szProduct, "ETOP"))
    {
        ppStdDataset = pStdProduct->m_totalProduct.m_ppEtop;
        iProductMax  = pStdProduct->m_totalProduct.m_iMaxEtop;
    }
    else
        return NULL;

    if(pMaxDset != NULL) *pMaxDset = iProductMax;

    return ppStdDataset;
}

HDF_RADAR* fnStdSyncDownHdf(STD_RADAR *pStd)
{
#define FN_STD_SYNC_DOWN_HDF_ERROR(MSG) \
    fprintf(stderr, "%s :%s\n", __func__, MSG); \
    if(pHdf != NULL) { fnFreeHdfRadar(pHdf); }

    STD_SWEEP       *pStdSweep  = NULL;
    HDF_RADAR       *pHdf       = NULL;
    HDF_DATASET     *pHdfDset   = NULL;
    HDF_DATA        *pHdfData   = NULL;
    int             iMaxSweep   = 0;
    int             iMaxField   = 0;
    int             iSweepIdx   = 0;
    int             iFieldIdx   = 0;
    int             iMaxRay     = 0;
    int             iMaxBin     = 0;

    if(pStd == NULL)
        return NULL;

    if(fnValidStdRadar(pStd) == FALSE)
    {   FN_STD_SYNC_DOWN_HDF_ERROR("fnValidStdRadar fail") return NULL; }

    if(fnGetMaxCountStd(pStd, NULL, &iMaxSweep, NULL, NULL, &iMaxField) == FALSE)
    {   FN_STD_SYNC_DOWN_HDF_ERROR("fnGetMaxCountStd fail") return NULL; }
    
    if(iMaxSweep <= 0 || iMaxField <= 0)
    {   FN_STD_SYNC_DOWN_HDF_ERROR("fnGetMaxCountStd error") return NULL; }

    if((pHdf = fnInitHdfRadar(iMaxSweep, iMaxField, 0, 0)) == NULL)
    {   FN_STD_SYNC_DOWN_HDF_ERROR("fnInitHdfRadar fail") return NULL; }

    pHdf->m_iHdfType = HDF_EN_R_TYPE_POLAR;
    snprintf(pHdf->m_szConventions, sizeof(pHdf->m_szConventions),
             "%s", RDR_DF_HDF_CONVENTIONS_STR);

    // TOP WHAT
    fnStdToHdfTopWhat(pStd, pHdf);
    // TOP WHERE
    fnStdToHdfTopWhere(pStd, pHdf);
    // TOP HOW
    fnStdToHdfTopHow(pStd, pHdf);

    for(iSweepIdx = 0; iSweepIdx < iMaxSweep; iSweepIdx++)
    {
        pStdSweep = pStd->m_ppSweep[iSweepIdx];
        pHdfDset  = pHdf->m_ppDataset[iSweepIdx];

        if(pStdSweep == NULL)
            continue;

        // Dataset WHAT
        fnStdToHdfDsetWhat(pStdSweep, pHdfDset);
        // Dataset WHERE
        fnStdToHdfDsetWhere(pStdSweep, pHdfDset);
        // Dataset HOW
        fnStdToHdfDsetHow(pStdSweep, pHdfDset);

        fnGetSweepMaxCountStd(pStdSweep, &iMaxRay, NULL, &iMaxBin);

        for(iFieldIdx = 0; iFieldIdx < iMaxField; iFieldIdx++)
        {
            pHdfData = pHdfDset->m_ppData[iFieldIdx];

            // Data WHAT
            if(fnStdToHdfDataWhat(pStdSweep, iFieldIdx, pHdfData, 
                                  pStd->m_hdr.m_iNoDataValue) == FALSE)
                continue;

            // Data
            if(fnStdToHdfData(pStdSweep, iMaxRay, iMaxBin, iFieldIdx, pHdfData) == FALSE)
            {   FN_STD_SYNC_DOWN_HDF_ERROR("fnStdToHdfData fail") return NULL; }
        }
    }

    return pHdf;
}







