/* ================================================================================ */
//
// Radar Grib2 Kma Input Format & Input Function
//
// 2016.11.28 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"

#include <grib_api.h>

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function

static GRIB_RADAR* fnInitGribRadar(grib_handle *hGrib)
{
    GRIB_RADAR      *pGrib      = NULL;
    GRIB_VOLUME     *pVolume    = NULL;
    int             iVolumeIdx  = 0;
    long            lMaxSweep   = 0;
    long            lMaxRay     = 0;
    long            lMaxBin     = 0;
    long            lMaxField   = 0;

    if(hGrib == NULL)
        return NULL;

    grib_get_long(hGrib, "rdc_sweep_count", &lMaxSweep);
    grib_get_long(hGrib, "rdc_ray_count",   &lMaxRay);
    grib_get_long(hGrib, "rdc_bin_count",   &lMaxBin);
    grib_get_long(hGrib, "rdc_field_count", &lMaxField);

    if(lMaxSweep <= 0 || lMaxRay <= 0 || lMaxBin <= 0 || lMaxField <= 0)
        return NULL;

    if((pGrib = (GRIB_RADAR *)calloc(1, sizeof(GRIB_RADAR))) == NULL)
        return NULL;

    pGrib->m_hdr.m_iMaxSweep  = (int)lMaxSweep;
    pGrib->m_hdr.m_iMaxRay    = (int)lMaxRay;
    pGrib->m_hdr.m_iMaxBin    = (int)lMaxBin;
    pGrib->m_hdr.m_iMaxField  = (int)lMaxField;

    pGrib->m_hdr.m_pMaxRay       = (long *)  calloc((int)lMaxSweep,sizeof(long));
    pGrib->m_hdr.m_pMaxBin       = (long *)  calloc((int)lMaxRay,  sizeof(long));
    pGrib->m_hdr.m_pRayTime      = (double *)calloc((int)lMaxRay,  sizeof(double));
    pGrib->m_hdr.m_pRayAzimuth   = (double *)calloc((int)lMaxRay,  sizeof(double));
    pGrib->m_hdr.m_pRayElevation = (double *)calloc((int)lMaxRay,  sizeof(double));
    pGrib->m_hdr.m_pRayFixedAngle= (double *)calloc((int)lMaxRay,  sizeof(double));

    if(pGrib->m_hdr.m_pMaxRay           == NULL || pGrib->m_hdr.m_pMaxBin           == NULL ||
       pGrib->m_hdr.m_pRayTime          == NULL || pGrib->m_hdr.m_pRayAzimuth       == NULL ||
       pGrib->m_hdr.m_pRayElevation     == NULL || pGrib->m_hdr.m_pRayFixedAngle    == NULL)
    {   fnFreeGribRadar(pGrib); return NULL; }

    pGrib->m_iMaxVolume = pGrib->m_hdr.m_iMaxField;
    if((pGrib->m_ppVolume = calloc(pGrib->m_iMaxVolume, sizeof(GRIB_VOLUME *))) == NULL)
    {   fnFreeGribRadar(pGrib); return NULL; }

    for(iVolumeIdx = 0; iVolumeIdx < pGrib->m_iMaxVolume; iVolumeIdx++)
    {
        pVolume = pGrib->m_ppVolume[iVolumeIdx] = calloc(1, sizeof(GRIB_VOLUME));
        if(pVolume == NULL)
        {   fnFreeGribRadar(pGrib); return NULL; }

        pVolume->m_pData = calloc(lMaxBin*lMaxRay, sizeof(short));
        if(pVolume->m_pData == NULL)
        {   fnFreeGribRadar(pGrib); return NULL; }
    }

    return pGrib;
}

static GRIB_PRODUCT_DATASET** fnFindGribProductDset(GRIB_PRODUCT* pGribProduct, char *szProduct, int *pMaxDset)
{
    GRIB_PRODUCT_DATASET    **ppDset        = NULL;
    int                     iMaxDset        = 0;

    if(pGribProduct == NULL || szProduct == NULL || pMaxDset == NULL)
        return NULL;

    if(!strcmp(szProduct, "PPI"))
    {
        iMaxDset = pGribProduct->m_totalProduct.m_iMaxPpi;
        ppDset   = pGribProduct->m_totalProduct.m_ppPpi;
    }
    else if(!strcmp(szProduct, "CAPPI"))
    {
        iMaxDset = pGribProduct->m_totalProduct.m_iMaxCappi;
        ppDset   = pGribProduct->m_totalProduct.m_ppCappi;
    }
    else if(!strcmp(szProduct, "BASE"))
    {
        iMaxDset = pGribProduct->m_totalProduct.m_iMaxBase;
        ppDset   = pGribProduct->m_totalProduct.m_ppBase;
    }
    else if(!strcmp(szProduct, "CMAX"))
    {
        iMaxDset = pGribProduct->m_totalProduct.m_iMaxCmax;
        ppDset   = pGribProduct->m_totalProduct.m_ppCmax;
    }
    else if(!strcmp(szProduct, "VIL"))
    {
        iMaxDset = pGribProduct->m_totalProduct.m_iMaxVil;
        ppDset   = pGribProduct->m_totalProduct.m_ppVil;
    }
    else if(!strcmp(szProduct, "ETOP"))
    {
        iMaxDset = pGribProduct->m_totalProduct.m_iMaxEtop;
        ppDset   = pGribProduct->m_totalProduct.m_ppEtop;
    }
    else
        return NULL;

    if(pMaxDset != NULL) *pMaxDset = iMaxDset;

    return ppDset;
}

static void fnSetGribProductNameParam(GRIB_PRODUCT* pGribProduct, char *szProduct, double *pProdpar)
{
    GRIB_PRODUCT_DATASET    **ppDset        = NULL;
    int                     iMaxDset        = 0;
    int                     iDsetIdx        = 0;

    if(pGribProduct == NULL || szProduct == NULL || pProdpar == NULL)
        return;

    ppDset = fnFindGribProductDset(pGribProduct, szProduct, &iMaxDset);
    if(ppDset == NULL)
        return;

    for(iDsetIdx = 0; iDsetIdx < iMaxDset*2; iDsetIdx+=2)
    {
        if(ppDset[iDsetIdx] == NULL)
            continue;

        snprintf(ppDset[iDsetIdx]->m_what.m_szProduct, 
                 sizeof(ppDset[iDsetIdx]->m_what.m_szProduct), "%s", szProduct);

        ppDset[iDsetIdx]->m_what.m_dProdpar[0] = pProdpar[iDsetIdx];
        ppDset[iDsetIdx]->m_what.m_dProdpar[1] = pProdpar[iDsetIdx+1];
    }
}
    
static int fnReadGribRadarGlobalHead(grib_handle *hGrib, GRIB_RADAR *pGrib)
{
    long            lYear                   = 0;
    long            lMonth                  = 0;
    long            lDay                    = 0;
    long            lHour                   = 0;
    long            lMinute                 = 0;
    long            lSecond                 = 0;
    long            lValue                  = 0;
    long            cx                      = 0;
    long            cy                      = 0;
    double          dValue                  = 0.0;
    size_t          len                     = 0;
    size_t          uiMaxSweep              = 0;
    size_t          uiMaxRay                = 0;
    int             iVolumeIdx              = 0;
    char            szTmp[STR_LENGTH_MAX]   = "";
    char            *pSp[RDR_DF_MAX_FIELD]  = { NULL, };

    if(hGrib == NULL || pGrib == NULL)
        return FALSE;

    grib_get_long(hGrib, "year",   &lYear);
    grib_get_long(hGrib, "month",  &lMonth);
    grib_get_long(hGrib, "day",    &lDay);
    grib_get_long(hGrib, "hour",   &lHour);
    grib_get_long(hGrib, "minute", &lMinute);
    grib_get_long(hGrib, "second", &lSecond);

    pGrib->m_hdr.m_tConvertTime = fnMakeTime(FALSE, (short)lYear,   (short)lMonth, 
                                                    (short)lDay,    (short)lHour, 
                                                    (short)lMinute, (short)lSecond);

    grib_get_long(hGrib, "missingValue", &lValue);
    pGrib->m_hdr.m_iNoDataValue = (int)lValue;

    grib_get_long(hGrib, "siteLatitude", &lValue);
    pGrib->m_hdr.m_dLat = lValue/1000000.;

    grib_get_long(hGrib, "siteLongitude", &lValue);
    pGrib->m_hdr.m_dLon = lValue/1000000.;

    grib_get_long(hGrib, "siteElevation", &lValue);
    pGrib->m_hdr.m_iAnteHeight = (int)lValue;

    grib_get_long(hGrib, "rangeBinSpacing", &lValue);
    pGrib->m_hdr.m_iBinSpacing = (int)lValue;

//    grib_get_long(hGrib, "decimalScaleFactor", &lValue);
//    pGrib->m_hdr.m_iScaleFactor = (int)lValue;

    // ADD by RDC
    len = sizeof(pGrib->m_hdr.m_szRadarName);
    grib_get_string(hGrib, "rdc_radar_name", pGrib->m_hdr.m_szRadarName, &len);

    len = sizeof(pGrib->m_hdr.m_szSiteName);
    grib_get_string(hGrib, "rdc_site_name", pGrib->m_hdr.m_szSiteName, &len);

    len = sizeof(pGrib->m_hdr.m_szConvertName);
    grib_get_string(hGrib, "rdc_generator_name", pGrib->m_hdr.m_szConvertName, &len);

    grib_get_long(hGrib, "rdc_sweep_mode", &lValue);
    pGrib->m_hdr.m_iSweepMode = (int)lValue;

    grib_get_double(hGrib, "rdc_sweep_rate", &dValue);
    pGrib->m_hdr.m_fSweepRate = (float)dValue;

    grib_get_long(hGrib, "rdc_scale_factor", &lValue);
    pGrib->m_hdr.m_iScaleFactor = (int)lValue;

    grib_get_double(hGrib, "rdc_start_range_meter", &dValue);
    pGrib->m_hdr.m_fStartRangeMeter = (float)dValue;
 
    grib_get_long(hGrib, "rdc_pulse_width", &lValue);
    pGrib->m_hdr.m_iPulseWidth = (int)lValue;

    grib_get_double(hGrib, "rdc_beam_width_h", &dValue);
    pGrib->m_hdr.m_fBeamWidthH = (float)dValue;

    grib_get_double(hGrib, "rdc_beam_width_v", &dValue);
    pGrib->m_hdr.m_fBeamWidthV = (float)dValue;

    grib_get_long(hGrib, "rdc_band_width", &lValue);
    pGrib->m_hdr.m_iBandWidth = (int)lValue;

    grib_get_long(hGrib, "rdc_polar_mode", &lValue);
    pGrib->m_hdr.m_iPolarMode = (int)lValue;

    grib_get_double(hGrib, "rdc_wave_length", &dValue);
    pGrib->m_hdr.m_fWaveLength = (float)dValue;

    grib_get_long(hGrib, "rdc_sample_size", &lValue);
    pGrib->m_hdr.m_iSampleSize = (int)lValue;

    grib_get_long(hGrib, "rdc_threshold_value", &lValue);
    pGrib->m_hdr.m_iThresholdValue = (int)lValue;

    grib_get_long(hGrib, "rdc_scale", &lValue);
    pGrib->m_hdr.m_iScale = (int)lValue;

    grib_get_long(hGrib, "rdc_prt", &lValue);
    pGrib->m_hdr.m_iPRT = (int)lValue;

    grib_get_long(hGrib, "rdc_nodata_value", &lValue);
    pGrib->m_hdr.m_iNoDataValue = (int)lValue;

    // Ray Header
    uiMaxSweep = pGrib->m_hdr.m_iMaxSweep;
    uiMaxRay   = pGrib->m_hdr.m_iMaxRay;

    grib_get_long_array  (hGrib,"rdc_ray_number",      pGrib->m_hdr.m_pMaxRay,        &uiMaxSweep);
    grib_get_long_array  (hGrib,"rdc_bin_number",      pGrib->m_hdr.m_pMaxBin,        &uiMaxRay);
    grib_get_double_array(hGrib,"rdc_ray_time",        pGrib->m_hdr.m_pRayTime,       &uiMaxRay);
    grib_get_double_array(hGrib,"rdc_ray_azimuth",     pGrib->m_hdr.m_pRayAzimuth,    &uiMaxRay);
    grib_get_double_array(hGrib,"rdc_ray_elevation",   pGrib->m_hdr.m_pRayElevation,  &uiMaxRay);
    grib_get_double_array(hGrib,"rdc_ray_fixed_angle", pGrib->m_hdr.m_pRayFixedAngle, &uiMaxRay);

    // Voume Header
    grib_get_long(hGrib, "rdc_volume_width", &cx);
    grib_get_long(hGrib, "rdc_volume_height",&cy);
    grib_get_long(hGrib, "rdc_volume_count", &lValue);
    len = sizeof(szTmp) - 1;
    grib_get_string(hGrib, "rdc_volume_names", szTmp, &len);

    if((cx     != pGrib->m_hdr.m_iMaxBin) ||
       (cy     != pGrib->m_hdr.m_iMaxRay) ||
       (lValue != pGrib->m_iMaxVolume))
        return FALSE;

    // Get the field name
    fnSplit(szTmp, pSp, RDR_DF_MAX_FIELD, ':');
    for(iVolumeIdx = 0; iVolumeIdx < pGrib->m_iMaxVolume; iVolumeIdx++)
    {
        snprintf(pGrib->m_ppVolume[iVolumeIdx]->m_szName, 
                 sizeof(pGrib->m_ppVolume[iVolumeIdx]->m_szName), "%s", pSp[iVolumeIdx]);
    }
    // Added by RDC ------------------
    
    return TRUE;
}

static GRIB_PRODUCT* fnReadGribProductSize(grib_handle *hGrib, char *pBuf, int iBufLen, int *pMaxData)
{
    GRIB_PRODUCT            *pGribProduct   = NULL;
    size_t                  len             = 0;
    char                    szProduct[8+1]  = "";
    int                     iMaxDset        = 0;
    int                     iMaxPpi         = 0;
    int                     iMaxCappi       = 0;
    int                     iMaxBase        = 0;
    int                     iMaxCmax        = 0;
    int                     iMaxVil         = 0;
    int                     iMaxEtop        = 0;
    int                     iMaxField       = 0;
    long                    lValue          = 0;
    double                  *pProdpar       = NULL;

    if(hGrib == NULL || pBuf == NULL || pMaxData == NULL)
        return NULL;

    len = sizeof(szProduct);
    grib_get_string(hGrib, "rdr_product", szProduct, &len);

    snprintf(pBuf, iBufLen, "%s", szProduct);

    grib_get_long(hGrib, "rdr_max_product", &lValue);
    iMaxDset = (int)lValue;

    if(!strcmp(szProduct, "PPI"))
        iMaxPpi = iMaxDset;
    else if(!strcmp(szProduct, "CAPPI"))
        iMaxCappi = iMaxDset;
    else if(!strcmp(szProduct, "BASE"))
        iMaxBase = iMaxDset;
    else if(!strcmp(szProduct, "CMAX"))
        iMaxCmax = iMaxDset;
    else if(!strcmp(szProduct, "VIL"))
        iMaxVil = iMaxDset;
    else if(!strcmp(szProduct, "ETOP"))
        iMaxEtop = iMaxDset;
    else
        return NULL;

    lValue = 0;
    grib_get_long(hGrib, "rdr_max_data", &lValue);

    iMaxField = (int)lValue;

    pGribProduct = fnInitGribProduct(iMaxField, iMaxPpi,  iMaxCappi, iMaxBase, 
                                                iMaxCmax, iMaxVil,   iMaxEtop);
    if(pGribProduct == NULL)
        return NULL;

    if((pProdpar = (double *)calloc(iMaxDset*2, sizeof(double))) == NULL)
    {
        fnFreeGribProduct(pGribProduct);
        return NULL;
    }

    len = iMaxDset*2;
    grib_get_double_array(hGrib, "rdr_prodpar", pProdpar, &len);

    fnSetGribProductNameParam(pGribProduct, szProduct, pProdpar);

    free(pProdpar);

    if(pMaxData != NULL) *pMaxData = iMaxField;

    return pGribProduct;
}

static int fnReadGribProductGlobalHead(grib_handle *hGrib, GRIB_PRODUCT *pGribProduct)
{
    long            lYear                   = 0;
    long            lMonth                  = 0;
    long            lDay                    = 0;
    long            lHour                   = 0;
    long            lMinute                 = 0;
    long            lSecond                 = 0;
    long            lValue                  = 0;
    double          dValue                  = 0.0;
    size_t          len                     = 0;
    time_t          tConvertTime            = 0;
    struct  tm      tm;

    if(hGrib == NULL || pGribProduct == NULL)
        return FALSE;

    grib_get_long(hGrib, "year",   &lYear);
    grib_get_long(hGrib, "month",  &lMonth);
    grib_get_long(hGrib, "day",    &lDay);
    grib_get_long(hGrib, "hour",   &lHour);
    grib_get_long(hGrib, "minute", &lMinute);
    grib_get_long(hGrib, "second", &lSecond);

    tConvertTime = fnMakeTime(FALSE, (short)lYear,   (short)lMonth, 
                                     (short)lDay,    (short)lHour, 
                                     (short)lMinute, (short)lSecond);

    memset(&tm, 0x00, sizeof(struct tm));
    localtime_r(&tConvertTime, &tm);

    strftime(pGribProduct->m_what.m_szDate, 
             sizeof(pGribProduct->m_what.m_szDate), "%Y%m%d", &tm);

    strftime(pGribProduct->m_what.m_szTime, 
             sizeof(pGribProduct->m_what.m_szTime), "%H%M%S", &tm);


    grib_get_long(hGrib, "siteLatitude", &lValue);
    pGribProduct->m_where.m_dLat = lValue/1000000.;

    grib_get_long(hGrib, "siteLongitude", &lValue);
    pGribProduct->m_where.m_dLon = lValue/1000000.;

    grib_get_long(hGrib, "siteElevation", &lValue);
    pGribProduct->m_where.m_dHeightM = (int)lValue;

    len = sizeof(pGribProduct->m_where.m_szProjdef);
    grib_get_string(hGrib, "rdr_projdef", pGribProduct->m_where.m_szProjdef, &len);
    
    grib_get_long(hGrib, "rdr_xsize", &lValue);
    pGribProduct->m_where.m_lXsize = lValue;

    grib_get_long(hGrib, "rdr_ysize", &lValue);
    pGribProduct->m_where.m_lYsize = lValue;

    grib_get_double(hGrib, "rdr_xscale", &dValue);
    pGribProduct->m_where.m_dXscale = dValue;

    grib_get_double(hGrib, "rdr_yscale", &dValue);
    pGribProduct->m_where.m_dYscale = dValue;

    grib_get_double(hGrib, "rdr_LL_Longitude", &dValue);
    pGribProduct->m_where.m_LL_lon = dValue;

    grib_get_double(hGrib, "rdr_LL_Latitude", &dValue);
    pGribProduct->m_where.m_LL_lat = dValue;

    grib_get_double(hGrib, "rdr_UL_Longitude", &dValue);
    pGribProduct->m_where.m_UL_lon = dValue;

    grib_get_double(hGrib, "rdr_UL_Latitude", &dValue);
    pGribProduct->m_where.m_UL_lat = dValue;

    grib_get_double(hGrib, "rdr_UR_Longitude", &dValue);
    pGribProduct->m_where.m_UR_lon = dValue;

    grib_get_double(hGrib, "rdr_UR_Latitude", &dValue);
    pGribProduct->m_where.m_UR_lat = dValue;

    grib_get_double(hGrib, "rdr_LR_Longitude", &dValue);
    pGribProduct->m_where.m_LR_lon = dValue;

    grib_get_double(hGrib, "rdr_LR_Latitude", &dValue);
    pGribProduct->m_where.m_LR_lat = dValue;

    return TRUE;
}

static int fnConvertGribProductDataToBuf(GRIB_PRODUCT_DATASET *pDset, double *pBuf, unsigned int uiBufLen, char *pQauntitySplit[RDR_DF_MAX_FIELD], int iCurData, int iYdim, int iXdim)
{
    GRIB_PRODUCT_DATA       *pGribData  = NULL;
    int                     iYIdx       = 0;
    int                     iXIdx       = 0;
    int                     iDataIdx    = 0;
    int                     iBufIdx     = 0;
    double                  dData       = 0.0;
    FIELD_INFO_TBL          fieldInfo;
    FIELD_MEM_INFO_TBL      memInfo;

    if(pDset == NULL || pBuf == NULL)
        return FALSE;

    for(iDataIdx = 0; iDataIdx < iCurData; iDataIdx++)
    {
        pGribData = pDset->m_ppProductData[iDataIdx];

        memset(&fieldInfo, 0x00, sizeof(FIELD_INFO_TBL));
        if(fnGetGribFieldInfo(pQauntitySplit[iDataIdx], &fieldInfo) == FALSE)
            continue;

        memset(&memInfo, 0x00, sizeof(FIELD_MEM_INFO_TBL));
        if(fnGetFieldMemInfo(fieldInfo.m_szFieldName, &memInfo) == FALSE)
            continue;

        snprintf(pGribData->m_szFieldName, sizeof(pGribData->m_szFieldName),
                 "%s", fieldInfo.m_szFieldName);
        pGribData->m_iMemType = memInfo.m_iMemType;

        snprintf(pGribData->m_what.m_szQuantity, sizeof(pGribData->m_what.m_szQuantity),
                 "%s", pQauntitySplit[iDataIdx]);
        pGribData->m_what.m_dScale      = 1.0;
        pGribData->m_what.m_dOffset     = 0.0;
        pGribData->m_what.m_dNodata     = RDR_DF_OUT_BOUND_F;
        pGribData->m_what.m_dUndetect   = RDR_DF_BAD_VALUE_F;
        
        if(pGribData->m_iMemType == RDR_EN_MEM_CHAR)
        {
            pGribData->m_ppData_c = fnMakeMatrix2D_C(iYdim, iXdim);
            if(pGribData->m_ppData_c == NULL)
                return FALSE;

            for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
            {
                for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
                {
                    dData = pBuf[iBufIdx];

                    if(fabs(dData - pGribData->m_what.m_dUndetect) < RDR_DF_ERR_RANGE_D)
                        pGribData->m_ppData_c[iYIdx][iXIdx] = (char)memInfo.m_fBadValue;
                    else if(fabs(dData - pGribData->m_what.m_dNodata) < RDR_DF_ERR_RANGE_D)
                        pGribData->m_ppData_c[iYIdx][iXIdx] = (char)memInfo.m_fOutBound;
                    else
                    {
                        pGribData->m_ppData_c[iYIdx][iXIdx] 
                        = (char)((dData+memInfo.m_fOffset)*memInfo.m_fScale);
                    }
                    iBufIdx++;
                }
            }
        }
        else if(pGribData->m_iMemType == RDR_EN_MEM_SHORT)
        {
            pGribData->m_ppData_s = fnMakeMatrix2D_S(iYdim, iXdim);
            if(pGribData->m_ppData_s == NULL)
                return FALSE;

            for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
            {
                for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
                {
                    dData = pBuf[iBufIdx];

                    if(fabs(dData - pGribData->m_what.m_dUndetect) < RDR_DF_ERR_RANGE_D)
                        pGribData->m_ppData_s[iYIdx][iXIdx] = (short)memInfo.m_fBadValue;
                    else if(fabs(dData - pGribData->m_what.m_dNodata) < RDR_DF_ERR_RANGE_D)
                        pGribData->m_ppData_s[iYIdx][iXIdx] = (short)memInfo.m_fOutBound;
                    else
                    {
                        pGribData->m_ppData_s[iYIdx][iXIdx] 
                        = (short)((dData+memInfo.m_fOffset)*memInfo.m_fScale);
                    }
                    iBufIdx++;
                }
            }
        }
        else if(pGribData->m_iMemType == RDR_EN_MEM_FLOAT)
        {
            pGribData->m_ppData_f = fnMakeMatrix2D_F(iYdim, iXdim);
            if(pGribData->m_ppData_f == NULL)
                return FALSE;

            for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
            {
                for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
                {
                    dData = pBuf[iBufIdx];

                    if(fabs(dData - pGribData->m_what.m_dUndetect) < RDR_DF_ERR_RANGE_D)
                        pGribData->m_ppData_f[iYIdx][iXIdx] = (float)memInfo.m_fBadValue;
                    else if(fabs(dData - pGribData->m_what.m_dNodata) < RDR_DF_ERR_RANGE_D)
                        pGribData->m_ppData_f[iYIdx][iXIdx] = (float)memInfo.m_fOutBound;
                    else
                    {
                        pGribData->m_ppData_f[iYIdx][iXIdx] 
                        = (float)((dData + memInfo.m_fOffset)*memInfo.m_fScale);
                    }
                    iBufIdx++;
                }
            }
        }
    }

    return TRUE;
}

/* ================================================================================ */
// Function

GRIB_RADAR* fnLoadGribRadar(char *szFile)
{
#define FN_LOAD_GRIB_RADAR_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pBuf  != NULL) { free(pBuf); } \
    if(hGrib != NULL) { grib_handle_delete(hGrib); } \
    if(pFp   != NULL) { fclose(pFp); } \
    if(pGrib != NULL) { fnFreeGribRadar(pGrib); }

    GRIB_RADAR      *pGrib                  = NULL;
    GRIB_VOLUME     *pVolume                = NULL;
    int             iVolumeIdx              = 0;
    long            lDataIdx                = 0;
    FILE            *pFp                    = NULL;
    grib_handle     *hGrib                  = NULL;
    int             iErr                    = 0;
    size_t          uiBufLen                = 0;
    double          *pBuf                   = NULL;
    char            szEnv[STR_LENGTH_MAX]   = "";

    if(szFile == NULL)
        return NULL;

    snprintf(szEnv, sizeof(szEnv), "%s/resource/grib_api/definitions", RDR_DF_APP_ROOT_PATH);
    setenv("GRIB_DEFINITION_PATH", szEnv, 1);
    snprintf(szEnv, sizeof(szEnv), "%s/resource/grib_api/samples", RDR_DF_APP_ROOT_PATH);
    setenv("GRIB_SAMPLES_PATH", szEnv, 1);
    setenv("GRIB_TEMPLATES_PATH", szEnv, 1);

    if((pFp = fopen(szFile, "r")) == NULL)
        return NULL;

    // turn on support for multi fields messages
    grib_multi_support_on(0);

    while((hGrib = grib_handle_new_from_file(0, pFp, &iErr)) != NULL)
    {
        if(pGrib == NULL)
        {
            pGrib = fnInitGribRadar(hGrib);
            if(pGrib == NULL)
            {   FN_LOAD_GRIB_RADAR_ERROR("fnInitGribRadar fail") return NULL; }

            fnReadGribRadarGlobalHead(hGrib, pGrib);
        }

        pVolume = pGrib->m_ppVolume[iVolumeIdx];
        if(pVolume == NULL)
        {   FN_LOAD_GRIB_RADAR_ERROR("Invalid pVolume") return NULL; }

        uiBufLen = pGrib->m_hdr.m_iMaxBin * pGrib->m_hdr.m_iMaxRay;
        pBuf = NULL;
        pBuf = (double *)calloc(uiBufLen, sizeof(double));
        if(pBuf == NULL)
        {   FN_LOAD_GRIB_RADAR_ERROR("calloc fail") return NULL; }

        grib_get_double_array(hGrib, "values", pBuf, &uiBufLen);

        for(lDataIdx = 0; lDataIdx < (long)uiBufLen; lDataIdx++)
            pVolume->m_pData[lDataIdx] = (short)pBuf[lDataIdx];

        free(pBuf);
        pBuf = NULL;

        grib_handle_delete(hGrib);
        hGrib = NULL;

        if(++iVolumeIdx > pGrib->m_iMaxVolume )
        {   FN_LOAD_GRIB_RADAR_ERROR("volume count error") return NULL; }
    }

    fclose(pFp);

    return pGrib;
}

void fnFreeGribRadar(GRIB_RADAR *pGrib)
{
    GRIB_VOLUME     *pVolume    = NULL;
    int             iVolumeIdx  = 0;

    if(pGrib != NULL)
    {
        if(pGrib->m_hdr.m_pMaxRay != NULL)
        {
            free(pGrib->m_hdr.m_pMaxRay);
        }
        if(pGrib->m_hdr.m_pMaxBin != NULL)
        {
            free(pGrib->m_hdr.m_pMaxBin);
        }
        if(pGrib->m_hdr.m_pRayTime != NULL)
        {
            free(pGrib->m_hdr.m_pRayTime);
        }
        if(pGrib->m_hdr.m_pRayAzimuth != NULL)
        {
            free(pGrib->m_hdr.m_pRayAzimuth);
        }
        if(pGrib->m_hdr.m_pRayElevation != NULL)
        {
            free(pGrib->m_hdr.m_pRayElevation);
        }
        if(pGrib->m_hdr.m_pRayFixedAngle != NULL)
        {
            free(pGrib->m_hdr.m_pRayFixedAngle);
        }

        if(pGrib->m_ppVolume != NULL)
        {
            for(iVolumeIdx = 0; iVolumeIdx <  pGrib->m_hdr.m_iMaxField; iVolumeIdx++)
            {
                pVolume = pGrib->m_ppVolume[iVolumeIdx];
                if(pVolume != NULL)
                {
                    if(pVolume->m_pData != NULL)
                    {
                        free(pVolume->m_pData);
                    }
                    free(pVolume);
                }
            }
        }
        free(pGrib);
    }
}

GRIB_PRODUCT* fnLoadGribProduct(char* szFile, int iProductType)
{
#define FN_LOAD_GRIB_PRODUCT_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pBuf         != NULL) { free(pBuf); } \
    if(hGrib        != NULL) { grib_handle_delete(hGrib); } \
    if(pFp          != NULL) { fclose(pFp); } \
    if(pGribProduct != NULL) { fnFreeGribProduct(pGribProduct); } 

    GRIB_PRODUCT            *pGribProduct                           = NULL;
    GRIB_PRODUCT_DATASET    **ppDset                                = NULL;
    int                     iMaxDset                                = 0;
    int                     iDsetIdx                                = 0;
    FILE                    *pFp                                    = NULL;
    grib_handle             *hGrib                                  = NULL;
    int                     iErr                                    = 0;
    size_t                  uiBufLen                                = 0;
    double                  *pBuf                                   = NULL;
    int                     iMaxData                                = 0;
    int                     iCurData                                = 0;
    int                     iYdim                                   = 0;
    int                     iXdim                                   = 0;
    char                    szEnv[STR_LENGTH_MAX]                   = "";
    size_t                  len                                     = 0;
    char                    szProduct[6+1]                          = "";
    char                    szTmp[STR_LENGTH_MAX+1]                 = "";
    char                    *pDsetSplit[RDR_DF_GRIB_PRODUCT_MAX]    = { NULL, };
    char                    *pQauntitySplit[RDR_DF_MAX_FIELD]       = { NULL, };

    if(szFile == NULL)
        return NULL;

    snprintf(szEnv, sizeof(szEnv), "%s/resource/grib_api/definitions", RDR_DF_APP_ROOT_PATH);
    setenv("GRIB_DEFINITION_PATH", szEnv, 1);
    snprintf(szEnv, sizeof(szEnv), "%s/resource/grib_api/samples", RDR_DF_APP_ROOT_PATH);
    setenv("GRIB_SAMPLES_PATH", szEnv, 1);
    setenv("GRIB_TEMPLATES_PATH", szEnv, 1);

    if((pFp = fopen(szFile, "r")) == NULL)
        return NULL;

    // turn on support for multi fields messages
    grib_multi_support_on(0);

    while((hGrib = grib_handle_new_from_file(0, pFp, &iErr)) != NULL)
    {
        if(pGribProduct == NULL)
        {
            pGribProduct = fnReadGribProductSize(hGrib, szProduct, sizeof(szProduct), &iMaxData);
            if(pGribProduct == NULL)
            {   FN_LOAD_GRIB_PRODUCT_ERROR("fnReadGribProductSize fail") return NULL; }

            pGribProduct->m_iGribProductType = iProductType;

            fnReadGribProductGlobalHead(hGrib, pGribProduct);

            len = sizeof(szTmp)-1;
            grib_get_string(hGrib, "rdr_quantity", szTmp, &len);

            fnSplit(szTmp, pDsetSplit, RDR_DF_GRIB_PRODUCT_MAX, '/');

            ppDset = fnFindGribProductDset(pGribProduct, szProduct, &iMaxDset);
            if(ppDset == NULL)
            {   FN_LOAD_GRIB_PRODUCT_ERROR("fnFindGribProductDset fail") return NULL; }

            iYdim = pGribProduct->m_where.m_lYsize;
            iXdim = pGribProduct->m_where.m_lXsize;
            uiBufLen = iYdim * iXdim * iMaxData;
            pBuf = NULL;
            pBuf = (double *)calloc(uiBufLen, sizeof(double));
            if(pBuf == NULL)
            {   FN_LOAD_GRIB_PRODUCT_ERROR("calloc fail") return NULL; }
        }

        grib_get_double_array(hGrib, "values", pBuf, &uiBufLen);

        iCurData = fnSplit(pDsetSplit[iDsetIdx], pQauntitySplit, RDR_DF_MAX_FIELD, ',');
        if(iCurData > iMaxData)
        {   FN_LOAD_GRIB_PRODUCT_ERROR("Data count error") return NULL; }

        fnConvertGribProductDataToBuf(ppDset[iDsetIdx], pBuf, uiBufLen, 
                                      pQauntitySplit, iCurData, iYdim, iXdim);

        grib_handle_delete(hGrib);
        hGrib = NULL;

        if(++iDsetIdx > iMaxDset)
        {   FN_LOAD_GRIB_PRODUCT_ERROR("Dataset count error") return NULL; }
    }

    if(pBuf != NULL) free(pBuf);
    fclose(pFp);

    return pGribProduct;
}

















