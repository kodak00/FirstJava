/* ================================================================================ */
//
// Radar NetCDF4 CF/Radial Input Format & Input Function
//
// 2016.11.21 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"

#include <netcdf.h>

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable

static NC_VAR_TYPE_TBL g_var_type_tbl[] =
{
    { "volume_number",                      NC_EN_VAR_GLOBAL        }, 
    { "platform_type",                      NC_EN_VAR_GLOBAL        },
    { "instrument_type",                    NC_EN_VAR_GLOBAL        },
    { "primary_axis",                       NC_EN_VAR_GLOBAL        },
    { "time_coverage_start",                NC_EN_VAR_GLOBAL        },
    { "time_coverage_end",                  NC_EN_VAR_GLOBAL        },
    { "time_reference",                     NC_EN_VAR_GLOBAL        },

    { "time",                               NC_EN_VAR_COORDINATE    },
    { "range",                              NC_EN_VAR_COORDINATE    },

    { "latitude",                           NC_EN_VAR_LOCATION      },
    { "longitude",                          NC_EN_VAR_LOCATION      },
    { "altitude",                           NC_EN_VAR_LOCATION      },
    { "altitude_ag1",                       NC_EN_VAR_LOCATION      },

    { "sweep_number",                       NC_EN_VAR_SWEEP         },
    { "sweep_mode",                         NC_EN_VAR_SWEEP         },
    { "fixed_angle",                        NC_EN_VAR_SWEEP         },
    { "sweep_start_ray_index",              NC_EN_VAR_SWEEP         },
    { "sweep_end_ray_index",                NC_EN_VAR_SWEEP         },
    { "target_scan_rate",                   NC_EN_VAR_SWEEP         },
    { "rays_are_indexed",                   NC_EN_VAR_SWEEP         },
    { "ray_angle_res",                      NC_EN_VAR_SWEEP         },

    { "azimuth",                            NC_EN_VAR_SENSOR        }, 
    { "elevation",                          NC_EN_VAR_SENSOR        }, 
    { "scan_rate",                          NC_EN_VAR_SENSOR        }, 
    { "antenna_transition",                 NC_EN_VAR_SENSOR        }, 
    { "georefs_applied",                    NC_EN_VAR_SENSOR        }, 

    { "heading",                            NC_EN_VAR_MOVING        }, 
    { "roll",                               NC_EN_VAR_MOVING        }, 
    { "pitch",                              NC_EN_VAR_MOVING        }, 
    { "drift",                              NC_EN_VAR_MOVING        }, 
    { "rotation",                           NC_EN_VAR_MOVING        }, 
    { "tilt",                               NC_EN_VAR_MOVING        }, 

    { "frequency",                          NC_EN_VAR_INSTRUMENT    },
    { "follow_mode",                        NC_EN_VAR_INSTRUMENT    },
    { "pulse_width",                        NC_EN_VAR_INSTRUMENT    },
    { "prt_mode",                           NC_EN_VAR_INSTRUMENT    },
    { "prt",                                NC_EN_VAR_INSTRUMENT    },
    { "prt_ratio",                          NC_EN_VAR_INSTRUMENT    },
    { "polariztion_mode",                   NC_EN_VAR_INSTRUMENT    },
    { "nyquist_velocity",                   NC_EN_VAR_INSTRUMENT    },
    { "unambiguous_range",                  NC_EN_VAR_INSTRUMENT    },
    { "n_samples",                          NC_EN_VAR_INSTRUMENT    },

    { "radar_antenna_gain_h",               NC_EN_VAR_RADAR         },
    { "radar_antenna_gain_v",               NC_EN_VAR_RADAR         },
    { "radar_beam_width_h",                 NC_EN_VAR_RADAR         },
    { "radar_beam_width_v",                 NC_EN_VAR_RADAR         },
    { "radar_receiver_bandwidth",           NC_EN_VAR_RADAR         },
    { "radar_measured_transmit_power_h",    NC_EN_VAR_RADAR         },
    { "radar_measured_transmit_power_v",    NC_EN_VAR_RADAR         },

    { "r_calib_index",                      NC_EN_VAR_R_CALIB       }, 
    { "r_calib_time",                       NC_EN_VAR_R_CALIB       }, 
    { "r_calib_pulse_width",                NC_EN_VAR_R_CALIB       }, 
    { "r_calib_antenna_gain_h",             NC_EN_VAR_R_CALIB       }, 
    { "r_calib_antenna_gain_v",             NC_EN_VAR_R_CALIB       }, 
    { "r_calib_xmit_power_h",               NC_EN_VAR_R_CALIB       }, 
    { "r_calib_xmit_power_v",               NC_EN_VAR_R_CALIB       }, 
    { "r_calib_two_way_waveguide_loss_h",   NC_EN_VAR_R_CALIB       }, 
    { "r_calib_two_way_waveguide_loss_v",   NC_EN_VAR_R_CALIB       }, 
    { "r_calib_two_ray_radome_loss_h",      NC_EN_VAR_R_CALIB       }, 
    { "r_calib_two_ray_radome_loss_v",      NC_EN_VAR_R_CALIB       }, 
    { "r_calib_receiver_mismatch_loss",     NC_EN_VAR_R_CALIB       }, 
    { "r_calib_radar_constant_h",           NC_EN_VAR_R_CALIB       }, 
    { "r_calib_radar_constant_v",           NC_EN_VAR_R_CALIB       }, 
    { "r_calib_noise_hc",                   NC_EN_VAR_R_CALIB       }, 
    { "r_calib_noise_vc",                   NC_EN_VAR_R_CALIB       }, 
    { "r_calib_noise_hx",                   NC_EN_VAR_R_CALIB       }, 
    { "r_calib_noise_vx",                   NC_EN_VAR_R_CALIB       }, 
    { "r_calib_receiver_gain_hc",           NC_EN_VAR_R_CALIB       }, 
    { "r_calib_receiver_gain_vc",           NC_EN_VAR_R_CALIB       }, 
    { "r_calib_receiver_gain_hx",           NC_EN_VAR_R_CALIB       }, 
    { "r_calib_receiver_gain_vx",           NC_EN_VAR_R_CALIB       }, 
    { "r_calib_base_1km_hc",                NC_EN_VAR_R_CALIB       }, 
    { "r_calib_base_1km_vc",                NC_EN_VAR_R_CALIB       }, 
    { "r_calib_base_1km_hx",                NC_EN_VAR_R_CALIB       }, 
    { "r_calib_base_1km_vx",                NC_EN_VAR_R_CALIB       }, 
    { "r_calib_sum_power_hc",               NC_EN_VAR_R_CALIB       },
    { "r_calib_sum_power_vc",               NC_EN_VAR_R_CALIB       },
    { "r_calib_sum_power_hx",               NC_EN_VAR_R_CALIB       },
    { "r_calib_sum_power_vx",               NC_EN_VAR_R_CALIB       },
    { "r_calib_noise_source_power_h",       NC_EN_VAR_R_CALIB       }, 
    { "r_calib_noise_source_power_v",       NC_EN_VAR_R_CALIB       }, 
    { "r_calib_power_measure_loss_h",       NC_EN_VAR_R_CALIB       }, 
    { "r_calib_power_measure_loss_v",       NC_EN_VAR_R_CALIB       }, 
    { "r_calib_coupler_forward_loss_h",     NC_EN_VAR_R_CALIB       }, 
    { "r_calib_coupler_forward_loss_v",     NC_EN_VAR_R_CALIB       }, 
    { "r_calib_zdr_correctoin",             NC_EN_VAR_R_CALIB       }, 
    { "r_calib_ldr_correctoin_h",           NC_EN_VAR_R_CALIB       }, 
    { "r_calib_ldr_correctoin_v",           NC_EN_VAR_R_CALIB       }, 
    { "r_calib_system_phidp",               NC_EN_VAR_R_CALIB       }, 
    { "r_calib_test_power_h",               NC_EN_VAR_R_CALIB       }, 
    { "r_calib_test_power_v",               NC_EN_VAR_R_CALIB       }, 
    { "r_calib_receiver_slope_hc",          NC_EN_VAR_R_CALIB       }, 
    { "r_calib_receiver_slope_vc",          NC_EN_VAR_R_CALIB       }, 
    { "r_calib_receiver_slope_hx",          NC_EN_VAR_R_CALIB       }, 
    { "r_calib_receiver_slope_vx",          NC_EN_VAR_R_CALIB       }, 

    { "eastward_velocity",                  NC_EN_VAR_VEL           }, 
    { "northward_velocity",                 NC_EN_VAR_VEL           }, 
    { "vertical_velocity",                  NC_EN_VAR_VEL           }, 
    { "eastward_wind",                      NC_EN_VAR_VEL           }, 
    { "northward_wind",                     NC_EN_VAR_VEL           }, 
    { "vertical_wind",                      NC_EN_VAR_VEL           }, 
    { "heading_rate",                       NC_EN_VAR_VEL           }, 
    { "roll_rate",                          NC_EN_VAR_VEL           }, 
    { "pitch_rate",                         NC_EN_VAR_VEL           }, 

    { "azimuth_correction",                 NC_EN_VAR_COR           }, 
    { "elevation_correctoin",               NC_EN_VAR_COR           }, 
    { "range_correctoin",                   NC_EN_VAR_COR           }, 
    { "longitude_correctoin",               NC_EN_VAR_COR           }, 
    { "latitude_correctoin",                NC_EN_VAR_COR           }, 
    { "pressure_altitude__correctoin",      NC_EN_VAR_COR           }, 
    { "radar_altitude_correctoin",          NC_EN_VAR_COR           }, 
    { "eastward_ground_speed_correctoin",   NC_EN_VAR_COR           }, 
    { "northward_ground_speed_correcton",   NC_EN_VAR_COR           }, 
    { "vertical_velocity_correctoin",       NC_EN_VAR_COR           }, 
    { "heading_correctoin",                 NC_EN_VAR_COR           }, 
    { "roll_correctoin",                    NC_EN_VAR_COR           }, 
    { "pitch_correctoin",                   NC_EN_VAR_COR           }, 
    { "drift_correctoin",                   NC_EN_VAR_COR           }, 
    { "rotation_correctoin",                NC_EN_VAR_COR           }, 
    { "tilt_correctoin",                    NC_EN_VAR_COR           }, 

    { "DBZ",                                NC_EN_VAR_MOMENT        }, 
    { "VEL",                                NC_EN_VAR_MOMENT        }, 
    { "WIDTH",                              NC_EN_VAR_MOMENT        }, 
    { "ZDR",                                NC_EN_VAR_MOMENT        }, 
    { "PHIDP",                              NC_EN_VAR_MOMENT        }, 
    { "KDP",                                NC_EN_VAR_MOMENT        }, 
    { "RHOHV",                              NC_EN_VAR_MOMENT        }, 
    { "DBZc",                               NC_EN_VAR_MOMENT        }, 

    { "", -1 }, 
};

/* ================================================================================ */
// Static Function

static int fnGetVarType(char *szVarName)
{
    int         iTblIdx = 0;

    while(iTblIdx < RDR_DF_LOOP_CNT_MAX)
    {
        if(!strcmp(g_var_type_tbl[iTblIdx].m_szVarName, ""))
            return -1;

        if(!strcmp(g_var_type_tbl[iTblIdx].m_szVarName, szVarName))
            return g_var_type_tbl[iTblIdx].m_iVarType;

        iTblIdx++;
    }

    return -1;
}

int fnNcReadData(int iNcid, char *pDataName, void *pData)
{
    int         iVarId  = 0;

    if(pDataName == NULL || pData == NULL)
        return -1;

    if(nc_inq_varid(iNcid, pDataName, &iVarId) != 0)
        return -1;

    if(nc_get_var(iNcid, iVarId, pData) != 0)
        return -1;

    return iVarId;
}

static void fnFreeNcRadarCoordiVar(NC_RADAR *pNc)
{
    if(pNc != NULL)
    {
        if(pNc->m_coordi_var.m_pTime != NULL)
            free(pNc->m_coordi_var.m_pTime);

        if(pNc->m_coordi_var.m_pRange != NULL)
            free(pNc->m_coordi_var.m_pRange);
    }
}

static void fnFreeNcRadarSweepVar(NC_RADAR *pNc)
{
    int     iTempIdx    = 0;

    if(pNc != NULL)
    {
        if(pNc->m_sweep_var.m_pSweep_number != NULL)
            free(pNc->m_sweep_var.m_pSweep_number);

        if(pNc->m_sweep_var.m_ppSweep_mode != NULL)
        {
            for(iTempIdx = 0; iTempIdx < pNc->m_dim.m_nSweep; iTempIdx++)
            {
                if(pNc->m_sweep_var.m_ppSweep_mode[iTempIdx] != NULL)
                    free(pNc->m_sweep_var.m_ppSweep_mode[iTempIdx]);
            }
            free(pNc->m_sweep_var.m_ppSweep_mode);
        }

        if(pNc->m_sweep_var.m_pFixed_angle != NULL)
            free(pNc->m_sweep_var.m_pFixed_angle);

        if(pNc->m_sweep_var.m_pSweep_start_ray_index != NULL)
            free(pNc->m_sweep_var.m_pSweep_start_ray_index);

        if(pNc->m_sweep_var.m_pSweep_end_ray_index != NULL)
            free(pNc->m_sweep_var.m_pSweep_end_ray_index);

        if(pNc->m_sweep_var.m_pTarget_scan_rate != NULL)
            free(pNc->m_sweep_var.m_pTarget_scan_rate);

        if(pNc->m_sweep_var.m_ppRays_are_indexed != NULL)
        {
            for(iTempIdx = 0; iTempIdx < pNc->m_dim.m_nSweep; iTempIdx++)
            {
                if(pNc->m_sweep_var.m_ppRays_are_indexed[iTempIdx] != NULL)
                    free(pNc->m_sweep_var.m_ppRays_are_indexed[iTempIdx]);
            }
            free(pNc->m_sweep_var.m_ppRays_are_indexed);
        }

        if(pNc->m_sweep_var.m_pRay_angled_res != NULL)
            free(pNc->m_sweep_var.m_pRay_angled_res);
    }
}

static void fnFreeNcRadarSensorVar(NC_RADAR *pNc)
{
    if(pNc != NULL)
    {
        if(pNc->m_sensor_var.m_pAzimuth != NULL)
            free(pNc->m_sensor_var.m_pAzimuth);

        if(pNc->m_sensor_var.m_pElevation != NULL)
            free(pNc->m_sensor_var.m_pElevation);

        if(pNc->m_sensor_var.m_pScan_rate != NULL)
            free(pNc->m_sensor_var.m_pScan_rate);

        if(pNc->m_sensor_var.m_pAntenna_transition != NULL)
            free(pNc->m_sensor_var.m_pAntenna_transition);

        if(pNc->m_sensor_var.m_pGeorefs_applied != NULL)
            free(pNc->m_sensor_var.m_pGeorefs_applied);
    }
}

static void fnFreeNcRadarMovingVar(NC_RADAR *pNc)
{
    if(pNc != NULL)
    {
        if(pNc->m_moving_var.m_pHeading != NULL)
            free(pNc->m_moving_var.m_pHeading);

        if(pNc->m_moving_var.m_pRoll != NULL)
            free(pNc->m_moving_var.m_pRoll);

        if(pNc->m_moving_var.m_pPitch != NULL)
            free(pNc->m_moving_var.m_pPitch);

        if(pNc->m_moving_var.m_pDrift != NULL)
            free(pNc->m_moving_var.m_pDrift);

        if(pNc->m_moving_var.m_pRotation != NULL)
            free(pNc->m_moving_var.m_pRotation);

        if(pNc->m_moving_var.m_pTilt != NULL)
            free(pNc->m_moving_var.m_pTilt);
    }
}

static void fnFreeNcRadarInstruSub(NC_RADAR *pNc)
{
    int     iTempIdx    = 0;

    if(pNc != NULL)
    {
        if(pNc->m_instru_sub.m_pFrequency != NULL)
            free(pNc->m_instru_sub.m_pFrequency);

        if(pNc->m_instru_sub.m_ppFollow_mode != NULL)
        {
            for(iTempIdx = 0; iTempIdx < pNc->m_dim.m_nSweep; iTempIdx++)
            {
                if(pNc->m_instru_sub.m_ppFollow_mode[iTempIdx] != NULL)
                    free(pNc->m_instru_sub.m_ppFollow_mode[iTempIdx]);
            }
            free(pNc->m_instru_sub.m_ppFollow_mode);
        }

        if(pNc->m_instru_sub.m_pPulse_width != NULL)
            free(pNc->m_instru_sub.m_pPulse_width);

        if(pNc->m_instru_sub.m_ppPrt_mode != NULL)
        {
            for(iTempIdx = 0; iTempIdx < pNc->m_dim.m_nSweep; iTempIdx++)
            {
                if(pNc->m_instru_sub.m_ppPrt_mode[iTempIdx] != NULL)
                    free(pNc->m_instru_sub.m_ppPrt_mode[iTempIdx]);
            }
            free(pNc->m_instru_sub.m_ppPrt_mode);
        }

        if(pNc->m_instru_sub.m_pPrt != NULL)
            free(pNc->m_instru_sub.m_pPrt);

        if(pNc->m_instru_sub.m_pPrt_ratio != NULL)
            free(pNc->m_instru_sub.m_pPrt_ratio);

        if(pNc->m_instru_sub.m_ppPolarization_mode != NULL)
        {
            for(iTempIdx = 0; iTempIdx < pNc->m_dim.m_nSweep; iTempIdx++)
            {
                if(pNc->m_instru_sub.m_ppPolarization_mode[iTempIdx] != NULL)
                    free(pNc->m_instru_sub.m_ppPolarization_mode[iTempIdx]);
            }
            free(pNc->m_instru_sub.m_ppPolarization_mode);
        }

        if(pNc->m_instru_sub.m_pNyquist_velocity != NULL)
            free(pNc->m_instru_sub.m_pNyquist_velocity);

        if(pNc->m_instru_sub.m_pUnamebiguous_range != NULL)
            free(pNc->m_instru_sub.m_pUnamebiguous_range);

        if(pNc->m_instru_sub.m_pN_samples != NULL)
            free(pNc->m_instru_sub.m_pN_samples);
    }
}

static void fnFreeNcRadarRadarSub(NC_RADAR *pNc)
{
    if(pNc != NULL)
    {
        if(pNc->m_radar_sub.m_pRadar_mesured_transmit_power_h != NULL)
            free(pNc->m_radar_sub.m_pRadar_mesured_transmit_power_h);

        if(pNc->m_radar_sub.m_pRadar_mesured_transmit_power_v != NULL)
            free(pNc->m_radar_sub.m_pRadar_mesured_transmit_power_v);
    }
}

static void fnFreeNcRadarRCalibSub(NC_RADAR *pNc)
{
    int     iTempIdx    = 0;

    if(pNc != NULL)
    {
        if(pNc->m_r_calib_sub.m_pR_calib_index != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_index);

        if(pNc->m_r_calib_sub.m_ppR_calib_time != NULL)
        {
            for(iTempIdx = 0; iTempIdx < pNc->m_dim.m_nR_calib; iTempIdx++)
            {
                if(pNc->m_r_calib_sub.m_ppR_calib_time[iTempIdx] != NULL)
                    free(pNc->m_r_calib_sub.m_ppR_calib_time[iTempIdx]);
            }
            free(pNc->m_r_calib_sub.m_ppR_calib_time);
        }

        if(pNc->m_r_calib_sub.m_pR_calib_pulse_width != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_pulse_width);

        if(pNc->m_r_calib_sub.m_pR_calib_antenna_gain_h != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_antenna_gain_h);

        if(pNc->m_r_calib_sub.m_pR_calib_antenna_gain_v != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_antenna_gain_v);

        if(pNc->m_r_calib_sub.m_pR_calib_xmit_power_h != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_xmit_power_h);

        if(pNc->m_r_calib_sub.m_pR_calib_xmit_power_v != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_xmit_power_v);

        if(pNc->m_r_calib_sub.m_pR_calib_two_way_waveguid_loss_h != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_two_way_waveguid_loss_h);

        if(pNc->m_r_calib_sub.m_pR_calib_two_way_waveguid_loss_v != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_two_way_waveguid_loss_v);

        if(pNc->m_r_calib_sub.m_pR_calib_two_way_radome_loss_h != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_two_way_radome_loss_h);

        if(pNc->m_r_calib_sub.m_pR_calib_two_way_radome_loss_v != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_two_way_radome_loss_v);

        if(pNc->m_r_calib_sub.m_pR_calib_receiver_mismatch_loss != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_receiver_mismatch_loss);

        if(pNc->m_r_calib_sub.m_pR_calib_radar_constant_h != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_radar_constant_h);

        if(pNc->m_r_calib_sub.m_pR_calib_radar_constant_v != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_radar_constant_v);

        if(pNc->m_r_calib_sub.m_pR_calib_noise_hc != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_noise_hc);

        if(pNc->m_r_calib_sub.m_pR_calib_noise_vc != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_noise_vc);

        if(pNc->m_r_calib_sub.m_pR_calib_noise_hx != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_noise_hx);

        if(pNc->m_r_calib_sub.m_pR_calib_noise_vx != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_noise_vx);

        if(pNc->m_r_calib_sub.m_pR_calib_receiver_gain_hc != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_receiver_gain_hc);

        if(pNc->m_r_calib_sub.m_pR_calib_receiver_gain_vc != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_receiver_gain_vc);

        if(pNc->m_r_calib_sub.m_pR_calib_receiver_gain_hx != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_receiver_gain_hx);

        if(pNc->m_r_calib_sub.m_pR_calib_receiver_gain_vx != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_receiver_gain_vx);

        if(pNc->m_r_calib_sub.m_pR_calib_base_1km_hc != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_base_1km_hc);

        if(pNc->m_r_calib_sub.m_pR_calib_base_1km_vc != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_base_1km_vc);

        if(pNc->m_r_calib_sub.m_pR_calib_base_1km_hx != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_base_1km_hx);

        if(pNc->m_r_calib_sub.m_pR_calib_base_1km_vx != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_base_1km_vx);

        if(pNc->m_r_calib_sub.m_pR_calib_sum_power_hc != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_sum_power_hc);

        if(pNc->m_r_calib_sub.m_pR_calib_sum_power_vc != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_sum_power_vc);

        if(pNc->m_r_calib_sub.m_pR_calib_sum_power_hx != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_sum_power_hx);

        if(pNc->m_r_calib_sub.m_pR_calib_sum_power_vx != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_sum_power_vx);

        if(pNc->m_r_calib_sub.m_pR_calib_noise_source_power_h != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_noise_source_power_h);

        if(pNc->m_r_calib_sub.m_pR_calib_noise_source_power_v != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_noise_source_power_v);

        if(pNc->m_r_calib_sub.m_pR_calib_power_measure_loss_h != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_power_measure_loss_h);

        if(pNc->m_r_calib_sub.m_pR_calib_power_measure_loss_v != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_power_measure_loss_v);

        if(pNc->m_r_calib_sub.m_pR_calib_coupler_forward_loss_h != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_coupler_forward_loss_h);

        if(pNc->m_r_calib_sub.m_pR_calib_coupler_forward_loss_v != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_coupler_forward_loss_v);

        if(pNc->m_r_calib_sub.m_pR_calib_zdr_correction != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_zdr_correction);

        if(pNc->m_r_calib_sub.m_pR_calib_ldr_correctoin_h != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_ldr_correctoin_h);

        if(pNc->m_r_calib_sub.m_pR_calib_ldr_correctoin_v != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_ldr_correctoin_v);

        if(pNc->m_r_calib_sub.m_pR_calib_system_phidp != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_system_phidp);

        if(pNc->m_r_calib_sub.m_pR_calib_test_power_h != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_test_power_h);

        if(pNc->m_r_calib_sub.m_pR_calib_test_power_v != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_test_power_v);

        if(pNc->m_r_calib_sub.m_pR_calib_receiver_slope_hc != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_receiver_slope_hc);

        if(pNc->m_r_calib_sub.m_pR_calib_receiver_slope_vc != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_receiver_slope_vc);

        if(pNc->m_r_calib_sub.m_pR_calib_receiver_slope_hx != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_receiver_slope_hx);

        if(pNc->m_r_calib_sub.m_pR_calib_receiver_slope_vx != NULL)
            free(pNc->m_r_calib_sub.m_pR_calib_receiver_slope_vx);
    }
}

static void fnFreeNcRadarVelSub(NC_RADAR *pNc)
{
    if(pNc != NULL)
    {
        if(pNc->m_vel_sub.m_pEastward_velocity != NULL)
            free(pNc->m_vel_sub.m_pEastward_velocity);

        if(pNc->m_vel_sub.m_pNorthward_velocity != NULL)
            free(pNc->m_vel_sub.m_pNorthward_velocity);

        if(pNc->m_vel_sub.m_pVertical_velocity != NULL)
            free(pNc->m_vel_sub.m_pVertical_velocity);

        if(pNc->m_vel_sub.m_pEastward_wind != NULL)
            free(pNc->m_vel_sub.m_pEastward_wind);

        if(pNc->m_vel_sub.m_pNorthwrad_wind != NULL)
            free(pNc->m_vel_sub.m_pNorthwrad_wind);

        if(pNc->m_vel_sub.m_pVertical_wind != NULL)
            free(pNc->m_vel_sub.m_pVertical_wind);

        if(pNc->m_vel_sub.m_pHeading_rate != NULL)
            free(pNc->m_vel_sub.m_pHeading_rate);

        if(pNc->m_vel_sub.m_pRoll_rate != NULL)
            free(pNc->m_vel_sub.m_pRoll_rate);

        if(pNc->m_vel_sub.m_pPitch_rate != NULL)
            free(pNc->m_vel_sub.m_pPitch_rate);
    }
}

static void fnFreeNcRadarMomentVar(NC_RADAR *pNc)
{
    int     iMomentIdx  = 0;

    if(pNc != NULL)
    {
        for(iMomentIdx = 0; iMomentIdx < pNc->m_iMaxMoment; iMomentIdx++)
        {
            if(pNc->m_moment_var[iMomentIdx].m_pData != NULL)
                free(pNc->m_moment_var[iMomentIdx].m_pData);
        }
    }
}

static int fnReadNcRadarDimensions(int iNcId, NC_DIMENSION *pNcDim)
{
    int             iNdims                      = 0;
    int             iDimIdx                     = 0;
    int             dimIds[NC_MAX_DIMS]         = { 0, };
    char            szDimName[STR_LENGTH_MAX]   = "";

    if(pNcDim == NULL)
        return FALSE;

    if(nc_inq_dimids(iNcId, &iNdims, dimIds, 0) != 0)
        return FALSE;

    for(iDimIdx = 0; iDimIdx < iNdims; iDimIdx++)
    {
        nc_inq_dimname(iNcId, dimIds[iDimIdx], szDimName);

        if(!strcmp(szDimName, "time"))
            nc_inq_dimlen(iNcId, dimIds[iDimIdx], &pNcDim->m_nTime);
        else if(!strcmp(szDimName, "range"))
            nc_inq_dimlen(iNcId, dimIds[iDimIdx], &pNcDim->m_nRange);
        else if(!strcmp(szDimName, "sweep"))
            nc_inq_dimlen(iNcId, dimIds[iDimIdx], &pNcDim->m_nSweep);
        else if(!strcmp(szDimName, "string_length_short"))
            nc_inq_dimlen(iNcId, dimIds[iDimIdx], &pNcDim->m_nString_length_short);
        else if(!strcmp(szDimName, "string_length_medium"))
            nc_inq_dimlen(iNcId, dimIds[iDimIdx], &pNcDim->m_nString_length_medium);
        else if(!strcmp(szDimName, "string_length_long"))
            nc_inq_dimlen(iNcId, dimIds[iDimIdx], &pNcDim->m_nString_length_long);
        else if(!strcmp(szDimName, "r_calib"))
            nc_inq_dimlen(iNcId, dimIds[iDimIdx], &pNcDim->m_nR_calib);
        else if(!strcmp(szDimName, "ray_n_gates"))
            nc_inq_dimlen(iNcId, dimIds[iDimIdx], &pNcDim->m_nRay_n_gates);
        else if(!strcmp(szDimName, "ray_start_index"))
            nc_inq_dimlen(iNcId, dimIds[iDimIdx], &pNcDim->m_nRay_start_index);
        else if(!strcmp(szDimName, "frequency"))
            nc_inq_dimlen(iNcId, dimIds[iDimIdx], &pNcDim->m_nFrequency);
    }

    return TRUE;
}

static NC_RADAR* fnInitNcRadar(NC_DIMENSION ncDim)
{
    NC_RADAR        *pNc        = NULL;

    if((pNc = (NC_RADAR *)calloc(1, sizeof(NC_RADAR))) == NULL)
        return NULL;

    pNc->m_dim = ncDim;

    return pNc;
} 

static int fnReadNcRadarGlobalAttr(int iNcid, NC_RADAR *pNc)
{
    if(pNc == NULL)
        return FALSE;

    nc_get_att_text(iNcid, NC_GLOBAL, "Conventions",
                    pNc->m_global_attr.m_szConventions);

    nc_get_att_text(iNcid, NC_GLOBAL, "version",
                    pNc->m_global_attr.m_szVersion);

    nc_get_att_text(iNcid, NC_GLOBAL, "institution",
                    pNc->m_global_attr.m_szInstitution);

    nc_get_att_text(iNcid, NC_GLOBAL, "references",
                    pNc->m_global_attr.m_szReferences);

    nc_get_att_text(iNcid, NC_GLOBAL, "source",
                    pNc->m_global_attr.m_szTitle);

    nc_get_att_text(iNcid, NC_GLOBAL, "history",
                    pNc->m_global_attr.m_szHistory);

    nc_get_att_text(iNcid, NC_GLOBAL, "comment",
                    pNc->m_global_attr.m_szComment);

    nc_get_att_text(iNcid, NC_GLOBAL, "instrument_name", 
                    pNc->m_global_attr.m_szInstrument_name);

    nc_get_att_text(iNcid, NC_GLOBAL, "site_name", 
                    pNc->m_global_attr.m_szSite_name);

    nc_get_att_text(iNcid, NC_GLOBAL, "scan_name", 
                    pNc->m_global_attr.m_szScan_name);

    nc_get_att_int(iNcid, NC_GLOBAL, "scan_id", 
                   &pNc->m_global_attr.m_iScan_id);

    nc_get_att_text(iNcid, NC_GLOBAL, "platform_is_mobile", 
                    pNc->m_global_attr.m_szPlatform_is_mobile);

    nc_get_att_text(iNcid, NC_GLOBAL, "n_gates_vary", 
                    pNc->m_global_attr.m_szN_gates_vary);

    nc_get_att_text(iNcid, NC_GLOBAL, "ray_times_increase", 
                    pNc->m_global_attr.m_szRay_times_increas);

    nc_get_att_text(iNcid, NC_GLOBAL, "field_names", 
                    pNc->m_global_attr.m_szField_names);

    return TRUE;
}

static int fnReadNcRadarGlobalVar(int iNcid, char *szVarName, NC_RADAR *pNc)
{
    if(szVarName == NULL || pNc == NULL)
        return FALSE;

    if(!strcmp(szVarName, "volume_number"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_global_var.m_iVolume_number);
    }
    else if(!strcmp(szVarName, "platform_type"))
    {
        fnNcReadData(iNcid, szVarName, pNc->m_global_var.m_szPlatform_type);
    }
    else if(!strcmp(szVarName, "instrument_type"))
    {
        fnNcReadData(iNcid, szVarName, pNc->m_global_var.m_szInstrument_type);
    }
    else if(!strcmp(szVarName, "primary_axis"))
    {
        fnNcReadData(iNcid, szVarName, pNc->m_global_var.m_szPrimary_axis);
    }
    else if(!strcmp(szVarName, "time_coverage_start"))
    {
        fnNcReadData(iNcid, szVarName, pNc->m_global_var.m_szTime_coverage_start);
    }
    else if(!strcmp(szVarName, "time_coverage_end"))
    {
        fnNcReadData(iNcid, szVarName, pNc->m_global_var.m_szTime_coverage_end);
    }
    else if(!strcmp(szVarName, "time_reference"))
    {
        fnNcReadData(iNcid, szVarName, pNc->m_global_var.m_szTime_reference);
    }

    return TRUE;
}

static int fnReadNcRadarCoordiVar(int iNcid, char *szVarName, NC_RADAR *pNc)
{
    int             iVarId  = 0;

    if(szVarName == NULL || pNc == NULL)
        return FALSE;

    if(!strcmp(szVarName, "time"))
    {
        pNc->m_coordi_var.m_pTime 
        = (double *)calloc(pNc->m_dim.m_nTime, sizeof(double));
        if(pNc->m_coordi_var.m_pTime == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_coordi_var.m_pTime);
    }
    else if(!strcmp(szVarName, "range"))
    {
        pNc->m_coordi_var.m_pRange 
        = (float *)calloc(pNc->m_dim.m_nRange, sizeof(float));
        if(pNc->m_coordi_var.m_pRange == NULL)
            return FALSE;

        iVarId = fnNcReadData(iNcid, szVarName, pNc->m_coordi_var.m_pRange);

        nc_get_att_float(iNcid, iVarId, "meters_to_center_of_first_gate", 
                         &pNc->m_coordi_var.m_rangeAttr.m_fMeters_to_center_of_first_gate);
        nc_get_att_float(iNcid, iVarId, "meters_between_gates", 
                         &pNc->m_coordi_var.m_rangeAttr.m_fMeters_between_gates);
    }

    return TRUE;
}

static int fnReadNcRadarLocatVar(int iNcid, char *szVarName, NC_RADAR *pNc)
{
    if(szVarName == NULL || pNc == NULL)
        return FALSE;

    if(!strcmp(szVarName, "latitude"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_locat_var.m_dLatitude);
    }
    else if(!strcmp(szVarName, "longitude"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_locat_var.m_dLongitude);
    }
    else if(!strcmp(szVarName, "altitude"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_locat_var.m_dAltitude);
    }
    else if(!strcmp(szVarName, "altitude_ag1"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_locat_var.m_dAltitude_agl);
    }

    return TRUE;
}

static int fnReadNcRadarSweepVar(int iNcid, char *szVarName, NC_RADAR *pNc)
{
    int         iTmpIdx     = 0;
    size_t      start[2]    = { 0, 0 };
    size_t      count[2]    = { 0, 0 };
    int         varid       = 0;

    if(szVarName == NULL || pNc == NULL)
        return FALSE;

    if(!strcmp(szVarName, "sweep_number"))
    {
        pNc->m_sweep_var.m_pSweep_number 
        = (int *)calloc(pNc->m_dim.m_nSweep, sizeof(int));
        if(pNc->m_sweep_var.m_pSweep_number == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_sweep_var.m_pSweep_number);
    }
    else if(!strcmp(szVarName, "sweep_mode"))
    {
        if(nc_inq_varid(iNcid, szVarName, &varid) != 0)
            return FALSE;

        pNc->m_sweep_var.m_ppSweep_mode 
        = (char **)calloc(pNc->m_dim.m_nSweep, sizeof(char *));
        if(pNc->m_sweep_var.m_ppSweep_mode == NULL)
            return FALSE;

        start[0] = 0;
        start[1] = 0;
        count[0] = 1;
        count[1] = pNc->m_dim.m_nString_length_short;

        for(iTmpIdx = 0; iTmpIdx < pNc->m_dim.m_nSweep; iTmpIdx++)
        {
            pNc->m_sweep_var.m_ppSweep_mode[iTmpIdx]
            = (char *)calloc(pNc->m_dim.m_nString_length_short, sizeof(char));
            if(pNc->m_sweep_var.m_ppSweep_mode[iTmpIdx] == NULL)
                return FALSE;

            start[0] = iTmpIdx;
            nc_get_vara(iNcid, varid, start, count, 
                        pNc->m_sweep_var.m_ppSweep_mode[iTmpIdx]);
        }
    }
    else if(!strcmp(szVarName, "fixed_angle"))
    {
        pNc->m_sweep_var.m_pFixed_angle 
        = (float *)calloc(pNc->m_dim.m_nSweep, sizeof(float));
        if(pNc->m_sweep_var.m_pFixed_angle == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_sweep_var.m_pFixed_angle);
    }
    else if(!strcmp(szVarName, "sweep_start_ray_index"))
    {
        pNc->m_sweep_var.m_pSweep_start_ray_index 
        = (int *)calloc(pNc->m_dim.m_nSweep, sizeof(int));
        if(pNc->m_sweep_var.m_pSweep_start_ray_index == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_sweep_var.m_pSweep_start_ray_index);
    }
    else if(!strcmp(szVarName, "sweep_end_ray_index"))
    {
        pNc->m_sweep_var.m_pSweep_end_ray_index 
        = (int *)calloc(pNc->m_dim.m_nSweep, sizeof(int));
        if(pNc->m_sweep_var.m_pSweep_end_ray_index == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_sweep_var.m_pSweep_end_ray_index);
    }
    else if(!strcmp(szVarName, "target_scan_rate"))
    {
        pNc->m_sweep_var.m_pTarget_scan_rate
        = (float *)calloc(pNc->m_dim.m_nSweep, sizeof(float));
        if(pNc->m_sweep_var.m_pTarget_scan_rate == NULL)
            return FALSE;
    }
    else if(!strcmp(szVarName, "rays_are_indexed"))
    {
        if(nc_inq_varid(iNcid, szVarName, &varid) != 0)
            return FALSE;

        pNc->m_sweep_var.m_ppRays_are_indexed
        = (char **)calloc(pNc->m_dim.m_nSweep, sizeof(char *));
        if(pNc->m_sweep_var.m_ppRays_are_indexed == NULL)
            return FALSE;

        start[0] = 0;
        start[1] = 0;
        count[0] = 1;
        count[1] = pNc->m_dim.m_nString_length_short;

        for(iTmpIdx = 0; iTmpIdx < pNc->m_dim.m_nSweep; iTmpIdx++)
        {
            pNc->m_sweep_var.m_ppRays_are_indexed[iTmpIdx]
            = (char *)calloc(pNc->m_dim.m_nString_length_short, sizeof(char));
            if(pNc->m_sweep_var.m_ppRays_are_indexed[iTmpIdx] == NULL)
                return FALSE;

            start[0] = iTmpIdx;
            nc_get_vara(iNcid, varid, start, count, 
                        pNc->m_sweep_var.m_ppRays_are_indexed[iTmpIdx]);
        }
    }
    else if(!strcmp(szVarName, "ray_angle_res"))
    {
        pNc->m_sweep_var.m_pRay_angled_res 
        = (float *)calloc(pNc->m_dim.m_nSweep, sizeof(float));
        if(pNc->m_sweep_var.m_pRay_angled_res == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_sweep_var.m_pRay_angled_res);
    }

    return TRUE;
}

static int fnReadNcRadarSensorVar(int iNcid, char *szVarName, NC_RADAR *pNc)
{
    if(szVarName == NULL || pNc == NULL)
        return FALSE;

    if(!strcmp(szVarName, "azimuth"))
    {
        pNc->m_sensor_var.m_pAzimuth 
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_sensor_var.m_pAzimuth == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_sensor_var.m_pAzimuth);
    }
    else if(!strcmp(szVarName, "elevation"))
    {
        pNc->m_sensor_var.m_pElevation
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_sensor_var.m_pElevation == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_sensor_var.m_pElevation);
    }
    else if(!strcmp(szVarName, "scan_rate"))
    {
        pNc->m_sensor_var.m_pScan_rate
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_sensor_var.m_pScan_rate == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_sensor_var.m_pScan_rate);
    }
    else if(!strcmp(szVarName, "antenna_transition"))
    {
        pNc->m_sensor_var.m_pAntenna_transition 
        = (char *)calloc(pNc->m_dim.m_nTime, sizeof(char));
        if(pNc->m_sensor_var.m_pAntenna_transition == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_sensor_var.m_pAntenna_transition);
    }
    else if(!strcmp(szVarName, "georefs_applied"))
    {
        pNc->m_sensor_var.m_pGeorefs_applied 
        = (char *)calloc(pNc->m_dim.m_nTime, sizeof(char));
        if(pNc->m_sensor_var.m_pGeorefs_applied == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_sensor_var.m_pGeorefs_applied);
    }

    return TRUE;
}

static int fnReadNcRadarMovingVar(int iNcid, char *szVarName, NC_RADAR *pNc)
{
    if(szVarName == NULL || pNc == NULL)
        return FALSE;

    if(!strcmp(szVarName, "heading"))
    {
        pNc->m_moving_var.m_pHeading
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_moving_var.m_pHeading == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_moving_var.m_pHeading);
    }
    else if(!strcmp(szVarName, "roll"))
    {
        pNc->m_moving_var.m_pRoll
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_moving_var.m_pRoll == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_moving_var.m_pRoll);
    }
    else if(!strcmp(szVarName, "pitch"))
    {
        pNc->m_moving_var.m_pPitch
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_moving_var.m_pPitch == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_moving_var.m_pPitch);
    }
    else if(!strcmp(szVarName, "drift"))
    {
        pNc->m_moving_var.m_pDrift 
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_moving_var.m_pDrift == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_moving_var.m_pDrift);
    }
    else if(!strcmp(szVarName, "rotation"))
    {
        pNc->m_moving_var.m_pRotation
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_moving_var.m_pRotation == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_moving_var.m_pRotation);
    }
    else if(!strcmp(szVarName, "tilt"))
    {
        pNc->m_moving_var.m_pTilt
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_moving_var.m_pTilt == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_moving_var.m_pTilt);
    }

    return TRUE;
}

static int fnReadNcRadarInstruSub(int iNcid, char *szVarName, NC_RADAR *pNc)
{
    int         iTmpIdx     = 0;
    size_t      start[2]    = { 0, 0 };
    size_t      count[2]    = { 0, 0 };
    int         varid       = 0;

    if(szVarName == NULL || pNc == NULL)
        return FALSE;

    if(!strcmp(szVarName, "frequency"))
    {
        pNc->m_instru_sub.m_pFrequency
        = (float *)calloc(pNc->m_dim.m_nFrequency, sizeof(float));
        if(pNc->m_instru_sub.m_pFrequency == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_instru_sub.m_pFrequency);
    }
    else if(!strcmp(szVarName, "follow_mode"))
    {
        if(nc_inq_varid(iNcid, szVarName, &varid) != 0)
            return FALSE;

        pNc->m_instru_sub.m_ppFollow_mode
        = (char **)calloc(pNc->m_dim.m_nSweep, sizeof(char *));
        if(pNc->m_instru_sub.m_ppFollow_mode == NULL)
            return FALSE;

        start[0] = 0;
        start[1] = 0;
        count[0] = 1;
        count[1] = pNc->m_dim.m_nString_length_short;

        for(iTmpIdx = 0; iTmpIdx < pNc->m_dim.m_nSweep; iTmpIdx++)
        {
            pNc->m_instru_sub.m_ppFollow_mode[iTmpIdx]
            = (char *)calloc(pNc->m_dim.m_nString_length_short, sizeof(char));
            if(pNc->m_instru_sub.m_ppFollow_mode[iTmpIdx] == NULL)
                return FALSE;

            start[0] = iTmpIdx;
            nc_get_vara(iNcid, varid, start, count, 
                        pNc->m_instru_sub.m_ppFollow_mode[iTmpIdx]);
        }
    }
    else if(!strcmp(szVarName, "pulse_width"))
    {
        pNc->m_instru_sub.m_pPulse_width
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_instru_sub.m_pPulse_width == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_instru_sub.m_pPulse_width);
    }
    else if(!strcmp(szVarName, "prt_mode"))
    {
        if(nc_inq_varid(iNcid, szVarName, &varid) != 0)
            return FALSE;

        pNc->m_instru_sub.m_ppPrt_mode
        = (char **)calloc(pNc->m_dim.m_nSweep, sizeof(char *));
        if(pNc->m_instru_sub.m_ppPrt_mode == NULL)
            return FALSE;

        start[0] = 0;
        start[1] = 0;
        count[0] = 1;
        count[1] = pNc->m_dim.m_nString_length_short;

        for(iTmpIdx = 0; iTmpIdx < pNc->m_dim.m_nSweep; iTmpIdx++)
        {
            pNc->m_instru_sub.m_ppPrt_mode[iTmpIdx]
            = (char *)calloc(pNc->m_dim.m_nString_length_short, sizeof(char));
            if(pNc->m_instru_sub.m_ppPrt_mode[iTmpIdx] == NULL)
                return FALSE;

            start[0] = iTmpIdx;
            nc_get_vara(iNcid, varid, start, count, 
                        pNc->m_instru_sub.m_ppPrt_mode[iTmpIdx]);
        }
    }
    else if(!strcmp(szVarName, "prt"))
    {
        pNc->m_instru_sub.m_pPrt 
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_instru_sub.m_pPrt == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_instru_sub.m_pPrt);
    }
    else if(!strcmp(szVarName, "prt_ratio"))
    {
        pNc->m_instru_sub.m_pPrt_ratio 
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_instru_sub.m_pPrt_ratio == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_instru_sub.m_pPrt_ratio);
    }
    else if(!strcmp(szVarName, "polariztion_mode"))
    {
        if(nc_inq_varid(iNcid, szVarName, &varid) != 0)
            return FALSE;

        pNc->m_instru_sub.m_ppPolarization_mode
        = (char **)calloc(pNc->m_dim.m_nSweep, sizeof(char *));
        if(pNc->m_instru_sub.m_ppPolarization_mode == NULL)
            return FALSE;

        start[0] = 0;
        start[1] = 0;
        count[0] = 1;
        count[1] = pNc->m_dim.m_nString_length_short;

        for(iTmpIdx = 0; iTmpIdx < pNc->m_dim.m_nSweep; iTmpIdx++)
        {
            pNc->m_instru_sub.m_ppPolarization_mode[iTmpIdx]
            = (char *)calloc(pNc->m_dim.m_nString_length_short, sizeof(char));
            if(pNc->m_instru_sub.m_ppPolarization_mode[iTmpIdx] == NULL)
                return FALSE;

            start[0] = iTmpIdx;
            nc_get_vara(iNcid, varid, start, count, 
                        pNc->m_instru_sub.m_ppPolarization_mode[iTmpIdx]);
        }
    }
    else if(!strcmp(szVarName, "nyquist_velocity"))
    {
        pNc->m_instru_sub.m_pNyquist_velocity 
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_instru_sub.m_pNyquist_velocity == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_instru_sub.m_pNyquist_velocity);
    }
    else if(!strcmp(szVarName, "unambiguous_range"))
    {
        pNc->m_instru_sub.m_pUnamebiguous_range
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_instru_sub.m_pUnamebiguous_range == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_instru_sub.m_pUnamebiguous_range);
    }
    else if(!strcmp(szVarName, "n_samples"))
    {
        pNc->m_instru_sub.m_pN_samples 
        = (int *)calloc(pNc->m_dim.m_nTime, sizeof(int));
        if(pNc->m_instru_sub.m_pN_samples == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_instru_sub.m_pN_samples);
    }

    return TRUE;
}

static int fnReadNcRadarRadarSub(int iNcid, char *szVarName, NC_RADAR *pNc)
{
    if(szVarName == NULL || pNc == NULL)
        return FALSE;

    if(!strcmp(szVarName, "radar_antenna_gain_h"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_radar_sub.m_fRadar_antenna_gain_h);
    }
    else if(!strcmp(szVarName, "radar_antenna_gain_v"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_radar_sub.m_fRadar_antenna_gain_v);
    }
    else if(!strcmp(szVarName, "radar_beam_width_h"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_radar_sub.m_fRadar_beam_width_h);
    }
    else if(!strcmp(szVarName, "radar_beam_width_v"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_radar_sub.m_fRadar_beam_width_v);
    }
    else if(!strcmp(szVarName, "radar_receiver_bandwidth"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_radar_sub.m_fRadar_receiver_bandwidth);
    }
    else if(!strcmp(szVarName, "radar_measured_transmit_power_h"))
    {
        pNc->m_radar_sub.m_pRadar_mesured_transmit_power_h
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_radar_sub.m_pRadar_mesured_transmit_power_h == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_radar_sub.m_pRadar_mesured_transmit_power_h);
    }
    else if(!strcmp(szVarName, "radar_measured_transmit_power_v"))
    {
        pNc->m_radar_sub.m_pRadar_mesured_transmit_power_v
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_radar_sub.m_pRadar_mesured_transmit_power_v == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_radar_sub.m_pRadar_mesured_transmit_power_v);
    }

    return TRUE;
}

static int fnReadNcRadarRCalibSub(int iNcid, char *szVarName, NC_RADAR *pNc)
{
    int         iTmpIdx     = 0;
    size_t      start[2]    = { 0, 0 };
    size_t      count[2]    = { 0, 0 };
    int         varid       = 0;

    if(szVarName == NULL || pNc == NULL)
        return FALSE;

    if(!strcmp(szVarName, "r_calib_index"))
    {
        pNc->m_r_calib_sub.m_pR_calib_index
        = (char *)calloc(pNc->m_dim.m_nTime, sizeof(char));
        if(pNc->m_r_calib_sub.m_pR_calib_index == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_index);
    }
    else if(!strcmp(szVarName, "r_calib_time"))
    {
        if(nc_inq_varid(iNcid, szVarName, &varid) != 0)
            return FALSE;

        pNc->m_r_calib_sub.m_ppR_calib_time 
        = (char **)calloc(pNc->m_dim.m_nR_calib, sizeof(char *));
        if(pNc->m_r_calib_sub.m_ppR_calib_time == NULL)
            return FALSE;

        start[0] = 0;
        start[1] = 0;
        count[0] = 1;
        count[1] = pNc->m_dim.m_nString_length_short;

        for(iTmpIdx = 0; iTmpIdx < pNc->m_dim.m_nR_calib; iTmpIdx++)
        {
            pNc->m_r_calib_sub.m_ppR_calib_time[iTmpIdx]
            = (char *)calloc(pNc->m_dim.m_nString_length_short, sizeof(char));
            if(pNc->m_r_calib_sub.m_ppR_calib_time[iTmpIdx] == NULL)
                return FALSE;

            start[0] = iTmpIdx;
            nc_get_vara(iNcid, varid, start, count, 
                        pNc->m_r_calib_sub.m_ppR_calib_time[iTmpIdx]);
        }
    }
    else if(!strcmp(szVarName, "r_calib_pulse_width"))
    {
        pNc->m_r_calib_sub.m_pR_calib_pulse_width
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_pulse_width == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_pulse_width);
    }
    else if(!strcmp(szVarName, "r_calib_antenna_gain_h"))
    {
        pNc->m_r_calib_sub.m_pR_calib_antenna_gain_h
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_antenna_gain_h == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_antenna_gain_h);
    }
    else if(!strcmp(szVarName, "r_calib_antenna_gain_v"))
    {
        pNc->m_r_calib_sub.m_pR_calib_antenna_gain_v
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_antenna_gain_v == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_antenna_gain_v);
    }
    else if(!strcmp(szVarName, "r_calib_xmit_power_h"))
    {
        pNc->m_r_calib_sub.m_pR_calib_xmit_power_h
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_xmit_power_h == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_xmit_power_h);
    }
    else if(!strcmp(szVarName, "r_calib_xmit_power_v"))
    {
        pNc->m_r_calib_sub.m_pR_calib_xmit_power_v
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_xmit_power_v == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_xmit_power_v);
    }
    else if(!strcmp(szVarName, "r_calib_two_way_waveguide_loss_h"))
    {
        pNc->m_r_calib_sub.m_pR_calib_two_way_waveguid_loss_h
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_two_way_waveguid_loss_h == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_two_way_waveguid_loss_h);
    }
    else if(!strcmp(szVarName, "r_calib_two_way_waveguide_loss_v"))
    {
        pNc->m_r_calib_sub.m_pR_calib_two_way_waveguid_loss_v
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_two_way_waveguid_loss_v == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_two_way_waveguid_loss_v);
    }
    else if(!strcmp(szVarName, "r_calib_two_ray_radome_loss_h"))
    {
        pNc->m_r_calib_sub.m_pR_calib_two_way_radome_loss_h
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_two_way_radome_loss_h == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_two_way_radome_loss_h);
    }
    else if(!strcmp(szVarName, "r_calib_two_ray_radome_loss_v"))
    {
        pNc->m_r_calib_sub.m_pR_calib_two_way_radome_loss_v
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_two_way_radome_loss_v == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_two_way_radome_loss_v);
    }
    else if(!strcmp(szVarName, "r_calib_receiver_mismatch_loss"))
    {
        pNc->m_r_calib_sub.m_pR_calib_receiver_mismatch_loss
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_receiver_mismatch_loss == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_receiver_mismatch_loss);
    }
    else if(!strcmp(szVarName, "r_calib_radar_constant_h"))
    {
        pNc->m_r_calib_sub.m_pR_calib_radar_constant_h
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_radar_constant_h == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_radar_constant_h);
    }
    else if(!strcmp(szVarName, "r_calib_radar_constant_v"))
    {
        pNc->m_r_calib_sub.m_pR_calib_radar_constant_v
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_radar_constant_v == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_radar_constant_v);
    }
    else if(!strcmp(szVarName, "r_calib_noise_hc"))
    {
        pNc->m_r_calib_sub.m_pR_calib_noise_hc
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_noise_hc == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_noise_hc);
    }
    else if(!strcmp(szVarName, "r_calib_noise_vc"))
    {
        pNc->m_r_calib_sub.m_pR_calib_noise_vc
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_noise_vc == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_noise_vc);
    }
    else if(!strcmp(szVarName, "r_calib_noise_hx"))
    {
        pNc->m_r_calib_sub.m_pR_calib_noise_hx
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_noise_hx == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_noise_hx);
    }
    else if(!strcmp(szVarName, "r_calib_noise_vx"))
    {
        pNc->m_r_calib_sub.m_pR_calib_noise_vx
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_noise_vx == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_noise_vx);
    }
    else if(!strcmp(szVarName, "r_calib_receiver_gain_hc"))
    {
        pNc->m_r_calib_sub.m_pR_calib_receiver_gain_hc
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_receiver_gain_hc == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_receiver_gain_hc);
    }
    else if(!strcmp(szVarName, "r_calib_receiver_gain_vc"))
    {
        pNc->m_r_calib_sub.m_pR_calib_receiver_gain_vc
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_receiver_gain_vc == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_receiver_gain_vc);
    }
    else if(!strcmp(szVarName, "r_calib_receiver_gain_hx"))
    {
        pNc->m_r_calib_sub.m_pR_calib_receiver_gain_hx
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_receiver_gain_hx == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_receiver_gain_hx);
    }
    else if(!strcmp(szVarName, "r_calib_receiver_gain_vx"))
    {
        pNc->m_r_calib_sub.m_pR_calib_receiver_gain_vx
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_receiver_gain_vx == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_receiver_gain_vx);
    }
    else if(!strcmp(szVarName, "r_calib_base_1km_hc"))
    {
        pNc->m_r_calib_sub.m_pR_calib_base_1km_hc
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_base_1km_hc == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_base_1km_hc);
    }
    else if(!strcmp(szVarName, "r_calib_base_1km_vc"))
    {
        pNc->m_r_calib_sub.m_pR_calib_base_1km_vc
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_base_1km_vc == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_base_1km_vc);
    }
    else if(!strcmp(szVarName, "r_calib_base_1km_hx"))
    {
        pNc->m_r_calib_sub.m_pR_calib_base_1km_hx
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_base_1km_hx == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_base_1km_hx);
    }
    else if(!strcmp(szVarName, "r_calib_base_1km_vx"))
    {
        pNc->m_r_calib_sub.m_pR_calib_base_1km_vx
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_base_1km_vx == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_base_1km_vx);
    }
    else if(!strcmp(szVarName, "r_calib_sum_power_hc"))
    {
        pNc->m_r_calib_sub.m_pR_calib_sum_power_hc
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_sum_power_hc == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_sum_power_hc);
    }
    else if(!strcmp(szVarName, "r_calib_sum_power_vc"))
    {
        pNc->m_r_calib_sub.m_pR_calib_sum_power_vc
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_sum_power_vc == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_sum_power_vc);
    }
    else if(!strcmp(szVarName, "r_calib_sum_power_hx"))
    {
        pNc->m_r_calib_sub.m_pR_calib_sum_power_hx
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_sum_power_hx == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_sum_power_hx);
    }
    else if(!strcmp(szVarName, "r_calib_sum_power_vx"))
    {
        pNc->m_r_calib_sub.m_pR_calib_sum_power_vx
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_sum_power_vx == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_sum_power_vx);
    }
    else if(!strcmp(szVarName, "r_calib_noise_source_power_h"))
    {
        pNc->m_r_calib_sub.m_pR_calib_noise_source_power_h
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_noise_source_power_h == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_noise_source_power_h);
    }
    else if(!strcmp(szVarName, "r_calib_noise_source_power_v"))
    {
        pNc->m_r_calib_sub.m_pR_calib_noise_source_power_v
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_noise_source_power_v == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_noise_source_power_v);
    }
    else if(!strcmp(szVarName, "r_calib_power_measure_loss_h"))
    {
        pNc->m_r_calib_sub.m_pR_calib_power_measure_loss_h
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_power_measure_loss_h == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_power_measure_loss_h);
    }
    else if(!strcmp(szVarName, "r_calib_power_measure_loss_v"))
    {
        pNc->m_r_calib_sub.m_pR_calib_power_measure_loss_v
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_power_measure_loss_v == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_power_measure_loss_v);
    }
    else if(!strcmp(szVarName, "r_calib_coupler_forward_loss_h"))
    {
        pNc->m_r_calib_sub.m_pR_calib_coupler_forward_loss_h
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_coupler_forward_loss_h == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_coupler_forward_loss_h);
    }
    else if(!strcmp(szVarName, "r_calib_coupler_forward_loss_v"))
    {
        pNc->m_r_calib_sub.m_pR_calib_coupler_forward_loss_v
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_coupler_forward_loss_v == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_coupler_forward_loss_v);
    }
    else if(!strcmp(szVarName, "r_calib_zdr_correctoin"))
    {
        pNc->m_r_calib_sub.m_pR_calib_zdr_correction
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_zdr_correction == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_zdr_correction);
    }
    else if(!strcmp(szVarName, "r_calib_ldr_correctoin_h"))
    {
        pNc->m_r_calib_sub.m_pR_calib_ldr_correctoin_h
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_ldr_correctoin_h == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_ldr_correctoin_h);
    }
    else if(!strcmp(szVarName, "r_calib_ldr_correctoin_v"))
    {
        pNc->m_r_calib_sub.m_pR_calib_ldr_correctoin_v
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_ldr_correctoin_v == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_ldr_correctoin_v);
    }
    else if(!strcmp(szVarName, "r_calib_system_phidp"))
    {
        pNc->m_r_calib_sub.m_pR_calib_system_phidp
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_system_phidp == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_system_phidp);
    }
    else if(!strcmp(szVarName, "r_calib_test_power_h"))
    {
        pNc->m_r_calib_sub.m_pR_calib_test_power_h
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_test_power_h == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_test_power_h);
    }
    else if(!strcmp(szVarName, "r_calib_test_power_v"))
    {
        pNc->m_r_calib_sub.m_pR_calib_test_power_v
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_test_power_v == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_test_power_v);
    }
    else if(!strcmp(szVarName, "r_calib_receiver_slope_hc"))
    {
        pNc->m_r_calib_sub.m_pR_calib_receiver_slope_hc
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_receiver_slope_hc == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_receiver_slope_hc);
    }
    else if(!strcmp(szVarName, "r_calib_receiver_slope_vc"))
    {
        pNc->m_r_calib_sub.m_pR_calib_receiver_slope_vc
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_receiver_slope_vc == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_receiver_slope_vc);
    }
    else if(!strcmp(szVarName, "r_calib_receiver_slope_hx"))
    {
        pNc->m_r_calib_sub.m_pR_calib_receiver_slope_hx
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_receiver_slope_hx == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_receiver_slope_hx);
    }
    else if(!strcmp(szVarName, "r_calib_receiver_slope_vx"))
    {
        pNc->m_r_calib_sub.m_pR_calib_receiver_slope_vx
        = (float *)calloc(pNc->m_dim.m_nR_calib, sizeof(float));
        if(pNc->m_r_calib_sub.m_pR_calib_receiver_slope_vx == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_r_calib_sub.m_pR_calib_receiver_slope_vx);
    }

    return TRUE;
}

static int fnReadNcRadarVelSub(int iNcid, char *szVarName, NC_RADAR *pNc)
{
    if(szVarName == NULL || pNc == NULL)
        return FALSE;

    if(!strcmp(szVarName, "eastward_velocity"))
    {
        pNc->m_vel_sub.m_pEastward_velocity
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_vel_sub.m_pEastward_velocity == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_vel_sub.m_pEastward_velocity);
    }
    else if(!strcmp(szVarName, "northward_velocity"))
    {
        pNc->m_vel_sub.m_pNorthward_velocity
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_vel_sub.m_pNorthward_velocity == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_vel_sub.m_pNorthward_velocity);
    }
    else if(!strcmp(szVarName, "vertical_velocity"))
    {
        pNc->m_vel_sub.m_pVertical_velocity
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_vel_sub.m_pVertical_velocity == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_vel_sub.m_pVertical_velocity);
    }
    else if(!strcmp(szVarName, "eastward_wind"))
    {
        pNc->m_vel_sub.m_pEastward_wind
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_vel_sub.m_pEastward_wind == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_vel_sub.m_pEastward_wind);
    }
    else if(!strcmp(szVarName, "northward_wind"))
    {
        pNc->m_vel_sub.m_pNorthwrad_wind
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_vel_sub.m_pNorthwrad_wind == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_vel_sub.m_pNorthwrad_wind);
    }
    else if(!strcmp(szVarName, "vertical_wind"))
    {
        pNc->m_vel_sub.m_pVertical_wind
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_vel_sub.m_pVertical_wind == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_vel_sub.m_pVertical_wind);
    }
    else if(!strcmp(szVarName, "heading_rate"))
    {
        pNc->m_vel_sub.m_pHeading_rate
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_vel_sub.m_pHeading_rate == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_vel_sub.m_pHeading_rate);
    }
    else if(!strcmp(szVarName, "roll_rate"))
    {
        pNc->m_vel_sub.m_pRoll_rate
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_vel_sub.m_pRoll_rate == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_vel_sub.m_pRoll_rate);
    }
    else if(!strcmp(szVarName, "pitch_rate"))
    {
        pNc->m_vel_sub.m_pPitch_rate
        = (float *)calloc(pNc->m_dim.m_nTime, sizeof(float));
        if(pNc->m_vel_sub.m_pPitch_rate == NULL)
            return FALSE;

        fnNcReadData(iNcid, szVarName, pNc->m_vel_sub.m_pPitch_rate);
    }

    return TRUE;
}

static int fnReadNcRadarCorSub(int iNcid, char *szVarName, NC_RADAR *pNc)
{
    if(szVarName == NULL || pNc == NULL)
        return FALSE;

    if(!strcmp(szVarName, "azimuth_correction"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_cor_sub.m_fAzimuth_correction);
    }
    else if(!strcmp(szVarName, "elevation_correctoin"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_cor_sub.m_fElevation_correction);
    }
    else if(!strcmp(szVarName,"range_correctoin" ))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_cor_sub.m_fRange_correction);
    }
    else if(!strcmp(szVarName, "longitude_correctoin"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_cor_sub.m_fLonitude_correction);
    }
    else if(!strcmp(szVarName, "latitude_correctoin"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_cor_sub.m_fLatitude_correction);
    }
    else if(!strcmp(szVarName, "pressure_altitude__correctoin"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_cor_sub.m_fPressure_alitutde_correction);
    }
    else if(!strcmp(szVarName, "radar_altitude_correctoin"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_cor_sub.m_fRadar_alitude_correction);
    }
    else if(!strcmp(szVarName, "eastward_ground_speed_correctoin"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_cor_sub.m_fEastward_ground_speed_correction);
    }
    else if(!strcmp(szVarName, "northward_ground_speed_correcton"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_cor_sub.m_fNorthward_ground_speed_correction);
    }
    else if(!strcmp(szVarName, "vertical_velocity_correctoin"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_cor_sub.m_fVertical_velocity_correction);
    }
    else if(!strcmp(szVarName, "heading_correctoin"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_cor_sub.m_fHeading_correction);
    }
    else if(!strcmp(szVarName, "roll_correctoin"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_cor_sub.m_fRoll_correction);
    }
    else if(!strcmp(szVarName, "pitch_correctoin"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_cor_sub.m_fPitch_correction);
    }
    else if(!strcmp(szVarName, "drift_correctoin"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_cor_sub.m_fDrift_correction);
    }
    else if(!strcmp(szVarName, "rotation_correctoin"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_cor_sub.m_fRotation_correction);
    }
    else if(!strcmp(szVarName, "tilt_correctoin"))
    {
        fnNcReadData(iNcid, szVarName, &pNc->m_cor_sub.m_fTilt_correction);
    }

    return TRUE;
}

static int fnReadNcRadarMomentVar(int iNcid, char *szVarName, NC_RADAR *pNc)
{
    int     iVarId  = 0;

    if(szVarName == NULL || pNc == NULL)
        return FALSE;

    if(pNc->m_iMaxMoment >= RDR_DF_MAX_FIELD)
        return FALSE;

    pNc->m_moment_var[pNc->m_iMaxMoment].m_pData
    = (short *)calloc(pNc->m_dim.m_nTime*pNc->m_dim.m_nRange, sizeof(short));
    if(pNc->m_moment_var[pNc->m_iMaxMoment].m_pData == NULL)
        return FALSE;

    iVarId = fnNcReadData(iNcid, szVarName, pNc->m_moment_var[pNc->m_iMaxMoment].m_pData);

    nc_get_att_short(iNcid, iVarId, "_FillValue", 
                     &pNc->m_moment_var[pNc->m_iMaxMoment].m_momentAttr.m_sFillValue);

    nc_get_att_float(iNcid, iVarId, "scale_factor",
                     &pNc->m_moment_var[pNc->m_iMaxMoment].m_momentAttr.m_fScale_factor);

    nc_get_att_float(iNcid, iVarId, "add_offset", 
                     &pNc->m_moment_var[pNc->m_iMaxMoment].m_momentAttr.m_fAdd_offset);

    snprintf(pNc->m_moment_var[pNc->m_iMaxMoment].m_szMoment, 
             sizeof(pNc->m_moment_var[pNc->m_iMaxMoment].m_szMoment), 
             "%s", szVarName);

    pNc->m_iMaxMoment++;

    return TRUE;
}

static int fnReadNcRadarVariables(int iNcid, NC_RADAR *pNc)
{
    int     iVarIdx                     = 0;
    int     iNvars                      = 0;
    int     varIds[NC_MAX_VARS]         = { 0, };
    char    szVarName[STR_LENGTH_MAX]   = "";
    int     iVarType                    = -1;

    if(pNc == NULL)
        return FALSE;

    if(nc_inq_varids(iNcid, &iNvars, varIds) != 0)
        return FALSE;

    for(iVarIdx = 0; iVarIdx < iNvars; iVarIdx++)
    {
        nc_inq_varname(iNcid, varIds[iVarIdx], szVarName);
     
        iVarType = fnGetVarType(szVarName);

        if(iVarType == NC_EN_VAR_GLOBAL)
        {
            if(fnReadNcRadarGlobalVar(iNcid, szVarName, pNc) == FALSE)
                return FALSE;
        }
        else if(iVarType == NC_EN_VAR_COORDINATE)
        {
            if(fnReadNcRadarCoordiVar(iNcid, szVarName, pNc) == FALSE)
                return FALSE;
        }
        else if(iVarType == NC_EN_VAR_LOCATION)
        {
            if(fnReadNcRadarLocatVar(iNcid, szVarName, pNc) == FALSE)
                return FALSE;
        }
        else if(iVarType == NC_EN_VAR_SWEEP)
        {
            if(fnReadNcRadarSweepVar(iNcid, szVarName, pNc) == FALSE)
                return FALSE;
        }
        else if(iVarType == NC_EN_VAR_SENSOR)
        {
            if(fnReadNcRadarSensorVar(iNcid, szVarName, pNc) == FALSE)
                return FALSE;
        }
        else if(iVarType == NC_EN_VAR_MOVING)
        {
            if(fnReadNcRadarMovingVar(iNcid, szVarName, pNc) == FALSE)
                return FALSE;
        }
        else if(iVarType == NC_EN_VAR_INSTRUMENT)
        {
            if(fnReadNcRadarInstruSub(iNcid, szVarName, pNc) == FALSE)
                return FALSE;
        }
        else if(iVarType == NC_EN_VAR_RADAR)
        {
            if(fnReadNcRadarRadarSub(iNcid, szVarName, pNc) == FALSE)
                return FALSE;
        }
        else if(iVarType == NC_EN_VAR_R_CALIB)
        {
            if(fnReadNcRadarRCalibSub(iNcid, szVarName, pNc) == FALSE)
                return FALSE;
        }
        else if(iVarType == NC_EN_VAR_VEL)
        {
            if(fnReadNcRadarVelSub(iNcid, szVarName, pNc) == FALSE)
                return FALSE;
        }
        else if(iVarType == NC_EN_VAR_COR)
        {
            if(fnReadNcRadarCorSub(iNcid, szVarName, pNc) == FALSE)
                return FALSE;
        }
        else if(iVarType == NC_EN_VAR_MOMENT)
        {
            if(fnReadNcRadarMomentVar(iNcid, szVarName, pNc) == FALSE)
                return FALSE;
        }
    }

    return TRUE;
}

/* ================================================================================ */
// Function


NC_RADAR* fnLoadNcRadar(char* szFile)
{
#define FN_LOAD_NC_RADAR_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pNc != NULL) { fnFreeNcRadar(pNc); }

    NC_RADAR        *pNc        = NULL;
    int             iNcid       = 0;
    int             iRc         = 0;

    NC_DIMENSION    ncDim;

    if(szFile == NULL)
        return NULL;

    if((iRc = nc_open(szFile, NC_NOWRITE, &iNcid)) != 0)
    {   FN_LOAD_NC_RADAR_ERROR("nc_open fail") return NULL; }

    memset(&ncDim, 0x00, sizeof(ncDim));
    if(fnReadNcRadarDimensions(iNcid, &ncDim) == FALSE)
    {   FN_LOAD_NC_RADAR_ERROR("fnReadNcRadarDimensions fail") return NULL; }

    if((pNc = fnInitNcRadar(ncDim)) == NULL)
    {   FN_LOAD_NC_RADAR_ERROR("fnInitNcRadar fail") return NULL; }
    
    if(fnReadNcRadarGlobalAttr(iNcid, pNc) == FALSE)
    {   FN_LOAD_NC_RADAR_ERROR("fnReadNcRadarGlobalAttr fail") return NULL; }

    if(fnReadNcRadarVariables(iNcid, pNc) == FALSE)
    {   FN_LOAD_NC_RADAR_ERROR("fnReadNcRadarVariables fail") return NULL; }

    nc_close(iNcid);

    return pNc;
}

void fnFreeNcRadar(NC_RADAR *pNc)
{
    if(pNc != NULL)
    {
        fnFreeNcRadarCoordiVar(pNc);
        fnFreeNcRadarSweepVar(pNc);
        fnFreeNcRadarSensorVar(pNc);
        fnFreeNcRadarMovingVar(pNc);
        fnFreeNcRadarInstruSub(pNc);
        fnFreeNcRadarRadarSub(pNc);
        fnFreeNcRadarRCalibSub(pNc);
        fnFreeNcRadarVelSub(pNc);
        fnFreeNcRadarMomentVar(pNc);
        free(pNc);
    }
}

