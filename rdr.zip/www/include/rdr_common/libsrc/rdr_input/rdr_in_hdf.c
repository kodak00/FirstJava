/* ================================================================================ */
//
// Radar HDF Input Format & Input Function
//
// 2016.08.26 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"

#include <hdf5.h>
#include <hdf5_hl.h>

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function

static void fnInsertionSortRootGroup(int iRootObjCnt, char rootObjBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN])
{
    int             iCurObj_1                       = 0;
    int             iCurObj_2                       = 0;
    char            szTemp[RDR_DF_HDF_OBEJCT_LEN]  = "";

    if(iRootObjCnt <= 0)
        return;

    for(iCurObj_1 = 1; iCurObj_1 < iRootObjCnt; iCurObj_1++)
    {
        snprintf(szTemp, sizeof(szTemp), "%s", rootObjBuf[iCurObj_1]);
        for(iCurObj_2 = iCurObj_1-1; iCurObj_2 >= 0; iCurObj_2--)
        {
            if(!strncmp(rootObjBuf[iCurObj_2], "dataset", strlen("dataset")) && 
               !strncmp(szTemp,                "dataset", strlen("dataset")))
            {
               if(atoi(&rootObjBuf[iCurObj_2][strlen("dataset")]) < 
                       atoi(&szTemp[strlen("dataset")]))
                    break;
            }
            else
            {
                if(strcmp(rootObjBuf[iCurObj_2], szTemp) < 0)
                    break;
            }
            snprintf(rootObjBuf[iCurObj_2+1], sizeof(rootObjBuf[iCurObj_2+1]), 
                     "%s", rootObjBuf[iCurObj_2]);
        }
        snprintf(rootObjBuf[iCurObj_2+1], sizeof(rootObjBuf[iCurObj_2+1]), "%s", szTemp);
    }
}

static int fnHdfReadAttr(hid_t hGroup, char* szAttrName, hid_t hMemType, void *pBuf, int iBufLen) 
{
    hid_t       hAttr       = -1;
    hid_t       hStrType    = -1;

    if(hGroup < 0 || szAttrName == NULL || pBuf == NULL)
        return FALSE;

    if(hMemType == H5T_NATIVE_CHAR && iBufLen > 0) // STRING
    {
        if((hAttr = H5Aopen_name(hGroup, szAttrName)) < 0)
            return FALSE;

        if((hStrType = H5Tcopy(H5T_C_S1)) < 0 )
        {
            H5Aclose(hAttr);
            return FALSE;
        }

        if((H5Tset_size(hStrType, iBufLen)) < 0)
        {
            H5Tclose(hStrType);
            H5Aclose(hAttr);
            return FALSE;
        }

        if(H5Aread(hAttr, hStrType, pBuf) < 0)
        {
            H5Tclose(hStrType);
            H5Aclose(hAttr);
            return FALSE;
        }

        H5Tclose(hStrType);
        H5Aclose(hAttr);
    }
    else
    {
        if((hAttr = H5Aopen_name(hGroup, szAttrName)) < 0)
            return FALSE;

        if(H5Aread(hAttr, hMemType, pBuf) < 0)
        {
            H5Aclose(hAttr);
            return FALSE;
        }

        H5Aclose(hAttr);
    }

    return TRUE;
}

static int fnHdfSearchGroup(hid_t hNode, char pBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN])
{
    herr_t  status      = -1;
    hsize_t hObjCnt     = 0;    // unsigned long long
    int     iObjIdx     = 0;

    if(hNode < 0)
        return -1;

    if((status = H5Gget_num_objs(hNode, &hObjCnt)) < 0)
        return -1;

    if(hObjCnt > RDR_DF_HDF_OBJECT_MAX)
        return -1;

    for(iObjIdx = 0; iObjIdx < hObjCnt; iObjIdx++)
    {
         H5Gget_objname_by_idx(hNode, iObjIdx, pBuf[iObjIdx], RDR_DF_HDF_OBEJCT_LEN);
    }

    return hObjCnt;
}

static int fnHdfSearchAttr(hid_t hNode, char pBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN])
{
    hid_t   hAttr       = -1;
    int     iAttrNum    = 0;
    int     iAttrIdx    = 0;

    if(hNode < 0)
        return -1;

    iAttrNum = H5Aget_num_attrs(hNode);

    for(iAttrIdx = 0; iAttrIdx < iAttrNum; iAttrIdx++)
    {
        if((hAttr = H5Aopen_idx(hNode, iAttrIdx)) < 0)
            return -1;

        H5Aget_name(hAttr, RDR_DF_HDF_ATTR_LEN, pBuf[iAttrIdx]);

        H5Aclose(hAttr);
    }

    return iAttrNum;
}

static int fnGetMaxHdfData(hid_t hDataset)
{
    int         iDatasetObjCnt                                              = 0;
    int         iDatasetObjIdx                                              = 0;
    char        datasetObjBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN] = { "", };
    int         iDataCnt                                                    = 0;

    if(hDataset < 0)
        return -1;

    if((iDatasetObjCnt = fnHdfSearchGroup(hDataset, datasetObjBuf)) < 0)
        return -1;

    for(iDatasetObjIdx = 0; iDatasetObjIdx < iDatasetObjCnt; iDatasetObjIdx++)
    {
        if(!strncmp(datasetObjBuf[iDatasetObjIdx], "data", strlen("data")))
        {
            iDataCnt++;
        }
    }

    return iDataCnt;
}

static int fnGetMaxHdfQuality(hid_t hGroup)
{
    int         iObjCnt                                                 = 0;
    int         iObjIdx                                                 = 0;
    char        objBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN]    = { "", };
    int         iQualityCnt                                             = 0;

    if(hGroup < 0)
        return -1;

    if((iObjCnt = fnHdfSearchGroup(hGroup, objBuf)) < 0)
        return -1;

    for(iObjIdx = 0; iObjIdx < iObjCnt; iObjIdx++)
    {
        if(!strncmp(objBuf[iObjIdx], "quality", strlen("quality")))
        {
            iQualityCnt++;
        }
    }

    return iQualityCnt;
}

static int fnGetMaxHdfProduct(hid_t hRoot, int *pMaxPpi, int *pMaxCappi, int *pMaxBase, int *pMaxCmax, int *pMaxVil, int *pMaxEtop, int *pMaxField)
{
    int         iRootObjCnt                                                 = 0;
    int         iRootObjIdx                                                 = 0;
    char        rootObjBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN]    = { "", };
    hid_t       hDataset                                                    = -1;
    hid_t       hWhat                                                       = -1;
    char        szProduct[RDR_DF_HDF_OBEJCT_LEN]                            = "";
    int         iMaxPpi                                                     = 0;    // VARIABLE
    int         iMaxCappi                                                   = 0;    // VARIABLE
    int         iMaxBase                                                    = 0;    // VARIABLE
    int         iMaxCmax                                                    = 0;    // VARIABLE
    int         iMaxVil                                                     = 0;    // VARIABLE
    int         iMaxEtop                                                    = 0;    // VARIABLE
    int         iMaxField                                                   = 0;    // VARIABLE
    int         iFieldCnt                                                   = 0;    // VARIABLE

    if(hRoot < 0)
        return FALSE;

    if((iRootObjCnt = fnHdfSearchGroup(hRoot, rootObjBuf)) < 0)
        return FALSE;

    for(iRootObjIdx  = 0; iRootObjIdx < iRootObjCnt; iRootObjIdx++)
    {
        if(!strncmp(rootObjBuf[iRootObjIdx], "dataset", strlen("dataset")))
        {
            if((hDataset = H5Gopen1(hRoot, rootObjBuf[iRootObjIdx])) < 0)
                return FALSE;

            if((hWhat = H5Gopen1(hDataset, "what")) < 0)
            {
                H5Gclose(hDataset);
                return FALSE;
            }

            if(fnHdfReadAttr(hWhat, "product", H5T_NATIVE_CHAR, 
                            szProduct, RDR_DF_HDF_OBEJCT_LEN) == FALSE)
            {
                H5Gclose(hWhat);
                H5Gclose(hDataset);
                return FALSE;
            }

            if     (!strcmp(szProduct, "PPI"   ))   iMaxPpi++;
            else if(!strcmp(szProduct, "PCAPPI"))   iMaxCappi++;
            else if(!strcmp(szProduct, "BASE"  ))   iMaxBase++;
            else if(!strcmp(szProduct, "MAX"   ))   iMaxCmax++;
            else if(!strcmp(szProduct, "VIL"   ))   iMaxVil++;
            else if(!strcmp(szProduct, "ETOP"  ))   iMaxEtop++;
            else 
            {
                H5Gclose(hWhat);
                H5Gclose(hDataset);
                return FALSE;
            }

            iFieldCnt = fnGetMaxHdfData(hDataset);
            if(iMaxField < iFieldCnt)
                iMaxField = iFieldCnt;

            H5Gclose(hWhat);
            H5Gclose(hDataset);
        }
    }

    if(pMaxPpi   != NULL) *pMaxPpi   = iMaxPpi;
    if(pMaxCappi != NULL) *pMaxCappi = iMaxCappi;
    if(pMaxBase  != NULL) *pMaxBase  = iMaxBase;
    if(pMaxCmax  != NULL) *pMaxCmax  = iMaxCmax;
    if(pMaxVil   != NULL) *pMaxVil   = iMaxVil;
    if(pMaxEtop  != NULL) *pMaxEtop  = iMaxEtop;
    if(pMaxField != NULL) *pMaxField = iMaxField;

    return TRUE;
}

static int fnGetHdfProductCurDataset(HDF_PRODUCT_DATASET **ppDataset, int iMaxDataset)
{
    int                 iCurDataset     = -1;

    if(ppDataset == NULL || iMaxDataset <= 0)
        return -1;

    for(iCurDataset = 0; iCurDataset < iMaxDataset; iCurDataset++)
    {
        if(!strcmp(ppDataset[iCurDataset]->m_what.m_szProduct, ""))
            break;
    }

    if(iCurDataset < iMaxDataset)
        return iCurDataset;
    else
        return -1;
}

static int fnReadHdfProductDatasetWhat(hid_t hWhat, HDF_PRODUCT_DATASET *pDataset, char *szProduct, int iHdfProductType)
{
    hid_t   hProdpar                                                    = -1;
    int     iWhatObjCnt                                                 = 0;
    int     iWhatObjIdx                                                 = 0;
    char    whatObjBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN]    = { "", };

    if(hWhat < 0 || pDataset == NULL)
        return FALSE;

    if((iWhatObjCnt = fnHdfSearchGroup(hWhat, whatObjBuf)) < 0)
        return FALSE;

    for(iWhatObjIdx = 0; iWhatObjIdx < iWhatObjCnt; iWhatObjIdx++)
    {
        if(!strncmp(whatObjBuf[iWhatObjIdx], "prodpar", strlen("prodpar")))
        {
            if((hProdpar = H5Dopen1(hWhat, whatObjBuf[iWhatObjIdx])) < 0)
                continue;

            H5Dread(hProdpar, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, 
                    H5P_DEFAULT, pDataset->m_what.m_dProdpar);
            H5Dclose(hProdpar);
        }
    }

    return TRUE;
}

static int fnGetHdfProductCurData(HDF_PRODUCT_DATA **ppProductData, int iMaxField)
{
    int         iCurData        = -1;

    if(ppProductData == NULL || iMaxField <= 0)
        return -1;

    for(iCurData = 0; iCurData < iMaxField; iCurData++)
    {
        if(!strcmp(ppProductData[iCurData]->m_szFieldName, ""))
            break;
    }

    if(iCurData < iMaxField)
        return iCurData;
    else
        return -1;
}

static int fnReadHdfProductDataWhat(hid_t hWhat, HDF_PRODUCT_DATA *pProductData)
{
    double      dValue                                                  = 0.0;
    int         iAttrCnt                                                = 0;
    int         iAttrIdx                                                = 0;
    char        pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]    = { "", };

    if(hWhat < 0 || pProductData == NULL)
        return FALSE;

    iAttrCnt = fnHdfSearchAttr(hWhat, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        if(!strcmp(pAttrBuf[iAttrIdx], "quatity"))
        {
            fnHdfReadAttr(hWhat, "quantity", H5T_NATIVE_CHAR,   
                          pProductData->m_what.m_szQuantity, 
                          sizeof(pProductData->m_what.m_szQuantity));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "gain"))
        {
            fnHdfReadAttr(hWhat, "gain",     H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pProductData->m_what.m_dGain = dValue;
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "offset"))
        {
            fnHdfReadAttr(hWhat, "offset",   H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pProductData->m_what.m_dOffset = dValue;
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "nodata"))
        {
            fnHdfReadAttr(hWhat, "nodata",   H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pProductData->m_what.m_dNodata = dValue;
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "undetect"))
        {
            fnHdfReadAttr(hWhat, "undetect", H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pProductData->m_what.m_dUndetect = dValue;
        }
    }

    return TRUE;
}

static int fnReadHdfProductDataChar(hid_t hData, HDF_PRODUCT_DATA *pProductData, int iYdim, int iXdim)
{
    hid_t               hArrayData      = -1;
    int                 iDataCount      = 0;
    char                *pDataBuf       = NULL;
    int                 iYIdx           = 0;
    int                 iXIdx           = 0;
    float               fData           = 0;
    FIELD_MEM_INFO_TBL  memInfo;

    if(hData < 0 || pProductData == NULL)
        return FALSE;

    memset(&memInfo, 0x00, sizeof(FIELD_MEM_INFO_TBL));
    if(fnGetFieldMemInfo(pProductData->m_szFieldName, &memInfo) == RDR_DF_FALSE)
        return FALSE;

    if((hArrayData = H5Dopen1(hData, "data")) < 0)
        return FALSE;

    pDataBuf = (char *)calloc(1, sizeof(char)*iYdim*iXdim);
    if(pDataBuf == NULL)
    {   H5Dclose(hArrayData); return FALSE; }

    if(H5Dread(hArrayData, H5T_NATIVE_CHAR, H5S_ALL, H5S_ALL, H5P_DEFAULT, pDataBuf) < 0)
    {   H5Dclose(hArrayData); free(pDataBuf); return FALSE; }

    pProductData->m_ppData_c = (char **)calloc(iYdim, sizeof(char *));
    if(pProductData->m_ppData_c == NULL)
    {   H5Dclose(hArrayData); free(pDataBuf); return FALSE; }

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        pProductData->m_ppData_c[iYIdx] = (char *)calloc(iXdim, sizeof(char));
        if(pProductData->m_ppData_c[iYIdx] == NULL)
        {
            fnFreeMatrix2D((void **)pProductData->m_ppData_c, iYdim);
            H5Dclose(hArrayData);
            free(pDataBuf);
            return FALSE;
        }
    }

    pProductData->m_iMemType = RDR_EN_MEM_CHAR;

    iDataCount = 0;
    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            if(fabs(pDataBuf[iDataCount] - pProductData->m_what.m_dNodata) < RDR_DF_ERR_RANGE_D)
                pProductData->m_ppData_c[iYIdx][iXIdx] = (char)memInfo.m_fOutBound;
            else if(fabs(pDataBuf[iDataCount] - pProductData->m_what.m_dUndetect) < RDR_DF_ERR_RANGE_D)
                pProductData->m_ppData_c[iYIdx][iXIdx] = (char)memInfo.m_fBadValue;
            else
            {
                fData = ((pDataBuf[iDataCount] * pProductData->m_what.m_dGain)
                         + pProductData->m_what.m_dOffset);

                pProductData->m_ppData_c[iYIdx][iXIdx] 
                = (char)((fData+memInfo.m_fOffset)*memInfo.m_fScale);
            }
            iDataCount++;
        }
    }

    H5Dclose(hArrayData);
    free(pDataBuf);

    return TRUE;
}

static int fnReadHdfProductDataShort(hid_t hData, HDF_PRODUCT_DATA *pProductData, int iYdim, int iXdim)
{
    hid_t               hArrayData      = -1;
    int                 iDataCount      = 0;
    short               *pDataBuf       = NULL;
    int                 iYIdx           = 0;
    int                 iXIdx           = 0;
    float               fData           = 0;
    FIELD_MEM_INFO_TBL  memInfo;

    if(hData < 0 || pProductData == NULL)
        return FALSE;

    memset(&memInfo, 0x00, sizeof(FIELD_MEM_INFO_TBL));
    if(fnGetFieldMemInfo(pProductData->m_szFieldName, &memInfo) == RDR_DF_FALSE)
        return FALSE;

    if((hArrayData = H5Dopen1(hData, "data")) < 0)
        return FALSE;

    pDataBuf = (short *)calloc(1, sizeof(short)*iYdim*iXdim);
    if(pDataBuf == NULL)
    {   H5Dclose(hArrayData); return FALSE; }

    if(H5Dread(hArrayData, H5T_NATIVE_SHORT, H5S_ALL, H5S_ALL, H5P_DEFAULT, pDataBuf) < 0)
    {   H5Dclose(hArrayData); free(pDataBuf); return FALSE; }

    pProductData->m_ppData_s = (short **)calloc(iYdim, sizeof(short *));
    if(pProductData->m_ppData_s == NULL)
    {   H5Dclose(hArrayData); free(pDataBuf); return FALSE; }

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        pProductData->m_ppData_s[iYIdx] = (short *)calloc(iXdim, sizeof(short));
        if(pProductData->m_ppData_s[iYIdx] == NULL)
        {
            fnFreeMatrix2D((void **)pProductData->m_ppData_s, iYdim);
            H5Dclose(hArrayData);
            free(pDataBuf);
            return FALSE;
        }
    }

    pProductData->m_iMemType = RDR_EN_MEM_SHORT;

    iDataCount = 0;
    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            if(fabs(pDataBuf[iDataCount] - pProductData->m_what.m_dNodata) < RDR_DF_ERR_RANGE_D)
                pProductData->m_ppData_s[iYIdx][iXIdx] = (short)memInfo.m_fOutBound;
            else if(fabs(pDataBuf[iDataCount] - pProductData->m_what.m_dUndetect) < RDR_DF_ERR_RANGE_D)
                pProductData->m_ppData_s[iYIdx][iXIdx] = (short)memInfo.m_fBadValue;
            else
            {
                fData = ((pDataBuf[iDataCount] * pProductData->m_what.m_dGain)
                         + pProductData->m_what.m_dOffset);

                pProductData->m_ppData_s[iYIdx][iXIdx] 
                = (short)((fData+memInfo.m_fOffset)*memInfo.m_fScale);
            }
            iDataCount++;
        }
    }

    H5Dclose(hArrayData);
    free(pDataBuf);

    return TRUE;
}

static int fnReadHdfProductDataFloat(hid_t hData, HDF_PRODUCT_DATA *pProductData, int iYdim, int iXdim)
{
    hid_t               hArrayData      = -1;
    int                 iDataCount      = 0;
    float               *pDataBuf       = NULL;
    int                 iYIdx           = 0;
    int                 iXIdx           = 0;
    float               fData           = 0;
    FIELD_MEM_INFO_TBL  memInfo;

    if(hData < 0 || pProductData == NULL)
        return FALSE;

    memset(&memInfo, 0x00, sizeof(FIELD_MEM_INFO_TBL));
    if(fnGetFieldMemInfo(pProductData->m_szFieldName, &memInfo) == RDR_DF_FALSE)
        return FALSE;

    if((hArrayData = H5Dopen1(hData, "data")) < 0)
        return FALSE;

    pDataBuf = (float *)calloc(1, sizeof(float)*iYdim*iXdim);
    if(pDataBuf == NULL)
    {   H5Dclose(hArrayData); return FALSE; }

    if(H5Dread(hArrayData, H5T_NATIVE_FLOAT, H5S_ALL, H5S_ALL, H5P_DEFAULT, pDataBuf) < 0)
    {   H5Dclose(hArrayData); free(pDataBuf); return FALSE; }

    pProductData->m_ppData_f = (float **)calloc(iYdim, sizeof(float *));
    if(pProductData->m_ppData_f == NULL)
    {   H5Dclose(hArrayData); free(pDataBuf); return FALSE; }

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        pProductData->m_ppData_f[iYIdx] = (float *)calloc(iXdim, sizeof(float));
        if(pProductData->m_ppData_f[iYIdx] == NULL)
        {
            fnFreeMatrix2D((void **)pProductData->m_ppData_f, iYdim);
            H5Dclose(hArrayData);
            free(pDataBuf);
            return FALSE;
        }
    }

    pProductData->m_iMemType = RDR_EN_MEM_FLOAT;

    iDataCount = 0;
    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            if(fabs(pDataBuf[iDataCount] - pProductData->m_what.m_dNodata) < RDR_DF_ERR_RANGE_D)
                pProductData->m_ppData_f[iYIdx][iXIdx] = (float)memInfo.m_fOutBound;
            else if(fabs(pDataBuf[iDataCount] - pProductData->m_what.m_dUndetect) < RDR_DF_ERR_RANGE_D)
                pProductData->m_ppData_f[iYIdx][iXIdx] = (float)memInfo.m_fBadValue;
            else
            {
                fData = ((pDataBuf[iDataCount] * pProductData->m_what.m_dGain)
                          + pProductData->m_what.m_dOffset);

                pProductData->m_ppData_f[iYIdx][iXIdx] 
                = (float)((fData+memInfo.m_fOffset)*memInfo.m_fScale);
            }
            iDataCount++;
        }
    }

    H5Dclose(hArrayData);
    free(pDataBuf);

    return TRUE;
}

static int fnReadHdfProductDatasetData(hid_t hDataset, HDF_PRODUCT_DATASET *pDataset, char *szFieldName, int iYdim, int iXdim)
{
    int                 iDatasetObjCnt                                              = 0;
    int                 iDatasetObjIdx                                              = 0;
    char                datasetObjBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN] = { "", };
    char                szQuantity[6+1]                                             = "";
    int                 iCurData                                                    = 0;
    hid_t               hData                                                       = -1;
    hid_t               hWhat                                                       = -1;
    FIELD_INFO_TBL      fieldInfo;
    FIELD_MEM_INFO_TBL  memInfo;

    if(hDataset < 0 || pDataset == NULL)
        return FALSE;

    if((iDatasetObjCnt = fnHdfSearchGroup(hDataset, datasetObjBuf)) < 0)
        return FALSE;

    for(iDatasetObjIdx = 0; iDatasetObjIdx < iDatasetObjCnt; iDatasetObjIdx++)
    {
        if(!strncmp(datasetObjBuf[iDatasetObjIdx], "data", strlen("data")))
        {
            if((hData = H5Gopen1(hDataset, datasetObjBuf[iDatasetObjIdx])) < 0)
                return FALSE;

            if((hWhat = H5Gopen1(hData, "what")) < 0)
            {   H5Gclose(hData); return FALSE; }
            
            fnHdfReadAttr(hWhat, "quantity", H5T_NATIVE_CHAR, szQuantity, sizeof(szQuantity));

            memset(&fieldInfo, 0x00, sizeof(FIELD_INFO_TBL));
            if(fnGetHdfFieldInfo(szQuantity, &fieldInfo) == FALSE)
            {   H5Gclose(hWhat); H5Gclose(hData); return FALSE; }

            if(szFieldName != NULL && strcmp(szFieldName, fieldInfo.m_szFieldName))
                continue;

            if((iCurData = fnGetHdfProductCurData(pDataset->m_ppProductData, 
                                                  pDataset->m_iMaxField)) < 0)
            {   H5Gclose(hWhat); H5Gclose(hData); return FALSE; }

            snprintf(pDataset->m_ppProductData[iCurData]->m_szFieldName, 
                     sizeof(pDataset->m_ppProductData[iCurData]->m_szFieldName), 
                     "%s", fieldInfo.m_szFieldName);

            if(fnReadHdfProductDataWhat(hWhat, pDataset->m_ppProductData[iCurData]) == FALSE)
            {   H5Gclose(hWhat); H5Gclose(hData); return FALSE; }

            memset(&memInfo, 0x00, sizeof(FIELD_MEM_INFO_TBL));
            if(fnGetFieldMemInfo(fieldInfo.m_szFieldName, &memInfo) == RDR_DF_FALSE)
            {   H5Gclose(hWhat); H5Gclose(hData); return FALSE; }

            if(fabs(memInfo.m_fBadValue - RDR_DF_BAD_VALUE_C) < RDR_DF_ERR_RANGE_F)
            {
                if(fnReadHdfProductDataChar(hData, 
                                            pDataset->m_ppProductData[iCurData], 
                                            iYdim, iXdim) == FALSE)
                {   H5Gclose(hWhat); H5Gclose(hData); return FALSE; }
            }
            else if(fabs(memInfo.m_fBadValue - RDR_DF_BAD_VALUE_S) < RDR_DF_ERR_RANGE_F)
            {
                if(fnReadHdfProductDataShort(hData, 
                                             pDataset->m_ppProductData[iCurData], 
                                             iYdim, iXdim) == FALSE)
                {   H5Gclose(hWhat); H5Gclose(hData); return FALSE; }
            }
            else if(fabs(memInfo.m_fBadValue - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
            {
                if(fnReadHdfProductDataFloat(hData, 
                                             pDataset->m_ppProductData[iCurData], 
                                             iYdim, iXdim) == FALSE)
                {   H5Gclose(hWhat); H5Gclose(hData); return FALSE; }
            }

            H5Gclose(hWhat);
            H5Gclose(hData);
        }
    }

    return TRUE;
}

static int fnReadHdfProductDatasetByIdx(hid_t hRoot, char* szDataset, HDF_PRODUCT *pHdfProduct, int iProductIdx, char *szFieldName)
{
    hid_t               hDataset                = -1;
    hid_t               hWhat                   = -1;
    char                szDatasetProduct[6+1]   = "";
    int                 iMaxDataset             = 0;
    int                 iCurDataset             = 0;
    HDF_PRODUCT_DATASET **ppDataset             = NULL;
    PRODUCT_INFO_TBL    productInfo;

    if(hRoot < 0 || pHdfProduct == NULL)
        return FALSE;

    if((hDataset = H5Gopen1(hRoot, szDataset)) < 0)
        return FALSE;

    if((hWhat = H5Gopen1(hDataset, "what")) < 0)
    {   H5Gclose(hDataset); return FALSE; }
    
    fnHdfReadAttr(hWhat, "product", H5T_NATIVE_CHAR, szDatasetProduct, sizeof(szDatasetProduct));
    if(fnGetHdfProductInfo(szDatasetProduct, &productInfo) == FALSE)
    {   H5Gclose(hWhat); H5Gclose(hDataset); return FALSE; }

    if(!strcmp(productInfo.m_szStdProduct, "PPI"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxPpi;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppPpi;
    }
    else if(!strcmp(productInfo.m_szStdProduct, "CAPPI"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxCappi;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppCappi;
    }
    else if(!strcmp(productInfo.m_szStdProduct, "BASE"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxBase;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppBase;
    }
    else if(!strcmp(productInfo.m_szStdProduct, "CMAX"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxCmax;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppCmax;
    }
    else if(!strcmp(productInfo.m_szStdProduct, "VIL"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxVil;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppVil;
    }
    else if(!strcmp(productInfo.m_szStdProduct, "ETOP"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxEtop;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppEtop;
    }
    else { H5Gclose(hWhat); H5Gclose(hDataset); return FALSE; }

    if(ppDataset != NULL && iMaxDataset > 0)
    {
        iCurDataset = iProductIdx;

        if(fnReadHdfProductDatasetWhat(hWhat, ppDataset[iCurDataset], 
                                       productInfo.m_szStdProduct, 
                                       pHdfProduct->m_iHdfProductType) == FALSE)
        {   H5Gclose(hWhat); H5Gclose(hDataset); return FALSE; }

        snprintf(ppDataset[iCurDataset]->m_what.m_szProduct, 
                 sizeof(ppDataset[iCurDataset]->m_what.m_szProduct),
                 "%s", szDatasetProduct);

        if(fnReadHdfProductDatasetData(hDataset, ppDataset[iCurDataset], szFieldName, 
                                        (int)pHdfProduct->m_where.m_image_where.m_lYsize, 
                                        (int)pHdfProduct->m_where.m_image_where.m_lXsize) == FALSE)
        {   
            // ppDataset[iCurDataset]->m_what.m_szProduct 유무로 
            // Dataset의 사용여부를 확인하기때문에 초기화시킨다.
            memset(ppDataset[iCurDataset]->m_what.m_szProduct, 0x00, 
                   sizeof(ppDataset[iCurDataset]->m_what.m_szProduct));
            H5Gclose(hWhat); 
            H5Gclose(hDataset); 
            return FALSE; 
        }
    }

    H5Gclose(hWhat); 
    H5Gclose(hDataset);

    return TRUE;
}

static int fnReadHdfProductDataset(hid_t hRoot, char* szDataset, HDF_PRODUCT *pHdfProduct, char *szFieldName)
{
    hid_t               hDataset                = -1;
    hid_t               hWhat                   = -1;
    char                szDatasetProduct[6+1]   = "";
    int                 iMaxDataset             = 0;
    int                 iCurDataset             = 0;
    HDF_PRODUCT_DATASET **ppDataset             = NULL;
    PRODUCT_INFO_TBL    productInfo;

    if(hRoot < 0 || pHdfProduct == NULL)
        return FALSE;

    if((hDataset = H5Gopen1(hRoot, szDataset)) < 0)
        return FALSE;

    if((hWhat = H5Gopen1(hDataset, "what")) < 0)
    {   H5Gclose(hDataset); return FALSE; }
    
    fnHdfReadAttr(hWhat, "product", H5T_NATIVE_CHAR, szDatasetProduct, sizeof(szDatasetProduct));
    if(fnGetHdfProductInfo(szDatasetProduct, &productInfo) == FALSE)
    {   H5Gclose(hWhat); H5Gclose(hDataset); return FALSE; }

    if(!strcmp(productInfo.m_szStdProduct, "PPI"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxPpi;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppPpi;
    }
    else if(!strcmp(productInfo.m_szStdProduct, "CAPPI"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxCappi;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppCappi;
    }
    else if(!strcmp(productInfo.m_szStdProduct, "BASE"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxBase;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppBase;
    }
    else if(!strcmp(productInfo.m_szStdProduct, "CMAX"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxCmax;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppCmax;
    }
    else if(!strcmp(productInfo.m_szStdProduct, "VIL"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxVil;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppVil;
    }
    else if(!strcmp(productInfo.m_szStdProduct, "ETOP"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxEtop;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppEtop;
    }
    else { H5Gclose(hWhat); H5Gclose(hDataset); return FALSE; }

    if(ppDataset != NULL && iMaxDataset > 0)
    {
        if((iCurDataset = fnGetHdfProductCurDataset(ppDataset, iMaxDataset)) < 0)
        {   H5Gclose(hWhat); H5Gclose(hDataset); return FALSE; }

        if(fnReadHdfProductDatasetWhat(hWhat, ppDataset[iCurDataset], 
                                       productInfo.m_szStdProduct, 
                                       pHdfProduct->m_iHdfProductType) == FALSE)
        {   H5Gclose(hWhat); H5Gclose(hDataset); return FALSE; }

        snprintf(ppDataset[iCurDataset]->m_what.m_szProduct, 
                 sizeof(ppDataset[iCurDataset]->m_what.m_szProduct),
                 "%s", szDatasetProduct);

        if(fnReadHdfProductDatasetData(hDataset, ppDataset[iCurDataset], szFieldName, 
                                       (int)pHdfProduct->m_where.m_image_where.m_lYsize, 
                                       (int)pHdfProduct->m_where.m_image_where.m_lXsize) == FALSE)
        {   
            // ppDataset[iCurDataset]->m_what.m_szProduct 유무로 
            // Dataset의 사용여부를 확인하기때문에 초기화시킨다.
            memset(ppDataset[iCurDataset]->m_what.m_szProduct, 0x00, 
                   sizeof(ppDataset[iCurDataset]->m_what.m_szProduct));
            H5Gclose(hWhat); 
            H5Gclose(hDataset); 
            return FALSE; 
        }
    }

    H5Gclose(hWhat); 
    H5Gclose(hDataset);

    return TRUE;
}

static int fnReadHdfProductDatasetByArg(hid_t hRoot, char* szDataset, HDF_PRODUCT *pHdfProduct, double dProductArg1, double dProductArg2, char *szFieldName)
{
    hid_t               hDataset                = -1;
    hid_t               hWhat                   = -1;
    char                szDatasetProduct[6+1]   = "";
    int                 iMaxDataset             = 0;
    int                 iCurDataset             = 0;
    HDF_PRODUCT_DATASET **ppDataset             = NULL;
    PRODUCT_INFO_TBL    productInfo;

    if(hRoot < 0 || pHdfProduct == NULL)
        return FALSE;

    if((hDataset = H5Gopen1(hRoot, szDataset)) < 0)
        return FALSE;

    if((hWhat = H5Gopen1(hDataset, "what")) < 0)
    {   H5Gclose(hDataset); return FALSE; }
    
    fnHdfReadAttr(hWhat, "product", H5T_NATIVE_CHAR, szDatasetProduct, sizeof(szDatasetProduct));
    if(fnGetHdfProductInfo(szDatasetProduct, &productInfo) == FALSE)
    {   H5Gclose(hWhat); H5Gclose(hDataset); return FALSE; }

    if(!strcmp(productInfo.m_szStdProduct, "PPI"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxPpi;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppPpi;
    }
    else if(!strcmp(productInfo.m_szStdProduct, "CAPPI"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxCappi;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppCappi;
    }
    else if(!strcmp(productInfo.m_szStdProduct, "BASE"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxBase;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppBase;
    }
    else if(!strcmp(productInfo.m_szStdProduct, "CMAX"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxCmax;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppCmax;
    }
    else if(!strcmp(productInfo.m_szStdProduct, "VIL"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxVil;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppVil;
    }
    else if(!strcmp(productInfo.m_szStdProduct, "ETOP"))
    {
        iMaxDataset = pHdfProduct->m_totalProduct.m_iMaxEtop;
        ppDataset   = pHdfProduct->m_totalProduct.m_ppEtop;
    }
    else { H5Gclose(hWhat); H5Gclose(hDataset); return FALSE; }

    if(ppDataset != NULL && iMaxDataset > 0)
    {
        if((iCurDataset = fnGetHdfProductCurDataset(ppDataset, iMaxDataset)) < 0)
        {   H5Gclose(hWhat); H5Gclose(hDataset); return FALSE; }

        if(fnReadHdfProductDatasetWhat(hWhat, ppDataset[iCurDataset], 
                                       productInfo.m_szStdProduct, 
                                       pHdfProduct->m_iHdfProductType) == FALSE)
        {   H5Gclose(hWhat); H5Gclose(hDataset); return FALSE; }

        if(fabs(ppDataset[iCurDataset]->m_what.m_dProdpar[0] - dProductArg1) >= RDR_DF_ERR_RANGE_D &&
           fabs(ppDataset[iCurDataset]->m_what.m_dProdpar[1] - dProductArg1) >= RDR_DF_ERR_RANGE_D)
        {   H5Gclose(hWhat); H5Gclose(hDataset); return FALSE; }

        snprintf(ppDataset[iCurDataset]->m_what.m_szProduct, 
                 sizeof(ppDataset[iCurDataset]->m_what.m_szProduct),
                 "%s", szDatasetProduct);

        if(fnReadHdfProductDatasetData(hDataset, ppDataset[iCurDataset], szFieldName, 
                                        (int)pHdfProduct->m_where.m_image_where.m_lYsize, 
                                        (int)pHdfProduct->m_where.m_image_where.m_lXsize) == FALSE)
        {   
            // ppDataset[iCurDataset]->m_what.m_szProduct 유무로 
            // Dataset의 사용여부를 확인하기때문에 초기화시킨다.
            memset(ppDataset[iCurDataset]->m_what.m_szProduct, 0x00, 
                   sizeof(ppDataset[iCurDataset]->m_what.m_szProduct));
            H5Gclose(hWhat); 
            H5Gclose(hDataset); 
            return FALSE; 
        }
    }

    H5Gclose(hWhat); 
    H5Gclose(hDataset);

    return TRUE;
}

static int fnReadHdfProductTopWhat(hid_t hRoot, HDF_PRODUCT *pHdfProduct)
{
    hid_t       hWhat                                               = -1;
    int         iAttrCnt                                            = 0;
    int         iAttrIdx                                            = 0;
    char        pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]  = { "", };

    if(hRoot < 0 || pHdfProduct == NULL)
        return FALSE;

    if((hWhat = H5Gopen1(hRoot, "what")) < 0)
        return FALSE;

    iAttrCnt = fnHdfSearchAttr(hWhat, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        if(!strcmp(pAttrBuf[iAttrIdx], "object"))
        {
            fnHdfReadAttr(hWhat, "object",  H5T_NATIVE_CHAR, 
                          pHdfProduct->m_what.m_szObject,  sizeof(pHdfProduct->m_what.m_szObject));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "version"))
        {
            fnHdfReadAttr(hWhat, "version", H5T_NATIVE_CHAR, 
                          pHdfProduct->m_what.m_szVersion, sizeof(pHdfProduct->m_what.m_szVersion));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "date"))
        {
            fnHdfReadAttr(hWhat, "date",    H5T_NATIVE_CHAR, 
                          pHdfProduct->m_what.m_szDate,    sizeof(pHdfProduct->m_what.m_szDate));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "time"))
        {
            fnHdfReadAttr(hWhat, "time",    H5T_NATIVE_CHAR, 
                          pHdfProduct->m_what.m_szTime,    sizeof(pHdfProduct->m_what.m_szTime));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "source"))
        {
            fnHdfReadAttr(hWhat, "source",  H5T_NATIVE_CHAR, 
                          pHdfProduct->m_what.m_szSource,  sizeof(pHdfProduct->m_what.m_szSource));
        }
    }

    H5Gclose(hWhat);

    return TRUE;
}

static int fnReadHdfProductTopWhere(hid_t hRoot, HDF_PRODUCT *pHdfProduct)
{
    hid_t       hWhere                                              = -1;
    double      dValue                                              = 0.0;
    long        lValue                                              = 0;
    int         iAttrCnt                                            = 0;
    int         iAttrIdx                                            = 0;
    char        pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]  = { "", };

    if(hRoot < 0 || pHdfProduct == NULL)
        return FALSE;

    if((hWhere = H5Gopen1(hRoot, "where")) < 0)
        return FALSE;

    iAttrCnt = fnHdfSearchAttr(hWhere, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        // POLAR
        if(!strcmp(pAttrBuf[iAttrIdx], "lon"))
        {
            fnHdfReadAttr(hWhere, "lon",     H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pHdfProduct->m_where.m_polar_where.m_dLon = dValue;
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "lat"))
        {
            fnHdfReadAttr(hWhere, "lat",     H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pHdfProduct->m_where.m_polar_where.m_dLat = dValue;
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "height"))
        {
            fnHdfReadAttr(hWhere, "height",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pHdfProduct->m_where.m_polar_where.m_dHeightM = dValue;
        }
        // PRODUCT
        else if(!strcmp(pAttrBuf[iAttrIdx], "projdef"))
        {
            fnHdfReadAttr(hWhere, "projdef", H5T_NATIVE_CHAR,   
                          pHdfProduct->m_where.m_image_where.m_szProjdef, 
                          sizeof(pHdfProduct->m_where.m_image_where.m_szProjdef));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "xsize"))
        {
            fnHdfReadAttr(hWhere, "xsize",   H5T_NATIVE_LONG,   (void *)&lValue, 0);
            pHdfProduct->m_where.m_image_where.m_lXsize = lValue;
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "ysize"))
        {
            fnHdfReadAttr(hWhere, "ysize",   H5T_NATIVE_LONG,   (void *)&lValue, 0);
            pHdfProduct->m_where.m_image_where.m_lYsize = lValue;
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "xscale"))
        {
            fnHdfReadAttr(hWhere, "xscale",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pHdfProduct->m_where.m_image_where.m_dXscale = dValue;
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "yscale"))
        {
            fnHdfReadAttr(hWhere, "yscale",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pHdfProduct->m_where.m_image_where.m_dYscale = dValue;
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "LL_lon"))
        {
            fnHdfReadAttr(hWhere, "LL_lon",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pHdfProduct->m_where.m_image_where.m_LL_lon = dValue;
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "LL_lat"))
        {
            fnHdfReadAttr(hWhere, "LL_lat",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pHdfProduct->m_where.m_image_where.m_LL_lat = dValue;
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "UL_lon"))
        {
            fnHdfReadAttr(hWhere, "UL_lon",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pHdfProduct->m_where.m_image_where.m_UL_lon = dValue;
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "UL_lat"))
        {
            fnHdfReadAttr(hWhere, "UL_lat",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pHdfProduct->m_where.m_image_where.m_UL_lat = dValue;
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "UR_lon"))
        {
            fnHdfReadAttr(hWhere, "UR_lon",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pHdfProduct->m_where.m_image_where.m_UR_lon = dValue;
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "UR_lat"))
        {
            fnHdfReadAttr(hWhere, "UR_lat",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pHdfProduct->m_where.m_image_where.m_UR_lat = dValue;
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "LR_lon"))
        {
            fnHdfReadAttr(hWhere, "LR_lon",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pHdfProduct->m_where.m_image_where.m_LR_lon = dValue;
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "LR_lat"))
        {
            fnHdfReadAttr(hWhere, "LR_lat",  H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pHdfProduct->m_where.m_image_where.m_LR_lat = dValue;
        }
    }

    H5Gclose(hWhere);

    return TRUE;
}

static int fnReadHdfProductTopHow(hid_t hRoot, HDF_PRODUCT *pHdfProduct)
{
    hid_t       hHow                                                = -1;
    double      dValue                                              = 0.0;
    int         iAttrCnt                                            = 0;
    int         iAttrIdx                                            = 0;
    char        pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]  = { "", };

    if(hRoot < 0 || pHdfProduct == NULL)
        return FALSE;

    // HDF TOP HOW
    if((hHow = H5Gopen1(hRoot, "how")) < 0)
        return FALSE;

    iAttrCnt = fnHdfSearchAttr(hHow, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        if(!strcmp(pAttrBuf[iAttrIdx], "NI"))
        {
            fnHdfReadAttr(hHow, "NI",     H5T_NATIVE_DOUBLE, (void *)&dValue, 0);
            pHdfProduct->m_how.m_radar_how.m_dNi = dValue;
        }
    }

    H5Gclose(hHow);

    return TRUE;
}

static int fnGetHdfProductTotalDatsetMax(HDF_PRODUCT *pHdfProduct)
{
    int         iTotalDatasetMax    = 0;

    if(pHdfProduct == NULL)
        return -1;

    iTotalDatasetMax += pHdfProduct->m_totalProduct.m_iMaxPpi;
    iTotalDatasetMax += pHdfProduct->m_totalProduct.m_iMaxCappi;
    iTotalDatasetMax += pHdfProduct->m_totalProduct.m_iMaxBase;
    iTotalDatasetMax += pHdfProduct->m_totalProduct.m_iMaxCmax;
    iTotalDatasetMax += pHdfProduct->m_totalProduct.m_iMaxVil;
    iTotalDatasetMax += pHdfProduct->m_totalProduct.m_iMaxEtop;

    return iTotalDatasetMax;
}

static int fnReadHdfProductRoot(hid_t hRoot, HDF_PRODUCT *pHdfProduct, char* szFieldName)
{
    int         iRootObjCnt                                                 = 0;
    int         iRootObjIdx                                                 = 0;
    int         iTotalDatasetMax                                            = 0;
    int         iCurDatasetCnt                                              = 0;
    char        rootObjBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN]    = { "", };

    if(hRoot < 0 || pHdfProduct == NULL)
        return FALSE;

    fnHdfReadAttr(hRoot, "Conventions",  H5T_NATIVE_CHAR, 
                  pHdfProduct->m_szConventions, sizeof(pHdfProduct->m_szConventions));

    if((iRootObjCnt = fnHdfSearchGroup(hRoot, rootObjBuf)) < 0)
        return FALSE;

    fnInsertionSortRootGroup(iRootObjCnt, rootObjBuf);

    if(fnReadHdfProductTopWhat(hRoot, pHdfProduct) == FALSE)
        return FALSE;

    if(fnReadHdfProductTopWhere(hRoot, pHdfProduct) == FALSE)
        return FALSE;

    if(fnReadHdfProductTopHow(hRoot, pHdfProduct) == FALSE)
        return FALSE;

    if(!strcmp(pHdfProduct->m_what.m_szObject, "AZIM"))
        pHdfProduct->m_iHdfProductType = HDF_EN_PRODUCT_SITE;
    else if(!strcmp(pHdfProduct->m_what.m_szObject, "COMP"))
        pHdfProduct->m_iHdfProductType = HDF_EN_PRODUCT_COMP;

    iCurDatasetCnt = 0;
    iTotalDatasetMax = fnGetHdfProductTotalDatsetMax(pHdfProduct);
    for(iRootObjIdx = 0; iRootObjIdx < iRootObjCnt; iRootObjIdx++)
    {
        if(!strncmp(rootObjBuf[iRootObjIdx], "dataset", strlen("dataset")))
        {
            if(fnReadHdfProductDataset(hRoot, 
                                       rootObjBuf[iRootObjIdx], 
                                       pHdfProduct, szFieldName) == FALSE)
                return FALSE;
            else
                iCurDatasetCnt++;

            if(iCurDatasetCnt >= iTotalDatasetMax)
                break;
        }
    }

    if(iCurDatasetCnt != iTotalDatasetMax)
        return FALSE;

    return TRUE;
}

static int fnReadHdfProductRootByIdx(hid_t hRoot, HDF_PRODUCT *pHdfProduct, int iProductIdx, char* szFieldName)
{
    int         iRootObjCnt                                                 = 0;
    int         iRootObjIdx                                                 = 0;
    int         iTotalDatasetMax                                            = 0;
    int         iCurDatasetCnt                                              = 0;
    char        rootObjBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN]    = { "", };

    if(hRoot < 0 || pHdfProduct == NULL)
        return FALSE;

    fnHdfReadAttr(hRoot, "Conventions",  H5T_NATIVE_CHAR, 
                   pHdfProduct->m_szConventions, sizeof(pHdfProduct->m_szConventions));

    if((iRootObjCnt = fnHdfSearchGroup(hRoot, rootObjBuf)) < 0)
        return FALSE;

    fnInsertionSortRootGroup(iRootObjCnt, rootObjBuf);

    if(fnReadHdfProductTopWhat(hRoot, pHdfProduct) == FALSE)
        return FALSE;

    if(fnReadHdfProductTopWhere(hRoot, pHdfProduct) == FALSE)
        return FALSE;

    if(fnReadHdfProductTopHow(hRoot, pHdfProduct) == FALSE)
        return FALSE;

    if(!strcmp(pHdfProduct->m_what.m_szObject, "AZIM"))
        pHdfProduct->m_iHdfProductType = HDF_EN_PRODUCT_SITE;
    else if(!strcmp(pHdfProduct->m_what.m_szObject, "COMP"))
        pHdfProduct->m_iHdfProductType = HDF_EN_PRODUCT_COMP;

    iCurDatasetCnt = 0;
    iTotalDatasetMax = fnGetHdfProductTotalDatsetMax(pHdfProduct);
	
	fprintf(stderr, "iRootObjCnt : %d \n " , iRootObjCnt);
	int i = 0 ; 
    for(iRootObjIdx = 0; iRootObjIdx < iRootObjCnt; iRootObjIdx++)
    {
		fprintf(stderr, " -->iRootObjidx  : %d \n " , i); i++;
        if(!strncmp(rootObjBuf[iRootObjIdx], "dataset", strlen("dataset")))
        {
            if(iCurDatasetCnt == iProductIdx)
                if(fnReadHdfProductDatasetByIdx(hRoot, 
                                                rootObjBuf[`], 
                                                pHdfProduct, iProductIdx, szFieldName) == FALSE)
                    return FALSE;

            iCurDatasetCnt++;

            if(iCurDatasetCnt >= iTotalDatasetMax)
                break;
        }
    }

    if(iCurDatasetCnt != iTotalDatasetMax)
        return FALSE;

    return TRUE;
}

static int fnReadHdfProductRootByArg(hid_t hRoot, HDF_PRODUCT *pHdfProduct, double dProductArg1, double dProductArg2, char* szFieldName)
{
    int         iRootObjCnt                                                 = 0;
    int         iRootObjIdx                                                 = 0;
    int         iTotalDatasetMax                                            = 0;
    int         iCurDatasetCnt                                              = 0;
    char        rootObjBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN]    = { "", };

    if(hRoot < 0 || pHdfProduct == NULL)
        return FALSE;

    fnHdfReadAttr(hRoot, "Conventions",  H5T_NATIVE_CHAR, 
                   pHdfProduct->m_szConventions, sizeof(pHdfProduct->m_szConventions));

    if((iRootObjCnt = fnHdfSearchGroup(hRoot, rootObjBuf)) < 0)
        return FALSE;

    fnInsertionSortRootGroup(iRootObjCnt, rootObjBuf);

    if(fnReadHdfProductTopWhat(hRoot, pHdfProduct) == FALSE)
        return FALSE;

    if(fnReadHdfProductTopWhere(hRoot, pHdfProduct) == FALSE)
        return FALSE;

    if(fnReadHdfProductTopHow(hRoot, pHdfProduct) == FALSE)
        return FALSE;

    if(!strcmp(pHdfProduct->m_what.m_szObject, "AZIM"))
        pHdfProduct->m_iHdfProductType = HDF_EN_PRODUCT_SITE;
    else if(!strcmp(pHdfProduct->m_what.m_szObject, "COMP"))
        pHdfProduct->m_iHdfProductType = HDF_EN_PRODUCT_COMP;

    iCurDatasetCnt = 0;
    iTotalDatasetMax = 1;
    for(iRootObjIdx = 0; iRootObjIdx < iRootObjCnt; iRootObjIdx++)
    {
        if(!strncmp(rootObjBuf[iRootObjIdx], "dataset", strlen("dataset")))
        {
            if(fnReadHdfProductDatasetByArg(hRoot, rootObjBuf[iRootObjIdx], 
                                            pHdfProduct, dProductArg1, dProductArg2, 
                                            szFieldName) == FALSE)
                continue;
            else
                iCurDatasetCnt++;

            if(iCurDatasetCnt >= iTotalDatasetMax)
                break;
        }
    }

    if(iCurDatasetCnt != iTotalDatasetMax)
        return FALSE;

    return TRUE;
}

static int fnGetMaxHdfRadar(hid_t hRoot, int *pMaxDataset, int *pMaxData, int *pMaxDsetQuality, int *pMaxDataQuality)
{
    int         iRootObjCnt                                                 = 0;
    int         iRootObjIdx                                                 = 0;
    char        rootObjBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN]    = { "", };
    hid_t       hDataset                                                    = -1;
    int         iDsetObjCnt                                                 = 0;
    int         iDsetObjIdx                                                 = 0;
    char        DsetObjBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN]    = { "", };
    hid_t       hData                                                       = -1;
    int         iMaxDataset                                                 = 0;        // VARIABLE
    int         iMaxData                                                    = 0;        // VARIABLE
    int         iDataCnt                                                    = 0;        // BARIABLE
    int         iMaxDsetQuality                                             = 0;        // VARIABLE
    int         iDsetQualityCnt                                             = 0;        // VARIABLE
    int         iMaxDataQuality                                             = 0;        // VARIABLE
    int         iDataQualityCnt                                             = 0;        // VARIABLE

    if(hRoot < 0)
        return FALSE;

    if((iRootObjCnt = fnHdfSearchGroup(hRoot, rootObjBuf)) < 0)
        return FALSE;

    for(iRootObjIdx  = 0; iRootObjIdx < iRootObjCnt; iRootObjIdx++)
    {
        if(!strncmp(rootObjBuf[iRootObjIdx], "dataset", strlen("dataset")))
        {
            if((hDataset = H5Gopen1(hRoot, rootObjBuf[iRootObjIdx])) < 0)
                return FALSE;

            iMaxDataset++;

            iDataCnt = fnGetMaxHdfData(hDataset);
            if(iMaxData < iDataCnt)
                iMaxData = iDataCnt;

            iDsetQualityCnt = fnGetMaxHdfQuality(hDataset);
            if(iMaxDsetQuality < iDsetQualityCnt)
                iMaxDsetQuality = iDsetQualityCnt;

            iDsetObjCnt = fnHdfSearchGroup(hDataset, DsetObjBuf);
            for(iDsetObjIdx = 0; iDsetObjIdx < iDsetObjCnt; iDsetObjIdx++)
            {
                if(!strncmp(DsetObjBuf[iDsetObjIdx], "data", strlen("data")))
                {
                    if((hData = H5Gopen1(hDataset, DsetObjBuf[iDsetObjIdx])) < 0)
                    {
                        H5Gclose(hDataset);
                        return FALSE;
                    }

                    iDataQualityCnt = fnGetMaxHdfQuality(hData);
                    if(iMaxDataQuality < iDataQualityCnt)
                        iMaxDataQuality = iDataQualityCnt;

                    H5Gclose(hData);
                }
            }

            H5Gclose(hDataset);
        }
    }

    if(pMaxDataset     != NULL) *pMaxDataset     = iMaxDataset;
    if(pMaxData        != NULL) *pMaxData        = iMaxData;
    if(pMaxDsetQuality != NULL) *pMaxDsetQuality = iMaxDsetQuality;
    if(pMaxDataQuality != NULL) *pMaxDataQuality = iDataQualityCnt;

    return TRUE;
}

static int fnReadHdfRadarTopWhat(hid_t hRoot, HDF_RADAR *pHdf)
{
    hid_t       hWhat                                               = -1;
    int         iAttrCnt                                            = 0;
    int         iAttrIdx                                            = 0;
    char        pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]  = { "", };

    if(hRoot < 0 || pHdf == NULL)
        return FALSE;

    if((hWhat = H5Gopen1(hRoot, "what")) < 0)
        return FALSE;

    iAttrCnt = fnHdfSearchAttr(hWhat, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        if(!strcmp(pAttrBuf[iAttrIdx], "object"))
        {
            fnHdfReadAttr(hWhat, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR,
                           pHdf->m_what.m_szObject, sizeof(pHdf->m_what.m_szObject));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "version"))
        {
            fnHdfReadAttr(hWhat, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR,
                           pHdf->m_what.m_szVersion, sizeof(pHdf->m_what.m_szVersion));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "date"))
        {
            fnHdfReadAttr(hWhat, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR,
                           pHdf->m_what.m_szDate, sizeof(pHdf->m_what.m_szDate));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "time"))
        {
            fnHdfReadAttr(hWhat, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR,
                           pHdf->m_what.m_szTime, sizeof(pHdf->m_what.m_szTime));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "source"))
        {
            fnHdfReadAttr(hWhat, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR,
                           pHdf->m_what.m_szSource, sizeof(pHdf->m_what.m_szSource));
        }
    }

    H5Gclose(hWhat);

    return TRUE;
}

static int fnReadHdfRadarDsetWhat(hid_t hDataset, HDF_DATASET_WHAT *pWhat)
{
    hid_t       hWhat                                               = -1;
    hid_t       hData                                               = -1;
    int         iAttrCnt                                            = 0;
    int         iAttrIdx                                            = 0;
    char        pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]  = { "", };

    if(hDataset < 0 || pWhat == NULL)
        return FALSE;

    if((hWhat = H5Gopen1(hDataset, "what")) < 0)
        return FALSE;

    iAttrCnt = fnHdfSearchAttr(hWhat, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        if(!strcmp(pAttrBuf[iAttrIdx], "product"))
        {
            fnHdfReadAttr(hWhat, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR,
                           pWhat->m_szProduct, sizeof(pWhat->m_szProduct));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "prodpar"))
        {
            if((hData = H5Dopen1(hWhat, pAttrBuf[iAttrIdx])) < 0)
                continue;

            H5Dread(hData, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, pWhat->m_dProdpar);
            H5Dclose(hData);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "quantity"))
        {
            fnHdfReadAttr(hWhat, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR,
                           pWhat->m_szQuantity, sizeof(pWhat->m_szQuantity));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "startdate"))
        {
            fnHdfReadAttr(hWhat, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR,
                           pWhat->m_szStartDate, sizeof(pWhat->m_szStartDate));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "starttime"))
        {
            fnHdfReadAttr(hWhat, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR,
                           pWhat->m_szStartTime, sizeof(pWhat->m_szStartTime));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "enddate"))
        {
            fnHdfReadAttr(hWhat, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR,
                           pWhat->m_szEndDate, sizeof(pWhat->m_szEndDate));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "endtime"))
        {
            fnHdfReadAttr(hWhat, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR,
                           pWhat->m_szEndTime, sizeof(pWhat->m_szEndTime));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "gain"))
        {
            fnHdfReadAttr(hWhat, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                           (void *)(&pWhat->m_dGain), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "offset"))
        {
            fnHdfReadAttr(hWhat, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                           (void *)(&pWhat->m_dOffset), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "nodata"))
        {
            fnHdfReadAttr(hWhat, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                           (void *)(&pWhat->m_dNodata), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "undetect"))
        {
            fnHdfReadAttr(hWhat, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                           (void *)(&pWhat->m_dUndetect), 0);
        }
    }

    H5Gclose(hWhat);

    return TRUE;
}

static int fnReadHdfRadarPolarWhere(hid_t hGroup, HDF_POLAR_WHERE *pWhere)
{
    hid_t       hWhere                                              = -1;
    int         iAttrCnt                                            = 0;
    int         iAttrIdx                                            = 0;
    char        pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]  = { "", };

    if(hGroup < 0 || pWhere == NULL)
        return FALSE;

    if((hWhere = H5Gopen1(hGroup, "where")) < 0)
        return FALSE;

    iAttrCnt = fnHdfSearchAttr(hWhere, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        // Common
        if(!strcmp(pAttrBuf[iAttrIdx], "lon"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                           (void *)(&pWhere->m_dLon), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "lat"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                           (void *)(&pWhere->m_dLat), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "height"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                           (void *)(&pWhere->m_dHeightM), 0);
        }
        // Dataset
        else if(!strcmp(pAttrBuf[iAttrIdx], "elangle"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                           (void *)(&pWhere->m_dElangle), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "nbins"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_LONG, 
                           (void *)(&pWhere->m_nBins), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "rstart"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                           (void *)(&pWhere->m_dRstart), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "rscale"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                           (void *)(&pWhere->m_dRScale), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "nrays"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_LONG, 
                           (void *)(&pWhere->m_nRays), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "a1gate"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_LONG, 
                           (void *)(&pWhere->m_lA1gate), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "startaz"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                           (void *)(&pWhere->m_dStartAz), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "stopaz"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                           (void *)(&pWhere->m_dStopAz), 0);
        }
    }

    H5Gclose(hWhere);

    return TRUE;
}

static int fnReadHdfRadarImageWhere(hid_t hGroup, HDF_IMAGE_WHERE *pWhere)
{
    hid_t       hWhere                                              = -1;
    int         iAttrCnt                                            = 0;
    int         iAttrIdx                                            = 0;
    char        pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]  = { "", };

    if(hGroup < 0 || pWhere == NULL)
        return FALSE;

    if((hWhere = H5Gopen1(hGroup, "where")) < 0)
        return FALSE;

    iAttrCnt = fnHdfSearchAttr(hWhere, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        // image
        if(!strcmp(pAttrBuf[iAttrIdx], "projdef"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pWhere->m_szProjdef, sizeof(pWhere->m_szProjdef));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "xsize"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_LONG, 
                          (void *)(&pWhere->m_lXsize), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "ysize"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_LONG, 
                          (void *)(&pWhere->m_lYsize), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "xscale"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dXscale), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "yscale"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dYscale), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "LL_lon"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_LL_lon), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "LL_lat"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_LL_lat), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "UL_lon"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_UL_lon), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "UL_lat"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_UL_lat), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "UR_lon"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_UR_lon), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "UR_lat"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_UR_lat), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "LR_lon"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_LR_lon), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "LR_lat"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_LR_lat), 0);
        }
    }

    H5Gclose(hWhere);

    return TRUE;
}

static int fnReadHdfRadarCrossWhere(hid_t hGroup, HDF_CROSS_WHERE *pWhere)
{
    hid_t       hWhere                                              = -1;
    hid_t       hData                                               = -1;
    int         iAttrCnt                                            = 0;
    int         iAttrIdx                                            = 0;
    char        pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]  = { "", };

    if(hGroup < 0 || pWhere == NULL)
        return FALSE;

    if((hWhere = H5Gopen1(hGroup, "where")) < 0)
        return FALSE;

    iAttrCnt = fnHdfSearchAttr(hWhere, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        // Cross
        if(!strcmp(pAttrBuf[iAttrIdx], "xsize"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_LONG, 
                          (void *)(&pWhere->m_lXsize), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "ysize"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_LONG, 
                          (void *)(&pWhere->m_lYsize), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "xscale"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dXscale), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "yscale"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dYscale), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "minheight"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dMinHeightM), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "maxheight"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dMaxHeightM), 0);
        }
        // RHI
        else if(!strcmp(pAttrBuf[iAttrIdx], "lon"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dLon), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "lat"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dLat), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "az_angle"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dAz_angle), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "angles"))
        {
            if((hData = H5Dopen1(hWhere, pAttrBuf[iAttrIdx])) < 0)
                continue;

            H5Dread(hData, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, pWhere->m_dAngles);
            H5Dclose(hData);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "range"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dRange), 0);
        }
        // Cross section
        else if(!strcmp(pAttrBuf[iAttrIdx], "start_lon"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dStart_lon), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "start_lat"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dStart_lat), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "stop_lon"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dStop_lon), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "stop_lat"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dStop_lat), 0);
        }
    }

    H5Gclose(hWhere);

    return TRUE;
}

static int fnReadHdfRadarVerticalWhere(hid_t hGroup, HDF_VERTICAL_WHERE *pWhere)
{
    hid_t       hWhere                                              = -1;
    int         iAttrCnt                                            = 0;
    int         iAttrIdx                                            = 0;
    char        pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]  = { "", };

    if(hGroup < 0 || pWhere == NULL)
        return FALSE;

    if((hWhere = H5Gopen1(hGroup, "where")) < 0)
        return FALSE;

    iAttrCnt = fnHdfSearchAttr(hWhere, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        // Vertical
        if(!strcmp(pAttrBuf[iAttrIdx], "lon"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dLon), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "lat"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dLat), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "height"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dHeightM), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "levels"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_LONG, 
                          (void *)(&pWhere->m_lLevels), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "interval"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dInterval), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "minheight"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dMinHeightM), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "maxheight"))
        {
            fnHdfReadAttr(hWhere, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pWhere->m_dMaxHeightM), 0);
        }
    }

    H5Gclose(hWhere);

    return TRUE;
}

static int fnReadHdfRadarGeneralHow(hid_t hGroup, HDF_GENERAL_HOW *pHow)
{
    hid_t       hHow                                                = -1;
    int         iAttrCnt                                            = 0;
    int         iAttrIdx                                            = 0;
    char        pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]  = { "", };

    if(hGroup < 0 || pHow == NULL)
        return FALSE;

    if((hHow = H5Gopen1(hGroup, "how")) < 0)
        return FALSE;

    iAttrCnt = fnHdfSearchAttr(hHow, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        if(!strcmp(pAttrBuf[iAttrIdx], "task"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szTask, sizeof(pHow->m_szTask));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "task_arg"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szTaskArg, sizeof(pHow->m_szTaskArg));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "startepochs"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dStartepochs), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "endepochs"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dEndepochs), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "system"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szSystem, sizeof(pHow->m_szSystem));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "TXtype"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szTXtype, sizeof(pHow->m_szTXtype));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "poltype"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szPoltype, sizeof(pHow->m_szPoltype));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "polmode"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szPolmode, sizeof(pHow->m_szPolmode));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "software"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szSoftware, sizeof(pHow->m_szSoftware));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "sw_version"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szSW_version, sizeof(pHow->m_szSW_version));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "zr_a"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dZr_a), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "zr_b"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dZr_b), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "kr_a"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dKr_a), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "kr_b"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dKr_b), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "simulated"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_bSimulated, sizeof(pHow->m_bSimulated));
        }
    }

    H5Gclose(hHow);

    return TRUE;
}

static int fnReadHdfRadarRadarHow(hid_t hGroup, HDF_RADAR_HOW *pHow)
{
    hid_t       hHow                                                = -1;
    hid_t       hData                                               = -1;
    int         iAttrCnt                                            =  0;
    int         iAttrIdx                                            = 0;
    char        pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]  = { "", };

    if(hGroup < 0 || pHow == NULL)
        return FALSE;

    if((hHow = H5Gopen1(hGroup, "how")) < 0)
        return FALSE;

    iAttrCnt = fnHdfSearchAttr(hHow, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        if(!strcmp(pAttrBuf[iAttrIdx], "breamwidth"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dBeamwidth), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "wavelength"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dWaveLength), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "rpm"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dRpm), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "elevspeed"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dElevsSpeed), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "pulsewidth"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dPulseWidth), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "RXbandwidth"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dRXbandWidth), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "lowprf"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dLowPrf), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "midprf"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dMidPrf), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "highprf"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dHighPrf), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "TXlossH"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dTXlossH), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "TXlossV"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dTXlossV), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "injectlossH"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dInjectlossH), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "injectlossV"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dInjectlossV), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "RXlossH"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dRXlossH), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "RXlossV"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dRXlossV), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "radomelossH"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dRadomelossH), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "radomelossV"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dRadomelossV), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "antgainH"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dAntgainH), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "antgainV"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dAntgainV), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "beamwH"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dBeamwH), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "beamwV"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dBeamwV), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "gasattn"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dGasattn), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "radconstH"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dRadconstH), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "radconstV"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dRadconstV), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "nomTXpower"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dNomTXpower), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "TXpower"))
        {
            if((hData = H5Dopen1(hHow, pAttrBuf[iAttrIdx])) < 0)
                continue;

            H5Dread(hData, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, pHow->m_dTXpower);
            H5Dclose(hData);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "powerdiff"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dPowerDiff), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "phasediff"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dPhaseDiff), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "NI"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dNi), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "Vsamples"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_LONG, 
                          (void *)(&pHow->m_lVsamples), 0);
        }
    }

    H5Gclose(hHow);

    return TRUE;
}

static int fnReadHdfRadarPolarHow(hid_t hGroup, HDF_POLAR_HOW *pHow)
{
    hid_t       hHow                                                = -1;
    hid_t       hData                                               = -1;
    int         iAttrCnt                                            = 0;
    int         iAttrIdx                                            = 0;
    char        pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]  = { "", };

    if(hGroup < 0 || pHow == NULL)
        return FALSE;

    if((hHow = H5Gopen1(hGroup, "how")) < 0)
        return FALSE;

    iAttrCnt = fnHdfSearchAttr(hHow, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        if(!strcmp(pAttrBuf[iAttrIdx], "scan_index"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_LONG, 
                          (void *)(&pHow->m_lScan_index), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "scan_count"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_LONG, 
                          (void *)(&pHow->m_lScan_count), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "astart"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dAstart), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "szmethod"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szAzmethod, sizeof(pHow->m_szAzmethod));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "elmethod"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szElmethod, sizeof(pHow->m_szElmethod));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "binmethod"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szBinmethod, sizeof(pHow->m_szBinmethod));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "elangles"))
        {
            if((hData = H5Dopen1(hHow, pAttrBuf[iAttrIdx])) < 0)
                continue;

            H5Dread(hData, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, pHow->m_dElangles);
            H5Dclose(hData);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "startazA"))
        {
            if((hData = H5Dopen1(hHow, pAttrBuf[iAttrIdx])) < 0)
                continue;

            H5Dread(hData, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, pHow->m_dStartazA);
            H5Dclose(hData);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "stopazA"))
        {
            if((hData = H5Dopen1(hHow, pAttrBuf[iAttrIdx])) < 0)
                continue;

            H5Dread(hData, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, pHow->m_dStopazA);
            H5Dclose(hData);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "startazT"))
        {
            if((hData = H5Dopen1(hHow, pAttrBuf[iAttrIdx])) < 0)
                continue;

            H5Dread(hData, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, pHow->m_dStartazT);
            H5Dclose(hData);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "stopazT"))
        {
            if((hData = H5Dopen1(hHow, pAttrBuf[iAttrIdx])) < 0)
                continue;

            H5Dread(hData, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, pHow->m_dStopazT);
            H5Dclose(hData);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "startelA"))
        {
            if((hData = H5Dopen1(hHow, pAttrBuf[iAttrIdx])) < 0)
                continue;

            H5Dread(hData, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, pHow->m_dStartelA);
            H5Dclose(hData);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "stopelA"))
        {
            if((hData = H5Dopen1(hHow, pAttrBuf[iAttrIdx])) < 0)
                continue;

            H5Dread(hData, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, pHow->m_dStopelA);
            H5Dclose(hData);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "startelT"))
        {
            if((hData = H5Dopen1(hHow, pAttrBuf[iAttrIdx])) < 0)
                continue;

            H5Dread(hData, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, pHow->m_dStartelT);
            H5Dclose(hData);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "stopelT"))
        {
            if((hData = H5Dopen1(hHow, pAttrBuf[iAttrIdx])) < 0)
                continue;

            H5Dread(hData, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, pHow->m_dStopelT);
            H5Dclose(hData);
        }
    }

    H5Gclose(hHow);

    return TRUE;
}

static int fnReadHdfRadarImageHow(hid_t hGroup, HDF_IMAGE_HOW *pHow)
{
    hid_t       hHow                                                = -1;
    hid_t       hData                                               = -1;
    int         iAttrCnt                                            = 0;
    int         iAttrIdx                                            = 0;
    char        pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]  = { "", };

    if(hGroup < 0 || pHow == NULL)
        return FALSE;

    if((hHow = H5Gopen1(hGroup, "how")) < 0)
        return FALSE;

    iAttrCnt = fnHdfSearchAttr(hHow, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        if(!strcmp(pAttrBuf[iAttrIdx], "angles"))
        {
            if((hData = H5Dopen1(hHow, pAttrBuf[iAttrIdx])) < 0)
                continue;

            H5Dread(hData, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, pHow->m_dAngles);
            H5Dclose(hData);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "arotation"))
        {
            if((hData = H5Dopen1(hHow, pAttrBuf[iAttrIdx])) < 0)
                continue;

            H5Dread(hData, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, pHow->m_dArotation);
            H5Dclose(hData);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "camethod"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szCamethod, sizeof(pHow->m_szCamethod));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "nodes"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szNodes, sizeof(pHow->m_szNodes));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "ACCnum"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_LONG, 
                          (void *)(&pHow->m_lAccNum), 0);
        }
    }

    H5Gclose(hHow);

    return TRUE;
}

static int fnReadHdfRadarVerticalHow(hid_t hGroup, HDF_VERTICAL_HOW *pHow)
{
    hid_t       hHow                                                = -1;
    int         iAttrCnt                                            = 0;
    int         iAttrIdx                                            = 0;
    char        pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]  = { "", };

    if(hGroup < 0 || pHow == NULL)
        return FALSE;

    if((hHow = H5Gopen1(hGroup, "how")) < 0)
        return FALSE;

    iAttrCnt = fnHdfSearchAttr(hHow, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        if(!strcmp(pAttrBuf[iAttrIdx], "minrange"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dMinRangeKm), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "maxrange"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dMaxRangeKm), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "dealiased"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szDealiased, sizeof(pHow->m_szDealiased));
        }
    }

    H5Gclose(hHow);

    return TRUE;
}

static int fnReadHdfRadarQualityHow(hid_t hGroup, HDF_QUALITY_HOW *pHow)
{
    hid_t       hHow                                                = -1;
    int         iAttrCnt                                            = 0;
    int         iAttrIdx                                            = 0;
    char        pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]  = { "", };

    if(hGroup < 0 || pHow == NULL)
        return FALSE;

    if((hHow = H5Gopen1(hGroup, "how")) < 0)
        return FALSE;

    iAttrCnt = fnHdfSearchAttr(hHow, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        if(!strcmp(pAttrBuf[iAttrIdx], "pointaccEL"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dPointAccEl), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "pointaccAZ"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dPointAccAZ), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "anglesync"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szAngleSync, sizeof(pHow->m_szAngleSync));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "anglesynceRes"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dAnglesSyncRes), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "malfunc"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szMalfunc, sizeof(pHow->m_szMalfunc));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "radar_msg"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szRadar_msg, sizeof(pHow->m_szRadar_msg));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "radhoriz"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dRadarHoriz), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "NEZH"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dNEZH), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "NEZV"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dNEZV), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "OUR"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dOUR), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "Dclutter"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szDclutter, sizeof(pHow->m_szDclutter));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "clutterType"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szClutterType, sizeof(pHow->m_szClutterType));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "clutterMap"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szClutterMap, sizeof(pHow->m_szClutterMap));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "zcalH"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dZcalH), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "zcalV"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dZcalV), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "nsampleH"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dNsampleH), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "nsampleV"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dNsampleV), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "comment"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szComment, sizeof(pHow->m_szComment));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "SQI"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dSQI), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "CSR"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dCSR), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "LOG"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dLOG), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "VPRCorr"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szVPRCorr, sizeof(pHow->m_szVPRCorr));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "freeze"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dFreeze), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "min"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dMin), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "max"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dMax), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "step"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dStep), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "levels"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_LONG, 
                          (void *)(&pHow->m_lLevels), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "peakpwr"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dPeakpwr), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "avepwr"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dAvgpwr), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "dynrange"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dDynrange), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "RAC"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dRAC), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "BBC"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szBBC, sizeof(pHow->m_szBBC));
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "PAC"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dPAC), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "S2N"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_DOUBLE, 
                          (void *)(&pHow->m_dS2N), 0);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "polarization"))
        {
            fnHdfReadAttr(hHow, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR, 
                          pHow->m_szPolarization, sizeof(pHow->m_szPolarization));
        }
    }

    H5Gclose(hHow);

    return TRUE;
}

static int fnReadHdfRadarWhere(hid_t hGroup, HDF_WHERE *pWhere, int iHdfType)
{
    switch(iHdfType)
    {
        case HDF_EN_R_TYPE_POLAR:
        {
            if(fnReadHdfRadarPolarWhere(hGroup, &(pWhere->m_polar_where)) == FALSE)
                return FALSE;
        }
        break;
        case HDF_EN_R_TYPE_IMAGE:
        {
            if(fnReadHdfRadarImageWhere(hGroup, &(pWhere->m_image_where)) == FALSE)
                return FALSE;
        }
        break;
        case HDF_EN_R_TYPE_CROSS:
        {
            if(fnReadHdfRadarCrossWhere(hGroup, &(pWhere->m_cross_where)) == FALSE)
                return FALSE;
        }
        break;
        case HDF_EN_R_TYPE_VERTICAL:
        {
            if(fnReadHdfRadarVerticalWhere(hGroup, &(pWhere->m_vertical_where)) == FALSE)
                return FALSE;
        }
        break;
    }
    
    return TRUE;
}

static int fnReadHdfRadarHow(hid_t hGroup, HDF_HOW *pHow, int iHdfType)
{
    if(fnReadHdfRadarGeneralHow(hGroup, &(pHow->m_general_how)) == FALSE)
        return FALSE;

    if(fnReadHdfRadarRadarHow(hGroup, &(pHow->m_radar_how)) == FALSE)
        return FALSE;

    switch(iHdfType)
    {
        case HDF_EN_R_TYPE_POLAR:
        {
            if(fnReadHdfRadarPolarHow(hGroup, &(pHow->m_polar_how)) == FALSE)
                return FALSE;
        }
        break;
        case HDF_EN_R_TYPE_IMAGE:
        {
            if(fnReadHdfRadarImageHow(hGroup, &(pHow->m_image_how)) == FALSE)
                return FALSE;
        }
        break;
        case HDF_EN_R_TYPE_CROSS:
        {
        }
        break;
        case HDF_EN_R_TYPE_VERTICAL:
        {
            if(fnReadHdfRadarVerticalHow(hGroup, &(pHow->m_vertical_how)) == FALSE)
                return FALSE;
        }
        break;
    }

    if(fnReadHdfRadarQualityHow(hGroup, &(pHow->m_quality_how)) == FALSE)
        return FALSE;
    
    return TRUE;
}

static float** fnReadHdfRadarDataChar(hid_t hData, int iYdim, int iXdim, hid_t hMemType, char *szMemStr, HDF_DATASET_WHAT what)
{
    float               **ppData    = NULL;
    char                *pBuf       = NULL;
    int                 iBufIdx     = 0;
    int                 iYIdx       = 0;
    int                 iXIdx       = 0;

    if(hData < 0)
        return NULL;

    if((pBuf = (char *)calloc(1, sizeof(char)*iYdim*iXdim)) == NULL)
        return NULL;
    
    if((ppData = fnMakeMatrix2D_F(iYdim, iXdim)) == NULL)
    {
        free(pBuf);
        return NULL;
    }

    if(H5Dread(hData, hMemType, H5S_ALL, H5S_ALL, H5P_DEFAULT, pBuf) < 0)
    {
        fnFreeMatrix2D((void **)ppData, iYdim);
        free(pBuf);
        return NULL;
    }

    iBufIdx = 0;
    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            if(fabs(pBuf[iBufIdx] - what.m_dNodata) < RDR_DF_ERR_RANGE_D)
                ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
            else if(fabs(pBuf[iBufIdx] - what.m_dUndetect) < RDR_DF_ERR_RANGE_D)
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
            else
                ppData[iYIdx][iXIdx] = (float)((pBuf[iBufIdx]*what.m_dGain)+what.m_dOffset);

            iBufIdx++;
        }
    }

    free(pBuf);

    return ppData;
}

static float** fnReadHdfRadarDataUChar(hid_t hData, int iYdim, int iXdim, hid_t hMemType, char *szMemStr, HDF_DATASET_WHAT what)
{
    float               **ppData    = NULL;
    unsigned char       *pBuf       = NULL;
    int                 iBufIdx     = 0;
    int                 iYIdx       = 0;
    int                 iXIdx       = 0;

    if(hData < 0)
        return NULL;

    if((pBuf = (unsigned char *)calloc(1, sizeof(unsigned char)*iYdim*iXdim)) == NULL)
        return NULL;
    
    if((ppData = fnMakeMatrix2D_F(iYdim, iXdim)) == NULL)
    {
        free(pBuf);
        return NULL;
    }

    if(H5Dread(hData, hMemType, H5S_ALL, H5S_ALL, H5P_DEFAULT, pBuf) < 0)
    {
        fnFreeMatrix2D((void **)ppData, iYdim);
        free(pBuf);
        return NULL;
    }

    iBufIdx = 0;
    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            if(fabs(pBuf[iBufIdx] - what.m_dNodata) < RDR_DF_ERR_RANGE_D)
                ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
            else if(fabs(pBuf[iBufIdx] - what.m_dUndetect) < RDR_DF_ERR_RANGE_D)
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
            else
                ppData[iYIdx][iXIdx] = (float)((pBuf[iBufIdx]*what.m_dGain)+what.m_dOffset);

            iBufIdx++;
        }
    }

    free(pBuf);

    return ppData;
}

static float** fnReadHdfRadarDataShort(hid_t hData, int iYdim, int iXdim, hid_t hMemType, char *szMemStr, HDF_DATASET_WHAT what)
{
    float               **ppData    = NULL;
    short               *pBuf       = NULL;
    int                 iBufIdx     = 0;
    int                 iYIdx       = 0;
    int                 iXIdx       = 0;

    if(hData < 0)
        return NULL;

    if((pBuf = (short *)calloc(1, sizeof(short)*iYdim*iXdim)) == NULL)
        return NULL;
    
    if((ppData = fnMakeMatrix2D_F(iYdim, iXdim)) == NULL)
    {
        free(pBuf);
        return NULL;
    }

    if(H5Dread(hData, hMemType, H5S_ALL, H5S_ALL, H5P_DEFAULT, pBuf) < 0)
    {
        fnFreeMatrix2D((void **)ppData, iYdim);
        free(pBuf);
        return NULL;
    }

    if(fnIsLittleEndian() == TRUE)
    {
        if(!strcmp(szMemStr, "H5T_STD_I16BE"))
        {
            for(iBufIdx = 0; iBufIdx < iYdim*iXdim; iBufIdx++)
                fnSwap2Byte(&pBuf[iBufIdx]);
        }
    }
    else
    {
        if(!strcmp(szMemStr, "H5T_STD_I16LE"))
        {
            for(iBufIdx = 0; iBufIdx < iYdim*iXdim; iBufIdx++)
                fnSwap2Byte(&pBuf[iBufIdx]);
        }
    }

    iBufIdx = 0;
    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            if(fabs(pBuf[iBufIdx] - what.m_dNodata) < RDR_DF_ERR_RANGE_D)
                ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
            else if(fabs(pBuf[iBufIdx] - what.m_dUndetect) < RDR_DF_ERR_RANGE_D)
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
            else
                ppData[iYIdx][iXIdx] = (float)((pBuf[iBufIdx]*what.m_dGain)+what.m_dOffset);

            iBufIdx++;
        }
    }

    free(pBuf);

    return ppData;
}

static float** fnReadHdfRadarDataUShort(hid_t hData, int iYdim, int iXdim, hid_t hMemType, char *szMemStr, HDF_DATASET_WHAT what)
{
    float               **ppData    = NULL;
    unsigned short      *pBuf       = NULL;
    int                 iBufIdx     = 0;
    int                 iYIdx       = 0;
    int                 iXIdx       = 0;

    if(hData < 0)
        return NULL;

    if((pBuf = (unsigned short *)calloc(1, sizeof(unsigned short)*iYdim*iXdim)) == NULL)
        return NULL;
    
    if((ppData = fnMakeMatrix2D_F(iYdim, iXdim)) == NULL)
    {
        free(pBuf);
        return NULL;
    }

    if(H5Dread(hData, hMemType, H5S_ALL, H5S_ALL, H5P_DEFAULT, pBuf) < 0)
    {
        fnFreeMatrix2D((void **)ppData, iYdim);
        free(pBuf);
        return NULL;
    }

    if(fnIsLittleEndian() == TRUE)
    {
        if(!strcmp(szMemStr, "H5T_STD_U16BE"))
        {
            for(iBufIdx = 0; iBufIdx < iYdim*iXdim; iBufIdx++)
                fnSwap2Byte(&pBuf[iBufIdx]);
        }
    }
    else
    {
        if(!strcmp(szMemStr, "H5T_STD_U16LE"))
        {
            for(iBufIdx = 0; iBufIdx < iYdim*iXdim; iBufIdx++)
                fnSwap2Byte(&pBuf[iBufIdx]);
        }
    }

    iBufIdx = 0;
    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            if(fabs(pBuf[iBufIdx] - what.m_dNodata) < RDR_DF_ERR_RANGE_D)
                ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
            else if(fabs(pBuf[iBufIdx] - what.m_dUndetect) < RDR_DF_ERR_RANGE_D)
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
            else
                ppData[iYIdx][iXIdx] = (float)((pBuf[iBufIdx]*what.m_dGain)+what.m_dOffset);

            iBufIdx++;
        }
    }

    free(pBuf);

    return ppData;
}

static float** fnReadHdfRadarDataInt(hid_t hData, int iYdim, int iXdim, hid_t hMemType, char *szMemStr, HDF_DATASET_WHAT what)
{
    float               **ppData    = NULL;
    int                 *pBuf       = NULL;
    int                 iBufIdx     = 0;
    int                 iYIdx       = 0;
    int                 iXIdx       = 0;

    if(hData < 0)
        return NULL;

    if((pBuf = (int *)calloc(1, sizeof(int)*iYdim*iXdim)) == NULL)
        return NULL;
    
    if((ppData = fnMakeMatrix2D_F(iYdim, iXdim)) == NULL)
    {
        free(pBuf);
        return NULL;
    }

    if(H5Dread(hData, hMemType, H5S_ALL, H5S_ALL, H5P_DEFAULT, pBuf) < 0)
    {
        fnFreeMatrix2D((void **)ppData, iYdim);
        free(pBuf);
        return NULL;
    }

    if(fnIsLittleEndian() == TRUE)
    {
        if(!strcmp(szMemStr, "H5T_STD_I32BE"))
        {
            for(iBufIdx = 0; iBufIdx < iYdim*iXdim; iBufIdx++)
                fnSwap2Byte(&pBuf[iBufIdx]);
        }
    }
    else
    {
        if(!strcmp(szMemStr, "H5T_STD_I32LE"))
        {
            for(iBufIdx = 0; iBufIdx < iYdim*iXdim; iBufIdx++)
                fnSwap2Byte(&pBuf[iBufIdx]);
        }
    }

    iBufIdx = 0;
    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            if(fabs(pBuf[iBufIdx] - what.m_dNodata) < RDR_DF_ERR_RANGE_D)
                ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
            else if(fabs(pBuf[iBufIdx] - what.m_dUndetect) < RDR_DF_ERR_RANGE_D)
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
            else
                ppData[iYIdx][iXIdx] = (float)((pBuf[iBufIdx]*what.m_dGain)+what.m_dOffset);

            iBufIdx++;
        }
    }

    free(pBuf);

    return ppData;
}

static float** fnReadHdfRadarDataUInt(hid_t hData, int iYdim, int iXdim, hid_t hMemType, char *szMemStr, HDF_DATASET_WHAT what)
{
    float               **ppData    = NULL;
    unsigned  int       *pBuf       = NULL;
    int                 iBufIdx     = 0;
    int                 iYIdx       = 0;
    int                 iXIdx       = 0;

    if(hData < 0)
        return NULL;

    if((pBuf = (unsigned int *)calloc(1, sizeof(unsigned int)*iYdim*iXdim)) == NULL)
        return NULL;
    
    if((ppData = fnMakeMatrix2D_F(iYdim, iXdim)) == NULL)
    {
        free(pBuf);
        return NULL;
    }

    if(H5Dread(hData, hMemType, H5S_ALL, H5S_ALL, H5P_DEFAULT, pBuf) < 0)
    {
        fnFreeMatrix2D((void **)ppData, iYdim);
        free(pBuf);
        return NULL;
    }

    if(fnIsLittleEndian() == TRUE)
    {
        if(!strcmp(szMemStr, "H5T_STD_U32BE"))
        {
            for(iBufIdx = 0; iBufIdx < iYdim*iXdim; iBufIdx++)
                fnSwap2Byte(&pBuf[iBufIdx]);
        }
    }
    else
    {
        if(!strcmp(szMemStr, "H5T_STD_U32LE"))
        {
            for(iBufIdx = 0; iBufIdx < iYdim*iXdim; iBufIdx++)
                fnSwap2Byte(&pBuf[iBufIdx]);
        }
    }

    iBufIdx = 0;
    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            if(fabs(pBuf[iBufIdx] - what.m_dNodata) < RDR_DF_ERR_RANGE_D)
                ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
            else if(fabs(pBuf[iBufIdx] - what.m_dUndetect) < RDR_DF_ERR_RANGE_D)
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
            else
                ppData[iYIdx][iXIdx] = (float)((pBuf[iBufIdx]*what.m_dGain)+what.m_dOffset);

            iBufIdx++;
        }
    }

    free(pBuf);

    return ppData;
}

static float** fnReadHdfRadarDataFloat(hid_t hData, int iYdim, int iXdim, hid_t hMemType, char *szMemStr, HDF_DATASET_WHAT what)
{
    float               **ppData    = NULL;
    float               *pBuf       = NULL;
    int                 iBufIdx     = 0;
    int                 iYIdx       = 0;
    int                 iXIdx       = 0;

    if(hData < 0)
        return NULL;

    if((pBuf = (float *)calloc(1, sizeof(float)*iYdim*iXdim)) == NULL)
        return NULL;
    
    if((ppData = fnMakeMatrix2D_F(iYdim, iXdim)) == NULL)
    {
        free(pBuf);
        return NULL;
    }

    if(H5Dread(hData, hMemType, H5S_ALL, H5S_ALL, H5P_DEFAULT, pBuf) < 0)
    {
        fnFreeMatrix2D((void **)ppData, iYdim);
        free(pBuf);
        return NULL;
    }

    if(fnIsLittleEndian() == TRUE)
    {
        if(!strcmp(szMemStr, "H5T_IEEE_F32LE"))
        {
            for(iBufIdx = 0; iBufIdx < iYdim*iXdim; iBufIdx++)
                fnSwap2Byte(&pBuf[iBufIdx]);
        }
    }
    else
    {
        if(!strcmp(szMemStr, "H5T_IEEE_F32BE"))
        {
            for(iBufIdx = 0; iBufIdx < iYdim*iXdim; iBufIdx++)
                fnSwap2Byte(&pBuf[iBufIdx]);
        }
    }

    iBufIdx = 0;
    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            if(fabs(pBuf[iBufIdx] - what.m_dNodata) < RDR_DF_ERR_RANGE_D)
                ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
            else if(fabs(pBuf[iBufIdx] - what.m_dUndetect) < RDR_DF_ERR_RANGE_D)
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
            else
                ppData[iYIdx][iXIdx] = (float)((pBuf[iBufIdx]*what.m_dGain)+what.m_dOffset);

            iBufIdx++;
        }
    }

    free(pBuf);

    return ppData;
}

static float** fnReadHdfRadarDataArray(hid_t hGroup, int iYdim, int iXdim, HDF_DATASET_WHAT what, char *pClassBuf, int iClassBufLen, char *pVersionBuf, int iVersionBufLen)
{
    float               **ppData                                                = NULL;
    hid_t               hData                                                   = -1;
    hid_t               hMemType                                                = -1;
    char                szMemStr[32]                                            = "";
    size_t              nLen                                                    = 0;
    int                 iAttrCnt                                                = 0;
    int                 iAttrIdx                                                = 0;
    char                pAttrBuf[RDR_DF_HDF_ATTR_MAX][RDR_DF_HDF_ATTR_LEN]    = { "", };

    if(hGroup < 0 || iYdim <= 0 || iXdim <= 0 || pClassBuf == NULL || pVersionBuf == NULL)
        return NULL;

    if((hData = H5Dopen1(hGroup, "data")) < 0)
        return NULL;

    iAttrCnt = fnHdfSearchAttr(hData, pAttrBuf);
    for(iAttrIdx = 0; iAttrIdx < iAttrCnt; iAttrIdx++)
    {
        if(!strcmp(pAttrBuf[iAttrIdx], "CLASS"))
        {
            fnHdfReadAttr(hData, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR,   
                          pClassBuf, iClassBufLen);
        }
        else if(!strcmp(pAttrBuf[iAttrIdx], "IMAGE_VERSION"))
        {
            fnHdfReadAttr(hData, pAttrBuf[iAttrIdx], H5T_NATIVE_CHAR,   
                          pVersionBuf, iVersionBufLen);
        }
    }

    if((hMemType = H5Dget_type(hData)) < 0)
    {   H5Gclose(hData); return NULL; }

    nLen = sizeof(szMemStr);
    H5LTdtype_to_text(hMemType, szMemStr, H5LT_DDL, &nLen);

    if(!strcmp(szMemStr, "H5T_STD_I8LE") || !strcmp(szMemStr, "H5T_STD_I8BE"))
    {
        ppData = fnReadHdfRadarDataChar(hData, iYdim, iXdim, hMemType, szMemStr, what);
    }
    else if(!strcmp(szMemStr, "H5T_STD_U8LE") || !strcmp(szMemStr, "H5T_STD_U8BE"))
    {
        ppData = fnReadHdfRadarDataUChar(hData, iYdim, iXdim, hMemType, szMemStr, what);
    }
    else if(!strcmp(szMemStr, "H5T_STD_I16LE") || !strcmp(szMemStr, "H5T_STD_I16BE"))
    {
        ppData = fnReadHdfRadarDataShort(hData, iYdim, iXdim, hMemType, szMemStr, what);
    }
    else if(!strcmp(szMemStr, "H5T_STD_U16LE") || !strcmp(szMemStr, "H5T_STD_U16LE"))
    {
        ppData = fnReadHdfRadarDataUShort(hData, iYdim, iXdim, hMemType, szMemStr, what);
    }
    else if(!strcmp(szMemStr, "H5T_STD_I32LE") || !strcmp(szMemStr, "H5T_STD_I32LE"))
    {
        ppData = fnReadHdfRadarDataInt(hData, iYdim, iXdim, hMemType, szMemStr, what);
    }
    else if(!strcmp(szMemStr, "H5T_STD_U32LE") || !strcmp(szMemStr, "H5T_STD_U32BE"))
    {
        ppData = fnReadHdfRadarDataUInt(hData, iYdim, iXdim, hMemType, szMemStr, what);
    }
    else if(!strcmp(szMemStr, "H5T_IEEE_F32LE") || !strcmp(szMemStr, "H5T_IEEE_F32BE"))
    {
        ppData = fnReadHdfRadarDataFloat(hData, iYdim, iXdim, hMemType, szMemStr, what);
    }
    else
    {
        fprintf(stderr, "%s : unknown mem_type\n", __func__);
    }

    H5Dclose(hData);

    return ppData;
}

static int fnReadHdfRadarDataQuality(hid_t hData, char *szQuality, HDF_DATA *pData, int iHdfType)
{
    hid_t               hQual                                                   = -1;
    int                 iReadWhat                                               = FALSE;
    int                 iReadWhere                                              = FALSE;
    int                 iReadHow                                                = FALSE;
    int                 iCurQual                                                = 0;
    HDF_DATA_QUALITY    *pDataQual                                              = NULL;
    int                 iYdim                                                   = 0;
    int                 iXdim                                                   = 0;
    int                 iObjCnt                                                 = 0;
    int                 iObjIdx                                                 = 0;
    char                objBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN]  = { "", };

    if(hData < 0 || szQuality == NULL || pData == NULL)
        return FALSE;

    iCurQual = atoi(&szQuality[strlen("quality")]) - 1;
    if(iCurQual >= pData->m_iMaxQuality)
        return FALSE;

    pDataQual = pData->m_ppQuality[iCurQual];
    if(pDataQual == NULL)
        return FALSE;

    if((hQual = H5Gopen1(hData, szQuality)) < 0)
        return FALSE;

    if((iObjCnt = fnHdfSearchGroup(hQual, objBuf)) < 0)
    {   H5Gclose(hQual); return FALSE; }

    for(iObjIdx = 0; iObjIdx < iObjCnt; iObjIdx++)
    {
        if(!strncmp(objBuf[iObjIdx], "what", strlen("what")))
        {
            if(fnReadHdfRadarDsetWhat(hQual, &pDataQual->m_what) == FALSE)
            {   H5Gclose(hQual); return FALSE; }
            else
                iReadWhat = TRUE;
        }
        else if(!strncmp(objBuf[iObjIdx], "where", strlen("where")))
        {
            if(fnReadHdfRadarWhere(hQual, &(pDataQual->m_where), iHdfType) == FALSE) 
            {   H5Gclose(hQual); return FALSE; }
            else
                iReadWhere = TRUE;
        }
        else if(!strncmp(objBuf[iObjIdx], "how", strlen("how")))
        {
            if(fnReadHdfRadarHow(hQual, &(pDataQual->m_how), iHdfType) == FALSE) 
            {   H5Gclose(hQual); return FALSE; }
            else
                iReadHow = TRUE;
        }
    }

    if(iReadWhat == FALSE)
        pDataQual->m_what = pData->m_what;

    if(iReadWhere == FALSE)
        pDataQual->m_where = pData->m_where;

    if(iReadHow == FALSE)
        pDataQual->m_how = pData->m_how;

    switch(iHdfType)
    {
        case HDF_EN_R_TYPE_POLAR:
        {
            iYdim = pDataQual->m_where.m_polar_where.m_nRays;
            iXdim = pDataQual->m_where.m_polar_where.m_nBins;
        }
        break;
        default:
        {
            fprintf(stderr, "%s : unknown hdf5 type\n", __func__);
            H5Gclose(hQual);
            return FALSE;
        }
    }

    for(iObjIdx = 0; iObjIdx < iObjCnt; iObjIdx++)
    {
        if(!strncmp(objBuf[iObjIdx], "data", strlen("data")))
        {
            if((pDataQual->m_ppData = fnReadHdfRadarDataArray(hQual, iYdim, iXdim,  
                                                              pDataQual->m_what, 
                                                              pDataQual->m_szClass, 
                                                              sizeof(pDataQual->m_szClass), 
                                                              pDataQual->m_szVersion,
                                                              sizeof(pDataQual->m_szVersion))) == NULL)
            {   H5Gclose(hQual); return FALSE; }
        }
    }

    H5Gclose(hQual);

    return TRUE;
}

static int fnReadHdfRadarData(hid_t hDataset, char *szData, HDF_DATASET *pDataset, int iHdfType)
{
    hid_t           hData                                                   = -1;
    int             iReadWhat                                               = FALSE;
    int             iReadWhere                                              = FALSE;
    int             iReadHow                                                = FALSE;
    int             iCurData                                                = 0;
    HDF_DATA        *pData                                                  = NULL;
    int             iYdim                                                   = 0;
    int             iXdim                                                   = 0;
    int             iObjCnt                                                 = 0;
    int             iObjIdx                                                 = 0;
    char            objBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN]  = { "", };

    if(hDataset < 0 || szData == NULL || pDataset == NULL)
        return FALSE;

    iCurData = atoi(&szData[strlen("data")]) - 1;
    if(iCurData >= pDataset->m_iMaxData)
        return FALSE;

    pData = pDataset->m_ppData[iCurData];
    if(pData == NULL)
        return FALSE;

    if((hData = H5Gopen1(hDataset, szData)) < 0)
        return FALSE;

    if((iObjCnt = fnHdfSearchGroup(hData, objBuf)) < 0)
    {   H5Gclose(hData); return FALSE; }

    for(iObjIdx = 0; iObjIdx < iObjCnt; iObjIdx++)
    {
        if(!strncmp(objBuf[iObjIdx], "what", strlen("what")))
        {
            if(fnReadHdfRadarDsetWhat(hData, &pData->m_what) == FALSE)
            {   H5Gclose(hData); return FALSE; }
            else
                iReadWhat = TRUE;
        }
        else if(!strncmp(objBuf[iObjIdx], "where", strlen("where")))
        {
            if(fnReadHdfRadarWhere(hData, &(pData->m_where), iHdfType) == FALSE) 
            {   H5Gclose(hData); return FALSE; }
            else
                iReadWhere = TRUE;
        }
        else if(!strncmp(objBuf[iObjIdx], "how", strlen("how")))
        {
            if(fnReadHdfRadarHow(hData, &(pData->m_how), iHdfType) == FALSE) 
            {   H5Gclose(hData); return FALSE; }
            else
                iReadHow = TRUE;
        }
    }

    if(iReadWhat == FALSE)
        pData->m_what = pDataset->m_what;

    if(iReadWhere == FALSE)
        pData->m_where = pDataset->m_where;

    if(iReadHow == FALSE)
        pData->m_how = pDataset->m_how;

    switch(iHdfType)
    {
        case HDF_EN_R_TYPE_POLAR:
        {
            iYdim = pData->m_where.m_polar_where.m_nRays;
            iXdim = pData->m_where.m_polar_where.m_nBins;
        }
        break;
        default:
        {
            fprintf(stderr, "%s : unknown hdf5 type\n", __func__);
            H5Gclose(hData);
            return FALSE;
        }
    }

    for(iObjIdx = 0; iObjIdx < iObjCnt; iObjIdx++)
    {
        if(!strncmp(objBuf[iObjIdx], "data", strlen("data")))
        {
            if((pData->m_ppData = fnReadHdfRadarDataArray(hData, iYdim, iXdim, 
                                                          pData->m_what, 
                                                          pData->m_szClass, 
                                                          sizeof(pData->m_szClass),
                                                          pData->m_szVersion,
                                                          sizeof(pData->m_szVersion))) == NULL)
            {   H5Gclose(hData); return FALSE; }
        }
        else if(!strncmp(objBuf[iObjIdx], "quality", strlen("quality")))
        {
            if(fnReadHdfRadarDataQuality(hData, objBuf[iObjIdx], pData, iHdfType) == FALSE) 
            {   H5Gclose(hData); return FALSE; }
        }
    }

    H5Gclose(hData);

    return TRUE;
}

static int fnReadHdfRadarDsetQuality(hid_t hDataset, char *szQuality, HDF_DATASET *pDataset, int iHdfType)
{
    hid_t               hQual                                                   = -1;
    int                 iReadWhat                                               = FALSE;
    int                 iReadWhere                                              = FALSE;
    int                 iReadHow                                                = FALSE;
    int                 iCurQual                                                = 0;
    HDF_DATASET_QUALITY *pDsetQual                                              = NULL;
    int                 iYdim                                                   = 0;
    int                 iXdim                                                   = 0;
    int                 iObjCnt                                                 = 0;
    int                 iObjIdx                                                 = 0;
    char                objBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN]  = { "", };

    if(hDataset < 0 || szQuality == NULL || pDataset == NULL)
        return FALSE;

    iCurQual = atoi(&szQuality[strlen("quality")]) - 1;
    if(iCurQual >= pDataset->m_iMaxQuality)
        return FALSE;

    pDsetQual = pDataset->m_ppQuality[iCurQual];
    if(pDsetQual == NULL)
        return FALSE;

    if((hQual = H5Gopen1(hDataset, szQuality)) < 0)
        return FALSE;

    if((iObjCnt = fnHdfSearchGroup(hQual, objBuf)) < 0)
    {   H5Gclose(hQual); return FALSE; }

    for(iObjIdx = 0; iObjIdx < iObjCnt; iObjIdx++)
    {
        if(!strncmp(objBuf[iObjIdx], "what", strlen("what")))
        {
            if(fnReadHdfRadarDsetWhat(hQual, &pDsetQual->m_what) == FALSE)
            {   H5Gclose(hQual); return FALSE; }
            else
                iReadWhat = TRUE;
        }
        else if(!strncmp(objBuf[iObjIdx], "where", strlen("where")))
        {
            if(fnReadHdfRadarWhere(hQual, &(pDsetQual->m_where), iHdfType) == FALSE) 
            {   H5Gclose(hQual); return FALSE; }
            else
                iReadWhere = TRUE;
        }
        else if(!strncmp(objBuf[iObjIdx], "how", strlen("how")))
        {
            if(fnReadHdfRadarHow(hQual, &(pDsetQual->m_how), iHdfType) == FALSE) 
            {   H5Gclose(hQual); return FALSE; }
            else
                iReadHow = TRUE;
        }
    }

    if(iReadWhat == FALSE)
        pDsetQual->m_what = pDataset->m_what;

    if(iReadWhere == FALSE)
        pDsetQual->m_where = pDataset->m_where;

    if(iReadHow == FALSE)
        pDsetQual->m_how = pDataset->m_how;

    switch(iHdfType)
    {
        case HDF_EN_R_TYPE_POLAR:
        {
            iYdim = pDsetQual->m_where.m_polar_where.m_nRays;
            iXdim = pDsetQual->m_where.m_polar_where.m_nBins;
        }
        break;
        default:
        {
            fprintf(stderr, "%s : unknown hdf5 type\n", __func__);
            return FALSE;
        }
    }

    for(iObjIdx = 0; iObjIdx < iObjCnt; iObjIdx++)
    {
        if(!strncmp(objBuf[iObjIdx], "data", strlen("data")))
        {
            if((pDsetQual->m_ppData = fnReadHdfRadarDataArray(hQual, iYdim, iXdim, 
                                                              pDsetQual->m_what, 
                                                              pDsetQual->m_szClass, 
                                                              sizeof(pDsetQual->m_szClass), 
                                                              pDsetQual->m_szVersion,
                                                              sizeof(pDsetQual->m_szVersion))) == NULL)
            {   H5Gclose(hQual); return FALSE; }
        }
    }

    H5Gclose(hQual);

    return TRUE;
}

static int fnReadHdfRadarDataset(hid_t hRoot, char* szDataset, HDF_RADAR *pHdf, int iHdfType)
{
    hid_t           hDataset                                                = -1;
    int             iReadWhat                                               = FALSE;
    int             iReadWhere                                              = FALSE;
    int             iReadHow                                                = FALSE;
    int             iCurDset                                                = 0;
    HDF_DATASET     *pDataset                                               = NULL;
    int             iObjCnt                                                 = 0;
    int             iObjIdx                                                 = 0;
    char            objBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN]  = { "", };

    if(hRoot < 0 || szDataset == NULL || pHdf == NULL)
        return FALSE;

    iCurDset = atoi(&szDataset[strlen("dataset")]) - 1;
    if(iCurDset >= pHdf->m_iMaxDataset)
        return FALSE;

    pDataset = pHdf->m_ppDataset[iCurDset];
    if(pDataset == NULL)
        return FALSE;

    if((hDataset = H5Gopen1(hRoot, szDataset)) < 0)
        return FALSE;

    if((iObjCnt = fnHdfSearchGroup(hDataset, objBuf)) < 0)
    {   H5Gclose(hDataset); return FALSE; }

    for(iObjIdx = 0; iObjIdx < iObjCnt; iObjIdx++)
    {
        if(!strncmp(objBuf[iObjIdx], "what", strlen("what")))
        {
            if(fnReadHdfRadarDsetWhat(hDataset, &pDataset->m_what) == FALSE)
            {   H5Gclose(hDataset); return FALSE; }
            else
                iReadWhat = TRUE;
        }
        else if(!strncmp(objBuf[iObjIdx], "where", strlen("where")))
        {
            if(fnReadHdfRadarWhere(hDataset, &(pDataset->m_where), iHdfType) == FALSE) 
            {   H5Gclose(hDataset); return FALSE; }
            else 
                iReadWhere = TRUE;
        }
        else if(!strncmp(objBuf[iObjIdx], "how", strlen("how")))
        {
            if(fnReadHdfRadarHow(hDataset, &(pDataset->m_how), iHdfType) == FALSE) 
            {   H5Gclose(hDataset); return FALSE; }
            else
                iReadHow = TRUE;
        }
    }
    
    if(iReadWhere == FALSE)
        pDataset->m_where = pHdf->m_where;

    if(iReadHow == FALSE)
        pDataset->m_how = pHdf->m_how;

    for(iObjIdx = 0; iObjIdx < iObjCnt; iObjIdx++)
    {
        if(!strncmp(objBuf[iObjIdx], "data", strlen("data")))
        {
            if(fnReadHdfRadarData(hDataset, objBuf[iObjIdx], pDataset, iHdfType) == FALSE)
            {   H5Gclose(hDataset); return FALSE; }
        }
        else if(!strncmp(objBuf[iObjIdx], "quality", strlen("quality")))
        {
            if(fnReadHdfRadarDsetQuality(hDataset, objBuf[iObjIdx], pDataset, iHdfType) == FALSE)
            {   H5Gclose(hDataset); return FALSE; }
        }
    }

    H5Gclose(hDataset);

    return TRUE;
}

static int fnReadHdfRadarRoot(hid_t hRoot, HDF_RADAR *pHdf, int iHdfType)
{
    int         iRootObjCnt                                                 = 0;
    int         iRootObjIdx                                                 = 0;
    char        rootObjBuf[RDR_DF_HDF_OBJECT_MAX][RDR_DF_HDF_OBEJCT_LEN]  = { "", };

    if(hRoot < 0 || pHdf == NULL)
        return FALSE;

    fnHdfReadAttr(hRoot, "Conventions", H5T_NATIVE_CHAR,
                   pHdf->m_szConventions, sizeof(pHdf->m_szConventions));

    if((iRootObjCnt = fnHdfSearchGroup(hRoot, rootObjBuf)) < 0)
        return FALSE;

    fnInsertionSortRootGroup(iRootObjCnt, rootObjBuf);

    for(iRootObjIdx = 0; iRootObjIdx < iRootObjCnt; iRootObjIdx++)
    {
        if(!strncmp(rootObjBuf[iRootObjIdx], "what", strlen("what")))
        {
            if(fnReadHdfRadarTopWhat(hRoot, pHdf) == FALSE)
                return FALSE;
        }
        else if(!strncmp(rootObjBuf[iRootObjIdx], "where", strlen("where")))
        {
            if(fnReadHdfRadarWhere(hRoot, &(pHdf->m_where), iHdfType) == FALSE) 
                return FALSE;
        }
        else if(!strncmp(rootObjBuf[iRootObjIdx], "how", strlen("how")))
        {
            if(fnReadHdfRadarHow(hRoot, &(pHdf->m_how), iHdfType) == FALSE) 
                return FALSE;
        }
    }

    for(iRootObjIdx = 0; iRootObjIdx < iRootObjCnt; iRootObjIdx++)
    {
        if(!strncmp(rootObjBuf[iRootObjIdx], "dataset", strlen("dataset")))
        {
            if(fnReadHdfRadarDataset(hRoot, rootObjBuf[iRootObjIdx], pHdf, iHdfType) == FALSE)
                return FALSE;
        }
    }

    return TRUE;
}

/* ================================================================================ */
// Function

HDF_RADAR* fnInitHdfRadar(int iMaxDataset, int iMaxData, int iMaxDsetQuality, int iMaxDataQuality)
{
    HDF_RADAR               *pHdf       = NULL;
    HDF_DATASET             *pHdfDset   = NULL;
    HDF_DATA                *pHdfData   = NULL;
    int                     iDsetIdx    = 0;
    int                     iDataIdx    = 0;
    int                     iDsetQIdx   = 0;
    int                     iDataQIdx   = 0;

    if((pHdf = (HDF_RADAR *)calloc(1, sizeof(HDF_RADAR))) == NULL)
        return NULL;

    pHdf->m_iMaxDataset = iMaxDataset;
    if((pHdf->m_ppDataset = (HDF_DATASET **)calloc(iMaxDataset, sizeof(HDF_DATASET *))) == NULL)
    {   fnFreeHdfRadar(pHdf); return NULL; }

    for(iDsetIdx = 0; iDsetIdx < iMaxDataset; iDsetIdx++)
    {
        if((pHdf->m_ppDataset[iDsetIdx] = (HDF_DATASET *)calloc(1, sizeof(HDF_DATASET))) == NULL)
        {   fnFreeHdfRadar(pHdf); return NULL; }

        pHdfDset = pHdf->m_ppDataset[iDsetIdx];

        pHdfDset->m_iMaxData = iMaxData;
        if((pHdfDset->m_ppData = (HDF_DATA **)calloc(iMaxData, sizeof(HDF_DATA *))) == NULL)
        {   fnFreeHdfRadar(pHdf); return NULL; }

        for(iDataIdx = 0; iDataIdx < iMaxData; iDataIdx++)
        {
            if((pHdfDset->m_ppData[iDataIdx] = (HDF_DATA *)calloc(1, sizeof(HDF_DATA))) == NULL)
            {   fnFreeHdfRadar(pHdf); return NULL; }

            pHdfData = pHdfDset->m_ppData[iDataIdx];

            if(iMaxDataQuality > 0)
            {
                pHdfData->m_iMaxQuality = iMaxDataQuality;
                pHdfData->m_ppQuality 
                = (HDF_DATA_QUALITY **)calloc(iMaxDataQuality, sizeof(HDF_DATA_QUALITY *));
                if(pHdfData->m_ppQuality == NULL)
                {   fnFreeHdfRadar(pHdf); return NULL; }

                for(iDataQIdx = 0; iDataQIdx < iMaxDataQuality; iDataQIdx++)
                {
                    pHdfData->m_ppQuality[iDataQIdx] 
                    = (HDF_DATA_QUALITY *)calloc(1, sizeof(HDF_DATA_QUALITY));
                    if(pHdfData->m_ppQuality[iDataQIdx] == NULL)
                    {   fnFreeHdfRadar(pHdf); return NULL; }
                }
            }
        }

        if( iMaxDsetQuality > 0)
        {
            pHdfDset->m_iMaxQuality = iMaxDsetQuality;
            pHdfDset->m_ppQuality 
            = (HDF_DATASET_QUALITY **)calloc(iMaxDsetQuality, sizeof(HDF_DATASET_QUALITY *));
            if(pHdfDset->m_ppQuality == NULL)
            {   fnFreeHdfRadar(pHdf); return NULL; }

            for(iDsetQIdx = 0; iDsetQIdx < iMaxDsetQuality; iDsetQIdx++)
            {
                pHdfDset->m_ppQuality[iDsetQIdx] 
                = (HDF_DATASET_QUALITY *)calloc(1, sizeof(HDF_DATASET_QUALITY));
                if(pHdfDset->m_ppQuality[iDsetQIdx] == NULL)
                {   fnFreeHdfRadar(pHdf); return NULL; }
            }
        }
    }

    return pHdf;
}

HDF_PRODUCT* fnLoadHdfProduct(char* szFile, char* szProduct, char* szFieldName)
{
#define FN_LOAD_HDF_PRODUCT_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(hRoot        >= 0   ) { H5Gclose(hRoot); } \
    if(hFile        >= 0   ) { H5Fclose(hFile); } \
    if(pHdfProduct != NULL) { fnFreeHdfProduct(pHdfProduct); }

    HDF_PRODUCT     *pHdfProduct   = NULL;     // VARIABLE
    hid_t           hFile           = -1;
    hid_t           hRoot           = -1;
    int             iMaxPpi         = 0;        // VARIABLE
    int             iMaxCappi       = 0;        // VARIABLE
    int             iMaxBase        = 0;        // VARIABLE
    int             iMaxCmax        = 0;        // VARIABLE
    int             iMaxVil         = 0;        // VARIABLE
    int             iMaxEtop        = 0;        // VARIABLE
    int             iMaxField       = 0;        // VARIABLE

    if(szFile == NULL)
        return NULL;

    if((hFile = H5Fopen(szFile, H5F_ACC_RDONLY, H5P_DEFAULT)) < 0)
    {   FN_LOAD_HDF_PRODUCT_ERROR("H5Fopen fail"); return NULL; }

    if((hRoot = H5Gopen1(hFile, "/")) < 0)
    {   FN_LOAD_HDF_PRODUCT_ERROR("H5Gopen1 fail"); return NULL; }

    if(fnGetMaxHdfProduct(hRoot, &iMaxPpi, &iMaxCappi, &iMaxBase, &iMaxCmax, 
                                  &iMaxVil, &iMaxEtop, &iMaxField) == FALSE)
    {   FN_LOAD_HDF_PRODUCT_ERROR("fnGetMaxHdfProduct fail"); return NULL; }

    if(szProduct != NULL && !strcmp(szProduct, "PPI"))
    {   iMaxCappi = iMaxBase = iMaxCmax = iMaxVil = iMaxEtop = 0; }
    else if(szProduct != NULL && !strcmp(szProduct, "CAPPI"))
    {   iMaxPpi = iMaxBase = iMaxCmax = iMaxVil = iMaxEtop = 0; }
    else if(szProduct != NULL && !strcmp(szProduct, "BASE"))
    {   iMaxPpi = iMaxCappi = iMaxCmax = iMaxVil = iMaxEtop = 0; }
    else if(szProduct != NULL && !strcmp(szProduct, "CMAX"))
    {   iMaxPpi = iMaxCappi = iMaxBase = iMaxVil = iMaxEtop = 0; }
    else if(szProduct != NULL && !strcmp(szProduct, "VIL"))
    {   iMaxPpi = iMaxCappi = iMaxBase = iMaxCmax = iMaxEtop = 0; }
    else if(szProduct != NULL && !strcmp(szProduct, "ETOP"))
    {   iMaxPpi = iMaxCappi = iMaxBase = iMaxCmax = iMaxVil = 0; }
    else if(szProduct != NULL)
    {   FN_LOAD_HDF_PRODUCT_ERROR("unkwon product"); return NULL; }

    if(szFieldName != NULL && iMaxField > 0)
        iMaxField = 1;

    pHdfProduct = fnInitHdfProduct(iMaxField, iMaxPpi, iMaxCappi, 
                                     iMaxBase, iMaxCmax, iMaxVil, iMaxEtop);
    if(pHdfProduct == NULL)
    {   FN_LOAD_HDF_PRODUCT_ERROR("fnInitHdfProduct fail"); return NULL; }

    if(fnReadHdfProductRoot(hRoot, pHdfProduct, szFieldName) == FALSE)
    {   FN_LOAD_HDF_PRODUCT_ERROR("fnReadHdfProductRoot fail"); return NULL; }

    H5Gclose(hRoot);
    H5Fclose(hFile);

    return pHdfProduct;
}

HDF_PRODUCT* fnLoadHdfProductByIdx(char* szFile, char* szProduct, int iProductIdx, char* szFieldName)
{
#define FN_LOAD_HDF_PRODUCT_BY_IDX_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(hRoot        >= 0   ) { H5Gclose(hRoot); } \
    if(hFile        >= 0   ) { H5Fclose(hFile); } \
    if(pHdfProduct != NULL) { fnFreeHdfProduct(pHdfProduct); }

    HDF_PRODUCT     *pHdfProduct   = NULL;     // VARIABLE
    hid_t           hFile           = -1;
    hid_t           hRoot           = -1;
    int             iMaxPpi         = 0;        // VARIABLE
    int             iMaxCappi       = 0;        // VARIABLE
    int             iMaxBase        = 0;        // VARIABLE
    int             iMaxCmax        = 0;        // VARIABLE
    int             iMaxVil         = 0;        // VARIABLE
    int             iMaxEtop        = 0;        // VARIABLE
    int             iMaxField       = 0;        // VARIABLE

    if(szFile == NULL || szProduct == NULL)
        return NULL;

    if((hFile = H5Fopen(szFile, H5F_ACC_RDONLY, H5P_DEFAULT)) < 0)
    {   FN_LOAD_HDF_PRODUCT_BY_IDX_ERROR("H5Fopen fail"); return NULL; }

    if((hRoot = H5Gopen1(hFile, "/")) < 0)
    {   FN_LOAD_HDF_PRODUCT_BY_IDX_ERROR("H5Gopen1 fail"); return NULL; }

    if(fnGetMaxHdfProduct(hRoot, &iMaxPpi, &iMaxCappi, &iMaxBase, &iMaxCmax, 
                                  &iMaxVil, &iMaxEtop, &iMaxField) == FALSE)
    {   FN_LOAD_HDF_PRODUCT_BY_IDX_ERROR("fnGetMaxHdfProduct fail"); return NULL; }

    if(szProduct != NULL && !strcmp(szProduct, "PPI"))
    {   iMaxCappi = iMaxBase = iMaxCmax = iMaxVil = iMaxEtop = 0; }
    else if(szProduct != NULL && !strcmp(szProduct, "CAPPI"))
    {   iMaxPpi = iMaxBase = iMaxCmax = iMaxVil = iMaxEtop = 0; }
    else if(szProduct != NULL && !strcmp(szProduct, "BASE"))
    {   iMaxPpi = iMaxCappi = iMaxCmax = iMaxVil = iMaxEtop = 0; }
    else if(szProduct != NULL && !strcmp(szProduct, "CMAX"))
    {   iMaxPpi = iMaxCappi = iMaxBase = iMaxVil = iMaxEtop = 0; }
    else if(szProduct != NULL && !strcmp(szProduct, "VIL"))
    {   iMaxPpi = iMaxCappi = iMaxBase = iMaxCmax = iMaxEtop = 0; }
    else if(szProduct != NULL && !strcmp(szProduct, "ETOP"))
    {   iMaxPpi = iMaxCappi = iMaxBase = iMaxCmax = iMaxVil = 0; }
    else if(szProduct != NULL)
    {   FN_LOAD_HDF_PRODUCT_ERROR("unkwon product"); return NULL; }

    if(szFieldName != NULL && iMaxField > 0)
        iMaxField = 1;

    pHdfProduct = fnInitHdfProduct(iMaxField, iMaxPpi, iMaxCappi, iMaxBase, iMaxCmax, iMaxVil, iMaxEtop);
    if(pHdfProduct == NULL)
    {   FN_LOAD_HDF_PRODUCT_BY_IDX_ERROR("fnInitHdfProduct fail"); return NULL; }

    if(fnReadHdfProductRootByIdx(hRoot, pHdfProduct, iProductIdx, szFieldName) == FALSE)
    {   FN_LOAD_HDF_PRODUCT_BY_IDX_ERROR("fnReadHdfProductRootByIdx fail"); return NULL; }

    H5Gclose(hRoot);
    H5Fclose(hFile);

    return pHdfProduct;
}

HDF_PRODUCT* fnLoadHdfProductByArg(char* szFile, char* szProduct, double dProductArg1, double dProductArg2, char* szFieldName)
{
#define FN_LOAD_HDF_PRODUCT_BY_IDX_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(hRoot        >= 0   ) { H5Gclose(hRoot); } \
    if(hFile        >= 0   ) { H5Fclose(hFile); } \
    if(pHdfProduct != NULL) { fnFreeHdfProduct(pHdfProduct); }

    HDF_PRODUCT     *pHdfProduct   = NULL;     // VARIABLE
    hid_t           hFile           = -1;
    hid_t           hRoot           = -1;
    int             iMaxPpi         = 0;        // VARIABLE
    int             iMaxCappi       = 0;        // VARIABLE
    int             iMaxBase        = 0;        // VARIABLE
    int             iMaxCmax        = 0;        // VARIABLE
    int             iMaxVil         = 0;        // VARIABLE
    int             iMaxEtop        = 0;        // VARIABLE
    int             iMaxField       = 0;        // VARIABLE

    if(szFile == NULL || szProduct == NULL)
        return NULL;

    if((hFile = H5Fopen(szFile, H5F_ACC_RDONLY, H5P_DEFAULT)) < 0)
    {   FN_LOAD_HDF_PRODUCT_BY_IDX_ERROR("H5Fopen fail"); return NULL; }

    if((hRoot = H5Gopen1(hFile, "/")) < 0)
    {   FN_LOAD_HDF_PRODUCT_BY_IDX_ERROR("H5Gopen1 fail"); return NULL; }

    if(fnGetMaxHdfProduct(hRoot, &iMaxPpi, &iMaxCappi, &iMaxBase, &iMaxCmax, 
                                  &iMaxVil, &iMaxEtop, &iMaxField) == FALSE)
    {   FN_LOAD_HDF_PRODUCT_BY_IDX_ERROR("fnGetMaxHdfProduct fail"); return NULL; }

    if(!strcmp(szProduct, "PPI") && iMaxPpi > 0)
    {   
        iMaxCappi = iMaxBase = iMaxCmax = iMaxVil = iMaxEtop = 0;
        iMaxPpi = 1;
    }
    else if(!strcmp(szProduct, "CAPPI") && iMaxCappi > 0)
    {   
        iMaxPpi = iMaxBase = iMaxCmax = iMaxVil = iMaxEtop = 0;
        iMaxCappi = 1;
    }
    else if(!strcmp(szProduct, "BASE") && iMaxBase > 0)
    {   
        iMaxPpi = iMaxCappi = iMaxCmax = iMaxVil = iMaxEtop = 0; 
        iMaxBase = 1;
    }
    else if(!strcmp(szProduct, "CMAX") && iMaxCmax > 0)
    {   
        iMaxPpi = iMaxCappi = iMaxBase = iMaxVil = iMaxEtop = 0;
        iMaxCmax = 1;
    }
    else if(!strcmp(szProduct, "VIL") && iMaxVil > 0)
    {   
        iMaxPpi = iMaxCappi = iMaxBase = iMaxCmax = iMaxEtop = 0; 
        iMaxVil = 1;
    }
    else if(!strcmp(szProduct, "ETOP") && iMaxEtop > 0)
    {   
        iMaxPpi = iMaxCappi = iMaxBase = iMaxCmax = iMaxVil = 0; 
        iMaxEtop = 1;
    }
    else
    {   FN_LOAD_HDF_PRODUCT_BY_IDX_ERROR("unkwon product"); return NULL; }

    if(szFieldName != NULL && iMaxField > 0)
        iMaxField = 1;

    pHdfProduct = fnInitHdfProduct(iMaxField, iMaxPpi, iMaxCappi, iMaxBase, iMaxCmax, iMaxVil, iMaxEtop);
    if(pHdfProduct == NULL)
    {   FN_LOAD_HDF_PRODUCT_BY_IDX_ERROR("fnInitHdfProduct fail"); return NULL; }

    if(fnReadHdfProductRootByArg(hRoot, pHdfProduct, dProductArg1, dProductArg2, szFieldName) == FALSE)
    {   FN_LOAD_HDF_PRODUCT_BY_IDX_ERROR("fnReadHdfProductRootByArg fail"); return NULL; }

    H5Gclose(hRoot);
    H5Fclose(hFile);

    return pHdfProduct;
}

HDF_RADAR* fnLoadHdfRadar(char* szFile, int iHdfType)
{
#define FN_LAOD_HDF_RADAR_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(hRoot        >= 0)       { H5Gclose(hRoot); } \
    if(hFile        >= 0)       { H5Fclose(hFile); } \
    if(pHdf    != NULL)    { fnFreeHdfRadar(pHdf); }

    hid_t       hFile           = -1;
    hid_t       hRoot           = -1;
    HDF_RADAR   *pHdf      = NULL;     // VARIABLE
    int         iMaxDataset     = 0;        // VARIABLE
    int         iMaxData        = 0;        // VARIABLE
    int         iMaxDsetQuality = 0;        // VARIABLE
    int         iMaxDataQuality = 0;        // VARIABLE

    if(szFile == NULL)
        return NULL;

    if((hFile = H5Fopen(szFile, H5F_ACC_RDONLY, H5P_DEFAULT)) < 0)
    {   FN_LAOD_HDF_RADAR_ERROR("H5Fopen fail"); return NULL; }

    if((hRoot = H5Gopen1(hFile, "/")) < 0)
    {   FN_LAOD_HDF_RADAR_ERROR("H5Gopen1 fail"); return NULL; }

    if(fnGetMaxHdfRadar(hRoot, &iMaxDataset, &iMaxData, &iMaxDsetQuality, &iMaxDataQuality) == FALSE)
    {   FN_LAOD_HDF_RADAR_ERROR("fnGetMaxHdfRadar fail"); return NULL; }

    if((pHdf = fnInitHdfRadar(iMaxDataset, iMaxData, iMaxDsetQuality, iMaxDataQuality)) == NULL)
    {   FN_LAOD_HDF_RADAR_ERROR("fnInitHdfRadar fail"); return NULL; }

    pHdf->m_iHdfType = iHdfType;

    if((fnReadHdfRadarRoot(hRoot, pHdf, iHdfType)) == FALSE)
    {   FN_LAOD_HDF_RADAR_ERROR("fnReadHdfRadarRoot fail"); return NULL; }

    H5Gclose(hRoot);
    H5Fclose(hFile);

    return pHdf;
}

void fnFreeHdfRadar(HDF_RADAR *pHdf)
{
    int                     iDatasetIdx         = 0;
    int                     iDataIdx            = 0;
    int                     iMaxData            = 0;
    int                     iQualityIdx         = 0;
    int                     iMaxQuality         = 0;
    int                     iYdim               = 0;
    HDF_DATA                *pHdfData           = NULL;
    HDF_DATASET_QUALITY     *pHdfDsetQuality    = NULL;

    if(pHdf != NULL)
    {
        if(pHdf->m_ppDataset != NULL)
        {
            for(iDatasetIdx = 0; iDatasetIdx < pHdf->m_iMaxDataset; iDatasetIdx++)
            {
                if(pHdf->m_ppDataset[iDatasetIdx] != NULL)
                {
                    if(pHdf->m_ppDataset[iDatasetIdx]->m_ppData != NULL)
                    {
                        iMaxData = pHdf->m_ppDataset[iDatasetIdx]->m_iMaxData;
                        for(iDataIdx = 0; iDataIdx < iMaxData; iDataIdx++)
                        {
                            pHdfData = NULL;
                            pHdfData = pHdf->m_ppDataset[iDatasetIdx]->m_ppData[iDataIdx];
                            if(pHdfData != NULL)
                            {
                                if(pHdfData->m_ppData != NULL)
                                {
                                    switch(pHdf->m_iHdfType)
                                    {
                                        case HDF_EN_R_TYPE_POLAR:
                                            iYdim = pHdfData->m_where.m_polar_where.m_nRays;
                                    }
                                    fnFreeMatrix2D((void **)pHdfData->m_ppData, iYdim);
                                }
                                if(pHdfData->m_ppQuality != NULL)
                                {
                                    iMaxQuality = pHdfData->m_iMaxQuality;
                                    for(iQualityIdx = 0; iQualityIdx < iMaxQuality; iQualityIdx++)
                                    {
                                        if(pHdfData->m_ppQuality[iQualityIdx] != NULL)
                                        {
                                            switch(pHdf->m_iHdfType)
                                            {
                                                case HDF_EN_R_TYPE_POLAR:
                                                {
                                                    iYdim = pHdfData->m_ppQuality[iQualityIdx]->
                                                            m_where.m_polar_where.m_nRays;
                                                }
                                            }
                                            fnFreeMatrix2D((void **)pHdfData->
                                                           m_ppQuality[iQualityIdx]->m_ppData, iYdim);
                                        }
                                    }
                                    free(pHdfData->m_ppQuality);
                                }
                                free(pHdfData);
                            }
                        }
                        free(pHdf->m_ppDataset[iDatasetIdx]->m_ppData);
                    }
                    if(pHdf->m_ppDataset[iDatasetIdx]->m_ppQuality != NULL)
                    {
                        iMaxQuality = pHdf->m_ppDataset[iDatasetIdx]->m_iMaxQuality;
                        for(iQualityIdx = 0; iQualityIdx < iMaxQuality; iQualityIdx++)
                        {
                            pHdfDsetQuality = NULL;
                            pHdfDsetQuality = pHdf->m_ppDataset[iDatasetIdx]->m_ppQuality[iQualityIdx];
                            if(pHdfDsetQuality != NULL)
                            {
                                if(pHdfDsetQuality->m_ppData != NULL)
                                {
                                    switch(pHdf->m_iHdfType)
                                    {
                                        case HDF_EN_R_TYPE_POLAR:
                                            iYdim = pHdfDsetQuality->m_where.m_polar_where.m_nRays;
                                    }
                                    fnFreeMatrix2D((void **)pHdfDsetQuality->m_ppData, iYdim);
                                }
                                free(pHdfDsetQuality);
                            }
                        }
                        free(pHdf->m_ppDataset[iDatasetIdx]->m_ppQuality);
                    }
                    free(pHdf->m_ppDataset[iDatasetIdx]);
                }
            }
            free(pHdf->m_ppDataset);
        }
        free(pHdf);
    }
}

int fnGetMaxCountHdfRadar(HDF_RADAR *pHdf, int *pMaxDataset, int *pMaxData, int *pMaxRay, int *pMaxBin)
{
    int         iDsetIdx    = 0;
    int         iDataIdx    = 0;
    int         iMaxDataset = 0;
    int         iMaxData    = 0;
    int         iMaxRay     = 0;
    int         iMaxBin     = 0;

    if(pHdf == NULL)
        return FALSE;

    iMaxDataset = pHdf->m_iMaxDataset;

    for(iDsetIdx = 0; iDsetIdx < pHdf->m_iMaxDataset; iDsetIdx++)
    {
        if(pHdf->m_ppDataset == NULL)
            break;

        if(pHdf->m_ppDataset[iDsetIdx] == NULL)
            continue;

        if(iMaxData < pHdf->m_ppDataset[iDsetIdx]->m_iMaxData)
            iMaxData = pHdf->m_ppDataset[iDsetIdx]->m_iMaxData;

        for(iDataIdx = 0; iDataIdx < pHdf->m_ppDataset[iDsetIdx]->m_iMaxData; iDataIdx++)
        {
            if(pHdf->m_ppDataset[iDsetIdx]->m_ppData == NULL)
                break;

            if(pHdf->m_ppDataset[iDsetIdx]->m_ppData[iDataIdx] == NULL)
                continue;

            if(iMaxRay < (int)pHdf->m_ppDataset[iDsetIdx]->
                         m_ppData[iDataIdx]->m_where.m_polar_where.m_nRays)
            {
                iMaxRay = (int)pHdf->m_ppDataset[iDsetIdx]->
                          m_ppData[iDataIdx]->m_where.m_polar_where.m_nRays;
            }
            if(iMaxBin < (int)pHdf->m_ppDataset[iDsetIdx]->
                          m_ppData[iDataIdx]->m_where.m_polar_where.m_nBins)
            {
                iMaxBin = (int)pHdf->m_ppDataset[iDsetIdx]->
                          m_ppData[iDataIdx]->m_where.m_polar_where.m_nBins;
            }
        }
    }

    if(pMaxDataset != NULL) *pMaxDataset = iMaxDataset;
    if(pMaxData    != NULL) *pMaxData    = iMaxData;
    if(pMaxRay     != NULL) *pMaxRay     = iMaxRay;
    if(pMaxBin     != NULL) *pMaxBin     = iMaxBin;

    return TRUE;
}

/* ================================================================================ */







