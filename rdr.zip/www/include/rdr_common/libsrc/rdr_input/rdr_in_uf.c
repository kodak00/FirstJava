/* ================================================================================ */
//
// Radar UF Input Format & Input Function
//
// 2016.08.07 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function

static EN_UF_TYPE_E fnChkUfMagic(gzFile pFp, UF_TYPE_HDR *pMagic)
{
    if(pFp == NULL || pMagic == NULL)
    {
        return EN_UF_TYPE_UNKNOWN;
    }

    if(gzread(pFp, pMagic->buf, 6) != 6)
    {
        return EN_UF_TYPE_UNKNOWN;
    }

    // UF type => record len => 4byte(xxxxUF), 2byte(xxUF), 0byte(UF)
    if(pMagic->buf[0] == 'U' && pMagic->buf[1] == 'F')
    {
        return EN_UF_TYPE_ZERO;
    }
    else if(pMagic->buf[2] == 'U' && pMagic->buf[3] == 'F')
    {
        return EN_UF_TYPE_TWO;
    }
    else if(pMagic->buf[4] == 'U' && pMagic->buf[5] == 'F')
    {
        return EN_UF_TYPE_FOUR;
    }
    else
    {
        return EN_UF_TYPE_UNKNOWN;
    }
}

static int fnUfInitSweep(UF_RADAR *pUf, int iMaxSweep)
{
    int         iSweepIdx   = 0;

    if(pUf == NULL || pUf->m_ppSweep != NULL)
        return FALSE;

    pUf->m_iMaxSweep = iMaxSweep;
    pUf->m_ppSweep   = (UF_SWEEP **)calloc(pUf->m_iMaxSweep, sizeof(UF_SWEEP *));
    if(pUf->m_ppSweep == NULL)
        return FALSE;

    for(iSweepIdx = 0; iSweepIdx < pUf->m_iMaxSweep; iSweepIdx++)
    {
        pUf->m_ppSweep[iSweepIdx] = (UF_SWEEP *)calloc(1, sizeof(UF_SWEEP));
        if(pUf->m_ppSweep[iSweepIdx] == NULL)
            return FALSE;
    }

    return TRUE;
}

static int fnUfInitRay(UF_SWEEP *pSweep, int iMaxRay)
{
    int         iRayIdx     = 0;

    if(pSweep == NULL || pSweep->m_ppRay != NULL)
        return FALSE;

    pSweep->m_iMaxRay = iMaxRay;
    pSweep->m_ppRay   = (UF_RAY **)calloc(pSweep->m_iMaxRay, sizeof(UF_RAY *));
    if(pSweep->m_ppRay == NULL)
        return FALSE;

    for(iRayIdx = 0; iRayIdx < pSweep->m_iMaxRay; iRayIdx++)
    {
        pSweep->m_ppRay[iRayIdx] = (UF_RAY *)calloc(1, sizeof(UF_RAY));
        if(pSweep->m_ppRay[iRayIdx] == NULL)
            return FALSE;
    }

    return TRUE;
}

static int fnUfInitField(UF_RAY *pRay, int iMaxField)
{
    int         iFieldId    = 0;

    if(pRay == NULL || pRay->m_ppField != NULL)
        return FALSE;

    // data header
    pRay->dh.m_iMaxField         = iMaxField;
    pRay->dh.m_iMaxRecord        = 1;
    pRay->dh.m_iMaxFieldInRecord = iMaxField;

    pRay->dh.m_pfi = (UF_FIELD_INFO *)calloc(1, iMaxField * sizeof(UF_FIELD_INFO));
    if(pRay->dh.m_pfi == NULL)
        return FALSE;

    pRay->m_iMaxField = iMaxField;
    pRay->m_ppField   = (UF_FIELD **)calloc(pRay->m_iMaxField, sizeof(UF_FIELD*));
    if(pRay->m_ppField == NULL)
        return FALSE;

    for(iFieldId = 0; iFieldId < pRay->m_iMaxField; iFieldId++)
    {
        pRay->m_ppField[iFieldId] = (UF_FIELD *)calloc(1, sizeof(UF_FIELD));
        if(pRay->m_ppField[iFieldId] == NULL)
            return FALSE;
    }

    return TRUE;
}

static int fnUfInitBin(UF_FIELD *pField, int iMaxBin)
{
    if(pField == NULL || pField->m_pData != NULL)
        return FALSE;

    pField->m_iMaxBin = iMaxBin;
    pField->m_pData   = (short *)calloc(pField->m_iMaxBin, sizeof(short));
    if(pField->m_pData == NULL)
        return FALSE;

    return TRUE;
}

static UF_RADAR* fnInitUf(int iMaxSweep, int iMaxRay, int iMaxField, int iMaxBin)
{
    UF_RADAR    *pUf        = NULL;     // VARIABLE
    UF_SWEEP    *pSweep     = NULL;     // VARIABLE
    UF_RAY      *pRay       = NULL;     // VARIABLE
    UF_FIELD    *pField     = NULL;     // VARIABLE
    int         iSweepIdx   = 0;
    int         iRayIdx     = 0;
    int         iFieldIdx   = 0;

    if(iMaxSweep <= 0 || iMaxRay <= 0 || iMaxField <= 0 || iMaxBin <= 0)
        return NULL;

    if((pUf = (UF_RADAR *)calloc(1, sizeof(UF_RADAR))) == NULL) 
        return NULL;

    if(fnUfInitSweep(pUf, iMaxSweep) == FALSE)
    {
        fprintf(stderr, "%s : fnUfInitSweep fail\n", __func__);
        fnFreeUfRadar(pUf); return NULL;
    }

    for(iSweepIdx = 0; iSweepIdx < iMaxSweep; iSweepIdx++)
    {
        pSweep = pUf->m_ppSweep[iSweepIdx];
        if(fnUfInitRay(pSweep, iMaxRay) == FALSE)
        {
            fprintf(stderr, "%s : fnUfInitRay fail\n", __func__);
            fnFreeUfRadar(pUf); return NULL;
        }

        for(iRayIdx = 0; iRayIdx < iMaxRay; iRayIdx++)
        {
            pRay = pSweep->m_ppRay[iRayIdx];
            if(fnUfInitField(pRay, iMaxField) == FALSE)
            {
                fprintf(stderr, "%s : fnUfInitField fail\n", __func__);
                fnFreeUfRadar(pUf); return NULL;
            }

            for(iFieldIdx = 0; iFieldIdx < iMaxField; iFieldIdx++)
            {
                pField = pRay->m_ppField[iFieldIdx];
                if(fnUfInitBin(pField, iMaxBin) == FALSE)
                {
                    fprintf(stderr, "%s : fnUfInitBin fail\n", __func__);
                    fnFreeUfRadar(pUf); return NULL;
                }
            }
        }
    }

    return pUf;
}

static void fnUfSwapBuffer(UFBuffer arrBuf, int iBufLen)
{
    //fnSwap2Array(arrBuf, sizeof(UFBuffer) / sizeof(short));
    fnSwap2Array(arrBuf, iBufLen / sizeof(short));
}

static void fnMandatoryHeaderConvert(UF_RAY *pRay, short *pUf_ma, int bLittleEndian)
{
    if(pRay == NULL || pUf_ma == NULL)
        return;

    if(bLittleEndian == TRUE) fnSwap2Array(&pUf_ma[0], 1);
    memcpy(pRay->mh.m_szID, &pUf_ma[0], 2);
    pRay->mh.m_iRecLen      = pUf_ma[1];
    pRay->mh.m_iOHpos       = pUf_ma[2];
    pRay->mh.m_iLHpos       = pUf_ma[3];
    pRay->mh.m_iDHpos       = pUf_ma[4];
    pRay->mh.m_iRecordNo    = pUf_ma[5];
    pRay->mh.m_iVolumeNo    = pUf_ma[6];
    pRay->mh.m_iRayNo       = pUf_ma[7];
    pRay->mh.m_iRecordInRay = pUf_ma[8];
    pRay->mh.m_iSweepNo     = pUf_ma[9];
    if(bLittleEndian == TRUE) fnSwap2Array(&pUf_ma[10], 4);
    memcpy(pRay->mh.m_szRadarName, &pUf_ma[10], 8);
    if(bLittleEndian == TRUE) fnSwap2Array(&pUf_ma[14], 4);
    memcpy(pRay->mh.m_szSiteName, &pUf_ma[14], 8);
    pRay->mh.m_iLatDeg    = pUf_ma[18];
    pRay->mh.m_iLatMin    = pUf_ma[19];
    pRay->mh.m_fLatSec    = pUf_ma[20] / 64.f;
    pRay->mh.m_iLonDeg    = pUf_ma[21];
    pRay->mh.m_iLonMin    = pUf_ma[22];
    pRay->mh.m_fLonSec    = pUf_ma[23] / 64.f;
    pRay->mh.m_iAnteHeight= pUf_ma[24];
    pRay->mh.m_iYear      = pUf_ma[25];
    if(pRay->mh.m_iYear < 1900)
    {
        pRay->mh.m_iYear += 1900;
        if(pRay->mh.m_iYear < 1980)
            pRay->mh.m_iYear += 100;
    }
    pRay->mh.m_iMonth  = pUf_ma[26];
    pRay->mh.m_iDay    = pUf_ma[27];
    pRay->mh.m_iHour   = pUf_ma[28];
    pRay->mh.m_iMinute = pUf_ma[29];
    pRay->mh.m_iSecond = pUf_ma[30];
    if(bLittleEndian == TRUE) fnSwap2Array(&pUf_ma[31], 1);
    memcpy(pRay->mh.m_szTimeZone, &pUf_ma[31], 2);
    pRay->mh.m_fAzimuth      = pUf_ma[32] / 64.f;
    if(pRay->mh.m_fAzimuth < 0)
        pRay->mh.m_fAzimuth += 360.0;
    pRay->mh.m_fElevation    = pUf_ma[33] / 64.f;
    pRay->mh.m_iSweepMode    = pUf_ma[34];
    pRay->mh.m_fFixedAngle   = pUf_ma[35] / 64.f;
    pRay->mh.m_fSweepRate    = pUf_ma[36] / 64.f;
    pRay->mh.m_iConvertYear  = pUf_ma[37];
    pRay->mh.m_iConvertMonth = pUf_ma[38];
    pRay->mh.m_iConvertDay   = pUf_ma[39];
    if(pRay->mh.m_iConvertYear < 1900)
    {
        pRay->mh.m_iConvertYear += 1900;
        if( pRay->mh.m_iConvertYear < 1980 )
            pRay->mh.m_iConvertYear += 100;
    }
    if(bLittleEndian == TRUE) fnSwap2Array(&pUf_ma[40], 4);
    memcpy(pRay->mh.m_szConvertName, &pUf_ma[40], 8);
    pRay->mh.m_iNoDataValue  = pUf_ma[44];
}

static void fnOptionalHeaderConvert(UF_RAY *pRay, short *pUf_oh, int bLittleEndian)
{
    if(pRay == NULL || pUf_oh == NULL)
        return;

    memcpy(pRay->oh.m_szProjectName, "", 8);
    pRay->oh.m_fBaselineAzimuth   = 0.f;
    pRay->oh.m_fBaselineElevation = 0.f;
    pRay->oh.m_iVolumeScanHour    = 0;
    pRay->oh.m_iVolumeScanMin     = 0;
    pRay->oh.m_iVolumeScanSec     = 0;
    memcpy(pRay->oh.m_szFieldTapeName, "", 8);
    pRay->oh.m_iFlag              = 0;
    if(pRay->mh.m_iOHpos != pRay->mh.m_iLHpos)
    {
        if(bLittleEndian == TRUE) fnSwap2Array(&pUf_oh[0], 4);
        memcpy(pRay->oh.m_szProjectName, &pUf_oh[0], 8);

        pRay->oh.m_fBaselineAzimuth   = pUf_oh[4] / 64.f;
        pRay->oh.m_fBaselineElevation = pUf_oh[5] / 64.f;
        pRay->oh.m_iVolumeScanHour    = pUf_oh[6];
        pRay->oh.m_iVolumeScanMin     = pUf_oh[7];
        pRay->oh.m_iVolumeScanSec     = pUf_oh[8];

        if(pRay->oh.m_fBaselineAzimuth < 0)
            pRay->oh.m_fBaselineAzimuth += 360.0;

        if(bLittleEndian == TRUE) fnSwap2Array(&pUf_oh[9], 4);
        memcpy(pRay->oh.m_szFieldTapeName, &pUf_oh[9], 8);

        pRay->oh.m_iFlag = pUf_oh[13];
    }
}

static void fnLocalUseHeaderConvert(UF_RAY *pRay, short *pUf_lh, int bLittleEndian)
{
    int         iLen            = 0;

    if(pRay == NULL || pUf_lh == NULL)
        return;

    pRay->lh.m_iMaxContent = 0;
    pRay->lh.m_pszContent  = NULL;

    if(pRay->mh.m_iLHpos != pRay->mh.m_iDHpos)
    {
        iLen = (pRay->mh.m_iDHpos - pRay->mh.m_iLHpos) * 2;

        pRay->lh.m_iMaxContent = iLen;
        pRay->lh.m_pszContent  = (char *)calloc(1, iLen * sizeof(char));
        if(pRay->lh.m_pszContent == NULL) 
        {
            pRay->lh.m_iMaxContent = 0;
            return;
        }

        if(bLittleEndian == TRUE) fnSwap2Array(&pUf_lh[0], iLen / 2);
        memcpy(pRay->lh.m_pszContent, &pUf_lh[0], iLen);
    }
}

static void fnDataHeaderConvert(UF_RAY *pRay, short *pUf_dh, int bLittleEndian)
{
    int         iFieldIdx       = 0;

    if(pRay == NULL || pUf_dh == NULL)
        return;

    pRay->dh.m_iMaxField         = pUf_dh[0];
    pRay->dh.m_iMaxRecord        = pUf_dh[1];
    pRay->dh.m_iMaxFieldInRecord = pUf_dh[2];

    for(iFieldIdx = 0; iFieldIdx < pRay->dh.m_iMaxField; iFieldIdx++)
    {
        if(bLittleEndian == TRUE) fnSwap2Array(&pUf_dh[3 + 2 * iFieldIdx], 1);
        memcpy(pRay->dh.m_pfi[iFieldIdx].m_szFieldName, &pUf_dh[3 + 2 * iFieldIdx], 2);

        pRay->dh.m_pfi[iFieldIdx].m_iFHpos = pUf_dh[4 + 2 * iFieldIdx];
    }
}

static void fnFieldHeaderConvert(UF_RAY *pRay, int iFieldIdx, short *pUf_fh, int bLittleEndian)
{
    float       fScaleFactor    = 0;

    if(pRay == NULL || pUf_fh == NULL)
        return;

    pRay->m_ppField[iFieldIdx]->m_iCurBin             = pUf_fh[5];

    pRay->m_ppField[iFieldIdx]->fh.m_iDataPos         = pUf_fh[0];
    pRay->m_ppField[iFieldIdx]->fh.m_iScaleFactor     = pUf_fh[1];
    pRay->m_ppField[iFieldIdx]->fh.m_iStartRangeKm    = pUf_fh[2];
    pRay->m_ppField[iFieldIdx]->fh.m_iStartRangeMeter = pUf_fh[3];
    pRay->m_ppField[iFieldIdx]->fh.m_iBinSpacing      = pUf_fh[4];
    pRay->m_ppField[iFieldIdx]->fh.m_iMaxBin          = pUf_fh[5];
    pRay->m_ppField[iFieldIdx]->fh.m_iPulseWidth      = pUf_fh[6];
    pRay->m_ppField[iFieldIdx]->fh.m_fBeamWidthH      = pUf_fh[7]  / 64.f;
    pRay->m_ppField[iFieldIdx]->fh.m_fBeamWidthV      = pUf_fh[8]  / 64.f;
    pRay->m_ppField[iFieldIdx]->fh.m_iBandWidth       = pUf_fh[9];
    pRay->m_ppField[iFieldIdx]->fh.m_iPolarMode       = pUf_fh[10];
    pRay->m_ppField[iFieldIdx]->fh.m_fWaveLength      = pUf_fh[11] / 64.f;
    pRay->m_ppField[iFieldIdx]->fh.m_iSampleSize      = pUf_fh[12];

    if(bLittleEndian == TRUE) fnSwap2Array(&pUf_fh[13], 1);
    memcpy(pRay->m_ppField[iFieldIdx]->fh.m_szThresholdType, &pUf_fh[13], 2);

    pRay->m_ppField[iFieldIdx]->fh.m_iThresholdValue  = pUf_fh[14];
    pRay->m_ppField[iFieldIdx]->fh.m_iScale           = pUf_fh[15];

    if(bLittleEndian == TRUE) fnSwap2Array(&pUf_fh[16], 1);
    memcpy(pRay->m_ppField[iFieldIdx]->fh.m_szEditCode, &pUf_fh[16], 2);

    pRay->m_ppField[iFieldIdx]->fh.m_iPRT             = pUf_fh[17];
    pRay->m_ppField[iFieldIdx]->fh.m_iBitsPerBin      = pUf_fh[18];

    fScaleFactor = pRay->m_ppField[iFieldIdx]->fh.m_iScaleFactor;

    // for VF, VE, VR, VT, VP
    if( strncmp(pRay->dh.m_pfi[iFieldIdx].m_szFieldName, "VF", 2) == 0 ||
        strncmp(pRay->dh.m_pfi[iFieldIdx].m_szFieldName, "VE", 2) == 0 ||
        strncmp(pRay->dh.m_pfi[iFieldIdx].m_szFieldName, "VR", 2) == 0 ||
        strncmp(pRay->dh.m_pfi[iFieldIdx].m_szFieldName, "VT", 2) == 0 ||
        strncmp(pRay->dh.m_pfi[iFieldIdx].m_szFieldName, "VP", 2) == 0 )
    {
        pRay->m_ppField[iFieldIdx]->fh.m_fNyquistVelocity = pUf_fh[19] / fScaleFactor;
        if(bLittleEndian == TRUE) fnSwap2Array(&pUf_fh[20], 1);
        memcpy(pRay->m_ppField[iFieldIdx]->fh.m_szVelocityFlag, &pUf_fh[20], 2);
    }
    else if(strncmp(pRay->dh.m_pfi[iFieldIdx].m_szFieldName, "DM", 2) == 0 )
    {
        pRay->m_ppField[iFieldIdx]->fh.m_fRadarConstant = pUf_fh[19] / 64.f;
        pRay->m_ppField[iFieldIdx]->fh.m_fNoisePower    = pUf_fh[20] / fScaleFactor;
        pRay->m_ppField[iFieldIdx]->fh.m_fReceiverGain  = pUf_fh[21] / fScaleFactor;
        pRay->m_ppField[iFieldIdx]->fh.m_fPeakPower     = pUf_fh[22] / fScaleFactor;
        pRay->m_ppField[iFieldIdx]->fh.m_fAntennaGain   = pUf_fh[23] / fScaleFactor;
        pRay->m_ppField[iFieldIdx]->fh.m_fPulseDuration = pUf_fh[24] / 64.f;
    }
}

static int fnUfIntoMemory(UFBuffer arrBuf, UF_RADAR *pUf, int bLittleEndian)
{
    short       *pUf_ma         = NULL;     // Mandatory header block.
    short       *pUf_oh         = NULL;     // Optional header block.
    short       *pUf_lh         = NULL;     // Local Use header block.
    short       *pUf_dh         = NULL;     // Data header.
    short       *pUf_fh         = NULL;     // Field header.
    short       *pUf_data       = NULL;     // Data.
    int         iCurField       = 0;
    int         iSweepNo        = 0;
    int         iRayNo          = 0;
    int         iFieldIdx       = 0;
    UF_SWEEP    *pSweep         = NULL;     // VARIABLE
    UF_RAY      *pRay           = NULL;     // VARIABLE
    UF_FIELD    *pField         = NULL;     // VARIABLE

    if(arrBuf == NULL || pUf == NULL)
        return FALSE;

    pUf_ma = arrBuf;
    pUf_oh = arrBuf + pUf_ma[2] - 1;
    pUf_lh = arrBuf + pUf_ma[3] - 1;
    pUf_dh = arrBuf + pUf_ma[4] - 1;
    iCurField = pUf_dh[0];
    iSweepNo  = pUf_ma[9] - 1;

    if(iSweepNo >= RDR_DF_MAX_SWEEP || iCurField >= RDR_DF_MAX_FIELD)
        return FALSE;

    if(pUf->m_iCurSweep == iSweepNo)
        pUf->m_iCurSweep++;

    iRayNo = pUf->m_ppSweep[iSweepNo]->m_iCurRay;
    pUf->m_ppSweep[iSweepNo]->m_iCurRay++;
    if(pUf->m_ppSweep[iSweepNo]->m_iCurRay >= RDR_DF_MAX_RAY)
        return FALSE;

    pUf->m_ppSweep[iSweepNo]->m_ppRay[iRayNo]->m_iCurField = iCurField;

    pSweep = pUf->m_ppSweep[iSweepNo];
    pRay   = pUf->m_ppSweep[iSweepNo]->m_ppRay[iRayNo];

    fnMandatoryHeaderConvert(pRay, pUf_ma, bLittleEndian);
    fnOptionalHeaderConvert(pRay, pUf_oh, bLittleEndian);
    fnLocalUseHeaderConvert(pRay, pUf_lh, bLittleEndian);
    fnDataHeaderConvert(pRay, pUf_dh, bLittleEndian);
    for(iFieldIdx = 0; iFieldIdx < pRay->dh.m_iMaxField; iFieldIdx++)
    {
        pField = pRay->m_ppField[iFieldIdx];
        pUf_fh = arrBuf + pRay->dh.m_pfi[iFieldIdx].m_iFHpos - 1;
        fnFieldHeaderConvert(pRay, iFieldIdx, pUf_fh, bLittleEndian);
        if(pField->m_iCurBin < 0 || pField->m_iCurBin >= RDR_DF_MAX_BIN)
            return FALSE;

        pUf_data = arrBuf + pRay->m_ppField[iFieldIdx]->fh.m_iDataPos - 1;
        memcpy(pField->m_pData, pUf_data, pField->m_iCurBin * 2);
    }

    return TRUE;
}

static UF_RADAR* fnTypeFourUfRead(gzFile pFp, int bLittleEndian, UF_TYPE_HDR *pMagic)
{
    int             iLoopCnt        = 0;
    int             iRecLen         = 0;
    int             iTailSize       = -1;
    int             iTailIdx        = 0;
    char            szDummy[28]     = { "" };
    UF_SIZE_HEAD    size            = { 0, "", 0 };
    UF_RADAR        *pUf            = NULL;
    UFBuffer        arrBuf;

    pUf = fnInitUf(RDR_DF_MAX_SWEEP, RDR_DF_MAX_RAY, RDR_DF_MAX_FIELD, RDR_DF_MAX_BIN);
    if(pUf == NULL)
        return NULL;

    gzseek(pFp, 0, SEEK_SET);
    memset(&arrBuf, 0x00, sizeof(arrBuf));

    while((gzread(pFp, &size, sizeof(UF_SIZE_HEAD)) > 0) && iLoopCnt < LOOP_CNT_MAX)
    {
        if(bLittleEndian == TRUE)
            fnSwap2Byte(&size.m_iRecLen);

        if(gzread(pFp, &arrBuf[2], (size.m_iRecLen)*2 - 4) <= 0)
        {
            fnFreeUfRadar(pUf); 
            return NULL;
        }

        if(bLittleEndian == TRUE)
            fnUfSwapBuffer(&arrBuf[2], (size.m_iRecLen)*2 - 4);

        memcpy(&arrBuf[0], &size.m_szID,    2);
        memcpy(&arrBuf[1], &size.m_iRecLen, 2);

        if(fnUfIntoMemory(arrBuf, pUf, bLittleEndian) == FALSE)
        {
            fnFreeUfRadar(pUf); 
            return NULL;
        }

        if(iTailSize == -1)
        {
            if(gzread(pFp, &szDummy, 12) != 12)
            {
                fnFreeUfRadar(pUf); 
                return NULL;
            }
            for(iTailIdx = 0; iTailIdx < 12; iTailIdx++)
            {
                if(szDummy[iTailIdx] == 'U' && szDummy[iTailIdx+1] == 'F')
                    break;
            }
            iTailSize = iTailIdx - (sizeof(int)+sizeof(int)); // 레코드 앞뒤
            gzseek(pFp, -12, SEEK_CUR);
        }

        if(iTailSize == 0)
            gzread(pFp, &iRecLen, sizeof(int));

        iLoopCnt++;
    }

    if(iLoopCnt == LOOP_CNT_MAX)
    {
        fnFreeUfRadar(pUf); 
        return NULL;
    }

    return pUf;
}

static UF_RADAR* fnTypeTwoUfRead(gzFile pFp, int bLittleEndian, UF_TYPE_HDR *pMagic)
{
    int         iLoopCnt        = 0;
    short       sRecLen         = 0;
    UF_RADAR    *pUf            = NULL;
    UFBuffer    arrBuf;

    pUf = fnInitUf(RDR_DF_MAX_SWEEP, RDR_DF_MAX_RAY, RDR_DF_MAX_FIELD, RDR_DF_MAX_BIN);
    if(pUf == NULL)
        return NULL;

    memset(&arrBuf, 0x00, sizeof(arrBuf));

    sRecLen = pMagic->sword;
    if(bLittleEndian == TRUE)
        fnSwap2Byte(&sRecLen);

    memcpy(arrBuf, &(pMagic->buf[2]), 4);
    if(gzread(pFp, &arrBuf[2], sRecLen - 4) <= 0)
    {
        fnFreeUfRadar(pUf); return NULL;
    }

    if(bLittleEndian == TRUE)
        fnUfSwapBuffer(arrBuf, sRecLen);

    if(fnUfIntoMemory(arrBuf, pUf, bLittleEndian) == FALSE)
    {
        fnFreeUfRadar(pUf); return NULL;
    }

    gzread(pFp, &sRecLen, sizeof(short));

    while((gzread(pFp, &sRecLen, sizeof(short)) > 0 ) && iLoopCnt < LOOP_CNT_MAX)
    {
        if(bLittleEndian == TRUE)
            fnSwap2Byte(&sRecLen);

        if(gzread(pFp, arrBuf, sRecLen) <= 0)
        {
            fnFreeUfRadar(pUf); return NULL;
        }

        if(bLittleEndian == TRUE)
            fnUfSwapBuffer(arrBuf, sRecLen);

        if(fnUfIntoMemory(arrBuf, pUf, bLittleEndian) == FALSE)
        {
            fnFreeUfRadar(pUf); return NULL;
        }

        gzread(pFp, &sRecLen, sizeof(short));
        iLoopCnt++;
    }

    if(iLoopCnt == LOOP_CNT_MAX)
    {
        fnFreeUfRadar(pUf); return NULL;
    }

    return pUf;
}

static UF_RADAR* fnTypeZeroUfRead(gzFile pFp, int bLittleEndian, UF_TYPE_HDR *pMagic)
{
    int         iLoopCnt        = 0;
    short       sRecLen         = 0;
    UF_RADAR    *pUf            = NULL;
    UFBuffer    arrBuf;

    pUf = fnInitUf(RDR_DF_MAX_SWEEP, RDR_DF_MAX_RAY, RDR_DF_MAX_FIELD, RDR_DF_MAX_BIN);
    if(pUf == NULL)
        return NULL;

    memset(&arrBuf, 0x00, sizeof(arrBuf));

    memcpy(&sRecLen, &(pMagic->buf[2]), 2);
    if(bLittleEndian == TRUE)
        fnSwap2Byte(&sRecLen);

    memcpy(arrBuf, &(pMagic->buf[0]), 6);
    if(gzread(pFp, &arrBuf[3], sizeof(short) * (sRecLen - 3)) <= 0)
    {
        fnFreeUfRadar(pUf); return NULL;
    }

    if(bLittleEndian == TRUE)
        fnUfSwapBuffer(arrBuf, sizeof(short) * sRecLen);

    if(fnUfIntoMemory(arrBuf, pUf, bLittleEndian) == FALSE)
    {
        fnFreeUfRadar(pUf); return NULL;
    }

    while((gzread(pFp, arrBuf, sizeof(short) * 2) > 0) && iLoopCnt < LOOP_CNT_MAX)
    {
        memcpy(&sRecLen, &arrBuf[1], 2);
        if(bLittleEndian == TRUE)
            fnSwap2Byte(&sRecLen);

        if(gzread(pFp, &arrBuf[2], sizeof(short) * (sRecLen - 2)) <= 0)
        {
            fnFreeUfRadar(pUf); return NULL;
        }

        if(bLittleEndian == TRUE)
            fnUfSwapBuffer(arrBuf, sizeof(short) * sRecLen);

        if(fnUfIntoMemory(arrBuf, pUf, bLittleEndian) == FALSE)
        {
            fnFreeUfRadar(pUf); return NULL;
        }

        iLoopCnt++;
    }

    if(iLoopCnt == LOOP_CNT_MAX)
    {
        fnFreeUfRadar(pUf); return NULL;
    }

    return pUf;
}

/* ================================================================================ */
// Function

UF_RADAR* fnLoadUf(char *pFile)
{
#define FN_UF_LOAD_ERROR(ERR_MSG) \
    fprintf(stderr, "%s : %s\n", __func__, ERR_MSG); \
    if(pFp != NULL)  { gzclose(pFp); }

    UF_TYPE_HDR magic;
    gzFile      pFp             = NULL;
    UF_RADAR    *pUf            = NULL;
    int         bLittleEndian   = FALSE;
    int         ufType          = EN_UF_TYPE_UNKNOWN;

    bLittleEndian = fnIsLittleEndian();

    if((pFp = gzopen(pFile, "r" )) == NULL)
    {
        FN_UF_LOAD_ERROR("gzopen fail")
        return NULL;
    }

    if((ufType = fnChkUfMagic(pFp, &magic)) == EN_UF_TYPE_UNKNOWN)
    {
        FN_UF_LOAD_ERROR("UF file type is EN_UF_TYPE_UNKNOWN")
        return NULL;
    }

    switch( ufType )
    {
        case EN_UF_TYPE_FOUR:
        {
            pUf = fnTypeFourUfRead(pFp, bLittleEndian, &magic);
        }
        break;
        case EN_UF_TYPE_TWO:
        {
            pUf = fnTypeTwoUfRead(pFp, bLittleEndian, &magic);
        }
        break;
        case EN_UF_TYPE_ZERO:
        {
            pUf = fnTypeZeroUfRead(pFp, bLittleEndian, &magic);
        }
        break;
    }

    gzclose(pFp);

    return pUf;
}

void fnFreeUfRadar(UF_RADAR *pUf)
{
    UF_SWEEP    *pSweep     = NULL;     // VARIABLE
    UF_RAY      *pRay       = NULL;     // VARIABLE
    UF_FIELD    *pField     = NULL;     // VARIABLE
    int         iSweepIdx   = 0;
    int         iRayIdx     = 0;
    int         iFieldIdx   = 0;

    if(pUf != NULL)
    {
        if(pUf->m_ppSweep != NULL)
        {
            for(iSweepIdx = 0; iSweepIdx < pUf->m_iMaxSweep; iSweepIdx++)
            {
                pSweep = pUf->m_ppSweep[iSweepIdx];
                if(pSweep != NULL)
                {
                    if(pSweep->m_ppRay != NULL)
                    {
                        for(iRayIdx = 0; iRayIdx < pSweep->m_iMaxRay; iRayIdx++)
                        {
                            pRay = pSweep->m_ppRay[iRayIdx];
                            if(pRay != NULL)
                            {
                                for(iFieldIdx = 0; iFieldIdx < pRay->m_iMaxField; iFieldIdx++)
                                {
                                    pField = pRay->m_ppField[iFieldIdx];
                                    if(pField != NULL)
                                    {
                                        if(pField->m_pData != NULL)
                                        {
                                            free(pField->m_pData);
                                        }
                                        free(pField);
                                    }
                                }
                                if(pRay->lh.m_pszContent != NULL)
                                {
                                    free(pRay->lh.m_pszContent);
                                }
                                if(pRay->dh.m_pfi != NULL)
                                {
                                    free(pRay->dh.m_pfi);
                                }
                                free(pRay->m_ppField);
                                free(pRay);
                            }
                        }
                        free(pSweep->m_ppRay);
                    }
                    free(pSweep);
                }
            }
            free(pUf->m_ppSweep);
        }
        free(pUf);
    }
}

int fnValidUf(UF_RADAR *pUf)
{
    UF_SWEEP    *pSweep     = NULL;     // VARIABLE
    UF_RAY      *pRay       = NULL;     // VARIABLE
    UF_FIELD    *pField     = NULL;     // VARIABLE
    int         iSweepIdx   = 0;
    int         iRayIdx     = 0;
    int         iFieldIdx   = 0;

    if(pUf == NULL || pUf->m_ppSweep == NULL)
        return FALSE;

    for(iSweepIdx = 0; iSweepIdx < pUf->m_iMaxSweep; iSweepIdx++)
    {
        pSweep = pUf->m_ppSweep[iSweepIdx];
        if( pSweep == NULL || pSweep->m_ppRay == NULL)
            return FALSE;

        for(iRayIdx = 0; iRayIdx < pSweep->m_iMaxRay; iRayIdx++)
        {
            pRay = pSweep->m_ppRay[iRayIdx];
            if( pRay == NULL || pRay->m_ppField == NULL || pRay->dh.m_pfi == NULL)
                return FALSE;

            for(iFieldIdx = 0; iFieldIdx < pRay->m_iMaxField; iFieldIdx++)
            {
                pField = pRay->m_ppField[iFieldIdx];
                if( pField == NULL || pField->m_pData == NULL)
                    return FALSE;
            }
        }
    }

    return TRUE;

}

/* ================================================================================ */

