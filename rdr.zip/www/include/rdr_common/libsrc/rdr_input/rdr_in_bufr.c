/* ================================================================================ */
//
// Radar BUFR Input Format & Input Function
//
// 2016.11.09 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"

/* Interface for the PROJ library of geographic projections */
#include <proj_api.h>

/* bufr */
#include <desc.h>
#include <bufr.h>
#include <bitio.h>
#include <rlenc.h>

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable

static BUFR_RADAR               *g_pBufr            = NULL;

static BUFR_PRODUCT             *g_pBufrProduct     = NULL;
static BUFR_PRODUCT_READ_TBL    g_bufrPrdtReadTbl   = { 0, 0, 0, NULL };

/* ================================================================================ */
// Static Function

static int fnGetMaxDatasetCountReadTbl(char *szProduct, int *pMaxDataset, int *pMaxData)
{
    int     iTotalDataIdx                       = 0;
    int     iMaxDataset                         = 0;
    int     iProdparIdx                         = 0;
    int     iDataCnt                            = 0;
    int     iMaxData                            = 0;
    double  dProdpar                            = 0.0;
    double  prodpar[RDR_DF_BUFR_PRODUCT_MAX]    = { 0.0, };

    if(g_bufrPrdtReadTbl.m_ppTmpData == NULL)
        return -1;

    for(iProdparIdx = 0; iProdparIdx < RDR_DF_BUFR_PRODUCT_MAX; iProdparIdx++)
        prodpar[iProdparIdx] = -9999.;

    for(iTotalDataIdx = 0; iTotalDataIdx < g_bufrPrdtReadTbl.m_iMaxData; iTotalDataIdx++)
    {
        if(!strcmp(g_bufrPrdtReadTbl.m_ppTmpData[iTotalDataIdx]->m_szProduct, szProduct))
        {
            dProdpar    = g_bufrPrdtReadTbl.m_ppTmpData[iTotalDataIdx]->m_dProdpar;

            for(iProdparIdx = 0; iProdparIdx < RDR_DF_BUFR_PRODUCT_MAX; iProdparIdx++)
            {
                if(fabs(prodpar[iProdparIdx] - -9999.) < RDR_DF_ERR_RANGE_D)
                    break;

                if(fabs(prodpar[iProdparIdx] - dProdpar) < RDR_DF_ERR_RANGE_D)
                    break;
            }

            if(iProdparIdx >= iMaxDataset)
            {
                prodpar[iProdparIdx] = dProdpar;
                iMaxDataset++;
                if(iMaxDataset > 1)
                {
                    if(iMaxData < iDataCnt)
                    {
                        iMaxData = iDataCnt;
                        iDataCnt = 0;
                    }
                }
            }

            iDataCnt++;
        }
    }
    
    if(iMaxData < iDataCnt)
        iMaxData = iDataCnt;

    if(pMaxDataset != NULL) *pMaxDataset = iMaxDataset;
    if(pMaxData    != NULL) *pMaxData    = iMaxData;

    return 0;
}

static void fnFreeBufrProductDataset(BUFR_PRODUCT_DATASET *pDset)
{
    int                     iTmpIdx = 0;

    if(pDset != NULL)
    {
        if(pDset->m_ppProductData != NULL)
        {
            for(iTmpIdx = 0; iTmpIdx < pDset->m_iMaxField; iTmpIdx++)
            {
                if(pDset->m_ppProductData[iTmpIdx] != NULL)
                {
                    free(pDset->m_ppProductData[iTmpIdx]);
                }
            }
            free(pDset->m_ppProductData);
        }
        free(pDset);
    }
}

static BUFR_PRODUCT_DATASET* fnInitBufrProductDataset(char *szProduct, int iMaxData)
{
    BUFR_PRODUCT_DATASET    *pDset  = NULL;
    int                     iTmpIdx = 0;

    pDset = (BUFR_PRODUCT_DATASET *)calloc(1, sizeof(BUFR_PRODUCT_DATASET));
    if(pDset == NULL)
        return NULL;
    
    snprintf(pDset->m_what.m_szProduct, sizeof(pDset->m_what.m_szProduct), "%s", szProduct);

    pDset->m_iMaxField = iMaxData;
    pDset->m_ppProductData  
    = (BUFR_PRODUCT_DATA **)calloc(iMaxData, sizeof(BUFR_PRODUCT_DATA *));
    if(pDset->m_ppProductData == NULL)
    {
        free(pDset);
        return NULL;
    }

    for(iTmpIdx = 0; iTmpIdx < iMaxData; iTmpIdx++)
    {
        pDset->m_ppProductData[iTmpIdx]
        = (BUFR_PRODUCT_DATA *)calloc(1, sizeof(BUFR_PRODUCT_DATA));
        if(pDset->m_ppProductData[iTmpIdx] == NULL)
        {
            fnFreeBufrProductDataset(pDset);
            return NULL;
        }
    }

    return pDset;
}

static char** fnConvertBufrProductData_C(int iTotIdx, FIELD_MEM_INFO_TBL memInfo)
{
    int                 iYIdx       = 0;
    int                 iXIdx       = 0;
    int                 iYdim       = 0;
    int                 iXdim       = 0;
    char                **ppData    = NULL;
    float               fData       = 0.0;

    if(g_bufrPrdtReadTbl.m_ppTmpData[iTotIdx] == NULL)
        return NULL;

    iYdim = g_pBufrProduct->m_where.m_image_where.m_lYsize;
    iXdim = g_pBufrProduct->m_where.m_image_where.m_lXsize;

    if((ppData = fnMakeMatrix2D_C(iYdim, iXdim)) == NULL)
        return NULL;

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            fData = g_bufrPrdtReadTbl.m_ppTmpData[iTotIdx]->m_ppData[iYIdx][iXIdx];

            if(fabs(fData - RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
                ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_C;
            else if(fabs(fData - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_C;
            else
            {
                ppData[iYIdx][iXIdx] = (char)((fData+memInfo.m_fOffset)*memInfo.m_fScale);
            }
        }
    }

    return ppData;
}

static short** fnConvertBufrProductData_S(int iTotIdx, FIELD_MEM_INFO_TBL memInfo)
{
    int                 iYIdx       = 0;
    int                 iXIdx       = 0;
    int                 iYdim       = 0;
    int                 iXdim       = 0;
    short               **ppData    = NULL;
    float               fData       = 0.0;

    if(g_bufrPrdtReadTbl.m_ppTmpData[iTotIdx] == NULL)
        return NULL;

    iYdim = g_pBufrProduct->m_where.m_image_where.m_lYsize;
    iXdim = g_pBufrProduct->m_where.m_image_where.m_lXsize;

    if((ppData = fnMakeMatrix2D_S(iYdim, iXdim)) == NULL)
        return NULL;

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            fData = g_bufrPrdtReadTbl.m_ppTmpData[iTotIdx]->m_ppData[iYIdx][iXIdx];

            if(fabs(fData - RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
                ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_S;
            else if(fabs(fData - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_S;
            else
            {
                ppData[iYIdx][iXIdx] = (short)((fData+memInfo.m_fOffset)*memInfo.m_fScale);
            }
        }
    }

    return ppData;
}

static float** fnConvertBufrProductData_F(int iTotIdx, FIELD_MEM_INFO_TBL memInfo)
{
    int                 iYIdx       = 0;
    int                 iXIdx       = 0;
    int                 iYdim       = 0;
    int                 iXdim       = 0;
    float               **ppData    = NULL;
    float               fData       = 0.0;

    if(g_bufrPrdtReadTbl.m_ppTmpData[iTotIdx] == NULL)
        return NULL;

    iYdim = g_pBufrProduct->m_where.m_image_where.m_lYsize;
    iXdim = g_pBufrProduct->m_where.m_image_where.m_lXsize;

    if((ppData = fnMakeMatrix2D_F(iYdim, iXdim)) == NULL)
        return NULL;

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            fData = g_bufrPrdtReadTbl.m_ppTmpData[iTotIdx]->m_ppData[iYIdx][iXIdx];

            if(fabs(fData - RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
                ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
            else if(fabs(fData - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
                ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
            else
            {
                ppData[iYIdx][iXIdx] = (float)((fData+memInfo.m_fOffset)*memInfo.m_fScale);
            }
        }
    }

    return ppData;
}

static int fnConvertReadTblToBufrProductDset(char *szProduct, BUFR_PRODUCT_DATASET **ppDset, int iMaxDset, int iMaxData)
{
    BUFR_PRODUCT_DATA   *pData                              = NULL;
    int                 iProdparIdx                         = 0;
    int                 iDsetIdx                            = -1;
    int                 iDataIdx                            = 0;
    int                 iTotalDataIdx                       = 0;
    double              dProdpar                            = 0.0;
    double              prodpar[RDR_DF_BUFR_PRODUCT_MAX]    = { 0.0, };
    FIELD_INFO_TBL      fieldInfo;
    FIELD_MEM_INFO_TBL  memInfo;

    if(ppDset == NULL)
        return -1;

    for(iProdparIdx = 0; iProdparIdx < RDR_DF_BUFR_PRODUCT_MAX; iProdparIdx++)
        prodpar[iProdparIdx] = -9999.;

    for(iTotalDataIdx = 0; iTotalDataIdx < g_bufrPrdtReadTbl.m_iMaxData; iTotalDataIdx++)
    {
        if(!strcmp(g_bufrPrdtReadTbl.m_ppTmpData[iTotalDataIdx]->m_szProduct, szProduct))
        {
            dProdpar    = g_bufrPrdtReadTbl.m_ppTmpData[iTotalDataIdx]->m_dProdpar;

            for(iProdparIdx = 0; iProdparIdx < RDR_DF_BUFR_PRODUCT_MAX; iProdparIdx++)
            {
                if(fabs(prodpar[iProdparIdx] - -9999.) < RDR_DF_ERR_RANGE_D)
                    break;

                if(fabs(prodpar[iProdparIdx] - dProdpar) < RDR_DF_ERR_RANGE_D)
                    break;
            }

            if(iProdparIdx > iDsetIdx)
            {
                prodpar[iProdparIdx] = dProdpar;
                iDsetIdx++;
                ppDset[iDsetIdx] = fnInitBufrProductDataset(szProduct, iMaxData);

                ppDset[iDsetIdx]->m_what.m_dProdpar[0] = dProdpar;

                iDataIdx = 0;
            }

            pData = ppDset[iDsetIdx]->m_ppProductData[iDataIdx];

            snprintf(pData->m_what.m_szQuantity, sizeof(pData->m_what.m_szQuantity), 
                     "%s", g_bufrPrdtReadTbl.m_ppTmpData[iTotalDataIdx]->m_szQuantity);
            pData->m_what.m_dGain       = 1.0;
            pData->m_what.m_dOffset     = 0.0;
            pData->m_what.m_dNodata     = DBL_MAX;
            pData->m_what.m_dUndetect   = -DBL_MAX;

            memset(&fieldInfo, 0x00, sizeof(fieldInfo));
            fnGetBufrFieldInfo(pData->m_what.m_szQuantity, &fieldInfo);

            snprintf(pData->m_szFieldName, sizeof(pData->m_szFieldName), fieldInfo.m_szFieldName);

            memset(&memInfo, 0x00, sizeof(memInfo));
            fnGetFieldMemInfo(fieldInfo.m_szFieldName, &memInfo);

            if(memInfo.m_iMemType == RDR_EN_MEM_CHAR)
            {
                pData->m_iMemType = RDR_EN_MEM_CHAR;
                pData->m_ppData_c = fnConvertBufrProductData_C(iTotalDataIdx, memInfo);
            }
            else if(memInfo.m_iMemType == RDR_EN_MEM_SHORT)
            {
                pData->m_iMemType = RDR_EN_MEM_SHORT;
                pData->m_ppData_s = fnConvertBufrProductData_S(iTotalDataIdx, memInfo);
            }
            else if(memInfo.m_iMemType == RDR_EN_MEM_FLOAT)
            {
                pData->m_iMemType = RDR_EN_MEM_FLOAT;
                pData->m_ppData_f = fnConvertBufrProductData_F(iTotalDataIdx, memInfo);
            }

            iDataIdx++;
        }
    }
    
    return 0;
}

static void fnConvertReadTblToBufrProduct(void)
{
    int                     iMaxDataset     = 0;
    int                     iMaxData        = 0;

    iMaxDataset = 0; 
    iMaxData    = 0;
    fnGetMaxDatasetCountReadTbl("PPI", &iMaxDataset, &iMaxData);
    if(iMaxDataset > 0 && iMaxData > 0)
    {
        g_pBufrProduct->m_totalProduct.m_iMaxPpi = iMaxDataset;
        g_pBufrProduct->m_totalProduct.m_ppPpi
        = (BUFR_PRODUCT_DATASET **)calloc(iMaxDataset, sizeof(BUFR_PRODUCT_DATASET *));
        if(g_pBufrProduct->m_totalProduct.m_ppPpi == NULL)
            return;

        fnConvertReadTblToBufrProductDset("PPI", g_pBufrProduct->m_totalProduct.m_ppPpi,
                                          iMaxDataset, iMaxData);
    }

    iMaxDataset = 0; 
    iMaxData    = 0;
    fnGetMaxDatasetCountReadTbl("PCAPPI", &iMaxDataset, &iMaxData);
    if(iMaxDataset > 0 && iMaxData > 0)
    {
        g_pBufrProduct->m_totalProduct.m_iMaxCappi = iMaxDataset;
        g_pBufrProduct->m_totalProduct.m_ppCappi 
        = (BUFR_PRODUCT_DATASET **)calloc(iMaxDataset, sizeof(BUFR_PRODUCT_DATASET *));
        if(g_pBufrProduct->m_totalProduct.m_ppCappi == NULL)
            return;

        fnConvertReadTblToBufrProductDset("PCAPPI", g_pBufrProduct->m_totalProduct.m_ppCappi,
                                          iMaxDataset, iMaxData);
    }

    iMaxDataset = 0; 
    iMaxData    = 0;
    fnGetMaxDatasetCountReadTbl("BASE", &iMaxDataset, &iMaxData);
    if(iMaxDataset > 0 && iMaxData > 0)
    {
        g_pBufrProduct->m_totalProduct.m_iMaxBase = iMaxDataset;
        g_pBufrProduct->m_totalProduct.m_ppBase 
        = (BUFR_PRODUCT_DATASET **)calloc(iMaxDataset, sizeof(BUFR_PRODUCT_DATASET *));
        if(g_pBufrProduct->m_totalProduct.m_ppBase == NULL)
            return;

        fnConvertReadTblToBufrProductDset("BASE", g_pBufrProduct->m_totalProduct.m_ppBase, 
                                          iMaxDataset, iMaxData);
    }

    iMaxDataset = 0; 
    iMaxData    = 0;
    fnGetMaxDatasetCountReadTbl("MAX", &iMaxDataset, &iMaxData);
    if(iMaxDataset > 0 && iMaxData > 0)
    {
        g_pBufrProduct->m_totalProduct.m_iMaxCmax = iMaxDataset;
        g_pBufrProduct->m_totalProduct.m_ppCmax 
        = (BUFR_PRODUCT_DATASET **)calloc(iMaxDataset, sizeof(BUFR_PRODUCT_DATASET *));
        if(g_pBufrProduct->m_totalProduct.m_ppCmax == NULL)
            return;

        fnConvertReadTblToBufrProductDset("MAX", g_pBufrProduct->m_totalProduct.m_ppCmax, 
                                          iMaxDataset, iMaxData);
    }

    iMaxDataset = 0; 
    iMaxData    = 0;
    fnGetMaxDatasetCountReadTbl("VIL", &iMaxDataset, &iMaxData);
    if(iMaxDataset > 0 && iMaxData > 0)
    {
        g_pBufrProduct->m_totalProduct.m_iMaxVil = iMaxDataset;
        g_pBufrProduct->m_totalProduct.m_ppVil 
        = (BUFR_PRODUCT_DATASET **)calloc(iMaxDataset, sizeof(BUFR_PRODUCT_DATASET *));
        if(g_pBufrProduct->m_totalProduct.m_ppVil == NULL)
            return;

        fnConvertReadTblToBufrProductDset("VIL", g_pBufrProduct->m_totalProduct.m_ppVil, 
                                          iMaxDataset, iMaxData);
    }

    iMaxDataset = 0; 
    iMaxData    = 0;
    fnGetMaxDatasetCountReadTbl("ETOP", &iMaxDataset, &iMaxData);
    if(iMaxDataset > 0 && iMaxData > 0)
    {
        g_pBufrProduct->m_totalProduct.m_iMaxEtop = iMaxDataset;
        g_pBufrProduct->m_totalProduct.m_ppEtop 
        = (BUFR_PRODUCT_DATASET **)calloc(iMaxDataset, sizeof(BUFR_PRODUCT_DATASET *));
        if(g_pBufrProduct->m_totalProduct.m_ppEtop == NULL)
            return;

        fnConvertReadTblToBufrProductDset("ETOP", g_pBufrProduct->m_totalProduct.m_ppEtop,
                                          iMaxDataset, iMaxData);
    }
}

static void fnCleanBufrProductReadTbl(void)
{
    int     iDataIdx        = 0;


    if(g_bufrPrdtReadTbl.m_ppTmpData != NULL)
    {
        for(iDataIdx = 0; iDataIdx < g_bufrPrdtReadTbl.m_iMaxData; iDataIdx++)
        {
            if(g_bufrPrdtReadTbl.m_ppTmpData[iDataIdx] != NULL)
            {
                if(g_bufrPrdtReadTbl.m_ppTmpData[iDataIdx]->m_ppData != NULL)
                {
                    fnFreeMatrix2D((void **)g_bufrPrdtReadTbl.m_ppTmpData[iDataIdx]->m_ppData,
                                   g_pBufrProduct->m_where.m_image_where.m_dYscale);
                }
                free(g_bufrPrdtReadTbl.m_ppTmpData[iDataIdx]);
            }
        }
        free(g_bufrPrdtReadTbl.m_ppTmpData);
    }

    memset(&g_bufrPrdtReadTbl, 0x00, sizeof(g_bufrPrdtReadTbl));
}

static char* fnSetFuseau(char *szNouveau)
{
    char    *szAncien   = NULL;

    if(szNouveau == NULL)
        return NULL;

    szAncien = getenv("TZ");
    if(szAncien != NULL)
        szAncien -= strlen("TZ=");

    putenv(szNouveau);
    tzset();
    return szAncien;
}

static varfl* fnDecompress(unsigned char *pBuf, int iLen, int iDecomp)
{
    int             iCompIdx                = 0;
    int             iVarIdx                 = 0;
    unsigned char   szStr[sizeof(varfl)]    = { 0, };
    unsigned char   *pUnCompDataBuf         = NULL;
    unsigned long   lDestBufSize            = 0;

    if(pBuf == NULL)
        return NULL;

    lDestBufSize = iDecomp;

    if((pUnCompDataBuf = (unsigned char *)calloc(lDestBufSize, sizeof(unsigned char))) == NULL)
        return NULL;

    if(uncompress(pUnCompDataBuf, &lDestBufSize, pBuf, iLen) != Z_OK)
    {
        free(pUnCompDataBuf);
        return NULL;
    }

    if(fnIsLittleEndian() == FALSE)
    {
        for(iCompIdx = 0; iCompIdx < lDestBufSize/sizeof(varfl); iCompIdx++)
        {
            for(iVarIdx = 0; iVarIdx < sizeof(varfl); iVarIdx++)
            {
                szStr[iVarIdx] = pUnCompDataBuf[iCompIdx*sizeof(varfl)+iVarIdx];
            }
            for(iVarIdx = 0; iVarIdx < sizeof(varfl); iVarIdx++)
            {
                pUnCompDataBuf[iCompIdx*sizeof(varfl)+iVarIdx] = szStr[sizeof(varfl)-1-iVarIdx];
            }
        }
    }

    return (varfl *)pUnCompDataBuf;
}


static int fnBufrCallBack_3_1_31(varfl *pVV)
{
    varfl       temp        = 0;
    int         iVVIdx      = 0;
    int         iWMO_block  = 0;
    int         iWMO_stat   = 0;
    int         iYear       = 0;
    int         iMonth      = 0;
    int         iDay        = 0;
    int         iHour       = 0;
    int         iMin        = 0;
    int         iOff        = 0;


    if(pVV == NULL)
        return -1;

    iVVIdx = 0;
    temp = pVV[iVVIdx++];
    if(temp == MISSVAL)
    {
        iVVIdx++;
    }
    else
    {
        iWMO_block = temp;
        iWMO_stat  = pVV[iVVIdx++];
        iOff = strlen(g_pBufr->m_what.m_szSource);
        snprintf(&g_pBufr->m_what.m_szSource[iOff], sizeof(g_pBufr->m_what.m_szSource)-iOff, 
                 ",WMO:%02d%03d", iWMO_block, iWMO_stat);
    }

    snprintf(g_pBufr->m_what.m_szObject,  sizeof(g_pBufr->m_what.m_szObject),  
             RDR_DF_BUFR_OBJECT_STR);
    snprintf(g_pBufr->m_what.m_szVersion, sizeof(g_pBufr->m_what.m_szVersion), 
             RDR_DF_BUFR_VERSION_STR);

    iVVIdx++;
    iYear   = pVV[iVVIdx++];
    iMonth  = pVV[iVVIdx++];
    iDay    = pVV[iVVIdx++];
    iHour   = pVV[iVVIdx++];
    iMin    = pVV[iVVIdx++];
    snprintf(g_pBufr->m_what.m_szDate, sizeof(g_pBufr->m_what.m_szDate), "%04d%02d%02d",
             iYear, iMonth, iDay);
    snprintf(g_pBufr->m_what.m_szTime, sizeof(g_pBufr->m_what.m_szTime), "%02d%02d00",
             iHour, iMin);
    
    g_pBufr->m_where.m_polar_where.m_dLat       = pVV[iVVIdx++];
    g_pBufr->m_where.m_polar_where.m_dLon       = pVV[iVVIdx++];
    g_pBufr->m_where.m_polar_where.m_dHeightM   = pVV[iVVIdx++];

    return 0;
}

static int fnBufrCallBack_How_String_General(BUFR_GENERAL_HOW *pHow, char *szHowName, char *szHowStr)
{
    if(pHow == NULL || szHowName == NULL || szHowStr == NULL)
        return FALSE;

    if(!strcmp(szHowName, "task"))
    {
        snprintf(pHow->m_szTask, sizeof(pHow->m_szTask), szHowStr);
        return TRUE;
    }
    else if(!strcmp(szHowName, "task_arg"))
    {
        snprintf(pHow->m_szTaskArg, sizeof(pHow->m_szTaskArg), szHowStr);
        return TRUE;
    }
    else if(!strcmp(szHowName, "system"))
    {
        snprintf(pHow->m_szSystem, sizeof(pHow->m_szSystem), szHowStr);
        return TRUE;
    }
    else if(!strcmp(szHowName, "task_arg"))
    {
        snprintf(pHow->m_szTaskArg, sizeof(pHow->m_szTaskArg), szHowStr);
        return TRUE;
    }
    else if(!strcmp(szHowName, "TXtype"))
    {
        snprintf(pHow->m_szTXtype, sizeof(pHow->m_szTXtype), szHowStr);
        return TRUE;
    }
    else if(!strcmp(szHowName, "poltype"))
    {
        snprintf(pHow->m_szPoltype, sizeof(pHow->m_szPoltype), szHowStr);
        return TRUE;
    }
    else if(!strcmp(szHowName, "polmode"))
    {
        snprintf(pHow->m_szPolmode, sizeof(pHow->m_szPolmode), szHowStr);
        return TRUE;
    }
    else if(!strcmp(szHowName, "software"))
    {
        snprintf(pHow->m_szSoftware, sizeof(pHow->m_szSoftware), szHowStr);
        return TRUE;
    }
    else if(!strcmp(szHowName, "sw_version"))
    {
        snprintf(pHow->m_szSW_version, sizeof(pHow->m_szSW_version), szHowStr);
        return TRUE;
    }
    else if(!strcmp(szHowName, "simulated"))
    {
        snprintf(pHow->m_bSimulated, sizeof(pHow->m_bSimulated), szHowStr);
        return TRUE;
    }

    return FALSE;
}

static int fnBufrCallBack_How_String_Radar(BUFR_RADAR_HOW *pHow, char *szHowName, char *szHowStr)
{
    if(pHow == NULL || szHowName == NULL || szHowStr == NULL)
        return FALSE;

    // empty

    return FALSE;
}

static int fnBufrCallBack_How_String_Polar(BUFR_POLAR_HOW *pHow, char *szHowName, char *szHowStr)
{
    if(pHow == NULL || szHowName == NULL || szHowStr == NULL)
        return FALSE;

    if(!strcmp(szHowName, "szmethod"))
    {
        snprintf(pHow->m_szAzmethod, sizeof(pHow->m_szAzmethod), szHowStr);
        return TRUE;
    }
    else if(!strcmp(szHowName, "elmethod"))
    {
        snprintf(pHow->m_szElmethod, sizeof(pHow->m_szElmethod), szHowStr);
        return TRUE;
    }
    else if(!strcmp(szHowName, "binmethod"))
    {
        snprintf(pHow->m_szBinmethod, sizeof(pHow->m_szBinmethod), szHowStr);
        return TRUE;
    }

    return FALSE;
}

static void fnBufrCallBack_How_String(BUFR_HOW *pHow, char *szHowName, char *szHowStr)
{
    if(pHow == NULL || szHowName == NULL || szHowStr == NULL)
        return;

    if(fnBufrCallBack_How_String_General(&pHow->m_general_how, szHowName, szHowStr) == TRUE)
        return;

    if(fnBufrCallBack_How_String_Radar(&pHow->m_radar_how, szHowName, szHowStr) == TRUE)
        return;

    // POLAR
    if(fnBufrCallBack_How_String_Polar(&pHow->m_polar_how, szHowName, szHowStr) == TRUE)
        return;

}

static int fnBufrCallBack_How_Double_General(BUFR_GENERAL_HOW *pHow, char *szHowName, varfl dHowValue)
{
    if(pHow == NULL || szHowName == NULL)
        return FALSE;

    if(!strcmp(szHowName, "startepochs"))
    {
        pHow->m_dStartepochs = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "endepochs"))
    {
        pHow->m_dEndepochs = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "zr_a"))
    {
        pHow->m_dZr_a = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "zr_b"))
    {
        pHow->m_dZr_b = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "kr_a"))
    {
        pHow->m_dKr_a = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "kr_b"))
    {
        pHow->m_dKr_b = dHowValue;
        return TRUE;
    }

    return FALSE;
}

static int fnBufrCallBack_How_Double_Radar(BUFR_RADAR_HOW *pHow, char *szHowName, varfl dHowValue)
{
    if(pHow == NULL || szHowName == NULL)
        return FALSE;

    if(!strcmp(szHowName, "breamwidth"))
    {
        pHow->m_dBeamwidth = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "wavelength"))
    {
        pHow->m_dWaveLength = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "elevspeed"))
    {
        pHow->m_dElevsSpeed = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "pulsewidth"))
    {
        pHow->m_dPulseWidth = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "RXbandwidth"))
    {
        pHow->m_dRXbandWidth = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "lowprf"))
    {
        pHow->m_dLowPrf = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "midprf"))
    {
        pHow->m_dMidPrf = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "highprf"))
    {
        pHow->m_dHighPrf = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "TXlossH"))
    {
        pHow->m_dTXlossV = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "injectlossH"))
    {
        pHow->m_dInjectlossH = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "injectlossV"))
    {
        pHow->m_dInjectlossV = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "RXlossH"))
    {
        pHow->m_dRXlossH = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "RXlossV"))
    {
        pHow->m_dRXlossV = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "radomelossH"))
    {
        pHow->m_dRadomelossH = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "radomelossV"))
    {
        pHow->m_dRadomelossV = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "antgainH"))
    {
        pHow->m_dAntgainH = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "antgainV"))
    {
        pHow->m_dAntgainV = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "beamwH"))
    {
        pHow->m_dBeamwH = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "beamwV"))
    {
        pHow->m_dBeamwV = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "gasattn"))
    {
        pHow->m_dGasattn = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "radconstH"))
    {
        pHow->m_dRadconstH = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "radconstV"))
    {
        pHow->m_dRadconstV = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "nomTXpower"))
    {
        pHow->m_dGasattn = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "powerdiff"))
    {
        pHow->m_dPowerDiff = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "phasediff"))
    {
        pHow->m_dPhaseDiff = dHowValue;
        return TRUE;
    }
    else if(!strcmp(szHowName, "NI"))
    {
        pHow->m_dNi = dHowValue;
        return TRUE;
    }

    return FALSE;
}

static int fnBufrCallBack_How_Double_Polar(BUFR_POLAR_HOW *pHow, char *szHowName, varfl dHowValue)
{
    if(pHow == NULL || szHowName == NULL)
        return FALSE;

    if(!strcmp(szHowName, "astart"))
    {
        pHow->m_dAstart = dHowValue;
        return TRUE;
    }

    return FALSE;
}

static void fnBufrCallBack_How_Double(BUFR_HOW *pHow, char *szHowName, varfl dHowValue)
{
    if(pHow == NULL || szHowName == NULL)
        return;

    if(fnBufrCallBack_How_Double_General(&pHow->m_general_how, szHowName, dHowValue) == TRUE)
        return;

    if(fnBufrCallBack_How_Double_Radar(&pHow->m_radar_how, szHowName, dHowValue) == TRUE)
        return;

    // POLAR
    if(fnBufrCallBack_How_Double_Polar(&pHow->m_polar_how, szHowName, dHowValue) == TRUE)
        return;
}

static void fnBufrCallBack_How(BUFR_HOW *pHow, varfl *pVV, int *pVVIdx)
{
    int         iVVIdx                                      = 0;
    int         iHowSCnt                                    = 0;
    int         iHowSIdx                                    = 0;
    int         iHowDCnt                                    = 0;
    int         iHowDIdx                                    = 0;
    int         iByteIdx                                    = 0;
    char        szHowName[RDR_DF_BUFR_HOW_NAME_LENGTH+1]    = "";
    char        szHowStr[RDR_DF_BUFR_HOW_STR_LENGTH+1]      = "";
    char        *pHowDouble                                 = NULL;
    varfl       dHowValue                                   = 0.0;

    if(pHow == NULL || pVV == NULL || pVVIdx == NULL)
        return;

    iVVIdx = *pVVIdx;

    iHowSCnt = pVV[iVVIdx++];
    for(iHowSIdx = 0; iHowSIdx < iHowSCnt; iHowSIdx++)
    {
        for(iByteIdx = 0; iByteIdx < RDR_DF_BUFR_HOW_NAME_LENGTH; iByteIdx++)
        {
            szHowName[iByteIdx] =  pVV[iVVIdx++];
        }
        szHowName[RDR_DF_BUFR_HOW_NAME_LENGTH] = 0;
        for(iByteIdx = RDR_DF_BUFR_HOW_NAME_LENGTH-1; iByteIdx >= 0; iByteIdx--)
        {
            if(szHowName[iByteIdx] == ' ')
                szHowName[iByteIdx] = 0;
            else
                break;
        }

        for(iByteIdx = 0; iByteIdx < RDR_DF_BUFR_HOW_STR_LENGTH; iByteIdx++)
        {
            szHowStr[iByteIdx] =  pVV[iVVIdx++];
        }
        szHowName[RDR_DF_BUFR_HOW_STR_LENGTH] = 0;
        for(iByteIdx = RDR_DF_BUFR_HOW_STR_LENGTH-1; iByteIdx >= 0; iByteIdx--)
        {
            if(szHowStr[iByteIdx] == ' ')
                szHowStr[iByteIdx] = 0;
            else
                break;
        }
        fnBufrCallBack_How_String(pHow, szHowName, szHowStr);
    }

    iHowDCnt = pVV[iVVIdx++];
    for(iHowDIdx = 0; iHowDIdx < iHowDCnt; iHowDIdx++)
    {
        for(iByteIdx = 0; iByteIdx < RDR_DF_BUFR_HOW_NAME_LENGTH; iByteIdx++)
        {
            szHowName[iByteIdx] =  pVV[iVVIdx++];
        }
        szHowName[RDR_DF_BUFR_HOW_NAME_LENGTH] = 0;
        for(iByteIdx = RDR_DF_BUFR_HOW_NAME_LENGTH-1; iByteIdx >= 0; iByteIdx--)
        {
            if(szHowName[iByteIdx] == ' ')
                szHowName[iByteIdx] = 0;
            else
                break;
        }

        dHowValue = 0.0;
        pHowDouble = (char *)&dHowValue;
        for(iByteIdx = 0; iByteIdx < 8; iByteIdx++)
        {
            pHowDouble[iByteIdx] = pVV[iVVIdx++];
        }
        fnBufrCallBack_How_Double(pHow, szHowName, dHowValue);
    }

    *pVVIdx = iVVIdx;
}

static void fnBufrCallBack_Dset_What_V2_0(BUFR_DATASET_WHAT *pWhat, varfl *pVV, int *pVVIdx)
{
    int             iVVIdx      = 0;
    char            *szTimeZone = NULL;
    time_t          tTempTime   = 0;
    struct  tm      localTm;

    if(pWhat == NULL || pVV == NULL || pVVIdx == NULL)
        return;

    iVVIdx = *pVVIdx;

    szTimeZone = fnSetFuseau("TZ=UTC");
    localTm.tm_year = pVV[iVVIdx++] - 1900;
    localTm.tm_mon  = pVV[iVVIdx++] - 1;
    localTm.tm_mday = pVV[iVVIdx++];
    localTm.tm_hour = pVV[iVVIdx++];
    localTm.tm_min  = pVV[iVVIdx++];
    localTm.tm_sec  = pVV[iVVIdx++];
    localTm.tm_wday = 0;
    localTm.tm_yday = 0;
    localTm.tm_isdst= 0;
    tTempTime = mktime(&localTm);
    strftime(pWhat->m_szStartDate, sizeof(pWhat->m_szStartDate), "%Y%m%d", &localTm);
    strftime(pWhat->m_szStartTime, sizeof(pWhat->m_szStartTime), "%H%m%S", &localTm);

    localTm.tm_year = pVV[iVVIdx++] - 1900;
    localTm.tm_mon  = pVV[iVVIdx++] - 1;
    localTm.tm_mday = pVV[iVVIdx++];
    localTm.tm_hour = pVV[iVVIdx++];
    localTm.tm_min  = pVV[iVVIdx++];
    localTm.tm_sec  = pVV[iVVIdx++];
    localTm.tm_wday = 0;
    localTm.tm_yday = 0;
    localTm.tm_isdst= 0;
    tTempTime = mktime(&localTm);
    strftime(pWhat->m_szEndDate, sizeof(pWhat->m_szEndDate), "%Y%m%d", &localTm);
    strftime(pWhat->m_szEndTime, sizeof(pWhat->m_szEndTime), "%H%m%S", &localTm);
    fnSetFuseau(szTimeZone);

    iVVIdx++; // 2.0

    snprintf(pWhat->m_szProduct, sizeof(pWhat->m_szProduct), "SCAN");

    *pVVIdx = iVVIdx;
}

static void fnBufrCallBack_Dset_What_V2_1(BUFR_DATASET_WHAT *pWhat, varfl *pVV, int *pVVIdx)
{
    int             iVVIdx      = 0;
    int             iTempIdx    = 0;
    char            *szTimeZone = NULL;
    time_t          tTempTime   = 0;
    struct  tm      localTm;

    if(pWhat == NULL || pVV == NULL || pVVIdx == NULL)
        return;

    iVVIdx = *pVVIdx;

    szTimeZone = fnSetFuseau("TZ=UTC");
    localTm.tm_year = pVV[iVVIdx++] - 1900;
    localTm.tm_mon  = pVV[iVVIdx++] - 1;
    localTm.tm_mday = pVV[iVVIdx++];
    localTm.tm_hour = pVV[iVVIdx++];
    localTm.tm_min  = pVV[iVVIdx++];
    localTm.tm_sec  = pVV[iVVIdx++];
    localTm.tm_wday = 0;
    localTm.tm_yday = 0;
    localTm.tm_isdst= 0;
    tTempTime = mktime(&localTm);
    strftime(pWhat->m_szStartDate, sizeof(pWhat->m_szStartDate), "%Y%m%d", &localTm);
    strftime(pWhat->m_szStartTime, sizeof(pWhat->m_szStartTime), "%H%m%S", &localTm);

    localTm.tm_year = pVV[iVVIdx++] - 1900;
    localTm.tm_mon  = pVV[iVVIdx++] - 1;
    localTm.tm_mday = pVV[iVVIdx++];
    localTm.tm_hour = pVV[iVVIdx++];
    localTm.tm_min  = pVV[iVVIdx++];
    localTm.tm_sec  = pVV[iVVIdx++];
    localTm.tm_wday = 0;
    localTm.tm_yday = 0;
    localTm.tm_isdst= 0;
    tTempTime = mktime(&localTm);
    strftime(pWhat->m_szEndDate, sizeof(pWhat->m_szEndDate), "%Y%m%d", &localTm);
    strftime(pWhat->m_szEndTime, sizeof(pWhat->m_szEndTime), "%H%m%S", &localTm);
    fnSetFuseau(szTimeZone);

    for(iTempIdx = 0; iTempIdx < 6; iTempIdx++)
    {
        pWhat->m_szProduct[iTempIdx] = pVV[iVVIdx++];
    }
    for(iTempIdx = 6-1; iTempIdx >= 0; iTempIdx--)
    {
        if(pWhat->m_szProduct[iTempIdx] == ' ')
            pWhat->m_szProduct[iTempIdx] = 0;
        else
            break;
    }

    *pVVIdx = iVVIdx;
}

static void fnBufrCallBack_Data_What_V2_0(BUFR_DATASET_WHAT *pWhat, varfl *pVV, int *pVVIdx)
{
    int             iVVIdx                      = 0;
    int             iParam                      = 0;

    if(pWhat == NULL || pVV == NULL || pVVIdx == NULL)
        return;

    iVVIdx = *pVVIdx;

    iParam = pVV[iVVIdx++];
    if(iParam == 0)
        snprintf(pWhat->m_szQuantity, sizeof(pWhat->m_szQuantity), "DBZH");
    else if(iParam == 40)
        snprintf(pWhat->m_szQuantity, sizeof(pWhat->m_szQuantity), "VRAD");
    else if(iParam == 91)
        snprintf(pWhat->m_szQuantity, sizeof(pWhat->m_szQuantity), "TH");
    else if(iParam == 92)
        snprintf(pWhat->m_szQuantity, sizeof(pWhat->m_szQuantity), "WRAD");

    pWhat->m_dGain      = 1.0;
    pWhat->m_dOffset    = 0.;
    pWhat->m_dNodata    = DBL_MAX;
    pWhat->m_dUndetect  = -DBL_MAX;

    *pVVIdx = iVVIdx;
}

static void fnBufrCallBack_Data_What_V2_1(BUFR_DATASET_WHAT *pWhat, varfl *pVV, int *pVVIdx)
{
    int             iVVIdx                      = 0;
    int             iTempIdx                    = 0;

    if(pWhat == NULL || pVV == NULL || pVVIdx == NULL)
        return;

    iVVIdx = *pVVIdx;

    for(iTempIdx = 0; iTempIdx < 6; iTempIdx++)
    {
        pWhat->m_szQuantity[iTempIdx] = pVV[iVVIdx++];
    }
    for(iTempIdx = 5; iTempIdx >= 0; iTempIdx--)
    {
        if(pWhat->m_szQuantity[iTempIdx] == ' ')
            pWhat->m_szQuantity[iTempIdx] = 0;
        else
            break;
    }

    pWhat->m_dGain      = 1.0;
    pWhat->m_dOffset    = 0.;
    pWhat->m_dNodata    = DBL_MAX;
    pWhat->m_dUndetect  = -DBL_MAX;

    *pVVIdx = iVVIdx;
}

static void fnBufrCallBack_Dset_Where(BUFR_WHERE *pWhere, varfl *pVV, int *pVVIdx)
{
    int             iVVIdx      = 0;

    if(pWhere == NULL || pVV == NULL || pVVIdx == NULL)
        return;

    iVVIdx = *pVVIdx;

    pWhere->m_polar_where.m_dElangle = pVV[iVVIdx++];
    pWhere->m_polar_where.m_nBins    = pVV[iVVIdx++];
    pWhere->m_polar_where.m_dRScale  = pVV[iVVIdx++];
    //pWhere->m_polar_where.m_dRstart  = pVV[iVVIdx++];
    pWhere->m_polar_where.m_dRstart  = pVV[iVVIdx++]/1000.;
    pWhere->m_polar_where.m_nRays    = pVV[iVVIdx++];
    pWhere->m_polar_where.m_lA1gate  = pVV[iVVIdx++];

    *pVVIdx = iVVIdx;
}

static int fnBufrCallBack_3_21_203(varfl *pVV)
{
    BUFR_DATASET    *pBufrDset  = NULL;
    BUFR_DATA       *pBufrData  = NULL;
    int             iDsetIdx    = 0;
    int             iDataIdx    = 0;
    int             iVVIdx      = 0;
    int             iCompress   = 0;
    int             iDecomp     = 0;
    int             iIterCnt    = 0;
    int             iIterIdx    = 0;
    int             iCompCnt    = 0;
    int             iCompIdx    = 0;
    int             iCompAll    = 0;
    unsigned char   *pTemp      = NULL;
    varfl           *pTempData  = NULL;
    int             iYdim       = 0;
    int             iXdim       = 0;
    int             iYIdx       = 0;
    int             iXIdx       = 0;
    varfl           fData       = 0.0;

    if(pVV == NULL)
        return -1;

    g_pBufr->m_iMaxDataset = pVV[iVVIdx++];
    g_pBufr->m_ppDataset 
    = (BUFR_DATASET **)calloc(g_pBufr->m_iMaxDataset, sizeof(BUFR_DATASET *));
    if(g_pBufr->m_ppDataset == NULL)
        return -1;

    for(iDsetIdx = 0; iDsetIdx < g_pBufr->m_iMaxDataset; iDsetIdx++)
    {
        g_pBufr->m_ppDataset[iDsetIdx] = (BUFR_DATASET *)calloc(1, sizeof(BUFR_DATASET));
        if(g_pBufr->m_ppDataset[iDsetIdx] == NULL)
            return -1;

        pBufrDset = g_pBufr->m_ppDataset[iDsetIdx];

        fnBufrCallBack_Dset_What_V2_0(&pBufrDset->m_what, pVV, &iVVIdx);
        fnBufrCallBack_Dset_Where(&pBufrDset->m_where, pVV, &iVVIdx);

        pBufrDset->m_iMaxData = pVV[iVVIdx++];
        pBufrDset->m_ppData = (BUFR_DATA **)calloc(pBufrDset->m_iMaxData, sizeof(BUFR_DATA *));
        if(pBufrDset->m_ppData == NULL)
            return -1;

        for(iDataIdx = 0; iDataIdx < pBufrDset->m_iMaxData; iDataIdx++)
        {
            pBufrDset->m_ppData[iDataIdx] = (BUFR_DATA *)calloc(1, sizeof(BUFR_DATA));
            if(pBufrDset->m_ppData[iDataIdx] == NULL)
                return -1;

            pBufrData = pBufrDset->m_ppData[iDataIdx];
            
            fnBufrCallBack_Data_What_V2_0(&pBufrData->m_what, pVV, &iVVIdx);
            pBufrData->m_where = pBufrDset->m_where;

            iCompress = pVV[iVVIdx++];
            if(iCompress == 0)
                ;
            
            iYdim = pBufrDset->m_where.m_polar_where.m_nRays;
            iXdim = pBufrDset->m_where.m_polar_where.m_nBins;

            /* zlib compression */
            iDecomp = iYdim * iXdim * sizeof(varfl);
            iIterCnt = pVV[iVVIdx++];
            
            pTemp = NULL;
            pTemp = (unsigned char *)calloc(iIterCnt*RDR_DF_BUFR_ITER_SIZE, sizeof(unsigned char));
            if(pTemp == NULL)
                return -1;

            iCompAll = 0;
            for(iIterIdx = 0; iIterIdx < iIterCnt; iIterIdx++)
            {
                iCompCnt = pVV[iVVIdx++];
                for(iCompIdx = 0; iCompIdx < iCompCnt; iCompIdx++)
                {
                    pTemp[iCompAll++] 
                    = (pVV[iVVIdx+iCompIdx] == MISSVAL ? RDR_DF_BUFR_MISS_VALUE : pVV[iVVIdx+iCompIdx]);
                }
                iVVIdx += iCompCnt;
            }

            pTempData = NULL;
            pTempData = fnDecompress(pTemp, iCompAll, iDecomp);
            if(pTempData == NULL)
            {
                free(pTemp);
                return -1;
            }
 
            pBufrData->m_ppData = fnMakeMatrix2D_F(iYdim, iXdim);
            if(pBufrData->m_ppData == NULL)
            {
                free(pTempData);
                free(pTemp);
                return -1;
            }

            for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
            {
                for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
                {
                    fData = pTempData[iYIdx*iXdim+iXIdx];

                    if(fabs(fData - pBufrData->m_what.m_dUndetect) < RDR_DF_ERR_RANGE_D)
                        pBufrData->m_ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
                    else if(fabs(fData - pBufrData->m_what.m_dNodata) < RDR_DF_ERR_RANGE_D)
                        pBufrData->m_ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
                    else
                    {
                        pBufrData->m_ppData[iYIdx][iXIdx] 
                        = (float)((fData * pBufrData->m_what.m_dGain) + pBufrData->m_what.m_dOffset);
                    }
                }
            }

            free(pTempData);
            free(pTemp);
        }
    }

    return 0;
}

static int fnBufrCallBack_3_21_207(varfl *pVV)
{
    BUFR_DATASET    *pBufrDset  = NULL;
    BUFR_DATA       *pBufrData  = NULL;
    int             iDsetIdx    = 0;
    int             iDataIdx    = 0;
    int             iVVIdx      = 0;
    int             iCompress   = 0;
    int             iDecomp     = 0;
    int             iIterCnt    = 0;
    int             iIterIdx    = 0;
    int             iCompCnt    = 0;
    int             iCompIdx    = 0;
    int             iCompAll    = 0;
    unsigned char   *pTemp      = NULL;
    varfl           *pTempData  = NULL;
    int             iYdim       = 0;
    int             iXdim       = 0;
    int             iYIdx       = 0;
    int             iXIdx       = 0;
    varfl           fData       = 0.0;

    if(pVV == NULL)
        return -1;

    fnBufrCallBack_How(&g_pBufr->m_how, pVV, &iVVIdx);

    g_pBufr->m_iMaxDataset = pVV[iVVIdx++];
    g_pBufr->m_ppDataset = (BUFR_DATASET **)calloc(g_pBufr->m_iMaxDataset, sizeof(BUFR_DATASET *));
    if(g_pBufr->m_ppDataset == NULL)
        return -1;

    for(iDsetIdx = 0; iDsetIdx < g_pBufr->m_iMaxDataset; iDsetIdx++)
    {
        g_pBufr->m_ppDataset[iDsetIdx] = (BUFR_DATASET *)calloc(1, sizeof(BUFR_DATASET));
        if(g_pBufr->m_ppDataset[iDsetIdx] == NULL)
            return -1;

        pBufrDset = g_pBufr->m_ppDataset[iDsetIdx];

        fnBufrCallBack_How(&pBufrDset->m_how, pVV, &iVVIdx);
        fnBufrCallBack_Dset_What_V2_1(&pBufrDset->m_what, pVV, &iVVIdx);
        fnBufrCallBack_Dset_Where(&pBufrDset->m_where, pVV, &iVVIdx);

        pBufrDset->m_iMaxData = pVV[iVVIdx++];
        pBufrDset->m_ppData = (BUFR_DATA **)calloc(pBufrDset->m_iMaxData, sizeof(BUFR_DATA *));
        if(pBufrDset->m_ppData == NULL)
            return -1;

        for(iDataIdx = 0; iDataIdx < pBufrDset->m_iMaxData; iDataIdx++)
        {
            pBufrDset->m_ppData[iDataIdx] = (BUFR_DATA *)calloc(1, sizeof(BUFR_DATA));
            if(pBufrDset->m_ppData[iDataIdx] == NULL)
                return -1;

            pBufrData = pBufrDset->m_ppData[iDataIdx];
            
            fnBufrCallBack_How(&pBufrData->m_how, pVV, &iVVIdx);
            fnBufrCallBack_Data_What_V2_1(&pBufrData->m_what, pVV, &iVVIdx);
            pBufrData->m_where = pBufrDset->m_where;

            iCompress = pVV[iVVIdx++];
            if(iCompress == 0)
                ;
            
            iYdim = pBufrDset->m_where.m_polar_where.m_nRays;
            iXdim = pBufrDset->m_where.m_polar_where.m_nBins;

            /* zlib compression */
            iDecomp = iYdim * iXdim * sizeof(varfl);
            iIterCnt = pVV[iVVIdx++];
            
            pTemp = NULL;
            pTemp = (unsigned char *)calloc(iIterCnt*RDR_DF_BUFR_ITER_SIZE, sizeof(unsigned char));
            if(pTemp == NULL)
                return -1;

            iCompAll = 0;
            for(iIterIdx = 0; iIterIdx < iIterCnt; iIterIdx++)
            {
                iCompCnt = pVV[iVVIdx++];
                for(iCompIdx = 0; iCompIdx < iCompCnt; iCompIdx++)
                {
                    pTemp[iCompAll++] 
                    = (pVV[iVVIdx+iCompIdx] == MISSVAL ? RDR_DF_BUFR_MISS_VALUE : pVV[iVVIdx+iCompIdx]);
                }
                iVVIdx += iCompCnt;
            }

            pTempData = NULL;
            pTempData = fnDecompress(pTemp, iCompAll, iDecomp);
            if(pTempData == NULL)
            {
                free(pTemp);
                return -1;
            }
 
            pBufrData->m_ppData = fnMakeMatrix2D_F(iYdim, iXdim);
            if(pBufrData->m_ppData == NULL)
            {
                free(pTempData);
                free(pTemp);
                return -1;
            }

            for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
            {
                for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
                {
                    fData = pTempData[iYIdx*iXdim+iXIdx];

                    if(fabs(fData - pBufrData->m_what.m_dUndetect) < RDR_DF_ERR_RANGE_D)
                        pBufrData->m_ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
                    else if(fabs(fData - pBufrData->m_what.m_dNodata) < RDR_DF_ERR_RANGE_D)
                        pBufrData->m_ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
                    else
                    {
                        pBufrData->m_ppData[iYIdx][iXIdx] 
                        = (float)((fData * pBufrData->m_what.m_dGain) + pBufrData->m_what.m_dOffset);
                    }
                }
            }

            free(pTempData);
            free(pTemp);
        }
    }

    return 0;
}

static int fnBufrCallBack_3_21_204(varfl *pVV)
{
    int             iVVIdx                  = 0;
    int             iStationCnt             = 0;
    int             iStationIdx             = 0;
    int             iTempIdx                = 0;
    char            szIdentifier[3+1]       = "";
    char            szSource[16+1]          = "";
    int             iOff                    = 0;
    int             iLen                    = 0;

    if(pVV == NULL)
        return -1;

    iStationCnt = pVV[iVVIdx++] + 1; /* WMO station comes after */
    for(iStationIdx = 0; iStationIdx < iStationCnt-1; iStationIdx++)
    {
        for(iTempIdx = 0; iTempIdx < 3; iTempIdx++)
        {
            szIdentifier[iTempIdx] = pVV[iVVIdx++];
        }
        szIdentifier[3] = 0;
        for(iTempIdx = 0; iTempIdx < 16; iTempIdx++)
        {
            szSource[iTempIdx] = pVV[iVVIdx++];
        }
        szSource[16] = 0;
        for(iTempIdx = 16-1; iTempIdx >= 0; iTempIdx--)
        {
            if(szSource[iTempIdx] == ' ')
                szSource[iTempIdx] = 0;
            else
                break;
        }
        iLen = snprintf(&g_pBufr->m_what.m_szSource[iOff], sizeof(g_pBufr->m_what.m_szSource)-iOff,
                        "%s:%s", szIdentifier, szSource);
        iOff += iLen;

        if(iStationIdx < iStationCnt-1-1)
        {
            iLen = snprintf(&g_pBufr->m_what.m_szSource[iOff], sizeof(g_pBufr->m_what.m_szSource)-iOff,
                            ",");
            iOff += iLen;
        }
    }

    return 0;
}

static int fnBufrCallBack_V2_0(varfl val, int ind)
{
    dd          *pFxy       = NULL;
    bufrval_t   *pBufrVal   = NULL;
    varfl       *pVV        = NULL;

    /* do nothing if data modification descriptor or replication descriptor */
    if(ind == _desc_special)
    {
        if(des[ind]->el->d.f != 2)
            return 1;
    }

    /* sequence descriptor */
    if(des[ind]->id == SEQDESC)
    {
        pFxy =  &(des[ind]->seq->d);

        /* open array for values */
        pBufrVal = bufr_open_val_array();
        if(pBufrVal == NULL)
            return 0;

        /* decode sequence to global array */
        if(!bufr_parse_out(des[ind]->seq->del, 0, des[ind]->seq->nel - 1, bufr_val_to_global, 0))
        {
            bufr_close_val_array();
            return 0;
        }
        pVV = pBufrVal->vals;
        
        /* WMO block and station number */
        if(bufr_check_fxy(pFxy, 3,1,31))
        {
            if(fnBufrCallBack_3_1_31(pVV) < 0)
            {   bufr_close_val_array(); return 0; }
        }
        /* ODIM */
        else if(bufr_check_fxy(pFxy, 3,21,203))
        {
            if(fnBufrCallBack_3_21_203(pVV) < 0)
            {   bufr_close_val_array(); return 0; }
        }
        /* ODIM stations */
        else if(bufr_check_fxy(pFxy, 3,21,204))
        {
            if(fnBufrCallBack_3_21_204(pVV) < 0)
            {   bufr_close_val_array(); return 0; }
        }
        else
        {
            fprintf(stderr, "%s : f=%d x=%d y=%d\n", __func__, pFxy->f, pFxy->x, pFxy->y);
        }
        bufr_close_val_array();
    }
    /* element descriptor */
    else if(des[ind]->id == ELDESC)
    {
        fprintf(stderr, "%s : ELDESC\n", __func__);
    }
    else
    {
        fprintf(stderr, "%s : Unknown\n", __func__);
    }

    return 1;
}

static int fnBufrCallBack_V2_1(varfl val, int ind)
{
    dd          *pFxy       = NULL;
    bufrval_t   *pBufrVal   = NULL;
    varfl       *pVV        = NULL;

    /* do nothing if data modification descriptor or replication descriptor */
    if(ind == _desc_special)
    {
        if(des[ind]->el->d.f != 2)
            return 1;
    }

    /* sequence descriptor */
    if(des[ind]->id == SEQDESC)
    {
        pFxy =  &(des[ind]->seq->d);

        /* open array for values */
        pBufrVal = bufr_open_val_array();
        if(pBufrVal == NULL)
            return 0;

        /* decode sequence to global array */
        if(!bufr_parse_out(des[ind]->seq->del, 0, des[ind]->seq->nel - 1, bufr_val_to_global, 0))
        {
            bufr_close_val_array();
            return 0;
        }
        pVV = pBufrVal->vals;
        
        /* WMO block and station number */
        if(bufr_check_fxy(pFxy, 3,1,31))
        {
            if(fnBufrCallBack_3_1_31(pVV) < 0)
            {   bufr_close_val_array(); return 0; }
        }
        /* ODIM */
        else if(bufr_check_fxy(pFxy, 3,21,207))
        {
            if(fnBufrCallBack_3_21_207(pVV) < 0)
            {   bufr_close_val_array(); return 0; }
        }
        /* ODIM stations */
        else if(bufr_check_fxy(pFxy, 3,21,204))
        {
            if(fnBufrCallBack_3_21_204(pVV) < 0)
            {   bufr_close_val_array(); return 0; }
        }
        else
        {
            fprintf(stderr, "%s : f=%d x=%d y=%d\n", __func__, pFxy->f, pFxy->x, pFxy->y);
        }
        bufr_close_val_array();
    }
    /* element descriptor */
    else if(des[ind]->id == ELDESC)
    {
        fprintf(stderr, "%s : ELDESC\n", __func__);
    }
    else
    {
        fprintf(stderr, "%s : Unknown\n", __func__);
    }

    return 1;
}

// PRODUCT

static int fnBufrProductCallBack_3_1_11(varfl *pVV)
{
    if(pVV == NULL)
        return -1;

    snprintf(g_pBufrProduct->m_what.m_szDate, sizeof(g_pBufrProduct->m_what.m_szDate), 
             "%04d%02d%02d", (int)pVV[0], (int)pVV[1], (int)pVV[2]);

    return 0;
}

static int fnBufrProductCallBack_3_1_13(varfl *pVV)
{
    if(pVV == NULL)
        return -1;

    snprintf(g_pBufrProduct->m_what.m_szTime, sizeof(g_pBufrProduct->m_what.m_szTime), 
             "%02d%02d%02d", (int)pVV[0], (int)pVV[1], (int)pVV[2]);

    return 0;
}

static int fnBufrProductCallBack_3_1_21(varfl *pVV)
{
    if(pVV == NULL)
        return -1;

    if(g_bufrPrdtReadTbl.m_iLonLatCnt == 0)
    {
        g_pBufrProduct->m_where.m_image_where.m_UL_lat = pVV[0];
        g_pBufrProduct->m_where.m_image_where.m_UL_lon = pVV[1];
    }
    else if(g_bufrPrdtReadTbl.m_iLonLatCnt == 1)
    {
        g_pBufrProduct->m_where.m_image_where.m_UR_lat = pVV[0];
        g_pBufrProduct->m_where.m_image_where.m_UR_lon = pVV[1];
    }
    else if(g_bufrPrdtReadTbl.m_iLonLatCnt == 2)
    {
        g_pBufrProduct->m_where.m_image_where.m_LR_lat = pVV[0];
        g_pBufrProduct->m_where.m_image_where.m_LR_lon = pVV[1];
    }
    else if(g_bufrPrdtReadTbl.m_iLonLatCnt == 3)
    {
        g_pBufrProduct->m_where.m_image_where.m_LL_lat = pVV[0];
        g_pBufrProduct->m_where.m_image_where.m_LL_lon = pVV[1];
    }

    g_bufrPrdtReadTbl.m_iLonLatCnt++;

    return 0;
}

static int fnBufrProductCallBack_3_1_204(varfl *pVV)
{
    int             iVVIdx                  = 0;
    int             iStationCnt             = 0;
    int             iStationIdx             = 0;
    int             iTempIdx                = 0;
    char            szIdentifier[3+1]       = "";
    char            szSource[16+1]          = "";
    int             iOff                    = 0;
    int             iLen                    = 0;

    if(pVV == NULL)
        return -1;

    iStationCnt = pVV[iVVIdx++];
    for(iStationIdx = 0; iStationIdx < iStationCnt; iStationIdx++)
    {
        for(iTempIdx = 0; iTempIdx < 3; iTempIdx++)
        {
            szIdentifier[iTempIdx] = pVV[iVVIdx++];
        }
        szIdentifier[3] = 0;
        for(iTempIdx = 0; iTempIdx < 16; iTempIdx++)
        {
            szSource[iTempIdx] = pVV[iVVIdx++];
        }
        szSource[16] = 0;
        for(iTempIdx = 16-1; iTempIdx >= 0; iTempIdx--)
        {
            if(szSource[iTempIdx] == ' ')
                szSource[iTempIdx] = 0;
            else
                break;
        }
        iLen = snprintf(&g_pBufrProduct->m_what.m_szSource[iOff], 
                        sizeof(g_pBufrProduct->m_what.m_szSource)-iOff,
                        "%s:%s", szIdentifier, szSource);
        iOff += iLen;

        if(iStationIdx < iStationCnt-1-1)
        {
            iLen = snprintf(&g_pBufrProduct->m_what.m_szSource[iOff], 
                            sizeof(g_pBufrProduct->m_what.m_szSource)-iOff,
                            ",");
            iOff += iLen;
        }
    }

    return 0;
}

static int fnBufrProductCallBack_3_21_206(varfl *pVV)
{
    BUFR_PRODUCT_READ_TMP   *pTmpData   = NULL;
    int                     iVVIdx      = 0;
    int                     iCompress   = 0;
    int                     iDecomp     = 0;
    int                     iIterCnt    = 0;
    int                     iIterIdx    = 0;
    int                     iCompCnt    = 0;
    int                     iCompIdx    = 0;
    int                     iCompAll    = 0;
    unsigned char           *pTemp      = NULL;
    varfl                   *pTempData  = NULL;
    int                     iYdim       = 0;
    int                     iXdim       = 0;
    int                     iYIdx       = 0;
    int                     iXIdx       = 0;
    varfl                   dData       = 0.0;

    if(pVV == NULL)
        return -1;

    iCompress = pVV[iVVIdx++];
    if(iCompress == 0)
        ;
    
    iYdim = g_pBufrProduct->m_where.m_image_where.m_lYsize;
    iXdim = g_pBufrProduct->m_where.m_image_where.m_lXsize;

    /* zlib compression */
    iDecomp = iYdim * iXdim * sizeof(varfl);
    iIterCnt = pVV[iVVIdx++];
    
    pTemp = NULL;
    pTemp = (unsigned char *)calloc(iIterCnt*RDR_DF_BUFR_ITER_SIZE, sizeof(unsigned char));
    if(pTemp == NULL)
        return -1;

    iCompAll = 0;
    for(iIterIdx = 0; iIterIdx < iIterCnt; iIterIdx++)
    {
        iCompCnt = pVV[iVVIdx++];
        for(iCompIdx = 0; iCompIdx < iCompCnt; iCompIdx++)
        {
            pTemp[iCompAll++] 
            = (pVV[iVVIdx+iCompIdx] == MISSVAL ? RDR_DF_BUFR_MISS_VALUE : pVV[iVVIdx+iCompIdx]);
        }
        iVVIdx += iCompCnt;
    }

    pTempData = NULL;
    pTempData = fnDecompress(pTemp, iCompAll, iDecomp);
    if(pTempData == NULL)
    {
        free(pTemp);
        return -1;
    }

    pTmpData = g_bufrPrdtReadTbl.m_ppTmpData[g_bufrPrdtReadTbl.m_iCurData];
    pTmpData->m_ppData = fnMakeMatrix2D_F(iYdim, iXdim);
    if(pTmpData->m_ppData == NULL)
    {
        free(pTempData);
        free(pTemp);
        return -1;
    }

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
        {
            dData = pTempData[iYIdx*iXdim+iXIdx];

            if(fabs(dData - (-DBL_MAX)) < RDR_DF_ERR_RANGE_D)
                pTmpData->m_ppData[iYIdx][iXIdx] = RDR_DF_BAD_VALUE_F;
            else if(fabs(dData - (DBL_MAX)) < RDR_DF_ERR_RANGE_D)
                pTmpData->m_ppData[iYIdx][iXIdx] = RDR_DF_OUT_BOUND_F;
            else
                pTmpData->m_ppData[iYIdx][iXIdx] = (float)dData;
        }
    }

    free(pTempData);
    free(pTemp);

    g_bufrPrdtReadTbl.m_iCurData++;

    return 0;
}

static int bufr_char_0_29_205(varfl val, int ind)
{
    int             iLen    = 0;

    iLen = strlen(g_pBufrProduct->m_where.m_image_where.m_szProjdef);

    g_pBufrProduct->m_where.m_image_where.m_szProjdef[iLen] = val;

    return 1;
}

static int bufr_char_0_30_199(varfl val, int ind)
{
    int                     iLen            = 0;
    BUFR_PRODUCT_READ_TMP   *pCurTmpData    = NULL;

    pCurTmpData = g_bufrPrdtReadTbl.m_ppTmpData[g_bufrPrdtReadTbl.m_iCurData];

    iLen = strlen(pCurTmpData->m_szProduct);

    pCurTmpData->m_szProduct[iLen] = val;

    return 1;
}

static int bufr_char_0_30_200(varfl val, int ind)
{
    int                     iLen            = 0;
    BUFR_PRODUCT_READ_TMP   *pCurTmpData    = NULL;

    pCurTmpData = g_bufrPrdtReadTbl.m_ppTmpData[g_bufrPrdtReadTbl.m_iCurData];

    iLen = strlen(pCurTmpData->m_szQuantity);

    pCurTmpData->m_szQuantity[iLen] = val;

    return 1;
}

static int fnBufrProductCallBack_0_29_205(dd *pFxy)
{
    if(pFxy == NULL)
        return -1;

    bufr_parse_out(pFxy, 0, 0, bufr_char_0_29_205, 0);

    return 0;
}

static int fnBufrProductCallBack_0_30_199(dd *pFxy)
{
    if(pFxy == NULL)
        return -1;

    bufr_parse_out(pFxy, 0, 0, bufr_char_0_30_199, 0);

    return 0;
}

static int fnBufrProductCallBack_0_30_200(dd *pFxy)
{
    if(pFxy == NULL)
        return -1;

    bufr_parse_out(pFxy, 0, 0, bufr_char_0_30_200, 0);

    return 0;
}

static int fnBufrProductCallBack_0_5_33(varfl val)
{
    g_pBufrProduct->m_where.m_image_where.m_dXscale = val/1000.;

    return 0;
}

static int fnBufrProductCallBack_0_6_33(varfl val)
{
    g_pBufrProduct->m_where.m_image_where.m_dYscale = val/1000.;

    return 0;
}

static int fnBufrProductCallBack_0_30_21(varfl val)
{
    g_pBufrProduct->m_where.m_image_where.m_lXsize = (long)val;

    return 0;
}

static int fnBufrProductCallBack_0_30_22(varfl val)
{
    g_pBufrProduct->m_where.m_image_where.m_lYsize = (long)val;

    return 0;
}

static int fnBufrProductCallBack_0_29_193(varfl val)
{
    g_pBufrProduct->m_where.m_polar_where.m_dLon = val;

    return 0;
}

static int fnBufrProductCallBack_0_29_194(varfl val)
{
    g_pBufrProduct->m_where.m_polar_where.m_dLat = val;

    return 0;
}

static int fnBufrProductCallBack_0_21_200(varfl val)
{
    BUFR_PRODUCT_READ_TMP   *pCurTmpData    = NULL;

    pCurTmpData = g_bufrPrdtReadTbl.m_ppTmpData[g_bufrPrdtReadTbl.m_iCurData];

    pCurTmpData->m_dProdpar = val/1000.;

    return 0;
}

static int fnBufrProductCallBack_0_31_1(varfl val)
{
    int         iMaxData    = 0;
    int         iDataIdx    = 0;

    iMaxData = (int)val;

    g_bufrPrdtReadTbl.m_iMaxData = iMaxData;

    g_bufrPrdtReadTbl.m_ppTmpData 
    = (BUFR_PRODUCT_READ_TMP **)calloc(iMaxData, sizeof(BUFR_PRODUCT_READ_TMP *));
    if(g_bufrPrdtReadTbl.m_ppTmpData == NULL)
        return -1;

    for(iDataIdx = 0; iDataIdx < iMaxData; iDataIdx++)
    {
        g_bufrPrdtReadTbl.m_ppTmpData[iDataIdx]
        = (BUFR_PRODUCT_READ_TMP *)calloc(1, sizeof(BUFR_PRODUCT_READ_TMP));
        if(g_bufrPrdtReadTbl.m_ppTmpData[iDataIdx] == NULL)
            return -1;
    }

    return 0;
}

static int fnBufrProductCallBack(varfl val, int ind)
{
    dd          *pFxy       = NULL;
    bufrval_t   *pBufrVal   = NULL;
    varfl       *pVV        = NULL;

    /* sequence descriptor */
    if(des[ind]->id == SEQDESC)
    {
        pFxy =  &(des[ind]->seq->d);

        /* open array for values */
        pBufrVal = bufr_open_val_array();
        if(pBufrVal == NULL)
            return 0;

        /* decode sequence to global array */
        if(!bufr_parse_out(des[ind]->seq->del, 0, des[ind]->seq->nel-1, bufr_val_to_global, 0))
        {
            bufr_close_val_array();
            return 0;
        }
        pVV = pBufrVal->vals;

        if(bufr_check_fxy(pFxy, 3,1,11))
        {
            if(fnBufrProductCallBack_3_1_11(pVV) < 0)
            {   bufr_close_val_array(); return 0; }
        }
        else if(bufr_check_fxy(pFxy, 3,1,13))
        {
            if(fnBufrProductCallBack_3_1_13(pVV) < 0)
            {   bufr_close_val_array(); return 0; }
        }
        else if(bufr_check_fxy(pFxy, 3,1,21))
        {
            if(fnBufrProductCallBack_3_1_21(pVV) < 0)
            {   bufr_close_val_array(); return 0; }
        }
        else if(bufr_check_fxy(pFxy, 3,21,204))
        {
            if(fnBufrProductCallBack_3_1_204(pVV) < 0)
            {   bufr_close_val_array(); return 0; }
        }
        else if(bufr_check_fxy(pFxy, 3,21,206)) // DATA
        {
            if(fnBufrProductCallBack_3_21_206(pVV) < 0)
            {   bufr_close_val_array(); return 0; }
        }
        else
        {
            fprintf(stderr, "%s : SEQ f=%d x=%d y=%d\n", __func__, pFxy->f, pFxy->x, pFxy->y);
        }

        bufr_close_val_array();
    }
    /* element descriptor */
    else if(des[ind]->id == ELDESC)
    {
        pFxy =  &(des[ind]->el->d);

        if(bufr_check_fxy(pFxy, 0,29,205))
        {
            if(fnBufrProductCallBack_0_29_205(pFxy) < 0)
                return 0;
        }
        else if(bufr_check_fxy(pFxy, 0,5,33))
        {
            if(fnBufrProductCallBack_0_5_33(val) < 0)
                return 0;
        }
        else if(bufr_check_fxy(pFxy, 0,6,33))
        {
            if(fnBufrProductCallBack_0_6_33(val) < 0)
                return 0;
        }
        else if(bufr_check_fxy(pFxy, 0,30,21))
        {
            if(fnBufrProductCallBack_0_30_21(val) < 0)
                return 0;
        }
        else if(bufr_check_fxy(pFxy, 0,30,22))
        {
            if(fnBufrProductCallBack_0_30_22(val) < 0)
                return 0;
        }
        else if(bufr_check_fxy(pFxy, 0,30,199)) // PRODUCT
        {
            if(fnBufrProductCallBack_0_30_199(pFxy) < 0)
                return 0;
        }
        else if(bufr_check_fxy(pFxy, 0,21,200)) // PRODPAR
        {
            if(fnBufrProductCallBack_0_21_200(val) < 0)
                return 0;
        }
        else if(bufr_check_fxy(pFxy, 0,30,200)) // QUANTITY
        {
            if(fnBufrProductCallBack_0_30_200(pFxy) < 0)
                return 0;
        }
        else if(bufr_check_fxy(pFxy, 0,31,1))
        {
            if(fnBufrProductCallBack_0_31_1(val) < 0)
                return 0;
        }
        else if(bufr_check_fxy(pFxy, 0,29,193))
        {
            if(fnBufrProductCallBack_0_29_193(val) < 0)
                return 0;
        }
        else if(bufr_check_fxy(pFxy, 0,29,194))
        {
            if(fnBufrProductCallBack_0_29_194(val) < 0)
                return 0;
        }
        else if(bufr_check_fxy(pFxy, 1,4,0))
        {
            // SKIP
        }
        else if(bufr_check_fxy(pFxy, 2,1,0))
        {
            // SKIP
        }
        else if(bufr_check_fxy(pFxy, 2,1,129))
        {
            // SKIP
        }
        else
        {
            fprintf(stderr, "%s : EL f=%d x=%d y=%d\n", __func__, pFxy->f, pFxy->x, pFxy->y);
        }
    }
    else
    {
        fprintf(stderr, "%s : Unknown\n", __func__);
    }

    return 1;
}

/* ================================================================================ */
// Function

BUFR_RADAR* fnLoadBufrRadar(char* szFile)
{
#define FN_LOAD_BUFR_RADAR_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    free_descs(); \
    bufr_free_data(&msg); \
    bufr_close_descsec_r(hDesc); \
    bufr_close_datasect_r(); \
    if(pDesc   != NULL) { free(pDesc); } \
    if(g_pBufr != NULL) { fnFreeBufrRadar(g_pBufr); g_pBufr = NULL; } 

    BUFR_RADAR      *pBufr                 = NULL;
    int             hDesc                       = -1;
    int             iMaxDesc                    = 0;
    char            szTablePath[STR_LENGTH_MAX] = "";
    dd              *pDesc                      = NULL;
    bufr_t          msg;
    sect_1_t        s1;

    if(szFile == NULL)
        return NULL;

    memset(&msg, 0x00, sizeof(bufr_t));
    memset(&s1,  0x00, sizeof(sect_1_t));

    if((g_pBufr = (BUFR_RADAR *)calloc(1, sizeof(BUFR_RADAR))) == NULL)
    {   FN_LOAD_BUFR_RADAR_ERROR("calloc fail") return NULL; }
    snprintf(g_pBufr->m_szConventions, 
             sizeof(g_pBufr->m_szConventions), RDR_DF_BUFR_CONVENTIONS_STR);
    g_pBufr->m_iBufrType = BUFR_EN_R_TYPE_POLAR;

    if(!bufr_read_file(&msg, szFile))
    {   FN_LOAD_BUFR_RADAR_ERROR("bufr_read_file fail") return NULL; }

    /******* decode section 1 */
    if(!bufr_decode_sections01(&s1, &msg))
    {   FN_LOAD_BUFR_RADAR_ERROR("bufr_decode_sections01 fail") return NULL; }

    /* read descriptor tables */
    snprintf(szTablePath, sizeof(szTablePath), 
             "%s/resource/bufr_table", RDR_DF_APP_ROOT_PATH);
    if(read_tables(szTablePath, s1.vmtab, s1.vltab, s1.subcent, s1.gencent) < 0)
    {   FN_LOAD_BUFR_RADAR_ERROR("read_tables fail") return NULL; }

    /* decode data descriptor and data-section now */
    /* open bitstreams for section 3 and 4 */
    if((hDesc = bufr_open_descsec_r(&msg, NULL)) < 0)
    {   FN_LOAD_BUFR_RADAR_ERROR("bufr_open_descsec_r fail") return NULL; }

    if(bufr_open_datasect_r(&msg) < 0)
    {   FN_LOAD_BUFR_RADAR_ERROR("bufr_open_datasect_r fail") return NULL; }

    /* calculate number of data descriptors  */
    iMaxDesc = bufr_get_ndescs (&msg);

    /* allocate memory and read data descriptors from bitstream */
    if(bufr_in_descsec(&pDesc, iMaxDesc, hDesc) != 1)
    {   FN_LOAD_BUFR_RADAR_ERROR("bufr_in_descsec fail") return NULL; }

    /* output data to our global data structure */
    if(s1.vltab == 8)
    {
        if(bufr_parse_out(pDesc, 0, iMaxDesc-1, fnBufrCallBack_V2_0, 1) != 1)
        {   FN_LOAD_BUFR_RADAR_ERROR("bufr_parse_out fail") return NULL; }
    }
    else
    {
        if(bufr_parse_out(pDesc, 0, iMaxDesc-1, fnBufrCallBack_V2_1, 1) != 1)
        {   FN_LOAD_BUFR_RADAR_ERROR("bufr_parse_out fail") return NULL; }
    }

    /* close bitstreams and free descriptor array */
    if(pDesc != NULL) { free(pDesc); };
    bufr_free_data(&msg);
    bufr_close_descsec_r(hDesc);
    bufr_close_datasect_r();
    free_descs();

    pBufr   = g_pBufr;
    g_pBufr = NULL;

    return pBufr;
}

void fnFreeBufrRadar(BUFR_RADAR *pBufr)
{
    int                     iDatasetIdx         = 0;
    int                     iDataIdx            = 0;
    int                     iMaxData            = 0;
    int                     iYdim               = 0;
    BUFR_DATA               *pBufrData          = NULL;

    if(pBufr != NULL)
    {
        if(pBufr->m_ppDataset != NULL)
        {
            for(iDatasetIdx = 0; iDatasetIdx < pBufr->m_iMaxDataset; iDatasetIdx++)
            {
                if(pBufr->m_ppDataset[iDatasetIdx] != NULL)
                {
                    if(pBufr->m_ppDataset[iDatasetIdx]->m_ppData != NULL)
                    {
                        iMaxData = pBufr->m_ppDataset[iDatasetIdx]->m_iMaxData;
                        for(iDataIdx = 0; iDataIdx < iMaxData; iDataIdx++)
                        {
                            pBufrData = NULL;
                            pBufrData = pBufr->m_ppDataset[iDatasetIdx]->m_ppData[iDataIdx];
                            if(pBufrData != NULL)
                            {
                                if(pBufrData->m_ppData != NULL)
                                {
                                    switch(pBufr->m_iBufrType)
                                    {
                                        case BUFR_EN_R_TYPE_POLAR:
                                            iYdim = pBufrData->m_where.m_polar_where.m_nRays;
                                    }
                                    fnFreeMatrix2D((void **)pBufrData->m_ppData, iYdim);
                                }
                                free(pBufrData);
                            }
                        }
                        free(pBufr->m_ppDataset[iDatasetIdx]->m_ppData);
                    }
                    free(pBufr->m_ppDataset[iDatasetIdx]);
                }
            }
            free(pBufr->m_ppDataset);
        }
        free(pBufr);
    }
}

BUFR_PRODUCT* fnLoadBufrProduct(char* szFile, char *szObject)
{
#define FN_LOAD_BUFR_PRODUCT_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    free_descs(); \
    bufr_free_data(&msg); \
    bufr_close_descsec_r(hDesc); \
    bufr_close_datasect_r(); \
    if(pDesc          != NULL) { free(pDesc); } \
    if(g_pBufrProduct != NULL) { fnFreeBufrProduct(g_pBufrProduct); g_pBufrProduct = NULL; } \
    fnCleanBufrProductReadTbl();

    BUFR_PRODUCT   *pBufrProduct                = NULL;
    int             hDesc                       = -1;
    int             iMaxDesc                    = 0;
    char            szTablePath[STR_LENGTH_MAX] = "";
    dd              *pDesc                      = NULL;
    bufr_t          msg;
    sect_1_t        s1;

    if(szFile == NULL || szObject == NULL)
        return NULL;

    _bufr_edition = 4;

    memset(&msg, 0x00, sizeof(bufr_t));
    memset(&s1,  0x00, sizeof(sect_1_t));

    if((g_pBufrProduct = (BUFR_PRODUCT *)calloc(1, sizeof(BUFR_PRODUCT))) == NULL)
    {   FN_LOAD_BUFR_PRODUCT_ERROR("calloc fail") return NULL; }

    snprintf(g_pBufrProduct->m_szConventions, 
             sizeof(g_pBufr->m_szConventions), RDR_DF_BUFR_CONVENTIONS_STR);
    snprintf(g_pBufrProduct->m_what.m_szObject,  
             sizeof(g_pBufrProduct->m_what.m_szObject),  szObject);
    snprintf(g_pBufrProduct->m_what.m_szVersion, 
             sizeof(g_pBufrProduct->m_what.m_szVersion), RDR_DF_BUFR_VERSION_STR);

    if(!bufr_read_file(&msg, szFile))
    {   FN_LOAD_BUFR_PRODUCT_ERROR("bufr_read_file fail") return NULL; }

    /******* decode section 1 */
    if(!bufr_decode_sections01(&s1, &msg))
    {   FN_LOAD_BUFR_PRODUCT_ERROR("bufr_decode_sections01 fail") return NULL; }

    /* read descriptor tables */
    snprintf(szTablePath, sizeof(szTablePath), "%s/resource/bufr_table", RDR_DF_APP_ROOT_PATH);
    if(read_tables(szTablePath, s1.vmtab, s1.vltab, s1.subcent, s1.gencent) < 0)
    {   FN_LOAD_BUFR_PRODUCT_ERROR("read_tables fail") return NULL; }

    /* decode data descriptor and data-section now */
    /* open bitstreams for section 3 and 4 */
    if((hDesc = bufr_open_descsec_r(&msg, NULL)) < 0)
    {   FN_LOAD_BUFR_PRODUCT_ERROR("bufr_open_descsec_r fail") return NULL; }

    if(bufr_open_datasect_r(&msg) < 0)
    {   FN_LOAD_BUFR_PRODUCT_ERROR("bufr_open_datasect_r fail") return NULL; }

    /* calculate number of data descriptors  */
    iMaxDesc = bufr_get_ndescs(&msg);

    /* allocate memory and read data descriptors from bitstream */
    if(bufr_in_descsec(&pDesc, iMaxDesc, hDesc) != 1)
    {   FN_LOAD_BUFR_PRODUCT_ERROR("bufr_in_descsec fail") return NULL; }

    /* output data to our global data structure */
    if(bufr_parse_out(pDesc, 0, iMaxDesc-1, fnBufrProductCallBack, 1) != 1)
    {   FN_LOAD_BUFR_RADAR_ERROR("bufr_parse_out fail") return NULL; }

    /* close bitstreams and free descriptor array */
    if(pDesc != NULL) { free(pDesc); };
    bufr_free_data(&msg);
    bufr_close_descsec_r(hDesc);
    bufr_close_datasect_r();
    free_descs();

    fnConvertReadTblToBufrProduct();
    fnCleanBufrProductReadTbl();

    if(!strcmp(szObject, "AZIM"))
    {
        g_pBufrProduct->m_iBufrProductType = BUFR_EN_PRODUCT_SITE;
    }
    else if(!strcmp(szObject, "COMP"))
    {
        g_pBufrProduct->m_iBufrProductType = BUFR_EN_PRODUCT_COMP;
    }

    pBufrProduct   = g_pBufrProduct;
    g_pBufrProduct = NULL;

    return pBufrProduct;
}

int fnGetMaxCountBufrRadar(BUFR_RADAR *pBufr, int *pMaxDataset, int *pMaxData, int *pMaxRay, int *pMaxBin)
{
    int         iDsetIdx    = 0;
    int         iDataIdx    = 0;
    int         iMaxDataset = 0;
    int         iMaxData    = 0;
    int         iMaxRay     = 0;
    int         iMaxBin     = 0;

    if(pBufr == NULL)
        return FALSE;

    iMaxDataset = pBufr->m_iMaxDataset;

    for(iDsetIdx = 0; iDsetIdx < pBufr->m_iMaxDataset; iDsetIdx++)
    {
        if(pBufr->m_ppDataset == NULL)
            break;

        if(pBufr->m_ppDataset[iDsetIdx] == NULL)
            continue;

        if(iMaxData < pBufr->m_ppDataset[iDsetIdx]->m_iMaxData)
            iMaxData = pBufr->m_ppDataset[iDsetIdx]->m_iMaxData;

        for(iDataIdx = 0; iDataIdx < pBufr->m_ppDataset[iDsetIdx]->m_iMaxData; iDataIdx++)
        {
            if(pBufr->m_ppDataset[iDsetIdx]->m_ppData == NULL)
                break;

            if(pBufr->m_ppDataset[iDsetIdx]->m_ppData[iDataIdx] == NULL)
                continue;

            if(iMaxRay < (int)pBufr->m_ppDataset[iDsetIdx]->
                         m_ppData[iDataIdx]->m_where.m_polar_where.m_nRays)
            {
                iMaxRay = (int)pBufr->m_ppDataset[iDsetIdx]->
                          m_ppData[iDataIdx]->m_where.m_polar_where.m_nRays;
            }

            if(iMaxBin < (int)pBufr->m_ppDataset[iDsetIdx]->
                         m_ppData[iDataIdx]->m_where.m_polar_where.m_nBins)
            {
                iMaxBin = (int)pBufr->m_ppDataset[iDsetIdx]->
                          m_ppData[iDataIdx]->m_where.m_polar_where.m_nBins;
            }
        }
    }

    if(pMaxDataset != NULL) *pMaxDataset = iMaxDataset;
    if(pMaxData    != NULL) *pMaxData    = iMaxData;
    if(pMaxRay     != NULL) *pMaxRay     = iMaxRay;
    if(pMaxBin     != NULL) *pMaxBin     = iMaxBin;

    return TRUE;
}



