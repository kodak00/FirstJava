/* ================================================================================ */
//
// Radar Standard Input Format & Input Function
//
// 2016.08.05 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function

static double fnCwiseAngleDiff(float fAzimuth1, float fAzimuth2)
{
    double  dVal = 0.0;

    dVal = (double)(fAzimuth2 - fAzimuth1);
    if(dVal < 0) dVal += 360;
    return dVal;
}

static double fnCCwiseAngleDiff(float fAzimuth1, float fAzimuth2)
{
    double  dVal = 0.0;

    dVal = (double)(fAzimuth1 - fAzimuth2);
    if(dVal < 0) dVal += 360;
    return dVal;
}

/*
static int fnInitStdSweep(STD_RADAR *pStd, int iMaxSweep)
{
    int iSweepIdx   = 0;

    if(pStd == NULL || pStd->m_ppSweep != NULL)
        return FALSE;

    pStd->m_iMaxSweep = iMaxSweep;
    pStd->m_ppSweep   = calloc(pStd->m_iMaxSweep, sizeof(STD_SWEEP *));

    if(pStd->m_ppSweep == NULL)
        return FALSE;

    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        pStd->m_ppSweep[iSweepIdx] = calloc(1, sizeof(STD_SWEEP));
        if(pStd->m_ppSweep[iSweepIdx] == NULL)
            return FALSE;
    }

    return TRUE;
}

static int fnInitStdRay(STD_SWEEP *pSweep, int iMaxRay)
{
    int iRayIdx     = 0;

    if(pSweep == NULL || pSweep->m_ppRay != NULL)
        return FALSE;

    pSweep->m_iMaxRay = iMaxRay;
    pSweep->m_ppRay   = calloc(pSweep->m_iMaxRay, sizeof(STD_RAY *));

    if(pSweep->m_ppRay == NULL)
        return FALSE;

    for(iRayIdx = 0; iRayIdx < pSweep->m_iMaxRay; iRayIdx++)
    {
        pSweep->m_ppRay[iRayIdx] = calloc(1, sizeof(STD_RAY));
        if(pSweep->m_ppRay[iRayIdx] == NULL)
            return FALSE;
    }

    return TRUE;
}

static int fnInitStdField(STD_RAY *pRay, int iMaxField)
{
    int iFieldIdx   = 0;

    if(pRay == NULL || pRay->m_ppField != NULL)
        return FALSE;

    pRay->m_iMaxField = iMaxField;
    pRay->m_ppField   = calloc(pRay->m_iMaxField, sizeof(STD_FIELD *));

    if(pRay->m_ppField == NULL)
        return FALSE;

    for(iFieldIdx = 0; iFieldIdx < pRay->m_iMaxField; iFieldIdx++)
    {
        pRay->m_ppField[iFieldIdx] = calloc(1, sizeof(STD_FIELD));
        if(pRay->m_ppField[iFieldIdx])
            return FALSE;
    }

    return TRUE;
}

static int fnInitStdBin(STD_FIELD *pField, int iMaxBin)
{
    if(pField == NULL || pField->m_pData != NULL)
        return FALSE;

    pField->m_iMaxBin = iMaxBin;
    pField->m_pData   = calloc(pField->m_iMaxBin, sizeof(short));

    if(pField->m_pData == NULL)
        return FALSE;

    return TRUE;
}
*/

static STD_RADAR* fnInitStd(int iMaxSweep, int iMaxRay, int iMaxBin, int iMaxField)
{
    STD_RADAR   *pStd       = NULL;             // VARIABLE
    STD_SWEEP   *pSweep     = NULL;             // VARIABLE
    STD_RAY     *pRay       = NULL;             // VARIABLE
    STD_FIELD   *pField     = NULL;             // VARIABLE
    int         iSweepIdx   = 0; 
    int         iFieldIdx   = 0;
    int         iRayIdx     = 0;
    int         iBinIdx     = 0;

    if((pStd = calloc(1, sizeof(STD_RADAR))) == NULL)
        return NULL;

    pStd->m_iMaxSweep = iMaxSweep;
    if((pStd->m_ppSweep = (STD_SWEEP **)calloc(pStd->m_iMaxSweep, sizeof(STD_SWEEP *))) == NULL)
    {   fnFreeStdRadar(pStd);  return NULL; }

    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        pSweep = pStd->m_ppSweep[iSweepIdx] = (STD_SWEEP *)calloc(1, sizeof(STD_SWEEP));
        if(pSweep == NULL)
        {   fnFreeStdRadar(pStd);  return NULL; }

        pSweep->m_iMaxRay = iMaxRay;
        pSweep->m_ppRay   = (STD_RAY **)calloc(pSweep->m_iMaxRay, sizeof(STD_RAY *));
        if(pSweep->m_ppRay == NULL)
        {   fnFreeStdRadar(pStd);  return NULL; }

        for(iRayIdx = 0; iRayIdx < pSweep->m_iMaxRay; iRayIdx++)
        {
            pRay = pSweep->m_ppRay[iRayIdx] = (STD_RAY *)calloc(1, sizeof(STD_RAY));
            if(pRay == NULL)
            {   fnFreeStdRadar(pStd);  return NULL; }

            pRay->m_iMaxField = iMaxField;
            pRay->m_ppField   = (STD_FIELD **)calloc(pRay->m_iMaxField, sizeof(STD_FIELD *));
            if(pRay->m_ppField == NULL)
            {   fnFreeStdRadar(pStd);  return NULL; }

           for(iFieldIdx = 0;  iFieldIdx < pRay->m_iMaxField; iFieldIdx++)
           {
                pField = pRay->m_ppField[iFieldIdx] = (STD_FIELD *)calloc(1, sizeof(STD_FIELD));
                if(pField == NULL)
                {   fnFreeStdRadar(pStd);  return NULL; }

                pField->m_iMaxBin = iMaxBin;
                pField->m_pData   = (short *)calloc(pField->m_iMaxBin, sizeof(short));
                if(pField->m_pData == NULL)
                {   fnFreeStdRadar(pStd);  return NULL; }

                for(iBinIdx = 0; iBinIdx < pField->m_iMaxBin; iBinIdx++)
                {
                    pField->m_pData[iBinIdx] = RDR_DF_BAD_VALUE_S;
                }
            }
        }
    }

    return pStd;
}

static STD_RADAR* fnInitStdToUf(UF_RADAR* pUf)
{
    STD_RADAR   *pStd       = NULL;             // VARIABLE
    STD_SWEEP   *pSweep     = NULL;             // VARIABLE
    STD_RAY     *pRay       = NULL;             // VARIABLE
    STD_FIELD   *pField     = NULL;             // VARIABLE
    int         iSweepIdx   = 0;
    int         iRayIdx     = 0;
    int         iFieldIdx   = 0;

    if(pUf == NULL)
        return NULL;

    if((pStd = calloc(1, sizeof(STD_RADAR))) == NULL)
        return NULL;

    pStd->m_iMaxSweep = pUf->m_iCurSweep;
    pStd->m_ppSweep = (STD_SWEEP **)calloc(pStd->m_iMaxSweep, sizeof(STD_SWEEP *));
    if(pStd->m_ppSweep == NULL)
    {   fnFreeStdRadar(pStd);  return NULL; }

    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        pSweep = pStd->m_ppSweep[iSweepIdx] = (STD_SWEEP *)calloc(1, sizeof(STD_SWEEP));
        if(pSweep == NULL)
        {   fnFreeStdRadar(pStd);  return NULL; }

        pSweep->m_iMaxRay = pUf->m_ppSweep[iSweepIdx]->m_iCurRay;
        pSweep->m_ppRay   = (STD_RAY **)calloc(pSweep->m_iMaxRay, sizeof(STD_RAY *));
        if(pSweep->m_ppRay == NULL)
        {   fnFreeStdRadar(pStd);  return NULL; }

        for(iRayIdx = 0; iRayIdx < pSweep->m_iMaxRay; iRayIdx++)
        {
            pRay = pSweep->m_ppRay[iRayIdx] = (STD_RAY *)calloc(1, sizeof(STD_RAY));
            if(pRay == NULL)
            {   fnFreeStdRadar(pStd);  return NULL; }

            pRay->m_iMaxField = pUf->m_ppSweep[iSweepIdx]->m_ppRay[iRayIdx]->m_iCurField;
            pRay->m_ppField   = (STD_FIELD **)calloc(pRay->m_iMaxField, sizeof(STD_FIELD *));
            if(pRay->m_ppField == NULL)
            {   fnFreeStdRadar(pStd);  return NULL; }

            for(iFieldIdx = 0;  iFieldIdx < pRay->m_iMaxField; iFieldIdx++)
            {
                pField = pRay->m_ppField[iFieldIdx] = (STD_FIELD *)calloc(1, sizeof(STD_FIELD));
                if(pField == NULL)
                {   fnFreeStdRadar(pStd);  return NULL; }

                pField->m_iMaxBin 
                = pUf->m_ppSweep[iSweepIdx]->m_ppRay[iRayIdx]->m_ppField[iFieldIdx]->m_iCurBin;
            }
        }
    }

    return pStd;
}

static STD_RADAR* fnInitStdToNc(NC_RADAR* pNc)
{
    STD_RADAR   *pStd       = NULL;             // VARIABLE
    STD_SWEEP   *pSweep     = NULL;             // VARIABLE
    STD_RAY     *pRay       = NULL;             // VARIABLE
    STD_FIELD   *pField     = NULL;             // VARIABLE
    int         iSweepIdx   = 0;
    int         iRayIdx     = 0;
    int         iFieldIdx   = 0;
    int         iRayStart   = 0;
    int         iRayEnd     = 0;

    if(pNc == NULL)
        return NULL;

    if((pStd = calloc(1, sizeof(STD_RADAR))) == NULL)
        return NULL;

    pStd->m_iMaxSweep = pNc->m_dim.m_nSweep;
    pStd->m_ppSweep = (STD_SWEEP **)calloc(pStd->m_iMaxSweep, sizeof(STD_SWEEP *));
    if(pStd->m_ppSweep == NULL)
    {   fnFreeStdRadar(pStd);  return NULL; }

    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        pSweep = pStd->m_ppSweep[iSweepIdx] = (STD_SWEEP *)calloc(1, sizeof(STD_SWEEP));
        if(pSweep == NULL)
        {   fnFreeStdRadar(pStd);  return NULL; }

        iRayStart = pNc->m_sweep_var.m_pSweep_start_ray_index[iSweepIdx];
        iRayEnd   = pNc->m_sweep_var.m_pSweep_end_ray_index[iSweepIdx];

        pSweep->m_iMaxRay = iRayEnd - iRayStart + 1;
        pSweep->m_ppRay   = (STD_RAY **)calloc(pSweep->m_iMaxRay, sizeof(STD_RAY *));
        if(pSweep->m_ppRay == NULL)
        {   fnFreeStdRadar(pStd);  return NULL; }

        for(iRayIdx = 0; iRayIdx < pSweep->m_iMaxRay; iRayIdx++)
        {
            pRay = pSweep->m_ppRay[iRayIdx] = (STD_RAY *)calloc(1, sizeof(STD_RAY));
            if(pRay == NULL)
            {   fnFreeStdRadar(pStd);  return NULL; }

            pRay->m_iMaxField = pNc->m_iMaxMoment;
            pRay->m_ppField   = (STD_FIELD **)calloc(pRay->m_iMaxField, sizeof(STD_FIELD *));
            if(pRay->m_ppField == NULL)
            {   fnFreeStdRadar(pStd);  return NULL; }

            for(iFieldIdx = 0;  iFieldIdx < pRay->m_iMaxField; iFieldIdx++)
            {
                pField = pRay->m_ppField[iFieldIdx] 
                = (STD_FIELD *)calloc(1, sizeof(STD_FIELD));
                if(pField == NULL)
                {   fnFreeStdRadar(pStd);  return NULL; }

                pField->m_iMaxBin = pNc->m_dim.m_nRange;

                pField->m_pData = (short *)calloc(pField->m_iMaxBin, sizeof(short));
                if(pField->m_pData == NULL || pField->m_iMaxBin <= 0)
                {   fnFreeStdRadar(pStd);  return NULL; }
            }
        }
    }

    return pStd;
}

static STD_RADAR* fnInitStdToGrib(GRIB_RADAR* pGrib)
{
    STD_RADAR   *pStd       = NULL;             // VARIABLE
    STD_SWEEP   *pSweep     = NULL;             // VARIABLE
    STD_RAY     *pRay       = NULL;             // VARIABLE
    STD_FIELD   *pField     = NULL;             // VARIABLE
    int         iSweepIdx   = 0;
    int         iRayIdx     = 0;
    int         iCurRay     = 0;
    int         iFieldIdx   = 0;

    if(pGrib == NULL)
        return NULL;

    if((pStd = calloc(1, sizeof(STD_RADAR))) == NULL)
        return NULL;

    pStd->m_iMaxSweep = pGrib->m_hdr.m_iMaxSweep;
    pStd->m_ppSweep = (STD_SWEEP **)calloc(pStd->m_iMaxSweep, sizeof(STD_SWEEP *));
    if(pStd->m_ppSweep == NULL)
    {   fnFreeStdRadar(pStd);  return NULL; }

    for(iSweepIdx = 0, iCurRay = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        pSweep = pStd->m_ppSweep[iSweepIdx] = (STD_SWEEP *)calloc(1, sizeof(STD_SWEEP));
        if(pSweep == NULL)
        {   fnFreeStdRadar(pStd);  return NULL; }

        pSweep->m_iMaxRay = pGrib->m_hdr.m_pMaxRay[iSweepIdx];
        pSweep->m_ppRay   = (STD_RAY **)calloc(pSweep->m_iMaxRay, sizeof(STD_RAY *));
        if(pSweep->m_ppRay == NULL)
        {   fnFreeStdRadar(pStd);  return NULL; }

        for(iRayIdx = 0; iRayIdx < pSweep->m_iMaxRay; iRayIdx++, iCurRay++)
        {
            pRay = pSweep->m_ppRay[iRayIdx] = (STD_RAY *)calloc(1, sizeof(STD_RAY));
            if(pRay == NULL)
            {   fnFreeStdRadar(pStd);  return NULL; }

            pRay->m_iMaxField = pGrib->m_hdr.m_iMaxField;
            pRay->m_ppField   = (STD_FIELD **)calloc(pRay->m_iMaxField, sizeof(STD_FIELD *));
            if(pRay->m_ppField == NULL)
            {   fnFreeStdRadar(pStd);  return NULL; }

            for(iFieldIdx = 0; iFieldIdx < pRay->m_iMaxField; iFieldIdx++)
            {
                pField = pRay->m_ppField[iFieldIdx] = (STD_FIELD *)calloc(1, sizeof(STD_FIELD));
                if(pField == NULL)
                {   fnFreeStdRadar(pStd);  return NULL; }

                pField->m_iMaxBin = pGrib->m_hdr.m_pMaxBin[iCurRay];
                pField->m_pData   = (short *)calloc(pField->m_iMaxBin, sizeof(short));
                if(pField->m_pData == NULL)
                {   fnFreeStdRadar(pStd);  return NULL; }
            }
        }
    }

    return pStd;
}

static void fnUfRayToStdRay(UF_RAY *pRay, STD_RAY *pStdRay)
{
    if(pStdRay == NULL || pRay == NULL)
        return;

    pStdRay->m_hdr.m_tTime        = fnMakeTime(TRUE, pRay->mh.m_iYear, pRay->mh.m_iMonth, 
                                                     pRay->mh.m_iDay,  pRay->mh.m_iHour, 
                                                     pRay->mh.m_iMinute, pRay->mh.m_iSecond); // KST
    pStdRay->m_hdr.m_fAzimuth     = pRay->mh.m_fAzimuth;
    pStdRay->m_hdr.m_fElevation   = pRay->mh.m_fElevation;
    pStdRay->m_hdr.m_fFixedAngle  = pRay->mh.m_fFixedAngle;
}

static void fnUfFieldToStdRay(UF_FIELD *pField, STD_RAY *pStdRay)
{
    if(pField == NULL || pStdRay == NULL)
        return;

    pStdRay->m_hdr.m_iStartRangeKm     = pField->fh.m_iStartRangeKm;
    pStdRay->m_hdr.m_iStartRangeMeter  = pField->fh.m_iStartRangeMeter;
    pStdRay->m_hdr.m_iBinSpacing       = pField->fh.m_iBinSpacing;
    pStdRay->m_hdr.m_iSampleSize       = pField->fh.m_iSampleSize;
}

static void fnUfFieldToStdField(UF_FIELD *pField, char* szFieldName, STD_FIELD *pStdField)
{
    if(pField == NULL || szFieldName == NULL || pStdField == NULL)
        return;

    snprintf(pStdField->m_hdr.m_szFieldName, sizeof(pStdField->m_hdr.m_szFieldName), 
             "%s", szFieldName);
    pStdField->m_hdr.m_iScaleFactor = pField->fh.m_iScaleFactor;
    // 메모리 사용량 문제로 포인터 이동
    pStdField->m_pData = pField->m_pData;
    pField->m_pData = NULL;
}

static void fnUfToStdGlobal(UF_RAY *pRay, UF_FIELD *pField, STD_RADAR *pStd)
{
    if(pRay == NULL || pField == NULL || pStd == NULL)
        return;

    // mandatory header
    pStd->m_hdr.m_iVolumeNo  = pRay->mh.m_iVolumeNo;
    snprintf(pStd->m_hdr.m_szRadarName, sizeof(pStd->m_hdr.m_szRadarName), 
             "%s", pRay->mh.m_szRadarName);
    snprintf(pStd->m_hdr.m_szSiteName,  sizeof(pStd->m_hdr.m_szSiteName),  
             "%s", pRay->mh.m_szSiteName);

    pStd->m_hdr.m_dLat         = fnConvertDms2Deg(pRay->mh.m_iLatDeg, 
                                                  pRay->mh.m_iLatMin, 
                                                  pRay->mh.m_fLatSec);
    pStd->m_hdr.m_dLon         = fnConvertDms2Deg(pRay->mh.m_iLonDeg, 
                                                  pRay->mh.m_iLonMin, 
                                                  pRay->mh.m_fLonSec);
    pStd->m_hdr.m_iAnteHeight  = pRay->mh.m_iAnteHeight;
    pStd->m_hdr.m_iSweepMode   = pRay->mh.m_iSweepMode;
    pStd->m_hdr.m_fSweepRate   = pRay->mh.m_fSweepRate;
    snprintf(pStd->m_hdr.m_szConvertName, sizeof(pStd->m_hdr.m_szConvertName), 
             "%s", pRay->mh.m_szConvertName);
    pStd->m_hdr.m_tConvertTime = fnMakeTime(TRUE, pRay->mh.m_iConvertYear,  
                                                  pRay->mh.m_iConvertMonth, 
                                                  pRay->mh.m_iConvertDay,    
                                                  pRay->oh.m_iVolumeScanHour, 
                                                  pRay->oh.m_iVolumeScanMin, 
                                                  pRay->oh.m_iVolumeScanSec); // KST
    pStd->m_hdr.m_iNoDataValue = pRay->mh.m_iNoDataValue;

    // option information
    snprintf(pStd->m_hdr.m_szProjectName, sizeof(pStd->m_hdr.m_szProjectName), 
             "%s", pRay->oh.m_szProjectName);
    pStd->m_hdr.m_fBaselineAzimuth    = pRay->oh.m_fBaselineAzimuth;
    pStd->m_hdr.m_fBaselineElevation  = pRay->oh.m_fBaselineElevation;
    snprintf(pStd->m_hdr.m_szFieldTapeName, sizeof(pStd->m_hdr.m_szFieldTapeName), 
             "%s", pRay->oh.m_szFieldTapeName);

    // field information..
    pStd->m_hdr.m_iPulseWidth       = pField->fh.m_iPulseWidth;
    pStd->m_hdr.m_fBeamWidthH       = pField->fh.m_fBeamWidthH;
    pStd->m_hdr.m_fBeamWidthV       = pField->fh.m_fBeamWidthV;
    pStd->m_hdr.m_iBandWidth        = pField->fh.m_iBandWidth;
    pStd->m_hdr.m_iPolarMode        = pField->fh.m_iPolarMode;
    pStd->m_hdr.m_fWaveLength       = pField->fh.m_fWaveLength;
    snprintf(pStd->m_hdr.m_szThresholdType, sizeof(pStd->m_hdr.m_szThresholdType), 
             "%s", pField->fh.m_szThresholdType);
    pStd->m_hdr.m_iThresholdValue   = pField->fh.m_iThresholdValue;
    pStd->m_hdr.m_iScale            = pField->fh.m_iScale;
    snprintf(pStd->m_hdr.m_szEditCode, sizeof(pStd->m_hdr.m_szEditCode), 
             "%s", pField->fh.m_szEditCode);
    pStd->m_hdr.m_iPRT              = pField->fh.m_iPRT;
    pStd->m_hdr.m_iBitsPerBin       = pField->fh.m_iBitsPerBin;
}

// HDF Product -> STD Product

static void fnConvertStdProductHdrToHdf(STD_PRODUCT *pStdProduct, HDF_PRODUCT *pHdfProduct)
{
    char        szDateTime[15+1]    = "";
    char        szTemp[256]         = "";
    char        *szSplit[2]         = { NULL, };
    struct  tm  tm;

    if(pStdProduct == NULL || pHdfProduct == NULL)
        return;

    // HDF TOP WHAT
    snprintf(szDateTime, sizeof(szDateTime), 
             "%s%s", pHdfProduct->m_what.m_szDate, pHdfProduct->m_what.m_szTime);
    memset(&tm, 0x00, sizeof(tm));
    strptime(szDateTime, "%Y%m%d%H%M%S", &tm);
    pStdProduct->m_product_hdr.m_tConvertTime = mktime(&tm) + (60*60*9); // KST
    if(pHdfProduct->m_iHdfProductType == HDF_EN_PRODUCT_SITE)
    {
        snprintf(szTemp, sizeof(szTemp), "%s", pHdfProduct->m_what.m_szSource);
        if(fnSplit(szTemp, szSplit, 2, ':') == 2)
        {
            snprintf(pStdProduct->m_product_hdr.m_szSiteName , 
                     sizeof(pStdProduct->m_product_hdr.m_szSiteName), "%s", szSplit[1]);
        }
    }

    // HDF TOP WHERE
    pStdProduct->m_product_hdr.m_dLon         = pHdfProduct->m_where.m_polar_where.m_dLon;
    pStdProduct->m_product_hdr.m_dLat         = pHdfProduct->m_where.m_polar_where.m_dLat;
    pStdProduct->m_product_hdr.m_iAnteHeightM = pHdfProduct->m_where.m_polar_where.m_dHeightM;
    pStdProduct->m_product_hdr.m_lXsize       = pHdfProduct->m_where.m_image_where.m_lXsize;
    pStdProduct->m_product_hdr.m_lYsize       = pHdfProduct->m_where.m_image_where.m_lYsize;
    pStdProduct->m_product_hdr.m_dXscale      = pHdfProduct->m_where.m_image_where.m_dXscale;
    pStdProduct->m_product_hdr.m_dYscale      = pHdfProduct->m_where.m_image_where.m_dYscale;
    pStdProduct->m_product_hdr.m_LL_lon       = pHdfProduct->m_where.m_image_where.m_LL_lon;
    pStdProduct->m_product_hdr.m_LL_lat       = pHdfProduct->m_where.m_image_where.m_LL_lat;
    pStdProduct->m_product_hdr.m_UL_lon       = pHdfProduct->m_where.m_image_where.m_UL_lon;
    pStdProduct->m_product_hdr.m_UL_lat       = pHdfProduct->m_where.m_image_where.m_UL_lat;
    pStdProduct->m_product_hdr.m_UR_lon       = pHdfProduct->m_where.m_image_where.m_UR_lon;
    pStdProduct->m_product_hdr.m_UR_lat       = pHdfProduct->m_where.m_image_where.m_UR_lat;
    pStdProduct->m_product_hdr.m_LR_lon       = pHdfProduct->m_where.m_image_where.m_LR_lon;
    pStdProduct->m_product_hdr.m_LR_lat       = pHdfProduct->m_where.m_image_where.m_LR_lat;

    // HDF TOP HOW
    pStdProduct->m_product_hdr.m_dNi          = pHdfProduct->m_how.m_radar_how.m_dNi;
}

static int fnConvertStdDataToHdf(STD_PRODUCT_DATA **ppStdData, HDF_PRODUCT_DATA **ppHdfData, int iMaxField, int iYdim, int iXdim)
{
    int             iFieldIdx       = 0;

    if(ppStdData == NULL || ppHdfData == NULL || iMaxField <= 0)
        return FALSE;

    for(iFieldIdx = 0; iFieldIdx < iMaxField; iFieldIdx++)
    {
        if(ppStdData[iFieldIdx] == NULL || ppHdfData[iFieldIdx] == NULL)
            return FALSE;

        if(ppHdfData[iFieldIdx]->m_ppData_c == NULL &&
           ppHdfData[iFieldIdx]->m_ppData_s == NULL && 
           ppHdfData[iFieldIdx]->m_ppData_f == NULL)
            continue;

        snprintf(ppStdData[iFieldIdx]->m_szFieldName, 
                 sizeof(ppStdData[iFieldIdx]->m_szFieldName), 
                 "%s", ppHdfData[iFieldIdx]->m_szFieldName);

        // HDF DATA
        // 메모리 사용량 문제로 배열을 복사하지 않고 pointer를 옮김
        ppStdData[iFieldIdx]->m_iMemType = ppHdfData[iFieldIdx]->m_iMemType;

        ppStdData[iFieldIdx]->m_ppData_c  = ppHdfData[iFieldIdx]->m_ppData_c;
        ppHdfData[iFieldIdx]->m_ppData_c = NULL;

        ppStdData[iFieldIdx]->m_ppData_s  = ppHdfData[iFieldIdx]->m_ppData_s;
        ppHdfData[iFieldIdx]->m_ppData_s = NULL;

        ppStdData[iFieldIdx]->m_ppData_f  = ppHdfData[iFieldIdx]->m_ppData_f;
        ppHdfData[iFieldIdx]->m_ppData_f = NULL;
    }

    return TRUE;
}

static int fnConvertStdDatasetToHdf(STD_PRODUCT_DATASET **ppStdDataset, HDF_PRODUCT_DATASET **ppHdfDataset, int iMaxDataset, int iYdim, int iXdim)
{
    int                 iDatasetIdx      = 0;
    PRODUCT_INFO_TBL    productInfo;

    if(ppHdfDataset == NULL || ppStdDataset == NULL || iMaxDataset <= 0)
        return FALSE;

    for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
    {
        if(ppStdDataset[iDatasetIdx] == NULL || ppHdfDataset[iDatasetIdx] == NULL)
            continue;

        if(ppStdDataset[iDatasetIdx]->m_ppProductData == NULL || 
           ppHdfDataset[iDatasetIdx]->m_ppProductData == NULL)
            continue;

        // HDF DATASET WHAT
        if(fnGetHdfProductInfo(ppHdfDataset[iDatasetIdx]->m_what.m_szProduct, 
                               &productInfo) == FALSE)
            continue;

        snprintf(ppStdDataset[iDatasetIdx]->m_szProduct, 
                 sizeof(ppStdDataset[iDatasetIdx]->m_szProduct), 
                 "%s", productInfo.m_szStdProduct);
        ppStdDataset[iDatasetIdx]->m_dProdpar[0] 
        = ppHdfDataset[iDatasetIdx]->m_what.m_dProdpar[0];
        ppStdDataset[iDatasetIdx]->m_dProdpar[1] 
        = ppHdfDataset[iDatasetIdx]->m_what.m_dProdpar[1];

        // HDf5 DATA
        if(ppHdfDataset[iDatasetIdx]->m_iMaxField > 0)
        {
            ppStdDataset[iDatasetIdx]->m_iMaxField = ppHdfDataset[iDatasetIdx]->m_iMaxField;
            if(fnConvertStdDataToHdf(ppStdDataset[iDatasetIdx]->m_ppProductData, 
                                      ppHdfDataset[iDatasetIdx]->m_ppProductData,
                                      ppHdfDataset[iDatasetIdx]->m_iMaxField, 
                                      iYdim, iXdim) == FALSE)
                return FALSE;
        }
    }

    return TRUE;
}

// HDF -> STD

static void fnHdfToStdGlobal(HDF_RADAR *pHdf, STD_RADAR *pStd)
{
    int         iSpCnt                  = 0;
    int         iSpIdx                  = 0;
    char        *pSp[8]                 = { NULL, };
    char        szTemp[STR_LENGTH_MAX]  = "";
    struct  tm  tempTm;

    if(pHdf == NULL || pStd == NULL)
        return;

    pStd->m_hdr.m_iVolumeNo = 1;
    // m_szRadarName SKIP
    snprintf(szTemp, sizeof(szTemp), "%s", pHdf->m_what.m_szSource);
    iSpCnt = fnSplit(szTemp, pSp, 8, ',');
    for(iSpIdx = 0; iSpIdx < iSpCnt; iSpIdx++)
    {
        if(!strncmp(pSp[iSpIdx], "NOD:", strlen("NOD:")))
        {
            snprintf(pStd->m_hdr.m_szSiteName, sizeof(pStd->m_hdr.m_szSiteName), 
                     "%s", strstr(pSp[iSpIdx], ":")+1);
        }
    }
    pStd->m_hdr.m_dLat        = pHdf->m_where.m_polar_where.m_dLat;
    pStd->m_hdr.m_dLon        = pHdf->m_where.m_polar_where.m_dLon;
    pStd->m_hdr.m_iAnteHeight = pHdf->m_where.m_polar_where.m_dHeightM;

    if(!strcmp(pHdf->m_what.m_szObject, "PVOL"))
        pStd->m_hdr.m_iSweepMode = STD_EN_SWMD_PPI;
    // m_fSweepRate SKIP
    
    snprintf(pStd->m_hdr.m_szConvertName, sizeof(pStd->m_hdr.m_szConvertName), 
             "%s", pHdf->m_how.m_general_how.m_szTask);

    snprintf(szTemp, sizeof(szTemp), "%s%s", pHdf->m_what.m_szDate, pHdf->m_what.m_szTime);
    memset(&tempTm, 0x00, sizeof(struct tm));
    strptime(szTemp, "%Y%m%d%H%M%S", &tempTm);
    pStd->m_hdr.m_tConvertTime = mktime(&tempTm) + (60*60*9); // KST

    pStd->m_hdr.m_iNoDataValue = (int)(RDR_DF_BAD_VALUE_S);
    pStd->m_hdr.m_iPulseWidth  = (int)(pHdf->m_how.m_radar_how.m_dPulseWidth*
                                       (RDR_DF_SPEED_OF_LIGHT/1.0e6));
    pStd->m_hdr.m_fBeamWidthH  = (float)pHdf->m_how.m_radar_how.m_dBeamwH;
    pStd->m_hdr.m_fBeamWidthV  = (float)pHdf->m_how.m_radar_how.m_dBeamwV;
    pStd->m_hdr.m_iBandWidth   = (int)pHdf->m_how.m_radar_how.m_dRXbandWidth;
    // m_iPolarMode SKIP
    pStd->m_hdr.m_fWaveLength  = (float)pHdf->m_how.m_radar_how.m_dWaveLength;
    // m_iSampleSize SKIP
    // m_szThresholdType SKIP
    // m_iThresholdValue SKIP
    // m_iScale SKIP
    // m_iPRT SKIP
    pStd->m_hdr.m_iBitsPerBin = 16;
}

static void fnHdfToStdSweep(HDF_DATASET *pHdfDset, STD_SWEEP *pStdSweep)
{
    if(pHdfDset == NULL || pStdSweep == NULL)
        return;

    pStdSweep->m_hdr.m_fNyquistVelocity = pHdfDset->m_how.m_radar_how.m_dNi;
    // m_szVelocityFlag SKIP

    pStdSweep->m_hdr.m_fRadarConstant = pHdfDset->m_how.m_radar_how.m_dRadconstH;
    
    // m_fReceiverGain SKIP
    // m_fPeakPower SKIP
    pStdSweep->m_hdr.m_fAntennaGain =  pHdfDset->m_how.m_radar_how.m_dAntgainH;
    // m_fPulseDuration SKIP
}

static void fnHdfToStdRay(HDF_DATASET *pHdfDset, STD_RAY *pStdRay, int iRayIdx)
{
    char        szTemp[STR_LENGTH_MAX]  = "";
    double      dTempAzim               = 0;
    int         iRaySeq                 = 0;
    struct  tm  tempTm;

    if(pHdfDset == NULL || pStdRay == NULL)
        return;

    snprintf(szTemp, sizeof(szTemp), "%s%s", 
             pHdfDset->m_what.m_szStartDate, pHdfDset->m_what.m_szStartTime);
    memset(&tempTm, 0x00, sizeof(struct tm));
    strptime(szTemp, "%Y%m%d%H%M%S", &tempTm);
    pStdRay->m_hdr.m_tTime       = mktime(&tempTm) + (60*60*9); // KST

    dTempAzim = 360.0/pHdfDset->m_where.m_polar_where.m_nRays;
    if(iRayIdx < (int)pHdfDset->m_where.m_polar_where.m_lA1gate)
    {
        iRaySeq = (int)(pHdfDset->m_where.m_polar_where.m_nRays - 
                        pHdfDset->m_where.m_polar_where.m_lA1gate) + iRayIdx;
    }
    else
        iRaySeq = iRayIdx - (int)pHdfDset->m_where.m_polar_where.m_lA1gate;

    pStdRay->m_hdr.m_fAzimuth           = (float)(dTempAzim * iRaySeq);
    
    pStdRay->m_hdr.m_fElevation         = (float)pHdfDset->m_where.m_polar_where.m_dElangle;
    pStdRay->m_hdr.m_fFixedAngle        = (float)pHdfDset->m_where.m_polar_where.m_dElangle;
    
    pStdRay->m_hdr.m_iStartRangeKm      = (int)pHdfDset->m_where.m_polar_where.m_dRstart;
    pStdRay->m_hdr.m_iStartRangeMeter   = (int)((pHdfDset->m_where.m_polar_where.m_dRstart - 
                                                 pStdRay->m_hdr.m_iStartRangeKm) * 1000);
    pStdRay->m_hdr.m_iBinSpacing        = (int)pHdfDset->m_where.m_polar_where.m_dRScale;
}

static void fnHdfToStdField(HDF_DATA *pHdfData, STD_FIELD *pStdField, int iRayIdx, int nBins)
{
    int             iBinIdx = 0;
    FIELD_INFO_TBL  fieldInfo;

    if(pHdfData == NULL || pStdField == NULL)
        return;

    memset(&fieldInfo, 0x00, sizeof(fieldInfo));
    if(fnGetHdfFieldInfo(pHdfData->m_what.m_szQuantity, &fieldInfo) == FALSE)
        return;

    pStdField->m_hdr.m_iScaleFactor = RDR_DF_SHORT_SCALE;
    snprintf(pStdField->m_hdr.m_szFieldName, sizeof(pStdField->m_hdr.m_szFieldName),
             "%s", fieldInfo.m_szFieldName);

    for(iBinIdx = 0; iBinIdx < nBins; iBinIdx++)
    {
        if(fabs(pHdfData->m_ppData[iRayIdx][iBinIdx]-RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
           pStdField->m_pData[iBinIdx] = RDR_DF_BAD_VALUE_S;
        else if(fabs(pHdfData->m_ppData[iRayIdx][iBinIdx]-RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
           pStdField->m_pData[iBinIdx] = RDR_DF_BAD_VALUE_S;
        else
        {
            pStdField->m_pData[iBinIdx] 
            = (short)(pHdfData->m_ppData[iRayIdx][iBinIdx]*RDR_DF_SHORT_SCALE);
        }
    }
}

// BUFR -> STD

static void fnBufrToStdGlobal(BUFR_RADAR *pBufr, STD_RADAR *pStd)
{
    int         iSpCnt                  = 0;
    int         iSpIdx                  = 0;
    char        *pSp[8]                 = { NULL, };
    char        szTemp[STR_LENGTH_MAX]  = "";
    struct  tm  tempTm;

    if(pBufr == NULL || pStd == NULL)
        return;

    pStd->m_hdr.m_iVolumeNo = 1;
    // m_szRadarName SKIP
    snprintf(szTemp, sizeof(szTemp), "%s", pBufr->m_what.m_szSource);
    iSpCnt = fnSplit(szTemp, pSp, 8, ',');
    for(iSpIdx = 0; iSpIdx < iSpCnt; iSpIdx++)
    {
        if(!strncmp(pSp[iSpIdx], "NOD:", strlen("NOD:")))
        {
            snprintf(pStd->m_hdr.m_szSiteName, sizeof(pStd->m_hdr.m_szSiteName), 
                     "%s", strstr(pSp[iSpIdx], ":")+1);
        }
    }
    pStd->m_hdr.m_dLat        = pBufr->m_where.m_polar_where.m_dLat;
    pStd->m_hdr.m_dLon        = pBufr->m_where.m_polar_where.m_dLon;
    pStd->m_hdr.m_iAnteHeight = pBufr->m_where.m_polar_where.m_dHeightM;

    if(!strcmp(pBufr->m_what.m_szObject, "PVOL"))
        pStd->m_hdr.m_iSweepMode = STD_EN_SWMD_PPI;
    // m_fSweepRate SKIP
    
    snprintf(pStd->m_hdr.m_szConvertName, sizeof(pStd->m_hdr.m_szConvertName), 
             "%s", pBufr->m_how.m_general_how.m_szTask);

    snprintf(szTemp, sizeof(szTemp), "%s%s", pBufr->m_what.m_szDate, pBufr->m_what.m_szTime);
    memset(&tempTm, 0x00, sizeof(struct tm));
    strptime(szTemp, "%Y%m%d%H%M%S", &tempTm);
    pStd->m_hdr.m_tConvertTime = mktime(&tempTm) + (60*60*9); // KST

    pStd->m_hdr.m_iNoDataValue = (int)(RDR_DF_BAD_VALUE_S);
    pStd->m_hdr.m_iPulseWidth  = (int)(pBufr->m_how.m_radar_how.m_dPulseWidth *
                                       (RDR_DF_SPEED_OF_LIGHT/1.0e6));
    pStd->m_hdr.m_fBeamWidthH  = (float)pBufr->m_how.m_radar_how.m_dBeamwH;
    pStd->m_hdr.m_fBeamWidthV  = (float)pBufr->m_how.m_radar_how.m_dBeamwV;
    pStd->m_hdr.m_iBandWidth   = (int)pBufr->m_how.m_radar_how.m_dRXbandWidth;
    // m_iPolarMode SKIP
    pStd->m_hdr.m_fWaveLength  = (float)pBufr->m_how.m_radar_how.m_dWaveLength;
    // m_iSampleSize SKIP
    // m_szThresholdType SKIP
    // m_iThresholdValue SKIP
    // m_iScale SKIP
    // m_iPRT SKIP
    pStd->m_hdr.m_iBitsPerBin = 16;
}

static void fnBufrToStdSweep(BUFR_DATASET *pBufrDset, STD_SWEEP *pStdSweep)
{
    if(pBufrDset == NULL || pStdSweep == NULL)
        return;

    pStdSweep->m_hdr.m_fNyquistVelocity = pBufrDset->m_how.m_radar_how.m_dNi;
    // m_szVelocityFlag SKIP

    pStdSweep->m_hdr.m_fRadarConstant = pBufrDset->m_how.m_radar_how.m_dRadconstH;
    
    // m_fReceiverGain SKIP
    // m_fPeakPower SKIP
    pStdSweep->m_hdr.m_fAntennaGain =  pBufrDset->m_how.m_radar_how.m_dAntgainH;
    // m_fPulseDuration SKIP
}

static void fnBufrToStdRay(BUFR_DATASET *pBufrDset, STD_RAY *pStdRay, int iRayIdx)
{
    char        szTemp[STR_LENGTH_MAX]  = "";
    double      dTempAzim               = 0;
    int         iRaySeq                 = 0;
    struct  tm  tempTm;

    if(pBufrDset == NULL || pStdRay == NULL)
        return;

    snprintf(szTemp, sizeof(szTemp), "%s%s", 
             pBufrDset->m_what.m_szStartDate, pBufrDset->m_what.m_szStartTime);
    memset(&tempTm, 0x00, sizeof(struct tm));
    strptime(szTemp, "%Y%m%d%H%M%S", &tempTm);
    pStdRay->m_hdr.m_tTime       = mktime(&tempTm) + (60*60*9); // KST

    dTempAzim = 360.0/pBufrDset->m_where.m_polar_where.m_nRays;
    if(iRayIdx < (int)pBufrDset->m_where.m_polar_where.m_lA1gate)
    {
        iRaySeq = (int)(pBufrDset->m_where.m_polar_where.m_nRays - 
                        pBufrDset->m_where.m_polar_where.m_lA1gate) + iRayIdx;
    }
    else
        iRaySeq = iRayIdx - (int)pBufrDset->m_where.m_polar_where.m_lA1gate;

    pStdRay->m_hdr.m_fAzimuth           = (float)(dTempAzim * iRaySeq);
    
    pStdRay->m_hdr.m_fElevation         = (float)pBufrDset->m_where.m_polar_where.m_dElangle;
    pStdRay->m_hdr.m_fFixedAngle        = (float)pBufrDset->m_where.m_polar_where.m_dElangle;
    
    pStdRay->m_hdr.m_iStartRangeKm      = (int)pBufrDset->m_where.m_polar_where.m_dRstart;
    pStdRay->m_hdr.m_iStartRangeMeter   = (int)((pBufrDset->m_where.m_polar_where.m_dRstart - 
                                                 pStdRay->m_hdr.m_iStartRangeKm) * 1000);
    pStdRay->m_hdr.m_iBinSpacing        = (int)pBufrDset->m_where.m_polar_where.m_dRScale;
}

static void fnBufrToStdField(BUFR_DATA *pBufrData, STD_FIELD *pStdField, int iRayIdx, int nBins)
{
    int             iBinIdx = 0;
    float           fData   = 0.0;
    FIELD_INFO_TBL  fieldInfo;

    if(pBufrData == NULL || pStdField == NULL)
        return;

    memset(&fieldInfo, 0x00, sizeof(fieldInfo));

    if(fnGetBufrFieldInfo(pBufrData->m_what.m_szQuantity, &fieldInfo) == FALSE)
        return;

    pStdField->m_hdr.m_iScaleFactor = RDR_DF_SHORT_SCALE;
    snprintf(pStdField->m_hdr.m_szFieldName, sizeof(pStdField->m_hdr.m_szFieldName),
             "%s", fieldInfo.m_szFieldName);

    for(iBinIdx = 0; iBinIdx < nBins; iBinIdx++)
    {
        fData = pBufrData->m_ppData[iRayIdx][iBinIdx];
        if(fabs(fData - RDR_DF_OUT_BOUND_F) < RDR_DF_ERR_RANGE_F)
           pStdField->m_pData[iBinIdx] = RDR_DF_BAD_VALUE_S;
        else if(fabs(fData - RDR_DF_BAD_VALUE_F) < RDR_DF_ERR_RANGE_F)
           pStdField->m_pData[iBinIdx] = RDR_DF_BAD_VALUE_S;
        else
            pStdField->m_pData[iBinIdx] = (short)(fData * RDR_DF_SHORT_SCALE);
    }
}

// BUFR PRODUCT -> STD PRODUCT

static void fnConvertStdProductHdrToBufr(STD_PRODUCT *pStdProduct, BUFR_PRODUCT *pBufrProduct)
{
    char        szDateTime[15+1]    = "";
    char        szTemp[256]         = "";
    char        *szSplit[2]         = { NULL, };
    struct  tm  tm;

    if(pStdProduct == NULL || pBufrProduct == NULL)
        return;

    // BUFR TOP WHAT
    snprintf(szDateTime, sizeof(szDateTime), 
             "%s%s", pBufrProduct->m_what.m_szDate, pBufrProduct->m_what.m_szTime);
    memset(&tm, 0x00, sizeof(tm));
    strptime(szDateTime, "%Y%m%d%H%M%S", &tm);
    pStdProduct->m_product_hdr.m_tConvertTime = mktime(&tm) + (60*60*9); // KST
    if(pBufrProduct->m_iBufrProductType == BUFR_EN_PRODUCT_SITE)
    {
        snprintf(szTemp, sizeof(szTemp), "%s", pBufrProduct->m_what.m_szSource);
        if(fnSplit(szTemp, szSplit, 2, ':') == 2)
        {
            snprintf(pStdProduct->m_product_hdr.m_szSiteName , 
                     sizeof(pStdProduct->m_product_hdr.m_szSiteName), "%s", szSplit[1]);
        }
    }

    // BUFR TOP WHERE
    pStdProduct->m_product_hdr.m_dLon         = pBufrProduct->m_where.m_polar_where.m_dLon;
    pStdProduct->m_product_hdr.m_dLat         = pBufrProduct->m_where.m_polar_where.m_dLat;
    pStdProduct->m_product_hdr.m_iAnteHeightM = pBufrProduct->m_where.m_polar_where.m_dHeightM;
    pStdProduct->m_product_hdr.m_lXsize       = pBufrProduct->m_where.m_image_where.m_lXsize;
    pStdProduct->m_product_hdr.m_lYsize       = pBufrProduct->m_where.m_image_where.m_lYsize;
    pStdProduct->m_product_hdr.m_dXscale      = pBufrProduct->m_where.m_image_where.m_dXscale;
    pStdProduct->m_product_hdr.m_dYscale      = pBufrProduct->m_where.m_image_where.m_dYscale;
    pStdProduct->m_product_hdr.m_LL_lon       = pBufrProduct->m_where.m_image_where.m_LL_lon;
    pStdProduct->m_product_hdr.m_LL_lat       = pBufrProduct->m_where.m_image_where.m_LL_lat;
    pStdProduct->m_product_hdr.m_UL_lon       = pBufrProduct->m_where.m_image_where.m_UL_lon;
    pStdProduct->m_product_hdr.m_UL_lat       = pBufrProduct->m_where.m_image_where.m_UL_lat;
    pStdProduct->m_product_hdr.m_UR_lon       = pBufrProduct->m_where.m_image_where.m_UR_lon;
    pStdProduct->m_product_hdr.m_UR_lat       = pBufrProduct->m_where.m_image_where.m_UR_lat;
    pStdProduct->m_product_hdr.m_LR_lon       = pBufrProduct->m_where.m_image_where.m_LR_lon;
    pStdProduct->m_product_hdr.m_LR_lat       = pBufrProduct->m_where.m_image_where.m_LR_lat;

    // BUFR TOP HOW
    pStdProduct->m_product_hdr.m_dNi          = pBufrProduct->m_how.m_radar_how.m_dNi;
}

static int fnConvertStdDataToBufr(STD_PRODUCT_DATA **ppStdData, BUFR_PRODUCT_DATA **ppBufrData, int iMaxField, int iYdim, int iXdim)
{
    int             iFieldIdx       = 0;

    if(ppStdData == NULL || ppBufrData == NULL || iMaxField <= 0)
        return FALSE;

    for(iFieldIdx = 0; iFieldIdx < iMaxField; iFieldIdx++)
    {
        if(ppStdData[iFieldIdx] == NULL || ppBufrData[iFieldIdx] == NULL)
            return FALSE;

        if(ppBufrData[iFieldIdx]->m_ppData_c == NULL &&
           ppBufrData[iFieldIdx]->m_ppData_s == NULL && 
           ppBufrData[iFieldIdx]->m_ppData_f == NULL)
            continue;

        snprintf(ppStdData[iFieldIdx]->m_szFieldName, 
                 sizeof(ppStdData[iFieldIdx]->m_szFieldName), 
                 "%s", ppBufrData[iFieldIdx]->m_szFieldName);

        // BUFR DATA
        // 메모리 사용량 문제로 배열을 복사하지 않고 pointer를 옮김
        ppStdData[iFieldIdx]->m_iMemType = ppBufrData[iFieldIdx]->m_iMemType;

        ppStdData[iFieldIdx]->m_ppData_c  = ppBufrData[iFieldIdx]->m_ppData_c;
        ppBufrData[iFieldIdx]->m_ppData_c = NULL;

        ppStdData[iFieldIdx]->m_ppData_s  = ppBufrData[iFieldIdx]->m_ppData_s;
        ppBufrData[iFieldIdx]->m_ppData_s = NULL;

        ppStdData[iFieldIdx]->m_ppData_f  = ppBufrData[iFieldIdx]->m_ppData_f;
        ppBufrData[iFieldIdx]->m_ppData_f = NULL;
    }

    return TRUE;
}

static int fnConvertStdDatasetToBufr(STD_PRODUCT_DATASET **ppStdDataset, BUFR_PRODUCT_DATASET **ppBufrDataset, int iMaxDataset, int iYdim, int iXdim)
{
    int                 iDatasetIdx      = 0;
    PRODUCT_INFO_TBL    productInfo;

    if(ppBufrDataset == NULL || ppStdDataset == NULL || iMaxDataset <= 0)
        return FALSE;

    for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
    {
        if(ppStdDataset[iDatasetIdx] == NULL || ppBufrDataset[iDatasetIdx] == NULL)
            continue;

        if(ppStdDataset[iDatasetIdx]->m_ppProductData == NULL || 
           ppBufrDataset[iDatasetIdx]->m_ppProductData == NULL)
            continue;

        // BUFR DATASET WHAT
        if(fnGetBufrProductInfo(ppBufrDataset[iDatasetIdx]->m_what.m_szProduct, 
                               &productInfo) == FALSE)
            continue;

        snprintf(ppStdDataset[iDatasetIdx]->m_szProduct, 
                 sizeof(ppStdDataset[iDatasetIdx]->m_szProduct), 
                 "%s", productInfo.m_szStdProduct);
        ppStdDataset[iDatasetIdx]->m_dProdpar[0] 
        = ppBufrDataset[iDatasetIdx]->m_what.m_dProdpar[0];
        ppStdDataset[iDatasetIdx]->m_dProdpar[1] 
        = ppBufrDataset[iDatasetIdx]->m_what.m_dProdpar[1];

        // BUFR DATA
        if(ppBufrDataset[iDatasetIdx]->m_iMaxField > 0)
        {
            ppStdDataset[iDatasetIdx]->m_iMaxField = ppBufrDataset[iDatasetIdx]->m_iMaxField;
            if(fnConvertStdDataToBufr(ppStdDataset[iDatasetIdx]->m_ppProductData, 
                                      ppBufrDataset[iDatasetIdx]->m_ppProductData,
                                      ppBufrDataset[iDatasetIdx]->m_iMaxField, 
                                      iYdim, iXdim) == FALSE)
                return FALSE;
        }
    }

    return TRUE;
}

// NC -> STD

static void fnNcToStdGlobal(NC_RADAR *pNc, STD_RADAR *pStd)
{
    int         iYear   = 0;
    int         iMonth  = 0;
    int         iDay    = 0;
    int         iHour   = 0;
    int         iMin    = 0;
    int         iSec    = 0;

    if(pNc == NULL || pStd == NULL)
        return;

    pStd->m_hdr.m_iVolumeNo = pNc->m_global_var.m_iVolume_number;
    snprintf(pStd->m_hdr.m_szRadarName, sizeof(pStd->m_hdr.m_szRadarName),
             "%s", pNc->m_global_attr.m_szInstrument_name);
    snprintf(pStd->m_hdr.m_szSiteName, sizeof(pStd->m_hdr.m_szSiteName), 
             "%s", pNc->m_global_attr.m_szSite_name);
    pStd->m_hdr.m_dLat        = pNc->m_locat_var.m_dLatitude;
    pStd->m_hdr.m_dLon        = pNc->m_locat_var.m_dLongitude;
    pStd->m_hdr.m_iAnteHeight = pNc->m_locat_var.m_dAltitude;

    if(!strcmp(pNc->m_sweep_var.m_ppSweep_mode[0], "sector"))
        pStd->m_hdr.m_iSweepMode = STD_EN_SWMD_SECTOR;
    else if(!strcmp(pNc->m_sweep_var.m_ppSweep_mode[0], "coplane"))
        pStd->m_hdr.m_iSweepMode = STD_EN_SWMD_COPLANE;
    else if(!strcmp(pNc->m_sweep_var.m_ppSweep_mode[0], "rhi"))
        pStd->m_hdr.m_iSweepMode = STD_EN_SWMD_RHI;
    else if(!strcmp(pNc->m_sweep_var.m_ppSweep_mode[0], "vertical_pointing"))
        pStd->m_hdr.m_iSweepMode = STD_EN_SWMD_VERTICAL;
    else if(!strcmp(pNc->m_sweep_var.m_ppSweep_mode[0], "idle"))
        pStd->m_hdr.m_iSweepMode = STD_EN_SWMD_IDLE;
    else if(!strcmp(pNc->m_sweep_var.m_ppSweep_mode[0], "azimuth_surveillance"))
        pStd->m_hdr.m_iSweepMode = STD_EN_SWMD_PPI;
    else if(!strcmp(pNc->m_sweep_var.m_ppSweep_mode[0], "elevation_suveillance"))
        pStd->m_hdr.m_iSweepMode = STD_EN_SWMD_RHI;
    else if(!strcmp(pNc->m_sweep_var.m_ppSweep_mode[0], "sunscan"))
        pStd->m_hdr.m_iSweepMode = STD_EN_SWMD_SUNSCAN;
    else if(!strcmp(pNc->m_sweep_var.m_ppSweep_mode[0], "pointing"))
        pStd->m_hdr.m_iSweepMode = STD_EN_SWMD_POINTING;
    else if(!strcmp(pNc->m_sweep_var.m_ppSweep_mode[0], "manual_ppi"))
        pStd->m_hdr.m_iSweepMode = STD_EN_SWMD_MANUAL;
    else if(!strcmp(pNc->m_sweep_var.m_ppSweep_mode[0], "manual_rhi"))
        pStd->m_hdr.m_iSweepMode = STD_EN_SWMD_MANUAL;

    pStd->m_hdr.m_fSweepRate = pNc->m_sweep_var.m_pTarget_scan_rate[0];
    
    snprintf(pStd->m_hdr.m_szConvertName, sizeof(pStd->m_hdr.m_szConvertName), 
             "%s", pNc->m_global_attr.m_szScan_name);


    sscanf(pNc->m_global_var.m_szTime_coverage_start, "%04d-%02d-%02dT%02d:%02d:%02dZ",
           &iYear, &iMonth, &iDay, &iHour, &iMin, &iSec);

    pStd->m_hdr.m_tConvertTime = fnMakeTime(TRUE, iYear, iMonth, iDay, iHour, iMin, iSec); // KST
    pStd->m_hdr.m_iNoDataValue = (int)(RDR_DF_BAD_VALUE_S);

    // m_szProjectName SKIP
    // m_fBaselineAzimuth SKIP
    // m_fBaselineElevation SKIP
    // m_szFieldTapeName SKIP

    if(pNc->m_instru_sub.m_pPulse_width != NULL)
        pStd->m_hdr.m_iPulseWidth  = (int)pNc->m_instru_sub.m_pPulse_width[0];

    pStd->m_hdr.m_fBeamWidthH  = (float)pNc->m_radar_sub.m_fRadar_beam_width_h;
    pStd->m_hdr.m_fBeamWidthV  = (float)pNc->m_radar_sub.m_fRadar_beam_width_v;
    pStd->m_hdr.m_iBandWidth   = (int)pNc->m_radar_sub.m_fRadar_receiver_bandwidth;

    if(pNc->m_instru_sub.m_ppPolarization_mode    != NULL &&
       pNc->m_instru_sub.m_ppPolarization_mode[0] != NULL)
    {
        if(!strcmp(pNc->m_instru_sub.m_ppPolarization_mode[0], "horizontal"))
            pStd->m_hdr.m_iPolarMode = STD_EN_PM_HORIZONTAL;
        else if(!strcmp(pNc->m_instru_sub.m_ppPolarization_mode[0], "vertical"))
            pStd->m_hdr.m_iPolarMode = STD_EN_PM_VERTICAL;
        else if(!strcmp(pNc->m_instru_sub.m_ppPolarization_mode[0], "hv_alt"))
            pStd->m_hdr.m_iPolarMode = STD_EN_PM_HV_ALT;
        else if(!strcmp(pNc->m_instru_sub.m_ppPolarization_mode[0], "hv_sim"))
            pStd->m_hdr.m_iPolarMode = STD_EN_PM_HV_SIM;
        else if(!strcmp(pNc->m_instru_sub.m_ppPolarization_mode[0], "circular"))
            pStd->m_hdr.m_iPolarMode = STD_EN_PM_CIRCULAR;
    }

    // pStd->m_hdr.m_fWaveLength SKIP
    // m_szThresholdType SKIP
    // m_iThresholdValue SKIP
    // m_iScale SKIP

    if(pNc->m_instru_sub.m_pPrt != NULL)
        pStd->m_hdr.m_iPRT = pNc->m_instru_sub.m_pPrt[0] * 1000000;

    pStd->m_hdr.m_iBitsPerBin = 16;
}

static void fnNcToStdSweep(NC_RADAR *pNc, STD_SWEEP *pStdSweep)
{
    if(pNc == NULL || pStdSweep == NULL)
        return;

    if(pNc->m_instru_sub.m_pNyquist_velocity != NULL)
        pStdSweep->m_hdr.m_fNyquistVelocity = pNc->m_instru_sub.m_pNyquist_velocity[0];

    // m_szVelocityFlag SKIP

    if(pNc->m_r_calib_sub.m_pR_calib_radar_constant_h != NULL)
        pStdSweep->m_hdr.m_fRadarConstant = pNc->m_r_calib_sub.m_pR_calib_radar_constant_h[0];

    if(pNc->m_r_calib_sub.m_pR_calib_receiver_gain_hc != NULL)
        pStdSweep->m_hdr.m_fReceiverGain = pNc->m_r_calib_sub.m_pR_calib_receiver_gain_hc[0];

    // m_fPeakPower SKIP
    pStdSweep->m_hdr.m_fAntennaGain = pNc->m_radar_sub.m_fRadar_antenna_gain_h;
    // m_fPulseDuration SKIP
}

static void fnNcToStdRay(NC_RADAR *pNc, int iSweepIdx, int iRayIdx, STD_RAY *pStdRay)
{
    int         iYear           = 0;
    int         iMonth          = 0;
    int         iDay            = 0;
    int         iHour           = 0;
    int         iMin            = 0;
    int         iSec            = 0;
    int         iRayAddSec      = 0;
    int         iStartRangeM    = 0;

    if(pNc == NULL || pStdRay == NULL)
        return;

    sscanf(pNc->m_global_var.m_szTime_coverage_start, "%04d-%02d-%02dT%02d:%02d:%02dZ",
           &iYear, &iMonth, &iDay, &iHour, &iMin, &iSec);

    if(pNc->m_coordi_var.m_pTime != NULL)
        iRayAddSec = pNc->m_coordi_var.m_pTime[iRayIdx];

    pStdRay->m_hdr.m_tTime = fnMakeTime(TRUE, iYear, iMonth, iDay, iHour, iMin, iSec)
                             + iRayAddSec; // KST

    if(pNc->m_sensor_var.m_pAzimuth != NULL)
        pStdRay->m_hdr.m_fAzimuth = pNc->m_sensor_var.m_pAzimuth[iRayIdx];

    if(pNc->m_sensor_var.m_pElevation != NULL)
        pStdRay->m_hdr.m_fElevation = pNc->m_sensor_var.m_pElevation[iRayIdx];

    if(pNc->m_sweep_var.m_pFixed_angle != NULL)
        pStdRay->m_hdr.m_fFixedAngle = pNc->m_sweep_var.m_pFixed_angle[iSweepIdx];

    iStartRangeM = pNc->m_coordi_var.m_rangeAttr.m_fMeters_to_center_of_first_gate;

    pStdRay->m_hdr.m_iStartRangeKm    = (int)(iStartRangeM/1000.);
    pStdRay->m_hdr.m_iStartRangeMeter = (int)(iStartRangeM - pStdRay->m_hdr.m_iStartRangeKm);

    pStdRay->m_hdr.m_iBinSpacing = pNc->m_coordi_var.m_rangeAttr.m_fMeters_between_gates;

    if(pNc->m_instru_sub.m_pN_samples != NULL)
        pStdRay->m_hdr.m_iSampleSize = pNc->m_instru_sub.m_pN_samples[iRayIdx];
}

static void fnNcToStdField(NC_RADAR *pNc, int iRayIdx, int iFieldIdx, STD_FIELD *pStdField)
{
    NC_MOMENT_VAR   *pMomentVar = NULL;
    float           fData       = 0.0;
    int             iBinIdx     = 0;
    FIELD_INFO_TBL  fieldInfo;

    if(pNc == NULL || pStdField == NULL)
        return;

    pMomentVar = &pNc->m_moment_var[iFieldIdx];

    memset(&fieldInfo, 0x00, sizeof(FIELD_INFO_TBL));
    if((fnGetNcFieldInfo(pMomentVar->m_szMoment, &fieldInfo)) == FALSE)
        return;

    pStdField->m_hdr.m_iScaleFactor = RDR_DF_SHORT_SCALE;
    snprintf(pStdField->m_hdr.m_szFieldName, sizeof(pStdField->m_hdr.m_szFieldName),
             "%s", fieldInfo.m_szFieldName);

    for(iBinIdx = 0; iBinIdx < pNc->m_dim.m_nRange; iBinIdx++)
    {
        fData = pMomentVar->m_pData[iRayIdx*pNc->m_dim.m_nRange+iBinIdx] 
                * pMomentVar->m_momentAttr.m_fScale_factor 
                + pMomentVar->m_momentAttr.m_fAdd_offset;

        pStdField->m_pData[iBinIdx] = (short)(fData * RDR_DF_SHORT_SCALE);
    }
}

// GRIB -> STD

static void fnGribToStdGlobal(GRIB_RADAR *pGrib, STD_RADAR *pStd)
{
    if(pGrib == NULL || pStd == NULL)
        return;

    // iVolumeNO SKIP
    snprintf(pStd->m_hdr.m_szRadarName, sizeof(pStd->m_hdr.m_szRadarName), 
             "%s", pGrib->m_hdr.m_szRadarName);

    snprintf(pStd->m_hdr.m_szSiteName, sizeof(pStd->m_hdr.m_szSiteName), 
             "%s", pGrib->m_hdr.m_szSiteName);

    pStd->m_hdr.m_dLat              = pGrib->m_hdr.m_dLat;
    pStd->m_hdr.m_dLon              = pGrib->m_hdr.m_dLon;
    pStd->m_hdr.m_iAnteHeight       = pGrib->m_hdr.m_iAnteHeight;
    pStd->m_hdr.m_iSweepMode        = pGrib->m_hdr.m_iSweepMode;
    pStd->m_hdr.m_fSweepRate        = pGrib->m_hdr.m_fSweepRate;

    snprintf(pStd->m_hdr.m_szConvertName, sizeof(pStd->m_hdr.m_szConvertName), 
             "%s", pGrib->m_hdr.m_szConvertName);
    
    pStd->m_hdr.m_tConvertTime      = pGrib->m_hdr.m_tConvertTime + (60*60*9); // KST
    pStd->m_hdr.m_iNoDataValue      = pGrib->m_hdr.m_iNoDataValue;

    // Option Header SKIP

    pStd->m_hdr.m_iPulseWidth       = pGrib->m_hdr.m_iPulseWidth;
    pStd->m_hdr.m_fBeamWidthH       = pGrib->m_hdr.m_fBeamWidthH;
    pStd->m_hdr.m_fBeamWidthV       = pGrib->m_hdr.m_fBeamWidthV;
    pStd->m_hdr.m_iBandWidth        = pGrib->m_hdr.m_iBandWidth;
    pStd->m_hdr.m_iPolarMode        = pGrib->m_hdr.m_iPolarMode;
    pStd->m_hdr.m_fWaveLength       = pGrib->m_hdr.m_fWaveLength;
    // szThresholdType SKIP
    pStd->m_hdr.m_iThresholdValue   = pGrib->m_hdr.m_iThresholdValue;
    pStd->m_hdr.m_iScale            = pGrib->m_hdr.m_iScale;
    // szEditCode SKIP
    pStd->m_hdr.m_iPRT              = pGrib->m_hdr.m_iPRT;
    pStd->m_hdr.m_iBitsPerBin       = pGrib->m_hdr.m_iBitsPerBin;
}

static void fnGribToStdRay(GRIB_RADAR *pGrib, int iCurRay, STD_RAY *pStdRay, time_t tConvertTime)
{
    if(pGrib == NULL || pStdRay == NULL)
        return;

    if(pGrib->m_hdr.m_pRayTime != NULL)
        pStdRay->m_hdr.m_tTime = tConvertTime + (int)pGrib->m_hdr.m_pRayTime[iCurRay];

    if(pGrib->m_hdr.m_pRayAzimuth != NULL)
        pStdRay->m_hdr.m_fAzimuth = (float)pGrib->m_hdr.m_pRayAzimuth[iCurRay];

    if(pGrib->m_hdr.m_pRayElevation != NULL)
        pStdRay->m_hdr.m_fElevation = (float)pGrib->m_hdr.m_pRayElevation[iCurRay];

    if(pGrib->m_hdr.m_pRayFixedAngle != NULL)
        pStdRay->m_hdr.m_fFixedAngle = (float)pGrib->m_hdr.m_pRayFixedAngle[iCurRay];

    pStdRay->m_hdr.m_iStartRangeKm    = (int)(pGrib->m_hdr.m_fStartRangeMeter / 1000.0);
    pStdRay->m_hdr.m_iStartRangeMeter = (int)(pGrib->m_hdr.m_fStartRangeMeter 
                                              - (pStdRay->m_hdr.m_iStartRangeKm * 1000));
    pStdRay->m_hdr.m_iBinSpacing      = (int)pGrib->m_hdr.m_iBinSpacing;
    pStdRay->m_hdr.m_iSampleSize      = pGrib->m_hdr.m_iSampleSize;
}

// GRIB PRODUCT -> STD PRODUCT

static void fnConvertStdProductHdrToGrib(STD_PRODUCT *pStdProduct, GRIB_PRODUCT *pGribProduct)
{
    char        szDateTime[15+1]    = "";
    struct  tm  tm;

    if(pStdProduct == NULL || pGribProduct == NULL)
        return;

    // GRIB TOP WHAT
    snprintf(szDateTime, sizeof(szDateTime), 
             "%s%s", pGribProduct->m_what.m_szDate, pGribProduct->m_what.m_szTime);
    memset(&tm, 0x00, sizeof(tm));
    strptime(szDateTime, "%Y%m%d%H%M%S", &tm);
    pStdProduct->m_product_hdr.m_tConvertTime = mktime(&tm) + (60*60*9); // KST

    // GRIB TOP WHERE
    pStdProduct->m_product_hdr.m_dLon         = pGribProduct->m_where.m_dLon;
    pStdProduct->m_product_hdr.m_dLat         = pGribProduct->m_where.m_dLat;
    pStdProduct->m_product_hdr.m_iAnteHeightM = pGribProduct->m_where.m_dHeightM;
    pStdProduct->m_product_hdr.m_lXsize       = pGribProduct->m_where.m_lXsize;
    pStdProduct->m_product_hdr.m_lYsize       = pGribProduct->m_where.m_lYsize;
    pStdProduct->m_product_hdr.m_dXscale      = pGribProduct->m_where.m_dXscale;
    pStdProduct->m_product_hdr.m_dYscale      = pGribProduct->m_where.m_dYscale;
    pStdProduct->m_product_hdr.m_LL_lon       = pGribProduct->m_where.m_LL_lon;
    pStdProduct->m_product_hdr.m_LL_lat       = pGribProduct->m_where.m_LL_lat;
    pStdProduct->m_product_hdr.m_UL_lon       = pGribProduct->m_where.m_UL_lon;
    pStdProduct->m_product_hdr.m_UL_lat       = pGribProduct->m_where.m_UL_lat;
    pStdProduct->m_product_hdr.m_UR_lon       = pGribProduct->m_where.m_UR_lon;
    pStdProduct->m_product_hdr.m_UR_lat       = pGribProduct->m_where.m_UR_lat;
    pStdProduct->m_product_hdr.m_LR_lon       = pGribProduct->m_where.m_LR_lon;
    pStdProduct->m_product_hdr.m_LR_lat       = pGribProduct->m_where.m_LR_lat;
}

static int fnConvertStdDataToGrib(STD_PRODUCT_DATA **ppStdData, GRIB_PRODUCT_DATA **ppGribData, int iMaxField, int iYdim, int iXdim)
{
    int             iFieldIdx       = 0;

    if(ppStdData == NULL || ppGribData == NULL || iMaxField <= 0)
        return FALSE;

    for(iFieldIdx = 0; iFieldIdx < iMaxField; iFieldIdx++)
    {
        if(ppStdData[iFieldIdx] == NULL || ppGribData[iFieldIdx] == NULL)
            return FALSE;

        if(ppGribData[iFieldIdx]->m_ppData_c == NULL &&
           ppGribData[iFieldIdx]->m_ppData_s == NULL && 
           ppGribData[iFieldIdx]->m_ppData_f == NULL)
            continue;

        snprintf(ppStdData[iFieldIdx]->m_szFieldName, 
                 sizeof(ppStdData[iFieldIdx]->m_szFieldName), 
                 "%s", ppGribData[iFieldIdx]->m_szFieldName);

        // GRIB DATA
        // 메모리 사용량 문제로 배열을 복사하지 않고 pointer를 옮김
        ppStdData[iFieldIdx]->m_iMemType = ppGribData[iFieldIdx]->m_iMemType;

        ppStdData[iFieldIdx]->m_ppData_c  = ppGribData[iFieldIdx]->m_ppData_c;
        ppGribData[iFieldIdx]->m_ppData_c = NULL;

        ppStdData[iFieldIdx]->m_ppData_s  = ppGribData[iFieldIdx]->m_ppData_s;
        ppGribData[iFieldIdx]->m_ppData_s = NULL;

        ppStdData[iFieldIdx]->m_ppData_f  = ppGribData[iFieldIdx]->m_ppData_f;
        ppGribData[iFieldIdx]->m_ppData_f = NULL;
    }

    return TRUE;
}

static int fnConvertStdDatasetToGrib(STD_PRODUCT_DATASET **ppStdDataset, GRIB_PRODUCT_DATASET **ppGribDataset, int iMaxDataset, int iYdim, int iXdim)
{
    int                 iDatasetIdx      = 0;
    PRODUCT_INFO_TBL    productInfo;

    if(ppGribDataset == NULL || ppStdDataset == NULL || iMaxDataset <= 0)
        return FALSE;

    for(iDatasetIdx = 0; iDatasetIdx < iMaxDataset; iDatasetIdx++)
    {
        if(ppStdDataset[iDatasetIdx] == NULL || ppGribDataset[iDatasetIdx] == NULL)
            continue;

        if(ppStdDataset[iDatasetIdx]->m_ppProductData == NULL || 
           ppGribDataset[iDatasetIdx]->m_ppProductData == NULL)
            continue;

        // GRIB DATASET WHAT
        if(fnGetGribProductInfo(ppGribDataset[iDatasetIdx]->m_what.m_szProduct, 
                               &productInfo) == FALSE)
            continue;

        snprintf(ppStdDataset[iDatasetIdx]->m_szProduct, 
                 sizeof(ppStdDataset[iDatasetIdx]->m_szProduct), 
                 "%s", productInfo.m_szStdProduct);
        ppStdDataset[iDatasetIdx]->m_dProdpar[0] 
        = ppGribDataset[iDatasetIdx]->m_what.m_dProdpar[0];
        ppStdDataset[iDatasetIdx]->m_dProdpar[1] 
        = ppGribDataset[iDatasetIdx]->m_what.m_dProdpar[1];

        // GRIB DATA
        if(ppGribDataset[iDatasetIdx]->m_iMaxField > 0)
        {
            ppStdDataset[iDatasetIdx]->m_iMaxField = ppGribDataset[iDatasetIdx]->m_iMaxField;
            if(fnConvertStdDataToGrib(ppStdDataset[iDatasetIdx]->m_ppProductData, 
                                      ppGribDataset[iDatasetIdx]->m_ppProductData,
                                      ppGribDataset[iDatasetIdx]->m_iMaxField, 
                                      iYdim, iXdim) == FALSE)
                return FALSE;
        }
    }

    return TRUE;
}

/* ================================================================================ */
// Function

int fnGetRayHashIndex(float fRes, float fAzimuth)
{
    return (int)(fAzimuth/fRes + fRes/2.0f);
}

STD_AZIMUTH_TBL* fnMakeRayHashTable(STD_SWEEP *pSweep)
{
    STD_RAY         *pRay       = NULL;     // VARIABLE
    STD_AZIMUTH_TBL *pTable     = NULL;
    int             iRayIdx     = 0;
    int             iHashIdx    = 0;
    float           fRes        = 0.0f;

    if(pSweep == NULL)
        return NULL;

    pTable = (STD_AZIMUTH_TBL *)calloc(pSweep->m_iMaxRay, sizeof(STD_AZIMUTH_TBL));
    if(pTable == NULL)
        return NULL;

    for(iRayIdx = 0; iRayIdx < pSweep->m_iMaxRay; iRayIdx++)
    {
        pTable[iRayIdx].m_fAzimuth  = -9999.f;
        pTable[iRayIdx].m_iCon      = -1;
        pTable[iRayIdx].m_iHigh     = -1;
        pTable[iRayIdx].m_iLow      = -1;
    }

    fRes = 360.0f/pSweep->m_iMaxRay;

    for(iRayIdx = 0; iRayIdx < pSweep->m_iMaxRay; iRayIdx++)
    {
        pRay = pSweep->m_ppRay[iRayIdx];
        if(pRay == NULL) 
            continue;

        iHashIdx = fnGetRayHashIndex(fRes, pRay->m_hdr.m_fAzimuth);
        if(iHashIdx >= pSweep->m_iMaxRay)
            iHashIdx = iHashIdx % pSweep->m_iMaxRay;

        pTable[iHashIdx].m_fAzimuth = pRay->m_hdr.m_fAzimuth;
        pTable[iHashIdx].m_iCon     = iRayIdx;
        pTable[iRayIdx].m_iHigh     = (iRayIdx + 1) % pSweep->m_iMaxRay;
        if(iRayIdx == 0)
            pTable[iRayIdx].m_iLow = pSweep->m_iMaxRay - 1;
        else
            pTable[iRayIdx].m_iLow = iRayIdx - 1;
    }

    return pTable;
}

STD_AZIMUTH_TBL** fnMakeAllHashTable(STD_RADAR *pStd)
{
    STD_AZIMUTH_TBL         **ppTable       = NULL;
    int                     iSweepIdx       = 0;

    if(pStd == NULL)
        return NULL;

    ppTable = (STD_AZIMUTH_TBL **)calloc(pStd->m_iMaxSweep, sizeof(STD_AZIMUTH_TBL *));
    if(ppTable == NULL)
        return NULL;

    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        if((ppTable[iSweepIdx] = fnMakeRayHashTable(pStd->m_ppSweep[iSweepIdx])) == NULL)
        {
            fnFreeMatrix2D((void **)ppTable, pStd->m_iMaxSweep);
            return NULL;
        }
    }

    return ppTable;
}

int fnTheClosestRay(STD_SWEEP *pSweep, STD_AZIMUTH_TBL *pTable, int iHashIdx, float fAzimuth)
{
    double      dCLow       = 0.0;
    double      dCHight     = 0.0;
    double      dCCLow      = 0.0;
    int         iLow        = 0;
    int         iHigh       = 0;
    int         iLoopCnt    = 0;

    if(pSweep == NULL || pTable == NULL || iHashIdx < 0 || iHashIdx >= pSweep->m_iMaxRay)
        return -1;

    iLow  = pTable[iHashIdx].m_iCon;
    iHigh = pTable[iLow].m_iHigh;

    dCLow   = fnCwiseAngleDiff(fAzimuth,  pSweep->m_ppRay[iLow]->m_hdr.m_fAzimuth);
    dCHight = fnCwiseAngleDiff(fAzimuth,  pSweep->m_ppRay[iHigh]->m_hdr.m_fAzimuth);
    dCCLow  = fnCCwiseAngleDiff(fAzimuth, pSweep->m_ppRay[iLow]->m_hdr.m_fAzimuth);

    while((dCHight > dCLow) && (dCLow != 0) && iLoopCnt < LOOP_CNT_MAX)
    {
        if(dCLow < dCCLow)
        {
            iLow  = pTable[iLow].m_iLow;
            iHigh = pTable[iLow].m_iHigh;
        }
        else
        {
            iLow  = pTable[iLow].m_iHigh;
            iHigh = pTable[iLow].m_iHigh;
        }

        dCLow   = fnCwiseAngleDiff(fAzimuth,  pSweep->m_ppRay[iLow]->m_hdr.m_fAzimuth);
        dCHight = fnCwiseAngleDiff(fAzimuth,  pSweep->m_ppRay[iHigh]->m_hdr.m_fAzimuth);
        dCCLow  = fnCCwiseAngleDiff(fAzimuth, pSweep->m_ppRay[iLow]->m_hdr.m_fAzimuth);

        iLoopCnt++;
    }

    if(iLoopCnt >= LOOP_CNT_MAX)
        return -1;

    if(dCHight <= dCCLow)
        return iHigh;
    else
        return iLow;
}

int fnGetFieldIdxRay(STD_RAY *pRay, char* szFieldName)
{
    STD_FIELD    *pField    = NULL;     // VARIBALE
    int         iFieldIdx   = 0;

    if(pRay == NULL || pRay->m_ppField == NULL || szFieldName == NULL)
        return -1;

    for(iFieldIdx = 0; iFieldIdx < pRay->m_iMaxField; iFieldIdx++)
    {
        pField = pRay->m_ppField[iFieldIdx];
        if(pField == NULL)
            continue;

        if(!strcmp(pField->m_hdr.m_szFieldName, szFieldName))
            break;
    }

    if(iFieldIdx >= pRay->m_iMaxField)
        return -1;
    else
        return iFieldIdx;
}

int fnValidStdRadar(STD_RADAR *pStd)
{
    STD_SWEEP       *pSweep     = NULL;         // VARIABLE
    STD_RAY         *pRay       = NULL;         // VARIABLE
    STD_FIELD       *pField     = NULL;         // VARIABLE
    int             iSweepIdx   = 0;
    int             iRayIdx     = 0;
    int             iFieldIdx   = 0;

    if(pStd == NULL || pStd->m_ppSweep == NULL)
    {
        return FALSE;
    }

    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        pSweep = pStd->m_ppSweep[iSweepIdx];
        if(pSweep == NULL) 
            return FALSE;

        if(pSweep->m_ppRay == NULL)
            return FALSE;

        for(iRayIdx = 0; iRayIdx < pSweep->m_iMaxRay; iRayIdx++)
        {
            pRay = pSweep->m_ppRay[iRayIdx];
            if(pRay == NULL)
                return FALSE;

            for(iFieldIdx = 0; iFieldIdx < pRay->m_iMaxField; iFieldIdx++)
            {
                pField = pRay->m_ppField[iFieldIdx];
                if(pField == NULL || pField->m_pData == NULL)
                    return FALSE;
            }
        }
    }

    return TRUE;
}

void fnFreeStdRadar(STD_RADAR *pStd)
{
    STD_SWEEP   *pSweep     = NULL;     // VARIABLE
    STD_RAY     *pRay       = NULL;     // VARIABLE
    STD_FIELD   *pField     = NULL;     // VARIABLE
    int         iSweepIdx   = 0;
    int         iRayIdx     = 0;
    int         iFieldIdx   = 0;

    if(pStd != NULL)
    {
        if(pStd->m_ppSweep != NULL)
        {
            for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
            {
                pSweep = pStd->m_ppSweep[iSweepIdx];
                if(pSweep != NULL)
                {
                    if(pSweep->m_ppRay != NULL)
                    {
                        for(iRayIdx = 0; iRayIdx < pSweep->m_iMaxRay; iRayIdx++)
                        {
                            pRay = pSweep->m_ppRay[iRayIdx];
                            if(pRay != NULL)
                            {
                                for(iFieldIdx = 0; iFieldIdx < pRay->m_iMaxField; iFieldIdx++)
                                {
                                    pField = pRay->m_ppField[iFieldIdx];
                                    if(pField != NULL)
                                    {
                                        free(pField->m_pData);
                                        free(pField);
                                    }
                                }
                                free(pRay->m_ppField);
                                free(pRay);
                            }
                        }
                        free(pSweep->m_ppRay);
                    }
                    free(pSweep);
                }
            }
            free(pStd->m_ppSweep);
        }
    free(pStd);
    }
}

int fnGetMaxCountStd(STD_RADAR *pStd, int *pTotalRay, int *pMaxSweep, int *pMaxRay, int *pMaxBin, int *pMaxField)
{
    STD_SWEEP   *pSweep     = NULL;     // VARIABLE
    STD_RAY     *pRay       = NULL;     // VARIABLE
    STD_FIELD   *pField     = NULL;     // VARIABLE
    int         iTotalRay   = 0; 
    int         iMaxSweep   = 0; 
    int         iMaxRay     = 0; 
    int         iMaxBin     = 0; 
    int         iMaxField   = 0;
    int         iSweepIdx   = 0;
    int         iRayIdx     = 0;
    int         iFieldIdx   = 0;

    if(pStd == NULL)
        return FALSE;

    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++, iMaxSweep++)
    {
        pSweep = pStd->m_ppSweep[iSweepIdx];
        if(pSweep != NULL)
        {
            iTotalRay += pSweep->m_iMaxRay;

            if(iMaxRay < pSweep->m_iMaxRay)
                iMaxRay = pSweep->m_iMaxRay;

            for(iRayIdx = 0; iRayIdx < pSweep->m_iMaxRay; iRayIdx++)
            {
                pRay = pSweep->m_ppRay[iRayIdx];
                if(pRay != NULL)
                {
                    if(iMaxField < pRay->m_iMaxField)
                        iMaxField = pRay->m_iMaxField;

                    for(iFieldIdx = 0; iFieldIdx < pRay->m_iMaxField; iFieldIdx++)
                    {
                        pField = pRay->m_ppField[iFieldIdx];
                        if(pField != NULL)
                        {
                            if(iMaxBin < pField->m_iMaxBin)
                                iMaxBin = pField->m_iMaxBin;
                        }
                    }
                }
            }
        }
    }

    if(pTotalRay != NULL) *pTotalRay = iTotalRay;
    if(pMaxSweep != NULL) *pMaxSweep = iMaxSweep;
    if(pMaxRay   != NULL) *pMaxRay   = iMaxRay;
    if(pMaxBin   != NULL) *pMaxBin   = iMaxBin;
    if(pMaxField != NULL) *pMaxField = iMaxField;

    return TRUE;
}

void fnGetSweepMaxCountStd(STD_SWEEP *pSweep, int *pMaxRay, int *pMaxField, int *pMaxBin)
{
    STD_RAY     *pRay       = NULL;     // VARIABLE
    STD_FIELD   *pField     = NULL;     // VARIABLE
    int         iMaxRay     = 0; 
    int         iMaxBin     = 0; 
    int         iMaxField   = 0;
    int         iRayIdx     = 0;
    int         iFieldIdx   = 0;

    if(pSweep == NULL || pSweep->m_ppRay == NULL)
        return;

    for(iRayIdx = 0; iRayIdx < pSweep->m_iMaxRay; iRayIdx++, iMaxRay++)
    {
        pRay = pSweep->m_ppRay[iRayIdx];
        if(pRay != NULL)
        {
            if(iMaxField < pRay->m_iMaxField)
                iMaxField = pRay->m_iMaxField;

            for(iFieldIdx = 0; iFieldIdx < pRay->m_iMaxField; iFieldIdx++)
            {
                pField = pRay->m_ppField[iFieldIdx];
                if(pField != NULL)
                {
                    if(iMaxBin < pField->m_iMaxBin)
                        iMaxBin = pField->m_iMaxBin;
                }
            }
        }
    }

    if(pMaxRay   != NULL) *pMaxRay   = iMaxRay;
    if(pMaxField != NULL) *pMaxField = iMaxField;
    if(pMaxBin   != NULL) *pMaxBin   = iMaxBin;

}

float fnGetMaxRangeStd(STD_RADAR *pStd)
{
    STD_SWEEP   *pSweep     = NULL;     // VARIABLE
    STD_RAY     *pRay       = NULL;     // VARIABLE
    int         iSweepIdx   = 0;
    int         iRayIdx     = 0;
    float       fBin1Range  = 0.0;
    float       fRayRange   = 0.0;
    float       fMaxRange   = 0.0;

    if(pStd == NULL)
        return 0.0;

    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        pSweep = pStd->m_ppSweep[iSweepIdx];
        if(pSweep != NULL)
        {
            for(iRayIdx = 0; iRayIdx < pSweep->m_iMaxRay; iRayIdx++)
            {
                pRay = pSweep->m_ppRay[iRayIdx];
                if(pRay != NULL)
                {
                    if(pRay->m_ppField != NULL && pRay->m_ppField[0] != NULL)
                    {
                        fBin1Range 
                        = pRay->m_hdr.m_iStartRangeKm + pRay->m_hdr.m_iStartRangeMeter/1000.;
                        fRayRange  
                        = (pRay->m_hdr.m_iBinSpacing * pRay->m_ppField[0]->m_iMaxBin)/1000. 
                          + fBin1Range;

                        if(fMaxRange < fRayRange)
                            fMaxRange = fRayRange;
                    }
                }
            }
        }
    }

    if(pStd == NULL)
        return 0.0;

    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        
        for(iRayIdx = 0; iRayIdx < pSweep->m_iMaxRay; iRayIdx++)
        {
        }
    }

    return fMaxRange;
}

STD_RADAR* fnUfSyncUpStd(UF_RADAR *pUf)
{
#define FN_UF_SYNC_UP_STD_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pStd != NULL) { fnFreeStdRadar(pStd);}

    STD_RADAR   *pStd           = NULL;     // VARIABLE
    STD_SWEEP   *pStdSweep      = NULL;     // VARIABLE;
    STD_RAY     *pStdRay        = NULL;     // VARIABLE;
    STD_FIELD   *pStdField      = NULL;     // VARIABLE;
    UF_SWEEP    *pSweep         = NULL;     // VARIABLE;
    UF_RAY      *pRay           = NULL;     // VARIABLE;
    UF_FIELD    *pField         = NULL;     // VARIABLE;
    int         iSweepIdx       = 0;
    int         iRayIdx         = 0;
    int         iFieldIdx       = 0;
    int         bOnceField      = TRUE;
    int         bOnceRayField   = TRUE;

    if(fnValidUf(pUf) == FALSE)
    {   FN_UF_SYNC_UP_STD_ERROR("InValid UF") return NULL; }

    if((pStd = (STD_RADAR *)fnInitStdToUf(pUf)) == NULL)
    {   FN_UF_SYNC_UP_STD_ERROR("fnInitStdToUf fail") return NULL; }

    for(iSweepIdx = 0; iSweepIdx < pUf->m_iCurSweep; iSweepIdx++)
    {
        pSweep   = pUf->m_ppSweep[iSweepIdx];
        pStdSweep = pStd->m_ppSweep[iSweepIdx];

        for(iRayIdx = 0; iRayIdx < pSweep->m_iCurRay; iRayIdx++)
        {
            pRay   = pSweep->m_ppRay[iRayIdx];
            pStdRay = pStdSweep->m_ppRay[iRayIdx];

            // setup ray header..
            fnUfRayToStdRay(pRay, pStdRay);

            bOnceRayField = TRUE;

            for(iFieldIdx = 0; iFieldIdx < pRay->m_iCurField;  iFieldIdx++)
            {
                pField   = pRay->m_ppField[iFieldIdx];
                pStdField = pStdRay->m_ppField[iFieldIdx];
             
                // setup ray header to fileld
                if(bOnceRayField == TRUE)
                {
                    fnUfFieldToStdRay(pField, pStdRay);
                    bOnceRayField = FALSE;
                }

                // setup field header & data
                fnUfFieldToStdField(pField, pRay->dh.m_pfi[iFieldIdx].m_szFieldName, pStdField);

                // setup global header...
                if(bOnceField == TRUE)
                {
                    bOnceField = FALSE;
                    fnUfToStdGlobal(pRay, pField, pStd);
                }

               // for VF, VE, VR, VT, VP 
                if( strncmp(pRay->dh.m_pfi[iFieldIdx].m_szFieldName, "VF", 2) == 0 ||
                    strncmp(pRay->dh.m_pfi[iFieldIdx].m_szFieldName, "VE", 2) == 0 ||
                    strncmp(pRay->dh.m_pfi[iFieldIdx].m_szFieldName, "VR", 2) == 0 ||
                    strncmp(pRay->dh.m_pfi[iFieldIdx].m_szFieldName, "VT", 2) == 0 ||
                    strncmp(pRay->dh.m_pfi[iFieldIdx].m_szFieldName, "VP", 2) == 0 )
                {
                    if(pField->fh.m_fNyquistVelocity != 0.0)
                    {
                        pStdSweep->m_hdr.m_fNyquistVelocity  = pField->fh.m_fNyquistVelocity;
                        snprintf(pStdSweep->m_hdr.m_szVelocityFlag, 
                                 sizeof(pStdSweep->m_hdr.m_szVelocityFlag), 
                                 "%s", pField->fh.m_szVelocityFlag);
                    }
                }
                else if(strncmp(pRay->dh.m_pfi[iFieldIdx].m_szFieldName, "DM", 2) == 0)
                {
                    pStdSweep->m_hdr.m_fRadarConstant = pField->fh.m_fRadarConstant;
                    pStdSweep->m_hdr.m_fNoisePower    = pField->fh.m_fNoisePower;
                    pStdSweep->m_hdr.m_fReceiverGain  = pField->fh.m_fReceiverGain;
                    pStdSweep->m_hdr.m_fPeakPower     = pField->fh.m_fPeakPower;
                    pStdSweep->m_hdr.m_fAntennaGain   = pField->fh.m_fAntennaGain;
                    pStdSweep->m_hdr.m_fPulseDuration = pField->fh.m_fPulseDuration;
                }
            }
        }
    }

    return pStd;
}

STD_PRODUCT* fnHdfProductSyncUpStd(HDF_PRODUCT *pHdfProduct)
{
#define FN_HDF_PRODUCT_SYNC_UP_STD_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pStdProduct != NULL) { fnFreeStdProduct(pStdProduct); }

    STD_PRODUCT *pStdProduct    = NULL;
    int         iMaxPpi         = 0;
    int         iMaxCappi       = 0;
    int         iMaxBase        = 0;
    int         iMaxCmax        = 0;
    int         iMaxVil         = 0;
    int         iMaxEtop        = 0;
    int         iMaxField       = 0;

    if(pHdfProduct == NULL)
        return NULL;

    if(fnGetMaxCountHdfProduct(pHdfProduct, &iMaxField, &iMaxPpi,  &iMaxCappi, 
                                                        &iMaxBase, &iMaxCmax, 
                                                        &iMaxVil,  &iMaxEtop) == FALSE)
    {   FN_HDF_PRODUCT_SYNC_UP_STD_ERROR("fnGetMaxCountHdfProduct fail"); return NULL; }

    if((pStdProduct = fnInitStdProduct(iMaxField, iMaxPpi,  iMaxCappi, iMaxBase, 
                                                  iMaxCmax, iMaxVil,   iMaxEtop)) == NULL)
    {   FN_HDF_PRODUCT_SYNC_UP_STD_ERROR("fnInitStdProduct fail"); return NULL; }

    if(pHdfProduct->m_iHdfProductType == HDF_EN_PRODUCT_SITE)
        pStdProduct->m_iStdProductType = STD_EN_PRODUCT_SITE;
    else if(pHdfProduct->m_iHdfProductType == HDF_EN_PRODUCT_SITE)
        pStdProduct->m_iStdProductType = STD_EN_PRODUCT_COMP;

    fnConvertStdProductHdrToHdf(pStdProduct, pHdfProduct);

    if(pHdfProduct->m_totalProduct.m_iMaxPpi > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxPpi = pHdfProduct->m_totalProduct.m_iMaxPpi;
        if(fnConvertStdDatasetToHdf(pStdProduct->m_totalProduct.m_ppPpi, 
                                     pHdfProduct->m_totalProduct.m_ppPpi,
                                     pHdfProduct->m_totalProduct.m_iMaxPpi, 
                                     (int)pHdfProduct->m_where.m_image_where.m_lYsize,
                                     (int)pHdfProduct->m_where.m_image_where.m_lXsize) == FALSE)
        {   FN_HDF_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToHdf PPI fail"); return NULL; }
    }

    if(pHdfProduct->m_totalProduct.m_iMaxCappi > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxCappi = pHdfProduct->m_totalProduct.m_iMaxCappi;
        if(fnConvertStdDatasetToHdf(pStdProduct->m_totalProduct.m_ppCappi, 
                                     pHdfProduct->m_totalProduct.m_ppCappi,
                                     pHdfProduct->m_totalProduct.m_iMaxCappi, 
                                     (int)pHdfProduct->m_where.m_image_where.m_lYsize,
                                     (int)pHdfProduct->m_where.m_image_where.m_lXsize) == FALSE)
        {   FN_HDF_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToHdf CAPPI fail"); return NULL; }
    }

    if(pHdfProduct->m_totalProduct.m_iMaxBase > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxBase = pHdfProduct->m_totalProduct.m_iMaxBase;
        if(fnConvertStdDatasetToHdf(pStdProduct->m_totalProduct.m_ppBase, 
                                     pHdfProduct->m_totalProduct.m_ppBase,
                                     pHdfProduct->m_totalProduct.m_iMaxBase, 
                                     (int)pHdfProduct->m_where.m_image_where.m_lYsize,
                                     (int)pHdfProduct->m_where.m_image_where.m_lXsize) == FALSE)
        {   FN_HDF_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToHdf BASE fail"); return NULL; }
    }

    if(pHdfProduct->m_totalProduct.m_iMaxCmax > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxCmax = pHdfProduct->m_totalProduct.m_iMaxCmax;
        if(fnConvertStdDatasetToHdf(pStdProduct->m_totalProduct.m_ppCmax, 
                                     pHdfProduct->m_totalProduct.m_ppCmax,
                                     pHdfProduct->m_totalProduct.m_iMaxCmax, 
                                     (int)pHdfProduct->m_where.m_image_where.m_lYsize,
                                     (int)pHdfProduct->m_where.m_image_where.m_lXsize) == FALSE)
        {   FN_HDF_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToHdf CMAX fail"); return NULL; }
    }

    if(pHdfProduct->m_totalProduct.m_iMaxVil > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxVil = pHdfProduct->m_totalProduct.m_iMaxVil;
        if(fnConvertStdDatasetToHdf(pStdProduct->m_totalProduct.m_ppVil, 
                                     pHdfProduct->m_totalProduct.m_ppVil,
                                     pHdfProduct->m_totalProduct.m_iMaxVil, 
                                     (int)pHdfProduct->m_where.m_image_where.m_lYsize,
                                     (int)pHdfProduct->m_where.m_image_where.m_lXsize) == FALSE)
        {   FN_HDF_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToHdf VIL fail"); return NULL; }
    }

    if(pHdfProduct->m_totalProduct.m_iMaxEtop > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxEtop = pHdfProduct->m_totalProduct.m_iMaxEtop;
        if(fnConvertStdDatasetToHdf(pStdProduct->m_totalProduct.m_ppEtop, 
                                     pHdfProduct->m_totalProduct.m_ppEtop,
                                     pHdfProduct->m_totalProduct.m_iMaxEtop, 
                                     (int)pHdfProduct->m_where.m_image_where.m_lYsize,
                                     (int)pHdfProduct->m_where.m_image_where.m_lXsize) == FALSE)
        {   FN_HDF_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToHdf ETOP fail"); return NULL; }
    }

    return pStdProduct;
}

STD_RADAR* fnHdfSyncUpStd(HDF_RADAR *pHdf)
{
#define FN_HDF_SYNC_UP_STD_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pStd != NULL) { fnFreeStdRadar(pStd);} 
    
    STD_RADAR       *pStd       = NULL;
    STD_SWEEP       *pStdSweep  = NULL;
    STD_RAY         *pStdRay    = NULL;
    STD_FIELD       *pStdField  = NULL;
    HDF_DATASET     *pHdfDset   = NULL;
    HDF_DATA        *pHdfData   = NULL;
    int             iMaxDset    = 0;
    int             iMaxData    = 0;
    int             iMaxRay     = 0;
    int             iMaxBin     = 0;
    int             iDsetIdx    = 0;
    int             iDataIdx    = 0;
    int             iRayIdx     = 0;

    if(pHdf == NULL)
        return NULL;

    if(fnGetMaxCountHdfRadar(pHdf, &iMaxDset, &iMaxData, &iMaxRay, &iMaxBin) == FALSE)
        return NULL;

    if(iMaxDset <= 0 || iMaxData <= 0 || iMaxRay <= 0 || iMaxBin <= 0)
    {   FN_HDF_SYNC_UP_STD_ERROR("fnGetMaxCountHdfRadar error") return NULL; }

    if((pStd = fnInitStd(iMaxDset, iMaxRay, iMaxBin, iMaxData)) == NULL)
    {   FN_HDF_SYNC_UP_STD_ERROR("fnInitStd fail") return NULL; }

    // Global Header
    fnHdfToStdGlobal(pHdf, pStd);

    for(iDsetIdx = 0; iDsetIdx < pHdf->m_iMaxDataset; iDsetIdx++)
    {
        pStdSweep = pStd->m_ppSweep[iDsetIdx];
        pHdfDset  = pHdf->m_ppDataset[iDsetIdx];
        
        if(pHdfDset == NULL)
            continue;

        // Sweep Header
        fnHdfToStdSweep(pHdfDset, pStdSweep);
        for(iDataIdx = 0; iDataIdx < pHdfDset->m_iMaxData; iDataIdx++)
        {
            pHdfData = pHdfDset->m_ppData[iDataIdx];
            if(pHdfData == NULL)
                continue;

            for(iRayIdx = 0; iRayIdx < pHdfData->m_where.m_polar_where.m_nRays; iRayIdx++)
            {
                pStdRay = pStdSweep->m_ppRay[iRayIdx];

                // Ray Header
                fnHdfToStdRay(pHdfDset, pStdRay, iRayIdx);

                pStdField = pStdRay->m_ppField[iDataIdx];

                // Field Header & Data
                fnHdfToStdField(pHdfData, pStdField, iRayIdx, 
                                pHdfDset->m_where.m_polar_where.m_nBins);
            }
        }
    }

    return pStd;
}

STD_RADAR* fnNcSyncUpStd(NC_RADAR *pNc)
{
#define FN_NC_SYNC_UP_STD_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pStd != NULL) { fnFreeStdRadar(pStd);}

    STD_RADAR   *pStd           = NULL;     // VARIABLE
    STD_SWEEP   *pStdSweep      = NULL;     // VARIABLE;
    STD_RAY     *pStdRay        = NULL;     // VARIABLE;
    STD_FIELD   *pStdField      = NULL;     // VARIABLE;
    int         iSweepIdx       = 0;
    int         iRayIdx         = 0;
    int         iFieldIdx       = 0;
    int         iRayStart       = 0;
    int         iRayEnd         = 0;

    if(pNc == NULL)
        return NULL;

    if(pNc->m_sweep_var.m_pSweep_start_ray_index == NULL ||
       pNc->m_sweep_var.m_pSweep_end_ray_index   == NULL)
    {   FN_NC_SYNC_UP_STD_ERROR("invalid nc") return NULL; }

    if((pStd = fnInitStdToNc(pNc)) == NULL)
    {   FN_NC_SYNC_UP_STD_ERROR("fnInitStdtoNc fail") return NULL; }

    // Global Header
    fnNcToStdGlobal(pNc, pStd);

    for(iSweepIdx = 0; iSweepIdx < pNc->m_dim.m_nSweep; iSweepIdx++)
    {
        pStdSweep = pStd->m_ppSweep[iSweepIdx];

        fnNcToStdSweep(pNc, pStdSweep);

        iRayStart = pNc->m_sweep_var.m_pSweep_start_ray_index[iSweepIdx];
        iRayEnd   = pNc->m_sweep_var.m_pSweep_end_ray_index[iSweepIdx];

        for(iRayIdx = iRayStart; iRayIdx <= iRayEnd; iRayIdx++)
        {
            pStdRay = pStdSweep->m_ppRay[iRayIdx - iRayStart];

            fnNcToStdRay(pNc, iSweepIdx, iRayIdx, pStdRay);

            for(iFieldIdx = 0; iFieldIdx < pNc->m_iMaxMoment; iFieldIdx++)
            {
                pStdField = pStdRay->m_ppField[iFieldIdx];

                fnNcToStdField(pNc, iRayIdx, iFieldIdx, pStdField);
            }
        }
    }

    return pStd;
}

STD_RADAR* fnBufrSyncUpStd(BUFR_RADAR *pBufr)
{
#define FN_BUFR_SYNC_UP_STD_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pStd != NULL) { fnFreeStdRadar(pStd);} 
    
    STD_RADAR       *pStd       = NULL;
    STD_SWEEP       *pStdSweep  = NULL;
    STD_RAY         *pStdRay    = NULL;
    STD_FIELD       *pStdField  = NULL;
    BUFR_DATASET    *pBufrDset   = NULL;
    BUFR_DATA       *pBufrData   = NULL;
    int             iMaxDset    = 0;
    int             iMaxData    = 0;
    int             iMaxRay     = 0;
    int             iMaxBin     = 0;
    int             iDsetIdx    = 0;
    int             iDataIdx    = 0;
    int             iRayIdx     = 0;

    if(pBufr == NULL)
        return NULL;

    if(fnGetMaxCountBufrRadar(pBufr, &iMaxDset, &iMaxData, &iMaxRay, &iMaxBin) == FALSE)
        return NULL;

    if(iMaxDset <= 0 || iMaxData <= 0 || iMaxRay <= 0 || iMaxBin <= 0)
    {   FN_BUFR_SYNC_UP_STD_ERROR("fnGetMaxCountBufrRadar error") return NULL; }

    if((pStd = fnInitStd(iMaxDset, iMaxRay, iMaxBin, iMaxData)) == NULL)
        return NULL;

    // Global Header
    fnBufrToStdGlobal(pBufr, pStd);

    for(iDsetIdx = 0; iDsetIdx < pBufr->m_iMaxDataset; iDsetIdx++)
    {
        pStdSweep = pStd->m_ppSweep[iDsetIdx];
        pBufrDset  = pBufr->m_ppDataset[iDsetIdx];
        
        if(pBufrDset == NULL)
            continue;

        // Sweep Header
        fnBufrToStdSweep(pBufrDset, pStdSweep);
        for(iDataIdx = 0; iDataIdx < pBufrDset->m_iMaxData; iDataIdx++)
        {
            pBufrData = pBufrDset->m_ppData[iDataIdx];
            if(pBufrData == NULL)
                continue;

            for(iRayIdx = 0; iRayIdx < pBufrData->m_where.m_polar_where.m_nRays; iRayIdx++)
            {
                pStdRay = pStdSweep->m_ppRay[iRayIdx];

                // Ray Header
                fnBufrToStdRay(pBufrDset, pStdRay, iRayIdx);

                pStdField = pStdRay->m_ppField[iDataIdx];

                // Field Header & Data
                fnBufrToStdField(pBufrData, pStdField, iRayIdx, 
                                 pBufrDset->m_where.m_polar_where.m_nBins);
            }
        }
    }

    return pStd;
}

STD_PRODUCT* fnBufrProductSyncUpStd(BUFR_PRODUCT *pBufrProduct)
{
#define FN_BUFR_PRODUCT_SYNC_UP_STD_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pStdProduct != NULL) { fnFreeStdProduct(pStdProduct); }

    STD_PRODUCT *pStdProduct    = NULL;
    int         iMaxPpi         = 0;
    int         iMaxCappi       = 0;
    int         iMaxBase        = 0;
    int         iMaxCmax        = 0;
    int         iMaxVil         = 0;
    int         iMaxEtop        = 0;
    int         iMaxField       = 0;

    if(pBufrProduct == NULL)
        return NULL;

    if(fnGetMaxCountBufrProduct(pBufrProduct, &iMaxField, &iMaxPpi,  &iMaxCappi, &iMaxBase, 
                                              &iMaxCmax, &iMaxVil,   &iMaxEtop) == FALSE)
    {   FN_BUFR_PRODUCT_SYNC_UP_STD_ERROR("fnGetMaxCountBufrProduct fail"); return NULL; }

    if((pStdProduct = fnInitStdProduct(iMaxField, iMaxPpi,  iMaxCappi, iMaxBase, 
                                                  iMaxCmax, iMaxVil,   iMaxEtop)) == NULL)
    {   FN_BUFR_PRODUCT_SYNC_UP_STD_ERROR("fnInitStdProduct fail"); return NULL; }

    if(pBufrProduct->m_iBufrProductType == BUFR_EN_PRODUCT_SITE)
        pStdProduct->m_iStdProductType = STD_EN_PRODUCT_SITE;
    else if(pBufrProduct->m_iBufrProductType == BUFR_EN_PRODUCT_SITE)
        pStdProduct->m_iStdProductType = STD_EN_PRODUCT_COMP;

    fnConvertStdProductHdrToBufr(pStdProduct, pBufrProduct);

    if(pBufrProduct->m_totalProduct.m_iMaxPpi > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxPpi = pBufrProduct->m_totalProduct.m_iMaxPpi;
        if(fnConvertStdDatasetToBufr(pStdProduct->m_totalProduct.m_ppPpi, 
                                     pBufrProduct->m_totalProduct.m_ppPpi,
                                     pBufrProduct->m_totalProduct.m_iMaxPpi, 
                                     (int)pBufrProduct->m_where.m_image_where.m_lYsize,
                                     (int)pBufrProduct->m_where.m_image_where.m_lXsize) == FALSE)
        {   FN_BUFR_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToBufr PPI fail"); return NULL; }
    }

    if(pBufrProduct->m_totalProduct.m_iMaxCappi > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxCappi = pBufrProduct->m_totalProduct.m_iMaxCappi;
        if(fnConvertStdDatasetToBufr(pStdProduct->m_totalProduct.m_ppCappi, 
                                     pBufrProduct->m_totalProduct.m_ppCappi,
                                     pBufrProduct->m_totalProduct.m_iMaxCappi, 
                                     (int)pBufrProduct->m_where.m_image_where.m_lYsize,
                                     (int)pBufrProduct->m_where.m_image_where.m_lXsize) == FALSE)
        {   FN_BUFR_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToBufr CAPPI fail"); return NULL; }
    }

    if(pBufrProduct->m_totalProduct.m_iMaxBase > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxBase = pBufrProduct->m_totalProduct.m_iMaxBase;
        if(fnConvertStdDatasetToBufr(pStdProduct->m_totalProduct.m_ppBase, 
                                     pBufrProduct->m_totalProduct.m_ppBase,
                                     pBufrProduct->m_totalProduct.m_iMaxBase, 
                                     (int)pBufrProduct->m_where.m_image_where.m_lYsize,
                                     (int)pBufrProduct->m_where.m_image_where.m_lXsize) == FALSE)
        {   FN_BUFR_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToBufr BASE fail"); return NULL; }
    }

    if(pBufrProduct->m_totalProduct.m_iMaxCmax > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxCmax = pBufrProduct->m_totalProduct.m_iMaxCmax;
        if(fnConvertStdDatasetToBufr(pStdProduct->m_totalProduct.m_ppCmax, 
                                     pBufrProduct->m_totalProduct.m_ppCmax,
                                     pBufrProduct->m_totalProduct.m_iMaxCmax, 
                                     (int)pBufrProduct->m_where.m_image_where.m_lYsize,
                                     (int)pBufrProduct->m_where.m_image_where.m_lXsize) == FALSE)
        {   FN_BUFR_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToBufr CMAX fail"); return NULL; }
    }

    if(pBufrProduct->m_totalProduct.m_iMaxVil > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxVil = pBufrProduct->m_totalProduct.m_iMaxVil;
        if(fnConvertStdDatasetToBufr(pStdProduct->m_totalProduct.m_ppVil, 
                                     pBufrProduct->m_totalProduct.m_ppVil,
                                     pBufrProduct->m_totalProduct.m_iMaxVil, 
                                     (int)pBufrProduct->m_where.m_image_where.m_lYsize,
                                     (int)pBufrProduct->m_where.m_image_where.m_lXsize) == FALSE)
        {   FN_BUFR_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToBufr VIL fail"); return NULL; }
    }

    if(pBufrProduct->m_totalProduct.m_iMaxEtop > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxEtop = pBufrProduct->m_totalProduct.m_iMaxEtop;
        if(fnConvertStdDatasetToBufr(pStdProduct->m_totalProduct.m_ppEtop, 
                                     pBufrProduct->m_totalProduct.m_ppEtop,
                                     pBufrProduct->m_totalProduct.m_iMaxEtop, 
                                     (int)pBufrProduct->m_where.m_image_where.m_lYsize,
                                     (int)pBufrProduct->m_where.m_image_where.m_lXsize) == FALSE)
        {   FN_BUFR_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToBufr ETOP fail"); return NULL; }
    }

    return pStdProduct;
}

STD_PRODUCT* fnGribProductSyncUpStd(GRIB_PRODUCT *pGribProduct)
{
#define FN_GRIB_PRODUCT_SYNC_UP_STD_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pStdProduct != NULL) { fnFreeStdProduct(pStdProduct); }

    STD_PRODUCT *pStdProduct    = NULL;
    int         iMaxPpi         = 0;
    int         iMaxCappi       = 0;
    int         iMaxBase        = 0;
    int         iMaxCmax        = 0;
    int         iMaxVil         = 0;
    int         iMaxEtop        = 0;
    int         iMaxField       = 0;

    if(pGribProduct == NULL)
        return NULL;

    if(fnGetMaxCountGribProduct(pGribProduct, &iMaxField, &iMaxPpi,  &iMaxCappi, &iMaxBase, 
                                              &iMaxCmax, &iMaxVil,   &iMaxEtop) == FALSE)
    {   FN_GRIB_PRODUCT_SYNC_UP_STD_ERROR("fnGetMaxCountGribProduct fail"); return NULL; }

    if((pStdProduct = fnInitStdProduct(iMaxField, iMaxPpi,  iMaxCappi, iMaxBase, 
                                                  iMaxCmax, iMaxVil,   iMaxEtop)) == NULL)
    {   FN_GRIB_PRODUCT_SYNC_UP_STD_ERROR("fnInitStdProduct fail"); return NULL; }

    if(pGribProduct->m_iGribProductType == GRIB_EN_PRODUCT_SITE)
        pStdProduct->m_iStdProductType = STD_EN_PRODUCT_SITE;
    else if(pGribProduct->m_iGribProductType == GRIB_EN_PRODUCT_SITE)
        pStdProduct->m_iStdProductType = STD_EN_PRODUCT_COMP;

    fnConvertStdProductHdrToGrib(pStdProduct, pGribProduct);

    if(pGribProduct->m_totalProduct.m_iMaxPpi > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxPpi = pGribProduct->m_totalProduct.m_iMaxPpi;
        if(fnConvertStdDatasetToGrib(pStdProduct->m_totalProduct.m_ppPpi, 
                                     pGribProduct->m_totalProduct.m_ppPpi,
                                     pGribProduct->m_totalProduct.m_iMaxPpi, 
                                     (int)pGribProduct->m_where.m_lYsize,
                                     (int)pGribProduct->m_where.m_lXsize) == FALSE)
        {   FN_GRIB_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToGrib PPI fail"); return NULL; }
    }

    if(pGribProduct->m_totalProduct.m_iMaxCappi > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxCappi = pGribProduct->m_totalProduct.m_iMaxCappi;
        if(fnConvertStdDatasetToGrib(pStdProduct->m_totalProduct.m_ppCappi, 
                                     pGribProduct->m_totalProduct.m_ppCappi,
                                     pGribProduct->m_totalProduct.m_iMaxCappi, 
                                     (int)pGribProduct->m_where.m_lYsize,
                                     (int)pGribProduct->m_where.m_lXsize) == FALSE)
        {   FN_GRIB_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToGrib CAPPI fail"); return NULL; }
    }

    if(pGribProduct->m_totalProduct.m_iMaxBase > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxBase = pGribProduct->m_totalProduct.m_iMaxBase;
        if(fnConvertStdDatasetToGrib(pStdProduct->m_totalProduct.m_ppBase, 
                                     pGribProduct->m_totalProduct.m_ppBase,
                                     pGribProduct->m_totalProduct.m_iMaxBase, 
                                     (int)pGribProduct->m_where.m_lYsize,
                                     (int)pGribProduct->m_where.m_lXsize) == FALSE)
        {   FN_GRIB_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToGrib BASE fail"); return NULL; }
    }

    if(pGribProduct->m_totalProduct.m_iMaxCmax > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxCmax = pGribProduct->m_totalProduct.m_iMaxCmax;
        if(fnConvertStdDatasetToGrib(pStdProduct->m_totalProduct.m_ppCmax, 
                                     pGribProduct->m_totalProduct.m_ppCmax,
                                     pGribProduct->m_totalProduct.m_iMaxCmax, 
                                     (int)pGribProduct->m_where.m_lYsize,
                                     (int)pGribProduct->m_where.m_lXsize) == FALSE)
        {   FN_GRIB_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToGrib CMAX fail"); return NULL; }
    }

    if(pGribProduct->m_totalProduct.m_iMaxVil > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxVil = pGribProduct->m_totalProduct.m_iMaxVil;
        if(fnConvertStdDatasetToGrib(pStdProduct->m_totalProduct.m_ppVil, 
                                     pGribProduct->m_totalProduct.m_ppVil,
                                     pGribProduct->m_totalProduct.m_iMaxVil, 
                                     (int)pGribProduct->m_where.m_lYsize,
                                     (int)pGribProduct->m_where.m_lXsize) == FALSE)
        {   FN_GRIB_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToGrib VIL fail"); return NULL; }
    }

    if(pGribProduct->m_totalProduct.m_iMaxEtop > 0)
    {
        pStdProduct->m_totalProduct.m_iMaxEtop = pGribProduct->m_totalProduct.m_iMaxEtop;
        if(fnConvertStdDatasetToGrib(pStdProduct->m_totalProduct.m_ppEtop, 
                                     pGribProduct->m_totalProduct.m_ppEtop,
                                     pGribProduct->m_totalProduct.m_iMaxEtop, 
                                     (int)pGribProduct->m_where.m_lYsize,
                                     (int)pGribProduct->m_where.m_lXsize) == FALSE)
        {   FN_GRIB_PRODUCT_SYNC_UP_STD_ERROR("fnConvertStdDatasetToGrib ETOP fail"); return NULL; }
    }

    return pStdProduct;
}

STD_RADAR* fnGribSyncUpStd(GRIB_RADAR *pGrib)
{
#define FN_GRIB_SYNC_UP_STD_ERROR(MSG) \
    fprintf(stderr, "%s : %s\n", __func__, MSG); \
    if(pStd != NULL) { fnFreeStdRadar(pStd);}

    STD_RADAR       *pStd       = NULL;
    STD_SWEEP       *pStdSweep  = NULL;
    STD_RAY         *pStdRay    = NULL;
    STD_FIELD       *pStdField  = NULL;
    int             iSweepIdx   = 0;
    int             iCurRay     = 0;
    int             iRayIdx     = 0;
    int             iFieldIdx   = 0;
    short           *pData      = NULL;
    int             iDataIdx    = 0;
 
    if((pStd = fnInitStdToGrib(pGrib)) == NULL)
    {   FN_GRIB_SYNC_UP_STD_ERROR("fnInitStdToGrib fail") return NULL; }

    fnGribToStdGlobal(pGrib, pStd);

    for(iSweepIdx = 0, iCurRay = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        pStdSweep = pStd->m_ppSweep[iSweepIdx];
        if(pStdSweep == NULL)
        {   FN_GRIB_SYNC_UP_STD_ERROR("pStdSweep is NULL") return NULL; }

        for(iRayIdx = 0; iRayIdx < pStdSweep->m_iMaxRay; iRayIdx++, iCurRay++)
        {
            pStdRay = pStdSweep->m_ppRay[iRayIdx];
            if(pStdRay == NULL)
            {   FN_GRIB_SYNC_UP_STD_ERROR("pStdRay is NULL") return NULL; }

            fnGribToStdRay(pGrib, iCurRay, pStdRay, pStd->m_hdr.m_tConvertTime);

            for(iFieldIdx = 0; iFieldIdx < pStdRay->m_iMaxField; iFieldIdx++)
            {
                pStdField = pStdRay->m_ppField[iFieldIdx];
                if(pStdField == NULL)
                {   FN_GRIB_SYNC_UP_STD_ERROR("pStdField is NULL") return NULL; }

                pData = pGrib->m_ppVolume[iFieldIdx]->m_pData;
                iDataIdx = pGrib->m_hdr.m_iMaxBin * iCurRay;

                snprintf(pStdField->m_hdr.m_szFieldName, sizeof(pStdField->m_hdr.m_szFieldName), 
                         "%s", pGrib->m_ppVolume[iFieldIdx]->m_szName);

                pStdField->m_hdr.m_iScaleFactor = pGrib->m_hdr.m_iScaleFactor;

                if(pStdField->m_pData != NULL && pData != NULL)
                {
                    memcpy(pStdField->m_pData, &pData[iDataIdx], 
                           pStdField->m_iMaxBin*sizeof(short));
                }
            }
        }
    }

    return pStd;
}

int fnStdRadarAzimuthCorrection(STD_RADAR *pStd, float fAzimCor)
{
    STD_SWEEP       *pStdSweep  = NULL;
    STD_RAY         *pStdRay    = NULL;
    int             iSweepIdx   = 0;
    int             iRayIdx     = 0;

    if(pStd == NULL)
        return FALSE;

    if(pStd->m_ppSweep == NULL)
        return FALSE;

    for(iSweepIdx = 0; iSweepIdx < pStd->m_iMaxSweep; iSweepIdx++)
    {
        pStdSweep = pStd->m_ppSweep[iSweepIdx];

        if(pStdSweep == NULL)
            continue;

        if(pStdSweep->m_ppRay == NULL)
            continue;

        for(iRayIdx = 0; iRayIdx < pStdSweep->m_iMaxRay; iRayIdx++)
        {
            pStdRay = pStdSweep->m_ppRay[iRayIdx];

            if(pStdRay == NULL)
                continue;

            pStdRay->m_hdr.m_fAzimuth += fAzimCor;
            if(pStdRay->m_hdr.m_fAzimuth < 0)
                pStdRay->m_hdr.m_fAzimuth = 360. + pStdRay->m_hdr.m_fAzimuth;
            else if(pStdRay->m_hdr.m_fAzimuth >= 360.)
                pStdRay->m_hdr.m_fAzimuth = 360. - pStdRay->m_hdr.m_fAzimuth;
        }
    }

    return TRUE;
}

/* ================================================================================ */








