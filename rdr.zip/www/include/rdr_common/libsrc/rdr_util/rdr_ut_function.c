/* ================================================================================ */
//
// Radar Utility Function
//
// 2016.08.07 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function



/* ================================================================================ */
// Function

int fnIsLittleEndian(void)
{
    union {
        char byte[4];
        int  val;
    } dword;

    dword.val     = 0;      // windows=16777216
    dword.byte[3] = 0x1;

    return dword.val != 1;
}

void fnSwap2Byte(void *word)
{
    char*   ptr, temp;

    ptr    = (char *)word;
    temp   = ptr[0];
    ptr[0] = ptr[1];
    ptr[1] = temp;
}

void fnSwap4Byte(void *word)
{
    char*   ptr, temp;

    ptr    = (char *)word;
    temp   = ptr[0];
    ptr[0] = ptr[3];
    ptr[3] = temp;
    temp   = ptr[1];
    ptr[1] = ptr[2];
    ptr[2] = temp;
}

void fnSwap2Array(short *pBuf, int len)
{
    short *pEnd;

    pEnd = pBuf + len;

    while( pBuf < pEnd )
    {
        fnSwap2Byte(pBuf);
        pBuf++;
    }
}

time_t fnMakeTime(int bUTC, short year, short mon, short day, short hour, short min, short sec)
{
    struct tm    ts;
    time_t       tElapseSec = 0;

    memset(&ts, 0, sizeof(ts));

    ts.tm_year = year - 1900;
    ts.tm_mon  = mon - 1;
    ts.tm_mday = day;
    ts.tm_hour = hour;
    ts.tm_min  = min;
    ts.tm_sec  = sec;

    tElapseSec = mktime(&ts);           // local time  [0 = mktime(1970:01:01:09:00:00)]

    if(bUTC == TRUE)
    {
        tElapseSec += (60 * 60 * 9);    // +9hour
    }

    return tElapseSec;
}

float fnConvertDms2Deg(int Deg, int Min, float Sec)
{
    return (float)Deg + ((float)Min + Sec / 60.f ) / 60.f;
}

void fnFreeMatrix2D(void **ppMatrix, int iCnt)
{
    int     idx = 0;

    if(ppMatrix != NULL)
    {
        for(idx = 0; idx < iCnt; idx++)
        {
            if(ppMatrix[idx] != NULL)
            {
                free(ppMatrix[idx]);
            }
        }
        free(ppMatrix);
    }
}

int** fnMakeMatrix2D_I(int iYdim, int iXdim)
{
    int             **ppData    = NULL;
    int             iYIdx       = 0;

    if((ppData = (int **)calloc(iYdim, sizeof(int *))) == NULL)
        return NULL;

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        if((ppData[iYIdx] = (int *)calloc(iXdim, sizeof(int))) == NULL)
        {
            fnFreeMatrix2D((void **)ppData, iYdim);
            return NULL;
        }
    }
    
    return ppData;
}

float** fnMakeMatrix2D_F(int iYdim, int iXdim)
{
    float           **ppData    = NULL;
    int             iYIdx       = 0;

    if((ppData = (float **)calloc(iYdim, sizeof(float *))) == NULL)
        return NULL;

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        if((ppData[iYIdx] = (float *)calloc(iXdim, sizeof(float))) == NULL)
        {
            fnFreeMatrix2D((void **)ppData, iYdim);
            return NULL;
        }
    }
    
    return ppData;
}

short** fnMakeMatrix2D_S(int iYdim, int iXdim)
{
    short           **ppData    = NULL;
    int             iYIdx       = 0;

    if((ppData = (short **)calloc(iYdim, sizeof(short *))) == NULL)
        return NULL;

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        if((ppData[iYIdx] = (short *)calloc(iXdim, sizeof(short))) == NULL)
        {
            fnFreeMatrix2D((void **)ppData, iYdim);
            return NULL;
        }
    }
    
    return ppData;
}

char** fnMakeMatrix2D_C(int iYdim, int iXdim)
{
    char            **ppData    = NULL;
    int             iYIdx       = 0;

    if((ppData = (char **)calloc(iYdim, sizeof(char *))) == NULL)
        return NULL;

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        if((ppData[iYIdx] = (char *)calloc(iXdim, sizeof(char))) == NULL)
        {
            fnFreeMatrix2D((void **)ppData, iYdim);
            return NULL;
        }
    }
    
    return ppData;
}

unsigned char** fnMakeMatrix2D_UC(int iYdim, int iXdim)
{
    unsigned char   **ppData    = NULL;
    int             iYIdx       = 0;

    if((ppData = (unsigned char **)calloc(iYdim, sizeof(unsigned char *))) == NULL)
        return NULL;

    for(iYIdx = 0; iYIdx < iYdim; iYIdx++)
    {
        if((ppData[iYIdx] = (unsigned char *)calloc(iXdim, sizeof(unsigned char))) == NULL)
        {
            fnFreeMatrix2D((void **)ppData, iYdim);
            return NULL;
        }
    }
    
    return ppData;
}

double fnDegToRad(double dDeg)
{
    return (dDeg * RDR_DF_PI_DFS / 180 );
}

double fnRadToDeg(double dRad)
{
    return (dRad * 180 / RDR_DF_PI_DFS);
}

double fnCalcDistKmLonLat(double dLon1, double dLat1, double dLon2, double dLat2)
{
    double  dTheta  = 0.0;
    double  dDist   = 0.0;

    dTheta  = dLon1 - dLon2;
    dDist   = sin(fnDegToRad(dLat1))*sin(fnDegToRad(dLat2)) +
              cos(fnDegToRad(dLat1))*cos(fnDegToRad(dLat2))*cos(fnDegToRad(dTheta));
    dDist   = acos(dDist);
    dDist   = fnRadToDeg(dDist);
    dDist   = dDist * 60 * 1.1515;

    dDist   = dDist * 1.609344; // KM

    return dDist;
}

double fnDistSphericalSurface(float fLon1, float fLat1, float fLon2, float fLat2)
{
    double  dDist   = 0.0;
    float   fA      = 0.0;
    float   fB      = 0.0;
    float   fC      = 0.0;
    float   fX      = 0.0;

    fC = (RDR_DF_PI_DFS/180.0)*(90.0-fLat1);
    fB = (RDR_DF_PI_DFS/180.0)*(90.0-fLat2);
    fA = fabs((RDR_DF_PI_DFS/180.0)*(fLon1-fLon2));
    fX = (180/RDR_DF_PI_DFS)*acos((cos(fB)*cos(fC))+(sin(fB)*sin(fC)*cos(fA)));
    dDist = 2*RDR_DF_PI_DFS*RDR_DF_KMA_MAP_RE*(fX/360.0);

    return dDist;
}

int fnSplit(char *szStr, char *pSp[], int iSpCnt, char var)
{
   char     *pPtr   = NULL;
   int      iCnt     = 0;

   if(szStr == NULL || pSp == NULL || iSpCnt <= 0 || var == 0) {
      return -1;
   }

   pPtr = szStr;
   pSp[iCnt++] = szStr;

    while(*pPtr != 0 && iCnt < iSpCnt) 
    {
        if(*pPtr == var) 
        {
            *pPtr++ = 0;
            pSp[iCnt++] = pPtr;
        }
        else 
        {
            pPtr++;
        }
   }

   return iCnt;
}

float fnDiffDegree(float fAlpha, float fBeta)
{
    return fabs(fnMinusDegree(fAlpha, fBeta));
}

float fnMinusDegree(float fAlpha, float fBeta)
{
    float   fDiff    = 0.0f;

    if(fabs(fAlpha - fBeta) < RDR_DF_ERR_RANGE_F)
        return 0.;

    fDiff = fAlpha - fBeta;
    if(fDiff > 180.)
        return fDiff - 360.0;
    else if(fDiff < -180.0)
        return 360. + fDiff;

    return fDiff;
}

double fnDbzToZeF(double dDbz)
{
    return pow(10., (dDbz/10.));
}

double fnZeToDbzF(double dZe)
{
    if(dZe <= 0)
        return 0;
    else
        return (10. * log10(dZe));
}

float fnGetSlantRange(float fPointX, float fPointY, float fHeightM, float fGridM)
{
    float   fRangeX = 0.0f;
    float   fRangeY = 0.0f;
    float   fRangeZ = 0.0f;

    fRangeX = fPointX * fGridM;
    fRangeY = fPointY * fGridM;
    fRangeZ = fHeightM;

    return (float)(sqrt(pow(fRangeX, 2) + pow(fRangeY, 2) + pow(fRangeZ, 2)));
}

float fnGetElevation(float fSlantRangeM, float fHeightM)
{
    double  dAe     = 0.0;
    double  dR      = 0.0;

    dR  = fSlantRangeM;
    dAe = (RDR_DF_KMA_MAP_RE * 1000.)*4./3.;

    return (float)((180./RDR_DF_PI_DFS) * asin((fHeightM*fHeightM - dR*dR + 2*dAe*fHeightM) / (2*dR*dAe)));
}

double fnDbzToRainF(double dDbz, float fZr_a, float fZr_b)
{
    return (pow(pow(10.,(double)(dDbz/10.))/fZr_a, 1/fZr_b));
}

double fnRainToDbzF(double dRain, float fZr_a, float fZr_b)
{
    return (10*log10(fZr_a) + 10*fZr_b*log10(dRain));
}

struct tm fnIncYear(struct tm tm_ptr, int iAddYear)
{
    struct  tm new_tm_ptr;
    time_t  tTime           = 0;
    int     iNewYear        = 0;
    int     iMonth          = 0;
    int     iDay            = 0;

    iMonth = tm_ptr.tm_mon+1;
    iDay   = tm_ptr.tm_mday;

    new_tm_ptr = tm_ptr;

    new_tm_ptr.tm_year += iAddYear;

    if(iMonth == 2 && iDay == 29)
    {
        iNewYear = new_tm_ptr.tm_year+1900;
        if(fnCheckLeapYear(iNewYear) == 0)
        {
            new_tm_ptr.tm_mday = 28;
        }
    }

    tTime = mktime(&new_tm_ptr);
    localtime_r(&tTime, &new_tm_ptr);

    return new_tm_ptr;
}

struct tm fnIncMonth(struct tm tm_ptr, int iAddMonth)
{
    struct  tm new_tm_ptr;
    int     iMonth          = 0;
    int     iTempMonth      = 0;
    int     iDay            = 0;
    int     iTempDay        = 0;
    int     iMonthChgCnt    = 0;
    int     iSign           = 0;
    int     iIsFirst        = 0;

    if(iAddMonth < 0)
        iSign = -1;
    else if(iAddMonth > 0)
        iSign = 1;
    else
        return tm_ptr;

    iMonth = tm_ptr.tm_mon+1;
    iDay   = tm_ptr.tm_mday;

    new_tm_ptr = tm_ptr;

    while(1)
    {
        new_tm_ptr = fnIncDay(new_tm_ptr, iSign);
        iTempMonth = new_tm_ptr.tm_mon+1;
        if(iMonth != iTempMonth)
        {
            iMonthChgCnt++;
            iMonth = iTempMonth;
            if(iMonthChgCnt == abs(iAddMonth))
                break;
        }
    }

    while(1)
    {
        if(iSign > 0)
        {
            iTempDay = new_tm_ptr.tm_mday;
            if(iDay == iTempDay)
                break;

            iTempMonth = new_tm_ptr.tm_mon+1;
            if(iMonth != iTempMonth)
            {
                new_tm_ptr = fnIncDay(new_tm_ptr, -1);
                break;
            }
            new_tm_ptr = fnIncDay(new_tm_ptr, -1);
        }
        else
        {
            iTempDay = new_tm_ptr.tm_mday;
            if(iIsFirst == 1)
            {
                iIsFirst = 0;
                if(iDay >= iTempDay)
                    break;

            }

            if(iDay == iTempDay)
                break;

            new_tm_ptr = fnIncDay(new_tm_ptr, -1);
        }
    }

    return new_tm_ptr;
}

struct tm fnIncDay(struct tm tm_ptr, int iAddDay)
{
    time_t tTime    = 0;
    struct tm new_tm_ptr;

    tTime = mktime(&tm_ptr);
    tTime = tTime + (60 * 60 * 24 * iAddDay);
    memset(&new_tm_ptr, 0x00, sizeof(struct tm));
    localtime_r(&tTime, &new_tm_ptr);

    return new_tm_ptr;
}

struct tm fnIncMin(struct tm tm_ptr, int iAddMin)
{
    time_t tTime    = 0;
    struct tm new_tm_ptr;

    tTime = mktime(&tm_ptr);
    tTime = tTime + (60 * iAddMin);
    memset(&new_tm_ptr, 0x00, sizeof(struct tm));
    localtime_r(&tTime, &new_tm_ptr);

    return new_tm_ptr;
}

int fnCheckLeapYear(int iYear)
{
    if(((iYear % 4 == 0) && (iYear % 100 != 0)) || (iYear % 400 == 0))
        return TRUE;
    else
        return FALSE;
}

int fnGetLastDayOfYM(int iYear, int iMon)
{
    int iYearIdx = 0;

    int rgnDay[2][12] =
    {
        { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 },
        { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }
    };

    if(iYear < 1 || iMon < 1 || iMon > 12)
        return 0;

    if(fnCheckLeapYear(iYear) == TRUE)
    {
        iYearIdx = 1;
    }
    else
    {
        iYearIdx = 0;
    }

    return rgnDay[iYearIdx][iMon];
}

float fnGetMaxRangeToData(float **ppData, int iYdim, int iXdim, float fGridKm)
{
    int     iXIdx       = 0;
    int     iYCenter    = 0;
    int     iLeftX      = 0;
    int     iRightX     = 0;
    float   fMaxRange   = -9999.;

    if(ppData == NULL)
        return fMaxRange;

    iYCenter = iYdim/2;

    for(iXIdx = 0; iXIdx < iXdim; iXIdx++)
    {
        if(fabs(ppData[iYCenter][iXIdx] - RDR_DF_OUT_BOUND_F) >= RDR_DF_ERR_RANGE_F)
        {
            iLeftX = iXIdx;
            break;
        }
    }

    for(iXIdx = iXdim-1; iXIdx >= 0; iXIdx--)
    {
        if(fabs(ppData[iYCenter][iXIdx] - RDR_DF_OUT_BOUND_F) >= RDR_DF_ERR_RANGE_F)
        {
            iRightX = iXIdx;
            break;
        }
    }

    fMaxRange = ((iRightX - iLeftX) * fGridKm)/2.;

    return fMaxRange;
}

/* ================================================================================ */







