/* ================================================================================ */
//
// Radar Map Function
//
// 2016.08.25 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable



/* ================================================================================ */
// Static Function

static void fnInitAzedMap(AZED_PARAMETER *pMap, AZED_VAR *pMapv)
{
    double dAk      = 0.0;

    if(pMapv == NULL)
        return;

    (*pMapv).m_dPI = RDR_DF_PI_DFS;//asin(1.0)*2.0;
    (*pMapv).m_dDegrad = (*pMapv).m_dPI/180.0;
    (*pMapv).m_dRaddeg = 180.0/(*pMapv).m_dPI;
    (*pMapv).m_dRe = pMap->m_fRe/pMap->m_fGridKm;
    (*pMapv).m_dSlon = pMap->m_fSlon * (*pMapv).m_dDegrad;
    (*pMapv).m_dSlat = pMap->m_fSlat * (*pMapv).m_dDegrad;
    (*pMapv).m_dOlon = pMap->m_fOlon * (*pMapv).m_dDegrad;
    (*pMapv).m_dOlat = pMap->m_fOlat * (*pMapv).m_dDegrad;
    dAk = sin((*pMapv).m_dSlat)*sin((*pMapv).m_dOlat) 
          + cos((*pMapv).m_dSlat)*cos((*pMapv).m_dOlat)*cos((*pMapv).m_dOlon-(*pMapv).m_dSlon);
    if (dAk < -0.99999) return;
    else if (dAk > 0.99999)
    {
        dAk = 1.0;
    }
    else
    {
        dAk = acos(dAk);
        dAk = dAk / sin(dAk);
    }
    (*pMapv).m_dXo = (*pMapv).m_dRe*dAk*cos((*pMapv).m_dOlat)
                     *sin((*pMapv).m_dOlon-(*pMapv).m_dSlon) - pMap->m_fXo;
    (*pMapv).m_dYo = (*pMapv).m_dRe*dAk*(cos((*pMapv).m_dSlat)*sin((*pMapv).m_dOlat) - 
                     sin((*pMapv).m_dSlat)*cos((*pMapv).m_dOlat)
                     *cos((*pMapv).m_dOlon-(*pMapv).m_dSlon)) - pMap->m_fYo;
    (*pMapv).m_iFirst = 1;
}

/* ================================================================================ */
// Function

AZED_PARAMETER fnGetAzedMapInfo(float fRe, float fGridKm, float fSlon, float fSlat, float fOlon, float fOlat, float fXo, float fYo)
{
    AZED_PARAMETER  map;

    map.m_fRe       = fRe;
    map.m_fGridKm   = fGridKm;
    map.m_fSlon     = fSlon;
    map.m_fSlat     = fSlat;
    map.m_fOlon     = fOlon;
    map.m_fOlat     = fOlat;
    map.m_fXo       = fXo;
    map.m_fYo       = fYo;

    return map;
}

void fnAzedProj(float *fLon, float *fLat, float *fX, float *fY , int iCode, AZED_PARAMETER *pMap, AZED_VAR *pMapv)
{
    double dAlon    = 0.0;
    double dAlat    = 0.0;
    double dXn      = 0.0;
    double dYn      = 0.0;
    double dRa      = 0.0;
    double dTheta   = 0.0;
    double dAc      = 0.0;
    double dA1      = 0.0;
    double dA2      = 0.0;
    double dAk      = 0.0;

    if(fLon == NULL || fLat == NULL || fX == NULL || fY == NULL || pMapv == NULL)
        return;

    if((*pMapv).m_iFirst == 0)
        fnInitAzedMap(pMap, pMapv);

    if(iCode == 0) 
    {           //(lon,lat) --> (x,y)
        dAlat = (*fLat)*(*pMapv).m_dDegrad;
        dAlon = (*fLon)*(*pMapv).m_dDegrad - (*pMapv).m_dSlon;
        dAk = sin((*pMapv).m_dSlat)*sin(dAlat) + cos((*pMapv).m_dSlat)*cos(dAlat)*cos(dAlon);
        if (dAk < -0.99999) return;
        if (dAk > 0.99999)
        {
            dAk = 1.0;
        }
        else
        {
            dAk = acos(dAk);
            dAk = dAk / sin(dAk);
        }
        *fX = (*pMapv).m_dRe*dAk*cos(dAlat)*sin(dAlon) - (*pMapv).m_dXo;
        *fY = (*pMapv).m_dRe*dAk*(cos((*pMapv).m_dSlat)*sin(dAlat) 
              - sin((*pMapv).m_dSlat)*cos(dAlat)*cos(dAlon)) - (*pMapv).m_dYo;
    } 
    else 
    {                    //(x,y) --> (lon,lat)
        dXn = *fX + (*pMapv).m_dXo;
        dYn = *fY + (*pMapv).m_dYo;
        dRa = dXn*dXn + dYn*dYn;
        if (dRa <= 0.0)
        {
            dAlat = (*pMapv).m_dSlat;
        }
        else
        {
            dRa = sqrt(dRa);
            dAc = dRa/(*pMapv).m_dRe;
            dAlat = cos(dAc)*sin((*pMapv).m_dSlat) + dYn*sin(dAc)*cos((*pMapv).m_dSlat)/dRa;
            dAlat = asin(dAlat);
        }
        *fLat = dAlat*(*pMapv).m_dRaddeg;
        dA1 = dXn*sin(dAc);
        dA2 = dRa*cos((*pMapv).m_dSlat)*cos(dAc) - dYn*sin((*pMapv).m_dSlat)*sin(dAc);
        if (fabs(dA2) <= 0.0)
        {
            dTheta = (*pMapv).m_dPI*0.5;
            if (dA2 < 0.0) dTheta = -dTheta;
        }
        else
        {
            dTheta = atan2(dA1, dA2);
        }
        *fLon = (dTheta + (*pMapv).m_dSlon)*(*pMapv).m_dRaddeg;
    }
}

LAMC_PARAMETER fnGetLamcMapInfo(float fRe, float fGridKm, float fSlat1, float fSlat2, float fOlon, float fOlat, float fXo, float fYo)
{
    LAMC_PARAMETER  map;

    map.m_fRe       = fRe;
    map.m_fGridKm   = fGridKm;
    map.m_fSlat1    = fSlat1;
    map.m_fSlat2    = fSlat2;
    map.m_fOlon     = fOlon;
    map.m_fOlat     = fOlat;
    map.m_fXo       = fXo;
    map.m_fYo       = fYo;

    return map;
}

void fnLamcProj(float *fLon, float *fLat, float *fX, float *fY, int iCode, LAMC_PARAMETER *pMap, LAMC_VAR *pVar)
{
    double          dSlat1, dSlat2, dAlon, dAlat, dXn, dYn, dRa, dTheta;

    if(fLon == NULL || fLat == NULL || fX == NULL || fY == NULL)
        return;

    if(pVar->m_iFirst == 0) 
    {
        pVar->m_dPi = asin(1.0)*2.0;
        pVar->m_dDegard = pVar->m_dPi/180.0;
        pVar->m_dRaddeg = 180.0/pVar->m_dPi;

        pVar->m_dRe = pMap->m_fRe/pMap->m_fGridKm;
        dSlat1 = pMap->m_fSlat1 * pVar->m_dDegard;
        dSlat2 = pMap->m_fSlat2 * pVar->m_dDegard;
        pVar->m_dOlon = pMap->m_fOlon * pVar->m_dDegard;
        pVar->m_dOlat = pMap->m_fOlat * pVar->m_dDegard;

        pVar->m_dSn = tan(pVar->m_dPi*0.25 + dSlat2*0.5)/tan(pVar->m_dPi*0.25 + dSlat1*0.5);
        pVar->m_dSn = log(cos(dSlat1)/cos(dSlat2))/log(pVar->m_dSn);
        pVar->m_dSf = tan(pVar->m_dPi*0.25 + dSlat1*0.5);
        pVar->m_dSf = pow(pVar->m_dSf,pVar->m_dSn)*cos(dSlat1)/pVar->m_dSn;
        pVar->m_dRo = tan(pVar->m_dPi*0.25 + pVar->m_dOlat*0.5);
        pVar->m_dRo = pVar->m_dRe*pVar->m_dSf/pow(pVar->m_dRo,pVar->m_dSn);
        pVar->m_iFirst = 1;
    }

    if(iCode == 0) 
    {
        dRa = tan(pVar->m_dPi*0.25+(*fLat)*pVar->m_dDegard*0.5);
        dRa = pVar->m_dRe*pVar->m_dSf/pow(dRa,pVar->m_dSn);
        dTheta = (*fLon)*pVar->m_dDegard - pVar->m_dOlon;
        if (dTheta >  pVar->m_dPi) dTheta -= 2.0*pVar->m_dPi;
        if (dTheta < -pVar->m_dPi) dTheta += 2.0*pVar->m_dPi;
        dTheta *= pVar->m_dSn;
        *fX = (float)(dRa*sin(dTheta)) + pMap->m_fXo;
        *fY = (float)(pVar->m_dRo - dRa*cos(dTheta)) + pMap->m_fYo;
    } 
    else 
    {
        dXn = *fX - pMap->m_fXo;
        dYn = pVar->m_dRo - *fY + pMap->m_fYo;
        dRa = sqrt(dXn*dXn+dYn*dYn);
        if (pVar->m_dSn < 0.0) {
            dRa = -dRa;
        }
        dAlat = pow((pVar->m_dRe*pVar->m_dSf/dRa),(1.0/pVar->m_dSn));
        dAlat = 2.0*atan(dAlat) - pVar->m_dPi*0.5;
        if (fabs(dXn) <= 0.0) {
            dTheta = 0.0;
        } else {
            if (fabs(dYn) <= 0.0) {
                dTheta = pVar->m_dPi*0.5;
                if( dXn < 0.0 ) {
                    dTheta = -dTheta;
                }
            } else
                dTheta = atan2(dXn,dYn);
        }
        dAlon = dTheta/pVar->m_dSn + pVar->m_dOlon;
        *fLat = (float)(dAlat*pVar->m_dRaddeg);
        *fLon = (float)(dAlon*pVar->m_dRaddeg);
    }
}

/* ================================================================================ */



