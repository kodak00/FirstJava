/* ================================================================================ */
//
// Radar Format Information Function
//
// 2016.08.25 SnK 
//
/* ================================================================================ */
// Include

#include "rdr_common.h"
#include "rdr_util.h"

#include "rdr_in_out.h"
#include "rdr_image.h"

/* ================================================================================ */
// Define



/* ================================================================================ */
// Global Variable



/* ================================================================================ */
// Static Variable

static FIELD_MEM_INFO_TBL g_fieldMemInfoTbl[] =
{
    // FILED NAME   MEM TYPE          SCALE   OFF         BAD_VALUE           OUT_BOUND
    { "DZ",     RDR_EN_MEM_CHAR,      1.0f,   0.0f,  RDR_DF_BAD_VALUE_C, RDR_DF_OUT_BOUND_C },
    { "VR",     RDR_EN_MEM_CHAR,      1.0f,   0.0f,  RDR_DF_BAD_VALUE_C, RDR_DF_OUT_BOUND_C },
    { "SW",     RDR_EN_MEM_CHAR,     10.0f,   0.0f,  RDR_DF_BAD_VALUE_C, RDR_DF_OUT_BOUND_C },
    { "CZ",     RDR_EN_MEM_CHAR,      1.0f,   0.0f,  RDR_DF_BAD_VALUE_C, RDR_DF_OUT_BOUND_C },
    { "DR",     RDR_EN_MEM_SHORT,   100.0f,   0.0f,  RDR_DF_BAD_VALUE_S, RDR_DF_OUT_BOUND_S },
    { "PH",     RDR_EN_MEM_SHORT,     1.0f,   0.0f,  RDR_DF_BAD_VALUE_S, RDR_DF_OUT_BOUND_S },
    { "RH",     RDR_EN_MEM_CHAR,    100.0f,   0.0f,  RDR_DF_BAD_VALUE_C, RDR_DF_OUT_BOUND_C },
    { "KD",     RDR_EN_MEM_SHORT,   100.0f,   0.0f,  RDR_DF_BAD_VALUE_S, RDR_DF_OUT_BOUND_S },
    { "RN",     RDR_EN_MEM_FLOAT,     1.0f,   0.0f,  RDR_DF_BAD_VALUE_F, RDR_DF_OUT_BOUND_F },

    { "VIL",    RDR_EN_MEM_SHORT,    10.0f,   0.0f,  RDR_DF_BAD_VALUE_S, RDR_DF_OUT_BOUND_S },
    { "ETOP",   RDR_EN_MEM_SHORT,    10.0f,   0.0f,  RDR_DF_BAD_VALUE_S, RDR_DF_OUT_BOUND_S },

    { "",       RDR_EN_MEM_FLOAT,     1.0f,   0.0f,  RDR_DF_BAD_VALUE_F, RDR_DF_OUT_BOUND_F }
};

static PRODUCT_INFO_TBL g_productInfoTbl[] =
{
    // STD       HDF        BUFR        GRIB
    { "PPI",    "PPI",      "PPI",      "PPI"   },
    { "CAPPI",  "PCAPPI",   "PCAPPI",   "CAPPI" },
    { "BASE",   "BASE",     "BASE",     "BASE"  },
    { "CMAX",   "MAX",      "MAX",      "CMAX"  },
    { "VIL",    "VIL",      "VIL",      "VIL"   },
    { "ETOP",   "ETOP",     "ETOP",     "ETOP"  },
    { "COMP",   "COMP",     "COMP",     "COMP"  },
    { "", "", "", "" }
};

static COMP_INFO_TBL g_compInfoTbl[] = 
{
    // STD,             HDF         BUFR        GRIB
    { "MAX",            "MAXIMUM",  "MAXIMUM",  "MAX"           },
    { "AVE",            "AVERAGE",  "AVERAGE",  "AVE"           },
    { "MIN",            "DOMAIN",   "DOMAIN",   "MIN"           },
    { "NEAR_DIST",      "DOMAIN",   "DOMAIN",   "NEAR_DIST"     },
    { "DIST_WEIGHT",    "DOMAIN",   "DOMAIN",   "DIST_WEIGHT"   },
    { "QI",             "DOMAIN",   "DOMAIN",   "QI"            },
    { "", "", "", "" }
};

static FIELD_INFO_TBL g_fieldInfoTbl[] =
{
    // STD      HDF         BUFR        NC          GRIB
    { "DZ",     "TH",       "TH",       "DBZ",      "DZ"    },
    { "VR",     "VRADDH",   "VRADDH",   "VEL",      "VR"    },
    { "SW",     "WRADH",    "WRADH",    "WIDTH",    "SW"    },
    { "CZ",     "DBZH",     "DBZH",     "DBZc",     "CZ"    },
    { "DR",     "ZDR",      "ZDR",      "ZDR",      "DR"    },
    { "PH",     "PHIDP",    "PHIDP",    "PHIDP",    "PH"    },
    { "RH",     "RHOHV",    "RHOHV",    "RHOHV",    "RH"    },
    { "KD",     "KDP",      "KDP",      "KDP",      "KD"    },

    { "RN",     "RATE",     "RATE",     "RR",       "RN"    },
                                      
    { "VIL",    "VIL",      "VIL",      "VIL",      "VIL"   },
    { "ETOP",   "HIGH",     "HIGH",     "ETOP",     "ETOP"  },

    // NULL
    { "", "", "", "", "" }
};

static RDR_DISP_INFO_TBL g_colorInfoTbl[] =
{
    { "DZ",     RDR_DF_RN_COLOR_FILE,   "%.0f", RDR_EN_COLOR_UNIT,    0.0f },
    { "VR",     RDR_DF_VR_COLOR_FILE,   "%.0f", RDR_EN_COLOR_UNIT,  -50.0f },
    { "SW",     RDR_DF_SW_COLOR_FILE,   "%.1f", RDR_EN_COLOR_UNIT,    0.0f },
    { "CZ",     RDR_DF_RN_COLOR_FILE,   "%.0f", RDR_EN_COLOR_UNIT,    0.0f },
    { "DR",     RDR_DF_DR_COLOR_FILE,   "%.2f", RDR_EN_COLOR_UNIT,   -3.0f },
    { "PH",     RDR_DF_PH_COLOR_FILE,   "%.1f", RDR_EN_COLOR_UNIT,    0.0f },
    { "RH",     RDR_DF_RH_COLOR_FILE,   "%.2f", RDR_EN_COLOR_UNIT,    0.0f },
    { "KD",     RDR_DF_KD_COLOR_FILE,   "%.2f", RDR_EN_COLOR_UNIT,  -20.0f },
    { "RN",     RDR_DF_RN_COLOR_FILE,   "%.1f", RDR_EN_COLOR_RAIN,    0.0f },

    { "VIL",    RDR_DF_VIL_COLOR_FILE,  "%.1f", RDR_EN_COLOR_RAIN,    0.0f },
    { "ETOP",   RDR_DF_ETOP_COLOR_FILE, "%.1f", RDR_EN_COLOR_UNIT,    0.0f },

    { "TH",     RDR_DF_RN_COLOR_FILE,   "%.0f", RDR_EN_COLOR_UNIT,    0.0f },
    { "TV",     RDR_DF_RN_COLOR_FILE,   "%.0f", RDR_EN_COLOR_UNIT,    0.0f },
    { "VRADH",  RDR_DF_VR_COLOR_FILE,   "%.0f", RDR_EN_COLOR_UNIT,  -50.0f },
    { "VRADV",  RDR_DF_VR_COLOR_FILE,   "%.0f", RDR_EN_COLOR_UNIT,  -50.0f },
    { "WRADH",  RDR_DF_SW_COLOR_FILE,   "%.1f", RDR_EN_COLOR_UNIT,    0.0f },
    { "WRADV",  RDR_DF_SW_COLOR_FILE,   "%.1f", RDR_EN_COLOR_UNIT,    0.0f },
    { "DBZH",   RDR_DF_RN_COLOR_FILE,   "%.0f", RDR_EN_COLOR_UNIT,    0.0f },
    { "DBZV",   RDR_DF_RN_COLOR_FILE,   "%.0f", RDR_EN_COLOR_UNIT,    0.0f },
    { "ZDR",    RDR_DF_DR_COLOR_FILE,   "%.2f", RDR_EN_COLOR_UNIT,   -3.0f },
    { "PHIDP",  RDR_DF_PH_COLOR_FILE,   "%.1f", RDR_EN_COLOR_UNIT,    0.0f },
    { "RHOHV",  RDR_DF_RH_COLOR_FILE,   "%.2f", RDR_EN_COLOR_UNIT,    0.0f },
    { "KDP",    RDR_DF_KD_COLOR_FILE,   "%.2f", RDR_EN_COLOR_UNIT,  -20.0f },
    { "RATE",   RDR_DF_RN_COLOR_FILE,   "%.1f", RDR_EN_COLOR_RAIN,    0.0f },
 
    // NULL
    { "", "", "", 0, 0.0 }
};

static RDR_IMG_INFO_TBL g_imgInfoTbl[] =
{
    // SITE
    { "SITE_240", 30, 45, 20, 513,  513, 1.0,                    0,    0, 0, 0 },
    { "SITE_480", 30, 45, 20, 513,  513, RDR_DF_IMG_GRID_AUTO,   0,    0, 0, 0 },

    // COMP
    { "COMP_240", 30, 45,  0, 600,  480, 2.0,                    0,    0, 1, 0 },
    { "COMP_480", 30, 45,  0, 576,  526, 3.0,                  -92,   71, 0, 0 },
    { "COMP_KCJ", 30, 45,  0, 1101, 751, 3.0,                 -162,  367, 1, 0 },

    // NULL
    { "", 0, 0, 0, 0, 0}
};

/* ================================================================================ */
// Static Function



/* ================================================================================ */
// Function

int fnGetStdProductInfo(char *szProduct, PRODUCT_INFO_TBL *pBuf)
{
    int                 iProductIdx = 0;

    if(szProduct == NULL || pBuf == NULL)
        return FALSE;

    while(iProductIdx < LOOP_CNT_MAX)
    {
        if(!strcmp(g_productInfoTbl[iProductIdx].m_szStdProduct, ""))
            return FALSE;

        if(!strcmp(g_productInfoTbl[iProductIdx].m_szStdProduct, szProduct))
        {
            memcpy(pBuf, &g_productInfoTbl[iProductIdx], sizeof(PRODUCT_INFO_TBL));
            return TRUE;
        }

        iProductIdx++;
    }

    return FALSE;
}

int fnGetHdfProductInfo(char *szProduct, PRODUCT_INFO_TBL *pBuf)
{
    int                 iProductIdx = 0;

    if(szProduct == NULL || pBuf == NULL)
        return FALSE;

    while(iProductIdx < LOOP_CNT_MAX)
    {
        if(!strcmp(g_productInfoTbl[iProductIdx].m_szHdfProduct, ""))
            return FALSE;

        if(!strcmp(g_productInfoTbl[iProductIdx].m_szHdfProduct, szProduct))
        {
            memcpy(pBuf, &g_productInfoTbl[iProductIdx], sizeof(PRODUCT_INFO_TBL));
            return TRUE;
        }

        iProductIdx++;
    }

    return FALSE;
}

int fnGetBufrProductInfo(char *szProduct, PRODUCT_INFO_TBL *pBuf)
{
    int                 iProductIdx = 0;

    if(szProduct == NULL || pBuf == NULL)
        return FALSE;

    while(iProductIdx < LOOP_CNT_MAX)
    {
        if(!strcmp(g_productInfoTbl[iProductIdx].m_szBufrProduct, ""))
            return FALSE;

        if(!strcmp(g_productInfoTbl[iProductIdx].m_szBufrProduct, szProduct))
        {
            memcpy(pBuf, &g_productInfoTbl[iProductIdx], sizeof(PRODUCT_INFO_TBL));
            return TRUE;
        }

        iProductIdx++;
    }

    return FALSE;
}

int fnGetGribProductInfo(char *szProduct, PRODUCT_INFO_TBL *pBuf)
{
    int                 iProductIdx = 0;

    if(szProduct == NULL || pBuf == NULL)
        return FALSE;

    while(iProductIdx < LOOP_CNT_MAX)
    {
        if(!strcmp(g_productInfoTbl[iProductIdx].m_szGribProduct, ""))
            return FALSE;

        if(!strcmp(g_productInfoTbl[iProductIdx].m_szGribProduct, szProduct))
        {
            memcpy(pBuf, &g_productInfoTbl[iProductIdx], sizeof(PRODUCT_INFO_TBL));
            return TRUE;
        }

        iProductIdx++;
    }

    return FALSE;
}

int fnGetFieldMemInfo(char *szFieldName, FIELD_MEM_INFO_TBL *pBuf)
{
    int                 iInfoTblIdx = 0;

    if(szFieldName == NULL || pBuf == NULL)
        return FALSE;

    while(iInfoTblIdx < LOOP_CNT_MAX)
    {
        if(!strcmp(g_fieldMemInfoTbl[iInfoTblIdx].m_szFieldName, ""))
        {
            memcpy(pBuf, &g_fieldMemInfoTbl[iInfoTblIdx], sizeof(FIELD_MEM_INFO_TBL));
            return TRUE;
        }

        if(!strcmp(g_fieldMemInfoTbl[iInfoTblIdx].m_szFieldName, szFieldName))
        {
            memcpy(pBuf, &g_fieldMemInfoTbl[iInfoTblIdx], sizeof(FIELD_MEM_INFO_TBL));
            return TRUE;
        }

        iInfoTblIdx++;
    }

    return FALSE;
}

int fnGetStdCompInfo(char *szCompMethod, COMP_INFO_TBL *pBuf)
{
    int                 iInfoTblIdx = 0;

    if(szCompMethod == NULL || pBuf == NULL)
        return FALSE;

    while(iInfoTblIdx < LOOP_CNT_MAX)
    {
        if(!strcmp(g_compInfoTbl[iInfoTblIdx].m_szStdCompMethod, ""))
            return FALSE;

        if(!strcmp(g_compInfoTbl[iInfoTblIdx].m_szStdCompMethod, szCompMethod))
        {
            memcpy(pBuf, &g_compInfoTbl[iInfoTblIdx], sizeof(COMP_INFO_TBL));
            return TRUE;
        }

        iInfoTblIdx++;
    }

    return FALSE;
}

int fnGetStdFieldInfo(char *szFieldName, FIELD_INFO_TBL *pBuf)
{
    int                 iInfoTblIdx = 0;

    if(szFieldName == NULL || pBuf == NULL)
        return FALSE;

    while(iInfoTblIdx < LOOP_CNT_MAX)
    {
        if(!strcmp(g_fieldInfoTbl[iInfoTblIdx].m_szFieldName, ""))
            return FALSE;

        if(!strcmp(g_fieldInfoTbl[iInfoTblIdx].m_szFieldName, szFieldName))
        {
            memcpy(pBuf, &g_fieldInfoTbl[iInfoTblIdx], sizeof(FIELD_INFO_TBL));
            return TRUE;
        }

        iInfoTblIdx++;
    }

    return FALSE;
}

int fnGetHdfFieldInfo(char *szQuantity, FIELD_INFO_TBL *pBuf)
{
    int                 iInfoTblIdx = 0;

    if(szQuantity == NULL || pBuf == NULL)
        return FALSE;

    while(iInfoTblIdx < LOOP_CNT_MAX)
    {
        if(!strcmp(g_fieldInfoTbl[iInfoTblIdx].m_szHdfQuantity, ""))
        {
            snprintf(pBuf->m_szFieldName,     sizeof(pBuf->m_szFieldName),     
                     "%s", szQuantity);
            snprintf(pBuf->m_szHdfQuantity,   sizeof(pBuf->m_szHdfQuantity),   
                     "%s", szQuantity);
            snprintf(pBuf->m_szBufrQuantity,  sizeof(pBuf->m_szBufrQuantity),  
                     "%s", szQuantity);
            snprintf(pBuf->m_szNcMoment,      sizeof(pBuf->m_szNcMoment),  
                     "%s", szQuantity);
            snprintf(pBuf->m_szGribQuantity,  sizeof(pBuf->m_szGribQuantity), 
                     "%s", szQuantity);
            return TRUE;
        }

        if(!strcmp(g_fieldInfoTbl[iInfoTblIdx].m_szHdfQuantity, szQuantity))
        {
            memcpy(pBuf, &g_fieldInfoTbl[iInfoTblIdx], sizeof(FIELD_INFO_TBL));
            return TRUE;
        }

        iInfoTblIdx++;
    }

    return FALSE;
}

int fnGetBufrFieldInfo(char *szQuantity, FIELD_INFO_TBL *pBuf)
{
    int                 iInfoTblIdx = 0;

    if(szQuantity == NULL || pBuf == NULL)
        return FALSE;

    while(iInfoTblIdx < LOOP_CNT_MAX)
    {
        if(!strcmp(g_fieldInfoTbl[iInfoTblIdx].m_szBufrQuantity, ""))
        {
            snprintf(pBuf->m_szFieldName,     sizeof(pBuf->m_szFieldName),     
                     "%s", szQuantity);
            snprintf(pBuf->m_szHdfQuantity,   sizeof(pBuf->m_szHdfQuantity),   
                     "%s", szQuantity);
            snprintf(pBuf->m_szBufrQuantity,  sizeof(pBuf->m_szBufrQuantity),  
                     "%s", szQuantity);
            snprintf(pBuf->m_szNcMoment,      sizeof(pBuf->m_szNcMoment),  
                     "%s", szQuantity);
            snprintf(pBuf->m_szGribQuantity,  sizeof(pBuf->m_szGribQuantity), 
                     "%s", szQuantity);
            return TRUE;
        }

        if(!strcmp(g_fieldInfoTbl[iInfoTblIdx].m_szBufrQuantity, szQuantity))
        {
            memcpy(pBuf, &g_fieldInfoTbl[iInfoTblIdx], sizeof(FIELD_INFO_TBL));
            return TRUE;
        }

        iInfoTblIdx++;
    }

    return FALSE;
}

int fnGetNcFieldInfo(char *szMoment, FIELD_INFO_TBL *pBuf)
{
    int                 iInfoTblIdx = 0;

    if(szMoment == NULL || pBuf == NULL)
        return FALSE;

    while(iInfoTblIdx < LOOP_CNT_MAX)
    {
        if(!strcmp(g_fieldInfoTbl[iInfoTblIdx].m_szNcMoment, ""))
        {
            snprintf(pBuf->m_szFieldName,     sizeof(pBuf->m_szFieldName),     
                     "%s", szMoment);
            snprintf(pBuf->m_szHdfQuantity,   sizeof(pBuf->m_szHdfQuantity),   
                     "%s", szMoment);
            snprintf(pBuf->m_szBufrQuantity,  sizeof(pBuf->m_szBufrQuantity),  
                     "%s", szMoment);
            snprintf(pBuf->m_szNcMoment,      sizeof(pBuf->m_szNcMoment),  
                     "%s", szMoment);
            snprintf(pBuf->m_szGribQuantity,  sizeof(pBuf->m_szGribQuantity), 
                     "%s", szMoment);
            return TRUE;
        }

        if(!strcmp(g_fieldInfoTbl[iInfoTblIdx].m_szNcMoment, szMoment))
        {
            memcpy(pBuf, &g_fieldInfoTbl[iInfoTblIdx], sizeof(FIELD_INFO_TBL));
            return TRUE;
        }

        iInfoTblIdx++;
    }

    return FALSE;
}

int fnGetGribFieldInfo(char *szQuantity, FIELD_INFO_TBL *pBuf)
{
    int                 iInfoTblIdx = 0;

    if(szQuantity == NULL || pBuf == NULL)
        return FALSE;

    while(iInfoTblIdx < LOOP_CNT_MAX)
    {
        if(!strcmp(g_fieldInfoTbl[iInfoTblIdx].m_szGribQuantity, ""))
        {
            snprintf(pBuf->m_szFieldName,     sizeof(pBuf->m_szFieldName),     
                     "%s", szQuantity);
            snprintf(pBuf->m_szHdfQuantity,   sizeof(pBuf->m_szHdfQuantity),   
                     "%s", szQuantity);
            snprintf(pBuf->m_szBufrQuantity,  sizeof(pBuf->m_szBufrQuantity),  
                     "%s", szQuantity);
            snprintf(pBuf->m_szNcMoment,      sizeof(pBuf->m_szNcMoment),  
                     "%s", szQuantity);
            snprintf(pBuf->m_szGribQuantity,  sizeof(pBuf->m_szGribQuantity), 
                     "%s", szQuantity);
            return TRUE;
        }

        if(!strcmp(g_fieldInfoTbl[iInfoTblIdx].m_szGribQuantity, szQuantity))
        {
            memcpy(pBuf, &g_fieldInfoTbl[iInfoTblIdx], sizeof(FIELD_INFO_TBL));
            return TRUE;
        }

        iInfoTblIdx++;
    }

    return FALSE;
}

int fnGetColorFileInfo(char *szFieldName, RDR_DISP_INFO_TBL *pBuf)
{
    int                 iInfoTblIdx = 0;

    if(szFieldName == NULL || pBuf == NULL)
        return FALSE;

    while(iInfoTblIdx < LOOP_CNT_MAX)
    {
        if(!strcmp(g_colorInfoTbl[iInfoTblIdx].m_szFieldName, ""))
            return FALSE;

        if(!strcmp(g_colorInfoTbl[iInfoTblIdx].m_szFieldName, szFieldName))
        {
            memcpy(pBuf, &g_colorInfoTbl[iInfoTblIdx], sizeof(RDR_DISP_INFO_TBL));
            return TRUE;
        }

        iInfoTblIdx++;
    }

    return FALSE;
}

int fnGetImgSizeInfo(char *szImgKind, RDR_IMG_INFO_TBL *pBuf)
{
    int                 iInfoTblIdx = 0;

    if(szImgKind == NULL || pBuf == NULL)
        return FALSE;

    while(iInfoTblIdx < LOOP_CNT_MAX)
    {
        if(!strcmp(g_imgInfoTbl[iInfoTblIdx].m_szImgKind, ""))
            return FALSE;

        if(!strcmp(g_imgInfoTbl[iInfoTblIdx].m_szImgKind, szImgKind))
        {
            memcpy(pBuf, &g_imgInfoTbl[iInfoTblIdx], sizeof(RDR_IMG_INFO_TBL));
            return TRUE;
        }

        iInfoTblIdx++;
    }

    return FALSE;
}

/* ================================================================================ */



