/* ================================================================================ */
//
// Radar Image Common Function Header
//
// 2016.08.30 SnK 
//
/* ================================================================================ */

#ifndef RDR_IMG_FUNCTION_H
#define RDR_IMG_FUNCTION_H

/* ================================================================================ */
// Define

#define     RDR_DF_RING_RADIUS      (100.)

/* ================================================================================ */
// Enum



/* ================================================================================ */
// Struct



/* ================================================================================ */
// Function

/* -----------------------------------------------------------------------------+
|   2차원 배열 데이터에서 이미지에 해당하는 데이터를 생성한다.                  |
|   파라미터                                                                    |
|       float **ppData              : 2차원 배열 데이터                         |
|       int iYdim                   : 배열의 Ydim                               |
|       int iXdim                   : 배열의 Xdim                               |
|       float fDataGridKm           : 데이터의 그리드                           |
|       int iWidth                  : 이미지의 가로 크기                        |
|       int iHeight                 : 이미지의 세로 크기                        |
|       float fImgGridKm            : 이미지의 그리드                           |
|   반환값                                                                      |
|       float 데이터                                                            |
+----------------------------------------------------------------------------- */
float** fnMakeSiteImageData(float **ppData, int iYdim, int iXdim, float fDataGridKm, int iWidth, int iHeight, float fImgGridKm);

/* -----------------------------------------------------------------------------+
|   2차원 배열 데이터에서 이미지에 해당하는 데이터를 생성한다.                  |
|   파라미터                                                                    |
|       char *szImgKind             : 이미지 종류 ( "COMP_240", ... )           |
|       float **ppData              : 2차원 배열 데이터                         |
|       int iYdim                   : 배열의 Ydim                               |
|       int iXdim                   : 배열의 Xdim                               |
|       float fDataGridKm           : 데이터의 그리드                           |
|       int iWidth                  : 이미지의 가로 크기                        |
|       int iHeight                 : 이미지의 세로 크기                        |
|       float fImgGridKm            : 이미지의 그리드                           |
|   반환값                                                                      |
|       float 데이터                                                            |
+----------------------------------------------------------------------------- */
float** fnMakeCompImageData(char *szImgKind, float **ppData, int iYdim, int iXdim, float fDataGridKm, int iWidth, int iHeight, float fImgGridKm);

/* -----------------------------------------------------------------------------+
|   2차원 배열 데이터와 이미지 배열의 그리드 비율을 이용하여 데이터를 가져온다. |
|   파라미터                                                                    |
|       float **ppData      : 2차원 배열 데이터                                 |
|       int iYdim           : 배열의 Ydim                                       |
|       int iXdim           : 배열의 Xdim                                       |
|       int iDiff_x         : 이미지 배열의 원점 이동 X 값                      |
|       int iDiff_y         : 이미지 배열의 원점 이동 Y 값                      |
|       int iYPoint         : 이미지 배열의 Y 좌표                              |
|       int iXPoint         : 이미지 배열의 X 좌표                              |
|       float fXGridScale   : X축 그리드 비율                                   |
|       float fYGridScale   : Y축 그리드 비율                                   |
|   반환값                                                                      |
|       float 데이터                                                            |
+----------------------------------------------------------------------------- */
float fnGetRadarValue(float **ppData, int iYdim, int iXdim, int iDiff_x, int iDiff_y, int iYPoint, int iXPoint, float fXGridScale, float fYGridScale);

/* -----------------------------------------------------------------------------+
|   레이더 관측 반경의 표시                                                     |
|   파라미터                                                                    |
|       gdImagePtr pImg             : 이미지 포인터                             |
|       float **ppImgData           : 이미지 배열                               |
|       int iWidth                  : 이미지 배열 가로 크기                     |
|       int iHeight                 : 이미지 배열 세로 크기                     |
|       float fOutBound             : 관측반경 밖의 값                          |
|       int iInBoundColor           : 관측반경 안의 색상                        |
|       int iOutBoundColor          : 관측반경 밖의 색상                        |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnDrawRadarImgBound(gdImagePtr pImg, float **ppImgData, int iWidth, int iHeight, float fOutBound, int iInBoundColor, int iOutBoundColor);

/* -----------------------------------------------------------------------------+
|   레이더 에코의 표시                                                          |
|   파라미터                                                                    |
|       gdImagePtr pImg                     : 이미지 포인터                     |
|       float **ppImgData                   : 이미지 배열                       |
|       int iWidth                          : 이미지 배열 가로 크기             |
|       int iHeight                         : 이미지 배열 세로 크기             |
|       RDR_COLOR_TBL *pColorTbl            : 색상표 정보                       |
|       int iColorKind                      : 표출할 색상의 종류                |
|       float fMinValue                     : 표출 최소 값                      |
|       int iMinDiffType                    : 최소값 비교 종류 (0:'<', 1:'<=')  |
|       int iEchoDiffType                   : 에코값 비교 종류 (0:'<', 1:'<=')  |
|       int echoColorBar[RDR_DF_COLOR_MAX]  : 생상표 배열                       |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnDrawRadarEcho(gdImagePtr pImg, float **ppImgData, int iWidth, int iHeight, RDR_COLOR_TBL *pColorTbl, int iColorKind, float fMinValue, int iMinDiffType, int iEchoDiffType, int echoColorBar[RDR_DF_COLOR_MAX]);

/* -----------------------------------------------------------------------------+
|   배열의 DBZ를 RAIN으로 변환한다.                                        |
|   파라미터                                                                    |
|       float **Data    : 2차원 배열                                            |
|       int iYdim       : 배열의 Ydim                                           |
|       int iXdim       : 배열의 Xdim                                           |
|       int iUnit       : 변경되는 종류 ( DBZ -> RAIN, ... )                    |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnDbzToRainrate(float **ppData, int iYdim, int iXdim, int iUnit);

/* -----------------------------------------------------------------------------+
|   기상청 스무딩 함수                                                          |
|   파라미터                                                                    |
|       float **ppData  : 2차원 배열                                            |
|       int iYdim       : 2차원 배열의 Ydim                                     |
|       int iXdim       : 2차원 배열의 Xdim                                     |
|       int iSmoothNum  : 스무딩 회수                                           |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnKmaCmpSmooth(float **ppData, int iYdim, int iXdim, int iSmoothNum);

/* -----------------------------------------------------------------------------+
|   기상청 스무딩 함수                                                          |
|   파라미터                                                                    |
|       float **ppData  : 2차원 배열                                            |
|       int iYdim       : 2차원 배열의 Ydim                                     |
|       int iXdim       : 2차원 배열의 Xdim                                     |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnCompSmooth(float **ppData, int iYdim, int iXdim);

/* -----------------------------------------------------------------------------+
|   등거리 동심원 표시                                                          |
|   파라미터                                                                    |
|       gdImagePtr pImg     : 이미지 포인터                                     |
|       int iWidth          : 이미지 배열 가로 크기                             |
|       int iHeight         : 이미지 배열 세로 크기                             |
|       float fImgGridKm    : 이미지의 그리드                                   |
|       int iLineColor      : 라인 색상                                         |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnDrawSiteImgRing(gdImagePtr pImg, int iWidth, int iHeight, float fImgGridKm, int iLineColor);

/* -----------------------------------------------------------------------------+
|   대각선 표시                                                                 |
|   파라미터                                                                    |
|       gdImagePtr pImg     : 이미지 포인터                                     |
|       int iWidth          : 이미지 배열 가로 크기                             |
|       int iHeight         : 이미지 배열 세로 크기                             |
|       int iLineColor      : 라인 색상                                         |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnDrawSiteImgDirection(gdImagePtr pImg, int iWidth, int iHeight, int iLineColor);

/* ================================================================================ */

#endif

