/* ================================================================================ */
//
// Radar Map Header
//
// 2016.08.25 SnK 
//
/* ================================================================================ */

#ifndef RDR_UT_MAP_H
#define RDR_UT_MAP_H

/* ================================================================================ */
// Define

#define     RDR_DF_KMA_MAP_RE           (6371.00877)

// Lambert Conformal Conic Projection KMA PROJ
#define     RDR_DF_LCC_SLAT1            (30.0f)
#define     RDR_DF_LCC_SLAT2            (60.0f)
#define     RDR_DF_LCC_OLON             (126.0f)
#define     RDR_DF_LCC_OLAT             (38.0f)

// COMP 240km MAP LON - LAT
#define     RDR_DF_COMP_240_LL_LON      (121.808304f)
#define     RDR_DF_COMP_240_LL_LAT      (30.596533f)
#define     RDR_DF_COMP_240_LU_LON      (121.028351f)
#define     RDR_DF_COMP_240_LU_LAT      (41.590557f)
#define     RDR_DF_COMP_240_RU_LON      (132.951736f)
#define     RDR_DF_COMP_240_RU_LAT      (41.479988f)
#define     RDR_DF_COMP_240_RL_LON      (131.863235f)
#define     RDR_DF_COMP_240_RL_LAT      (30.506027f)

// COMP 240km 1KM MAP
#define     RDR_DF_COMP_240_1KM_GRID    (1.0f)
#define     RDR_DF_COMP_240_1KM_XO      (400)
#define     RDR_DF_COMP_240_1KM_YO      (800)
#define     RDR_DF_COMP_240_1KM_YDIM    (1200)
#define     RDR_DF_COMP_240_1KM_XDIM    (960)

// COMP 480km MAP LON - LAT
#define     RDR_DF_COMP_480_LL_LON      (118.283920f)
#define     RDR_DF_COMP_480_LL_LAT      (27.850607f)
#define     RDR_DF_COMP_480_LU_LON      (116.147820f)
#define     RDR_DF_COMP_480_LU_LAT      (43.574066f)
#define     RDR_DF_COMP_480_RU_LON      (136.463547f)
#define     RDR_DF_COMP_480_RU_LAT      (43.517548f)
#define     RDR_DF_COMP_480_RL_LON      (134.196945f)
#define     RDR_DF_COMP_480_RL_LAT      (27.808210f)

// COMP 480km 3KM MAP
#define     RDR_DF_COMP_480_3KM_GRID    (3.0f)
#define     RDR_DF_COMP_480_3KM_XO      (255)
#define     RDR_DF_COMP_480_3KM_YO      (360)
#define     RDR_DF_COMP_480_3KM_YDIM    (576)
#define     RDR_DF_COMP_480_3KM_XDIM    (526)

// COMP KCJ MAP LON - LAT
#define     RDR_DF_COMP_KCJ_LL_LON      (116.800659f)
#define     RDR_DF_COMP_KCJ_LL_LAT      (17.412804f)
#define     RDR_DF_COMP_KCJ_LU_LON      (111.657104f)
#define     RDR_DF_COMP_KCJ_LU_LAT      (46.738403f)
#define     RDR_DF_COMP_KCJ_RU_LON      (142.338867f)
#define     RDR_DF_COMP_KCJ_RU_LAT      (46.472404f)
#define     RDR_DF_COMP_KCJ_RL_LON      (136.499435f)
#define     RDR_DF_COMP_KCJ_RL_LAT      (17.259367f)

// COMP KCJ 3KM MAP
#define     RDR_DF_COMP_KCJ_3KM_GRID    (3.0f)
#define     RDR_DF_COMP_KCJ_3KM_XO      (350)
#define     RDR_DF_COMP_KCJ_3KM_YO      (755)
#define     RDR_DF_COMP_KCJ_3KM_YDIM    (1101)
#define     RDR_DF_COMP_KCJ_3KM_XDIM    (751)

// SAT 5KM MAP
#define     RDR_DF_SAT_5KM_GRID         (5.0f)
#define     RDR_DF_SAT_5KM_XO           (850)
#define     RDR_DF_SAT_5KM_YO           (1061)

/* ================================================================================ */
// Enum



/* ================================================================================ */
// Struct

// LAMC MAP INFO
typedef struct
{
    float   m_fRe;
    float   m_fGridKm;
    float   m_fSlat1;
    float   m_fSlat2;
    float   m_fOlon;
    float   m_fOlat;
    float   m_fXo;
    float   m_fYo;
} LAMC_PARAMETER;

typedef struct
{
    int     m_iFirst;
    double  m_dPi;
    double  m_dDegard;
    double  m_dRaddeg;
    double  m_dRe;
    double  m_dOlon;
    double  m_dOlat;
    double  m_dSn;
    double  m_dSf;
    double  m_dRo;
} LAMC_VAR;

// AZED MAP INFO
typedef struct 
{
    float   m_fRe;
    float   m_fGridKm;
    float   m_fSlon;
    float   m_fSlat;
    float   m_fOlon;
    float   m_fOlat;
    float   m_fXo;
    float   m_fYo;
} AZED_PARAMETER;

typedef struct 
{
    int     m_iFirst;
    double  m_dRe;
    double  m_dSlon;
    double  m_dSlat;
    double  m_dOlon;
    double  m_dOlat;
    double  m_dXo;
    double  m_dYo;
    double  m_dPI;
    double  m_dDegrad;
    double  m_dRaddeg;
} AZED_VAR;

/* ================================================================================ */
// Function

/* -----------------------------------------------------------------------------+
|   Azimuthal Equidistant Projection의 지도 정보를 세팅한다.                    |
|   파리미터                                                                    |
|       float fRe       : 지구반경
|       float fGridKm   : Grid ( km )                                           |
|       float fSlon     : 기준 경도                                             |
|       float fSlat     : 기준 위도                                             |
|       float fOlon     : 원점 경도                                             |
|       float fOlat     : 원점 위도                                             |
|       float fXo       : 원점 X 좌표                                           |
|       float fYo       : 원점 Y 좌표                                           |
|   반환값                                                                      |
|       AZED_PARAMETER 구조체                                                   |
+----------------------------------------------------------------------------- */
AZED_PARAMETER fnGetAzedMapInfo(float fRe, float fGridKm, float fSlon, float fSlat, float fOlon, float fOlat, float fXo, float fYo);

/* -----------------------------------------------------------------------------+
|   Azimuthal Equidistant Projection                                            |
|   파리미터                                                                    |
|       float *fLon             : 경도 메모리 포인터                            |
|       float *fLat             : 위도 메모리 포인터                            |
|       float *fX               : X 좌표 메모리 포인터                          |
|       float *fY               : Y 좌표 메모리 포인터                          |
|       int iCode               : 0 = 위경도 -> XY / 1 = XY -> 위경도           |
|       AZED_PARAMETER *pMap    : 좌표변환 지도 정보                            |
|       AZED_VAR *pMapv         : 좌표변환 지도 파라미터                        |
+----------------------------------------------------------------------------- */
void fnAzedProj(float *fLon,float *fLat, float *fX, float *fY, int iCode, AZED_PARAMETER *pMap, AZED_VAR *pMapv);

/* -----------------------------------------------------------------------------+
|   Lambert Conformal Conic Projection의 지도 정보를 세팅한다.                  |
|   파리미터                                                                    |
|       float fRe       : 지구 반경                                             |
|       float fGridKm   : Grid ( km )                                           |
|       float fSlat1    : 기준 위도1                                            |
|       float fSlat2    : 기준 위도2                                            |
|       float fOlon     : 원점 경도                                             |
|       float fOlat     : 원점 위도                                             |
|       float fXo       : 원점 X 좌표                                           |
|       float fYo       : 원점 Y 좌표                                           |
|   반환값                                                                      |
|       LAMC_PARAMETER 구조체                                                   |
+----------------------------------------------------------------------------- */
LAMC_PARAMETER fnGetLamcMapInfo(float fRe, float fGridKm, float fSlat1, float fSlat2, float fOlon, float fOlat, float fXo, float fYo);

/* -----------------------------------------------------------------------------+
|   Lambert Conformal Conic Projection                                          |
|   파리미터                                                                    |
|       float *fLon             : 경도 메모리 포인터                            |
|       float *fLat             : 위도 메모리 포인터                            |
|       float *fX               : X 좌표 메모리 포인터                          |
|       float *fY               : Y 좌표 메모리 포인터                          |
|       int iCode               : 0 = 위경도 -> XY / 1 = XY -> 위경도           |
|       LAMC_PARAMETER *pMap    : 좌표변환 지도 정보                            |
|       LAMC_VAR *pVar          : 좌표변환에 사용되는 변수                      |
+----------------------------------------------------------------------------- */
void fnLamcProj(float *fLon, float *fLat, float *fX, float *fY, int iCode, LAMC_PARAMETER *pMap, LAMC_VAR *pVar);

/* ================================================================================ */

#endif


