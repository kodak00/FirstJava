/* ================================================================================ */
//
// Radar Image Color Header
//
// 2016.08.30 SnK 
//
/* ================================================================================ */

#ifndef RDR_IMG_COLOR_H
#define RDR_IMG_COLOR_H

/* ================================================================================ */
// Define

// PPI, CAPPI, BASE, CMAX
#define RDR_DF_RN_COLOR_FILE        "kma_rn_comis.col"
#define RDR_DF_VR_COLOR_FILE        "kma_vr_comis.col"
#define RDR_DF_SW_COLOR_FILE        "kma_sw_comis.col"
#define RDR_DF_DR_COLOR_FILE        "kma_dr_comis.col"
#define RDR_DF_PH_COLOR_FILE        "kma_ph_comis.col"
#define RDR_DF_RH_COLOR_FILE        "kma_rh_comis.col"
#define RDR_DF_KD_COLOR_FILE        "kma_kd_comis.col"
// ETOP, VIL
#define RDR_DF_ETOP_COLOR_FILE      "kma_etop_comis.col"
#define RDR_DF_VIL_COLOR_FILE       "kma_vil_comis.col"

// Not Use Color Value
#define RDR_DF_SKIP_COLOR           (-9999)
#define RDR_DF_LINE_COLOR           (-9998)
#define RDR_DF_FONT_COLOR           (-9997)
#define RDR_DF_IN_BOUND_COLOR       (-9996)
#define RDR_DF_OUT_BOUND_COLOR      (-9995)
#define RDR_DF_AWS_COLOR            (-9994)

#define RDR_DF_COLOR_MAX            (100)

/* ================================================================================ */
// Enum

typedef enum
{
    RDR_EN_COLOR_RAIN = 0,
    RDR_EN_COLOR_UNIT
} RDR_EN_COLOR_TYPE;

typedef enum
{
    RDR_EN_LINE_COLOR  = 0,
    RDR_EN_FONT_COLOR,
    RDR_EN_IN_BOUND_COLOR,
    RDR_EN_OUT_BOUND_COLOR,
    RDR_EN_AWS_COLOR,
    RDR_EN_DISP_COLOR_MAX
} RDR_EN_DISP_COLOR;

/* ================================================================================ */
// Struct

typedef struct
{
    int     m_iNum;
    int     m_iR;
    int     m_iG;
    int     m_iB;
    float   m_fRain;
    float   m_fUnit;
} RDR_COLOR_INFO;

typedef struct
{
    char            m_szRainTitle[20];
    char            m_szUnitTitle[20];
    int             m_iEchoColorCnt;
    RDR_COLOR_INFO  m_dispColorTbl[RDR_EN_DISP_COLOR_MAX];
    RDR_COLOR_INFO  m_echoColorTbl[RDR_DF_COLOR_MAX];
} RDR_COLOR_TBL;

/* ================================================================================ */
// Function

/* -----------------------------------------------------------------------------+
|	이미지 생산을 위한 Color File을 읽는다.                                     |
|   파라미터                                                                    |
|       char *szFile    : Color 파일의 이름                                     |
|   반환값                                                                      |
|       Color 정보 or NULL                                                      |
|       메모리를 할당하기 때문에 free 해야 한다.                                |
+----------------------------------------------------------------------------- */
RDR_COLOR_TBL *fnReadColorTable(char *szFile);

/* -----------------------------------------------------------------------------+
|	생상정보파일에서 읽은 R,G,B 값으로 색상표를 생성한다.                       |
|   파라미터                                                                    |
|       gdImagePtr pImg                         : gd 이미지 포인터              |
|       RDR_COLOR_TBL *pColorTbl                : 생성 정보 포인터              |
|       int echoColorBar[RDR_DF_COLOR_MAX]      : 에코 색상표 버퍼              |
|       int dispColorBar[RDR_EN_DISP_COLOR_MAX] : 기타 색상표 버퍼              |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnAllocColorTbl(gdImagePtr pImg, RDR_COLOR_TBL *pColorTbl, int echoColorBar[RDR_DF_COLOR_MAX], int dispColorBar[RDR_EN_DISP_COLOR_MAX]);

/* -----------------------------------------------------------------------------+
|	데이터 값으로 색상표 인덱스를 구한다.                                       |
|   파라미터                                                                    |
|       float fData                 : 데이터                                    |
|       RDR_COLOR_TBL *pColorTbl    : 색상 정보 포인터                          |
|       int iColorKind              : 색상의 종류                               |
|       float fMinValue             : 표출 최소값                               |
|       int iMinDiffType            : 최소값  비교타입 ( 0:<, 1:<= )            |
|       int iDiffType               : 데이터값비교타입 ( 0:<, 1:<= )            |
|   반환값                                                                      |
|       색상표 인덱스 or -1                                                     |
+----------------------------------------------------------------------------- */
int fnGetColorLevel(float fData, RDR_COLOR_TBL *pColorTbl, int iColorKind, float fMinValue, int iMinDiffType, int iDiffType);

/* ================================================================================ */

#endif



