/* ================================================================================ */
//
// Radar NetCDF Output Function
//
// 2016.11.20 SnK 
//
/* ================================================================================ */

#ifndef RDR_IO_NC_H
#define RDR_IO_NC_H

/* ================================================================================ */
// Define



/* ================================================================================ */
// Enum

typedef enum
{
    NC_EN_VAR_GLOBAL = 0,
    NC_EN_VAR_COORDINATE,
    NC_EN_VAR_LOCATION,
    NC_EN_VAR_SWEEP,
    NC_EN_VAR_SENSOR,
    NC_EN_VAR_MOVING,
    NC_EN_VAR_INSTRUMENT,
    NC_EN_VAR_RADAR,
    NC_EN_VAR_R_CALIB,
    NC_EN_VAR_VEL,
    NC_EN_VAR_COR,
    NC_EN_VAR_MOMENT,
} NC_EN_VAR_TYPE;

/* ================================================================================ */
// Struct

typedef struct
{
    char    m_szVarName[STR_LENGTH_MAX];
    int     m_iVarType;
} NC_VAR_TYPE_TBL;

typedef struct
{
    size_t                  m_nTime;
    size_t                  m_nRange;
    size_t                  m_nSweep;
    size_t                  m_nString_length_short;
    size_t                  m_nString_length_medium;
    size_t                  m_nString_length_long;
    size_t                  m_nR_calib;
    size_t                  m_nRay_n_gates;                         // m_szN_gates_vary is TRUE
    size_t                  m_nRay_start_index;                     // m_szN_gates_vary is TRUE
    size_t                  m_nFrequency;
} NC_DIMENSION;

typedef struct
{
    char                    m_szConventions[STR_LENGTH_MAX];
    char                    m_szVersion[STR_LENGTH_MAX];
    char                    m_szTitle[STR_LENGTH_MAX];
    char                    m_szInstitution[STR_LENGTH_MAX];
    char                    m_szReferences[STR_LENGTH_MAX];
    char                    m_szSource[STR_LENGTH_MAX];
    char                    m_szHistory[STR_LENGTH_MAX];
    char                    m_szComment[STR_LENGTH_MAX];
    char                    m_szInstrument_name[STR_LENGTH_MAX];
    char                    m_szSite_name[STR_LENGTH_MAX];
    char                    m_szScan_name[STR_LENGTH_MAX];
    int                     m_iScan_id;
    char                    m_szPlatform_is_mobile[STR_LENGTH_MAX];
    char                    m_szN_gates_vary[STR_LENGTH_MAX];
    char                    m_szRay_times_increas[STR_LENGTH_MAX];
    char                    m_szField_names[STR_LENGTH_MAX];
} NC_GLOBAL_ATTR;

typedef struct
{
    int                     m_iVolume_number;
    char                    m_szPlatform_type[STR_LENGTH_MAX];
    char                    m_szInstrument_type[STR_LENGTH_MAX];
    char                    m_szPrimary_axis[STR_LENGTH_MAX];
    char                    m_szTime_coverage_start[STR_LENGTH_MAX];
    char                    m_szTime_coverage_end[STR_LENGTH_MAX];
    char                    m_szTime_reference[STR_LENGTH_MAX];
} NC_GLOBAL_VAR;

typedef struct
{
    float                   m_fMeters_to_center_of_first_gate;
    float                   m_fMeters_between_gates;
} NC_RANGE_ATTR;

typedef struct
{
    double                  *m_pTime;                               // time_coverage_start+sec
                                                                    // Dim : time
                                                                    // Dim : time
    NC_RANGE_ATTR           m_rangeAttr;
    float                   *m_pRange;                              // each bin Range Meter
                                                                    // Dim : ragne
} NC_COORDINATE_VAR;    

typedef struct
{
    double                  m_dLatitude;
    double                  m_dLongitude;
    double                  m_dAltitude;                            // Meters
    double                  m_dAltitude_agl;
} NC_LOCATION_VAR;

typedef struct
{
    int                     *m_pSweep_number;                       // Dim : sweep
    char                    **m_ppSweep_mode;                       // Dim : sweep*str_short
    float                   *m_pFixed_angle;                        // Dim : sweep
    int                     *m_pSweep_start_ray_index;              // Dim : sweep
    int                     *m_pSweep_end_ray_index;                // Dim : sweep
    float                   *m_pTarget_scan_rate;                   // Dim : sweep
    char                    **m_ppRays_are_indexed;                 // Dim : sweep*str_short
    float                   *m_pRay_angled_res;                     // Dim : sweep
} NC_SWEEP_VAR;

typedef struct
{
    float                   *m_pAzimuth;                            // Dim : time
    float                   *m_pElevation;                          // Dim : time
    float                   *m_pScan_rate;                          // Dim : time
    char                    *m_pAntenna_transition;                 // Dim : time
    char                    *m_pGeorefs_applied;                    // Dim : time
} NC_SENSOR_VAR;

typedef struct
{
    float                   *m_pHeading;                            // Dim : time
    float                   *m_pRoll;                               // Dim : time
    float                   *m_pPitch;                              // Dim : time
    float                   *m_pDrift;                              // Dim : time
    float                   *m_pRotation;                           // Dim : time
    float                   *m_pTilt;                               // Dim : time
} NC_MOVING_VAR;

typedef struct
{
    short                   m_sFillValue;
    float                   m_fScale_factor;
    float                   m_fAdd_offset;
} NC_MOMENT_ATTR;

typedef struct
{
    NC_MOMENT_ATTR          m_momentAttr;
    char                    m_szMoment[6+1];
    short                   *m_pData;                               // Dim : time * range
} NC_MOMENT_VAR;

typedef struct
{
    float                   *m_pFrequency;                          // Dim : frequency
    char                    **m_ppFollow_mode;                      // Dim : sweep*str_short
    float                   *m_pPulse_width;                        // Dim : time
    char                    **m_ppPrt_mode;                         // Dim : sweep*str_short
    float                   *m_pPrt;                                // Dim : time
    float                   *m_pPrt_ratio;                          // Dim : time
    char                    **m_ppPolarization_mode;                // Dim : sweep*str_short
    float                   *m_pNyquist_velocity;                   // Dim : time
    float                   *m_pUnamebiguous_range;                 // Dim : time
    int                     *m_pN_samples;                          // Dim : time
} NC_INSTRUMENT_SUB;

typedef struct
{
    float                   m_fRadar_antenna_gain_h;
    float                   m_fRadar_antenna_gain_v;
    float                   m_fRadar_beam_width_h;
    float                   m_fRadar_beam_width_v;
    float                   m_fRadar_receiver_bandwidth;
    float                   *m_pRadar_mesured_transmit_power_h;     // Dim : time
    float                   *m_pRadar_mesured_transmit_power_v;     // Dim : time
} NC_RADAR_SUB;

typedef struct
{
    char                    *m_pR_calib_index;                      // Dim : time
    char                    **m_ppR_calib_time;                     // Dim : r_calib*str_short
    float                   *m_pR_calib_pulse_width;                // Dim : r_calib
    float                   *m_pR_calib_antenna_gain_h;             // Dim : r_calib
    float                   *m_pR_calib_antenna_gain_v;             // Dim : r_calib
    float                   *m_pR_calib_xmit_power_h;               // Dim : r_calib
    float                   *m_pR_calib_xmit_power_v;               // Dim : r_calib
    float                   *m_pR_calib_two_way_waveguid_loss_h;    // Dim : r_calib
    float                   *m_pR_calib_two_way_waveguid_loss_v;    // Dim : r_calib
    float                   *m_pR_calib_two_way_radome_loss_h;      // Dim : r_calib
    float                   *m_pR_calib_two_way_radome_loss_v;      // Dim : r_calib
    float                   *m_pR_calib_receiver_mismatch_loss;     // Dim : r_calib
    float                   *m_pR_calib_radar_constant_h;           // Dim : r_calib
    float                   *m_pR_calib_radar_constant_v;           // Dim : r_calib
    float                   *m_pR_calib_noise_hc;                   // Dim : r_calib
    float                   *m_pR_calib_noise_vc;                   // Dim : r_calib
    float                   *m_pR_calib_noise_hx;                   // Dim : r_calib
    float                   *m_pR_calib_noise_vx;                   // Dim : r_calib
    float                   *m_pR_calib_receiver_gain_hc;           // Dim : r_calib
    float                   *m_pR_calib_receiver_gain_vc;           // Dim : r_calib
    float                   *m_pR_calib_receiver_gain_hx;           // Dim : r_calib
    float                   *m_pR_calib_receiver_gain_vx;           // Dim : r_calib
    float                   *m_pR_calib_base_1km_hc;                // Dim : r_calib
    float                   *m_pR_calib_base_1km_vc;                // Dim : r_calib
    float                   *m_pR_calib_base_1km_hx;                // Dim : r_calib
    float                   *m_pR_calib_base_1km_vx;                // Dim : r_calib
    float                   *m_pR_calib_sum_power_hc;               // Dim : r_calib
    float                   *m_pR_calib_sum_power_vc;               // Dim : r_calib
    float                   *m_pR_calib_sum_power_hx;               // Dim : r_calib
    float                   *m_pR_calib_sum_power_vx;               // Dim : r_calib
    float                   *m_pR_calib_noise_source_power_h;       // Dim : r_calib
    float                   *m_pR_calib_noise_source_power_v;       // Dim : r_calib
    float                   *m_pR_calib_power_measure_loss_h;       // Dim : r_calib
    float                   *m_pR_calib_power_measure_loss_v;       // Dim : r_calib
    float                   *m_pR_calib_coupler_forward_loss_h;     // Dim : r_calib
    float                   *m_pR_calib_coupler_forward_loss_v;     // Dim : r_calib
    float                   *m_pR_calib_zdr_correction;             // Dim : r_calib
    float                   *m_pR_calib_ldr_correctoin_h;           // Dim : r_calib
    float                   *m_pR_calib_ldr_correctoin_v;           // Dim : r_calib
    float                   *m_pR_calib_system_phidp;               // Dim : r_calib
    float                   *m_pR_calib_test_power_h;               // Dim : r_calib
    float                   *m_pR_calib_test_power_v;               // Dim : r_calib
    float                   *m_pR_calib_receiver_slope_hc;          // Dim : r_calib
    float                   *m_pR_calib_receiver_slope_vc;          // Dim : r_calib
    float                   *m_pR_calib_receiver_slope_hx;          // Dim : r_calib
    float                   *m_pR_calib_receiver_slope_vx;          // Dim : r_calib
} NC_R_CALIB_SUB;

typedef struct
{
    float                   *m_pEastward_velocity;                  // Dim : time
    float                   *m_pNorthward_velocity;                 // Dim : time
    float                   *m_pVertical_velocity;                  // Dim : time
    float                   *m_pEastward_wind;                      // Dim : time
    float                   *m_pNorthwrad_wind;                     // Dim : time
    float                   *m_pVertical_wind;                      // Dim : time
    float                   *m_pHeading_rate;                       // Dim : time
    float                   *m_pRoll_rate;                          // Dim : time
    float                   *m_pPitch_rate;                         // Dim : time
} NC_PLATFORM_VEL_SUB;

typedef struct
{
    float                   m_fAzimuth_correction;
    float                   m_fElevation_correction;
    float                   m_fRange_correction;
    float                   m_fLonitude_correction;
    float                   m_fLatitude_correction;
    float                   m_fPressure_alitutde_correction;
    float                   m_fRadar_alitude_correction;
    float                   m_fEastward_ground_speed_correction;
    float                   m_fNorthward_ground_speed_correction;
    float                   m_fVertical_velocity_correction;
    float                   m_fHeading_correction;
    float                   m_fRoll_correction;
    float                   m_fPitch_correction;
    float                   m_fDrift_correction;
    float                   m_fRotation_correction;
    float                   m_fTilt_correction;
} NC_GEOMETRY_COR_SUB;

typedef struct
{
    NC_DIMENSION            m_dim;
    NC_GLOBAL_ATTR          m_global_attr;
    NC_GLOBAL_VAR           m_global_var;
    NC_COORDINATE_VAR       m_coordi_var;
    NC_LOCATION_VAR         m_locat_var;
    NC_SWEEP_VAR            m_sweep_var;
    NC_SENSOR_VAR           m_sensor_var;
    NC_MOVING_VAR           m_moving_var;
    NC_INSTRUMENT_SUB       m_instru_sub;
    NC_RADAR_SUB            m_radar_sub;
    NC_R_CALIB_SUB          m_r_calib_sub;
    NC_PLATFORM_VEL_SUB     m_vel_sub;
    NC_GEOMETRY_COR_SUB     m_cor_sub;

    int                     m_iMaxMoment;
    NC_MOMENT_VAR           m_moment_var[RDR_DF_MAX_FIELD];
} NC_RADAR;

/* ================================================================================ */
// Function


/* -----------------------------------------------------------------------------+
|   NC RADAR 파일을 읽는다.                                                     |
|   파라미터                                                                    |
|       char* szFile        : NC RADAR 파일 전체 경로                           |
|   반환값                                                                      |
|       NC 메모리 포인터 or NULL                                                |
|       메모리를 할당하기 때문에 fnFreeNcRadar를 호출하여 해제해야 한다.        |
+----------------------------------------------------------------------------- */
NC_RADAR* fnLoadNcRadar(char* szFile);

/* -----------------------------------------------------------------------------+
|   NC 데이터 메모리를 해제한다.                                                |
|   파라미터                                                                    |
|       NC_RADAR *pNc : NC 메모리 포인터                                        |
+----------------------------------------------------------------------------- */
void fnFreeNcRadar(NC_RADAR *pNc);

/* ================================================================================ */

#endif









