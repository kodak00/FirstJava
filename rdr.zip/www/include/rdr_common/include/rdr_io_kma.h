/* ================================================================================ */
//
// Radar KMA Output Function
//
// 2016.10.31 SnK 
//
/* ================================================================================ */

#ifndef RDR_IO_KMA_H
#define RDR_IO_KMA_H

/* ================================================================================ */
// Define

#define RDR_DF_KMA_SHORT_SCALE  (100.)

/* ================================================================================ */
// Enum



/* ================================================================================ */
// Struct



/* ================================================================================ */
// Function

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷의 240km 합성장을 기상청형식의 바이너리로 저장한다.       |
|   파라미터                                                                    |
|       STD_PRODUCT* pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char* szProduct             : 프로덕트 이름 ("PPI, "CAPPI", ... )       |
|       char* szFieldName           : 필드이름 ("CZ")                           |
|       char* szOutFile             : 저장 파일 이름                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnWriteStdProductKmaComp240(STD_PRODUCT* pStdProduct, char* szProduct, char* szFieldName, char* szOutFile);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷의 480km 합성장을 기상청형식의 바이너리로 저장한다.       |
|   파라미터                                                                    |
|       STD_PRODUCT* pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char* szProduct             : 프로덕트 이름 ("PPI")                     |
|       char* szFieldName           : 필드이름 ("CZ")                           |
|       char* szOutFile             : 저장 파일 이름                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnWriteStdProductKmaComp480(STD_PRODUCT* pStdProduct, char* szProduct, char* szFieldName, char* szOutFile);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷의 동아시아 합성장을 기상청형식의 바이너리로 저장한다.    |
|   파라미터                                                                    |
|       STD_PRODUCT* pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char* szProduct             : 프로덕트 이름 ("PPI")                     |
|       char* szFieldName           : 필드이름 ("CZ")                           |
|       char* szOutFile             : 저장 파일 이름                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnWriteStdProductKmaCompKCJ(STD_PRODUCT* pStdProduct, char* szProduct, char* szFieldName, char* szOutFile);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷의 동아시아 합성장을 기상청형식의 바이너리로 저장한다.    |
|   파라미터                                                                    |
|       STD_PRODUCT* pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char* szProduct             : 프로덕트 이름 ("PPI")                     |
|       char* szFieldName           : 필드이름 ("CZ")                           |
|       int iCappiCnt               : 3D 연직 개수                              |
|       char* szOutFile             : 저장 파일 이름                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnWriteStdProductKmaComp3D(STD_PRODUCT* pStdProduct, char* szProduct, char* szFieldName, int iCappiCnt, char* szOutFile);

/* ================================================================================ */

#endif

