/* ================================================================================ */
//
// Radar Standard Format & Function
//
// 2016.08.05 SnK 
//
/* ================================================================================ */

#ifndef RDR_IO_STD_H
#define RDR_IO_STD_H

/* ================================================================================ */
// Define

#define RDR_DF_STD_PRODUCT_MAX      (100)

/* ================================================================================ */
// Enum

typedef enum
{
    STD_EN_PRODUCT_SITE = 1,
    STD_EN_PRODUCT_COMP
} STD_EN_PRODUCT_TYPE;

typedef enum
{
    // UF
    STD_EN_SWMD_CALIBATION = 0,
    STD_EN_SWMD_PPI,
    STD_EN_SWMD_COPLANE,
    STD_EN_SWMD_RHI,
    STD_EN_SWMD_VERTICAL,
    STD_EN_SWMD_TARGET,
    STD_EN_SWMD_MANUAL,
    STD_EN_SWMD_IDLE,

    // NC
    STD_EN_SWMD_SECTOR,
    STD_EN_SWMD_POINTING,
    STD_EN_SWMD_SUNSCAN
} STD_EN_SWEEP_MODE;

typedef enum
{
    // UF
    STD_EN_PM_HORIZONTAL = 0,
    STD_EN_PM_VERTICAL,
    STD_EN_PM_CIRCULAR,
    STD_EN_PM_ELLIPTICAL,

    // NC
    STD_EN_PM_HV_ALT,
    STD_EN_PM_HV_SIM
} STD_EN_POL_MODE;

/* ================================================================================ */
// Struct

// Hash Table
typedef struct
{
    float   m_fAzimuth;
    int     m_iCon;
    int     m_iHigh;
    int     m_iLow;
} STD_AZIMUTH_TBL;

typedef struct
{
    // mandatory header
    int             m_iVolumeNo;                        // Volume scan number on the tape, N/A for disk
    char            m_szRadarName[8+1];                 // radar name
    char            m_szSiteName[8+1];                  // site name
    double          m_dLat;
    double          m_dLon;
    int             m_iAnteHeight;                      // Height of antenna above sea level in meters
    int             m_iSweepMode;                       // Sweep mode
    float           m_fSweepRate;                       // Sweep rate (degrees/seconds x 64). 
    char            m_szConvertName[8+1];               // Tape generator facility name (8 character ASCII)
    time_t          m_tConvertTime;                     // Current time when the converter was run
    int             m_iNoDataValue;                     // Deleted of missing data flag (Suggest 100000 octal)

    // option header
    char            m_szProjectName[8+1];
    float           m_fBaselineAzimuth;                 // Baseline azimuth (1/64)
    float           m_fBaselineElevation;               // Baseline elevation (1/64)
    char            m_szFieldTapeName[8+1];             // Field tape name (8 ASCII)

    // field header
    int             m_iPulseWidth;                      // Sample volume depth (m), (Pulse width in meters)
    float           m_fBeamWidthH;                      // Horizontal Beam width in 1/64 of degree
    float           m_fBeamWidthV;                      // Vertical Beam width in 1/64 of degree
    int             m_iBandWidth;                       // Receiver bandwidth (Mhz)
    int             m_iPolarMode;                       // Polarization transmitted
    float           m_fWaveLength;                      // Wavelength in 1/64 of a cm
    char            m_szThresholdType[2+1];             // Type of data used to threshold
    int             m_iThresholdValue;
    int             m_iScale;
    char            m_szEditCode[2+1];                  // Edit code (2 ASCII)
    int             m_iPRT;                             // Pulse repetition time (microseconds)
    int             m_iBitsPerBin;                      // Must be 16
} STD_GLOBAL_HDR;

typedef struct
{
    // for VF, VE, VR, VT, VP
    float           m_fNyquistVelocity;                 // Nyquist velocity (scaled)
    char            m_szVelocityFlag[2+1];              // FL (2 ASCII)
    // for DM
    float           m_fRadarConstant;                   // Radar constant
    float           m_fNoisePower;                      // Noise power (dB(mW) x scale)
    float           m_fReceiverGain;                    // Receiver gain (dB ×x scale)
    float           m_fPeakPower;                       // Peak power (dB(mW) x scale)
    float           m_fAntennaGain;                     // Antenna gain (dB x scale)
    float           m_fPulseDuration;                   // Pulse duration (microseconds x 64)
} STD_SWEEP_HDR;

typedef struct
{
    time_t          m_tTime;                            // Time of the ray
    float           m_fAzimuth;                         // Azimuth (1/64) to midpoint of sample
    float           m_fElevation;                       // Elevation in 1/64 of a degree
    float           m_fFixedAngle;                      // Sweep desired angle in 1/64 of a degree
    int             m_iStartRangeKm;                    // Range to first gate (km) => 0
    int             m_iStartRangeMeter;                 // Adjustment to center of first gate (m)
    int             m_iBinSpacing;                      // Sample Volume spacing (m), (Bin spacing in meters)
    int             m_iSampleSize;                      // Sample size
} STD_RAY_HDR;

typedef struct
{
    int             m_iScaleFactor;                     // Met units = file value/ScaleFactor => 100
    char            m_szFieldName[8+1];                 // (Field name) 1st field name (2 ASCII)
} STD_FIELD_HDR;

typedef struct
{
    time_t          m_tConvertTime;
    char            m_szSiteName[8+1];
    double          m_dLon;
    double          m_dLat;
    int             m_iAnteHeightM;
    char            m_szTask[8+1];
    char            m_szSystem[8+1];
    double          m_dNi;
    char            m_szCompMethod[16+1];

    long            m_lXsize;
    long            m_lYsize;
    double          m_dXscale;
    double          m_dYscale;
    double          m_LL_lon;
    double          m_LL_lat;
    double          m_UL_lon;
    double          m_UL_lat;
    double          m_UR_lon;
    double          m_UR_lat;
    double          m_LR_lon;
    double          m_LR_lat;
} STD_PRODUCT_HDR;

/* -----------------------------------------------------------------------------+
|	데이터 입력을 위한 표준데이터규격                                           |
+----------------------------------------------------------------------------- */

// field
typedef struct
{
    STD_FIELD_HDR   m_hdr;
    int             m_iMaxBin;
    short           *m_pData;
} STD_FIELD;

// ray
typedef struct
{
    STD_RAY_HDR     m_hdr;
    int             m_iMaxField;
    STD_FIELD       **m_ppField;
} STD_RAY;

// sweep
typedef struct
{
    STD_SWEEP_HDR   m_hdr;
    int             m_iMaxRay;
    STD_RAY         **m_ppRay;
} STD_SWEEP;

// radar
typedef struct
{
    STD_GLOBAL_HDR  m_hdr;
    int             m_iMaxSweep;
    STD_SWEEP       **m_ppSweep;
} STD_RADAR;

/* -----------------------------------------------------------------------------+
|	데이터 출력을 위한 표준데이터규격                                           |
+----------------------------------------------------------------------------- */

typedef struct
{
    char                m_szFieldName[8+1];
    int                 m_iMemType;
    char                **m_ppData_c;
    short               **m_ppData_s;
    float               **m_ppData_f;
} STD_PRODUCT_DATA;

typedef struct
{
    char                m_szProduct[6+1];
    double              m_dProdpar[2];
    int                 m_iMaxField;
    STD_PRODUCT_DATA    **m_ppProductData;
} STD_PRODUCT_DATASET;

typedef struct
{
    int                 m_iMaxPpi;
    int                 m_iMaxCappi;
    int                 m_iMaxBase;
    int                 m_iMaxCmax;
    int                 m_iMaxVil;
    int                 m_iMaxEtop;
    STD_PRODUCT_DATASET **m_ppPpi;
    STD_PRODUCT_DATASET **m_ppCappi;
    STD_PRODUCT_DATASET **m_ppBase;
    STD_PRODUCT_DATASET **m_ppCmax;
    STD_PRODUCT_DATASET **m_ppVil;
    STD_PRODUCT_DATASET **m_ppEtop;
} STD_TOTAL_PRODUCT;

typedef struct
{
    int                 m_iStdProductType;
    STD_PRODUCT_HDR     m_product_hdr;
    STD_TOTAL_PRODUCT   m_totalProduct;
} STD_PRODUCT;

/* ================================================================================ */
// Input Function

/* -----------------------------------------------------------------------------+
|	표준데이터포맷의 메모리가 정상인지 판단하는 함수                            |
|   파라미터                                                                    |
|       STD_RADAR *pStd : 표준데이터포맷 메모리 포인터                          |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnValidStdRadar(STD_RADAR *pStd);

/* -----------------------------------------------------------------------------+
|	표준데이터포맷의 메모리 할당 해제 함수                                      |
|   파라미터                                                                    |
|       STD_RADAR* pStd : 표준데이터포맷의 메모리 포인터                        |
+----------------------------------------------------------------------------- */
void fnFreeStdRadar(STD_RADAR *pStd);

/* -----------------------------------------------------------------------------+
|	표준데이터포맷의 모든 RAY의수, 최대 Sweep의 수,                             |
|   모든 Sweep중 최대 Ray의 수,  모든 Ray 중 최대 Bin 의 수,                    |
|   모든 Ray 중 최대 Field의 수를 구한다.                                       |
|   파라미터                                                                    |
|       STD_RADAR* pStd : 표준데이터포맷의 메모리 포인터                        |
|       int *pTotalRay  : 모든 Ray의   수 저장 버퍼 포인터                      |
|       int *pMaxSweep  : 최대 Sweep의 수 저장 버퍼 포인터                      |
|       int *pMaxRay    : 최대 Ray의   수 저장 버퍼 포인터                      |
|       int *pMaxBin    : 최대 Bin의   수 저장 버퍼 포인터                      |
|       int *pMaxField  : 최대 Field의 수 저장 버퍼 포인터                      |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnGetMaxCountStd(STD_RADAR *pStd, int *pTotalRay, int *pMaxSweep, int *pMaxRay, int *pMaxBin, int *pMaxField);

/* -----------------------------------------------------------------------------+
|   Sweep의 최대 Ray의 수,  모든 Ray 중 최대 Bin 의 수,                         |
|   모든 Ray 중 최대 Field의 수를 구한다.                                       |
|   파라미터                                                                    |
|       STD_SWEEP *pSweep   : 표준데이터포맷의 메모리 포인터                    |
|       int *pMaxRay        : 최대 Ray의   수 저장 버퍼 포인터                  |
|       int *pMaxBin        : 최대 Bin의   수 저장 버퍼 포인터                  |
|       int *pMaxField      : 최대 Field의 수 저장 버퍼 포인터                  |
+----------------------------------------------------------------------------- */
void fnGetSweepMaxCountStd(STD_SWEEP *pSweep, int *pMaxRay, int *pMaxField, int *pMaxBin);

/* -----------------------------------------------------------------------------+
|   표준데이터포맷의 최대 관측 거리를 구한다.                                   |
|   파라미터                                                                    |
|       STD_RADAR* pStd : 표준데이터포맷의 메모리 포인터                        |
|   반환값                                                                      |
|       최대 관측거리 ( KM )                                                    |
+----------------------------------------------------------------------------- */
float fnGetMaxRangeStd(STD_RADAR *pStd);

/* -----------------------------------------------------------------------------+
|   UF 데이터를 표준데이터 포맷으로 변환한다.                                   |
|   변환 후 UF의 BIN 데이터는 NULL로 변경된다.                                  |
|   파라미터                                                                    |
|       UF_RADAR *pUf   : UF 데이터 메모리 포인터                               |
|   반환값                                                                      |
|       표준데이터포맷 메모리 포인터 or NULL                                    |
|       메모리를 할당하기 때문에 fnFreeStdRadar를 호출하여 해제해야 한다.       |
+----------------------------------------------------------------------------- */
STD_RADAR* fnUfSyncUpStd(UF_RADAR *pUf);

/* -----------------------------------------------------------------------------+
|   HDF 데이터를 표준데이터 포맷으로 변환한다.                                  |
|   파라미터                                                                    |
|       HDF_RADAR *pHdf : HDF 데이터 메모리 포인터                              |
|   반환값                                                                      |
|       표준데이터포맷 메모리 포인터 or NULL                                    |
|       메모리를 할당하기 때문에 fnFreeStdRadar를 호출하여 해제해야 한다.       |
+----------------------------------------------------------------------------- */
STD_RADAR* fnHdfSyncUpStd(HDF_RADAR *pHdf);

/* -----------------------------------------------------------------------------+
|   NC 데이터를 표준데이터 포맷으로 변환한다.                                   |
|   파라미터                                                                    |
|       NC_RADAR *pNc   : NC 데이터 메모리 포인터                               |
|   반환값                                                                      |
|       표준데이터포맷 메모리 포인터 or NULL                                    |
|       메모리를 할당하기 때문에 fnFreeStdRadar를 호출하여 해제해야 한다.       |
+----------------------------------------------------------------------------- */
STD_RADAR* fnNcSyncUpStd(NC_RADAR *pNc);

/* -----------------------------------------------------------------------------+
|   HDF 프로덕트포맷을 표준데이터 포맷으로 변환한다.                            |
|   변환후 HDF의 데이터는 NULL로 변화된다. ( 메모리 사용량문제로 수정 )         |
|   파라미터                                                                    |
|       HDF_PRODUCT *pHdfProduct : HDF 프로덕트포맷 메모리 포인터               |
|   반환값                                                                      |
|       표준데이터포맷 메모리 포인터 or NULL                                    |
|       메모리를 할당하기 때문에 fnFreeStdProduct를 호출하여 해제해야 한다.     |
+----------------------------------------------------------------------------- */
STD_PRODUCT* fnHdfProductSyncUpStd(HDF_PRODUCT *pHdfProduct);

/* -----------------------------------------------------------------------------+
|   BUFR 데이터를 표준데이터 포맷으로 변환한다.                                 |
|   파라미터                                                                    |
|       BUFR_RADAR *pBufr   : Bufr 데이터 메모리 포인터                         |
|   반환값                                                                      |
|       표준데이터포맷 메모리 포인터 or NULL                                    |
|       메모리를 할당하기 때문에 fnFreeStdRadar를 호출하여 해제해야 한다.       |
+----------------------------------------------------------------------------- */
STD_RADAR* fnBufrSyncUpStd(BUFR_RADAR *pBufr);

/* -----------------------------------------------------------------------------+
|   BUFR 프로덕트포맷을 표준데이터 포맷으로 변환한다.                           |
|   변환후 HDF의 데이터는 NULL로 변화된다. ( 메모리 사용량문제로 수정 )         |
|   파라미터                                                                    |
|       BUFR_PRODUCT *pBufrProduct  : BUFR 프로덕트포맷 메모리 포인터           |
|   반환값                                                                      |
|       표준데이터포맷 메모리 포인터 or NULL                                    |
|       메모리를 할당하기 때문에 fnFreeStdProduct를 호출하여 해제해야 한다.     |
+----------------------------------------------------------------------------- */
STD_PRODUCT* fnBufrProductSyncUpStd(BUFR_PRODUCT *pBufrProduct);

/* -----------------------------------------------------------------------------+
|   GRIB 데이터를 표준데이터 포맷으로 변환한다.                                 |
|   파라미터                                                                    |
|       GRIB_RADAR *pGrib   : GRIB 데이터 메모리 포인터                         |
|   반환값                                                                      |
|       표준데이터포맷 메모리 포인터 or NULL                                    |
|       메모리를 할당하기 때문에 fnFreeStdRadar를 호출하여 해제해야 한다.       |
+----------------------------------------------------------------------------- */
STD_RADAR* fnGribSyncUpStd(GRIB_RADAR *pGrib);

/* -----------------------------------------------------------------------------+
|   GRIB 프로덕트포맷을 표준데이터 포맷으로 변환한다.                           |
|   변환후 GRIB의 데이터는 NULL로 변화된다. ( 메모리 사용량문제로 수정 )        |
|   파라미터                                                                    |
|       GRIB_PRODUCT *pGribProduct  : GRIB 프로덕트포맷 메모리 포인터           |
|   반환값                                                                      |
|       표준데이터포맷 메모리 포인터 or NULL                                    |
|       메모리를 할당하기 때문에 fnFreeStdProduct를 호출하여 해제해야 한다.     |
+----------------------------------------------------------------------------- */
STD_PRODUCT* fnGribProductSyncUpStd(GRIB_PRODUCT *pGribProduct);

/* -----------------------------------------------------------------------------+
|   표준데이터 포맷의 모든 RAY의 방위각을 변경한다.                             |
|   파라미터                                                                    |
|       STD_RADAR   *pStd   : 표준데이터 포맷 메모리 포인터                     |
|       float fAzimCor      : 방위각 보정치                                     |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnStdRadarAzimuthCorrection(STD_RADAR *pStd, float fAzimCor);

/* ================================================================================ */
// Output Function

/* -----------------------------------------------------------------------------+
|   표준프로덕트포맷의 메모리를 초기화 한다.                                    |
|   파라미터                                                                    |
|       int iMaxField   : 총 moment의 수                                        |
|       int iMaxPpi     : 총 PPI의 수                                           |
|       int iMaxCappi   : 총 CAPPI의 수                                         |
|       int iMaxBase    : 총 BASE의 수                                          |
|       int iMaxCmax    : 총 CMAX의 수                                          |
|       int iMaxVil     : 총 VIL의 수                                           |
|       int iMaxEtop    : 총 ETOP의 수                                          |
|   반환값                                                                      |
|       표준프로덕트포맷 메모리 포인터 or NULL                                  |
|       메모리를 할당하기 때문에 fnFreeStdProduct를 호출하여 해제해야 한다.     |
+----------------------------------------------------------------------------- */
STD_PRODUCT* fnInitStdProduct(int iMaxField, int iMaxPpi, int iMaxCappi, int iMaxBase, int iMaxCmax, int iMaxVil, int iMaxEtop);

/* -----------------------------------------------------------------------------+
|	표준프로덕트포맷의 메모리 할당 해제 함수                                    |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct  : 표준프로덕트포맷의 메모리 포인터            |
+----------------------------------------------------------------------------- */
void fnFreeStdProduct(STD_PRODUCT *pStdProduct);

/* -----------------------------------------------------------------------------+
|	표준프로덕트포맷의 프로덕트 사이트 헤더를 세팅한다.                         |
|   파라미터                                                                    |
|       STD_RADAR *pStd             : 표준데이터포맷 메모리 포인터              |
|       STD_PRODUCT *pStdProduct    : 표준프로덕트포맷의 메모리 포인터          |
|       int iYdim                   : Ydim 사이즈                               |
|       int iXdim                   : Xdim 사이즈                               |
|       float fGridKm               : Grid 사이즈 ( km )                        |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnSetStdProductSiteHdr(STD_RADAR *pStd, STD_PRODUCT *pStdProduct, int iYdim, int iXdim, float fGridKm);

/* -----------------------------------------------------------------------------+
|	표준프로덕트포맷의 프로덕트 합성 헤더를 세팅한다.                           |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct    : 표준프로덕트포맷의 메모리 포인터          |
|       char* szCompMethod          : 합성 방법 ( "MAX", "AVE" ... )            |
|       char *szDateTime            : 합성 기준 시간                            |
|       int iYdim                   : Ydim 사이즈                               |
|       int iXdim                   : Xdim 사이즈                               |
|       float fGridKm               : Grid 사이즈 ( km )                        |
|       int iXo                     : Lampbert XO                               |
|       int iYo                     : Lampbert YO                               |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnSetStdProductCompHdr(STD_PRODUCT *pStdProduct, char* szCompMethod, char *szDateTime, int iYdim, int iXdim, float fGridKm, int iXo, int iYo);

/* -----------------------------------------------------------------------------+
|	표준 프로덕트 포맷에서 해당 프로덕트, 인덱스, moment에 해당하는 데이터를    |
|   찯는다.                                                                     |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char *szProduct             : 산출물 ( "PPI", "CAPPI",... )             |
|       int iProductIdx             : 프로덕트의 인덱스                         |
|       char *szFieldName           : moment 이름 ( "DZ", "CZ", ... )           |
|   반환값                                                                      |
|       2차원 float 배열 포인터 or NULL                                         |
|       2차원 float 배열을 할당하여 반환하기 때문에 해제 해야 한다.             |
+----------------------------------------------------------------------------- */
float** fnGetStdProductDataByIdx(STD_PRODUCT *pStdProduct, char *szProduct, int iProductIdx, char *szFieldName);

/* -----------------------------------------------------------------------------+
|	표준 프로덕트 포맷에서 해당 프로덕트, 인덱스에 해당 하는 반사도 데이터를    |
|   찯는다. ( CZ를 확인한후 DZ를 확인 )                                         |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char *szProduct             : 산출물 ( "PPI", "CAPPI",... )             |
|       int iProductIdx             : 프로덕트의 인덱스                         |
|   반환값                                                                      |
|       2차원 float 배열 포인터 or NULL                                         |
|       2차원 float 배열을 할당하여 반환하기 때문에 해제 해야 한다.             |
+----------------------------------------------------------------------------- */
float** fnGetStdProductDataByIdxDBZ(STD_PRODUCT *pStdProduct, char *szProduct, int iProductIdx);

/* -----------------------------------------------------------------------------+
|	표준 프로덕트 포맷에서 해당 프로덕트, 파라미터, moment에 해당하는 데이터를  |
|   찯는다.                                                                     |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char *szProduct             : 산출물 ( "PPI", "CAPPI",... )             |
|       double dProductArg1         : 프로덕트의 첫번째 파라미터                |
|       double dProductArg2         : 프로덕트의 두번째 파라미터                |
|       char *szFieldName           : moment 이름 ( "DZ", "CZ", ... )           |
|   반환값                                                                      |
|       2차원 float 배열 포인터 or NULL                                         |
|       2차원 float 배열을 할당하여 반환하기 때문에 해제 해야 한다.             |
+----------------------------------------------------------------------------- */
float** fnGetStdProductDataByArg(STD_PRODUCT *pStdProduct, char *szProduct, double dProductArg1, double dProductArg2, char *szFieldName);

/* -----------------------------------------------------------------------------+
|	표준 프로덕트 포맷에서 해당 프로덕트, 파라미터에 해당하는 데이터를          |
|   찯는다. ( CZ를 확인후 DZ를 확인 )                                           |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char *szProduct             : 산출물 ( "PPI", "CAPPI",... )             |
|       double dProductArg1         : 프로덕트의 첫번째 파라미터                |
|       double dProductArg2         : 프로덕트의 두번째 파라미터                |
|   반환값                                                                      |
|       2차원 float 배열 포인터 or NULL                                         |
|       2차원 float 배열을 할당하여 반환하기 때문에 해제 해야 한다.             |
+----------------------------------------------------------------------------- */
float** fnGetStdProductDataByArgDBZ(STD_PRODUCT *pStdProduct, char *szProduct, double dProductArg1, double dProductArg2);

/* -----------------------------------------------------------------------------+
|	표준프로덕트포맷에 산출물 데이터를 입력한다.                                |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct    : 표준프로덕트포맷의 메모리 포인터          |
|       char *szProduct             : 산출물 이름 ( "PPI", "CAPPI", ... )       |
|       int iProductIdx             : 산출물내의 Index ( 0번 PPI, 1번 PPI ... ) |
|       double dProductArg1         : 산출물의 파라미터                         |
|                                     ( PPI : 고도각,    CAPPI : 높이,          |
|                                       VIL : 상위 높이, ETOP  : 최저값 )       |
|       double dProductArg2         : VIL일때 하위 높이                         |
|       char *szFieldName           : 산출물의 Moment ( "DZ", "CZ"              |
|       float *pData                : 산출물의 1차원 배열                       |
|       int iYdim                   : Ydim 사이즈                               |
|       int iXdim                   : Xdim 사이즈                               |
|       float fGridKm               : Grid 사이즈 ( km )                        |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnAddStdProductToData(STD_PRODUCT *pStdProduct, char *szProduct, int iProductIdx, double dProductArg1, double dProductArg2, char *szFieldName, float *pData, int iYdim, int iXdim);

/* -----------------------------------------------------------------------------+
|   표준데이터 포맷을 HDF 포맷으로 변환한다.                                    |
|   파라미터                                                                    |
|       STD_RADAR *pStd : 표준데이터 메모리 포인터                              |
|   반환값                                                                      |
|       HDF 데이터포맷 메모리 포인터 or NULL                                    |
|       메모리를 할당하기 때문에 fnFreeHdfRadar를 호출하여 해제해야 한다.       |
+----------------------------------------------------------------------------- */
HDF_RADAR* fnStdSyncDownHdf(STD_RADAR *pStd);

/* -----------------------------------------------------------------------------+
|   표준프로덕트포맷을 HDF프로덕트포맷으로 변환한다.                            |
|   변환후 표준프로덕트포맷의 데이터 배열은 NULL이 된다.                        |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct  : 표준프로덕트포맷 메모리 포인터              |
|   반환값                                                                      |
|       HDF프로덕트포맷 메모리 포인터 or NULL                                   |
|       메모리를 할당하기 때문에 fnFreeHdfProduct를 호출하여 해제해야 한다.     |
+----------------------------------------------------------------------------- */
HDF_PRODUCT* fnStdProductSyncDownHdf(STD_PRODUCT *pStdProduct);

/* -----------------------------------------------------------------------------+
|   표준프로덕트포맷을 BUFR프로덕트포맷으로 변환한다.                           |
|   변환후 표준프로덕트포맷의 데이터 배열은 NULL이 된다.                        |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct  : 표준프로덕트포맷 메모리 포인터              |
|   반환값                                                                      |
|       BUFR프로덕트포맷 메모리 포인터 or NULL                                  |
|       메모리를 할당하기 때문에 fnFreeBufrProduct를 호출하여 해제해야 한다.    |
+----------------------------------------------------------------------------- */
BUFR_PRODUCT* fnStdProductSyncDownBufr(STD_PRODUCT *pStdProduct);

/* -----------------------------------------------------------------------------+
|   표준프로덕트포맷을 GRIB프로덕트포맷으로 변환한다.                           |
|   변환후 표준프로덕트포맷의 데이터 배열은 NULL이 된다.                        |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct  : 표준프로덕트포맷 메모리 포인터              |
|   반환값                                                                      |
|       GRIB프로덕트포맷 메모리 포인터 or NULL                                  |
|       메모리를 할당하기 때문에 fnFreeGribProduct를 호출하여 해제해야 한다.    |
+----------------------------------------------------------------------------- */
GRIB_PRODUCT* fnStdProductSyncDownGrib(STD_PRODUCT *pStdProduct);

/* -----------------------------------------------------------------------------+
|   표준프로덕트포맷에서 산출물별 파라미터를 가져온다.                          |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct    : 표준프로덕트포맷 메모리 포인터            |
|       char *szProduct             : 산출물 이름 ( "PPI", "CAPPI",... )        |
|       int iProuductIdx            : 산출물 인덱스                             |
|       double *pProductArg1        : 첫번째 파라미터 저장 변수                 |
|       double *pProductArg2        : 두번째 파라미터 저장 변수                 |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnGetStdProductProdpar(STD_PRODUCT *pStdProduct, char *szProduct, int iProductIdx, double *pProductArg1, double *pProductArg2);

/* ================================================================================ */
// Util Function

/* -----------------------------------------------------------------------------+
|   Sweep의 Ray를 Hash 하기 위한 Hash 함수                                      |
|   파라미터                                                                    |
|       float fRes      : Ray의 각도 ( 360 / ray의 수 )                         |
|       float fAzimuth  : Ray의 방위각                                          |
|   반환값                                                                      |
|       Hash Value                                                              |
+----------------------------------------------------------------------------- */
int fnGetRayHashIndex(float fRes, float fAzimuth);

/* -----------------------------------------------------------------------------+
|   Sweep 에서 Ray를 방위각으로 Hash하기 위한 테이블을 생성한다.                |
|   파라미터                                                                    |
|       STD_SWEEP *pSweep       : Sweep의 메모리 포인터                         |
|   반환값                                                                      |
|       Hash Table 메모리 포인터 or NULL                                        |
|       메모리를 할당하여 반환 하기 때문에 free 해야 한다.                      |
+----------------------------------------------------------------------------- */
STD_AZIMUTH_TBL* fnMakeRayHashTable(STD_SWEEP *pSweep);

/* -----------------------------------------------------------------------------+
|   전체 Sweep에 해당하는 Hash 테이블을 생성한다.                               |
|   파라미터                                                                    |
|       STD_RADAR *pStd             : 표준데이터포맷 메모리 포인터              |
|   반환값                                                                      |
|       전체 Sweep Hash Table 메모리 포인터 or NULL                             |
|       메모리를 할당하기 때문에 메모리를 해제 해야 한다.                       |
+----------------------------------------------------------------------------- */
STD_AZIMUTH_TBL** fnMakeAllHashTable(STD_RADAR *pStd);

/* -----------------------------------------------------------------------------+
|   Sweep 에서 입력 방위각에 가까운 Ray를 찾는다.                               |
|   파라미터                                                                    |
|       STD_SWEEP *pSweep       : Sweep 메모리 포인터                           |
|       STD_AZIMUTH_TBL *pTable : Hash Table 배열 포인터                        |
|       int iHashIdx            : Hash Index                                    |
|       float fAzimuth          : 방위각                                        |
|   반환값                                                                      |
|       Ray Index or -1                                                         |
+----------------------------------------------------------------------------- */
int fnTheClosestRay(STD_SWEEP *pSweep, STD_AZIMUTH_TBL *pTable, int iHashIdx, float fAzimuth);

/* -----------------------------------------------------------------------------+
|   Ray에서 Moment에 해당하는 Field의 Index를 구한다.                           |
|   파라미터                                                                    |
|       STD_RAY *pRay       : Ray 메모리 포인터                                 |
|       char *szFieldName   : Moment 문자열                                     |
|   반환값                                                                      |
|       Field index or -1                                                       |
+----------------------------------------------------------------------------- */
int fnGetFieldIdxRay(STD_RAY *pRay, char *szFieldName);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷에서 입력 산출물에 해당하는 DATASET 및 개수를 찾는다.     |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char *szProduct             : 프로덕트 ( "PPI", "CAPPI", ... )          |
|       int *pMaxDset               : 데이터셋의 수를 저장할 버퍼               |
|   반환값                                                                      |
|       프로덕트의 전체 데이터셋 포인터 or NULL                                 |
|       표준 프로덕트 내부 멤버의 포인터를 반환한다.                            |
+----------------------------------------------------------------------------- */
STD_PRODUCT_DATASET** fnFindDsetStdProduct(STD_PRODUCT *pStdProduct, char *szProduct, int *pMaxDset);

/* ================================================================================ */

#endif

