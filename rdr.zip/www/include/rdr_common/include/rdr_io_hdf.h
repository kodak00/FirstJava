/* ================================================================================ */
//
// Radar HDF Format & Function
//
// 2016.08.19 SnK 
//
/* ================================================================================ */

#ifndef RDR_IO_HDF_H
#define RDR_IO_HDF_H

/* ================================================================================ */
// Define

#define RDR_DF_HDF_PRODUCT_MAX          (100)
#define RDR_DF_HDF_OBJECT_MAX           (100)
#define RDR_DF_HDF_OBEJCT_LEN           (128)

#define RDR_DF_HDF_ATTR_MAX             (100)
#define RDR_DF_HDF_ATTR_LEN             (128)

#define RDR_DF_HDF_STR_MAX              (255)

#define RDR_DF_HDF_CONVENTIONS_STR      "ODIM_H5/V2_2"
#define RDR_DF_HDF_VERSION_STR          "H5rad 1.0"
#define RDR_DF_HDF_DATA_CLASS_STR       "IMAGE"
#define RDR_DF_HDF_DATA_VERSION_STR     "1.2"

#define RDR_DF_HDF_MAX_ANGLES           (20)
#define RDR_DF_HDF_MAX_RAYS             (600)

#define RDR_DF_HDF_COMP_MAX_SITES       (100)

#define RDR_DF_HDF_NODATA               (32767)

/* ================================================================================ */
// Enum

typedef enum
{
    HDF_EN_PRODUCT_SITE = 1,
    HDF_EN_PRODUCT_COMP
} HDF_EN_PRODUCT_TYPE;

typedef enum
{
    HDF_EN_R_TYPE_POLAR = 1,
    HDF_EN_R_TYPE_IMAGE,
    HDF_EN_R_TYPE_CROSS,
    HDF_EN_R_TYPE_VERTICAL,
} HDF_EN_RADAR_TYPE;

/* ================================================================================ */
// Union



/* ================================================================================ */
// Struct

typedef struct
{
    char                m_szObject[6+1];
    char                m_szVersion[10+1];
    char                m_szDate[8+1];
    char                m_szTime[6+1];
    char                m_szSource[RDR_DF_HDF_STR_MAX+1];
} HDF_TOP_WHAT;

typedef struct
{
    double              m_dLon;
    double              m_dLat;
    double              m_dHeightM;
    // Datsset 
    double              m_dElangle;
    long                m_nBins;
    double              m_dRstart;
    double              m_dRScale;
    long                m_nRays;
    long                m_lA1gate;
    // Sector
    double              m_dStartAz;
    double              m_dStopAz;
} HDF_POLAR_WHERE;

typedef struct
{
    // DATASET
    char                m_szProduct[6+1];
    double              m_dProdpar[2];
    char                m_szStartDate[8+1];
    char                m_szStartTime[6+1];
    char                m_szEndDate[8+1];
    char                m_szEndTime[6+1];
    // DATA
    char                m_szQuantity[6+1];
    double              m_dGain;
    double              m_dOffset;
    double              m_dNodata;
    double              m_dUndetect;
} HDF_DATASET_WHAT;

typedef struct
{
    char                m_szProjdef[RDR_DF_HDF_STR_MAX+1];
    long                m_lXsize;
    long                m_lYsize;
    double              m_dXscale;
    double              m_dYscale;
    double              m_LL_lon;
    double              m_LL_lat;
    double              m_UL_lon;
    double              m_UL_lat;
    double              m_UR_lon;
    double              m_UR_lat;
    double              m_LR_lon;
    double              m_LR_lat;
} HDF_IMAGE_WHERE;

typedef struct
{
    long                m_lXsize;
    long                m_lYsize;
    double              m_dXscale;
    double              m_dYscale;
    double              m_dMinHeightM;
    double              m_dMaxHeightM;
    // RHI
    double              m_dLon;
    double              m_dLat;
    double              m_dAz_angle;
    double              m_dAngles[RDR_DF_HDF_MAX_ANGLES];
    double              m_dRange;
    // CROSS
    double              m_dStart_lon;
    double              m_dStart_lat;
    double              m_dStop_lon;
    double              m_dStop_lat;
} HDF_CROSS_WHERE;

typedef struct
{
    double              m_dLon;
    double              m_dLat;
    double              m_dHeightM;
    long                m_lLevels;
    double              m_dInterval;
    double              m_dMinHeightM;
    double              m_dMaxHeightM;
} HDF_VERTICAL_WHERE;

typedef struct
{
    HDF_POLAR_WHERE     m_polar_where;
    HDF_IMAGE_WHERE     m_image_where;
    HDF_CROSS_WHERE     m_cross_where;
    HDF_VERTICAL_WHERE  m_vertical_where;
} HDF_WHERE;

typedef struct
{
    char                m_szTask[8+1];
    char                m_szTaskArg[RDR_DF_HDF_STR_MAX+1];
    double              m_dStartepochs;
    double              m_dEndepochs;
    char                m_szSystem[8+1];
    char                m_szTXtype[16+1];
    char                m_szPoltype[32+1];
    char                m_szPolmode[32+1];
    char                m_szSoftware[10+1];
    char                m_szSW_version[16+1];
    double              m_dZr_a;
    double              m_dZr_b;
    double              m_dKr_a;
    double              m_dKr_b;
    char                m_bSimulated[6+1];
} HDF_GENERAL_HOW;

typedef struct
{
    double              m_dBeamwidth;
    double              m_dWaveLength;
    double              m_dRpm;
    double              m_dElevsSpeed;
    double              m_dPulseWidth;
    double              m_dRXbandWidth;
    double              m_dLowPrf;
    double              m_dMidPrf;
    double              m_dHighPrf;
    double              m_dTXlossH;
    double              m_dTXlossV;
    double              m_dInjectlossH;
    double              m_dInjectlossV;
    double              m_dRXlossH;
    double              m_dRXlossV;
    double              m_dRadomelossH;
    double              m_dRadomelossV;
    double              m_dAntgainH;
    double              m_dAntgainV;
    double              m_dBeamwH;
    double              m_dBeamwV;
    double              m_dGasattn;
    double              m_dRadconstH;
    double              m_dRadconstV;
    double              m_dNomTXpower;
    double              m_dTXpower[RDR_DF_HDF_MAX_RAYS];
    double              m_dPowerDiff;
    double              m_dPhaseDiff;
    double              m_dNi;
    long                m_lVsamples;
} HDF_RADAR_HOW;

typedef struct
{
    long                m_lScan_index;
    long                m_lScan_count;
    double              m_dAstart;
    char                m_szAzmethod[16+1];
    char                m_szElmethod[16+1];
    char                m_szBinmethod[16+1];
    double              m_dElangles[RDR_DF_HDF_MAX_RAYS];
    double              m_dStartazA[RDR_DF_HDF_MAX_RAYS];
    double              m_dStopazA[RDR_DF_HDF_MAX_RAYS];
    double              m_dStartazT[RDR_DF_HDF_MAX_RAYS];
    double              m_dStopazT[RDR_DF_HDF_MAX_RAYS];
    double              m_dStartelA[RDR_DF_HDF_MAX_RAYS];
    double              m_dStopelA[RDR_DF_HDF_MAX_RAYS];
    double              m_dStartelT[RDR_DF_HDF_MAX_RAYS];
    double              m_dStopelT[RDR_DF_HDF_MAX_RAYS];
} HDF_POLAR_HOW;

typedef struct
{
    double              m_dAngles[RDR_DF_HDF_COMP_MAX_SITES];
    double              m_dArotation[RDR_DF_HDF_COMP_MAX_SITES];
    char                m_szCamethod[16+1];
    char                m_szNodes[RDR_DF_HDF_STR_MAX+1];
    long                m_lAccNum;
} HDF_IMAGE_HOW;

typedef struct
{
    double              m_dMinRangeKm;
    double              m_dMaxRangeKm;
    char                m_szDealiased[6+1];
} HDF_VERTICAL_HOW;

typedef struct
{
    double              m_dPointAccEl;
    double              m_dPointAccAZ;
    char                m_szAngleSync[16+1];
    double              m_dAnglesSyncRes;
    char                m_szMalfunc[6+1];
    char                m_szRadar_msg[RDR_DF_HDF_STR_MAX+1];
    double              m_dRadarHoriz;
    double              m_dNEZH;
    double              m_dNEZV;
    double              m_dOUR;
    char                m_szDclutter[RDR_DF_HDF_STR_MAX+1];
    char                m_szClutterType[RDR_DF_HDF_STR_MAX+1];
    char                m_szClutterMap[RDR_DF_HDF_STR_MAX+1];
    double              m_dZcalH;
    double              m_dZcalV;
    double              m_dNsampleH;
    double              m_dNsampleV;
    char                m_szComment[RDR_DF_HDF_STR_MAX+1];
    double              m_dSQI;
    double              m_dCSR;
    double              m_dLOG;
    char                m_szVPRCorr[6+1];
    double              m_dFreeze;
    double              m_dMin;
    double              m_dMax;
    double              m_dStep;
    long                m_lLevels;
    double              m_dPeakpwr;
    double              m_dAvgpwr;
    double              m_dDynrange;
    double              m_dRAC;
    char                m_szBBC[6+1];
    double              m_dPAC;
    double              m_dS2N;
    char                m_szPolarization[RDR_DF_HDF_STR_MAX+1];
} HDF_QUALITY_HOW;

typedef struct
{
    HDF_GENERAL_HOW     m_general_how;
    HDF_RADAR_HOW       m_radar_how;
    HDF_POLAR_HOW       m_polar_how;
    HDF_IMAGE_HOW       m_image_how;
    HDF_VERTICAL_HOW    m_vertical_how;
    HDF_QUALITY_HOW     m_quality_how;
} HDF_HOW;

/* -----------------------------------------------------------------------------+
|   HDF 입력 데이터 규격	                                                    |
+----------------------------------------------------------------------------- */

typedef struct
{
    HDF_DATASET_WHAT    m_what;
    HDF_WHERE           m_where;
    HDF_HOW             m_how;
    char                m_szClass[6+1];
    char                m_szVersion[4+1];
    float               **m_ppData;
} HDF_DATASET_QUALITY;

typedef struct
{
    HDF_DATASET_WHAT    m_what;
    HDF_WHERE           m_where;
    HDF_HOW             m_how;
    char                m_szClass[6+1];
    char                m_szVersion[4+1];
    float               **m_ppData;
} HDF_DATA_QUALITY;

typedef struct
{
    HDF_DATASET_WHAT    m_what;
    HDF_WHERE           m_where;
    HDF_HOW             m_how;
    char                m_szClass[6+1];
    char                m_szVersion[4+1];
    float               **m_ppData;
    int                 m_iMaxQuality;
    HDF_DATA_QUALITY    **m_ppQuality;
} HDF_DATA;

typedef struct
{
    HDF_DATASET_WHAT    m_what;
    HDF_WHERE           m_where;
    HDF_HOW             m_how;
    int                 m_iMaxData;
    int                 m_iMaxQuality;
    HDF_DATA            **m_ppData;
    HDF_DATASET_QUALITY **m_ppQuality;
} HDF_DATASET;

typedef struct
{
    int                 m_iHdfType;
    char                m_szConventions[16+1];
    HDF_TOP_WHAT        m_what;
    HDF_WHERE           m_where;
    HDF_HOW             m_how;
    int                 m_iMaxDataset;
    HDF_DATASET         **m_ppDataset;
} HDF_RADAR;

/* -----------------------------------------------------------------------------+
|   HDF 출력 데이터 규격	                                                    |
+----------------------------------------------------------------------------- */

typedef struct
{
    HDF_DATASET_WHAT    m_what;
    char                m_szFieldName[8+1];
    char                m_szClass[6+1];
    char                m_szVersion[4+1];
    int                 m_iMemType;
    char                **m_ppData_c;
    short               **m_ppData_s;
    float               **m_ppData_f;
} HDF_PRODUCT_DATA;

typedef struct
{
    HDF_DATASET_WHAT    m_what;
    int                 m_iMaxField;
    HDF_PRODUCT_DATA    **m_ppProductData;
} HDF_PRODUCT_DATASET;

typedef struct
{
    int                 m_iMaxPpi;
    int                 m_iMaxCappi;
    int                 m_iMaxBase;
    int                 m_iMaxCmax;
    int                 m_iMaxVil;
    int                 m_iMaxEtop;
    HDF_PRODUCT_DATASET **m_ppPpi;
    HDF_PRODUCT_DATASET **m_ppCappi;
    HDF_PRODUCT_DATASET **m_ppBase;
    HDF_PRODUCT_DATASET **m_ppCmax;
    HDF_PRODUCT_DATASET **m_ppVil;
    HDF_PRODUCT_DATASET **m_ppEtop;
} HDF_TOTAL_PRODUCT;

typedef struct
{
    int                 m_iHdfProductType;
    char                m_szConventions[16+1];
    HDF_TOP_WHAT        m_what;
    HDF_WHERE           m_where;
    HDF_HOW             m_how;
    HDF_TOTAL_PRODUCT   m_totalProduct;
} HDF_PRODUCT;

/* ================================================================================ */
// Input Function

/* -----------------------------------------------------------------------------+
|   HDF 메모리를 초기화 한다.                                                   |
|   파라미터                                                                    |
|       int iMaxDataset         : 최대 데이터셋의 수                            |
|       int iMaxData            : 최대 데이터의 수                              |
|       int iMaxDsetQuality     : 최대 데이터셋 퀄리티 데이터의 수              |
|       int int iMaxDataQuality : 최대 데이터의 퀄리트 데이터의 수              |
|   반환값                                                                      |
|       HDF 메모리 포인터 or NULL                                               |
|       메모리를 할당하기 때문에 fnFreeHdfRadar를 호출하여 해제해야 한다.       |
+----------------------------------------------------------------------------- */
HDF_RADAR* fnInitHdfRadar(int iMaxDataset, int iMaxData, int iMaxDsetQuality, int iMaxDataQuality);

/* -----------------------------------------------------------------------------+
|   HDF RADAR 파일을 읽는다.                                                    |
|   파라미터                                                                    |
|       char *szFile        : HDF 프로덕트 파일 전체 경로                       |
|       int iHdfType        : HDF 파일 종류 ( POLAR, IMAGE, .. )                |
|   반환값                                                                      |
|       HDF 메모리 포인터 or NULL                                               |
|       메모리를 할당하기 때문에 fnFreeHdfRadar를 호출하여 해제해야 한다.       |
+----------------------------------------------------------------------------- */
HDF_RADAR* fnLoadHdfRadar(char* szFile, int iHdfType);

/* -----------------------------------------------------------------------------+
|   HDF 데이터 메모리를 해제한다.                                               |
|   파라미터                                                                    |
|       HDF_RADAR *pHdf : HDF 메모리 포인터                                     |
+----------------------------------------------------------------------------- */
void fnFreeHdfRadar(HDF_RADAR *pHdf);

/* -----------------------------------------------------------------------------+
|   HDF 프로덕트 파일을 읽는다.                                                 |
|   파라미터                                                                    |
|       char *szFile        : HDF 프로덕트 파일 전체 경로                       |
|       char *szProduc      : 산출물의 종류 ( PPI,PCAPPI,BASE,MAX,VIL,ETOP )    |
|                             NULL이면 모든 산출물을 다 Load 한다.              |
|       char *szFieldName   : Moment 이름 ( DZ, VR, SW, CZ, DR, RH, PH, KD )    |
|                             NULL이면 모든 Moment를 다 Load 한다.              |
|   반환값                                                                      |
|       HDF 프로덕트포맷 메모리 포인터 or NULL                                  |
|       메모리를 할당하기 때문에 fnFreeHdfProduct를 호출하여 해제해야 한다.     |
+----------------------------------------------------------------------------- */
HDF_PRODUCT* fnLoadHdfProduct(char* szFile, char* szProduct, char* szFieldName);

/* -----------------------------------------------------------------------------+
|   HDF 프로덕트 파일을 읽는다.                                                 |
|   입력된 프로덕트를 해당 개수만큼 읽는다.                                     |
|   파라미터                                                                    |
|       char *szFile        : HDF 프로덕트 파일 전체 경로                       |
|       char *szProduc      : 산출물의 종류 ( PPI,PCAPPI,BASE,MAX,VIL,ETOP )    |
|       int iProductMax     : 읽을 산출물의 INDEX                               |
|       char *szFieldName   : Moment 이름 ( DZ, VR, SW, CZ, DR, RH, PH, KD )    |
|                             NULL이면 모든 Moment를 다 Load 한다.              |
|   반환값                                                                      |
|       HDF 프로덕트포맷 메모리 포인터 or NULL                                  |
|       메모리를 할당하기 때문에 fnFreeHdfProduct를 호출하여 해제해야 한다.     |
+----------------------------------------------------------------------------- */
HDF_PRODUCT* fnLoadHdfProductByIdx(char *szFile, char *szProduct, int iProductIdx, char *szFieldName);

/* -----------------------------------------------------------------------------+
|   HDF 프로덕트 파일을 읽는다.                                                 |
|   입력된 프로덕트의 파라미터(CAPPI:height...)에 해당하는 것만 읽는다.         |
|   파라미터                                                                    |
|       char *szFile        : HDF 프로덕트 파일 전체 경로                       |
|       char *szProduc      : 산출물의 종류 ( PPI,PCAPPI,BASE,MAX,VIL,ETOP )    |
|       double dProductArg1 : 첫번째 파라미터                                   |
|       double dProductArg2 : 두번째 파라미터                                   |
|       char *szFieldName   : Moment 이름 ( DZ, VR, SW, CZ, DR, RH, PH, KD )    |
|                             NULL이면 모든 Moment를 다 Load 한다.              |
|   반환값                                                                      |
|       HDF 프로덕트포맷 메모리 포인터 or NULL                                  |
|       메모리를 할당하기 때문에 fnFreeHdfProduct를 호출하여 해제해야 한다.     |
+----------------------------------------------------------------------------- */
HDF_PRODUCT* fnLoadHdfProductByArg(char *szFile, char *szProduct, double dProductArg1, double dProductArg2, char *szFieldName);

/* ================================================================================ */
// Output Function

/* -----------------------------------------------------------------------------+
|   HDF 프로덕트포맷 메모리를 초기화 한다.                                      |
|   파라미터                                                                    |
|       int iMaxField   : 총 moment의 수                                        |
|       int iMaxPpi     : 총 PPI의 수                                           |
|       int iMaxCappi   : 총 CAPPI의 수                                         |
|       int iMaxBase    : 총 BASE의 수                                          |
|       int iMaxCmax    : 총 CMAX의 수                                          |
|       int iMaxVil     : 총 VIL의 수                                           |
|       int iMaxEtop    : 총 ETOP의 수                                          |
|   반환값                                                                      |
|       HDF 프로덕트포맷 메모리 포인터 or NULL                                  |
|       메모리를 할당하기 때문에 fnFreeHdfProduct를 호출하여 해제해야 한다.     |
+----------------------------------------------------------------------------- */
HDF_PRODUCT* fnInitHdfProduct(int iMaxField, int iMaxPpi, int iMaxCappi, int iMaxBase, int iMaxCmax, int iMaxVil, int iMaxEtop);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷을 확인하여 HDF 프로덕트 포맷을 초기화한다.               |
|   파라미터                                                                    |
|       void    *pStdPtr: 표준 프로덕트 포멧 메모리 포인터                      |
|                         함수 내부에서 캐스팅한다.                             |
|   반환값                                                                      |
|       HDF 출력포맷 메모리 포인터 or NULL                                      |
|       메모리를 할당하기 때문에 fnFreeHdfProduct를 호출하여 해제해야 한다.     |
+----------------------------------------------------------------------------- */
HDF_PRODUCT* fnInitHdfProductToStdProduct(void *pStdPtr);

/* -----------------------------------------------------------------------------+
|   HDF 프로덕트 메모리를 해제 한다.                                            |
|   파라미터                                                                    |
|       HDF_PRODUCT *pHdfProduct   : Hdf 프로덕트포맷의 메모리 포인터           |
+----------------------------------------------------------------------------- */
void fnFreeHdfProduct(HDF_PRODUCT *pHdfProduct);

/* -----------------------------------------------------------------------------+
|   HDF 프로덕트 포맷을 파일로 저장한다.                                        |
|   파라미터                                                                    |
|       HDF_PRODUCT *pHdfProduct    : Hdf 프로덕트포맷의 메모리 포인터          |
|       char        *szFileName     : 저장 파일의 전체 경로 및 이름             |       
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnWriteHdfProduct(HDF_PRODUCT *pHdfProduct, char *szFileName);

/* -----------------------------------------------------------------------------+
|   HDF 포맷을 파일로 저장한다.                                                 |
|   파라미터                                                                    |
|       HDF_RADAR   *pHdf       : Hdf 포맷의 메모리 포인터                      |
|       char        *szFileName : 저장 파일의 전체 경로 및 이름                 |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnWriteHdfRadar(HDF_RADAR *pHdf, char *szFileName);

/* -----------------------------------------------------------------------------+
|   HDF 프로덕트 포맷의 각 산출물 및 Moment의 최대 개수를 구한다.               |
|   파라미터                                                                    |
|       HDF_PRODUCT *pHdfProduct    : HDF 프로덕트 포맷 메모리 포인터           |
|       int *pMaxField              : Moment 개수 버퍼 포인터                   |
|       int *pMaxPpi                : PPI    개수 버퍼 포인터                   |
|       int *pMaxCappi              : CAPPI  개수 버퍼 포인터                   |
|       int *pMaxBase               : BASE   개수 버퍼 포인터                   |
|       int *pMaxCmax               : CMAX   개수 버퍼 포인터                   |
|       int *pMaxVil                : VIL    개수 버퍼 포인터                   |
|       int *pMaxEtop               : ETOP   개수 버퍼 포인터                   |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnGetMaxCountHdfProduct(HDF_PRODUCT *pHdfProduct, int *pMaxField, int *pMaxPpi, int *pMaxCappi, int *pMaxBase, int *pMaxCmax, int *pMaxVil, int *pMaxEtop);

/* -----------------------------------------------------------------------------+
|   HDF  포맷의 최대 개수를 구한다.                                             |
|   파라미터                                                                    |
|       HDF_RADAR   *pHdf   : HDF 프로덕트 포맷 메모리 포인터                   |
|       int *pMaxDataset    : 데이터셋 개수 버퍼 포인터                         |
|       int *pMaxData       : 데이터   개수 버퍼 포인터                         |
|       int *pMaxRay        : Ray      개수 버퍼 포인터                         |
|       int *pMaxbin        : Bin      개수 버퍼 포인터                         |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnGetMaxCountHdfRadar(HDF_RADAR *pHdf, int *pMaxDataset, int *pMaxData, int *pMaxRay, int *pMaxBin);

/* ================================================================================ */

#endif


