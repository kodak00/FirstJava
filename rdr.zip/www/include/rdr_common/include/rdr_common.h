/* ================================================================================ */
//
// Radar Common Header
//
// 2016.08.05 SnK 
//
/* ================================================================================ */

#ifndef RDR_COMMON_H
#define RDR_COMMON_H

#include "unp.h"

/* ================================================================================ */
// Define

#define     RDR_DF_APP_ROOT_PATH    "/rdr/www/cgi-src"

#define     TRUE                    (1)
#define     FALSE                   (0)
#define     RDR_DF_TRUE             (TRUE)
#define     RDR_DF_FALSE            (FALSE)

#define     LOOP_CNT_MAX            (1000000)
#define     RDR_DF_LOOP_CNT_MAX     (LOOP_CNT_MAX)
#define     STR_LENGTH_MAX          (1024)

#define     RDR_DF_MAX_SWEEP        (20)
#define     RDR_DF_MAX_RAY          (1000)
#define     RDR_DF_MAX_FIELD        (15)
#define     RDR_DF_MAX_BIN          (2500)

#define     RDR_DF_PI_DFS           (3.141592)

#define     RDR_DF_OUT_BOUND_C      (-128)
#define     RDR_DF_BAD_VALUE_C      (-127)

#define     RDR_DF_OUT_BOUND_S      (-32768)
#define     RDR_DF_BAD_VALUE_S      (-32767)

#define     RDR_DF_OUT_BOUND_F      (-9998.)
#define     RDR_DF_BAD_VALUE_F      (-9999.)

#define     RDR_DF_ERR_RANGE_F      (.000001)
#define     RDR_DF_ERR_RANGE_D      (.000000000000001)

#define     RDR_DF_DFLT_ZR_A        (200.)
#define     RDR_DF_DFLT_ZR_B        (1.6)

#define     RDR_DF_SHORT_SCALE      (100)
#define     RDR_DF_SPEED_OF_LIGHT   (299792458.0) /* m/s */

/* ================================================================================ */
// Enum

typedef enum
{
    RDR_EN_MEM_CHAR = 1,
    RDR_EN_MEM_SHORT,
    RDR_EN_MEM_FLOAT
} STD_EN_MEM_TYPE;

typedef enum
{
    RDR_EN_OUT_BOUND  = 0,
    RDR_EN_IN_BOUND,
    RDR_EN_RADAR_POSITION
} RDR_EN_BOUND_VALUE;

/* ================================================================================ */

// #define _XOPEN_SOURCE 의 영향이 정확하지 않아 proto-type 추가
char *strptime(const char *s, const char *format, struct tm *tm);

/* ================================================================================ */

#endif
