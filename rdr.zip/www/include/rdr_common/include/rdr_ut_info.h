/* ================================================================================ */
//
// Radar About Infomation Header ( Fixed Information )
//
// 2016.08.25 SnK 
//
/* ================================================================================ */

#ifndef RDR_UT_INFO_H
#define RDR_UT_INFO_H

/* ================================================================================ */
// Define

#define RDR_DF_IMG_GRID_AUTO    (0.0)

/* ================================================================================ */
// Enum



/* ================================================================================ */
// Struct

// 각 포맷별 산출물의 정보
typedef struct
{
    char                m_szStdProduct[6+1];
    char                m_szHdfProduct[6+1];
    char                m_szBufrProduct[6+1];
    char                m_szGribProduct[6+1];
} PRODUCT_INFO_TBL;

// 각 포멧별 합성방법의 정보
typedef struct
{
    char                m_szStdCompMethod[16+1];
    char                m_szHdfCompMethod[16+1];
    char                m_szBufrCompMethod[16+1];
    char                m_szGribCompMethod[16+1];
} COMP_INFO_TBL;

// STD PROUDCT 각 변수별 메모리 정보
typedef struct
{
    char                m_szFieldName[8+1];
    int                 m_iMemType;
    float               m_fScale;
    float               m_fOffset;
    float               m_fBadValue;
    float               m_fOutBound;
} FIELD_MEM_INFO_TBL;

// FIELD 저장 정보
typedef struct
{
    char                m_szFieldName[6+1];
    char                m_szHdfQuantity[6+1];
    char                m_szBufrQuantity[6+1];
    char                m_szNcMoment[6+1];
    char                m_szGribQuantity[6+1];
} FIELD_INFO_TBL;

// 각 산출물, MOMENT 별 Color 정보
typedef struct
{
    char                m_szFieldName[8+1];
    char                m_szColorFIle[256];
    char                m_szDispFormat[10];
    int                 m_iColorKind;
    float               m_fMinValue;
} RDR_DISP_INFO_TBL;

// 각 종류별 이미지 사이즈 정보
typedef struct
{
    char                m_szImgKind[16];
    int                 m_iTopHeight;
    int                 m_iRightWidth;
    int                 m_iBottomHeight;
    int                 m_iImgYdim;
    int                 m_iImgXdim;
    int                 m_iImgGridKm;
    int                 m_iCompOrgX;  // 합성장 지도의 원점 X 변경 위치
    int                 m_iCompOrgY;  // 합성장 지도의 원점 Y 변경 위치
    int                 m_iMinDiffType;
    int                 m_iEchoDIffType;
} RDR_IMG_INFO_TBL;

/* ================================================================================ */
// Function

/* -----------------------------------------------------------------------------+
|   moment 이름으로 표준프로덕트포맷의 메모리 종류 및 스케일을 가져온다.        |
|   파라미터                                                                    |
|       char *szFieldName           : moment 이름                               |
|       STD_PRODUCT_INFO_TBL *pBuf  : 정보를 저장할 버퍼                        |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
|       기본값은 FLOAT 이다.                                                    |
+----------------------------------------------------------------------------- */
int fnGetFieldMemInfo(char *szFieldName, FIELD_MEM_INFO_TBL *pBuf);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트포맷의 산출물 이름으로                                         |
|   각 데이터규격마다의 산출물 정보를 가져온다.                                 |
|   파라미터                                                                    |
|       char *szProduct         : 산출물의 이름 ( PPI,CAPPI,BASE,CMAX,VIL,ETOP )|
|       PRODUCT_INFO_TBL *pBuf  : 정보를 저장할 버퍼                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnGetStdProductInfo(char *szProduct, PRODUCT_INFO_TBL *pBuf);

/* -----------------------------------------------------------------------------+
|   HDF 프로덕트포맷의 산출물 이름으로                                          |
|   표준 프로덕트포맷의 산출물 정보를 가져온다.                                 |
|   파라미터                                                                    |
|       char *szProduct         : 산출물의 이름 ( PPI,PCAPPI,BASE,MAX,VIL,ETOP )|
|       PRODUCT_INFO_TBL *pBuf  : 정보를 저장할 버퍼                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnGetHdfProductInfo(char *szProduct, PRODUCT_INFO_TBL *pBuf);

/* -----------------------------------------------------------------------------+
|   BUFR 프로덕트포맷의 산출물 이름으로                                         |
|   표준 프로덕트포맷의 산출물 정보를 가져온다.                                 |
|   파라미터                                                                    |
|       char *szProduct         : 산출물의 이름 ( PPI,PCAPPI,BASE,MAX,VIL,ETOP )|
|       PRODUCT_INFO_TBL *pBuf  : 정보를 저장할 버퍼                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnGetBufrProductInfo(char *szProduct, PRODUCT_INFO_TBL *pBuf);

/* -----------------------------------------------------------------------------+
|   GRIB 프로덕트포맷의 산출물 이름으로                                         |
|   표준 프로덕트포맷의 산출물 정보를 가져온다.                                 |
|   파라미터                                                                    |
|       char *szProduct         : 산출물의 이름 ( PPI,CAPPI,BASE,MAX,VIL,ETOP ) |
|       PRODUCT_INFO_TBL *pBuf  : 정보를 저장할 버퍼                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnGetGribProductInfo(char *szProduct, PRODUCT_INFO_TBL *pBuf);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트포맷의 합성 이름으로                                           |
|   각 데이터규격마다의 합성이름 정보를 가져온다.                               |
|   파라미터                                                                    |
|       char *szCompMethod  : 합성 이름 ( "MAX", "MIN", ... )                   |
|       COMP_INFO_TBL *pBuf : 정보를 저장할 버퍼                                |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnGetStdCompInfo(char *szCompMethod, COMP_INFO_TBL *pBuf);

/* -----------------------------------------------------------------------------+
|   표준데이터포맷의 Field이름으로 다른 포맷의 정보를 가져온다.                 |
|   파라미터                                                                    |
|       char *szFieldName   : Moment의 이름 ( DZ, CZ, ... )                     |
|       FIELD_INFO_TBL *pBuf  : 정보를 저장할 버퍼                              |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
|       입력 파라미터로 해당 정보를 찾지 못하면 입력 값을 그대로 복사한다.      |
+----------------------------------------------------------------------------- */
int fnGetStdFieldInfo(char *szFieldName, FIELD_INFO_TBL *pBuf);

/* -----------------------------------------------------------------------------+
|   HDF5 데이터포맷의 Field이름으로 다른 포맷의 정보를 가져온다.                |
|   파라미터                                                                    |
|       char *m_szQuantity  : OPERA Moment의 이름 ( RHOHV, KDP, ... )           |
|       FIELD_INFO_TBL *pBuf  : 정보를 저장할 버퍼                              |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
|       입력 파라미터로 해당 정보를 찾지 못하면 입력 값을 그대로 복사한다.      |
+----------------------------------------------------------------------------- */
int fnGetHdfFieldInfo(char *szQuantity, FIELD_INFO_TBL *pBuf);

/* -----------------------------------------------------------------------------+
|   BUFR 데이터포맷의 Field이름으로 다른 포맷의 정보를 가져온다.                |
|   파라미터                                                                    |
|       char *m_szQuantity    : OPERA Moment의 이름 ( RHOHV, KDP, ... )         |
|       FIELD_INFO_TBL *pBuf  : 정보를 저장할 버퍼                              |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
|       입력 파라미터로 해당 정보를 찾지 못하면 입력 값을 그대로 복사한다.      |
+----------------------------------------------------------------------------- */
int fnGetBufrFieldInfo(char *szQuantity, FIELD_INFO_TBL *pBuf);

/* -----------------------------------------------------------------------------+
|   NC 데이터포맷의 Field이름으로 다른 포맷의 정보를 가져온다.                  |
|   파라미터                                                                    |
|       char *szMoment          :  CF/Radial Moment의 이름 ( DBZ, VEL, ... )    |
|       FIELD_INFO_TBL *pBuf    : 정보를 저장할 버퍼                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
|       입력 파라미터로 해당 정보를 찾지 못하면 입력 값을 그대로 복사한다.      |
+----------------------------------------------------------------------------- */
int fnGetNcFieldInfo(char *szMoment, FIELD_INFO_TBL *pBuf);

/* -----------------------------------------------------------------------------+
|   GRIB 데이터포맷의 Field이름으로 다른 포맷의 정보를 가져온다.                |
|   파라미터                                                                    |
|       char *szQuantity        : GRIB의 Moment 이름 ( DZ, VR, ... )            |
|       FIELD_INFO_TBL *pBuf    : 정보를 저장할 버퍼                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
|       입력 파라미터로 해당 정보를 찾지 못하면 입력 값을 그대로 복사한다.      |
+----------------------------------------------------------------------------- */
int fnGetGribFieldInfo(char *szQuantity, FIELD_INFO_TBL *pBuf);

/* -----------------------------------------------------------------------------+
|   각 산출물 및 Moment 이름으로 Echo Color 파일 정보를 가져온다.               |
|   파라미터                                                                    |
|       char *szFieldName       : moment ( "DZ", "CZ", ... )                    |
|       RDR_DISP_INFO_TBL *pBuf : 정보를 저장할 버퍼                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnGetColorFileInfo(char *szFieldName, RDR_DISP_INFO_TBL *pBuf);

/* -----------------------------------------------------------------------------+
|   이미지의 종류에 따른 사이즈 정보를 가져온다.                                |
|   파라미터                                                                    |
|       char *szImgKind         : 이미지의 종류                                 |
|                                ( "SITE", "COMP_240", "COMP_480", "COMP_KCJ" ) | 
|       RDR_IMG_INFO_TBL *pBuf  : 정보를 저장할 버퍼                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnGetImgSizeInfo(char *szImgKind, RDR_IMG_INFO_TBL *pBuf);

/* -----------------------------------------------------------------------------+
|   이미지의 상단의 코멘트를 작성한다.                                          |
|   파라미터                                                                    |
|       char *szImgKind     : 이미지의 종류                                     |
|                             ( "SITE", "COMP_240", "COMP_480", "COMP_KCJ" )    |
|       char *szProduct     : 프로덕트 ( "PPI", "CAPPI", ... )                  |
|       char *szFieldName   : moment ( "DZ", "CZ", ... )                        |
|       int iDbzUni         : 반사도의 표출 방법 ( Dbz, Rain )                  |
|       char *pBuf          : 코멘트 저장 버퍼                                  |
|       int iBufLen         : 버퍼의 사이즈                                     |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnGetImgComment(char *szImgKind, char *szProduct, char *szFieldName, int iDbzUnit, char *pBuf, int iBufLen);

/* ================================================================================ */

#endif





