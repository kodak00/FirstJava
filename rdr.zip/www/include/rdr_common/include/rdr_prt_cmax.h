/* ================================================================================ */
//
// Radar Create CMAX Header
//
// 2016.08.12 SnK 
//
/* ================================================================================ */

#ifndef RDR_PRT_CMAX_H
#define RDR_PRT_CMAX_H

/* ================================================================================ */
// Define



/* ================================================================================ */
// Enum



/* ================================================================================ */
// Struct



/* ================================================================================ */
// Function

/* -----------------------------------------------------------------------------+
|   CMAX를 생성 한다.                                                           |
|   파라미터                                                                    |
|       STD_RADAR* pStd             : 표준데이터포맷의 메모리 포인터            |
|       int iXdim                   : PPI의 XDIM                                |
|       int iYdim                   : PPI의 YDIM                                |
|       float fMaxRangeKm           : 최대 관측거리 ( Km )                      |
|       floag fGridKm               : Grid( Km )                                |
|       char *szFieldName           : Moment 문자열 ( DZ, CZ ... )              |
|       STD_AZIMUTH_TBL **ppTable   : Sweep의 Ray Hash Table                    |
|   반환값                                                                      |
|       CMAX 1차원 배열 or NULL                                                 |
|       메모리를 할당하여 반환하기 때문에 free 해야 한다.                       |
+----------------------------------------------------------------------------- */
float* fnCreateCmax(STD_RADAR *pStd, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, char* szFieldName, STD_AZIMUTH_TBL **ppTable);

/* -----------------------------------------------------------------------------+
|   QI CMAX를 생성 한다.                                                        |
|   파라미터                                                                    |
|       STD_RADAR* pStd             : 표준데이터포맷의 메모리 포인터            |
|       STD_RADAR* pQiStd           : QI 표준데이터포맷의 메모리 포인터         |
|       int iXdim                   : PPI의 XDIM                                |
|       int iYdim                   : PPI의 YDIM                                |
|       float fMaxRangeKm           : 최대 관측거리 ( Km )                      |
|       floag fGridKm               : Grid( Km )                                |
|       char *szFieldName           : Moment 문자열 ( DZ, CZ ... )              |
|       STD_AZIMUTH_TBL **ppTable   : Sweep의 Ray Hash Table                    |
|       STD_AZIMUTH_TBL **ppQiTable : QI Sweep의 Ray Hash Table                 |
|   반환값                                                                      |
|       CMAX 1차원 배열 or NULL                                                 |
|       메모리를 할당하여 반환하기 때문에 free 해야 한다.                       |
+----------------------------------------------------------------------------- */
float* fnCreateCmaxQI(STD_RADAR *pStd, STD_RADAR *pQiStd, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, char* szFieldName, STD_AZIMUTH_TBL **ppTable, STD_AZIMUTH_TBL **ppQiTable);

/* -----------------------------------------------------------------------------+
|   반사도 QI CMAX를 생성 한다.                                                 |
|   CZ를 확인한 후 DZ를 확인한다.                                               |
|   파라미터                                                                    |
|       STD_RADAR* pStd             : 표준데이터포맷의 메모리 포인터            |
|       STD_RADAR* pQiStd           : QI 표준데이터포맷의 메모리 포인터         |
|       int iXdim                   : PPI의 XDIM                                |
|       int iYdim                   : PPI의 YDIM                                |
|       float fMaxRangeKm           : 최대 관측거리 ( Km )                      |
|       floag fGridKm               : Grid( Km )                                |
|       STD_AZIMUTH_TBL **ppTable   : Sweep의 Ray Hash Table                    |
|       STD_AZIMUTH_TBL **ppQiTable : QI Sweep의 Ray Hash Table                 |
|   반환값                                                                      |
|       CMAX 1차원 배열 or NULL                                                 |
|       메모리를 할당하여 반환하기 때문에 free 해야 한다.                       |
+----------------------------------------------------------------------------- */
float* fnCreateCmaxQIToDbz(STD_RADAR *pStd, STD_RADAR *pQiStd, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, STD_AZIMUTH_TBL **ppTable, STD_AZIMUTH_TBL **ppQiTable);

/* ================================================================================ */

#endif

