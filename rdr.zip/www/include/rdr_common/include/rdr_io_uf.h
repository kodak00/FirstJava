/* ================================================================================ */
//
// Radar UF Format & Function
//
// 2016.08.07 SnK 
//
/* ================================================================================ */

#ifndef RDR_IO_UF_H
#define RDR_IO_UF_H

/* ================================================================================ */
// Define

#define     RDR_DF_UF_NO_DATA       (0X8000)

#define     RDR_DF_F_OFFSET         (4)

#define     RDR_DF_BADVAL           ((float)0x20000)
#define     RDR_DF_RFVAL            ((RDR_DF_BADVAL-1))
#define     RDR_DF_APFLAG           ((RDR_DF_BADVAL-2))
#define     RDR_DF_NOTFOUND_H       ((RDR_DF_BADVAL-3))
#define     RDR_DF_NOTFOUND_V       ((RDR_DF_BADVAL-4))
#define     RDR_DF_NOECHO           ((RDR_DF_BADVAL-5))

#define     RDR_DF_UF_BUFSIZE       (1024*512)

// UF Read Buffer
typedef short UFBuffer[RDR_DF_UF_BUFSIZE];

/* ================================================================================ */
// Enum

// UF type
typedef enum 
{
    EN_UF_TYPE_UNKNOWN = 0,
    EN_UF_TYPE_FOUR,       // 4byte record length
    EN_UF_TYPE_TWO,        // 2byte record length
    EN_UF_TYPE_ZERO,       // 0byte record length
} EN_UF_TYPE_E;

/* ================================================================================ */
// Union

// UF type => 4byte(xxxxUF), 2byte(xxUF), 0byte(UF)
typedef union
{
    char  buf[6];
    short sword;
    int   dword;
} UF_TYPE_HDR;

// QI UF데이터의 m_iTotalLen 이상으로 Mandantory header의 사이즈만 먼저읽어서 확인한다.
#pragma pack(push, 1)
typedef struct
{
    int   m_iTotalLen;
    char  m_szID[2];
    short m_iRecLen;
} UF_SIZE_HEAD;
#pragma pack(pop)

/* ================================================================================ */
// Struct

/* -----------------------------------------------------------------------------+
|   UF 입력 데이터 규격	                                                        |
+----------------------------------------------------------------------------- */
// mandatory header 45 x 2byte
typedef struct
{
    char  m_szID[2+1];
    short m_iRecLen;
    short m_iOHpos;                 // Offset to start of optional header, origin 1
    short m_iLHpos;                 // Offset to start of local use header, origin 1
    short m_iDHpos;                 // Offset to start of data header, origin 1
    short m_iRecordNo;              // Record number within the file, origin 1
    short m_iVolumeNo;              // Volume scan number on the tape, N/A for disk
    short m_iRayNo;                 // Ray number within volume scan
    short m_iRecordInRay;           // Record number within the ray
    short m_iSweepNo;               // Sweep number within this volume scan
    char  m_szRadarName[8+1];       // Radar name (8ASCII characters, includes processor ID.)
    char  m_szSiteName[8+1];        // Site name (8 ASCII characters)
    short m_iLatDeg;                // Degrees of latitude (North is positive, South is negative)
    short m_iLatMin;                // Minutes of latitude
    float m_fLatSec;                // Seconds (1/64) of latitude
    short m_iLonDeg;                // Degrees of longitude (East is positive, West is negative)
    short m_iLonMin;                // Minutes of longitude
    float m_fLonSec;                // Seconds (1/64) of longitude
    short m_iAnteHeight;            // Height of antenna above sea level in meters
    short m_iYear;                  // Time of the ray (ex) 2013)
    short m_iMonth;
    short m_iDay;
    short m_iHour;
    short m_iMinute;
    short m_iSecond;
    char  m_szTimeZone[2+1];        // Time zone (2 ASCII -- UT, CS, MS, etc.)
    float m_fAzimuth;               // Azimuth (1/64) to midpoint of sample
    float m_fElevation;             // Elevation in 1/64 of a degree
    short m_iSweepMode;             // Sweep mode
    float m_fFixedAngle;            // Sweep desired angle in 1/64 of a degree
    float m_fSweepRate;             // Sweep rate (degrees/seconds x 64). (Antenna scan rate in 1/64 of ? )
    short m_iConvertYear;           // Current time when the converter was run, GMT(Greenwich Mean Time)
    short m_iConvertMonth;
    short m_iConvertDay;
    char  m_szConvertName[8+1];     // Tape generator facility name (8 character ASCII)
    short m_iNoDataValue;           // Deleted of missing data flag (Suggest 100000 octal)
} UF_MANDATORY_HDR;

// optional header 14 x 2byte
typedef struct
{
    char  m_szProjectName[8+1];
    float m_fBaselineAzimuth;       // Baseline azimuth (1/64)
    float m_fBaselineElevation;     // Baseline elevation (1/64)
    short m_iVolumeScanHour;        // Time of start of current volume scan
    short m_iVolumeScanMin;
    short m_iVolumeScanSec;
    char  m_szFieldTapeName[8+1];   // Field tape name (8 ASCII)
    short m_iFlag;                  // Flag
} UF_OPTIONAL_HDR;

// local header. (Not used)
typedef struct
{
    int  m_iMaxContent;
    char *m_pszContent;
} UF_LOCAL_HDR;

typedef struct
{
    char  m_szFieldName[2+1];       // (Field name) 1st field name (2 ASCII)
    short m_iFHpos;                 // (FH pos)   Position of 1st word of 1st field header
} UF_FIELD_INFO;

// data header #define UF_MAX_MOMENTS (16)
typedef struct
{
    short m_iMaxField;              // Total number of fields this ray
    short m_iMaxRecord;             // Total number of records this ray (1)
    short m_iMaxFieldInRecord;      // Total number of fields this record
    UF_FIELD_INFO *m_pfi;           // UF_DATA_HDR::m_iMaxField count
} UF_DATA_HDR;

// 19*2 = 38 byte
typedef struct
{
    short m_iDataPos;               // Origin 1 offset of data from start of record
    short m_iScaleFactor;           // Met units = file value/ScaleFactor => 100
    short m_iStartRangeKm;          // Range to first gate (km) => 0
    short m_iStartRangeMeter;       // Adjustment to center of first gate (m)
    short m_iBinSpacing;            // Sample Volume spacing (m), (Bin spacing in meters)
    short m_iMaxBin;                // Number of sample volumes
    short m_iPulseWidth;            // Sample volume depth (m), (Pulse width in meters)
    float m_fBeamWidthH;            // Horizontal Beam width in 1/64 of degree
    float m_fBeamWidthV;            // Vertical Beam width in 1/64 of degree
    short m_iBandWidth;             // Receiver bandwidth (Mhz)
    short m_iPolarMode;             // Polarization transmitted 
    float m_fWaveLength;            // Wavelength in 1/64 of a cm
    short m_iSampleSize;            // Sample size
    char  m_szThresholdType[2+1];   // Type of data used to threshold
    short m_iThresholdValue;        // Threshold value
    short m_iScale;
    char  m_szEditCode[2+1];        // Edit code (2 ASCII)
    short m_iPRT;                   // Pulse repetition time (microseconds)
    short m_iBitsPerBin;            // Must be 16

    // for VF, VE, VR, VT, VP
    float m_fNyquistVelocity;       // Nyquist velocity (scaled)  :  value = real value × scale facter(100)
    char  m_szVelocityFlag[2+1];    // FL (2 ASCII)

    // for DM
    float m_fRadarConstant;         // Radar constant
    float m_fNoisePower;            // Noise power (dB(mW) x scale)
    float m_fReceiverGain;          // Receiver gain (dB ×x scale)
    float m_fPeakPower;             // Peak power (dB(mW) x scale)
    float m_fAntennaGain;           // Antenna gain (dB x scale)
    float m_fPulseDuration;         // Pulse duration (microseconds x 64)
} UF_FIELD_HDR;

// FIELD data
typedef struct
{
    UF_FIELD_HDR        fh;
    int                 m_iCurBin;              // UF의 BIN의 수
    int                 m_iMaxBin;              // 할당 BIN의 수
    short               *m_pData;
} UF_FIELD;

// RAY 자료구조
typedef struct
{
    UF_MANDATORY_HDR    mh;
    UF_OPTIONAL_HDR     oh;
    UF_LOCAL_HDR        lh;
    UF_DATA_HDR         dh;

    int                 m_iCurField;            // UF의 FIELD의 수
    int                 m_iMaxField;            // 할당 FIELD의 수
    UF_FIELD            **m_ppField;
} UF_RAY;

// SWEEP 자료구조
typedef struct
{
    int                 m_iCurRay;              // UF의 RAY의 수
    int                 m_iMaxRay;              // 할당 RAY의 수
    UF_RAY              **m_ppRay;
} UF_SWEEP;

// UF 자료구조   (ex) sweep(4), ray(360), field(4), bin(512)
typedef struct
{
    int                 m_iCurSweep;            // UF의 SWEEP의 수
    int                 m_iMaxSweep;            // 할당 SWEEP의 수
    UF_SWEEP            **m_ppSweep;
} UF_RADAR;

/* ================================================================================ */
// Function

/* -----------------------------------------------------------------------------+
|   UF 파일을 읽어 데이터 메모리를 반환한다.                                    |
|   파라미터                                                                    |
|       char *pFile : UF 파일의 경로                                            |
|   반환값                                                                      |
|       UF 데이터 메모리포인터 or NULL                                          |
|       메모리를 할당하기 때문에 fnFreeUfRadar 호출하여 해제해야 한다.          |
+----------------------------------------------------------------------------- */
UF_RADAR* fnLoadUf(char *szFile);

/* -----------------------------------------------------------------------------+
|   UF 데이터 메모리를 해제한다.                                                |
|   파라미터                                                                    |
|       UF_RADAR *pUf : UF 데이터 메모리 포인터                                 |
+----------------------------------------------------------------------------- */
void fnFreeUfRadar(UF_RADAR *pUf);

/* -----------------------------------------------------------------------------+
|   UF 데이터의 유효성을 확인한다.                                              |
|   파라미터                                                                    |
|       UF_RADAR *uf : UF 데이터 메모리 포인터                                  |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnValidUf(UF_RADAR *uf);

/* ================================================================================ */

#endif

