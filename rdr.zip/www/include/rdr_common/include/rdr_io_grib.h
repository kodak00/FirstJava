/* ================================================================================ */
//
// Radar Grib2 Input && Output Function
//
// 2016.11.28 SnK 
//
/* ================================================================================ */

#ifndef RDR_IO_GRIB_H
#define RDR_IO_GRIB_H

/* ================================================================================ */
// Define

#define RDR_DF_GRIB_PRODUCT_MAX         (100)

#define RDR_DF_GRIB_STR_MAX             (255)

#define RDR_DF_GRIB_SCALE_D             (100.)

/* ================================================================================ */
// Enum

typedef enum
{
    GRIB_EN_PRODUCT_SITE = 1,
    GRIB_EN_PRODUCT_COMP
} GRIB_EN_PRODUCT_TYPE;

/* ================================================================================ */
// Struct

// INPUT
// variable
typedef struct
{
    // dim information.
    int     m_iMaxSweep;
    int     m_iMaxRay;
    int     m_iMaxBin;
    int     m_iMaxField;

    // mandatory header
    char     m_szRadarName[8+1];
    char     m_szSiteName[8+1];
    char     m_szConvertName[8+1];
    double   m_dLat;
    double   m_dLon;
    int      m_iAnteHeight;
    int      m_iSweepMode;
    float    m_fSweepRate;
    time_t   m_tConvertTime;
    int      m_iNoDataValue;

    // field header
    int      m_iScaleFactor;
    float    m_fStartRangeMeter;
    int      m_iBinSpacing;
    int      m_iPulseWidth;
    float    m_fBeamWidthH;
    float    m_fBeamWidthV;
    int      m_iBandWidth;
    int      m_iPolarMode;
    float    m_fWaveLength;
    int      m_iSampleSize;
    int      m_iThresholdValue;
    int      m_iScale;
    int      m_iPRT;
    int      m_iBitsPerBin;

    // array [sweep]
    long     *m_pMaxRay;

    // array [totalray]
    long     *m_pMaxBin;
    double   *m_pRayTime;
    double   *m_pRayAzimuth;
    double   *m_pRayElevation;
    double   *m_pRayFixedAngle;
} GRIB_GLOBAL_HDR;

// volume
typedef struct 
{
    short *m_pData;                             // short [bin * ray * sweep]
    char  m_szName[8+1];                        // field name
} GRIB_VOLUME;

// app
typedef struct
{
    long m_lTotalMsg;                           // total message count
    long m_lSecTotalLen;                        // section total count
    long m_SecLen[9];                           // 0 ~ 8 section length
    long m_SecOffset[9];                        // 0 ~ 8 section offset
} GRIB_APP;

// GRIB_DATA
typedef struct 
{
//    GRIB_APP          m_app;
    GRIB_GLOBAL_HDR         m_hdr;

    int                     m_iMaxVolume;
    GRIB_VOLUME             **m_ppVolume;
} GRIB_RADAR;

// OUTPUT

typedef struct
{
    char                    m_szDate[8+1];
    char                    m_szTime[6+1];
} GRIB_PRODUCT_WHAT;

typedef struct
{
    // DATASET
    char                    m_szProduct[6+1];
    double                  m_dProdpar[2];
    // DATA
    char                    m_szQuantity[6+1];
    double                  m_dScale;
    double                  m_dOffset;
    double                  m_dNodata;
    double                  m_dUndetect;
} GRIB_DATASET_WHAT;

typedef struct
{

    double                  m_dLon;
    double                  m_dLat;
    double                  m_dHeightM;

    char                    m_szProjdef[RDR_DF_GRIB_STR_MAX+1];
    long                    m_lXsize;
    long                    m_lYsize;
    double                  m_dXscale;
    double                  m_dYscale;
    double                  m_LL_lon;
    double                  m_LL_lat;
    double                  m_UL_lon;
    double                  m_UL_lat;
    double                  m_UR_lon;
    double                  m_UR_lat;
    double                  m_LR_lon;
    double                  m_LR_lat;
} GRIB_PROUDCT_WHERE;

typedef struct
{
    GRIB_DATASET_WHAT       m_what;
    char                    m_szFieldName[8+1];
    int                     m_iMemType;
    char                    **m_ppData_c;
    short                   **m_ppData_s;
    float                   **m_ppData_f;
} GRIB_PRODUCT_DATA;

typedef struct
{
    GRIB_DATASET_WHAT       m_what;
    int                     m_iMaxField;
    GRIB_PRODUCT_DATA       **m_ppProductData;
} GRIB_PRODUCT_DATASET;

typedef struct
{
    int                     m_iMaxPpi;
    int                     m_iMaxCappi;
    int                     m_iMaxBase;
    int                     m_iMaxCmax;
    int                     m_iMaxVil;
    int                     m_iMaxEtop;
    GRIB_PRODUCT_DATASET    **m_ppPpi;
    GRIB_PRODUCT_DATASET    **m_ppCappi;
    GRIB_PRODUCT_DATASET    **m_ppBase;
    GRIB_PRODUCT_DATASET    **m_ppCmax;
    GRIB_PRODUCT_DATASET    **m_ppVil;
    GRIB_PRODUCT_DATASET    **m_ppEtop;
} GRIB_TOTAL_PRODUCT;

typedef struct
{
    int                     m_iGribProductType;
    GRIB_PRODUCT_WHAT       m_what;
    GRIB_PROUDCT_WHERE      m_where;
    GRIB_TOTAL_PRODUCT      m_totalProduct;
} GRIB_PRODUCT;

/* ================================================================================ */
// Function

/* -----------------------------------------------------------------------------+
|   GRIB 파일을 읽어 데이터 메모리를 반환한다.                                  |
|   파라미터                                                                    |
|       char *pFile : GRIB 파일의 경로                                          |
|   반환값                                                                      |
|       GRIB 데이터 메모리포인터 or NULL                                        |
|       메모리를 할당하기 때문에 fnFreeGribRadar 호출하여 해제해야 한다.        |
+----------------------------------------------------------------------------- */
GRIB_RADAR* fnLoadGribRadar(char *szFile);

/* -----------------------------------------------------------------------------+
|   GRIB 데이터 메모리를 해제한다.                                              |
|   파라미터                                                                    |
|       GRIB_RADAR *pGrib : Grib 데이터 메모리 포인터                           |
+----------------------------------------------------------------------------- */
void fnFreeGribRadar(GRIB_RADAR *pGrib);

/* -----------------------------------------------------------------------------+
|   GRIB 프로덕트 파일을 읽는다.                                                |
|   파라미터                                                                    |
|       char *szFile        : GRIB 프로덕트 파일 전체 경로                      |
|       int iProductType    : GRIB_EN_PRODUCT_SITE or GRIB_EN_PRODUCT_COMP      |
|   반환값                                                                      |
|       GRIB 프로덕트포맷 메모리 포인터 or NULL                                 |
|       메모리를 할당하기 때문에 fnFreeGribProduct를 호출하여 해제해야 한다.    |
+----------------------------------------------------------------------------- */
GRIB_PRODUCT* fnLoadGribProduct(char* szFile, int iProductType);

/* -----------------------------------------------------------------------------+
|   GRIB 프로덕트포맷 메모리를 초기화 한다.                                     |
|   파라미터                                                                    |
|       int iMaxField   : 총 moment의 수                                        |
|       int iMaxPpi     : 총 PPI의 수                                           |
|       int iMaxCappi   : 총 CAPPI의 수                                         |
|       int iMaxBase    : 총 BASE의 수                                          |
|       int iMaxCmax    : 총 CMAX의 수                                          |
|       int iMaxVil     : 총 VIL의 수                                           |
|       int iMaxEtop    : 총 ETOP의 수                                          |
|   반환값                                                                      |
|       GRIB 프로덕트포맷 메모리 포인터 or NULL                                 |
|       메모리를 할당하기 때문에 fnFreeGribProduct를 호출하여 해제해야 한다.    |
+----------------------------------------------------------------------------- */
GRIB_PRODUCT* fnInitGribProduct(int iMaxField, int iMaxPpi, int iMaxCappi, int iMaxBase, int iMaxCmax, int iMaxVil, int iMaxEtop);

/* -----------------------------------------------------------------------------+
|   GRIB 프로덕트 메모리를 해제 한다.                                           |
|   파라미터                                                                    |
|       GRIB_PRODUCT *pGribProduct  : Grib 프로덕트포맷의 메모리 포인터         |
+----------------------------------------------------------------------------- */
void fnFreeGribProduct(GRIB_PRODUCT *pGribProduct);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷을 확인하여 GRIB 프로덕트 포맷을 초기화한다.              |
|   파라미터                                                                    |
|       void    *pStdPtr: 표준 프로덕트 포멧 메모리 포인터                      |
|                         함수 내부에서 캐스팅한다.                             |
|   반환값                                                                      |
|       GRIB 출력포맷 메모리 포인터 or NULL                                     |
|       메모리를 할당하기 때문에 fnFreeGribProduct를 호출하여 해제해야 한다.    |
+----------------------------------------------------------------------------- */
GRIB_PRODUCT* fnInitGribProductToStdProduct(void *pStdPtr);

/* -----------------------------------------------------------------------------+
|   GRIB 프로덕트 포맷의 각 산출물 및 Moment의 최대 개수를 구한다.              |
|   파라미터                                                                    |
|       GRIB_PRODUCT *pGribProduct  : GRIB 프로덕트 포맷 메모리 포인터          |
|       int *pMaxField              : Moment 개수 버퍼 포인터                   |
|       int *pMaxPpi                : PPI    개수 버퍼 포인터                   |
|       int *pMaxCappi              : CAPPI  개수 버퍼 포인터                   |
|       int *pMaxBase               : BASE   개수 버퍼 포인터                   |
|       int *pMaxCmax               : CMAX   개수 버퍼 포인터                   |
|       int *pMaxVil                : VIL    개수 버퍼 포인터                   |
|       int *pMaxEtop               : ETOP   개수 버퍼 포인터                   |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnGetMaxCountGribProduct(GRIB_PRODUCT *pGribProduct, int *pMaxField, int *pMaxPpi, int *pMaxCappi, int *pMaxBase, int *pMaxCmax, int *pMaxVil, int *pMaxEtop);

/* -----------------------------------------------------------------------------+
|   GRIB 프로덕트 포맷을 파일로 저장한다.                                       |
|   GRIB 데이터 구조상 전체를 WRITE하지 못하고, 특정 PRODUCT 만을 WRITE 한다.   |
|   파라미터                                                                    |
|       GRIB_PRODUCT    *pGribProduct   : Grib 프로덕트포맷의 메모리 포인터     |
|       char            *szProduct      : ( PPI,CAPPI,BASE,CMAX,VAIL,ETOP )     |
|       char            *szFileName     : 저장 파일의 전체 경로 및 이름         | 
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnWriteGribProduct(GRIB_PRODUCT *pGribProduct, char *szProduct, char *szFileName);

/* ================================================================================ */

#endif




