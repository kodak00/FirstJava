/* ================================================================================ */
//
// Radar Create VIL Header
//
// 2016.08.12 SnK 
//
/* ================================================================================ */

#ifndef RDR_PRT_VIL_H
#define RDR_PRT_VIL_H

/* ================================================================================ */
// Define



/* ================================================================================ */
// Enum



/* ================================================================================ */
// Struct



/* ================================================================================ */
// Function

/* -----------------------------------------------------------------------------+
|   VIL을 생성 한다.                                                            |
|   파라미터                                                                    |
|       STD_RADAR* pStd             : 표준데이터포맷의 메모리 포인터            |
|       int iXdim                   : PPI의 XDIM                                |
|       int iYdim                   : PPI의 YDIM                                |
|       float fMaxRangeKm           : 최대 관측거리 ( Km )                      |
|       float fGridKm               : Grid 크기 ( Km )                          |
|       int iTop_h_km               : VIL Top 높이 ( Km )                       |
|       int iBottom_h_km            : VIL Bottom 높이 ( Km )                    |
|       char *szFieldName           : Moment 문자열 ( DZ, CZ ... )              |
|       STD_AZIMUTH_TBL **ppTable   : Sweep의 Ray Hash Table                    |
|   반환값                                                                      |
|       VIL 1차원 배열 or NULL                                                  |
|       메모리를 할당하여 반환하기 때문에 free 해야 한다.                       |
+----------------------------------------------------------------------------- */
float* fnCreateVil(STD_RADAR *pStd, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, int iTop_h_km, int iBottom_h_km, char* szFieldName, STD_AZIMUTH_TBL **ppTable);

/* ================================================================================ */

#endif

