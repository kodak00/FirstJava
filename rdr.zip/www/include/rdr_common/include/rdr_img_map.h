/* ================================================================================ */
//
// Radar Image Map Header
//
// 2016.08.30 SnK 
//
/* ================================================================================ */

#ifndef RDR_IMG_MAP_H
#define RDR_IMG_MAP_H

/* ================================================================================ */
// Define

#define RDR_DF_SITE_KR_MAP_FILE        "fine_kr_binary.dat"
#define RDR_DF_COMP_F2R_MAP_FILE       "F2R_map4.bln"
#define RDR_DF_COMP_KR_MAP_FILE        "map_data.bln"
#define RDR_DF_BIN_MAP_GRID             (4.0)
#define RDR_DF_AWS_1_FILE               "aws_pos_han_1.txt"
#define RDR_DF_AWS_2_FILE               "aws_pos_han_2.txt"

#define RDR_DF_AWS_FONT_FILE            "gulim.ttc"
#define RDR_DF_AWS_FONT_SIZE            (10.0)
#define RDR_DF_AWS_NAME_MV_POSITION_X   (26)
#define RDR_DF_AWS_NAME_MV_POSITION_Y   (2)

/* ================================================================================ */
// Enum



/* ================================================================================ */
// Struct



/* ================================================================================ */
// Function

/* -----------------------------------------------------------------------------+
|   이미지에 사이트 지도를 그린다.                                              |
|   파라미터                                                                    |
|       gdImagePtr pImg     : gd 이미지 메모리 포인터                           |
|       int iWidth          : 이미지의 가로 크기                                |
|       int iHeight         : 이미지의 세로 크기                                |
|       float fImgGridKm    : 이미지의 그리드                                   |
|       float fSiteLon      : 사이트의 경도                                     |
|       float fSiteLat      : 사이트의 위도                                     |
|       float fSiteXo       : 사이트의 X좌표 ( 원점 자표 )                      |
|       float fSiteXo       : 사이트의 Y좌표 ( 원점 자표 )                      |
|       int iMapColor       : 지도 색상                                         |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnDrawSiteImgMap(gdImagePtr pImg, int iWidth, int iHeight, float fImgGridKm, float fSiteLon, float fSiteXo, float fSiteYo, float fSiteLat, int iMapColor);

/* -----------------------------------------------------------------------------+
|   이미지에 AWS 지점을 표시한다.                                               |
|   파라미터                                                                    |
|       gdImagePtr pImg     : gd 이미지 메모리 포인터                           |
|       int iWidth          : 이미지의 가로 크기                                |
|       int iHeight         : 이미지의 세로 크기                                |
|       float fImgGridKm    : 이미지 그리드                                     |
|       float fSiteLon      : 사이트의 경도                                     |
|       float fSiteLat      : 사이트의 위도                                     |
|       float fSiteXo       : 사이트의 X좌표 ( 원점 자표 )                      |
|       float fSiteXo       : 사이트의 Y좌표 ( 원점 자표 )                      |
|       int iAWsColor       : AWS 색상                                          |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnDrawSiteImgAws(gdImagePtr pImg, int iWidth, int iHeight, float fImgGridKm, float fSiteLon, float fSiteLat, float fSiteXo, float fSiteYo, int iAwsColor, int iFontColor);

/* -----------------------------------------------------------------------------+
|   이미지에 합성 지도를 그린다.                                                |
|   파라미터                                                                    |
|       char *szImgKind     : 합성 이미지 종류 ("COMP_240","COMP_480","COMP_KCJ)|
|       gdImagePtr pImg     : gd 이미지 메모리 포인터                           |
|       int iWidth          : 이미지의 가로 크기                                |
|       int iHeight         : 이미지의 세로 크기                                |
|       float fImgGridKm    : 이미지의 그리드                                   |
|       float fOrgX         : 원본지도의 X좌표 이동 포인트                      |
|       float fOrgY         : 원본지도의 Y좌표 이동 포인트                      |
|       int iMoveX          : 그리드 적용 후의 X좌표 이동 포인트                |
|       int iMoveY          : 그리드 적용 후의 Y좌표 이동 포인트                |
|       int iMapColor       : 지도 색상                                         |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnDrawCompImgMap(char *szImgKind, gdImagePtr pImg, int iWidth, int iHeight, float fImgGridKm, float fOrgX, float fOrgY, int iMoveX, int iMoveY, int iMapColor);

/* ================================================================================ */

#endif

