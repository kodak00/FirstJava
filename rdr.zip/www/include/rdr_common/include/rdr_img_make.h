/* ================================================================================ */
//
// Radar Image Make Header
//
// 2016.08.30 SnK 
//
/* ================================================================================ */

#ifndef RDR_IMG_MAKE_H
#define RDR_IMG_MAKE_H

/* ================================================================================ */
// Define

// Top Comment
#define RDR_DF_COMMENT_FONT_FILE    "NanumGothic.ttf"
#define RDR_DF_COMMENT_FONT_SIZE    (12.0)
#define RDR_DF_COMMENT_UPPER_SPACE  (8)
#define RDR_DF_UNIT_FONT_SIZE       (10.0)
#define RDR_DF_UNIT_STR_WIDTH       (50)  

// Right Color Bar
#define RDR_DF_COLOR_BAR_WIDTH      (10)
#define RDR_DF_LEGEND_STR_SPACE     (5)

// Bottom Text
#define RDR_DF_BOTTOM_LEFT_SPACE    (10)
#define RDR_DF_BOTTOM_UPPER_SPACE   (2)

/* ================================================================================ */
// Enum

typedef enum
{
    RDR_EN_IMG_TYPE_PNG = 1,
    RDR_EN_IMG_TYPE_GIF,
    RDR_EN_IMG_TYPE_JPEG
} RDR_EN_IMG_TYPE;

typedef enum
{
    RDR_EN_UNIT_DEFAULT = 0,
    RDR_EN_DBZ_TO_RAIN,
} RDR_EN_UNIT_TYPE;

/* ================================================================================ */
// Struct

typedef struct
{
    int m_iImgType;         // 이미지의 종류 ( PNG, GIF, JPEG )
    int m_iImgWidth;        // 이미지의 가로크기 ( 0 기본값 )
    int m_iImgHeight;       // 이미지의 세로크기 ( 0 기본값 )
    int m_iSmoothNum;       // 이미지의 스무딩 회수
    int m_iDrawAws;         // AWS 표출 여부
    int m_iDrawRing;        // 등거리 반경 표시
    int m_iDrawDirection;   // 대각선 표시
} RDR_IMG_MAKE_OPTION;

/* ================================================================================ */
// Function

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷으로 사이트 이미지를 생산한다.                            |
|   파라미터                                                                    |
|       char* szImgKind             : 이미지의 종류 ( "SITE_240", "SITE_480" )  |
|       char* szSiteCode            : 사이트의 코드 ( "YIT", "GNG", ... )       |
|       STD_PRODUCT *pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char *szProduct             : 산출물 ( "PPI", "CAPPI", ... )            |
|       int iProuductIdx            : 산출물의 배열 인덱스 ( 0 ~ )              |
|       char *szFieldName           : moment 이름 ( "DZ", "CZ", ... )           |
|       RDR_IMG_MAKE_OPTION option  : 이미지 생성 옵션                          |
|       char *szOutFile             : 이미지 출력 전체경로                      |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnMakeSiteImageToStdProductByIdx(char *szImgKind, char *szSiteCode, STD_PRODUCT *pStdProduct, char *szProduct, int iProductIdx, char *szFieldName, RDR_IMG_MAKE_OPTION imgOption, char *szOutFile);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷으로 사이트 이미지를 생산한다.                            |
|   파라미터                                                                    |
|       char* szImgKind             : 이미지의 종류 ( "SITE_240", "SITE_480" )  |
|       char* szSiteCode            : 사이트의 코드 ( "YIT", "GNG", ... )       |
|       STD_PRODUCT *pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char *szProduct             : 산출물 ( "PPI", "CAPPI", ... )            |
|       double dProductArg1         : 프로덕트의 파라미터 1                     |
|       double dProductArg2         : 프로덕트의 파라미터 2                     |
|       char *szFieldName           : moment 이름 ( "DZ", "CZ", ... )           |
|       RDR_IMG_MAKE_OPTION option  : 이미지 생성 옵션                          |
|       char *szOutFile             : 이미지 출력 전체경로                      |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnMakeSiteImageToStdProductByArg(char *szImgKind, char *szSiteCode, STD_PRODUCT *pStdProduct, char *szProduct, double dProductArg1, double dProductArg2, char *szFieldName, RDR_IMG_MAKE_OPTION imgOption, char *szOutFile);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷으로 합성 이미지를 생산한다.                              |
|   파라미터                                                                    |
|       char* szImgKind             : 이미지의 종류 ( "COMP_240", ...)          |
|       STD_PRODUCT *pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char *szProduct             : 산출물 ( "PPI", "CAPPI", ... )            |
|       int iProuductIdx            : 산출물의 배열 인덱스 ( 0 ~ )              |
|       char *szFieldName           : moment 이름 ( "DZ", "CZ", ... )           |
|       RDR_IMG_MAKE_OPTION option  : 이미지 생성 옵션                          |
|       char *szQcStr               : 상단 TEXT 용 QC 문자 ( "NoQC", "Fuzzy", ) |
|       char *szOutFile             : 이미지 출력 전체경로                      |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnMakeCompImageToStdProductByIdx(char *szImgKind, STD_PRODUCT *pStdProduct, char *szProduct, int iProductIdx, char *szFieldName, RDR_IMG_MAKE_OPTION imgOption, char *szQcStr, char *szOutFile);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷으로 합성 이미지를 생산한다.                              |
|   파라미터                                                                    |
|       char* szImgKind             : 이미지의 종류 ( "COMP_240", ...)          |
|       STD_PRODUCT *pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char *szProduct             : 산출물 ( "PPI", "CAPPI", ... )            |
|       double dProductArg1         : 프로덕트의 파라미터 1                     |
|       double dProductArg2         : 프로덕트의 파라미터 2                     |
|       char *szFieldName           : moment 이름 ( "DZ", "CZ", ... )           |
|       RDR_IMG_MAKE_OPTION option  : 이미지 생성 옵션                          |
|       char *szQcStr               : 상단 TEXT 용 QC 문자 ( "NoQC", "Fuzzy", ) |
|       char *szOutFile             : 이미지 출력 전체경로                      |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnMakeCompImageToStdProductByArg(char *szImgKind, STD_PRODUCT *pStdProduct, char *szProduct, double dProductArg1, double dProductArg2, char *szFieldName, RDR_IMG_MAKE_OPTION imgOption, char *szQcStr, char *szOutFile);

/* ================================================================================ */

#endif

