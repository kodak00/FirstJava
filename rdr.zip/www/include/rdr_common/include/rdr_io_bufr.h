/* ================================================================================ */
//
// Radar BUFR Format & Function
//
// 2016.11.08 SnK 
//
/* ================================================================================ */

#ifndef RDR_IO_BUFR_H
#define RDR_IO_BUFR_H

/* ================================================================================ */
// Define

#define RDR_DF_BUFR_PRODUCT_MAX         (100)
#define RDR_DF_BUFR_OBJECT_MAX          (100)
#define RDR_DF_BUFR_OBEJCT_LEN          (128)

#define RDR_DF_BUFR_ATTR_MAX            (100)
#define RDR_DF_BUFR_ATTR_LEN            (128)

#define RDR_DF_BUFR_STR_MAX             (255)

#define RDR_DF_BUFR_CONVENTIONS_STR     "ODIM_H5/V2_1"
#define RDR_DF_BUFR_OBJECT_STR          "PVOL"
#define RDR_DF_BUFR_VERSION_STR         "H5rad 1.0"
#define RDR_DF_BUFR_PRODUCT_STR         "SCAN"

#define RDR_DF_BUFR_MAX_ANGLES          (20)
#define RDR_DF_BUFR_MAX_RAYS            (600)

#define RDR_DF_BUFR_COMP_MAX_SITES      (100)

#define RDR_DF_BUFR_HOW_NAME_LENGTH     (16)
#define RDR_DF_BUFR_HOW_STR_LENGTH      (16)

#define RDR_DF_BUFR_MISS_VALUE          (255)

#define RDR_DF_BUFR_ITER_SIZE           (65534)

/* ================================================================================ */
// Enum

typedef enum
{
    BUFR_EN_PRODUCT_SITE = 1,
    BUFR_EN_PRODUCT_COMP
} BUFR_EN_PRODUCT_TYPE;

typedef enum
{
    BUFR_EN_R_TYPE_POLAR = 1,
    BUFR_EN_R_TYPE_IMAGE,
    BUFR_EN_R_TYPE_CROSS,
    BUFR_EN_R_TYPE_VERTICAL,
} BUFR_EN_RADAR_TYPE;

/* ================================================================================ */
// Union



/* ================================================================================ */
// Struct

typedef struct
{
    char                m_szObject[6+1];
    char                m_szVersion[10+1];
    char                m_szDate[8+1];
    char                m_szTime[6+1];
    char                m_szSource[RDR_DF_BUFR_STR_MAX+1];
} BUFR_TOP_WHAT;

typedef struct
{
    // DATASET
    char                m_szProduct[6+1];
    double              m_dProdpar[2];
    char                m_szStartDate[8+1];
    char                m_szStartTime[6+1];
    char                m_szEndDate[8+1];
    char                m_szEndTime[6+1];
    // DATA
    char                m_szQuantity[6+1];
    double              m_dGain;
    double              m_dOffset;
    double              m_dNodata;
    double              m_dUndetect;
} BUFR_DATASET_WHAT;

typedef struct
{
    double              m_dLon;
    double              m_dLat;
    double              m_dHeightM;
    // Datsset 
    double              m_dElangle;
    long                m_nBins;
    double              m_dRstart;
    double              m_dRScale;
    long                m_nRays;
    long                m_lA1gate;
    // Sector
    double              m_dStartAz;
    double              m_dStopAz;
} BUFR_POLAR_WHERE;

typedef struct
{
    char                m_szProjdef[RDR_DF_BUFR_STR_MAX+1];
    long                m_lXsize;
    long                m_lYsize;
    double              m_dXscale;
    double              m_dYscale;
    double              m_LL_lon;
    double              m_LL_lat;
    double              m_UL_lon;
    double              m_UL_lat;
    double              m_UR_lon;
    double              m_UR_lat;
    double              m_LR_lon;
    double              m_LR_lat;
} BUFR_IMAGE_WHERE;

typedef struct
{
    long                m_lXsize;
    long                m_lYsize;
    double              m_dXscale;
    double              m_dYscale;
    double              m_dMinHeightM;
    double              m_dMaxHeightM;
    // RHI
    double              m_dLon;
    double              m_dLat;
    double              m_dAz_angle;
    double              m_dAngles[RDR_DF_BUFR_MAX_ANGLES];
    double              m_dRange;
    // CROSS
    double              m_dStart_lon;
    double              m_dStart_lat;
    double              m_dStop_lon;
    double              m_dStop_lat;
} BUFR_CROSS_WHERE;

typedef struct
{
    double              m_dLon;
    double              m_dLat;
    double              m_dHeightM;
    long                m_lLevels;
    double              m_dInterval;
    double              m_dMinHeightM;
    double              m_dMaxHeightM;
} BUFR_VERTICAL_WHERE;

typedef struct
{
    BUFR_POLAR_WHERE     m_polar_where;
    BUFR_IMAGE_WHERE     m_image_where;
    BUFR_CROSS_WHERE     m_cross_where;
    BUFR_VERTICAL_WHERE  m_vertical_where;
} BUFR_WHERE;

typedef struct
{
    char                m_szTask[8+1];
    char                m_szTaskArg[RDR_DF_BUFR_STR_MAX+1];
    double              m_dStartepochs;
    double              m_dEndepochs;
    char                m_szSystem[8+1];
    char                m_szTXtype[16+1];
    char                m_szPoltype[32+1];
    char                m_szPolmode[32+1];
    char                m_szSoftware[10+1];
    char                m_szSW_version[16+1];
    double              m_dZr_a;
    double              m_dZr_b;
    double              m_dKr_a;
    double              m_dKr_b;
    char                m_bSimulated[6+1];
} BUFR_GENERAL_HOW;

typedef struct
{
    double              m_dBeamwidth;
    double              m_dWaveLength;
    double              m_dRpm;
    double              m_dElevsSpeed;
    double              m_dPulseWidth;
    double              m_dRXbandWidth;
    double              m_dLowPrf;
    double              m_dMidPrf;
    double              m_dHighPrf;
    double              m_dTXlossH;
    double              m_dTXlossV;
    double              m_dInjectlossH;
    double              m_dInjectlossV;
    double              m_dRXlossH;
    double              m_dRXlossV;
    double              m_dRadomelossH;
    double              m_dRadomelossV;
    double              m_dAntgainH;
    double              m_dAntgainV;
    double              m_dBeamwH;
    double              m_dBeamwV;
    double              m_dGasattn;
    double              m_dRadconstH;
    double              m_dRadconstV;
    double              m_dNomTXpower;
    double              m_dTXpower[RDR_DF_BUFR_MAX_RAYS];
    double              m_dPowerDiff;
    double              m_dPhaseDiff;
    double              m_dNi;
    long                m_lVsamples;
} BUFR_RADAR_HOW;

typedef struct
{
    long                m_lScan_index;
    long                m_lScan_count;
    double              m_dAstart;
    char                m_szAzmethod[16+1];
    char                m_szElmethod[16+1];
    char                m_szBinmethod[16+1];
    double              m_dElangles[RDR_DF_BUFR_MAX_RAYS];
    double              m_dStartazA[RDR_DF_BUFR_MAX_RAYS];
    double              m_dStopazA[RDR_DF_BUFR_MAX_RAYS];
    double              m_dStartazT[RDR_DF_BUFR_MAX_RAYS];
    double              m_dStopazT[RDR_DF_BUFR_MAX_RAYS];
    double              m_dStartelA[RDR_DF_BUFR_MAX_RAYS];
    double              m_dStopelA[RDR_DF_BUFR_MAX_RAYS];
    double              m_dStartelT[RDR_DF_BUFR_MAX_RAYS];
    double              m_dStopelT[RDR_DF_BUFR_MAX_RAYS];
} BUFR_POLAR_HOW;

typedef struct
{
    double              m_dAngles[RDR_DF_BUFR_COMP_MAX_SITES];
    double              m_dArotation[RDR_DF_BUFR_COMP_MAX_SITES];
    char                m_szCamethod[16+1];
    char                m_szNodes[RDR_DF_BUFR_STR_MAX+1];
    long                m_lAccNum;
} BUFR_IMAGE_HOW;

typedef struct
{
    double              m_dMinRangeKm;
    double              m_dMaxRangeKm;
    char                m_szDealiased[6+1];
} BUFR_VERTICAL_HOW;

typedef struct
{
    double              m_dPointAccEl;
    double              m_dPointAccAZ;
    char                m_szAngleSync[16+1];
    double              m_dAnglesSyncRes;
    char                m_szMalfunc[6+1];
    char                m_szRadar_msg[RDR_DF_BUFR_STR_MAX+1];
    double              m_dRadarHoriz;
    double              m_dNEZH;
    double              m_dNEZV;
    double              m_dOUR;
    char                m_szDclutter[RDR_DF_BUFR_STR_MAX+1];
    char                m_szClutterType[RDR_DF_BUFR_STR_MAX+1];
    char                m_szClutterMap[RDR_DF_BUFR_STR_MAX+1];
    double              m_dZcalH;
    double              m_dZcalV;
    double              m_dNsampleH;
    double              m_dNsampleV;
    char                m_szComment[RDR_DF_BUFR_STR_MAX+1];
    double              m_dSQI;
    double              m_dCSR;
    double              m_dLOG;
    char                m_szVPRCorr[6+1];
    double              m_dFreeze;
    double              m_dMin;
    double              m_dMax;
    double              m_dStep;
    long                m_lLevels;
    double              m_dPeakpwr;
    double              m_dAvgpwr;
    double              m_dDynrange;
    double              m_dRAC;
    char                m_szBBC[6+1];
    double              m_dPAC;
    double              m_dS2N;
    char                m_szPolarization[RDR_DF_BUFR_STR_MAX+1];
} BUFR_QUALITY_HOW;

typedef struct
{
    BUFR_GENERAL_HOW     m_general_how;
    BUFR_RADAR_HOW       m_radar_how;
    BUFR_POLAR_HOW       m_polar_how;
    BUFR_IMAGE_HOW       m_image_how;
    BUFR_VERTICAL_HOW    m_vertical_how;
    BUFR_QUALITY_HOW     m_quality_how;
} BUFR_HOW;

/* -----------------------------------------------------------------------------+
|   BUFR 입력 데이터 규격	                                                    |
+----------------------------------------------------------------------------- */

typedef struct
{
    BUFR_DATASET_WHAT       m_what;
    BUFR_WHERE              m_where;
    BUFR_HOW                m_how;
    char                    m_szClass[6+1];
    char                    m_szVersion[4+1];
    float                   **m_ppData;
} BUFR_DATA;

typedef struct
{
    BUFR_DATASET_WHAT       m_what;
    BUFR_WHERE              m_where;
    BUFR_HOW                m_how;
    int                     m_iMaxData;
    BUFR_DATA               **m_ppData;
} BUFR_DATASET;

typedef struct
{
    int                     m_iBufrType;
    char                    m_szConventions[16+1];
    BUFR_TOP_WHAT           m_what;
    BUFR_WHERE              m_where;
    BUFR_HOW                m_how;
    int                     m_iMaxDataset;
    BUFR_DATASET            **m_ppDataset;
} BUFR_RADAR;

/* -----------------------------------------------------------------------------+
|   BUFR 출력 데이터 규격	                                                    |
+----------------------------------------------------------------------------- */

typedef struct
{
    BUFR_DATASET_WHAT       m_what;
    char                    m_szFieldName[8+1];
    char                    m_szClass[6+1];
    char                    m_szVersion[4+1];
    int                     m_iMemType;
    char                    **m_ppData_c;
    short                   **m_ppData_s;
    float                   **m_ppData_f;
} BUFR_PRODUCT_DATA;

typedef struct
{
    BUFR_DATASET_WHAT       m_what;
    int                     m_iMaxField;
    BUFR_PRODUCT_DATA       **m_ppProductData;
} BUFR_PRODUCT_DATASET;

typedef struct
{
    int                     m_iMaxPpi;
    int                     m_iMaxCappi;
    int                     m_iMaxBase;
    int                     m_iMaxCmax;
    int                     m_iMaxVil;
    int                     m_iMaxEtop;
    BUFR_PRODUCT_DATASET    **m_ppPpi;
    BUFR_PRODUCT_DATASET    **m_ppCappi;
    BUFR_PRODUCT_DATASET    **m_ppBase;
    BUFR_PRODUCT_DATASET    **m_ppCmax;
    BUFR_PRODUCT_DATASET    **m_ppVil;
    BUFR_PRODUCT_DATASET    **m_ppEtop;
} BUFR_TOTAL_PRODUCT;

typedef struct
{
    int                     m_iBufrProductType;
    char                    m_szConventions[16+1];
    BUFR_TOP_WHAT           m_what;
    BUFR_WHERE              m_where;
    BUFR_HOW                m_how;
    BUFR_TOTAL_PRODUCT      m_totalProduct;
} BUFR_PRODUCT;

typedef struct
q
{
    char                    m_szProduct[6+1];
    double                  m_dProdpar;
    char                    m_szQuantity[6+1];
    float                   **m_ppData;
} BUFR_PRODUCT_READ_TMP;

typedef struct
{
    int                     m_iLonLatCnt;
    int                     m_iMaxData;
    int                     m_iCurData;
    BUFR_PRODUCT_READ_TMP   **m_ppTmpData;
} BUFR_PRODUCT_READ_TBL;

/* ================================================================================ */
// Input Function

/* -----------------------------------------------------------------------------+
|   BUFR 프로덕트 파일을 읽는다.                                                |
|   파라미터                                                                    |
|       char *szFile        : BUFR 프로덕트 파일 전체 경로                      |
|   반환값                                                                      |
|       BUFR 메모리 포인터 or NULL                                              |
|       메모리를 할당하기 때문에 fnFreeBufrRadar를 호출하여 해제해야 한다.      |
+----------------------------------------------------------------------------- */
BUFR_RADAR* fnLoadBufrRadar(char* szFile);

/* -----------------------------------------------------------------------------+
|   BUFR 데이터 메모리를 해제한다.                                              |
|   파라미터                                                                    |
|       BUFR_RADAR *pBufr   : BUFR 메모리 포인터                                |
+----------------------------------------------------------------------------- */
void fnFreeBufrRadar(BUFR_RADAR *pBufr);

/* -----------------------------------------------------------------------------+
|   BUFR 프로덕트 파일을 읽는다.                                                |
|   파라미터                                                                    |
|       char *szFile        : BUFR 프로덕트 파일 전체 경로                      |
|       char *szObject      : 데이터 종류 ( "COMP", "AZIM" )                    |
|   반환값                                                                      |
|       BUFR 프로덕트포맷 메모리 포인터 or NULL                                 |
|       메모리를 할당하기 때문에 fnFreeBufrProduct를 호출하여 해제해야 한다.    |
+----------------------------------------------------------------------------- */
BUFR_PRODUCT* fnLoadBufrProduct(char* szFile, char *szObject);

/* ================================================================================ */
// Output Function

/* -----------------------------------------------------------------------------+
|   BUFR 프로덕트포맷 메모리를 초기화 한다.                                     |
|   파라미터                                                                    |
|       int iMaxField   : 총 moment의 수                                        |
|       int iMaxPpi     : 총 PPI의 수                                           |
|       int iMaxCappi   : 총 CAPPI의 수                                         |
|       int iMaxBase    : 총 BASE의 수                                          |
|       int iMaxCmax    : 총 CMAX의 수                                          |
|       int iMaxVil     : 총 VIL의 수                                           |
|       int iMaxEtop    : 총 ETOP의 수                                          |
|   반환값                                                                      |
|       BUFR 프로덕트포맷 메모리 포인터 or NULL                                 |
|       메모리를 할당하기 때문에 fnFreeBufrProduct를 호출하여 해제해야 한다.    |
+----------------------------------------------------------------------------- */
BUFR_PRODUCT* fnInitBufrProduct(int iMaxField, int iMaxPpi, int iMaxCappi, int iMaxBase, int iMaxCmax, int iMaxVil, int iMaxEtop);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷을 확인하여 BUFR 프로덕트 포맷을 초기화한다.              |
|   파라미터                                                                    |
|       void    *pStdPtr: 표준 프로덕트 포멧 메모리 포인터                      |
|                         함수 내부에서 캐스팅한다.                             |
|   반환값                                                                      |
|       BUFR 출력포맷 메모리 포인터 or NULL                                     |
|       메모리를 할당하기 때문에 fnFreeBufrProduct를 호출하여 해제해야 한다.    |
+----------------------------------------------------------------------------- */
BUFR_PRODUCT* fnInitBufrProductToStdProduct(void *pStdPtr);

/* -----------------------------------------------------------------------------+
|   BUFR 프로덕트 메모리를 해제 한다.                                           |
|   파라미터                                                                    |
|       BUFR_PRODUCT *pBufrProduct   : Bufr 프로덕트포맷의 메모리 포인터        |
+----------------------------------------------------------------------------- */
void fnFreeBufrProduct(BUFR_PRODUCT *pBufrProduct);

/* -----------------------------------------------------------------------------+
|   BUFR 프로덕트 포맷을 파일로 저장한다.                                       |
|   파라미터                                                                    |
|       BUFR_PRODUCT *pBufrProduct  : Bufr 프로덕트포맷의 메모리 포인터         |
|       char        *szFileName     : 저장 파일의 전체 경로 및 이름             |       
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnWriteBufrProduct(BUFR_PRODUCT *pBufrProduct, char* szFileName);

/* -----------------------------------------------------------------------------+
|   BUFR 프로덕트 포맷의 각 산출물 및 Moment의 최대 개수를 구한다.              |
|   파라미터                                                                    |
|       BUFR_PRODUCT *pBufrProduct  : BUFR 프로덕트 포맷 메모리 포인터          |
|       int *pMaxField              : Moment 개수 버퍼 포인터                   |
|       int *pMaxPpi                : PPI    개수 버퍼 포인터                   |
|       int *pMaxCappi              : CAPPI  개수 버퍼 포인터                   |
|       int *pMaxBase               : BASE   개수 버퍼 포인터                   |
|       int *pMaxCmax               : CMAX   개수 버퍼 포인터                   |
|       int *pMaxVil                : VIL    개수 버퍼 포인터                   |
|       int *pMaxEtop               : ETOP   개수 버퍼 포인터                   |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnGetMaxCountBufrProduct(BUFR_PRODUCT *pBufrProduct, int *pMaxField, int *pMaxPpi, int *pMaxCappi, int *pMaxBase, int *pMaxCmax, int *pMaxVil, int *pMaxEtop);

/* -----------------------------------------------------------------------------+
|   BUFR  포맷의 최대 개수를 구한다.                                            |
|   파라미터                                                                    |
|       BUFR_RADAR   *pBufr : BUFR 프로덕트 포맷 메모리 포인터                  |
|       int *pMaxDataset    : 데이터셋 개수 버퍼 포인터                         |
|       int *pMaxData       : 데이터   개수 버퍼 포인터                         |
|       int *pMaxRay        : Ray      개수 버퍼 포인터                         |
|       int *pMaxbin        : Bin      개수 버퍼 포인터                         |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnGetMaxCountBufrRadar(BUFR_RADAR *pBufr, int *pMaxDataset, int *pMaxData, int *pMaxRay, int *pMaxBin);

/* ================================================================================ */

#endif


