/* ================================================================================ */
//
// Radar CSV Output Function
//
// 2016.11.02 SnK 
//
/* ================================================================================ */

#ifndef RDR_IO_CSV_H
#define RDR_IO_CSV_H

/* ================================================================================ */
// Define



/* ================================================================================ */
// Enum



/* ================================================================================ */
// Struct



/* ================================================================================ */
// Function

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷의 사이트자료를 CSV 형식으로 저장한다.                    |
|   개별 형식으로 저장후 szOutFile.zip 으로 압축 한다.                          |
|   파라미터                                                                    |
|       STD_PRODUCT* pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char *szProduct             : 프로덕트 이름 ("PPI, "CAPPI", ... )       |
|       char *szCsvFormat           : 개별 저장 파일의 이름 형식                |
|       char *szOutFile             : 저장 파일 이름                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnWriteStdProductCsvSite(STD_PRODUCT *pStdProduct, char *szProduct, char *szCsvForamt, char *szOutFile);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷의 연직3차원 사이트를 CSV 형식으로 저장한다.              |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char *szProduct             : 프로덕트 이름 ("CAPPI")                   |
|       char *szFieldName           : 필드이름 ("CZ"...)                        |
|       int iCappiCnt               : 3D 연직 개수                              |
|       float fCrossGridKm          : 연직 격자 간격                            |
|       char *szOutFile             : 저장 파일 이름                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnWriteStdProductCsvSite3D(STD_PRODUCT *pStdProduct, char *szProduct, char *szFieldName, int iCappiCnt, float fCrossGridKm, char *szOutFile);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷의 240km 합성장을 CSV 형식으로 저장한다.                  |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char *szProduct             : 프로덕트 이름 ("PPI, "CAPPI", ... )       |
|       char *szFieldName           : 필드이름 ("CZ")                           |
|       char *szOutFile             : 저장 파일 이름                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnWriteStdProductCsvComp240(STD_PRODUCT *pStdProduct, char *szProduct, char *szFieldName, char *szOutFile);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷의 480km 합성장을 CSV 형식으로 저장한다.                  |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char *szProduct             : 프로덕트 이름 ("PPI")                     |
|       char *szFieldName           : 필드이름 ("CZ")                           |
|       char *szOutFile             : 저장 파일 이름                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnWriteStdProductCsvComp480(STD_PRODUCT *pStdProduct, char *szProduct, char *szFieldName, char *szOutFile);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷의 동아시아 합성장을 CSV 형식으로 저장한다.               |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char *szProduct             : 프로덕트 이름 ("PPI")                     |
|       char *szFieldName           : 필드이름 ("CZ")                           |
|       char *szOutFile             : 저장 파일 이름                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnWriteStdProductCsvCompKCJ(STD_PRODUCT *pStdProduct, char *szProduct, char *szFieldName, char *szOutFile);

/* -----------------------------------------------------------------------------+
|   표준 프로덕트 포맷의 연직3차원 합성장을 CSV 형식으로 저장한다.              |
|   파라미터                                                                    |
|       STD_PRODUCT *pStdProduct    : 표준 프로덕트 포맷 메모리 포인터          |
|       char *szProduct             : 프로덕트 이름 ("CAPPI")                   |
|       char *szFieldName           : 필드이름 ("CZ")                           |
|       int iCappiCnt               : 3D 연직 개수                              |
|       float fCrossGridKm          : 연직 격자 간격                            |
|       char *szOutFile             : 저장 파일 이름                            |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnWriteStdProductCsvComp3D(STD_PRODUCT *pStdProduct, char *szProduct, char *szFieldName, int iCappiCnt, float fCrossGridKm, char *szOutFile);

/* ================================================================================ */

#endif

