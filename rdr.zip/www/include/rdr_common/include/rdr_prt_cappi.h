/* ================================================================================ */
//
// Radar Create CAPPI Header
//
// 2016.08.09 SnK 
//
/* ================================================================================ */

#ifndef RDR_PRT_CAPPI_H
#define RDR_PRT_CAPPI_H

/* ================================================================================ */
// Define

#define     RDR_DF_ELEV_LIMIT               (2.0)
#define     RDR_DF_AZIM_LIMIT               (1.0)

#define     RDR_DF_CROSS_ELEV_LIMIT         (3.0)
#define     RDR_DF_CROSS_AZIM_LIMIT         (1.0)

/* ================================================================================ */
// Enum

typedef enum
{
    RDR_EN_PSEUDO_CAPPI = 1,
    RDR_EN_REAL_CAPPI
} RDR_EN_CAPPI_TYPE;

/* ================================================================================ */
// Struct


/* -----------------------------------------------------------------------------+
|   Mohr CAPPI 생성을 위한 구조체
+----------------------------------------------------------------------------- */
typedef struct
{
    int             m_valid[2];
    float           m_dBZ[2];//dBZ
    int             m_bin_num[2];
    float           m_R[2];//meter
} CLOEST_VALUES;

typedef struct
{
    int             m_valid[2];
    STD_RAY*         m_ray[2];
    CLOEST_VALUES   m_values[2];
    float           m_theta[2];//azimuth
} CLOEST_AZIMS;

typedef struct
{
    int             m_valid[2];
    int             m_swIdx[2];
    STD_SWEEP*       m_sweep[2];
    CLOEST_AZIMS    m_azims[2];
    float           m_phi[2];//elevation
} CLOEST_SWEEPS;

/* -----------------------------------------------------------------------------+
|   Real CAPPI 생성을 위한 구조체
+----------------------------------------------------------------------------- */
typedef struct
{
    float           m_fElev;
    float           m_fSrange;
} CAPPI_LOC;

/* ================================================================================ */
// Function

/* -----------------------------------------------------------------------------+
|   Mohr 방식의 CAPPI를 생성 한다.                                              |
|   파라미터                                                                    |
|       STD_RADAR *pStd             : 표준데이터 포맷 메모리 포인터             |
|       float fCappiHeightKm        : 생성할 Cappi 고도 ( Km )                  |
|       int iXDim                   : Xdim 사이즈                               |
|       int iYDim                   : Ydim 사이즈                               |
|       float fMaxRangeKm           : 최대 관측 거리 ( Km )                     |
|       float fGridKm               : 격자 크기                                 |
|       int iCappiKind              : Cappi 종류                                |
|       int iYesCross               : 연직단면에 사용되는지 여부                |
|       char* szFieldName           : moment 문자열                             |
|       STD_AZIMUTH_TBL **ppTable   : 전체 Sweep의 Hash Table                   |
|   반환값                                                                      |
|       Cappi 1차원 배열 포인터 or NULL                                         |
|       메모리를 할당하여 반환 하기 때문에 free 해야 한다.                      |
+----------------------------------------------------------------------------- */
float* fnCreateCappiMohr(STD_RADAR *pStd, float fCappiHeightKm, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, int iCappiKind, int iYesCross, char* szFieldName, STD_AZIMUTH_TBL **ppTable);

/* -----------------------------------------------------------------------------+
|   Real 방식의 CAPPI를 생성 한다.                                              |
|   파라미터                                                                    |
|       STD_RADAR *pStd             : 표준데이터 포맷 메모리 포인터             |
|       float fCappiHeightKm        : 생성할 Cappi 고도 ( Km )                  |
|       int iXDim                   : Xdim 사이즈                               |
|       int iYDim                   : Ydim 사이즈                               |
|       float fMaxRangeKm           : 최대 관측 거리 ( Km )                     |
|       float fGridKm               : 격자 크기                                 |
|       char* szFieldName           : moment 문자열                             |
|       STD_AZIMUTH_TBL **ppTable   : 전체 Sweep의 Hash Table                   |
|   반환값                                                                      |
|       Cappi 1차원 배열 포인터 or NULL                                         |
|       메모리를 할당하여 반환 하기 때문에 free 해야 한다.                      |
+----------------------------------------------------------------------------- */
float* fnCreateCappiReal(STD_RADAR *pStd, float fCappiHeightKm, int iXdim, int iYdim, float fMaxRangeKm, float fGridKm, char* szFieldName, STD_AZIMUTH_TBL **ppTable);

/* ================================================================================ */

#endif

