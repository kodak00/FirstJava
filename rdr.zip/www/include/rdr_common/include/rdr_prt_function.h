/* ================================================================================ */
//
// Radar Function Header
//
// 2016.08.09 SnK 
//
/* ================================================================================ */

#ifndef RDR_PRT_FUNCTION_H
#define RDR_PRT_FUNCTION_H

/* ================================================================================ */
// Define

#define RDR_DF_DEL_INDEPENT_ECHO_CNT    (4)

/* ================================================================================ */
// Function

/* -----------------------------------------------------------------------------+
|   X, Y 좌표값을 받아 방위각을 계산한다. ( 원점 0,0 )                          |
|   파라미터                                                                    |
|       int iYidx   : Y축 좌표값                                                |
|       int iXidx   : X축 좌표값                                                |
|   반환값                                                                      |
|       방위각                                                                  |
+----------------------------------------------------------------------------- */
float fnCalcAzimuthToXY(int iYidx, int iXidx);

/* -----------------------------------------------------------------------------+
|   X, Y 좌표값을 받아 방위각을 계산한다. ( 원점 0,0 )                          |
|   파라미터                                                                    |
|       float fPointX   : X축 좌표값                                            |
|       float fPointY   : Y축 좌표값                                            |
|   반환값                                                                      |
|       방위각                                                                  |
+----------------------------------------------------------------------------- */
float fnGetAzimuth(float fPointX, float fPointY);

/* -----------------------------------------------------------------------------+
|   방위각을 통하여 Sweep에서 Ray를 찾는다.                                     |
|   파라미터                                                                    |
|       STD_SWEEP *pSweep       : Sweep의 메모리 포인터                         |
|       float fRes              : Hash 파라미터 ( 360.0/Ray의수 )               |
|       float fAzim             : 방위각                                        |
|       STD_AZIMUTH_TBL pTable[]: Hash Table                                    |
|   반환값                                                                      |
|       Ray Index or -1                                                         |
+----------------------------------------------------------------------------- */
int fnSearchRayToAzim(STD_SWEEP *pSweep, float fRes, float fAzim, STD_AZIMUTH_TBL pTable[RDR_DF_MAX_RAY]);

/* -----------------------------------------------------------------------------+
|   거리를 통하여 Ray에서 Bin에 해당하는 변수값을 가져온다.                     |
|   파라미터                                                                    |
|       STD_RAY *pRay       : Ray 메모리 포인터                                 |
|       int iFieldIdx       : Field Index                                       |
|       float fRangeKm      : 거리 ( Km )                                       |
|       int iNoDataValue    : UF내에 저장되어있는 관측안됬을때 값               |
|                             변수값으로 변환하는데 필요한 값                   |
|   반환값                                                                      |
|       변수값 or RDR_BADVAL                                                    |
+----------------------------------------------------------------------------- */
float fnGetBinValueToRay(STD_RAY *pRay, int iFieldIdx, float fRangeKm, int iNoDataValue);

/* -----------------------------------------------------------------------------+
|   프로덕트 산출물의 관측반경 처리                                             |
|   파라미터                                                                    |
|       float *pData    : 산출물 배열                                           |
|       int iYdim       : 산출물의 Ydim                                         |
|       int iXdim       : 산출물의 Xdim                                         |
|       float fGridKm   : 산출물의 그리드                                       |
|       float fMaxRange : 산출물의 최대 관측 거리                               |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnProcOutBound(float *pData, int iYdim, int iXdim, float fGridKm, float fMaxRange);

/* -----------------------------------------------------------------------------+
|   독릭에코를 제거 한다.                                                       |
|   파라미터                                                                    |
|       float *pData    : 산출물 배열                                           |
|       int iYdim       : 산출물의 Ydim                                         |
|       int iXdim       : 산출물의 Xdim                                         |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnDeleteIndenpentEcho(float *pData, int iYdim, int iXdim);

/* -----------------------------------------------------------------------------+
|   PPI의 Ray 방위각 문제로 빈 공간이 생길 수 있어 채워주는 함수                |
|   파라미터                                                                    |
|       float *pData    : 산출물 배열                                           |
|       int iYdim       : 산출물의 Ydim                                         |
|       int iXdim       : 산출물의 Xdim                                         |
|   반환값                                                                      |
|       TRUE or FALSE                                                           |
+----------------------------------------------------------------------------- */
int fnFillSpaceData(float *pData, int iYdim, int iXdim);

/* ================================================================================ */

#endif

