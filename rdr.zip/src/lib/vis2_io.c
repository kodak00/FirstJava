#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "aws_data.h"
#include "aws2_data.h"

#define  MAXLINE  1024
#define  VIS_DIR  "/C4N_DATA/DATA/VIS/VISDB"

void vis2io_error();

/*****************************************************************************
 *
 *  VISM �ڷῡ�� � ����Ͻú��� AWS �ź��ڷḦ ó��
 *
 *****************************************************************************/
int
VISM2_IO
(
    int    YY,                  /* �� */
    int    MM,                  /* �� */
    int    DD,                  /* �� */
    int    HH,                  /* �� */
    int    MI,                  /* �� */
    int    aws_id,              /* aws_id > -1 (�ش�����), aws_id = -1 (��ü����) */
    struct AWS2_DATA  aws[],    /* AWS �ڷ� */
    char   mode                 /* 'r' : �б� (���� 0, ���� < 0) */
                                /* 'w' : ���� (���� 0, ���� < 0) */
                                /* 'c' : ���ϴݱ� */
)
{
    static FILE  *fd;
    static int   fnode = -1;
    static char  rw = 'r';
    long   offset = 0;
    char   dname[120], tmp[MAXLINE];
    int    node, nstn, nio, code;

    /*
    File Close & ID range check
    */

    if (mode == 'c')
    {
        if (fd != NULL) fclose(fd);
        fd = NULL;
        fnode = -1;
        rw = 'r';
        return 0;
    }
    if (aws_id >= 1000) aws_id %= 1000;

    /*
    File Open
    */

    node = ((YY*100 + MM)*100 + DD)*100 + HH;
    if (node != fnode || (rw != 'w' && mode == 'w'))
    {
        if (fd != NULL) fclose(fd);
        if (rw != 'w' && mode == 'w') rw = mode;

        sprintf(dname, "%s/%04d%02d/%02d/VISM_%04d%02d%02d%02d", VIS_DIR, YY, MM, DD, YY, MM, DD, HH);

        if (rw == 'w')
            fd = fopen(dname, "rb+");
        else
            fd = fopen(dname, "rb");

        if (fd == NULL)
        {
            sprintf(tmp, "[ VISM ] File not opened (%s,%c)", dname, rw);
            vis2io_error(&fnode, &offset, tmp);
            return -1;
        }
        else
        {
            fnode = node;
        }
    }

    /*
    Move to Read Pointer
    */

    offset = MI * NUM_AWS2 * AWS2_DATA_len;
    if (aws_id < 0)
    {
        nstn = NUM_AWS2;
    }
    else
    {
        offset += aws_id * AWS2_DATA_len;
        nstn = 1;
    }

    if (fseek(fd, offset, SEEK_SET) != 0)
    {
        sprintf(tmp, "[ VISM ] fseek error (%s,%d)", dname, offset);
        vis2io_error(&fnode, &offset, tmp);
        return -3;
    }

    /*
    Data Read & Write
    */
   
    if      (mode == 'r') nio = fread(aws, AWS2_DATA_len, nstn, fd);
    else if (mode == 'w') nio = fwrite(aws, AWS2_DATA_len, nstn, fd);

    if (nio != nstn)
    {
        sprintf(tmp, "[ VISM ] IO error (%c,%04d%02d%02d%02d%02d_%d)",
                mode, YY, MM, DD, HH, MI, aws_id);
        vis2io_error(&fnode, &offset, tmp);
        return -4;
    }
    return 0;
}

/*****************************************************************************
 *
 *  QC�ڷḦ ������ AWS �����ڷḦ MASKING �ϴ� ��ƾ
 *
 *****************************************************************************/
int
VIS_QCD
(
    struct AWS2_DATA  aws[]
)
{
    char qcd[AWS2_DATA_dnum];
    unsigned long q;
    int  i, j, k;

    for (k = 0; k < 8; k++)
    {
        if (k == 2 || k >= 4) continue;     /* RQMOD ���� �̻��Ͽ� ������ */

        q = aws[0].qc[k];

        for (i = 0; i < AWS2_DATA_dnum; i++)
        {
            qcd[i] = q & 0x0000000000000001;
            q = q >> 1;
        }

        for (i = 0; i < AWS2_DATA_dnum; i++)
        {
            if (qcd[i] == 1)
            {
                aws[0].d[i] = -998 + k;
            }
        }
    }
    return 0;
}

/*****************************************************************************
 *
 *  VISM �ڷῡ�� � ����Ͻú��� AWS �ź��ڷḦ ����
 *
 *****************************************************************************/
int
QVISM2_READ
(
    int    YY,                  /* �� */
    int    MM,                  /* �� */
    int    DD,                  /* �� */
    int    HH,                  /* �� */
    int    MI,                  /* �� */
    int    aws_id,              /* AWS ID (1�� ������ ����) */
    struct AWS2_DATA  aws[],    /* AWS �ڷ� */
    char   mode                 /* 'q' : �ش�ð��� �ڷḸ ���� (���� 0, ���� < 0)  */
                                /* 'r' : ���� 5�а��� �ڷῡ�� ���� (���� 0, ���� < 0) */
)
{
    struct AWS2_DATA  aws1[5];
    int    d[5], code = -1;
    int    seq, i;

    /*
    ID ���� ����
    */

    if (aws_id < 0) return -2;

    /*
    �ش� �ð� ����
    */

    code = VISM2_IO(YY, MM, DD, HH, MI, aws_id, aws, 'r');
    if (code >= 0) VIS_QCD(&aws[0]);
    if (mode == 'q' || code >= 0) return code;

    /*
    ���� ���, ���� 5�е��ȿ��� �ڷḦ ã��
    */

    seq = time2seq(YY, MM, DD, HH, MI, 'm') - 5;

    for (i = 4; i >= 0; i--)
    {
        seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
        code = VISM2_IO(YY, MM, DD, HH, MI, aws_id, &aws1[i], 'r');

        d[i] = 0;
        if (code >= 0) d[i] = 1;
        seq++;
    }

    code = -1;
    for (i = 0; i < 5; i++)
    {
        if (d[i])
        {
            aws[0] = aws1[i];
            VIS_QCD(&aws[0]);
            code = 0;
            break;
        }
    }
    return code;
}

/*****************************************************************************
 *
 *  VISD �ڷῡ�� � ������� AWS ���ڷḦ ó��
 *
 *****************************************************************************/
int
VISD2_IO
(
    int    YY,                  /* �� */
    int    MM,                  /* �� */
    int    DD,                  /* �� */
    int    aws_id,              /* aws_id > -1 (�ش�����), aws_id = -1 (��ü����) */
    struct AWS2_DAY  aws[],     /* AWS ���ڷ� */
    char   mode                 /* 'r' : �б� (���� 0, ���� < 0) */
                                /* 'w' : ���� (���� 0, ���� < 0) */
                                /* 'c' : ���ϴݱ� */
)
{
    static FILE  *fd;
    static int   fnode = -1;
    static char  rw = 'r';
    long   offset = 0;
    char   dname[120], tmp[MAXLINE];
    int    node, nstn, nio, code;

    /*
    File Close & ID range check
    */

    if (mode == 'c')
    {
        if (fd != NULL) fclose(fd);
        fd = NULL;
        fnode = -1;
        rw = 'r';
        return 0;
    }
    if (aws_id >= 1000) aws_id %= 1000;

    /*
    File Open
    */

    node = (YY*100 + MM)*100 + DD;
    if (node != fnode || (rw != 'w' && mode == 'w'))
    {
        if (fd != NULL) fclose(fd);
        if (rw != 'w' && mode == 'w') rw = mode;

        sprintf(dname, "%s/%04d%02d/%02d/VISD_%04d%02d%02d", VIS_DIR, YY, MM, DD, YY, MM, DD);

        if (rw == 'w')
            fd = fopen(dname, "rb+");
        else
            fd = fopen(dname, "rb");

        if (fd == NULL)
        {
            sprintf(tmp, "[ VISD ] File not opened (%s,%c)", dname, rw);
            vis2io_error(&fnode, &offset, tmp);
            return -1;
        }
        else
        {
            fnode = node;
        }
    }

    /*
    Move to Read Pointer
    */

    if (aws_id < 0)
    {
        offset = 0;
        nstn = NUM_AWS2;
    }
    else
    {
        offset = aws_id * AWS2_DAY_len;
        nstn = 1;
    }

    if (fseek(fd, offset, SEEK_SET) != 0)
    {
        sprintf(tmp, "[ VISD ] fseek error (%s,%d)", dname, offset);
        vis2io_error(&fnode, &offset, tmp);
        return -3;
    }

    /*
    Data Read & Write
    */

    if      (mode == 'r') nio = fread(aws, AWS2_DAY_len, nstn, fd);
    else if (mode == 'w') nio = fwrite(aws, AWS2_DAY_len, nstn, fd);

    if (nio != nstn)
    {
        sprintf(tmp, "[ VISD ] IO error (%c,%04d%02d%02d_%d)",
                mode, YY, MM, DD, aws_id);
        vis2io_error(&fnode, &offset, tmp);
        return -4;
    }
    return 0;
}

/*****************************************************************************
 *
 *  AWS �ź� �� �����ڷ� �ʱ�ȭ
 *
 *    o ID, ������ : -999,  �ð� : 0
 *
 *****************************************************************************/
int
VIS_DATA_ini
(
    struct AWS2_DATA *aws
)
{
    int  i;

    (*aws).aws_id = -999;   (*aws).lau_id = -999;
    (*aws).aws_tm.YY = 0;   (*aws).aws_tm.MM = 0;   (*aws).aws_tm.DD = 0;
    (*aws).aws_tm.HH = 0;   (*aws).aws_tm.MI = 0;
    (*aws).lau_tm.YY = 0;   (*aws).lau_tm.MM = 0;   (*aws).lau_tm.DD = 0;
    (*aws).lau_tm.HH = 0;   (*aws).lau_tm.MI = 0;
    (*aws).rec_tm.YY = 0;   (*aws).rec_tm.MM = 0;   (*aws).rec_tm.DD = 0;
    (*aws).rec_tm.HH = 0;   (*aws).rec_tm.MI = 0;

    for (i = 0; i < AWS2_DATA_dnum; i++) (*aws).d[i] = -999;
    for (i = 0; i <  8; i++) (*aws).qc[i] = 0;

    return 0;
}

/*****************************************************************************
 *  Error message print
 *****************************************************************************/
void
vis2io_error
(
    int  *fnode,
    long *offset,
    char *s
)
{
    int mode = 1;

    *fnode = -1;
    *offset = 0;

    if (strlen(s) > 0 && mode)
    {
        strcat(s, " : ");
        strcat(s, strerror(errno));
        strcat(s, "\n");
        fputs(s, stdout);
    }
    return;
}
