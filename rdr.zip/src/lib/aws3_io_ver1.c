#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "cgiutil.h"
#include "aws3_data.h"

extern FILE   *fp_log;
void   aws3_io_error();

/*****************************************************************************
 *
 *  AWS3 DATA �ڷῡ�� � ����Ͻú��� AWS �ź��ڷḦ ó��
 *
 *****************************************************************************/
int AWS3_DATA_IO (
  int    YY,                  /* �� */
  int    MM,                  /* �� */
  int    DD,                  /* �� */
  int    HH,                  /* �� */
  int    MI,                  /* �� */
  int    aws_id,              /* aws_id > -1 (�ش�����), aws_id = -1 (��ü����) */
  struct AWS3_DATA  aws[],    /* AWS3 DATA �ڷ� */
  char   mode                 /* 'r' : �б� (���� 0, ���� < 0) */
                              /* 'w' : ���� (���� 0, ���� < 0) */
                              /* 'c' : ���ϴݱ� */
)
{
  static FILE  *fp;
  static int   fnode = -1;
  static char  rw = 'r';
  long   offset = 0;
  char   dname[120];
  int    node, nstn, nio, code;

  // File Close & ID range check
  if (mode == 'c') {
    if (fp != NULL) fclose(fp);
    fp = NULL;
    fnode = -1;
    rw = 'r';
    return 0;
  }
  if (aws_id >= NUM_AWS3) aws_id %= NUM_AWS3;

  // File Open
  node = ((YY*100 + MM)*100 + DD)*100 + HH;
  if (node != fnode || (rw != 'w' && mode == 'w')) {
    if (fp != NULL) fclose(fp);
    if (rw != 'w' && mode == 'w') rw = mode;
    sprintf(dname, "%s/%04d%02d/%02d/AWS3_MIN_%04d%02d%02d%02d", AWS3_DIR, YY, MM, DD, YY, MM, DD, HH);

    if (rw == 'w')
      fp = fopen(dname, "rb+");
    else
      fp = fopen(dname, "rb");

    if (fp == NULL) {
      fprintf(fp_log, "[ AWS3 DATA ] File not opened (%s,%c)", dname, rw);
      return -1;
    }
    else {
      fnode = node;
    }
  }

  // Move to Read Pointer
  offset = MI * NUM_AWS3 * AWS3_DATA_len;
  if (aws_id < 0)
    nstn = NUM_AWS3;
  else {
    offset += aws_id * AWS3_DATA_len;
    nstn = 1;
  }

  if (fseek(fp, offset, SEEK_SET) != 0) {
    fprintf(fp_log, "[ AWS3 DATA ] fseek error (%s,%d)", dname, offset);
    return -3;
  }

  // Data Read & Write
  if (mode == 'r')
    nio = fread(aws, AWS3_DATA_len, nstn, fp);
  else if (mode == 'w') {
    nio = fwrite(aws, AWS3_DATA_len, nstn, fp);
    fflush(fp);
  }

  if (nio != nstn) {
    fprintf(fp_log, "[ AWS3 DATA ] IO error (%c,%04d%02d%02d%02d%02d_%d)",
            mode, YY, MM, DD, HH, MI, aws_id);
    return -4;
  }
  return 0;
}

/*****************************************************************************
 *
 *  AWS3 DATA �ڷῡ�� � ����Ͻú��� AWS �ź��ڷ��� LAU�κ��� ó��
 *
 *****************************************************************************/
int AWS3_RCV_IO (
  int    YY,                  /* �� */
  int    MM,                  /* �� */
  int    DD,                  /* �� */
  int    HH,                  /* �� */
  int    MI,                  /* �� */
  int    aws_id,              /* aws_id */
  struct AWS3_RCV aws[],      /* AWS3 RCV �ڷ� */
  char   mode                 /* 'r' : �б� (���� 0, ���� < 0) */
                              /* 'w' : ���� (���� 0, ���� < 0) */
                              /* 'c' : ���ϴݱ� */
)
{
  static FILE  *fp;
  static int   fnode = -1;
  static char  rw = 'r';
  long   offset = 0;
  char   dname[120];
  int    node, nstn, nio, code;

  // AWS ID ����
  if (aws_id < 0 || aws_id >= NUM_AWS3)
    return -9;

  // File Close & ID range check
  if (mode == 'c') {
    if (fp != NULL) fclose(fp);
    fp = NULL;
    fnode = -1;
    rw = 'r';
    return 0;
  }
  if (aws_id >= NUM_AWS3) aws_id %= NUM_AWS3;

  // File Open
  node = ((YY*100 + MM)*100 + DD)*100 + HH;
  if (node != fnode || (rw != 'w' && mode == 'w')) {
    if (fp != NULL) fclose(fp);
    if (rw != 'w' && mode == 'w') rw = mode;
    sprintf(dname, "%s/%04d%02d/%02d/AWS3_MIN_%04d%02d%02d%02d", AWS3_DIR, YY, MM, DD, YY, MM, DD, HH);

    if (rw == 'w')
      fp = fopen(dname, "rb+");
    else
      fp = fopen(dname, "rb");

    if (fp == NULL) {
      fprintf(fp_log, "[ AWS3 RCV ] File not opened (%s,%c)", dname, rw);
      return -1;
    }
    else {
      fnode = node;
    }
  }

  // Move to Read Pointer
  offset = MI * NUM_AWS3 * AWS3_DATA_len;
  offset += aws_id * AWS3_DATA_len;
  nstn = 1;

  if (fseek(fp, offset, SEEK_SET) != 0) {
    fprintf(fp_log, "[ AWS3 RCV ] fseek error (%s,%d)", dname, offset);
    return -3;
  }

  // Data Read & Write
  if (mode == 'r')
    nio = fread(aws, AWS3_RCV_len, nstn, fp);
  else if (mode == 'w') {
    nio = fwrite(aws, AWS3_RCV_len, nstn, fp);
    fflush(fp);
  }

  if (nio != nstn) {
    fprintf(fp_log, "[ AWS3 RCV ] IO error (%c,%04d%02d%02d%02d%02d_%d)",
            mode, YY, MM, DD, HH, MI, aws_id);
    return -4;
  }
  return 0;
}

/*****************************************************************************
 *
 *  AWS3 DATA �ڷῡ�� � ����Ͻú��� AWS�� Ư�� �ʵ��� ���� �аų� ����
 *
 *****************************************************************************/
int AWS3_FIELD_IO (
  int    YY,                  /* �� */
  int    MM,                  /* �� */
  int    DD,                  /* �� */
  int    HH,                  /* �� */
  int    MI,                  /* �� */
  int    aws_id,              /* aws_id >= 0 (�ش�����) */
  int    fd,                  /* AWS3 DATA�� Ư�� �ʵ��� ����(0~63) */
  short  *d1,                 /* AWS3 DATA�� Ư�� �ʵ��� �� */
  char   mode                 /* 'r' : �б� (���� 0, ���� < 0) */
                              /* 'w' : ���� (���� 0, ���� < 0) */
                              /* 'c' : ���ϴݱ� */
)
{
  static FILE  *fp;
  static int   fnode = -1;
  static char  rw = 'r';
  long   offset = 0;
  char   dname[120];
  int    node, nstn, nio, code;

  // AWS ID ����
  if (aws_id < 0 || aws_id >= NUM_AWS3)
    return -9;

  // File Close & ID range check
  if (mode == 'c') {
    if (fp != NULL) fclose(fp);
    fp = NULL;
    fnode = -1;
    rw = 'r';
    return 0;
  }
  if (aws_id >= NUM_AWS3) aws_id %= NUM_AWS3;

  // File Open
  node = ((YY*100 + MM)*100 + DD)*100 + HH;
  if (node != fnode || (rw != 'w' && mode == 'w')) {
    if (fp != NULL) fclose(fp);
    if (rw != 'w' && mode == 'w') rw = mode;
    sprintf(dname, "%s/%04d%02d/%02d/AWS3_MIN_%04d%02d%02d%02d", AWS3_DIR, YY, MM, DD, YY, MM, DD, HH);

    if (rw == 'w')
      fp = fopen(dname, "rb+");
    else
      fp = fopen(dname, "rb");

    if (fp == NULL) {
      fprintf(fp_log, "[ AWS3 FIELD ] File not opened (%s,%c)", dname, rw);
      return -1;
    }
    else {
      fnode = node;
    }
  }

  // Move to Read Pointer
  offset = MI * NUM_AWS3 * AWS3_DATA_len;
  offset += (aws_id * AWS3_DATA_len + 2 + 6 + fd*2);
  nstn = 1;

  if (fseek(fp, offset, SEEK_SET) != 0) {
    fprintf(fp_log, "[ AWS3 FIELD ] fseek error (%s,%d)", dname, offset);
    return -3;
  }

  // Data Read & Write
  if (mode == 'r')
    nio = fread(d1, 2, 1, fp);
  else if (mode == 'w') {
    nio = fwrite(d1, 2, 1, fp);
    fflush(fp);
  }

  if (nio != 1) {
    fprintf(fp_log, "[ AWS3 FIELD ] IO error (%c,%04d%02d%02d%02d%02d_%d)",
            mode, YY, MM, DD, HH, MI, aws_id);
    return -4;
  }
  return 0;
}

/*****************************************************************************
 *
 *  QC�ڷḦ ������ AWS �����ڷḦ MASKING �ϴ� ��ƾ
 *
 *****************************************************************************/
int AWS3_QCD (
  struct AWS3_DATA  aws[],
  struct AWS3_QCD   qcd[]
)
{
  unsigned long q, q1;
  int   d[AWS3_RCV_dnum];
  int   i, j, k;

  // �ʱ�ȭ
  for (i = 0; i < AWS3_RCV_dnum; i++)
    d[i] = 0;

  for (k = 7; k >= 1; k--) {  // �����ü ���˰��(k=0)�� ������� ����

    for (q = qcd[0].qc[k], i = 0; i < AWS3_RCV_dnum; i++, q = q >> 1) {
      if (d[i] > k) continue;   // ���� ���˿� üũ�Ǿ����� �� üũ���� ����

      q1 = q & 0x0000000000000001;
      if (q1 == 1) {
        if (d[i] < k) {
          // k=7�� QC�� �ɸ����� ���� �ڷḦ �����ϴ� ����
          if (k < 7) aws[0].d[i] = -998 + k;
          d[i] = k;
        }
      }
    }
  }
  return 0;
}

/*****************************************************************************
 *
 *  QC�ڷḦ ������ Ư�� �ʵ��� AWS �����ڷḦ MASKING �ϴ� ��ƾ
 *
 *****************************************************************************/
int AWS3_QCD_FIELD (
  struct AWS3_DATA  aws[],
  struct AWS3_QCD   qcd[],
  int    fn    // Ư�� �ʵ��ȣ(0~AWS3_RCV_dnum)
)
{
  unsigned long q, q1;
  int   d1 = 0;
  int   i, j, k;

  for (k = 7; k >= 1; k--) {  // �����ü ���˰��(k=0)�� ������� ����
    if (d1 > k) continue;   // ���� ���˿� üũ�Ǿ����� �� üũ���� ����
    q1 = (qcd[0].qc[k] >> fn) & 0x0000000000000001;
    if (q1 == 1) {
      if (d1 < k) {
        // k=7�� QC�� �ɸ����� ���� �ڷḦ �����ϴ� ����
        if (k < 7) aws[0].d[fn] = -998 + k;
        d1 = k;
      }
    }
  }
  return 0;
}

/*****************************************************************************
 *
 *  AWS3 QCD �ڷῡ�� � ����Ͻú��� AWS �ź��ڷḦ ó��
 *
 *****************************************************************************/
int AWS3_QCD_IO (
  int    YY,                  /* �� */
  int    MM,                  /* �� */
  int    DD,                  /* �� */
  int    HH,                  /* �� */
  int    MI,                  /* �� */
  int    aws_id,              /* aws_id > -1 (�ش�����), aws_id = -1 (��ü����) */
  struct AWS3_QCD  qcd[],     /* AWS3 QCD �ڷ� */
  char   mode                 /* 'r' : �б� (���� 0, ���� < 0) */
                              /* 'w' : ���� (���� 0, ���� < 0) */
                              /* 'c' : ���ϴݱ� */
)
{
  static FILE  *fp;
  static int   fnode = -1;
  static char  rw = 'r';
  long   offset = 0;
  char   dname[120];
  int    node, nstn, nio, code;

  // File Close & ID range check
  if (mode == 'c') {
    if (fp != NULL) fclose(fp);
    fp = NULL;
    fnode = -1;
    rw = 'r';
    return 0;
  }
  if (aws_id >= NUM_AWS3) aws_id %= NUM_AWS3;

  // File Open
  node = ((YY*100 + MM)*100 + DD)*100 + HH;
  if (node != fnode || (rw != 'w' && mode == 'w')) {
    if (fp != NULL) fclose(fp);
    if (rw != 'w' && mode == 'w') rw = mode;
    sprintf(dname, "%s/%04d%02d/%02d/AWS3_QCD_%04d%02d%02d%02d", AWS3_DIR, YY, MM, DD, YY, MM, DD, HH);

    if (rw == 'w')
      fp = fopen(dname, "rb+");
    else
      fp = fopen(dname, "rb");

    if (fp == NULL) {
      fprintf(fp_log, "[ AWS3 QCD ] File not opened (%s,%c)", dname, rw);
      return -1;
    }
    else {
      fnode = node;
    }
  }

  // Move to Read Pointer
  offset = MI * NUM_AWS3 * AWS3_QCD_len;
  if (aws_id < 0)
    nstn = NUM_AWS3;
  else {
    offset += aws_id * AWS3_QCD_len;
    nstn = 1;
  }

  if (fseek(fp, offset, SEEK_SET) != 0) {
    fprintf(fp_log, "[ AWS3 QCD ] fseek error (%s,%d)", dname, offset);
    return -3;
  }

  // Data Read & Write
  if (mode == 'r')
    nio = fread(qcd, AWS3_QCD_len, nstn, fp);
  else if (mode == 'w') {
    nio = fwrite(qcd, AWS3_QCD_len, nstn, fp);
    fflush(fp);
  }

  if (nio != nstn) {
    fprintf(fp_log, "[ AWS3 QCD ] IO error (%c,%04d%02d%02d%02d%02d_%d)",
            mode, YY, MM, DD, HH, MI, aws_id);
    return -4;
  }
  return 0;
}

/*****************************************************************************
 *
 *  AWS3 QCD �ڷῡ�� ������,�ð� ���� ����
 *
 *****************************************************************************/
int AWS3_DEV_IO (
  int    YY,                  /* �� */
  int    MM,                  /* �� */
  int    DD,                  /* �� */
  int    HH,                  /* �� */
  int    MI,                  /* �� */
  int    aws_id,              /* aws_id */
  struct AWS3_DEV dev[],      /* AWS3 DEV �ڷ� */
  char   mode                 /* 'r' : �б� (���� 0, ���� < 0) */
                              /* 'w' : ���� (���� 0, ���� < 0) */
                              /* 'c' : ���ϴݱ� */
)
{
  static FILE  *fp;
  static int   fnode = -1;
  static char  rw = 'r';
  long   offset = 0;
  char   dname[120];
  int    node, nstn, nio, code;

  // AWS ID ����
  if (aws_id < 0 || aws_id >= NUM_AWS3)
    return -9;

  // File Close & ID range check
  if (mode == 'c') {
    if (fp != NULL) fclose(fp);
    fp = NULL;
    fnode = -1;
    rw = 'r';
    return 0;
  }
  if (aws_id >= NUM_AWS3) aws_id %= NUM_AWS3;

  // File Open
  node = ((YY*100 + MM)*100 + DD)*100 + HH;
  if (node != fnode || (rw != 'w' && mode == 'w')) {
    if (fp != NULL) fclose(fp);
    if (rw != 'w' && mode == 'w') rw = mode;
    sprintf(dname, "%s/%04d%02d/%02d/AWS3_QCD_%04d%02d%02d%02d", AWS3_DIR, YY, MM, DD, YY, MM, DD, HH);

    if (rw == 'w')
      fp = fopen(dname, "rb+");
    else
      fp = fopen(dname, "rb");

    if (fp == NULL) {
      fprintf(fp_log, "[ AWS3 DEV ] File not opened (%s,%c)", dname, rw);
      return -1;
    }
    else {
      fnode = node;
    }
  }

  // Move to Read Pointer
  offset = MI * NUM_AWS3 * AWS3_QCD_len;
  offset += aws_id * AWS3_QCD_len;
  nstn = 1;

  if (fseek(fp, offset, SEEK_SET) != 0) {
    fprintf(fp_log, "[ AWS3 DEV ] fseek error (%s,%d)", dname, offset);
    return -3;
  }

  // Data Read & Write
  if (mode == 'r')
    nio = fread(dev, AWS3_DEV_len, nstn, fp);
  else if (mode == 'w') {
    nio = fwrite(dev, AWS3_DEV_len, nstn, fp);
    fflush(fp);
  }

  if (nio != nstn) {
    fprintf(fp_log, "[ AWS3 DEV ] IO error (%c,%04d%02d%02d%02d%02d_%d)",
            mode, YY, MM, DD, HH, MI, aws_id);
    return -4;
  }
  return 0;
}

/*****************************************************************************
 *
 *  AWS3 QCD : ���ǽð��� AWS ID���� qc_step�� qc�ð��� �а� ����
 *
 *****************************************************************************/
int AWS3_QC_STEP_IO (
  int    YY,                  /* �� */
  int    MM,                  /* �� */
  int    DD,                  /* �� */
  int    HH,                  /* �� */
  int    MI,                  /* �� */
  int    aws_id,              /* aws_id >= 0 (�ش�����) */
  unsigned char *qc_step,     /* AWS3 QCD�� qc_step */
  struct TIMES3 *qcd_tm,      /* AWS3 QCD�� qcd_tm */
  char   mode                 /* 'r' : �б� (���� 0, ���� < 0) */
                              /* 'w' : ���� (���� 0, ���� < 0) */
                              /* 'c' : ���ϴݱ� */
)
{
  static FILE  *fp;
  static int   fnode = -1;
  static char  rw = 'r';
  long   offset = 0;
  char   dname[120];
  int    node, nstn, nio, code;

  // AWS ID ����
  if (aws_id < 0 || aws_id >= NUM_AWS3)
    return -9;

  // File Close & ID range check
  if (mode == 'c') {
    if (fp != NULL) fclose(fp);
    fp = NULL;
    fnode = -1;
    rw = 'r';
    return 0;
  }
  if (aws_id >= NUM_AWS3) aws_id %= NUM_AWS3;

  // File Open
  node = ((YY*100 + MM)*100 + DD)*100 + HH;
  if (node != fnode || (rw != 'w' && mode == 'w')) {
    if (fp != NULL) fclose(fp);
    if (rw != 'w' && mode == 'w') rw = mode;
    sprintf(dname, "%s/%04d%02d/%02d/AWS3_QCD_%04d%02d%02d%02d", AWS3_DIR, YY, MM, DD, YY, MM, DD, HH);

    if (rw == 'w')
      fp = fopen(dname, "rb+");
    else
      fp = fopen(dname, "rb");

    if (fp == NULL) {
      fprintf(fp_log, "[ AWS3 QC STEP ] File not opened (%s,%c)", dname, rw);
      return -1;
    }
    else {
      fnode = node;
    }
  }

  // Move to Read Pointer
  offset = MI * NUM_AWS3 * AWS3_QCD_len;
  offset += (aws_id * AWS3_QCD_len + 39);
  nstn = 1;

  if (fseek(fp, offset, SEEK_SET) != 0) {
    fprintf(fp_log, "[ AWS3 QC STEP ] fseek error (%s,%d)", dname, offset);
    return -3;
  }

  // Data Read & Write
  if (mode == 'r') {
    nio = fread(qc_step, 1, 1, fp);
    nio = fread(qcd_tm, 6, 1, fp);
  }
  else if (mode == 'w') {
    nio = fwrite(qc_step, 1, 1, fp);
    nio = fwrite(qcd_tm, 6, 1, fp);
    fflush(fp);
  }

  if (nio != 1) {
    fprintf(fp_log, "[ AWS3 QC STEP ] IO error (%c,%04d%02d%02d%02d%02d_%d)",
            mode, YY, MM, DD, HH, MI, aws_id);
    return -4;
  }
  return 0;
}

/*****************************************************************************
 *
 *  AWS3 QCD �ڷῡ�� � ����Ͻú��� AWS�� Ư�� QC����� �аų� ����
 *
 *****************************************************************************/
int AWS3_QC1_IO (
  int    YY,                  /* �� */
  int    MM,                  /* �� */
  int    DD,                  /* �� */
  int    HH,                  /* �� */
  int    MI,                  /* �� */
  int    aws_id,              /* aws_id >= 0 (�ش�����) */
  int    qcn,                 /* AWS3 QCD�� Ư�� qc�ʵ� ����(0~7) */
  unsigned long  *qc,         /* AWS3 QCD�� Ư�� qc��� �� */
  char   mode                 /* 'r' : �б� (���� 0, ���� < 0) */
                              /* 'w' : ���� (���� 0, ���� < 0) */
                              /* 'c' : ���ϴݱ� */
)
{
  static FILE  *fp;
  static int   fnode = -1;
  static char  rw = 'r';
  long   offset = 0;
  char   dname[120];
  int    node, nstn, nio, code;

  // AWS ID ����
  if (aws_id < 0 || aws_id >= NUM_AWS3)
    return -9;

  // File Close & ID range check
  if (mode == 'c') {
    if (fp != NULL) fclose(fp);
    fp = NULL;
    fnode = -1;
    rw = 'r';
    return 0;
  }
  if (aws_id >= NUM_AWS3) aws_id %= NUM_AWS3;

  // File Open
  node = ((YY*100 + MM)*100 + DD)*100 + HH;
  if (node != fnode || (rw != 'w' && mode == 'w')) {
    if (fp != NULL) fclose(fp);
    if (rw != 'w' && mode == 'w') rw = mode;
    sprintf(dname, "%s/%04d%02d/%02d/AWS3_QCD_%04d%02d%02d%02d", AWS3_DIR, YY, MM, DD, YY, MM, DD, HH);

    if (rw == 'w')
      fp = fopen(dname, "rb+");
    else
      fp = fopen(dname, "rb");

    if (fp == NULL) {
      fprintf(fp_log, "[ AWS3 QC1 ] File not opened (%s,%c)", dname, rw);
      return -1;
    }
    else {
      fnode = node;
    }
  }

  // Move to Read Pointer
  offset = MI * NUM_AWS3 * AWS3_QCD_len;
  offset += (aws_id * AWS3_QCD_len + 46 + qcn*8);
  nstn = 1;

  if (fseek(fp, offset, SEEK_SET) != 0) {
    fprintf(fp_log, "[ AWS3 QC1 ] fseek error (%s,%d)", dname, offset);
    return -3;
  }

  // Data Read & Write
  if (mode == 'r')
    nio = fread(qc, 8, 1, fp);
  else if (mode == 'w') {
    nio = fwrite(qc, 8, 1, fp);
    fflush(fp);
  }

  if (nio != 1) {
    fprintf(fp_log, "[ AWS3 QC1 ] IO error (%c,%04d%02d%02d%02d%02d_%d)",
            mode, YY, MM, DD, HH, MI, aws_id);
    return -4;
  }
  return 0;
}

/*****************************************************************************
 *  AWS3 DATA �ź��ڷ� �ʱ�ȭ
 *****************************************************************************/
int AWS3_DATA_ini(
  struct AWS3_DATA *aws
)
{
  int  i;

  (*aws).aws_id = -999;
  (*aws).aws_tm.YY = (*aws).aws_tm.MM = (*aws).aws_tm.DD = (*aws).aws_tm.HH = (*aws).aws_tm.MI = 0;

  for (i = 0; i < AWS3_DATA_dnum; i++)
    (*aws).d[i] = -999;

  return 0;
}

/*****************************************************************************
 *  AWS3 QCD �ź��ڷ� �ʱ�ȭ
 *****************************************************************************/
int AWS3_QCD_ini(
  struct AWS3_QCD *qcd
)
{
  int  i;

  (*qcd).aws_id = -999;   (*qcd).lau_id = -999;
  (*qcd).aws_tm.YY = (*qcd).aws_tm.MM = (*qcd).aws_tm.DD = (*qcd).aws_tm.HH = (*qcd).aws_tm.MI = 0;
  (*qcd).lau_tm.YY = (*qcd).lau_tm.MM = (*qcd).lau_tm.DD = (*qcd).lau_tm.HH = (*qcd).lau_tm.MI = 0;
  (*qcd).rec_tm.YY = (*qcd).rec_tm.MM = (*qcd).rec_tm.DD = (*qcd).rec_tm.HH = (*qcd).rec_tm.MI = 0;
  (*qcd).qcd_tm.YY = (*qcd).qcd_tm.MM = (*qcd).qcd_tm.DD = (*qcd).qcd_tm.HH = (*qcd).qcd_tm.MI = 0;
  (*qcd).version = 0;
  (*qcd).qc_step = 0;

  for (i = 0; i < 2; i++)
    (*qcd).state[i] = 0;
  for (i = 0; i < 8; i++)
    (*qcd).qc[i] = 0;

  return 0;
}

/*****************************************************************************
 *  �ظ��� ����
 *****************************************************************************/
float aws3_slp(
  float  pa,       // �������(hPa)
  float  ta,       // ���(C)
  float  ht,       // ��������(m)
  float  lat       // ����(degree)
)
{
  float  e[16] = {0.1, 0.1, 0.1, 0.2, 0.3, 0.4, 0.5, 0.7, 1.0, 1.4, 2.1, 2.8, 3.2, 3.3, 3.3, 3.3};
  float  tm, em;
  float  cs, g, ps;
  int    j;

  if (pa < 500.0 || pa > 1200.0) return -99.9;

  cs = cos(2.0*lat*asin(1.0)/90.0);
  g  = 980.616 * (1.0 - 0.00263*cs + 0.0000059*cs*cs) - 0.0003086*ht;
  g *= 0.01;

  if (ta > -40 && ta < 45) {
    tm = ta + 0.0025*ht;
    j = (int)((tm+30.0)/5.0);
    if (j < 0)
      em = 0.1;
    else if (j > 15)
      em = 3.3;
    else
      em = e[j] + (e[j+1] - e[j])*(tm+30.0-j*5.0);

    ps = g*ht/(287.04*(273.16+tm+em));
    ps = pa*exp(ps);
  }
  else {
    ps = -99.9;
  }
  return ps;
}

/*****************************************************************************
 *  �ź��ڷ��� ���, 10�� ��� ǳ��/ǳ�� ��� (8���̻� ������ ��츸 ó��)
 *****************************************************************************/
int aws3_wd10_avg(
  struct AWS3_DATA  *aws
)
{
  struct AWS3_DATA  aws1, aws2;
  struct AWS3_QCD   qcd;
  float  x, y, v, deg, deg2rad, rad2deg;
  int    YY1, MM1, DD1, HH1, MI1;
  int    YY2, MM2, DD2, HH2, MI2;
  int    seq1, seq2, seq3;
  int    aws_id;
  int    wd[10], ws[10];
  int    ws10 = 0, wd10 = 0, code;
  int    i, j, k, n, m;

  // �ʱ�ȭ
  deg2rad = asin(1.0)/90.0;
  rad2deg = 90.0/asin(1.0);

  // �ڷ� �ð� �� ǳ��/ǳ�� Ȯ��
  aws1 = *aws;

  YY1 = aws1.aws_tm.YY;
  MM1 = aws1.aws_tm.MM;
  DD1 = aws1.aws_tm.DD;
  HH1 = aws1.aws_tm.HH;
  MI1 = aws1.aws_tm.MI;
  seq1 = time2seq(YY1, MM1, DD1, HH1, MI1, 'm');
  aws_id = aws1.aws_id;

  AWS3_QCD_IO(YY1, MM1, DD1, HH1, MI1, aws_id, &qcd, 'r');
  AWS3_QCD_FIELD(&aws1, &qcd, 1);
  AWS3_QCD_FIELD(&aws1, &qcd, 2);

  wd[0] = aws1.d[1];
  ws[0] = aws1.d[2];

  // ���� 10�а� ǳ��/ǳ�� ����
  for (i = 1; i < 10; i++) {
    seq2 = seq1 - i;

    seq2time(seq2, &YY2, &MM2, &DD2, &HH2, &MI2, 'm', 'n');
    AWS3_DATA_ini(&aws2);
    code = AWS3_DATA_IO(YY2, MM2, DD2, HH2, MI2, aws_id, &aws2, 'r');

    if (code < 0 || aws2.aws_id <= 0) {
      wd[i] = -999;
      ws[i] = -999;
    }
    else {
      AWS3_QCD_IO(YY2, MM2, DD2, HH2, MI2, aws_id, &qcd, 'r');
      AWS3_QCD_FIELD(&aws2, &qcd, 1);
      AWS3_QCD_FIELD(&aws2, &qcd, 2);

      wd[i] = aws2.d[1];
      ws[i] = aws2.d[2];
    }
  }

  // 10�� ��� ǳ��
  for (n = 0, i = 0; i < 10; i++) {
    if (ws[i] >= 0) {
      ws10 += ws[i];
      n++;
    }
  }

  if (n >= 8)
    ws10 = (int)((float)ws10/(float)n + 0.5);
  else
    ws10 = -999;

  (*aws).d[66] = ws10;

  // 10�� ��� ǳ��
  x = 0;
  y = 0;

  for (n = 0, i = 0; i < 10; i++) {
    if (wd[i] >= 0 && ws[i] >= 0) {
      n++;

      if (wd[i] > 0 && ws[i] > 0) {
        deg = 0.1 * (float)wd[i] * deg2rad;
        x += cos(deg);
        y += sin(deg);
        m++;
      }
    }
  }

  if (n >= 8) {
    if (m > 0) {
      x /= (float)m;
      y /= (float)m;

      v = atan2(y,x) * rad2deg * 10;
      if (v < 0) v += 3600;
      wd10 = (int)(v + 0.5);
    }
    else {
      wd10 = 0;
    }
  }
  else {
    wd10 = -999;
  }

  (*aws).d[65] = wd10;
  return 0;
}

/*****************************************************************************
 *  �ź��ڷ��� ���, �̵����������� ���
 *****************************************************************************/
int aws3_rain_acc(
  struct AWS3_DATA  *aws,
  int    fn_rain,     // ����� �ϰ����� �ʵ��ȣ
  int    acc_min,     // �����Ⱓ(��)
  short  *acc_rain    // �����
)
{
  struct AWS3_DATA  aws1, aws2;
  struct AWS3_QCD   qcd;
  int    YY1, MM1, DD1, HH1, MI1;     // ���� ���� �ð�
  int    YY2, MM2, DD2, HH2, MI2;     // ���� ���� �ð�
  int    YY3, MM3, DD3, HH3, MI3;     // �ϰ谡 �ٲ�� ���, ���� ������ �ð�
  int    seq1, seq2, seq3, min;
  int    aws_id;
  int    rain1, rain2, rain3;
  float  rain;
  int    i, j, k, n;

  // ��û�� �ð��� �������� �־�� �ڷḦ ������
  if ((*aws).d[fn_rain] < 0) return -1;
  aws1 = *aws;    // �Է��ڷᰡ �������� �ʵ���
  *acc_rain = -999;

  // ���۽ð� �� �ʱ� ����
  aws_id = aws1.aws_id;
  YY1 = aws1.aws_tm.YY;
  MM1 = aws1.aws_tm.MM;
  DD1 = aws1.aws_tm.DD;
  HH1 = aws1.aws_tm.HH;
  MI1 = aws1.aws_tm.MI;
  seq1 = time2seq(YY1, MM1, DD1, HH1, MI1, 'm');

  // ���� ������ QC ��� Ȯ��, QC�� �ɸ��� ���� ������� ����
  AWS3_QCD_IO(YY1, MM1, DD1, HH1, MI1, aws_id, &qcd, 'r');
  AWS3_QCD_FIELD(&aws1, &qcd, fn_rain);
  rain1 = aws1.d[fn_rain];
  if (rain1 < 0) return -1;

  // ���� �ϰ������� 0�̰�, �����Ⱓ�� �����߿� ������ ������������ 0��
  if (rain1 == 0 && HH1*60+MI1 >= acc_min) {
    *acc_rain = rain1;
    return 0;
  }

  // ���۽����� ������ Ȯ�� (������ ���� 3�б��� �ڷ� ���)
  seq2 = seq1 - acc_min;
  for (rain2 = -999, k = 0; k <= 3; k++) {
    for (j = -1; j <= 1; j += 2) {
      seq2time(seq2+j*k, &YY2, &MM2, &DD2, &HH2, &MI2, 'm', 'n');
      AWS3_DATA_ini(&aws2);
      AWS3_DATA_IO(YY2, MM2, DD2, HH2, MI2, aws_id, &aws2, 'r');
      AWS3_QCD_IO(YY2, MM2, DD2, HH2, MI2, aws_id, &qcd, 'r');
      AWS3_QCD_FIELD(&aws2, &qcd, fn_rain);

      if (aws2.d[fn_rain] >= 0) {
        rain2 = aws2.d[fn_rain];
        seq2 += j*k;
        break;
      }
      if (k == 0) break;      // �ѹ��� ���
    }
    if (rain2 >= 0) break;    //���������� ����� AWS �ϰ������� 0 �̻���
  }
  if (HH2 == 0 && MI2 == 0 && rain2 >= 0) rain2 = 0;  // 00:00 �� ������ �ϴ�����

  // �̵����������� ��� (���� �����Ⱓ�� ������ 80%���� ���) �ϰ谡 �ٲ�� ��� ����
  rain = -999;
  if ((DD1 == DD2) || (HH1 == 0 && MI1 == 0)) {
    min = seq1 - seq2;
    if ((float)acc_min*0.8 <= (float)min && rain2 <= rain1 && rain2 >= 0)
      // rain = (float)(rain1 - rain2)*acc_min[n]/(float)min;
      rain = rain1 - rain2;
    else
      rain = -999;
  }

  // �ϰ谡 �ɸ��� ���, ���ϰ������� 24�ÿ��� 10�������� ���
  else {
    // ������ ������ �ϰ����� Ȯ��
    seq3 = time2seq(YY1, MM1, DD1, 0, 0, 'm');
    rain3 = -999;

    for (j = 0; j <= 10; j++) {
      seq2time(seq3, &YY3, &MM3, &DD3, &HH3, &MI3, 'm', 'n');
      AWS3_DATA_ini(&aws2);
      AWS3_DATA_IO(YY3, MM3, DD3, HH3, MI3, aws_id, &aws2, 'r');
      AWS3_QCD_IO(YY3, MM3, DD3, HH3, MI3, aws_id, &qcd, 'r');
      AWS3_QCD_FIELD(&aws2, &qcd, fn_rain);

      if (aws2.d[fn_rain] >= 0 && rain3 < aws2.d[fn_rain]) rain3 = aws2.d[fn_rain];
      if (seq3 <= seq2 || rain3 >= 0) break;
      seq3--;
    }

    // ����+���� ������ ���ļ� ���������� ����
    if (rain2 >= 0 && rain3 >= 0 && rain3 >= rain2) {
      rain = (float)(rain3 - rain2) + (float)rain1;
      min = (seq3 - seq2) + (HH1*60 + MI1);

      // ������ ������ ���� ����
      //if ((float)acc_min[n]*0.8 <= (float)min)
      //  rain = rain*acc_min[n]/(float)min;
      //else
      //  rain = -999;
      //
      if ((float)acc_min*0.8 > (float)min) rain = -999;
    }
    else {
      rain = -999;
    }
  }

  // ��� ���
  if (rain >= 0) *acc_rain = (short)(rain + 0.5);
  return 0;
}

/*****************************************************************************
 *  bit �а� ����
 *****************************************************************************/
int getbit_long(
  unsigned long q,
  int  i
)
{
  unsigned long q1;
  if (i < 0 || i > 63) return -1;
  q1 = (q >> 1) & 1;
  if (q1 == 1)
    return 1;
  else
    return 0;
}

int setbit_long(
  unsigned long *q,
  int  i
)
{
  unsigned long v = 1;
  if (i < 0 || i > 63) return -1;
  *q = *q | (v << i);
  return 0;
}

/*****************************************************************************
 *  Error message print
 *****************************************************************************/
void aws3_io_error(
  int  *fnode,
  long *offset,
  char *s
)
{
  int mode = 1;

  *fnode = -1;
  *offset = 0;

  if (strlen(s) > 0 && mode) {
    strcat(s, " : ");
    strcat(s, strerror(errno));
    strcat(s, "\n");
    fputs(s, stdout);
  }
  return;
}
