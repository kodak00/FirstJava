#include <stdio.h>
#include <stdlib.h>    
#include <string.h>    
      
    
#define MAX_LINE_LEN	256    
    
#define ENV_ERROR		-1    
#define ENV_BLANK		1    
#define ENV_COMMENT		2    
#define ENV_SECTION		3    
#define ENV_KEY			4    
       
    
int ProcessEnvLine(char *pCur, char *pCur2);    
    
int GetCfgInt(char *pSection, char *pKey, int *nKeyValue, char *pFilePath)    
{    
	char 	pKeyValue[50];    
	int		nRet;    
    
	memset(pKeyValue, 0x00, sizeof(pKeyValue));    
            
	nRet = GetCfgStr(pSection, pKey, pKeyValue, pFilePath);    
	if(nRet < 0)    
		return -1;    
	else    
	{    
    	if(strlen(pKeyValue) != 0)    
		{		    
    		*nKeyValue = atoi(pKeyValue);    
		}    
	}    
	    
	return 0;    
}    
    
int PutCfgStr(char *pSection, char *pKey, char *pKeyValue, char *pFilePath)    
{    
    FILE    *fpIn, *fpTemp;    
    char    curline[MAX_LINE_LEN];    
    char    env_elem[MAX_LINE_LEN];    
    char    fsection[MAX_LINE_LEN];    
    char    fkey[MAX_LINE_LEN];    
    char    *value;    
    int     n;    
	char	pTempFilePath[200];    
	int		nFoundSection = 0;    
	int		nFoundKey = 0;    
	    
    fpIn = fopen(pFilePath, "r");    
    if(fpIn == NULL)    
    {       
    	LogMsg("PutCfgStr> fopen() Fail ");    
        return -1;    
    }    
    
	sprintf(pTempFilePath, "%s.out", pFilePath);    
    fpTemp = fopen(pTempFilePath, "w");    
    if(fpTemp == NULL)    
    {       
    	LogMsg("PutCfgStr> fopen() Fail ");    
        return -1;    
    }    
    	    
    while(fgets(curline, MAX_LINE_LEN, fpIn))     
	{    
        n = ProcessEnvLine(curline, env_elem);    
    
        switch(n)     
		{    
        case ENV_COMMENT :    
        case ENV_BLANK :    
        case ENV_ERROR :    
        	fputs(curline, fpTemp);    
            continue;    
    
        case ENV_SECTION :    
            strcpy(fsection, env_elem);    
                
            if(nFoundSection == 1)    
            {    
            	if(nFoundKey == 0)    
            	{    
            		LogMsg("PutCfgStr> Insert Key Value, Key = %s, Value = %s", pKey, pKeyValue);    
            		fprintf(fpTemp, "%s=%s\n", pKey, pKeyValue);    
            		nFoundKey = 1;    
            	}    
            }    
            else if(strcmp(fsection, pSection) == 0)    
            {    
            	 nFoundSection = 1;    
           	}               
           	    
            fputs(curline, fpTemp);    
                
            break;    
    
        case ENV_KEY :    
            if(curline[strlen(curline) - 1] = '\n')    
                curline[strlen(curline) - 1] = 0x00;    
    
            value = strchr(curline, '=');    
            if(value != NULL)      
            {    
                memset(fkey, 0, sizeof(fkey));    
                strncpy(fkey, curline,  value - curline);    
                    
                if(!strcmp(pSection, fsection) && !strcmp(pKey, fkey))    
                {    
                	LogMsg("PutCfgStr> Update Key Value, Key = %s, Value = %s", pKey, pKeyValue);    
                	nFoundKey = 1;    
                	fprintf(fpTemp, "%s=%s\n", pKey, pKeyValue);    
                }    
                else    
                {    
                	fprintf(fpTemp, "%s\n", curline);    
                }    
            }    
            else    
            {    
                fprintf(fpTemp, "%s\n", curline);            	    
         	}    
            break;    
        }    
    }    
           
    if(nFoundSection == 0)    
    {    
		LogMsg("PutCfgStr> Insert Section And Key Value, Key = %s, Value = %s", pKey, pKeyValue);    	    
    	fprintf(fpTemp, "[%s]\n", pSection);    
    	fprintf(fpTemp, "%s=%s\n", pKey, pKeyValue);    
    }    
        
	fclose(fpIn);    
	    
	fclose(fpTemp);    
	    
	if(rename(pTempFilePath, pFilePath) < 0)    
	{    
		LogMsg("PutCfgStr> rename() Fail ");    
		return -1;    
	}    
    
    return 0;    
}    
    
    
int GetCfgStr(char *pSection, char *pKey, char *pKeyValue, char *pFilePath)    
{    
    FILE    *fp;    
    char    curline[MAX_LINE_LEN];    
    char    env_elem[MAX_LINE_LEN];    
    char    fsection[MAX_LINE_LEN];    
    char    fkey[MAX_LINE_LEN];    
    char    *value;    
    int     n;    
    
    fp = fopen(pFilePath, "r");    
    if(fp == NULL)    
    {       
        return  -1;    
    }    
    
    while(fgets(curline, MAX_LINE_LEN, fp))     
	{    
        n = ProcessEnvLine(curline, env_elem);    
    
        switch(n)     
		{    
        case ENV_COMMENT :    
        case ENV_BLANK :    
        case ENV_ERROR :    
            continue;    
    
        case ENV_SECTION :    
             strcpy(fsection, env_elem);    
             break;    
    
        case ENV_KEY :    
            if(curline[strlen(curline) - 1] = '\n')    
                curline[strlen(curline) - 1] = 0x00;    
    
            value = strchr(curline, '=');    
            if(value != NULL)      
            {    
                memset(fkey, 0, sizeof(fkey));    
                strncpy(fkey, curline,  value - curline);    
                    
                if(!strcmp(pSection, fsection) && !strcmp(pKey, fkey))    
                {    
                    fclose(fp);    
		    strcpy(pKeyValue, value + 1);    
		    return 0;    
                }    
            }    
            break;    
        }    
    }    
            
	fclose(fp);    
    
    return -1;    
}    
    
    
int ProcessEnvLine(char *pCur, char *pCur2)    
{    
    int ret = ENV_ERROR;    
    
    /* FIRST BLANK SKIP */    
    for ( ; (*pCur == ' ') || (*pCur == '\t'); pCur++)    
        ;    
        
    switch(*pCur)     
	{    
    case '\0' :    
    case '\n' :    
        ret = ENV_BLANK;    
        break;    
    case '/':    
    case '#':    
    case ';':    
    case '!':    
        ret = ENV_COMMENT;    
        break;    
    case '[':    
        pCur++;    
        for( ; *pCur && (*pCur != ']'); pCur++)    
            *pCur2++ = *pCur;    
            
        if(!*pCur)     
			break; /* Not Found brace */    
    
        *pCur2 = '\0';    
    
        ret = ENV_SECTION;    
        break;    
    
    default:    
        ret = ENV_KEY;    
    }    
    
    return ret;    
}    
