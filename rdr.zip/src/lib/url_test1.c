#include "url_io.h"

/* 
   URL_IO �׽�Ʈ ���� �ҽ�
 */

int
main(int argc, char *argv[])
{
    URL_FILE *handle;
    int nread;
    char buffer[1024];
    const char *url;

	// HTML�� �д� ���
//	url = "http://weather.uwyo.edu/cgi-bin/sounding?region=naconf&TYPE=TEXT%3ALIST&YEAR=2009&MONTH=11&FROM=0900&TO=0900&STNM=71043";
	url = "http://172.20.156.33/gts/gts_temp1.php?tm=200912141200&stn_id=47122";
    handle = url_fopen(url, "r");
    if (!handle)
    {
        printf("url open error\n");
        return (-1);	
    }

    while (!url_feof(handle)) {
        url_fgets(buffer, sizeof(buffer), handle);
		fprintf(stdout, buffer);	
    }
    url_fclose(handle);

/*
	// IMAGE�� �д� ���
	url = "http://weather.uwyo.edu/upperair/images/2009111200.71043.skewt.gif";
    handle = url_fopen(url, "r");
    if (!handle) {
    	printf("can not open url\n");
    	return (-1);	
    }
    
    do {
        nread = url_fread(buffer, 1, sizeof(buffer), handle);
        fwrite(buffer, 1, nread, stdout);
    } while(nread); 
    url_fclose(handle);
*/
	return (0);
}
