
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>



int    Calc_token;																// �Ľ��� ���� ���� �Է� ���ڸ� ���´�.
char   Calc_exp[256];
double Calc_q_value;
int    Calc_pointer;

int  Calc_Exp      (double* result, char* expression, double v);
void Calc_getToken ();
int  Calc_match    (char c);
int  Calc_command  (double* result);
int  Calc_expr     (double* result);
int  Calc_term     (double* result);
int	 Calc_factor   (double* result);
int  Calc_power    (double* result);
int  Calc_number   (double* result);
int  Calc_digit    (double* result);



/*----------------------------------------------------------------------------
 * Name       : Calc_Exp()
 * Description: Calculate Expression
 * Parameter  : result    : (Return) Calculated Result Value
 *				expression: Expression to Calculate
 *				v		  : Value replaces '?' Character in Expression
 * Return     :  0: Success
 *				<0: Wrong Expression
 * Usage      : if (Calc_Exp(&value, "(((?+8)-3)*10)/100\n", 5)==0)
 *					printf("%f\n", value);
 *----------------------------------------------------------------------------*/
int Calc_Exp(double* result, char* expression, double v)
{
	strcpy(Calc_exp, expression);
	Calc_q_value = v;
	Calc_pointer = 0;
	Calc_getToken();															// ù ��° ��ū�� ��´�.
	return Calc_command(result);												// ���� ��ȣ�� ���� �Ľ� ���ν����� ȣ���Ѵ�.
}

void Calc_getToken()
{
	while((Calc_token = Calc_exp[Calc_pointer++]) == ' ');						// ��ū�� ���ڵ��̴�.
}

int Calc_match(char c)
{
	if (Calc_token == c)
		Calc_getToken();
	else
		return -3;
	return 0;
}


int Calc_command(double* result)												// command -> expr '\n'
{
	int err_no;
	if ((err_no=Calc_expr(result)) == 0)
		if (Calc_token != '\n')													// �Ľ��� ������ ����� ����Ѵ�.
			err_no = -2;
	return err_no;
}


int Calc_expr(double* result)													// expr -> term { '+' | '-' term }
{
	int    err_no = Calc_term(result);	
	double lvalue = *result;
	if (err_no == 0)
	{
		while(Calc_token == '+' || Calc_token == '-')
		{
			switch(Calc_token)
			{
				case '+':
					Calc_match('+');
					if ((err_no = Calc_term(result)) < 0) break;
					lvalue += *result;
					break;

				case '-':
					Calc_match('-');
					if ((err_no = Calc_term(result)) < 0) break;
					lvalue -= *result;
					break;
			}
		}
		*result = lvalue;
	}
	return err_no;
}

int Calc_term(double* result)													// term -> factor { '*' | '/' | '%' factor }
{
	int err_no = Calc_factor(result);
	double lvalue = *result;
	if (err_no == 0)
	{
		while(Calc_token == '*' || Calc_token == '/')
		{
			switch(Calc_token)
			{
				case '*':
					Calc_match('*');
					if ((err_no=Calc_term(result)) < 0) break;
					lvalue *= *result;
					break;

				case '/':
					Calc_match('/');
					if ((err_no=Calc_term(result)) < 0) break;
					lvalue /= *result;
					break;
			}
		}
		*result = lvalue;
	}
	return err_no;
}

int Calc_factor(double* result)													// factor -> power { '^' factor }
{
	int err_no = Calc_power(result);
	return err_no;
}

int Calc_power(double* result)													// power -> '(' expr ')' | number
{
	int err_no;
	if (Calc_token == '(')
	{
		Calc_match('(');
		err_no = Calc_expr(result);
		Calc_match(')');
	}
	else
		err_no = Calc_number(result);
	return err_no;
}

int Calc_number(double* result)													// number -> digit { digit }
{
	int err_no;
	if ((err_no=Calc_digit(result)) == 0)
	while(isdigit(Calc_token))
		*result = 10 * *result + Calc_digit(result);							//���ڷε� ���ڸ� ������ �����Ѵ�.
	return err_no;
}

int Calc_digit(double* result)													// digit -> '0' | '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9'
{
	int err_no = 0;
	if(isdigit(Calc_token))
	{
		*result = Calc_token - '0';												//���� '0'�� ���ָ� ���� ���ڰ��� �˼��ִ�.
		Calc_match(Calc_token);
	}
	else if(Calc_token==(int)('?'))
	{
		*result = Calc_q_value;
		Calc_match(Calc_token);
	}
	else
		err_no = -1;
	return err_no;
}
