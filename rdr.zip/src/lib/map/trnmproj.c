#include <stdio.h>
#include <math.h>
#include "map_ini.h"

/***************************************************************************
*
*  [ Transveres Mercator Projection ]
*
*      o lon, lat : (longitude,latitude) at earth  [degree]
*      o x, y     : (x,y) cordinate in map  [grid]
*      o code = 0 : (lon,lat) --> (x,y)
*               1 : (x,y) --> (lon,lat)
*
***************************************************************************/
int  trnmproj( lon, lat, x, y, code, map )
  float  *lon, *lat;         /* Longitude, Latitude [degree]  */
  float  *x, *y;             /* Coordinate in Map   [grid]    */
  int    code;               /* (0) lon,lat -> x,y  (1) x,y -> lon,lat */
  struct trnm_parameter *map;
{
  static double  PI, DEGRAD, RADDEG;
  static double  re, slon, slat, olon, olat, xo, yo;
  double         alon, alat, xn, yn, b, theta;

  if ((*map).first == 0) {
    PI = asin(1.0)*2.0;
    DEGRAD = PI/180.0;
    RADDEG = 180.0/PI;

    re = (*map).Re/(*map).grid;
    slon = (*map).slon * DEGRAD;
    slat = (*map).slat * DEGRAD;
    olon = (*map).olon * DEGRAD;
    olat = (*map).olat * DEGRAD;

    b = cos(olat) * sin(olon-slon);
    if (fabs(b) >= 0.99999) return -1;

    xo = 0.5*re*log( (1.0+b)/(1.0-b) ) - (*map).xo;
    if (fabs(olat) >= PI*0.5) {
      yn = olat;
      if (fabs(olon-slon) > PI*0.5) yn = -yn;
    }
    else if (fabs(cos(olon-slon)) <= 0.0) {
      yn = PI*0.5;
      if (olat >  0.0) yn = -yn;
      if (olat == 0.0) yn = 0.0;
    }
    else
      yn = atan2( tan(olat), cos(olon-slon) );
    yo = re*(yn - slat) - (*map).yo;
    (*map).first = 1;
  }

  if (code == 0) {
    alat = (*lat)*DEGRAD;
    alon = (*lon)*DEGRAD - slon;
    b = cos(alat) * sin(alon);
    if (fabs(b) >= 0.99999) return -1;
    *x = 0.5*re*log((1.0+b)/(1.0-b)) - xo;
    if (fabs(*lat) >= 90.0) {
      yn = PI*0.5;
      if (alat < 0.0) yn = -yn;
    }
    else if (fabs(cos(alon)) <= 0.0) {
      yn = PI*0.5;
      if ((*lat) <  0.0) yn = -yn;
      if ((*lat) == 0.0) yn = 0.0;
    }
    else
      yn = atan2( tan(alat), cos(alon) );
    *y = re*(yn - slat) - yo;
  }
  else {
    xn = (*x) + xo;
    yn = (*y) + yo;
    b = yn/re + slat;
    alat = sin(b) / cosh(xn/re);
    *lat = asin(alat) * RADDEG;
    if (fabs(cos(b)) <= 0.00001) {
      theta = PI*0.5;
      if( xn <  0.0 ) theta = -theta;
      if( xn == 0.0 ) theta = 0.0;
    }
    else
      theta = atan2( sinh(xn/re), cos(b) );
    *lon = (theta + slon) * RADDEG;
  }
  return 0;
}
