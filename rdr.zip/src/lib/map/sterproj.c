#include <stdio.h>
#include <math.h>
#include "map_ini.h"

/***************************************************************************
*
*  [ Stereographic Projection ]
*
*      o lon, lat : (longitude,latitude) at earth  [degree]
*      o x, y     : (x,y) cordinate in map  [grid]
*      o code = 0 : (lon,lat) --> (x,y)
*               1 : (x,y) --> (lon,lat)
*      o map      : map parameter
*
***************************************************************************/
int  sterproj( lon, lat, x, y, code, map )
  float  *lon, *lat;         /* Longitude, Latitude [degree]  */
  float  *x, *y;             /* Coordinate in Map   [grid]    */
  int    code;               /* (0) lon,lat -> x,y  (1) x,y -> lon,lat */
  struct ster_parameter *map;
{
  static int     first = 0, polar = 1;
  static double  re, slat, slon, olon, olat, xo, yo;
  static double  PI, DEGRAD, RADDEG;
  double         Re, alon, alat, ak, dd, xn, yn, a1, a2, ra, ac, theta;

  if ((*map).first == 0) {
    PI = asin(1.0)*2.0;
    DEGRAD = PI/180.0;
    RADDEG = 180.0/PI;

    slon = (*map).slon * DEGRAD;
    slat = (*map).slat * DEGRAD;
    olon = (*map).olon * DEGRAD;
    olat = (*map).olat * DEGRAD;

    /* if slat = 90N and 60N ��� */
    if( (*map).polar == 1 )
      re = (*map).Re/(*map).grid * ( 1.0 + sin( 60.0*DEGRAD ) ) * 0.5;
    else
      re = (*map).Re/(*map).grid;

    ak = 1.0 + sin(slat)*sin(olat) + cos(slat)*cos(olat)*cos(olon-slon);
    if( ak <= 0.0 ) return -1;
    ak = 2.0/ak;
    xo = re*ak*cos(olat)*sin(olon-slon) - (*map).xo;
    yo = re*ak*( cos(slat)*sin(olat) - sin(slat)*cos(olat)*cos(olon-slon) ) - (*map).yo;
    (*map).first = 1;
  }

  if (code == 0) {
    alat = (*lat)*DEGRAD;
    alon = (*lon)*DEGRAD - slon;
    ak = 1.0 + sin(slat)*sin(alat) + cos(slat)*cos(alat)*cos(alon);
    if( ak <= 0.0 )
      return -1;
    else {
      ak = 2.0/ak;
      (*x) = re*ak*cos(alat)*sin(alon) - xo;
      (*y) = re*ak*( cos(slat)*sin(alat) - sin(slat)*cos(alat)*cos(alon) ) - yo;
    }
  }
  else {
    xn = (*x) + xo;
    yn = (*y) + yo;
    ra = xn*xn + yn*yn;
    if (ra <= 0.0) {
      ac = 0.0;
      alat = slat;
    }
    else {
      ra = sqrt(ra);
      ac = 2.0*atan(0.5*ra/re);
      alat = cos(ac)*sin(slat) + yn*sin(ac)*cos(slat)/ra;
      alat = asin(alat);
    }
    a1 = xn*sin(ac);
    a2 = ra*cos(slat)*cos(ac) - yn*sin(slat)*sin(ac);
    if (fabs(a1) <= 0.0)
      theta = 0.0;
    else if( abs(a2) <= 0.0 ) {
      theta = PI*0.5;
      if( a2 < 0.0 ) theta = -theta;
    }
    else
      theta = atan2(a1,a2);
    alon = theta + slon;
    *lon = alon*RADDEG;
    *lat = alat*RADDEG;
  }
  return 0;
}
