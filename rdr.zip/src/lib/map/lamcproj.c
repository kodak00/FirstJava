#include <stdio.h>
#include <math.h>
#include "map_ini.h"

/***************************************************************************
*
*  [ Lambert Conformal Conic Projection ]
*
*      o lon, lat : (longitude,latitude) at earth  [degree]
*      o x, y     : (x,y) cordinate in map  [grid]
*      o code = 0 : (lon,lat) --> (x,y)
*               1 : (x,y) --> (lon,lat)
*
***************************************************************************/
int  lamcproj( lon, lat, x, y, code, map )
  float  *lon, *lat;         /* Longitude, Latitude [degree]  */
  float  *x, *y;             /* Coordinate in Map   [grid]    */
  int    code;               /* (0) lon,lat -> x,y  (1) x,y -> lon,lat */
  struct lamc_parameter *map;
{
  static double  PI, DEGRAD, RADDEG;
  static double  re, olon, olat, sn, sf, ro;
  double         slat1, slat2, alon, alat, xn, yn, ra, theta;

  if ((*map).first == 0) {
    PI = asin(1.0)*2.0;
    DEGRAD = PI/180.0;
    RADDEG = 180.0/PI;

    re = (*map).Re/(*map).grid;
    slat1 = (*map).slat1 * DEGRAD;
    slat2 = (*map).slat2 * DEGRAD;
    olon = (*map).olon * DEGRAD;
    olat = (*map).olat * DEGRAD;

    sn = tan(PI*0.25 + slat2*0.5)/tan(PI*0.25 + slat1*0.5);
    sn = log(cos(slat1)/cos(slat2))/log(sn);
    sf = tan(PI*0.25 + slat1*0.5);
    sf = pow(sf,sn)*cos(slat1)/sn;
    ro = tan(PI*0.25 + olat*0.5);
    ro = re*sf/pow(ro,sn);
    (*map).first = 1;
  }

  if (code == 0) {
    ra = tan(PI*0.25+(*lat)*DEGRAD*0.5);
    ra = re*sf/pow(ra,sn);
    theta = (*lon)*DEGRAD - olon;
    if (theta >  PI) theta -= 2.0*PI;
    if (theta < -PI) theta += 2.0*PI;
    theta *= sn;
    *x = (float)(ra*sin(theta)) + (*map).xo;
    *y = (float)(ro - ra*cos(theta)) + (*map).yo;
  }
  else {
    xn = *x - (*map).xo;
    yn = ro - *y + (*map).yo;
    ra = sqrt(xn*xn+yn*yn);
    if (sn < 0.0) -ra;
    alat = pow((re*sf/ra),(1.0/sn));
    alat = 2.0*atan(alat) - PI*0.5;
    if (fabs(xn) <= 0.0)
      theta = 0.0;
    else {
      if (fabs(yn) <= 0.0) {
        theta = PI*0.5;
        if (xn < 0.0) -theta;
      }
      else
        theta = atan2(xn,yn);
    }
    alon = theta/sn + olon;
    *lat = (float)(alat*RADDEG);
    *lon = (float)(alon*RADDEG);
  }
  return 0;
}

/***************************************************************************
*
*  [ Lambert Conformal Conic Projection ] - ellipsoid (WGS84)
*
*      o lon, lat : (longitude,latitude) at earth  [degree]
*      o x, y     : (x,y) cordinate in map  [grid]
*      o code = 0 : (lon,lat) --> (x,y)
*               1 : (x,y) --> (lon,lat)
*
***************************************************************************/
int  lamcproj_ellp( lon, lat, x, y, code, map )
  float  *lon, *lat;         /* Longitude, Latitude [degree]  */
  float  *x, *y;             /* Coordinate in Map   [grid]    */
  int    code;               /* (0) lon,lat -> x,y  (1) x,y -> lon,lat */
  struct lamc_parameter *map;
{
  static double  PI, DEGRAD, RADDEG;
  static double  ea, re, olon, olat, sn, sf, ro, f, ep;
  double slat1, slat2, alon, alat, xn, yn, ra, theta, m1, m2, t0, t1, t2;
  int    i;

  if ((*map).first == 0) {
    PI = asin(1.0)*2.0;
    DEGRAD = PI/180.0;
    RADDEG = 180.0/PI;

    ea = 6378.138;              // ��ݰ� (km)
    f  = 1.0/298.257223563;     // ���� : (��ݰ�-�ܹݰ�)/��ݰ�
    ep = sqrt(2.0*f - f*f);

    re = ea/(*map).grid;
    slat1 = (*map).slat1 * DEGRAD;
    slat2 = (*map).slat2 * DEGRAD;
    olon = (*map).olon * DEGRAD;
    olat = (*map).olat * DEGRAD;

    m1 = cos(slat1)/sqrt(1.0-ep*ep*sin(slat1)*sin(slat1));
    m2 = cos(slat2)/sqrt(1.0-ep*ep*sin(slat2)*sin(slat2));
    t1 = tan(PI*0.25 - slat1*0.5)/pow((1.0-ep*sin(slat1))/(1.0+ep*sin(slat1)), ep*0.5);
    t2 = tan(PI*0.25 - slat2*0.5)/pow((1.0-ep*sin(slat2))/(1.0+ep*sin(slat2)), ep*0.5);

    sn = (log(m1) - log(m2))/(log(t1) - log(t2));
    sf = m1/(sn*pow(t1, sn));

    t0 = tan(PI*0.25 - olat*0.5)/pow((1.0-ep*sin(olat))/(1.0+ep*sin(olat)), ep*0.5);
    ro = re*sf*pow(t0, sn);

    (*map).first = 1;
  }

  if (code == 0) {
    t0 = tan(PI*0.25 - (*lat)*DEGRAD*0.5)/pow((1.0-ep*sin((*lat)*DEGRAD))/(1.0+ep*sin((*lat)*DEGRAD)), ep*0.5);
    ra = re*sf*pow(t0, sn);
    theta = sn*((*lon)*DEGRAD - olon);

    *x = (float)(ra*sin(theta)) + (*map).xo;
    *y = (float)(ro - ra*cos(theta)) + (*map).yo;
  }
  else {
    xn = *x - (*map).xo;
    yn = ro - *y + (*map).yo;
    ra = sqrt(xn*xn + yn*yn);
    if (sn < 0.0) -ra;

    t0 = pow(ra/(re*sf), 1.0/sn);
    alat = PI*0.5 - 2.0*atan(t0);

    for (i = 0; i < 5; i++)
      alat = PI*0.5 - 2.0*atan(t0*pow((1.0-ep*sin(alat))/(1.0+ep*sin(alat)), ep*0.5));

    alon = atan2(xn, yn)/sn + olon;
    *lat = (float)(alat*RADDEG);
    *lon = (float)(alon*RADDEG);
  }
  return 0;
}
