#include <stdio.h>
#include <math.h>
#include "map_ini.h"

main()
{
    float  lon, lat, x, y, alon, alat;
    struct rdr_parameter map;
    int    i, j, ii;
    int    code1, code2;

    map.Re   = 6370.19584;
    map.grid = 4.0;
    map.olon = 127.0;
    map.olat = 35.0;
    map.xo   = 500.0;
    map.yo   = 500.0;
    map.curve = 0;
    map.Rc    = 6370.19584;
    map.first = 0;
/*
    for(;;) {
        printf(" input [lon, lat] ==>");
        scanf("%f %f", &lon,&lat);
        sterproj( &lon, &lat, &x, &y, 0, map );
        printf(" %f %f\n", x, y );
        sterproj( &lon, &lat, &x, &y, 1, map );
        printf(" %f %f\n", lon, lat );
    }
*/
    for(j = 10; j <= 70; j++)
    {
        printf("------- %d ------\n", j);

        for(i = 80; i <= 180; i++)
        {
            lon = i;
            lat = j;
            code1 = radarcon( &lon, &lat, &x, &y, 0, map );
            code2 = radarcon( &lon, &lat, &x, &y, 1, map );
            if ((fabs(fabs(lon-i)-360) > 0.01 && fabs(lon-i) > 0.01) || fabs(lat-j) > 0.01) {
                printf("(%3d, %3d) (%f, %f) (%f, %f) (%f, %f) (%d, %d)\n",
                        i, j, x, y, lon, lat, fabs(lon-i), fabs(lat-j), code1, code2 );
            }
            if (i%90 == 0) {
                printf("(%3d, %3d) (%f, %f) (%f, %f), (%f, %f)\n",
                        i, j, x, y, lon, lat, fabs(lon-i), fabs(lat-j) );
            }
        }
    }
    return 0;
}
