#include <stdio.h>
#include <time.h>

/******************************************************************
*
*  ����ð��� ���� (�����ð�, KST-9)
*
******************************************************************/

int  get_time( YY, MM, DD, HH, MI, SS )

int  *YY, *MM, *DD, *HH, *MI, *SS;
{
    struct tm  *now;
    time_t     ctm;

    time( &ctm );
    now  = localtime( &ctm );
    *YY  = ( now -> tm_year );
    if (*YY < 50)
        *YY += 2000;
    else
        *YY += 1900;
    *MM = ( now -> tm_mon  ) + 1;
    *DD = now -> tm_mday;
    *HH = now -> tm_hour;
    *MI = now -> tm_min;
    *SS = now -> tm_sec;

    return 0;
}

/******************************************************************
*
*  ����ð��� ���� (UTC)
*
******************************************************************/

int  get_time_utc( YY, MM, DD, HH, MI, SS )

int  *YY, *MM, *DD, *HH, *MI, *SS;
{
    struct tm  *now;
    time_t     ctm;

    time( &ctm );
    now  = gmtime( &ctm );
    *YY  = ( now -> tm_year );
    if (*YY < 50)
        *YY += 2000;
    else
        *YY += 1900;
    *MM = ( now -> tm_mon  ) + 1;
    *DD = now -> tm_mday;
    *HH = now -> tm_hour;
    *MI = now -> tm_min;
    *SS = now -> tm_sec;

    return 0;
}

/******************************************************************
*
*  �ð������� ���� �Ϸù�ȣ�� ��ȯ
*
*    o YY,MM,DD,HH,MI  : ��,��,��,��,��
*    o mode            : ��ȯ�� ����
*         . mode = 'd' : 1900. 1. 1.       ���� �ϼ�
*         . mode = 'h' : 1900. 1. 1. 00    ���� �ð���
*         . mode = 'm' : 1900. 1. 1. 00:00 ���� �м�
*
******************************************************************/

int  time2seq( YY, MM, DD, HH, MI, mode )

int  YY, MM, DD, HH, MI;
char mode;
{
    static int  month[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
    int  seq;
    int  i;

    seq = YY - 1900;
    seq = seq*365 + (seq + 3)/4;
    for( i = 0; i < MM-1; i++ )
        seq += month[i];
    if( ( MM > 2 ) && ( YY % 4 == 0 ) )  seq += 1;
    seq += DD - 1;

    if( mode == 'h' )
        seq = seq*24 + HH;
    else if( mode == 'm' )
        seq = ( seq*24 + HH )*60 + MI;

    return seq;
}

/******************************************************************
*
*  �Ϸù�ȣ�� �ð����� ��ȯ
*
*    o seq             : �Ϸù�ȣ
*    o YY,MM,DD,HH,MI  : �ð�
*    o mode            : seq�� ����
*         . mode = 'd' : 1900. 1. 1.       ���� �ϼ�
*         . mode = 'h' : 1900. 1. 1. 00    ���� �ð���
*         . mode = 'm' : 1900. 1. 1. 00:00 ���� �м�
*    o c24             : �ð���ȯ ���
*         . c24  = 'n' : 00:00
*         . c24  = 'y' : 24:00
*
******************************************************************/

int  seq2time( seq, YY, MM, DD, HH, MI, mode, c24 )

int  seq;
int  *YY, *MM, *DD, *HH, *MI;
char mode, c24;
{
    static int  month[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
    int    iseq, i;

    *MI = 0;
    if( mode == 'm' ) {
        *MI = seq % 60;
        seq /= 60;
    }
    *HH = 0;
    if( mode == 'h' || mode == 'm' ) {
        *HH  = seq % 24;
        seq /= 24;
        if( c24 == 'y' ) {
            if( *HH == 0 && *MI == 0 ) {
                *HH = 24;
                *MI = 0;
                seq -= 1;
            }
        }
    }
    *YY = (seq/1461)*4 + 1900;
    if( (seq %= 1461) > 365 ) {
        seq -= 366;
        *YY += seq/365 + 1;
        seq %= 365;
    }

    seq += 1;
    if( (*YY % 4) == 0 )
        month[1] = 29;
    else
        month[1] = 28;

    for( i = 0; i < 12; i++ ) {
        if( seq > month[i] )
            seq -= month[i];
        else {
            *MM = i + 1;
            *DD = seq;
            break;
        }
    }
    return 0;
}
