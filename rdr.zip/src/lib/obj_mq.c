#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <math.h>
#include "nrutil.h"

/*****************************************************************************
*  < LU decomposition >
*                                               from  Numerical Recips
*****************************************************************************/
#define TINY 1.0e-20;

int ludcmp(double **a, int n, int *indx, float *d)
{
    int i,imax,j,k;
    double big,dum,sum,temp;
    double *vv;

    vv=dvector(0,n-1);
    *d=1.0;
    for (i=0;i<n;i++) {
        big=0.0;
        for (j=0;j<n;j++)
            if ((temp=fabs(a[i][j])) > big) big=temp;
        if (big == 0.0) printf("Singular matrix in routine LUDCMP");
        vv[i]=1.0/big;
    }
    for (j=0;j<n;j++) {
        for (i=0;i<j;i++) {
            sum=a[i][j];
            for (k=0;k<i;k++) sum -= a[i][k]*a[k][j];
            a[i][j]=sum;
        }
        big=0.0;
        for (i=j;i<n;i++) {
            sum=a[i][j];
            for (k=0;k<j;k++)
                sum -= a[i][k]*a[k][j];
            a[i][j]=sum;
            if ( (dum=vv[i]*fabs(sum)) >= big) {
                big=dum;
                imax=i;
            }
        }
        if (j != imax) {
            for (k=0;k<n;k++) {
                dum=a[imax][k];
                a[imax][k]=a[j][k];
                a[j][k]=dum;
            }
            *d = -(*d);
            vv[imax]=vv[j];
        }
        indx[j]=imax;
        if (a[j][j] == 0.0) a[j][j]=TINY;
        if (j != n-1) {
            dum=1.0/(a[j][j]);
            for (i=j+1;i<n;i++) a[i][j] *= dum;
        }
    }
    free_dvector(vv,0,n-1);
    return 0;
}

/**************************************************************************
*  < A * X = B  calculation >
*                                               from  Numerical Recips
**************************************************************************/
int lubksb(double **a, int n, int *indx, double b[])
{
    int i,ii=-1,ip,j;
    double sum;

    for (i=0;i<n;i++) {
        ip=indx[i];
        sum=b[ip];
        b[ip]=b[i];
        if (ii >= 0)
            for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
        else if (sum) ii=i;
        b[i]=sum;
    }
    for (i=n-1;i>=0;i--) {
        sum=b[i];
        for (j=i+1;j<n;j++) sum -= a[i][j]*b[j];
        b[i]=sum/a[i][i];
    }
    return 0;
}

/*****************************************************************************
*   hydroboloid fuction as the basis function for m-q interpolation
*
*       - input -
*           (x1,y1) : Normalized coordinate of pistion 1
*           (x2,y2) : Normalized coordinate of pistion 2
*****************************************************************************/
double hydrof(double x1, double y1, double x2, double y2, double cc)
{
    double dx=x2-x1,dy=y2-y1,hf;
    hf = -sqrt( (dx*dx+dy*dy)*cc + 1.0 );
    return hf;
}

/*****************************************************************************
*   Multi-quadric interpolation
*
*       - input -
*           n     : number of the stations
*           x(n)  : normalized x-coordinate of the stations
*           y(n)  : normalized y-coordinate of the stations
*           v(n)  : observation value of the stations  (destroyed)
*           s(n)  : smooting value
*                   ( = n * smooting parameter
*                         * mean-squared observation error )
*           mp    : multiquadric parameter
*           ni,nj : grid number of x,y-coordinate (Center-point grid system)
*       - output -
*           g(ni,nj) : analyzed data at the grid points
******************************************************************************/
int mq_obj(int n, double *x, double *y, double *v, double *s, double mp, int ni, int nj, double **g)
{
    int    i,j,k;
    int    *indx;
    float  d;
    double dx=1.0/(ni-1),dy=1.0/(nj-1),cc=1.0/(mp*mp);
    double x1,y1,q1;
    double **q;

    /* allocation of memory */
    q=dmatrix(0,n-1,0,n-1);
    indx=ivector(0,n-1);

    /* Q-matrix */
    for (i=0;i<n;i++)
    for (j=i+1;j<n;j++) q[i][j] = hydrof(x[i],y[i],x[j],y[j],cc);
    for (i=1;i<n;i++)
    for (j=0;j<i;j++) q[i][j] = q[j][i];
    for (i=0;i<n;i++) q[i][i] = -1.0 + s[i];   /* Smooting parameter */

    /* LU decomposition of Q */
    ludcmp(q,n,indx,&d);

    /* (Invers matrix of Q)*v */
    lubksb(q,n,indx,v);

    /* Grid value (Center-point grid system) */
    for (j=0;j<nj;j++) {
        y1=dy*j;

        for (i=0;i<ni;i++) {
            x1=dx*i;

            for (q1=0.0, k=0;k<n;k++) q1 += v[k]*hydrof(x1,y1,x[k],y[k],cc);
            g[j][i]=q1;
        }
    }

    /* free allocation of memory */
    free_dmatrix(q,0,n-1,0,n-1);
    free_ivector(indx,0,n-1);

    return 0;
}
