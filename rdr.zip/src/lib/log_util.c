#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include <fcntl.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>

#define MAX_MSG_LEN		1000
#define BYTE           unsigned char


FILE	*pfLog = NULL;
char 	*GetByteStr(int nLen, BYTE *pBuff);
char	pByteStr[300];

void	LogTerm()
{
	if(pfLog != NULL)
	{
		fclose(pfLog);
		pfLog = NULL;
	}
}

int	LogInit(void *pLogFilePath)
{
	        
        if(!(pfLog = fopen(pLogFilePath, "a")))
        {
             return -1;
        }

        return 0;
}


void 	LogMsg(char *pFmt, ...)
{
    va_list  	vaList;
    char        szLogStr[MAX_MSG_LEN];

    struct timeval	tv;
    struct tm       *tm;
    
    if(pfLog == NULL)
    	return;

    va_start(vaList, pFmt);
    memset(szLogStr, 0x00, 200);

    vsprintf(szLogStr, pFmt, vaList);

    gettimeofday(&tv, 0);
    tm = localtime(&tv.tv_sec);

    fprintf(pfLog, "%04d/%02d/%02d=%02d:%02d:%02d:%06d : %s\n",
        tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday,
        tm->tm_hour, tm->tm_min, tm->tm_sec, tv.tv_usec,
        szLogStr);

    fflush(pfLog);

    va_end(vaList);
}

void	LogData(int nLen, char *pBuff)
{
    char    c[18];          /* save one line's worth of input */
    long    i;
    long    limit;          /* "nLen" rounded up mod-16 */
    int     j, k, l = 1;
    int     swatch = 0;     /* line suppression switch */
    char    tempchar;

    if((nLen <= 0) || (pfLog == NULL)) 
        return;

    limit = ((nLen + 15) >> 4) << 4;   /* "nLen" rounded up mod-16 */

    fprintf(pfLog,"==========================================================================\n");
    fprintf(pfLog,"RECEIVE DATA LENGTH : %d", nLen);
    fprintf(pfLog,
        "\nADDRESS   0--- 2--- 4--- 6--- 8--- A--- C--- E---      0-2-4-6-8-A-C-E-");

    for(j = 0;j < 18; j++)
        c[j] = '\0';    /* clear work area */

    for (i = 0, j = 0; i < limit; j++, i++)
    {
        /* for all of input */
        if (j > 15)
        {
            /* start a new line (not first line ever) */
            for(k = 0; k < 16; k++)
            {
                /* see if it matches old line */
                if(c[k] != pBuff[k])
                {
                    /* it doesn't match */
                    swatch = 0; /* mark no suppress */
                    break;
                }
            }

            if(k == 16)
            {
                /* line matches prev, will be suppressed */
                if(swatch == 0)
                {
                    /* first suppressed line, mark it */
                    swatch = 1;
                    fprintf(pfLog,"\n   ***");
                }

                i += 15;
                pBuff += 16;
                j = 15;
                continue;
            }

            j = 0;
        }

        if (j == 0)
        {
            /* start a new line */
            fprintf(pfLog,"\n%08lx  ",i);
        }

        if (i < nLen)
            fprintf(pfLog,"%02x",(c[j] = *(pBuff++)) & 0xff);
        else
        {
            /* finish partial (last) line */
            fprintf(pfLog, "  ");
            c[j] = ' ';
        }

        if ((l = 3 - l) == 1)
            fprintf(pfLog, " ");

        if (j == 15)
        {
            /* end-of-line == print the ASCII */
            fprintf(pfLog, "     ");
            for(k = 0; k < 16; k++)
            {
                tempchar = c[k];
                
             /*   if(nCode == EBCDIC_CODE)
                    tempchar = DebugE2A(tempchar);
             */
                if((tempchar > 0x1f) && (tempchar < 0x7f))
                    fprintf(pfLog, "%1c", tempchar);
                else
                    fprintf(pfLog, ".");
            }
        }
    }

    fprintf(pfLog,"\n==========================================================================");
    fprintf(pfLog, "\n\n");
    
    fflush(pfLog);
}



char   *GetByteStr(int nLen, BYTE *pBuff)
{
	char	pTemp[3];
	int		i;
	
	memset(pByteStr, 0x00, 300);
	for(i = 0; i < nLen; i++)
	{
		sprintf(pTemp, "%02x ", pBuff[i]);
		strcat(pByteStr, pTemp);
	}

	return pByteStr;
}

