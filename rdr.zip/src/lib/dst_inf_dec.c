/******************************************************************************
 *
 *  DST Information Decode Sub���α׷�
 *
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include "comn.h"

/*============================================================================*
 *
 *  DST Information Decode
 *
 *============================================================================*/
int dst_inf_dec(char *buf, struct DST_INF *inf)
{
    char dt = ':', dt2 = ',', tmp[4000];
    int  i, k, m;

    strcpy((*inf).buf, buf);

    /* �׸�� ���� */
    m = 0;
    for(i = 0; i < strlen(buf); i++) {
        if (buf[i] == dt) m++;
    }
    if (m < 15) return -1;

    /* ���� ���� */
    getword((*inf).nic, buf, dt);
    if (strlen((*inf).nic) <= 0) return -2;

    getword(tmp, buf, dt);
    (*inf).tp = atoi(tmp);
    if ((*inf).tp < 1 || (*inf).tp > 9) return -3;

    getword(tmp, buf, dt);
    (*inf).num = atoi(tmp);
    if ((*inf).num < 0 || (*inf).num > 99) return -4;

    getword((*inf).ip, buf, dt);
    getword((*inf).id, buf, dt);
    getword((*inf).pwd, buf, dt);

    for (i = 0; i < 32; i++) {
        (*inf).head[i][0] = '\0';
        (*inf).tail[i][0] = '\0';
        (*inf).excp[i][0] = '\0';
    }

    getword(tmp, buf, dt);
    for (i = 0; i < 32 && strlen(tmp) > 0; i++)
        getword((*inf).head[i], tmp, dt2);

    getword(tmp, buf, dt);
    for (i = 0; i < 32 && strlen(tmp) > 0; i++)
        getword((*inf).tail[i], tmp, dt2);

    getword(tmp, buf, dt);
    for (i = 0; i < 32 && strlen(tmp) > 0; i++)
        getword((*inf).excp[i], tmp, dt2);

    getword((*inf).dir, buf, dt);
    k = strlen((*inf).dir);
    if (k > 0) {
        if ((*inf).dir[k-1] == '/') (*inf).dir[k-1] = '\0';
    }

    getword((*inf).prg, buf, dt);
    if (strlen((*inf).prg) <= 0) return -5;

    getword(tmp, buf, dt);
    (*inf).fn = atoi(tmp);
    if ((*inf).fn > DST_FILE_MAX) (*inf).fn = DST_FILE_MAX;

    getword(tmp, buf, dt);
    (*inf).limit = atoi(tmp);
    if ((*inf).limit < 30) (*inf).limit = 30;
    if ((*inf).limit > 60*60*2) (*inf).limit = 60*60*2;

    getword(tmp, buf, dt);
    (*inf).mode = atoi(tmp);
    if ((*inf).mode < 0) return -6;

    getword(tmp, buf, dt);
    (*inf).stop = atoi(tmp);

    getword((*inf).name, buf, dt);

    (*inf).exe = 0;
    return 0;
}
