#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

/*---------------------------------------------------------------------------*/
/*  ȯ�溯�� ����                                                            */
/*---------------------------------------------------------------------------*/
int oracle_env_set()
{
    putenv("ORACLE_BASE=/usr/local/oracle");
    putenv("ORACLE_HOME=/usr/local/oracle/client/11g");
    putenv("NLS_LANG=AMERICAN_AMERICA.KO16KSC5601");
    putenv("ORA_NLS10=/usr/local/oracle/client/11g/nls/data");
    putenv("LD_LIBRARY_PATH=/usr/local/oracle/client/11g/:/usr/local/oracle/client/11g/lib32:/usr/local/oracle/client/11g/lib:/usr/lib:/usr/local/lib:/usr/local/trmm/lib");
    putenv("TNS_ADMIN=/usr/local/oracle/client/11g/network/admin");
    putenv("ORACLE_SID=SVC_COM");
    putenv("ORA_USER=comis@SVC_COM");
    putenv("ORA_PW=comis");
    putenv("PATH=/usr/lib64/qt-3.3/bin:/usr/kerberos/sbin:/usr/kerberos/bin:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/local/oracle/client/11g/bin:/home/obs/bin:/usr/local/php/bin:.");
    return 0;
}
