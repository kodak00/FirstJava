/******************************************************************
 *
 *  dst_main_man�� ���� DB�Է½� ó���� ���ϸ�� ó�� (MAIN) - ����
 *
 *================================================================*
 *
 *     o �ۼ��� : ����ȯ (2002.11.4)
 *
 ******************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>

#define LOG_DIR    "/LOGD/RECV"        /* �α� ���丮 */

FILE  *log_open();
FILE  *fd_log;                               /* Log File fd */
int   YYg, MMg, HHg, DDg, HHg, MIg, SSg;
char  msg_ini[256];


int main(int argc, char *argv[])
{
    char   out[512],fname[512];
    int    code;
    
    if (argc != 2)
    {
        printf("Error -> Correct arguments : [%s <FIle_name>] \n", argv[0]);
        exit(0);
    }

    memset(out, 0, sizeof(out));
    memset(fname, 0, sizeof(fname));
    
    strcpy(fname, argv[1]);

    /* Log File Open */
    fd_log = log_open(LOG_DIR, argv[0]);
    
    get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);
    
    /* DB ���� */
    if ( db_connect() < 0 )
    {
        sprintf(out, "$%02d%02d%02d:DB connect error\n", HHg, MIg, SSg);
        fputs(out, stdout);
        fprintf(fd_log, "%s", out);
        fclose(fd_log);
        exit(0);
    }
            
    /* ���� ó�� */
    code = file_dbi_main(fname);
    sprintf(out, "%s (%d)\n",fname, code);
    fputs(out, stdout);
        
    /* DB ���� ���� */
    db_disconnect();        

    /* Log File Close */
    fclose(fd_log);

    return 0;
}
