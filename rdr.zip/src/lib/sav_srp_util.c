#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <pwd.h>
#include <errno.h> 

extern FILE  *fd_log;
/*===============================================================*
 *
 *  �����ڷ� ó�� ���α׷� �ʱ�ȭ
 *
 *===============================================================*/
int sav_init(pname, uname, rcv_dir, work_mode)

    char  *pname;       /* ���μ����� */
    char  *uname;       /* ����ڸ� */
    char  *rcv_dir;     /* ���� ���丮 */
    int   work_mode;    /* 0:daemon, 10:rcv_dir ������ */
{
    char  tmp[64], *p;
    int   pid;

    /*-----------------------------------------------------------*/
    /* Process Name */

    p = strrchr(pname, '/');
    if (p != NULL)
    {
        strcpy(tmp, p+1);
        strcpy(pname, tmp);
    }

    /*-----------------------------------------------------------*/
    /* COMIS ���������� ���� ���� */

    if (proc_uid(uname) != 0)
    {
        fprintf(stderr, "[%s] User ID is not '%s'\n", pname, uname);
        return -1;
    }

    /*------------------------------------------------------------------------*/
    /* Daemon Init */

    if (work_mode%10 == 0)
    {
        if ( (pid = fork()) < 0 )
        {
            fprintf(stderr, "[%s] daemon init : fork error\n", pname);
            return -2;
        }
        else if (pid != 0)
        {
            exit(0);
        }
        setsid();
        umask(0);
    }

    /*-----------------------------------------------------------*/
    /* Change Working Directory */

    if (work_mode/10 == 0)
    {
        if (chdir(rcv_dir) != 0)
        {
            fprintf(stderr, "[%s] Change Dir Error (%s)\n", pname, rcv_dir);
            return -3;
        }
    }

    /*-----------------------------------------------------------*/
    /* PID ��� */

    if (work_mode%10 == 0)
    {
        if (proc_pid(pname) != 0)
        {
            fprintf(stderr, "[%s] PID write error\n", pname);
            return -4;
        }
    }
    return 0;
}

/*===============================================================*
 *
 *  �����ڷ� ������ ���丮 Ȯ�� �� �ڵ� ����
 *  ���丮 ���� ���н� ���丮 ��Ȯ�� �߰� (2007.09.12 -shkim)
 *
 *===============================================================*/
int sav_dir (dir_ini, step, YY, MM, DD, HH, dir)

    char  *dir_ini;          /* ���� ���丮 */
    int   step;              /* 0, 1(��), 2(��), 3(��), 4(��) ���� */
    int   YY, MM, DD, HH;    /* ��,��,��,�� */
    char  *dir;              /* ��� ���丮 */
{
    char   cmd[256];
    struct stat st;
    int    uid, gid;
    int    code;

    /*-----------------------------------------------------------*/
    /* ���翩�� Ȯ�� */

    switch (step)
    {
        case 0: sprintf(dir, "%s", dir_ini);  break;
        case 1: sprintf(dir, "%s/%04d", dir_ini, YY);  break;
        case 2: sprintf(dir, "%s/%04d%02d", dir_ini, YY, MM);  break;
        case 3: sprintf(dir, "%s/%04d%02d/%02d", dir_ini, YY, MM, DD);  break;
        case 4: sprintf(dir, "%s/%04d%02d/%02d/%02d", dir_ini, YY, MM, DD, HH);  break;
        default: return -9;
    }
    if ( stat(dir, &st) == 0 ) return 0;

    /*-----------------------------------------------------------*/
    /* ���� ���, �ڵ� ���� */

    /* start */
    if (step >= 0)
    {
        sprintf(dir, "%s", dir_ini);
        if ( stat(dir, &st) != 0 )
        {
            if ( mkdir(dir, 0755) != 0 ) 
            {
                if ( stat(dir, &st) != 0 )
                {
                	 fprintf(fd_log, "sav_dir() error(%d::%s)\n", errno, strerror (errno));
             		 return -91;	      	
                }
            }
        }
    }

    /* Year */
    if (step == 1)
    {
        sprintf(dir, "%s/%04d", dir_ini, YY);
        if ( stat(dir, &st) != 0 )
        {
            if ( mkdir(dir, 0755) != 0 )
            {
                if ( stat(dir, &st) != 0 )
                {
                	 fprintf(fd_log, "sav_dir() error(%d::%s)\n", errno, strerror (errno));
             		 return -92;	      	
                }
            }
        }
    }

    /* Month */
    if (step >= 2)
    {
        sprintf(dir, "%s/%04d%02d", dir_ini, YY, MM);
        if ( stat(dir, &st) != 0 )
        {
            if ( mkdir(dir, 0755) != 0 ) 
            {
                if ( stat(dir, &st) != 0 )
                {
                	 fprintf(fd_log, "sav_dir() error(%d::%s)\n", errno, strerror (errno));
             		 return -93;	      	
                }
            }
        }
    }

    /* Day */
    if (step >= 3)
    {
        sprintf(dir, "%s/%04d%02d/%02d", dir_ini, YY, MM, DD);
        if ( stat(dir, &st) != 0 )
        {
            if ( mkdir(dir, 0755) != 0 ) 
            {
                if ( stat(dir, &st) != 0 )
                {
                	 fprintf(fd_log, "sav_dir() error(%d::%s)\n", errno, strerror (errno));
             		 return -94;	      	
                }
            }
        }
    }

    /* Hour */
    if (step >= 4)
    {
        sprintf(dir, "%s/%04d%02d/%02d/%02d", dir_ini, YY, MM, DD, HH);
        if ( stat(dir, &st) != 0 )
        {
            if ( mkdir(dir, 0755) != 0 ) 
            {
                if ( stat(dir, &st) != 0 )
                {
                	 fprintf(fd_log, "sav_dir() error(%d::%s)\n", errno, strerror (errno));
             		 return -95;	      	
                }
            }
        }
    }
    return 0;
}


/*===============================================================*
 *
 *  �����ڷ� ������ ���丮 Ȯ�� �� �ڵ� ���� (������)
 *
 *===============================================================*/
int sav_dir2(dir_ini, step, YY, MM, DD, HH, dir)

    char  *dir_ini;          /* ���� ���丮 */
    int   step;              /* 0, 1(��), 2(��), 3(��), 4(��) ���� */
    int   YY, MM, DD, HH;    /* ��,��,��,�� */
    char  *dir;              /* ��� ���丮 */
{
    char   cmd[256];
    struct stat st;
    int    uid, gid;
    int    code;

    /*-----------------------------------------------------------*/
    /* ���翩�� Ȯ�� */

    switch (step)
    {
        case 0: sprintf(dir, "%s", dir_ini);  break;
        case 1: sprintf(dir, "%s/%04d", dir_ini, YY);  break;
        case 2: sprintf(dir, "%s/%04d/%02d", dir_ini, YY, MM);  break;
        case 3: sprintf(dir, "%s/%04d/%02d/%02d", dir_ini, YY, MM, DD);  break;
        case 4: sprintf(dir, "%s/%04d/%02d/%02d/%02d", dir_ini, YY, MM, DD, HH);  break;
        default: return -9;
    }
    if ( stat(dir, &st) == 0 ) return 0;

    /*-----------------------------------------------------------*/
    /* ���� ���, �ڵ� ���� */

    /* start */
    if (step >= 0)
    {
        sprintf(dir, "%s", dir_ini);
        if ( stat(dir, &st) != 0 )
        {
            if ( mkdir(dir, 0755) != 0 ) return -91;
        }
    }

    /* Year */
    if (step >= 1)
    {
        sprintf(dir, "%s/%04d", dir_ini, YY);
        if ( stat(dir, &st) != 0 )
        {
            if ( mkdir(dir, 0755) != 0 ) return -92;
        }
    }

    /* Month */
    if (step >= 2)
    {
        sprintf(dir, "%s/%04d/%02d", dir_ini, YY, MM);
        if ( stat(dir, &st) != 0 )
        {
            if ( mkdir(dir, 0755) != 0 ) return -93;
        }
    }

    /* Day */
    if (step >= 3)
    {
        sprintf(dir, "%s/%04d/%02d/%02d", dir_ini, YY, MM, DD);
        if ( stat(dir, &st) != 0 )
        {
            if ( mkdir(dir, 0755) != 0 ) return -94;
        }
    }

    /* Hour */
    if (step >= 4)
    {
        sprintf(dir, "%s/%04d/%02d/%02d/%02d", dir_ini, YY, MM, DD, HH);
        if ( stat(dir, &st) != 0 )
        {
            if ( mkdir(dir, 0755) != 0 ) return -95;
        }
    }
    return 0;
}

/*===============================================================*
 *
 *  ������ UID�� GID Ȯ��
 *
 *===============================================================*/
int uidgid (name, uid, gid)

    char  *name;        /* ������ (�Է°�) */
    int   *uid, *gid;   /* ������ UID, GID (�����) */
{
    struct passwd *pw;

    if ( (pw = getpwnam(name)) == NULL ) return -1;

    *uid = pw->pw_uid;
    *gid = pw->pw_gid;

    return 0;
}

/*===============================================================*
 *
 *  ���� ���� ������ �´��� Ȯ��
 *
 *===============================================================*/
int proc_uid (name)

    char  *name;     /* Ȯ���� ������ */
{
    struct passwd *pw;
    int    uid;

    if ( (pw = getpwnam(name)) == NULL ) return -1;
    uid = pw->pw_uid;

    if (uid != getuid()) return -1;
    return 0;
}

/*===============================================================*
 *
 *  ���μ��� ID�� ���
 *
 *===============================================================*/
#define PID_DIR "/comis/bin/PID"

int proc_pid (name)

    char  *name;     /* ���μ����� */
{
    FILE   *fd;
    char   fname[120], hostname[64];
    time_t tp;
    struct tm *tm1;

    if ( gethostname(hostname, 120) != 0 ) return -1;
    time(&tp);
    tm1 = localtime(&tp);

    sprintf(fname, "%s/%s.pid", PID_DIR, name);
    if ( (fd = fopen(fname, "w")) == NULL ) return -1;
    fprintf(fd, "%d:%s:%04d.%02d.%02d.%02d.%02d.%02d:\n",
                getpid(), hostname,
                tm1->tm_year+1900, tm1->tm_mon+1, tm1->tm_mday,
                tm1->tm_hour, tm1->tm_min, tm1->tm_sec);
    fclose(fd);
    return 0;
}

/*===============================================================*
 *
 *  Time Error Check
 *
 *===============================================================*/
int time_error_check (YY, MM, DD, HH, MI)

    int  YY, MM, DD, HH, MI;     /* ��,��,��,��,�� */
{
    if (YY < 1900 || YY > 2100) return -51;
    else if (MM < 1 || MM > 12) return -52;
    else if (DD < 1 || DD > 31) return -53;
    else if (HH < 0 || HH > 24) return -54;
    else if (MI < 0 || MI > 60) return -55;

    if (MM == 4 || MM == 6 || MM == 9 || MM == 11)
    {
        if (DD > 30) return -56;
    }
    else if (MM == 2)
    {
        if (DD > 29)
            return -57;
        else if (YY%4 != 0 && DD == 29)
            return -58;
    }
    return 0;
}

/*===============================================================*
 *
 *  File Copy / Append
 *
 *===============================================================*/
#define FILE_IO_BLKSIZE  8192

int file_copy(char *fname, char *oname)
{
    FILE  *f1, *f2;
    char  buf[FILE_IO_BLKSIZE];
    int   n, m, ncopy = 0;

    /* File Open */
    f1 = fopen(fname, "rb");
    if (f1 == NULL) return -1;

    f2 = fopen(oname, "wb");
    if (f2 == NULL)
    {
        fclose(f1);
        return -2;
    }

    /* Data Copy */
    while ( (n = fread(buf, 1, FILE_IO_BLKSIZE, f1)) > 0 )
    {
        m = fwrite(buf, 1, n, f2);
        ncopy += m;
        if (n < FILE_IO_BLKSIZE) break;
    }
    fclose(f1);
    fclose(f2);

    return ncopy;
}

int file_append(char *fname, char *oname)
{
    FILE  *f1, *f2;
    char  buf[FILE_IO_BLKSIZE];
    int   n, m, ncopy = 0;

    /* File Open */
    f1 = fopen(fname, "rb");
    if (f1 == NULL) return -1;

    f2 = fopen(oname, "ab");
    if (f2 == NULL)
    {
        fclose(f1);
        return -2;
    }

    /* Data Copy */
    while ( (n = fread(buf, 1, FILE_IO_BLKSIZE, f1)) > 0 )
    {
        m = fwrite(buf, 1, n, f2);
        ncopy += m;
        if (n < FILE_IO_BLKSIZE) break;
    }
    fclose(f1);
    fclose(f2);

    return ncopy;
}

/* ���� \n �� �߰� */

int file_append2(char *fname, char *oname)
{
    FILE  *f1, *f2;
    char  buf[FILE_IO_BLKSIZE];
    int   n, m, ncopy = 0;

    /* File Open */
    f1 = fopen(fname, "rb");
    if (f1 == NULL) return -1;

    f2 = fopen(oname, "ab");
    if (f2 == NULL)
    {
        fclose(f1);
        return -2;
    }

    /* Data Copy */
    while ( (n = fread(buf, 1, FILE_IO_BLKSIZE, f1)) > 0 )
    {
        m = fwrite(buf, 1, n, f2);
        ncopy += m;
        if (n < FILE_IO_BLKSIZE) break;
    }
    fclose(f1);

    strcpy(buf,"\n");
    n = strlen(buf);
    fwrite(buf, 1, n, f2);
    fclose(f2);

    return ncopy;
}

/*===============================================================*
 *
 *  1 ���ڵ带 ���Ͽ� ����
 *
 *===============================================================*/
#define MAXBUF 40960

int an_sav(buf, oname, mode)
    char *buf;      /* ������ �ڷ� ('\n'���� ������ ��) */
    char *oname;    /* ������ ���ϸ� */
    char mode;      /* 'a' (append, same check), 'w' (overwrite), 'p' (append) */
{
    FILE  *fd;
    char  b[MAXBUF];

    /* Same Data Check */
    if (mode == 'a')
    {
        if ( (fd = fopen(oname,"r")) != NULL)
        {
            while ( fgets(b, MAXBUF, fd) != NULL )
            {
                if (strcmp(buf, b) == 0)
                {
                    fclose(fd);
                    return 1;
                }
            }
            fclose(fd);
        }
    }

    /* Output File Open & Data Write */
    if (mode == 'w')
        fd = fopen(oname,"w");
    else
        fd = fopen(oname,"a");

    if (fd == NULL) return -78;

    fprintf(fd, "%s", buf);
    fclose(fd);

    return 0;
}

/*===============================================================*
 *
 *  LOG file open
 *
 *===============================================================*/
FILE *log_open(char *log_dir, char *proc_name)
{
    FILE   *fd;
    char   fname[120];
    time_t tp;
    struct tm *tm1;

    time(&tp);
    tm1 = localtime(&tp);

    sprintf(fname, "%s/%s_%04d%02d%02d.log",
                    log_dir, proc_name,
                    tm1->tm_year+1900, tm1->tm_mon+1, tm1->tm_mday);

    fd = fopen(fname, "a");
    if (fd == NULL)
        fd = stdout;
    else
        chmod(fname, 0777);
    return fd;
}

/*===============================================================*
 *
 *  ���μ��� üũ
 *
 *===============================================================*/
int process_check(char *proc_name)
{
    FILE  *fd;
    char  cmd[256];
    int   n;

    sprintf(cmd, "/bin/ps -ef|grep %s|wc", proc_name);
    fd = popen(cmd, "r");
    if (fd == NULL)
    {
        printf("pipe is not opened\n");
        exit(0);
    }

    fscanf(fd, "%d", &n);
    pclose(fd);

    if (n > 2)
    {
        printf("%s already running\n", proc_name);
        exit(0);
    }
    return 0;
}

/*===============================================================*
 *
 *  �ٳ����� ' '���� ��ȯ
 *
 *===============================================================*/
int nl2blank(char *str)
{
    int  i;

    for (i = 0; i < strlen(str); i++)
        if (str[i] == '\n') str[i] = ' ';
    return 0;
}

/*===============================================================*
 *
 *  ���� ' '���� ���� �� ���Ŀ� �ǵ��� �ٳ��� ����
 *
 *===============================================================*/
int str_rtrim(char *str)
{
    int  code = 0, i;

    for (i = strlen(str)-1; i >= 0; i--)
    {
        if (str[i] != ' ')
        {
            str[i+1] = '\0';
            code = 1;
            break;
        }
    }

    if (code == 0)
    {
        str[0] = '\0';
        return 0;
    }

    i = strlen(str) - 1;
    if (str[i] == '\n') str[i] = '\0';

    return 0;
}

