#define MAP_RE  6371.00877
#define PI_DFS  3.1415927
#define BAD_VALUE_F  -9999.

//typedef enum {REAL_CAPPI, PSEUDO_CAPPI} CAPPI_TYPE;
typedef struct
{
  int valid[2];
  float dBZ[2];   // dBZ
  int bin_num[2];
  float R[2];     // meter
} CLOEST_VALUES;

typedef struct
{
  int valid[2];
  Ray* r[2];
  CLOEST_VALUES values[2];
  float theta[2]; // azimuth 
} CLOEST_RAYS;

typedef struct
{
  int valid[2];
  Sweep* s[2];
  CLOEST_RAYS rays[2];
  float phi[2];   // elevation 
} CLOEST_SWEEPS;

static CLOEST_SWEEPS get_cloest_2_sweeps(Volume* volume,float elevation,float limit);
static CLOEST_RAYS get_cloest_2_rays(Sweep* s,float azimuth,float limit);
static CLOEST_VALUES get_cloest_2_bins(Ray* r,float range);

//float* KRL_cappi_at_h_cart(Volume* volume,float height_km,int xdim, int ydim, int range, float grid_size_km, CAPPI_TYPE pseudo_cappi, int is_dBZ)
float get_slant_range(float x, float y, float height,float grid_size);
float get_elevation(float x,float y,float h,float grid_size);
float get_azimuth(float x,float y);
float cal_mohr_cappi_value_f2(Volume* volume,CLOEST_SWEEPS cs,float azimuth,float elevation,float slant_range, int pseudo_cappi, int is_dBZ);
int get_closest_sweep_2_index(Volume *v,float sweep_angle,int* sweep_index1,int* sweep_index2);
float diff_degree(float alpha, float beta);
float minus_degree(float alpha, float beta);
int pseudo_cappi(Volume* volume,float height,int xdim, int ydim, int range, float grid_size);
