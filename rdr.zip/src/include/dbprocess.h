#define DBCFG "db.config"

void disconnect();
int db_connect();



