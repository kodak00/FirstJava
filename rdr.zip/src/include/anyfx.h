#include <sys/types.h>
#include <stdio.h>
#include <string.h>
/*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$*/
merge(aa, bb)
char *aa, *bb;
{
     FILE *in, *out;
     char line[BUFSIZ];

/*
 * Open the first file for reading.
 */
     if ((in = fopen(aa, "r")) == NULL) {
	  perror(aa);
     return -1;
     }

/*
 * Open the second file for writing.
 */
     if ((out = fopen(bb, "a")) == NULL) {
	  perror(bb);
     return -1;
     }

/*
 * Copy data from the first file to the second, one line 
 * at a time.
 */
     while (fgets(line, sizeof(line), in) != NULL)
	  fputs(line, out);
     fclose(out);
     fclose(in);
     return 0;
}
/*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$*/
int kaffilter(aa, bb)
char *aa, *bb;
{
     FILE *in, *out;
     char buf[BUFSIZ], line[100][BUFSIZ];
     int i=0, j=0, k=1;

/*
 * Open the first file for reading.
 */
     if ((in = fopen(aa, "r")) == NULL) {
	  perror(aa);
     return -1;
     }


/*
 * Copy data from the first file to the second, one line[i] 
 * at a time.
 */
     while (fgets(buf, sizeof(buf), in) != NULL) {
          if ((buf[0] == 'R' && buf[1] == 'K') && ((buf[2] == 'N' && buf[3] == 'F') ||
                                              (buf[2] == 'N' && buf[3] == 'L') ||
                                              (buf[2] == 'N' && buf[3] == 'O') ||
                                              (buf[2] == 'N' && buf[3] == 'R') ||
                                              (buf[2] == 'P' && buf[3] == 'C') ||
                                              (buf[2] == 'P' && buf[3] == 'M') ||
                                              (buf[2] == 'S' && buf[3] == 'C') ||
                                              (buf[2] == 'S' && buf[3] == 'D') ||
                                              (buf[2] == 'S' && buf[3] == 'F') ||
                                              (buf[2] == 'S' && buf[3] == 'J') ||
                                              (buf[2] == 'S' && buf[3] == 'O') ||
                                              (buf[2] == 'S' && buf[3] == 'P') ||
                                              (buf[2] == 'S' && buf[3] == 'Q') ||
                                              (buf[2] == 'S' && buf[3] == 'U') ||
                                              (buf[2] == 'S' && buf[3] == 'V') ||
                                              (buf[2] == 'S' && buf[3] == 'W') ||
                                              (buf[2] == 'T' && buf[3] == 'B') ||
                                              (buf[2] == 'T' && buf[3] == 'E') ||
                                              (buf[2] == 'T' && buf[3] == 'F') ||
                                              (buf[2] == 'T' && buf[3] == 'I') ||
                                              (buf[2] == 'T' && buf[3] == 'L') ||
                                              (buf[2] == 'T' && buf[3] == 'M') ||
                                              (buf[2] == 'T' && buf[3] == 'N') ||
                                              (buf[2] == 'T' && buf[3] == 'P') ||
                                              (buf[2] == 'T' && buf[3] == 'S') ||
                                              (buf[2] == 'T' && buf[3] == 'W'))) {
         continue;
     }
           strcpy(line[i], buf);
           i++;
     }
     for (j = 0; j <= i; j++) {
     if ((line[j][0] == 'R' && line[j][1] == 'K') && ((line[j][2] == 'T' && line[j][3] == 'H') ||
                                              (line[j][2] == 'T' && line[j][3] == 'Y') ||
                                              (line[j][2] == 'T' && line[j][3] == 'H') ||
                                              (line[j][2] == 'J' && line[j][3] == 'J') ||
                                              (line[j][2] == 'J' && line[j][3] == 'K') ||
                                              (line[j][2] == 'P' && line[j][3] == 'S') ||
                                              (line[j][2] == 'N' && line[j][3] == 'N') ||
                                              (line[j][2] == 'N' && line[j][3] == 'W') ||
                                              (line[j][2] == 'S' && line[j][3] == 'M'))) {
         printf("%s", line[i]);
         k=0;
         break;
     }
     }
     if (k == 0) {
/*
 * Open the second file for writing.
 */
     if ((out = fopen(bb, "a")) == NULL) {
	  perror(bb);
     return -1;
     }
     for (j = 0; j <= i; j++) {
	 fputs(line[j], out);
     }
     fclose(out);
     }
     fclose(in);
     return k;
}
/*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$*/
void gethead(char *dst, char *src, char stop)
{
    int i=0;
    while ((dst[i] = src[i]) != stop)
    {
       dst[i] = src[i];
       i++;
    }
    dst[i]='\0';
}
/*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$*/
void fcut(char *dst, char *src, int n)
{
    int i=0, j=0;
    char *p;
    for(i = 0; src[i] != NULL; i++)
    {
        if(src[i] == ' ')
            ++j;
                if (j == n)
                   break;
    }
    src[i]='\0';
    p = strrchr(src, ' ');
    if (p != NULL)
        strcpy(dst, p+1);
    else
        strcpy(dst, src);
}
/*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$*/
/*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$*/
/*
void gethead(char *word, char *line, char stop)
{
    int x = 0;
    for(x = 0; ((line[x]) && (line[x] != stop)); x++)
        word[x] = line[x];
    word[x] = '\0';
}
*/
/*
char *gethead(dst, src, stop)
    register char *dst, *src, stop;
{
    int i=0;
    while ((*dst++ = *src++) != stop)
    {
    continue;
    i++;
    }
    dst[i-1]='\0';
}
char * strcpy(char * dest,const char *src)
{
        char *tmp = dest;

        while ((*dest++ = *src++) != '\0')
*/
                /* nothing; */
/*
        return tmp;
}
*/
