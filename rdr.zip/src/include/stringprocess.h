#define WHITE_SPACE ' '
#define TAB '\t'
#define ENTER '\n'
#define CNULL '\0'
#define CR '\n'
#define LEFTPAREN '['
#define RIGHTPAREN ']'
#define INIDELI '='

#define FALSE 0
#define TRUE 1
#define MAX_BUF30 32768


int f_instr(char *, char *, int);
char *f_getprivatestring(char *, char *, char *);
char *f_getprivatestringA(char *, char *);
char *f_strreplace(char *, char *, char *);
char *f_strtrim(char *);
char *f_strlefttrim(char *);
char *f_strrighttrim(char *);
char *f_strleft(char *, int);
char *f_strright(char *, int);
char *f_substr( char *, int, int );
char* substr( char *, int, int );
char* subrstr( char *, int, int );
char* trim( char *);
char* replace( char *, int, int );
int f_getfilesize(char *);
int isdigitA(char *, int *);

