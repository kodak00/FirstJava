

/* Log level descriptions */
#define         LOG_TIME                0x0001
#define         LOG_COMMENT             0x0002
#define         LOG_80COLUMN   			0x0008
#define         LOG_HEADER              0x0010
#define         LOG_TEXT                0x0020
#define         LOG_NEW                 0x0100
#define         LOG_BACKUP              0x0200
#define         LOG_SEPARATOR   		0x0400
#define         LOG_DISPONLY   			0x0800

#define         LOG_FULL   ( LOG_TIME | LOG_COMMENT | LOG_HEADER | LOG_TEXT )
#define         LOG_FULL80 ( LOG_FULL | LOG_80COLUMN )

/* Log function return error code */
#define         LOG_SUCCESS      0               /* no error */
#define         LOG_OPENERR      1               /* file open error */
#define         LOG_WRITERR      2               /* write error */

#define LYEAR  (datetime->tm_year + 1900)
#define LMONTH (datetime->tm_mon	 + 1)
#define LDAY  (datetime->tm_mday)
#define LWDAY  (datetime->tm_wday)
#define LHOUR  (datetime->tm_hour)
#define LMINU  (datetime->tm_min)
#define LSEC	  (datetime->tm_sec)

#define LogFileMaxSize	(400L * 30720)

int LogToFile(char *, char *, char *);
