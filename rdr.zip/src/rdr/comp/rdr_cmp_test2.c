/*******************************************************************************
**
**  ���̴� �ռ���� ����2 : ������ ��
**
**=============================================================================*
**
**   o �ۼ��� : ����ȯ (2018.4.3)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "rsl_wrc.h"
#include "nrutil.h"
#include "stn_inf.h"
#include "map_ini.h"

#define  DEGRAD  3.1415927/180.0
#define  RADDEG  180.0/3.1415927
#define  RE  6371008.77   // ��������(m)
#define  NS  2000

struct lamc_parameter  map;
struct azed_parameter  rdr1;
struct rdr_parameter   rdr2;

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main(int argc, char *argv[])
{
  rdr_cmp_grd();
  return 0;
}

/*******************************************************************************
 *
 *  Radar data sum
 *
 *******************************************************************************/
int rdr_cmp_grd()
{
  float  stn_lon, stn_lat, stn_ht;
  float  cx[4], cy[4];
  float  lon, lat, x1, y1, x2, y2;
  int    x_min, x_max, y_min, y_max;
  int    seq1, seq2;
  int    i, j, k, i2, j2, ia, ja, ib, jb, di, dj;
  int    min_x, max_x, min_y, max_y;
  int    dx[41], dy[41];
  int    n;

  for (k = 0; k < 41; k++) {
    dx[k] = dy[k] = 0;
  }

  // 1. ���ǻ� ����
  stn_lon = 126.9640135;
  stn_lat = 37.44411208;
  stn_ht  = 640.0;

  // OUT Map parameter
  map.Re  = RE*0.001;
  map.grid  = 0.5;
  map.slat1 = 30.0;
  map.slat2 = 60.0;
  map.olon  = 126.0;
  map.olat  = 38.0;
  map.xo  = 4.0 * 140.0 / map.grid;
  map.yo  = 4.0 * 210.0 / map.grid;
  map.first = 0;

  // IN map parameter
  rdr1.Re  = RE*0.001;
  rdr1.grid  = 0.5;
  rdr1.slon  = stn_lon;
  rdr1.slat  = stn_lat;
  rdr1.olon  = stn_lon;
  rdr1.olat  = stn_lat;
  rdr1.xo  = 500.5;
  rdr1.yo  = 500.5;
  rdr1.first = 0;

  // IN map parameter
  rdr2.Re  = RE*0.001;
  rdr2.grid  = 0.5;
  //rdr2.slon  = stn_lon;
  //rdr2.slat  = stn_lat;
  rdr2.olon  = stn_lon;
  rdr2.olat  = stn_lat;
  rdr2.xo  = 500.5;
  rdr2.yo  = 500.5;
  rdr2.curve = 0;
  rdr2.Rc  = rdr2.Re;
  rdr2.first = 0;

  n = 0;
  for (j = 0; j <= rdr2.yo*2; j += 25) {
    y1 = j + 0.5;

    for (i = 0; i <= rdr2.xo*2; i += 25) {
      if (i != 500) continue;
      x1 = i + 0.5;

      azedproj(&lon, &lat, &x1, &y1, 1, &rdr1);
      //radarcon(&lon, &lat, &x1, &y1, 1, &rdr2);
      //printf("(%f,%f) (%f,%f) %d\n", x1, y1, lon, lat, rdr1.first);
      radarcon(&lon, &lat, &x2, &y2, 0, &rdr2);
      i2 = (int)x2;  j2 = (int)y2;
      printf("(%4d,%4d) (%f,%f) (%4d,%4d) (%3d,%3d)\n", i, j, lon, lat, i2, j2, i2-i, j2-j);
      n++;
    }
  }
  printf("n = %d\n", n);
  return 0;
}
