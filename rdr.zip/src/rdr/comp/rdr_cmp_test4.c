/*******************************************************************************
**
**  ���̴� HSR �ռ��ڷ� ���� ���α׷�
**
**=============================================================================*
**
**   o �ۼ��� : ����ȯ (2018.2.20)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "rsl_wrc.h"
#include "nrutil.h"
#include "map_ini.h"

#define  DEGRAD  3.1415927/180.0
#define  RADDEG  180.0/3.1415927
#define  RE  6371008.77   // ��������(m)

//-----------------------------------------------------------------------------
// �ռ��ڷ��� ���ڿ��� (1152 km x 1440 km : 0.5 km ���ڰ���)
#define  NI  1152
#define  NJ  1440

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main(int argc, char *argv[])
{
  struct azed_parameter  rdr;
  struct lamc_parameter  map;
  double cs, ss, re1, alpha, s, r, ec1, tc1, ec2, tc2;
  float  az1, az2, az3, range, range_max, beam_width;
  float  stn_lon, stn_lat, stn_ht;
  float  range_bin1, gate_size, elev;
  float  cx[4], cy[4];
  float  x1, y1, x2, y2;
  float  lon, lat;
  short  ec, tc;
  short  az[3600];
  char   echo[360][2000];
  int    num[100], n1, e1;
  int    nrays;
  int    x_min, x_max, y_min, y_max;
  int    nbin_max, first, code;
  int    seq1, seq2;
  int    i, j, k, i1, i2, ia, ja, ja1, ja2, ja3, ja4, k1, k2, k3, k4;

  // 2. �������� �ڷᰡ �ִ� �迭 ��ġ Ȯ��
  // 2.1. �ʱ�ȭ �� �ڷ� ����
  for (i = 0; i < 3600; i++)
    az[i] = -1;

  // 2.2. ������ Ȯ��
  nrays = 360;
  gate_size = 250;
  range_max = 240*1000*2;
  nbin_max = (int)(range_max/gate_size);
  beam_width = 1.0;
  elev = 0;

  for (j = 0; j < 360; j++) {
    for (i = 0; i < 2000; i++) {
      echo[j][i] = 0;
    }
  }

  for (j = 0; j < nrays; j++) {
    az1 = (j - 0.6*beam_width)*10;
    az2 = (j + 0.6*beam_width)*10;
    i1 = floor(az1);
    i2 = ceil(az2);
    if (i1 >= 0 && i2 < 3600) {
      for (i = i1; i <= i2; i++) {
        az3 = i;
        if (az3 >= az1 && az3 < az2) az[i] = j;
      }
    }
    else if (i1 < 0) {
      for (i = 0; i <= i2; i++) {
        az3 = i;
        if (az3 >= az1 && az3 < az2) az[i] = j;
      }
      for (i = 3600+i1-1; i < 3600; i++) {
        az3 = i;
        if (az3 >= az1+3600 && az3 < 3600) az[i] = j;
      }
    }
    else if (i2 >= 3600) {
      for (i = i1; i < 3600; i++) {
        az3 = i;
        if (az3 >= az1 && az3 < az2) az[i] = j;
      }
      for (i = 0; i <= i2-3600; i++) {
        az3 = i;
        if (az3 >= 0 && az3 < az2-3600) az[i] = j;
      }
    }
  }

  // 3. �ռ��� ���� ���� �ڷ�ó��
  // 3.1. ����Ʈ�� �浵, ����, ���� Ȯ��
  stn_lon = 126.9640135;
  stn_lat = 37.44411208;
  stn_ht  = 640.0;

  // 3.2. ���� ���
  cs = cos(elev * DEGRAD);
  ss = sin(elev * DEGRAD);
  re1 = 4.0*(RE+stn_ht)/3.0;

  // 4. ����Ʈ�� �ռ� ������ ���� �� �簢�� ������ ���� ��� ���
  // 4.1. ����Ʈ ������
  rdr.Re    = (RE + stn_ht)*0.001;
  rdr.grid  = 1.0;
  rdr.slon  = stn_lon;
  rdr.slat  = stn_lat;
  rdr.olon  = stn_lon;
  rdr.olat  = stn_lat;
  rdr.xo    = 0;
  rdr.yo    = 0;
  rdr.first = 0;

  // 4.2. �ռ� ������ (C-map)
  map.Re    = RE*0.001;
  map.grid  = 1.0;
  map.slat1 = 30.0;
  map.slat2 = 60.0;
  map.olon  = 126.0;
  map.olat  = 38.0;
  map.xo    = 800.0 / map.grid;
  map.yo    = 1000.0 / map.grid;
  map.first = 0;

  // 4.3. �簢�� ������ ���� ��� ���
  conv_cof(rdr, map, range_max, cx, cy, &x_min, &x_max, &y_min, &y_max);
  printf("[%4d,%4d] [%4d,%4d]\n", x_min, x_max, y_min, y_max);
  //x_min = (int)(map.xo - 600);
  //x_max = (int)(map.xo + 600);
  //y_min = (int)(map.yo - 600);
  //y_max = (int)(map.yo + 600);

  // 5. �ռ� (�ռ������� ����Ʈ ������ ���ں��� ó��)
  for (j = y_min; j <= y_max; j++) {
    for (i = x_min; i <= x_max; i++) {
      y2 = j;
      x2 = i;

      // 5.1. ��Ÿ������� ���� ��ġ���� ���
      //x1 = cx[0] + cx[1]*x2 + cx[2]*y2 + cx[3]*x2*y2;
      //y1 = cy[0] + cy[1]*x2 + cy[2]*y2 + cy[3]*x2*y2;
      lamcproj_ellp(&lon, &lat, &x2, &y2, 1, &map);
      azedproj(&lon, &lat, &x1, &y1, 0, &rdr);

      // 5.2. ����ǥ��� �̵��Ÿ� ���
      s = sqrt(x1*x1 + y1*y1)*1000;   // km -> m
      if (s >= range_max) continue;

      // 5.3. �� �浵�� �̵��Ÿ��� �׿� ���� �ڷ� �迭 ��ġ Ȯ��
      alpha = 1 - pow((double)(cs/sin(s/re1)), (double)(2.0));
      r = -(re1/alpha)*(sqrt(ss*ss - alpha) + ss);
      if (r >= range_max) continue;
      k = (int)((r - range_bin1)/gate_size);  // ������ ���ڼ�
      if (k < 0 || k >= nbin_max) continue;

      // 5.4. ���� ������ ��� �� �迭 ��ġ Ȯ��
      if (y1 > 0 || y1 < 0)
        az1 = atan2(x1, y1)*RADDEG;
      else
        az1 = 0;
      if (az1 < 0) az1 += 360;
      ia = (int)(az1*10);
      ja = az[ia];
      if (ja < 0 || ja >= nrays) continue;

      // 5.5. �ش� ��ġ�� ���ڰ��� �ع߰����� Ȯ��
      if      (r <  8000) { ja3 = 5; ja4 = 5; }
      else if (r < 12000) { ja3 = 3; ja4 = 3; }
      else if (r < 18000) { ja3 = 2; ja4 = 2; }
      else if (r < 24000) { ja3 = 1; ja4 = 2; }
      else if (r < 35000) { ja3 = 1; ja4 = 1; }
      else if (r < 60000) { ja3 = 0; ja4 = 1; }
      else                { ja3 = 0; ja4 = 0; }

      if (r < 275000) { k3 = 1; k4 = 2; }
      else            { k3 = 1; k4 = 2; }

      for (ja1 = ja-ja3; ja1 <= ja+ja4; ja1++) {
        ja2 = ja1;
        if (ja2 < 0) ja2 += nrays;
        if (ja2 >= nrays) ja2 -= nrays;

        for (k1 = k-k3; k1 <= k+k4; k1++) {
          if (k1 < 0 || k1 >= nbin_max) continue;
          echo[ja2][k1] += 1;
        }
      }
    }
  }

  // ��� Ȯ��
  // ��ü ���̴������߿��� ���� ����
  /*
  for (k = 0; k < 100; k++)
    num[k] = 0;

  for (j = 0; j < nrays; j++) {
    for (i = 0; i < nbin_max; i++)
      num[echo[j][i]] += 1;
  }
  */

  //for (k = 0; k < 100; k++)
  //  printf("n = %2d, %5d, %6.2f\n", k, num[k], 100.0*num[k]/(nrays*nbin_max));

  // ���������� ���� ����
  for (i = 0; i < nbin_max; i++) {
    for (k = 0; k < 100; k++)
      num[k] = 0;

    for (j = 0; j < nrays; j += 1) {
      k = echo[j][i];
      if (k > 12) k = 12;
      num[k] += 1;
    }

    printf("i = %3d : %6.2f :", i, i*0.25);
    for (k = 0; k <= 12; k++)
      printf(" %5.2f,", 100.0*num[k]/nrays);
//      printf("%4d,", num[k]);
    printf("\n");
  }

  // map���
  /*
  for (j = 0; j < nrays; j += 1) {
    for (i = 0; i < nbin_max; i += 1) {
      n1 = echo[j][i];
      if (n1 > 9) 
        printf("A");
      else
        printf("%d", n1);
    }
    printf("\n");
  }
  */

  return 0;
}

/*******************************************************************************
 *  ��ǥ��ȯ ��� ���
 *******************************************************************************/
int conv_cof(rdr, map, range_max, cx, cy, x_min, x_max, y_min, y_max)
  struct azed_parameter  rdr;
  struct lamc_parameter  map;
  float  range_max;
  float  cx[4], cy[4];
  int    *x_min, *x_max, *y_min, *y_max;
{
  float  xl[4], yl[4], xa[4], ya[4];
  float  lon, lat;
  float  t1, t2;
  int  i, j;

  // ����Ʈ map �������� �ױ����� ��ǥ
  xa[0] = -range_max*0.001;
  ya[0] = -range_max*0.001;
  xa[1] = range_max*0.001;
  ya[1] = -range_max*0.001;
  xa[2] = range_max*0.001;
  ya[2] = range_max*0.001;
  xa[3] = -range_max*0.001;
  ya[3] = range_max*0.001;

  // �ռ� map���� �ش�Ǵ� ��ǥ
  for (i = 0; i < 4; i++) {
    azedproj(&lon, &lat, &xa[i], &ya[i], 1, &rdr);
    lamcproj_ellp(&lon, &lat, &xl[i], &yl[i], 0, &map);
  }

  // �ռ� map������ ����
  *x_min = 99999;
  *x_max = -99999;
  *y_min = 99999;
  *y_max = -99999;

  for (i = 0; i < 4; i++) {
    if (*x_min > (int)xl[i]) *x_min = (int)xl[i];
    if (*x_max < (int)xl[i]) *x_max = (int)xl[i];
    if (*y_min > (int)yl[i]) *y_min = (int)yl[i];
    if (*y_max < (int)yl[i]) *y_max = (int)yl[i];
  }

  // �ռ� map���� ����Ʈ map���� ��ȯ��� ���
  matrix_cal(xa, xl, yl, cx);
  matrix_cal(ya, xl, yl, cy);

  return 0;
}

/*=============================================================================*
 *  ��� ���
 *=============================================================================*/
int matrix_cal(a, xl, yl, c)
  float a[4], xl[4], yl[4], c[4];
{
  float  mm[4][4], d;
  int  indx[4];
  int  i, j;

  for (j = 0; j < 4; j++) {
    mm[j][0] = 1.0;
    mm[j][1] = xl[j];
    mm[j][2] = yl[j];
    mm[j][3] = xl[j] * yl[j];
    c[j] = a[j];
  }

  ludcmp(mm,4,indx,&d);
  lubksb(mm,4,indx,c);

  return 0;
}

/*=============================================================================*
 *  < LU decomposition >            from  Numerical Recips
 *=============================================================================*/
int   lubksb(a,n,indx,b)
float a[4][4],b[4];
int   n,*indx;
{
  int  i,ii=-1,ip,j;
  float  sum;

  for (i=0;i<n;i++) {
    ip=indx[i];
    sum=b[ip];
    b[ip]=b[i];
    if (ii >= 0)
      for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
    else if (sum) ii=i;
    b[i]=sum;
  }
  for (i=n-1;i>=0;i--) {
    sum=b[i];
    for (j=i+1;j<n;j++) sum -= a[i][j]*b[j];
    b[i]=sum/a[i][i];
  }
  return 0;
}

/*=============================================================================*
 *  < LU decomposition >            from  Numerical Recips
 *=============================================================================*/
#define TINY 1.0e-20;

int   ludcmp(a,n,indx,d)
float a[4][4];
int   n,*indx;
float *d;
{
  int  i,imax,j,k;
  float  big,dum,sum,temp;
  float  vv[8];

  *d=1.0;
  for (i=0;i<n;i++) {
    big=0.0;
    for (j=0;j<n;j++) {
      if ((temp=fabs(a[i][j])) > big) big=temp;
    }
    if (big == 0.0) printf("Singular matrix in routine LUDCMP\n");
    vv[i]=1.0/big;
  }
  for (j=0;j<n;j++) {
    for (i=0;i<j;i++) {
      sum=a[i][j];
      for (k=0;k<i;k++) sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
    }
    big=0.0;
    for (i=j;i<n;i++) {
      sum=a[i][j];
      for (k=0;k<j;k++)
        sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
      if ( (dum=vv[i]*fabs(sum)) >= big) {
        big=dum;
        imax=i;
      }
    }
    if (j != imax) {
      for (k=0;k<n;k++) {
        dum=a[imax][k];
        a[imax][k]=a[j][k];
        a[j][k]=dum;
      }
      *d = -(*d);
      vv[imax]=vv[j];
    }
    indx[j]=imax;
    if (a[j][j] == 0.0) a[j][j]=TINY;
    if (j != n-1) {
      dum=1.0/(a[j][j]);
      for (i=j+1;i<n;i++) a[i][j] *= dum;
    }
  }
  return 0;
}
