/*******************************************************************************
**
**  ���̴� �ռ���� ����
**
**=============================================================================*
**
**   o �ۼ��� : ����ȯ (2018.4.3)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "rsl_wrc.h"
#include "nrutil.h"
#include "stn_inf.h"
#include "map_ini.h"

#define  DEGRAD  3.1415927/180.0
#define  RADDEG  180.0/3.1415927
#define  RE  6371008.77   // ��������(m)

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main(int argc, char *argv[])
{
  struct lamc_parameter  map;
  struct azed_parameter  rdr;
  float  stn_lon, stn_lat, stn_ht;
  float  range, range_max;
  float  cx[4], cy[4];
  float  lon, lat, x1, y1, x2, y2, x3, y3;
  float  dx, dy, dd, dd_avg, dd_std, dd_max, dd_min;
  int    dn[100];
  int    x_min, x_max, y_min, y_max;
  int    i, j, k, n;

  // 1. ���ǻ� ����
  stn_lon = 126.9640135;    // ���ǻ�
  stn_lat = 37.44411208;
  stn_ht  = 640.0;
  range_max = 240*1000;
  //range_max = 240*1000*2;   // 480km

  //stn_lon = 126.9640135;    // ������
  //stn_lat = 35.11880841;
  //stn_ht  = 547.0;

  // OUT Map parameter
  map.Re  = RE*0.001;
  map.grid  = 0.5;
  //map.grid  = 1.0;    // 480km
  map.slat1 = 30.0;
  map.slat2 = 60.0;
  map.olon  = 126.0;
  map.olat  = 38.0;
  map.xo  = 800.0 / map.grid;
  map.yo  = 1000.0 / map.grid;
  map.first = 0;

  // IN map parameter
  rdr.Re  = RE*0.001;
  rdr.grid  = 1.0;
  rdr.slon  = stn_lon;
  rdr.slat  = stn_lat;
  rdr.olon  = stn_lon;
  rdr.olat  = stn_lat;
  rdr.xo  = 0.0;
  rdr.yo  = 0.0;
  rdr.first = 0;

  // 2. �簢�� ������ ���� ��� ���
  conv_cof(rdr, map, range_max, cx, cy, &x_min, &x_max, &y_min, &y_max);
  printf("x = [%d,%d], y = [%d,%d]\n", x_min, x_max, y_min, y_max);

  // 3. ��ǥ ��ȯ
  n = 0;
  dd_avg = dd_std = 0;
  dd_max = -1;
  for (k = 0; k < 100; k++)
    dn[k] = 0;

  for (j = y_min; j <= y_max; j++) {
  for (i = x_min; i <= x_max; i++) {
    x1 = i + 0.5;
    y1 = j + 0.5;

    // 3.1. �簢�� ���� ������� ��ǥ ��ȯ
    x2 = cx[0] + cx[1]*x1 + cx[2]*y1 + cx[3]*x1*y1;
    y2 = cy[0] + cy[1]*x1 + cy[2]*y1 + cy[3]*x1*y1;

    // 3.2. ������������ ���� ��ǥ ��ȯ
    lamcproj_ellp(&lon, &lat, &x1, &y1, 1, &map);
    azedproj(&lon, &lat, &x3, &y3, 0, &rdr);
    range = sqrt(x3*x3 + y3*y3);
    if (range >= range_max) continue;

    // 3.3. ���� ��� �м�
    dx = x3 - x2;
    dy = y3 - y2;
    dd = sqrt(dx*dx + dy*dy);
    k = (int)(dd/0.5);
    dn[k]++;

    if (dd_max < dd) dd_max = dd;
    dd_avg += dd;
    dd_std += (dd*dd);
    n++;
  }
  }
  if (n > 1) {
    dd_avg /= (float)n;
    dd_std = sqrt(dd_std/(float)n - dd_avg*dd_avg);
  }
  dd_avg *= 1000;
  dd_std *= 1000;
  dd_max *= 1000;

  printf("n = %d, avg = %.0f, std = %.0f, max = %.0f\n", n, dd_avg, dd_std, dd_max);
  for (k = 0; k < 10; k++)
    printf("k = %d, %7d, %5.2f\n", k, dn[k], 100*(float)dn[k]/(float)n);

  return 0;
}

/*******************************************************************************
 *  ��ǥ��ȯ ��� ���
 *******************************************************************************/
int conv_cof(rdr, map, range_max, cx, cy, x_min, x_max, y_min, y_max)
  struct azed_parameter  rdr;
  struct lamc_parameter  map;
  float  range_max;
  float  cx[4], cy[4];
  int    *x_min, *x_max, *y_min, *y_max;
{
  float  xl[4], yl[4], xa[4], ya[4];
  float  lon, lat;
  float  t1, t2;
  int  i, j;

  // ����Ʈ map �������� �ױ����� ��ǥ
  xa[0] = -range_max*0.001;
  ya[0] = -range_max*0.001;
  xa[1] = range_max*0.001;
  ya[1] = -range_max*0.001;
  xa[2] = range_max*0.001;
  ya[2] = range_max*0.001;
  xa[3] = -range_max*0.001;
  ya[3] = range_max*0.001;

  // �ռ� map���� �ش�Ǵ� ��ǥ
  for (i = 0; i < 4; i++) {
    azedproj(&lon, &lat, &xa[i], &ya[i], 1, &rdr);
    lamcproj_ellp(&lon, &lat, &xl[i], &yl[i], 0, &map);
  }

  // �ռ� map������ ����
  *x_min = 99999;
  *x_max = -99999;
  *y_min = 99999;
  *y_max = -99999;

  for (i = 0; i < 4; i++) {
    if (*x_min > (int)xl[i]) *x_min = (int)xl[i];
    if (*x_max < (int)xl[i]) *x_max = (int)xl[i];
    if (*y_min > (int)yl[i]) *y_min = (int)yl[i];
    if (*y_max < (int)yl[i]) *y_max = (int)yl[i];
  }

  // �ռ� map���� ����Ʈ map���� ��ȯ��� ���
  for (i = 0; i < 4; i++) {
    xa[i] *= 0.6;
    ya[i] *= 0.6;
    azedproj(&lon, &lat, &xa[i], &ya[i], 1, &rdr);
    lamcproj_ellp(&lon, &lat, &xl[i], &yl[i], 0, &map);
  }
  matrix_cal(xa, xl, yl, cx);
  matrix_cal(ya, xl, yl, cy);

  return 0;
}

/*=============================================================================*
 *  ��� ���
 *=============================================================================*/
int matrix_cal(a, xl, yl, c)
  float a[4], xl[4], yl[4], c[4];
{
  float  mm[4][4], d;
  int  indx[4];
  int  i, j;

  for (j = 0; j < 4; j++) {
    mm[j][0] = 1.0;
    mm[j][1] = xl[j];
    mm[j][2] = yl[j];
    mm[j][3] = xl[j] * yl[j];
    c[j] = a[j];
  }

  ludcmp(mm,4,indx,&d);
  lubksb(mm,4,indx,c);

  return 0;
}

/*=============================================================================*
 *  < LU decomposition >            from  Numerical Recips
 *=============================================================================*/
int   lubksb(a,n,indx,b)
float a[4][4],b[4];
int   n,*indx;
{
  int  i,ii=-1,ip,j;
  float  sum;

  for (i=0;i<n;i++) {
    ip=indx[i];
    sum=b[ip];
    b[ip]=b[i];
    if (ii >= 0)
      for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
    else if (sum) ii=i;
    b[i]=sum;
  }
  for (i=n-1;i>=0;i--) {
    sum=b[i];
    for (j=i+1;j<n;j++) sum -= a[i][j]*b[j];
    b[i]=sum/a[i][i];
  }
  return 0;
}

/*=============================================================================*
 *  < LU decomposition >            from  Numerical Recips
 *=============================================================================*/
#define TINY 1.0e-20;

int   ludcmp(a,n,indx,d)
float a[4][4];
int   n,*indx;
float *d;
{
  int  i,imax,j,k;
  float  big,dum,sum,temp;
  float  vv[8];

  *d=1.0;
  for (i=0;i<n;i++) {
    big=0.0;
    for (j=0;j<n;j++) {
      if ((temp=fabs(a[i][j])) > big) big=temp;
    }
    if (big == 0.0) printf("Singular matrix in routine LUDCMP\n");
    vv[i]=1.0/big;
  }
  for (j=0;j<n;j++) {
    for (i=0;i<j;i++) {
      sum=a[i][j];
      for (k=0;k<i;k++) sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
    }
    big=0.0;
    for (i=j;i<n;i++) {
      sum=a[i][j];
      for (k=0;k<j;k++)
        sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
      if ( (dum=vv[i]*fabs(sum)) >= big) {
        big=dum;
        imax=i;
      }
    }
    if (j != imax) {
      for (k=0;k<n;k++) {
        dum=a[imax][k];
        a[imax][k]=a[j][k];
        a[j][k]=dum;
      }
      *d = -(*d);
      vv[imax]=vv[j];
    }
    indx[j]=imax;
    if (a[j][j] == 0.0) a[j][j]=TINY;
    if (j != n-1) {
      dum=1.0/(a[j][j]);
      for (i=j+1;i<n;i++) a[i][j] *= dum;
    }
  }
  return 0;
}
