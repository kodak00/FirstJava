/*******************************************************************************
**
**  HR������ ���� ��� � ���� 3���� �����м� ��� ����
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.10.16)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>

#include "cgiutil.h"
#include "nrutil.h"
#include "map_ini.h"
#include "url_io.h"
#include "rdr_cmp_header.h"

#define  DST_DIR        "/rdr/BUFD/OBS"  // �й� ���丮
#define  LOG_DIR        "/rdr/LOGD"      // �α� ���丮

// B-map(���̴�240km�ռ�) ����(km)
#define  HB_NX  1152
#define  HB_NY  1440
#define  HB_SX  560
#define  HB_SY  840

// C-map(���̴�480km�ռ�) ����(km)
#define  HC_NX  1600
#define  HC_NY  1600
#define  HC_SX  800
#define  HC_SY  1000

// �ռ�����(HR, km)
#define  COM_NX  1024
#define  COM_NY  1024
#define  COM_SX  440
#define  COM_SY  770

// �����м��� �ִ� ����
#define  MAX_HT  10000   // 10km����

//------------------------------------------------------------------------------
// ����� �Է� ����
struct INPUT_VAR {
  int   seq_now;      // ����ð� SEQ(��)
  int   seq;          // ���ؽð� or ����ð� SEQ(��)
  char  obs[8];       // ta,td,pa
  char  option[8];    // D3D, SFC ��
  char  map[8];       // ����� �����ڵ�
  float max_ht;       // �ִ����
  float ht;           // �����м��� ����(m)
  float grid;         // ����ũ��(km)
  int   grid_itv;     // �ڷ��� ���ڰ��� (1�̻�)
  char  disp;         // A(ASCII), B(����), C(csv)

  // ����� �ڷ�
  int   num_data;     // �� �ڷ��
  int   NX, NY;       // ���ڼ�, ���� ���������� ������ 1�� ���ϸ� ��
  int   SX, SY;       // ���� ������ ��ġ
} var;

FILE   *fp_log;
float  **g, **topo;
struct RDR_R3D_HEAD rdr_r3d_head;

// �Լ� ����
int rdr_r3d_obs_get(int, char *, int, int, int, float, int *);
int topo_get(int, int, int, int, float);
int data_obj_mq(int, int, int, float);
int rdr_r3d_obj_write(char);

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main(int argc, char *argv[])
{
  char  tm[20], tmp[20], str[200], fname[120];
  int   YY, MM, DD, HH, MI, SS;
  int   code;

  // 0. �μ� Ȯ��
  if (argc != 4) {
    printf("[Usage] %s {����Ͻú�} {ta|td|pa} {D3D|SFC}\n", argv[0]);
    return 0;
  }

  // 1. ����� ��û Ȯ��
  strcpy(tm, argv[1]);
  if (strlen(tm) >= 12) {
    strncpy(tmp, &tm[0], 4);  tmp[4]='\0';  YY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2]='\0';  MM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2]='\0';  DD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2]='\0';  HH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2]='\0';  MI = atoi(tmp);
    var.seq = time2seq(YY, MM, DD, HH, MI, 'm', 'n');
  }
  else if (atoi(tm) <= 0) {
    get_time(&YY, &MM, &DD, &HH, &MI, &SS);
    var.seq = time2seq(YY, MM, DD, HH, MI, 'm') - 3;
    var.seq = 5*(int)(var.seq/5) + atoi(tm);
    seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  }
  else {
    printf("[Usage] %s {����Ͻú�} {ta|td|pa} {D3D|SFC}\n", argv[0]);
    return 0;
  }
  strcpy(var.obs, argv[2]);
  strcpy(var.option, argv[3]);
  strcpy(var.map, "HR");
  var.max_ht = MAX_HT;

  // 2. �α����� ����
  get_time(&YY, &MM, &DD, &HH, &MI, &SS);
  sprintf(fname, "%s/rdr_r3d_obj_man-%s-%s_%04d%02d%02d.log", LOG_DIR, var.obs, var.option, YY, MM, DD);
  fp_log = fopen(fname, "a");
  if (fp_log == NULL) fp_log = stdout;

  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(str, "START %04d%02d%02d%02d%02d %s %s %.0f", YY, MM, DD, HH, MI, var.obs, var.option, var.max_ht);
  time_print(str);

  // 3. ����
  grid_map_inf(var.map, &(var.NX), &(var.NY), &(var.SX), &(var.SY), var.max_ht);
  if (strcmp(var.option, "SFC") == 0) {
    var.grid_itv = 1;
    var.ht = -99;
  }
  else {
    var.grid_itv = 4;
  }

  // 4. �����ڷ� �б�
  if (rdr_r3d_obs_get(var.seq, var.obs, var.NX/var.grid_itv, var.NY/var.grid_itv, var.grid_itv, var.max_ht, &(var.num_data)) < 0) return -1;
  sprintf(str, "OBS. Read (%d#)", var.num_data);
  time_print(str);

  // 5. ���� �����м�
  if (strcmp(var.option, "SFC") == 0) {
    topo_get(var.NY, var.NY, var.SX, var.SY, var.max_ht);
    time_print("TOPO Read");

    data_obj_mq(var.num_data, var.NX/var.grid_itv, var.NY/var.grid_itv, var.ht/var.max_ht);
    code = rdr_r3d_obj_write('w');
    time_print("SFC Write");
  }

  // 6. 3���� �����м�
  else {
    // 100m ���� (0~2km)
    for (var.ht = 0; var.ht < 2000; var.ht += 100) {
      data_obj_mq(var.num_data, var.NX/var.grid_itv, var.NY/var.grid_itv, var.ht/var.max_ht);
      rdr_r3d_obj_write('w');
      sprintf(str, "%.0fm Write", var.ht);
      time_print(str);
    }

    // 200m ���� (2~10km)
    for (var.ht = 2000; var.ht <= var.max_ht+10; var.ht += 200) {
      data_obj_mq(var.num_data, var.NX/var.grid_itv, var.NY/var.grid_itv, var.ht/var.max_ht);
      rdr_r3d_obj_write('w');
      sprintf(str, "%.0fm Write", var.ht);
      time_print(str);
    }
  }
  rdr_r3d_obj_write('c');
  time_print("END");

  // 7. �޸� ���� �� �α����� �ݱ�
  free_memory(var.option, var.num_data, var.NX/var.grid_itv, var.NY/var.grid_itv);
  fclose(fp_log);
  return 0;
}

/*******************************************************************************
 *  ��� ���
 *******************************************************************************/
int rdr_r3d_obj_write(char mode)
{
  static FILE  *fp;
  static char  fname[120], sname[120];
  static short  *gv, *v1;
  float  *g1;
  static int first = 0;
  int   YY, MM, DD, HH, MI;
  int   i, j, k, code;

  // ���� �ݱ�
  if (mode == 'c') {
    free_svector(gv, 0, rdr_r3d_head.nx-1);
    gzclose(fp);

    code = rename(sname, fname);
    time_print(fname);

    return 0;
  }

  // ������� ���
  if (first == 0) {
    rdr_r3d_head.version = 1;

    if      (strcmp(var.obs,"ta") == 0) rdr_r3d_head.ptype = 51;
    else if (strcmp(var.obs,"td") == 0) rdr_r3d_head.ptype = 52;
    else if (strcmp(var.obs,"pa") == 0) rdr_r3d_head.ptype = 53;

    seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
    rdr_r3d_head.tm.YY = YY;
    rdr_r3d_head.tm.MM = MM;
    rdr_r3d_head.tm.DD = DD;
    rdr_r3d_head.tm.HH = HH;
    rdr_r3d_head.tm.MI = MI;

    rdr_r3d_head.num_stn = 0;
    rdr_r3d_head.map_code = 3;    // HR
    rdr_r3d_head.map_etc = 0;
    rdr_r3d_head.nx = var.NX/var.grid_itv + 1;
    rdr_r3d_head.ny = var.NY/var.grid_itv + 1;
    rdr_r3d_head.dxy = 1000*var.grid_itv;

    if (strcmp(var.option,"D3D") == 0) {
      rdr_r3d_head.nz = 61;
      rdr_r3d_head.dz = 100;        // 100m
      rdr_r3d_head.z_min = 0;       // 0m
      rdr_r3d_head.num_data = 1;
      rdr_r3d_head.dz2 = 200;       // 200m
      rdr_r3d_head.z_min2 = 2000;   // 2km
    }
    else {
      rdr_r3d_head.nz = 1;      // �����̸� �Ѱ� ��
      rdr_r3d_head.dz = 0;
      rdr_r3d_head.z_min = 0;
      rdr_r3d_head.num_data = 1;
      rdr_r3d_head.dz2 = 0;
      rdr_r3d_head.z_min2 = 0;
    }

    if (strcmp(var.obs,"pa") == 0) {
      rdr_r3d_head.data_out = 0;
      rdr_r3d_head.data_in = 1;
      rdr_r3d_head.data_min = 2;
      rdr_r3d_head.data_minus = 0;
      rdr_r3d_head.data_scale = 10;
      rdr_r3d_head.data_unit = 22;    // hPa
    }
    else {
      rdr_r3d_head.data_out = 0;
      rdr_r3d_head.data_in = 10;
      rdr_r3d_head.data_min = 50;
      rdr_r3d_head.data_minus = 2000;
      rdr_r3d_head.data_scale = 10;
      rdr_r3d_head.data_unit = 21;    // C
    }
    rdr_r3d_head.num_obs = var.num_data;
    for (i = 0; i < 7; i++) rdr_r3d_head.etc[i] = 0;

    // ���ϸ�
    sprintf(fname, "%s/RDR_OBS_%s_%s_%04d%02d%02d%02d%02d.bin.gz",
            DST_DIR, var.obs, var.option, YY, MM, DD, HH, MI);
    sprintf(sname, "%s.tmp", fname);

    // ������
    fp = gzopen(sname, "wb");
    gzwrite(fp, &rdr_r3d_head, sizeof(rdr_r3d_head));

    gv = svector(0, rdr_r3d_head.nx-1);
    first = 1;
    time_print("Header Write");
  }

  // �ڷ� ���
  for (j = 0; j <= var.NY/var.grid_itv; j++) {
    for (g1 = g[j], v1 = &gv[0], i = 0; i <= var.NX/var.grid_itv; i++, g1++, v1++) {
      *v1 = (short)((*g1)*(rdr_r3d_head.data_scale) + rdr_r3d_head.data_minus);
    }
    gzwrite(fp, gv, 2*(rdr_r3d_head.nx));
  }
  return 0;
}
