#! /usr/local/php/bin/php -f
<?
//////////////////////////////////////////////////////////////////////////////////////////
//
//  ���̴� �����ڷ� ����
//
//////////////////////////////////////////////////////////////////////////////////////////

$dir1 = "/DATA/DFSD/VSRT/ODAM/"; //2017.12.04.Ȳ����.

$nt1 = mktime(0,0,0,6,1,2014);
$nt2 = mktime(23,50,0,6,30,2014);

for ($nt = $nt1; $nt <= $nt2; $nt += 10*60) {
  $dname = $dir1.date("Ym/d/",$nt)."RDR_PPI_COR_60M_".date("YmdHi",$nt).".bin.gz";
  if (!file_exists($dname)) {
    echo $dname."\n";
    $cmd = "/home/fct/bin/rdr_ppi_cor_60m ".date("YmdHi", $nt);
    //echo $cmd."\n";
    //system($cmd);
  }
  /*
  $cmd = "/home/fct/bin/rdr_ppi_cor_10m ".date("YmdHi", $nt);
  echo $cmd."\n";
  system($cmd);
  $cmd = "/home/fct/bin/rdr_ppi_cor_60m ".date("YmdHi", $nt);
  echo $cmd."\n";
  system($cmd);
  */
}
?>
