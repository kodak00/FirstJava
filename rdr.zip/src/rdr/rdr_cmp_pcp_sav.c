/*******************************************************************************
**
**  ���̴��ռ������ 60�� �����������ڷ� ���� ���α׷� (�ڵ�)
**
**=============================================================================*
**
**   o �ۼ��� : ����ȯ (2018.5.24)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>

#define PROC_USER "rdr"              // ���μ��� ����
#define LOG_DIR   "/rdr/LOGD"        // �α� ���丮

FILE   *log_open();
FILE   *fp_log;
int    YYg, MMg, HHg, DDg, MIg, SSg;
char   msg_ini[256];


int main(int argc, char *argv[])
{
  char   fname[120], cmd[256];
  int    seq, YY, MM, DD, HH, MI, SS;
  int    i, code;

  // 1. ��ó��
  if ( sav_init(argv[0], PROC_USER, "", 10) < 0 ) return -1;

  // 2. �ݺ� ����
  while (1) {
    // 3. Log File Open
    fp_log = log_open(LOG_DIR, argv[0]);

    // 4. ���ؽð� ����
    get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);
    seq = time2seq(YYg, MMg, DDg, HHg, MIg, 'm') - 2;
    seq = ( seq / 5 ) * 5;

    // 5. 30�� ������ ó��
    for (i = 0; i <= 30; i += 5) {
      // 5.1. �ð� ����
      seq2time(seq-i, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

      // 5.3. �αױ�Ͽ� ������ڿ� ����
      get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);
      sprintf(msg_ini, "#%02d%02d%02d:[%04d%02d%02d%02d%02d]",
              HHg, MIg, SSg, YY, MM, DD, HH, MI);

      // 5.4. HSR_KMA ����� �ռ��ڷ� ����
      fprintf(fp_log, "$%s:[HSR_KMA]", &msg_ini[1]);
      printf("$%s:[HSR_KMA]", &msg_ini[1]);
      sprintf(cmd, "rdr_cmp_pcp man HSR KMA 60 %d %d %d %d %d &", YY, MM, DD, HH, MI);
      code = system(cmd);
      fprintf(fp_log, ":%s (%d)\n", cmd, code);
      printf(":%s (%d)\n", cmd, code);

      // 5.5. HSR_MSK ����� �ռ��ڷ� ����
      fprintf(fp_log, "$%s:[HSR_MSK]", &msg_ini[1]);
      printf("$%s:[HSR_MSK]", &msg_ini[1]);
      sprintf(cmd, "rdr_cmp_pcp man HSR MSK 60 %d %d %d %d %d &", YY, MM, DD, HH, MI);
      code = system(cmd);
      fprintf(fp_log, ":%s (%d)\n", cmd, code);
      printf(":%s (%d)\n", cmd, code);

      // 5.6. HSR_EXT ����� �ռ��ڷ� ����
      fprintf(fp_log, "$%s:[HSR_EXT]", &msg_ini[1]);
      printf("$%s:[HSR_EXT]", &msg_ini[1]);
      sprintf(cmd, "rdr_cmp_pcp man HSR EXT 60 %d %d %d %d %d &", YY, MM, DD, HH, MI);
      code = system(cmd);
      fprintf(fp_log, ":%s (%d)\n", cmd, code);
      printf(":%s (%d)\n", cmd, code);

      // 5.7. PPI_NQC ����� �ռ��ڷ� ����
      fprintf(fp_log, "$%s:[PPI_NQC]", &msg_ini[1]);
      printf("$%s:[PPI_NQC]", &msg_ini[1]);
      sprintf(cmd, "rdr_cmp_pcp man PPI NQC 60 %d %d %d %d %d", YY, MM, DD, HH, MI);
      code = system(cmd);
      fprintf(fp_log, ":%s (%d)\n", cmd, code);
      printf(":%s (%d)\n", cmd, code);

      // 5.8. PPI_QCD ����� �ռ��ڷ� ����
      fprintf(fp_log, "$%s:[PPI_QCD]", &msg_ini[1]);
      printf("$%s:[PPI_QCD]", &msg_ini[1]);
      sprintf(cmd, "rdr_cmp_pcp man PPI QCD 60 %d %d %d %d %d", YY, MM, DD, HH, MI);
      code = system(cmd);
      fprintf(fp_log, ":%s (%d)\n", cmd, code);
      printf(":%s (%d)\n", cmd, code);

      // 5.9. PPI_EXT ����� �ռ��ڷ� ����
      fprintf(fp_log, "$%s:[PPI_EXT]", &msg_ini[1]);
      printf("$%s:[PPI_EXT]", &msg_ini[1]);
      sprintf(cmd, "rdr_cmp_pcp man PPI EXT 60 %d %d %d %d %d", YY, MM, DD, HH, MI);
      code = system(cmd);
      fprintf(fp_log, ":%s (%d)\n", cmd, code);
      printf(":%s (%d)\n", cmd, code);

      fflush(fp_log);
    }

    // 6. Log File Close
    fclose(fp_log);
    sleep(20);
  }
  return 0;
}
