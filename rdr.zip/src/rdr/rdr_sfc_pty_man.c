/*******************************************************************************
**
**  HR ���̴� �ռ��������� ������ �����Ǻ��� ���� �ڷ� ���
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.10.31)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>

#include "cgiutil.h"
#include "nrutil.h"
#include "rdr_cmp_header.h"

#define  DST_DIR        "/rdr/BUFD/OBS"  // �й� ���丮
#define  LOG_DIR        "/rdr/LOGD"      // �α� ���丮

// HR-map����(HR, km)
#define  HR_NX  1024
#define  HR_NY  1024
#define  HR_SX  440
#define  HR_SY  770

// �ռ��� �ڷῡ ����� �⺻��
#define  BLANK1  -30000     // No Area
#define  BLANK2  -25000     // No Data
#define  BLANK3  -20000     // Minimum Data

FILE   *fp_log;
int stn_info_get(int);
int aws_rain_data_get(int, int);
int aws_rain_obj(int, int, char *, short **);
int rdr_r3d_pty_get(int, char *, short **);
int rdr_cmp_hsr_echo_get(int, short **, char *);

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main(int argc, char *argv[])
{
  FILE  *fp;
  char  tm[20], tmp[20], str[120], fname[120], sname[120], rname[120];
  struct stat st;
  unsigned char **rnty, **rnsn, rdr_rnty;
  short **rain, **tw;
  int   nx = HR_NX*2+1, ny = HR_NY*2+1;   // HR������ 500m �� ����� ���ڼ�
  int   seq, num_stn, num_data;
  int   YY, MM, DD, HH, MI, SS;
  int   code;
  int   i, j, k;

  // 0. �μ� Ȯ��
  if (argc != 2) {
    printf("[Usage] %s {����Ͻú�|0|-5|-10|-30}\n", argv[0]);
    return 0;
  }

  // 1. ����� ��û Ȯ��
  strcpy(tm, argv[1]);
  if (strlen(tm) >= 12) {
    strncpy(tmp, &tm[0], 4);  tmp[4]='\0';  YY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2]='\0';  MM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2]='\0';  DD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2]='\0';  HH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2]='\0';  MI = atoi(tmp);
    seq = time2seq(YY, MM, DD, HH, MI, 'm', 'n');
  }
  else if (atoi(tm) <= 0) {
    get_time(&YY, &MM, &DD, &HH, &MI, &SS);
    seq = time2seq(YY, MM, DD, HH, MI, 'm') - 3;
    seq = 5*(int)(seq/5) + atoi(tm);
    seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  }
  else {
    printf("[Usage] %s {����Ͻú�|0|-5|-10|-30}\n", argv[0]);
    return 0;
  }
  //seq = time2seq(2018, 10, 28, 8, 50, 'm');

  // 2. �α����� ����
  get_time(&YY, &MM, &DD, &HH, &MI, &SS);
  sprintf(fname, "%s/rdr_sfx_pty_man_%04d%02d%02d.log", LOG_DIR, YY, MM, DD);
  fp_log = fopen(fname, "a");
  if (fp_log == NULL) fp_log = stdout;

  seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(str, "START %04d%02d%02d%02d%02d", YY, MM, DD, HH, MI);
  time_print(str);

  // 2. AWS ������ �����ڷ� �б�
  // 2.1. AWS �������� �б�
  num_stn = stn_info_get(seq);
  if (num_stn < 100) {
    sprintf(str, "END stn_info_get error (%d#)", num_stn);
    time_print(str);
    fclose(fp_log);
    return -1;
  }
  else {
    sprintf(str, "stn_info_get (%d#)", num_stn);
    time_print(str);
  }

  // 2.2. AWS �������� �� 15�а����� ����
  code = aws_rain_data_get(seq, num_stn);
  if (code < 0) {
    sprintf(str, "END aws_rain_data_get error (%d)", code);
    time_print(str);
    fclose(fp_log);
    return -2;
  }
  else {
    sprintf(str, "aws_rain_data_get");
    time_print(str);
  }

  // 3. AWS ����� �������� ���� ���
  rnsn = cmatrix(0, ny-1, 0, nx-1);
  rnty = cmatrix(0, ny-1, 0, nx-1);
  rain = smatrix(0, ny-1, 0, nx-1);

  num_data = aws_rain_obj(seq, num_stn, "rn_ex", rain);
  if (num_data < 0) {
    sprintf(str, "END aws_rain_obj [rn_ex] error (%d#)", num_data);
    time_print(str);
    fclose(fp_log);
    return -3;
  }
  else {
    sprintf(str, "aws_rain_obj [rn_ex] (%d#)", num_data);
    time_print(str);
  }
  for (j = 0; j < ny; j++) {
    for (i = 0; i < nx; i++)
      rnty[j][i] = (unsigned char)rain[j][i];
  }

  // 4. ���񰡴����� Ȯ��
  code = rdr_r3d_pty_get(seq, "rn_ex", rain);
  if (code < 0) {
    sprintf(str, "END rdr_r3d_pty_get [rn_ex] error (%d)", code);
    time_print(str);
    fclose(fp_log);
    return -4;
  }
  else {
    sprintf(str, "rdr_r3d_pty_get [rn_ex]");
    time_print(str);
  }
  for (j = 0; j < ny; j++) {
    for (i = 0; i < nx; i++)
      rnsn[j][i] = (unsigned char)rain[j][i];
  }

  // 5. ���̴� HSR����� ������ ����
  //    ��û�ð� ��� 5���� ���� ���
  //    (���̴��� �������۱����̰�, AWS�� ����ð��̶� ���߱� ����)
  code = rdr_cmp_hsr_echo_get(seq-5, rain, rname);
  if (code < 0) {
    sprintf(str, "END rdr_cmp_hsr_echo_get error (%d)", code);
    time_print(str);
    fclose(fp_log);
    return -5;
  }
  else {
    sprintf(str, "rdr_cmp_hsr_echo_get (%s)", rname);
    time_print(str);
  }

  // 6. ���񱸺� ����
  for (j = 0; j < ny; j++) {
    for (i = 0; i < nx; i++) {
      // 6.1. AWS��� ���񿵿�����
      if (rnty[j][i] > 1 && rnsn[j][i] > 1) {
        rnty[j][i] = rnsn[j][i];
      }

      // ���̴���� ���񿵿�����
      if (rain[j][i] > BLANK1) {
        if (rain[j][i] > 0) {
          rdr_rnty = 2;
          if (rnsn[j][i] > 1) rdr_rnty = rnsn[j][i];
        }
        else {
          rdr_rnty = 1;
        }
      }
      else {
        rdr_rnty = 0;
      }

      // AWS+���̴� �м���� ����
      rnty[j][i] = rdr_rnty*16 + rnty[j][i];
    }
  }
  sprintf(str, "AWS+���̴� ���񿵿��м���� ����");
  time_print(str);

  // 7. ��� ���� �� �߰����
  // 7.1. ������� OPEN
  sprintf(sname, "%s/RDR_SFC_PTY_%04d%02d%02d%02d%02d.bin.gz.tmp", DST_DIR, YY, MM, DD, HH, MI);
  fp = gzopen(sname,"wb");
  if (fp == NULL) {
    sprintf(str, "output file open error (%s)", sname);
    time_print(str);
    fclose(fp_log);
    return -6;
  }
  else {
    sprintf(str, "output file open (%s)", sname);
    time_print(str);
  }
  rdr_sfc_pty_head_write(fp, seq);
  sprintf(str, "Header Write");
  time_print(str);

  // 7.2. �������� ����
  for (j = 0; j < ny; j++)
    gzwrite(fp, rnty[j], nx);
  sprintf(str, "���񿵿� ����");
  time_print(str);

  // 7.3. ���񰡴����� ����
  for (j = 0; j < ny; j++)
    gzwrite(fp, rnsn[j], nx);
  sprintf(str, "���񰡴ɿ��� ����");
  time_print(str);

  // 7.4. ������� �迭 ����
  free_cmatrix(rnsn, 0, ny-1, 0, nx-1);
  free_cmatrix(rnty, 0, ny-1, 0, nx-1);

  // 8. �����µ� ��� �� ����
  tw = smatrix(0, ny-1, 0, nx-1);
  code = rdr_r3d_pty_get(seq, "tw", tw);
  if (code < 0) {
    sprintf(str, "END rdr_r3d_pty_get [tw] error (%d)", code);
    time_print(str);
    gzclose(fp);
    fclose(fp_log);
    return -7;
  }
  else {
    sprintf(str, "rdr_r3d_pty_get [tw]");
    time_print(str);
  }

  for (j = 0; j < ny; j++)
    gzwrite(fp, tw[j], nx*2);
  sprintf(str, "�����µ� ����");
  time_print(str);
  free_smatrix(tw, 0, ny-1, 0, nx-1);

  // 9. ���̴� ������ ����
  for (j = 0; j < ny; j++)
    gzwrite(fp, rain[j], nx*2);
  sprintf(str, "���̴� ������ ����");
  time_print(str);

  // 9. 15�а�����*4 ����
  num_data = aws_rain_obj(seq, num_stn, "rn_15x", rain);
  if (num_data < 0) {
    sprintf(str, "END aws_rain_obj [rn_15x] error (%d#)", num_data);
    time_print(str);
    gzclose(fp);
    fclose(fp_log);
    return -3;
  }
  else {
    sprintf(str, "aws_rain_obj [rn_15x] (%d#)", num_data);
    time_print(str);
  }
  for (j = 0; j < ny; j++)
    gzwrite(fp, rain[j], nx*2);
  sprintf(str, "15�а�����*4 ����");
  time_print(str);

  // 10. ������
  gzclose(fp);
  code = stat(sname, &st);
  sprintf(fname, "%s/RDR_SFC_PTY_%04d%02d%02d%02d%02d.bin.gz", DST_DIR, YY, MM, DD, HH, MI);
  code = rename(sname, fname);
  sprintf(str, "END %s (%d) %dbytes\n", fname, code, st.st_size);
  time_print(str);

  // 6. ǥ��
  /*
  seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  for (k = 0; k < num_stn; k++) {
    printf("%04d%02d%02d%02d%02d,", YY, MM, DD, HH, MI);
    printf("%4s,", stn_data[k].gov_cd);
    printf("%5d,", stn_data[k].stn_id);
    printf("%20s,", stn_data[k].stn_ko);
    printf("%12.8f,", stn_data[k].x);
    printf("%12.8f,", stn_data[k].y);
    printf("%7.2f,", stn_data[k].ht);
    printf("%2d,", stn_data[k].re);
    printf("%2d,", stn_data[k].re_base);
    printf("%4d,", stn_data[k].rn_15x);
    printf("=\n");
  }
  */

  return 0;
}

/*******************************************************************************
 *  HEAD ����
 *******************************************************************************/
int rdr_sfc_pty_head_write(FILE *fp, int seq)
{
  struct RDR_CMP_HEAD  rdr_cmp_head;
  int   YY, MM, DD, HH, MI;
  int   YYg, MMg, DDg, HHg, MIg, SSg;
  int   i, j, k, code;

  seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm','n');
  get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);

  rdr_cmp_head.version = 2;
  rdr_cmp_head.ptype = 50;
  rdr_cmp_head.tm.YY = YY;
  rdr_cmp_head.tm.MM = MM;
  rdr_cmp_head.tm.DD = DD;
  rdr_cmp_head.tm.HH = HH;
  rdr_cmp_head.tm.MI = MI;
  rdr_cmp_head.tm.SS = 0;
  rdr_cmp_head.tm_in.YY = YYg;
  rdr_cmp_head.tm_in.MM = MMg;
  rdr_cmp_head.tm_in.DD = DDg;
  rdr_cmp_head.tm_in.HH = HHg;
  rdr_cmp_head.tm_in.MI = MIg;
  rdr_cmp_head.tm_in.SS = SSg;
  rdr_cmp_head.num_stn = 0;
  rdr_cmp_head.map_code = 3;  // HR
  rdr_cmp_head.map_etc = 0;
  rdr_cmp_head.nx = HR_NX*2+1;
  rdr_cmp_head.ny = HR_NY*2+1;
  rdr_cmp_head.nz = 1;
  rdr_cmp_head.dxy = 500;
  rdr_cmp_head.dz = 0;
  rdr_cmp_head.z_min = 0;
  rdr_cmp_head.num_data = 5;

  for (i = 0; i < 16; i++)
    rdr_cmp_head.data_code[i] = 0;
  rdr_cmp_head.data_code[0] = 7;  // ���̴� + AWS ��������
  rdr_cmp_head.data_code[1] = 7;  // ���񰡴ɿ���
  rdr_cmp_head.data_code[2] = 8;  // �����µ�
  rdr_cmp_head.data_code[3] = 5;  // RDR HSR EXT (NUM Mask)
  rdr_cmp_head.data_code[4] = 5;  // AWS 15�а�����*4

  for (i = 0; i < 15; i++)
    rdr_cmp_head.etc[i] = 0;

  gzwrite(fp, &rdr_cmp_head, sizeof(rdr_cmp_head));
  return 0;
}

/*=============================================================================*
 * �ð� ǥ��
 *=============================================================================*/
int time_print(char *buf)
{
  int YY, MM, DD, HH, MI, SS;
  get_time(&YY, &MM, &DD, &HH, &MI, &SS);
  printf("#%04d%02d%02d%02d%02d(%02d) : %s\n", YY, MM, DD, HH, MI, SS, buf);
  fprintf(fp_log, "#%04d%02d%02d%02d%02d(%02d) : %s\n", YY, MM, DD, HH, MI, SS, buf);
  return 0;
}
