/*******************************************************************************
**
**  ���̴� 480km �ռ��ڷ� ���� ���α׷� (�ڵ�)
**
**=============================================================================*
**
**   o �ۼ��� : ����ȯ (2018.3.29)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>

#define PROC_USER "rdr"              // ���μ��� ����
#define RCV_DIR   "/rdr/BUFD/RDR"    // ���� ���丮
#define LOG_DIR   "/rdr/LOGD"        // �α� ���丮

FILE   *log_open();
FILE   *fp_log;
int    YYg, MMg, HHg, DDg, MIg, SSg;
char   msg_ini[256];


int main(int argc, char *argv[])
{
  time_t tp;
  DIR  *dp;
  struct dirent  *dirp;
  struct stat st;
  char   fname[120], cmd[256];
  int  seq, YY, MM, DD, HH, MI, SS;
  int  i, code;

  // 1. ��ó��
  if ( sav_init(argv[0], PROC_USER, RCV_DIR, 0) < 0 ) return -1;

  // 2. �ݺ� ����
  while (1) {
    // 3. Log File Open
    fp_log = log_open(LOG_DIR, argv[0]);

    // 4. ���ؽð� ����
    get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);
    seq = time2seq(YYg, MMg, DDg, HHg, MIg, 'm');
    seq = ( seq / 10 ) * 10;

    // 5. 40�� ������ ó��
    for (i = 0; i <= 40; i += 10) {
      // 5.1. �ð� ����
      seq2time(seq-i, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

      // 5.3. �αױ�Ͽ� ������ڿ� ����
      get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);
      sprintf(msg_ini, "#%02d%02d%02d:[%04d%02d%02d%02d%02d]",
              HHg, MIg, SSg, YY, MM, DD, HH, MI);

      // 5.4. LNG NQC �ռ��ڷ� ����
      fprintf(fp_log, "$%s:[LNG_NQC]", &msg_ini[1]);
      printf("$%s:[LNG_NQC]", &msg_ini[1]);
      sprintf(cmd, "rdr_cmp_lng man NQC %d %d %d %d %d", YY, MM, DD, HH, MI);
      code = system(cmd);
      fprintf(fp_log, ":%s (%d)\n", cmd, code);
      printf(":%s (%d)\n", cmd, code);

      // 5.5. LNG QCD �ռ��ڷ� ����
      fprintf(fp_log, "$%s:[LNG_QCD]", &msg_ini[1]);
      printf("$%s:[LNG_QCD]", &msg_ini[1]);
      sprintf(cmd, "rdr_cmp_lng man QCD %d %d %d %d %d", YY, MM, DD, HH, MI);
      code = system(cmd);
      fprintf(fp_log, ":%s (%d)\n", cmd, code);
      printf(":%s (%d)\n", cmd, code);

      // 5.6. LNG EXT �ռ��ڷ� ����
      fprintf(fp_log, "$%s:[LNG_EXT]", &msg_ini[1]);
      printf("$%s:[LNG_EXT]", &msg_ini[1]);
      sprintf(cmd, "rdr_cmp_lng man EXT %d %d %d %d %d", YY, MM, DD, HH, MI);
      code = system(cmd);
      fprintf(fp_log, ":%s (%d)\n", cmd, code);
      printf(":%s (%d)\n", cmd, code);

      fflush(fp_log);
    }

    // 6. Log File Close
    fclose(fp_log);
    sleep(30);
  }
  return 0;
}
