/*******************************************************************************
**
**  레이더 CAPPI/PPI 합성자료 수동 생성 프로그램
**
**=============================================================================*
**
**   o 작성자 : 이정환 (2015.7.30)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "rdr_cmp_ppi.h"

#define LOG_DIR   "/home/rdr/LOGD"       // 로그 디렉토리

FILE   *log_open();
FILE   *fp_log;
int    YYg, MMg, HHg, DDg, MIg, SSg;
char   msg_ini[120];
struct INPUT_VAR var;

int main(int argc, char *argv[])
{
  char  *p;
  int   YY, MM, DD, HH, MI, code;

  // 0. 인수 확인
  if (argc != 8) {
    printf("[Usage] %s {man|new} {0|1|2|3} YY MM DD HH MI\n", argv[0]);
    printf("   설명 : man(없거나 수정된 지점만 추가), new(전부 새로 작성)\n");
    printf("   설명 : 0(No QC), 1(QC), 2(NQS), 3(+유관기관)\n");
    printf("   시간 : KST\n");
    return 0;
  }

  // 1. 사용자 요청 확인
  var.mode = argv[1][0];
  var.qcd = atoi(argv[2]);
  var.YY = atoi(argv[3]);
  var.MM = atoi(argv[4]);
  var.DD = atoi(argv[5]);
  var.HH = atoi(argv[6]);
  var.MI = atoi(argv[7]);
  var.seq = time2seq(var.YY, var.MM, var.DD, var.HH, var.MI, 'm');
  var.fname[0] = '\0';

  // 2. Log File Open
  p = strrchr(argv[0],'/');
  if (p == NULL)
    fp_log = log_open(LOG_DIR, argv[0]);
  else {
    p += 1;
    fp_log = log_open(LOG_DIR, p);
  }

  get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);
  var.seq_now = time2seq(YYg, MMg, DDg, HHg, MIg, 'm');
  sprintf(msg_ini, "#%02d%02d%02d:[%04d%02d%02d%02d%02d][CM%d]",
      HHg, MIg, SSg, var.YY, var.MM, var.DD, var.HH, var.MI, var.qcd);

  // 3. 시간 점검
  code = time_error_check(var.YY, var.MM, var.DD, var.HH, var.MI);
  if (code != 0) {
    fprintf(fp_log, "$%s:time error(%d)\n", &msg_ini[1], code);
    fclose(fp_log);
    return -1;
  }

  // 5. 실행
  rdr_cmp_ppi();
  fclose(fp_log);
  return 0;
}
