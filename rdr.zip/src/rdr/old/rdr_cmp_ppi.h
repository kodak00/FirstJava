//-----------------------------------------------------------------------------
// 사용자 입력 변수

struct INPUT_VAR {
  int  seq_now;       // 현재 시간
  int  seq;           // 자료 일련시각
  int  YY;            // 년
  int  MM;            // 월
  int  DD;            // 일
  int  HH;            // 시
  int  MI;            // 분
  int  qcd;           // QC 파일사용여부 (0:non-QC, 1:QCed)
  char fname[120];    // 합성된 파일명
  char wname[120];    // 작업용 파일명
  char mode;          // 작업단계 (n:new, m:man)
  int  rdr_stn_num;   // 처리 대상인 지점수
  int  num_action;    // 합성에 사용될 지점수
};

//-----------------------------------------------------------------------------
// 처리가능 레이더 목록

struct RDR_STN_LIST {
  char    stn_cd[8];      // 지점 코드
  int     seq;            // 자료 시작
  float   lat;            // 지점 위도(deg)
  float   lon;            // 지점 경도(deg)
  float   ht;             // 안테나 해발고도(m)
  int     org;            // 기관번호 (1:기상청,2:공군,3:미공군,4:국토부)
  float   seaecho;        // 파랑에코 최대 거리(km)
  time_t  tm_in;          // 파일 생성 시각
  int     mode;           // 0 -> C mode, 1 -> S mode
  int     exist;          // 파일 존재 여부 (1->존재)
  int     action;         // 처리 대상 여부 (1->처리)
  char    qcd[8];         // QC된 자료 사용시, 사용할 QC종류
};
