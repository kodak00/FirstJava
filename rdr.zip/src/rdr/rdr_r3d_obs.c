/*******************************************************************************
**
**  HR ���̴� �ռ������� ���� ��� 3���� �����м��� ���� �����ڷ� ����
**
**=============================================================================*
**
**     o �ۼ��� : ����ȯ (2018.9.16)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>

#include "cgiutil.h"
#include "nrutil.h"
#include "map_ini.h"
#include "url_io.h"
#include "rdr_cmp_header.h"

#define  DEGRAD   3.1415927/180.0
#define  RADDEG   180.0/3.1415927
#define  MAP_INI_FILE  "/rdr/REF/MAP/map.ini" // �������� ��������
#define  TOPO_FILE     "/DATA/GIS/TOPO/SRTM/topo_mapB_1km.bin"   // HB-map������ 1km �ػ� ��������

// B-map(���̴�240km�ռ�) ����(km)
#define  HB_NX  1152
#define  HB_NY  1440
#define  HB_SX  560
#define  HB_SY  840

// C-map(���̴�480km�ռ�) ����(km)
#define  HC_NX  1600
#define  HC_NY  1600
#define  HC_SX  800
#define  HC_SY  1000

// �ռ�����(HR, km)
#define  COM_NX  1024
#define  COM_NY  1024
#define  COM_SX  440
#define  COM_SY  770

extern FILE *fp_log;
extern float  **g, **topo;
double *pnt_x, *pnt_y, *pnt_z, *pnt_v;
double **px, **py, *pz;

int rdr_r3d_obs_get(int, char *, int, int, int, float, int *);
int topo_get(int, int, int, int, float);
int grid_smooth(float **, int, int, float);
int data_obj_mq(int, int, int, float);
double hydrof(double, double, double, double, double, double, double);
int mq_obj_prep(double *, double *, double *, double *, double *, double, int);

/*******************************************************************************
 *  �����ڷ� �б�
 *******************************************************************************/
int rdr_r3d_obs_get(
  int   seq,        // �ش�ð�(KST)
  char  *obs,       // �����ڵ�
  int   nx,         // ���ڼ� [0:nx,0:ny]
  int   ny,
  int   grid_itv,   // ���ڰ���(km)
  float max_ht,     // �ִ����(m)
  int  *num_data    // [OUT] �ڷ��
)
{
  URL_FILE *fr; 
  char   buf[1000], url[1000], tmp[500], stn_ko[32], stn_sp[16];
  int    YY, MM, DD, HH, MI;
  int    num_pnt;
  int    first = 0, k;

  // �ʱ�ȭ
  *num_data = num_pnt = 0;

  // URL
  seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  sprintf(url, "http://rdr.kma.go.kr/cgi-bin/url/nph-rdr_r3d_stn_pnt?obs=%s&tm=%04d%02d%02d%02d%02d&map=HR&disp=C",
          obs, YY, MM, DD, HH, MI);
  if ((fr = url_fopen(url, "r")) == NULL) {
    printf("# �����ڷ� URL-API OPEN ERROR (%s)\n", url);
    return -1;
  }

  // ������ �б�
  while (!url_feof(fr)) {
    url_fgets(buf, sizeof(buf), fr);
    if (buf[0] == '#') continue;

    if (first == 0) {
      *num_data = atoi(buf);
      pnt_x = dvector(0, *num_data-1);
      pnt_y = dvector(0, *num_data-1);
      pnt_z = dvector(0, *num_data-1);
      pnt_v = dvector(0, *num_data-1);
      first = 1;
      continue;
    }

    // �ص�
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');
    getword(tmp, buf, ',');  pnt_x[num_pnt] = atof(tmp)/(float)(grid_itv*nx);
    getword(tmp, buf, ',');  pnt_y[num_pnt] = atof(tmp)/(float)(grid_itv*ny);
    getword(tmp, buf, ',');  pnt_z[num_pnt] = atof(tmp)/(float)max_ht;
    getword(tmp, buf, ',');  pnt_v[num_pnt] = atof(tmp);
    num_pnt++;
  }
  url_fclose(fr);
  return 0;
}

/*******************************************************************************
 *  �������� �б�
 *******************************************************************************/
int topo_get(int nx, int ny, int sx, int sy, float max_ht)
{
  FILE  *fp;
  long  offset1 = (HB_SX-sx)*2;
  long  offset2 = (HB_NX-nx)*2 - offset1;
  short *topo1;
  int   i, j, k;

  // 1. ���� ����
  if ((fp = fopen(TOPO_FILE, "rb")) == NULL) return -1;
  topo = matrix(0, ny, 0, nx);
  topo1 = svector(0, nx);

  // 2. �ش�(64byts) + �Ʒ��κ� skip
  fseek(fp, (long)((HB_SY-sy)*(HB_NX+1)*2 + 64), SEEK_SET);

  // 3. HR ������ �б�
  for (j = 0; j <= ny; j++) {
    fseek(fp, offset1, SEEK_CUR);
    fread(topo1, 2, nx+1, fp);  // ���� 0.1m
    fseek(fp, offset2, SEEK_CUR);

    for (i = 0; i <= nx; i++)
      topo[j][i] = (0.1*(float)topo1[i] + 2.0)/max_ht;
  }
  fclose(fp);

  // 4. �ӽ� �迭 ����
  free_svector(topo1, 0, nx);

  // 5. ��Ȱȭ
  grid_smooth(topo, nx, ny, 1.0);
  grid_smooth(topo, nx, ny, 1.0);
  return 0;
}

/*******************************************************************************
 *  Grid data Smoothing (by 1-2-1 Smoothing)
 *  by ����ȯ (1997. 3. 15)
 *******************************************************************************/
int grid_smooth (
  float **gr,     // input -> output
  int   nx,       // ���� [0:nx,0:ny]
  int   ny,
  float missing   // ���ϴ� �ڷ� ����
)
{
  float  e[4], e1, e2;
  int    i, j;

  for (j = 0; j <= ny; j++) {
    e1 = gr[j][0];
    e[0] = gr[j][0];
    e[1] = gr[j][1];

    for (i = 1; i < nx; i++) {
      e[2] = gr[j][i+1];

      if (e[0] > missing && e[1] > missing && e[2] > missing)
        e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
      else if (e[0] > missing && e[1] <= missing && e[2] > missing)
        e2 = (e[0] + e[2]) * 0.5;
      else
        e2 = e[1];

      gr[j][i-1] = e1;
      e1 = e2;
      e[0] = e[1];
      e[1] = e[2];
    }
    gr[j][i-1] = e1;
  }

  for (i = 0; i <= nx; i++) {
    e1 = gr[0][i];
    e[0] = gr[0][i];
    e[1] = gr[1][i];

    for (j = 1; j < ny; j++) {
      e[2] = gr[j+1][i];

      if (e[0] > missing && e[1] > missing && e[2] > missing)
        e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
      else if (e[0] > missing && e[1] <= missing && e[2] > missing)
        e2 = (e[0] + e[2]) * 0.5;
      else
        e2 = e[1];

      gr[j-1][i] = e1;
      e1 = e2;
      e[0] = e[1];
      e[1] = e[2];
    }
    gr[j-1][i] = e1;
  }
  return 0;
}

/*******************************************************************************
 *  �����м� (MQ ���)
 *******************************************************************************/
int data_obj_mq(
  int   num_data, // ������
  int   nx,       // ���� [0:nx,0:ny]
  int   ny,
  float ht        // ����(����ȭ�� ����)
)
{
  double mq_mp = 0.0005, mq_sm = 1.0, gx, gy;
  double dx, dy, dz, hf, x1, y1, z1, q1;
  double *xp, *yp, *zp, *vp, *s;
  static double cc, data_min, data_max, dd;
  static int first = 0;
  float  *g1, *t1;
  int    i, j, k;

  if (first == 0) {
    // 0. �ӽù迭����
    s = dvector(0, num_data-1);

    // 1. �����м� ��� �����鿡�� �ִ�,�ּҰ� Ȯ��
    data_min = 99999;  data_max = -99999;
    for (k = 0; k < num_data; k++) {
      if (data_min > pnt_v[k]) data_min = pnt_v[k];
      if (data_max < pnt_v[k]) data_max = pnt_v[k];
    }
    dd = data_max - data_min;

    // 2. MQ�� �°� ����ȭ�۾� ����
    for (k = 0; k < num_data; k++) {
      if (data_max != data_min) {
        pnt_v[k] = (pnt_v[k]-data_min)/dd;
        s[k] = mq_sm*num_data*(0.1/dd)*(0.1/dd);
      }
      else {
        pnt_v[k] = pnt_v[k];
        s[k] = mq_sm*num_data*(0.1*0.1);
      }
    }

    // 3. �����м� ��ó��
    mq_obj_prep(pnt_x, pnt_y, pnt_z, pnt_v, s, mq_mp, num_data);
    free_dvector(s, 0, num_data-1);

    // 4. �ļ� ó���� ���� ���� ����
    gx = 1.0/nx;
    gy = 1.0/ny;
    cc = 1.0/(mq_mp*mq_mp);
    g = matrix(0, ny, 0, nx);

    // 5. �������
    if (ht >= 0) {
      pz = dvector(0, num_data-1);
    }

    py = dmatrix(0, ny, 0, num_data-1);
    for (j = 0; j <= ny; j++) {
      for (k = 0; k < num_data; k++) {
        dy = pnt_y[k] - gy*j;
        py[j][k] = dy*dy*cc;
      }
    }

    px = dmatrix(0, nx, 0, num_data-1);
    for (i = 0; i <= nx; i++) {
      for (k = 0; k < num_data; k++) {
        dx = pnt_x[k] - gx*i;
        px[i][k] = dx*dx*cc;
      }
    }
    time_print("INI Calc.");

    first = 1;
  }

  // 6. �������� �� ���
  if (ht < 0) {
    for (j = 0; j <= ny; j++) {
      for (g1 = g[j], i = 0; i <= nx; i++, g1++) {
        z1 = (double)topo[j][i];

        xp = px[i];
        yp = py[j];
        vp = &pnt_v[0];

        for (q1 = 0.0, k = 0; k < num_data; k++, xp++, yp++, vp++) {
          dz = pnt_z[k] - z1;
          //printf("(%d,%d,%d) %f %f %f %f\n", j, i, k, *xp, *yp, dz, *vp);
          hf = -sqrt(*xp + *yp + dz*dz*cc + 1.0);
          q1 += ((*vp)*hf);
        }
        *g1 = q1*dd + data_min;
        //printf("%.1f ", *g1);
      }
      //printf("\n");
    }
  }
  else {
    for (k = 0; k < num_data; k++) {
      dz = pnt_z[k] - ht;
      pz[k] = dz*dz*cc + 1.0;
      //if (first > 0) printf("%5d %f : %f %f\n", k, ht, dz, pz[k]);
    }

    for (j = 0; j <= ny; j++) {
      for (g1 = g[j], i = 0; i <= nx; i++, g1++) {
        xp = px[i];
        yp = py[j];
        zp = &pz[0];
        vp = &pnt_v[0];

        for (q1 = 0.0, k = 0; k < num_data; k++, xp++, yp++, zp++, vp++) {
          hf = -sqrt(*xp + *yp + *zp);
          q1 += ((*vp)*hf);
        }
        *g1 = q1*dd + data_min;
        //if (first > 0) printf("%.1f ", *g1);
      }
      //if (first > 0) printf("\n");
    }
  }
  first++;
  return 0;
}

/*=============================================================================*
 *  < LU decomposition >    from  Numerical Recips
 *=============================================================================*/
#define TINY 1.0e-20;

int ludcmp(double **a, int n, int *indx, float *d)
{
  int j,jmax,i,k;
  double big,dum,sum,temp;
  double *vv, *a1, *a2;

  vv=dvector(0,n-1);
  *d=1.0;
  for (j=0;j<n;j++) {
    big=0.0;
    for (a1=a[j],i=0;i<n;i++,a1++)
      if ((temp=fabs(*a1)) > big) big=temp;
    if (big == 0.0) printf("Singular matrix in routine LUDCMP");
    vv[j]=1.0/big;
  }
  for (i=0;i<n;i++) {
    for (j=0;j<i;j++) {
      sum=a[j][i];
      for (a1=a[j],k=0;k<j;k++,a1++) sum -= (*a1)*a[k][i];
      a[j][i]=sum;
    }
    big=0.0;
    for (j=i;j<n;j++) {
      sum=a[j][i];
      for (a1=a[j],k=0;k<i;k++,a1++) sum -= (*a1)*a[k][i];
      a[j][i]=sum;
      if ( (dum=vv[j]*fabs(sum)) >= big) {
        big=dum;
        jmax=j;
      }
    }
    if (i != jmax) {
      for (k=0;k<n;k++) {
        dum=a[jmax][k];
        a[jmax][k]=a[i][k];
        a[i][k]=dum;
      }
      *d = -(*d);
      vv[jmax]=vv[j];
    }
    indx[i]=jmax;
    if (a[i][i] == 0.0) a[i][i]=TINY;
    if (i != n-1) {
      dum=1.0/(a[i][i]);
      for (j=i+1;j<n;j++) a[j][i] *= dum;
    }
  }
  free_dvector(vv,0,n-1);
  return 0;
}

/*=============================================================================*
 *  < A * X = B  calculation >    from  Numerical Recips
 *=============================================================================*/
int lubksb(double **a, int n, int *indx, double b[])
{
  int j,jj=-1,jp,i;
  double sum, *a1;

  for (j=0;j<n;j++) {
    jp=indx[j];
    sum=b[jp];
    b[jp]=b[j];
    if (jj >= 0)
      for (a1=&a[j][jj], i=jj;i<=j-1;i++, a1++) sum -= (*a1)*b[i];
    else if (sum) jj=j;
      b[j]=sum;
  }
  for (j=n-1;j>=0;j--) {
    sum=b[j];
    for (a1=&a[j][j+1], i=j+1;i<n;i++, a1++) sum -= (*a1)*b[i];
    b[j]=sum/a[j][j];
  }
  return 0;
}

/*=============================================================================*
 *  hydroboloid fuction as the basis function for m-q interpolation
 *       - input -
 *           (x1,y1) : Normalized coordinate of pistion 1
 *           (x2,y2) : Normalized coordinate of pistion 2
 *=============================================================================*/
double hydrof(double x1, double y1, double z1, double x2, double y2, double z2, double cc)
{
  double dx=x2-x1, dy=y2-y1, dz=z2-z1, hf;
  hf = -sqrt( (dx*dx + dy*dy + dz*dz)*cc + 1.0 );
  return hf;
}

/*=============================================================================*
 *   Multi-quadric interpolation
 *
 *       - input -
 *           v(n) : observation value of the stations  (destroyed)
 *           s(n) : smooting value
 *                   ( = n * smooting parameter
 *                         * mean-squared observation error )
 *           mp   : multiquadric parameter
 *           num_stn : ������
 *=============================================================================*/
int mq_obj_prep(double *x, double *y, double *z, double *v, double *s, double mp, int num_stn)
{
  double cc=1.0/(mp*mp);
  double dx, dy, dz;
  double **q;
  float  d;
  int    *indx;
  int    i,j,k;

  // 1. �޸� �Ҵ�
  q = dmatrix(0, num_stn-1, 0, num_stn-1);
  indx = ivector(0, num_stn-1);

  // 2. Q-matrix ���
  for (i = 0; i < num_stn; i++) {
    for (j = i+1; j < num_stn; j++) {
      dx = x[j] - x[i];  dy = y[j] - y[i];  dz = z[j] - z[i];
      q[i][j] = -sqrt( (dx*dx + dy*dy + dz*dz)*cc + 1.0 );
      //q[i][j] = hydrof((double)x[i], (double)y[i], (double)z[i], (double)x[j], (double)y[j], (double)z[j], cc);
    }
    if (i >= num_stn-2) break;
  }
  for (i = 1; i < num_stn; i++) {
    for (j = 0; j < i; j++)
      q[i][j] = q[j][i];
  }
  for (i = 0; i < num_stn; i++)   // Smooting parameter
    q[i][i] = -1.0 + s[i];

  // 3. LU decomposition of Q
  ludcmp(q, num_stn, indx, &d);

  // 4. (Invers matrix of Q)*v
  lubksb(q, num_stn, indx, v);

  // 6. �޸� �ݳ�
  free_dmatrix(q,0,num_stn-1,0,num_stn-1);
  free_ivector(indx,0,num_stn-1);

  return 0;
}

/*******************************************************************************
 *  �޸��Ҵ� ����
 *******************************************************************************/
int free_memory(
  char *option,
  int  num_data,
  int  nx,
  int  ny
)
{
  free_matrix(g, 0, ny, 0, nx);
  if (strcmp(option, "SFC") == 0) free_matrix(topo, 0, ny, 0, nx);
  free_dmatrix(px, 0, nx, 0, num_data-1);
  free_dmatrix(py, 0, ny, 0, num_data-1);
  if (strcmp(option, "SFC") != 0) free_dvector(pz, 0, num_data-1);

  free_dvector(pnt_v, 0, num_data-1);
  free_dvector(pnt_z, 0, num_data-1);
  free_dvector(pnt_y, 0, num_data-1);
  free_dvector(pnt_x, 0, num_data-1);
  return 0;
}

/*=============================================================================*
 *  ���� ���� ���� �б�
 *
 *      map : inp:������ ����
 *      nx  : out:�������� �������� (km)
 *      ny  : out:���Ϲ��� �������� (km)
 *      sx  : out:�������� ������ġ (km)
 *      sy  : out:���Ϲ��� ������ġ (km)
 *=============================================================================*/
int grid_map_inf(char *map, int *nx, int *ny, int *sx, int *sy)
{
  FILE  *fp;
  char  buf[1024], map_list[8], value[16];

  fp = fopen(MAP_INI_FILE,"r");
  if (fp == NULL) exit(-1);

  while (fgets(buf,1024,fp)) {
    if (buf[0] == '#') continue;
    getword(map_list, buf, ':');

    if ( !strcmp(map, map_list) ) {
      getword(value, buf, ':');  *nx = atoi(value);
      getword(value, buf, ':');  *ny = atoi(value);
      getword(value, buf, ':');  *sx = atoi(value);
      getword(value, buf, ':');  *sy = atoi(value);
      break;
    }
  }
  fclose(fp);
  return 0;
}

/*=============================================================================*
 * �ð� ǥ��
 *=============================================================================*/
int time_print(char *buf)
{
  int YY, MM, DD, HH, MI, SS;
  get_time(&YY, &MM, &DD, &HH, &MI, &SS);
  printf("#%04d%02d%02d%02d%02d(%02d) : %s\n", YY, MM, DD, HH, MI, SS, buf);
  fprintf(fp_log, "#%04d%02d%02d%02d%02d(%02d) : %s\n", YY, MM, DD, HH, MI, SS, buf);
  return 0;
}
