/*******************************************************************************
**
**  레이더 CAPPI/PPI 합성자료 생성 프로그램 (자동)
**
**=============================================================================*
**
**   o 작성자 : 이정환 (2015.7.30)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>

#define PROC_USER "rdr"              // 프로세스 계정
#define LOG_DIR   "/rdr/LOGD"        // 로그 디렉토리

FILE   *log_open();
FILE   *fp_log;
int    YYg, MMg, HHg, DDg, MIg, SSg;
char   msg_ini[256];


int main(int argc, char *argv[])
{
  time_t tp;
  DIR    *dp;
  struct dirent  *dirp;
  struct stat st;
  char   fname[120], cmd[256];
  int    seq, YY, MM, DD, HH, MI, SS;
  int    i, code;

  // 1. 전처리
  if ( sav_init(argv[0], PROC_USER, "", 10) < 0 ) return -1;

  // 2. 반복 수행
  while (1) {
    // 3. Log File Open
    fp_log = log_open(LOG_DIR, argv[0]);

    // 4. 기준시간 설정
    get_time(&YY, &MM, &DD, &HH, &MI, &SS);
    seq = time2seq(YY, MM, DD, HH, MI, 'm');
    seq = ( seq / 5 ) * 5;

    // 5. 30분 전부터 처리
    for (i = 0; i <= 30; i += 5) {
      // 5.1. 시간 설정
      seq2time(seq-i, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

      // 5.3. 로그기록용 헤더문자열 생성
      get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);
      sprintf(msg_ini, "#%02d%02d%02d:[%04d%02d%02d%02d%02d]",
              HHg, MIg, SSg, YY, MM, DD, HH, MI);

      // 5.8. 외부기관까지 합친 QC기반의 합성자료 생성
      fprintf(fp_log, "$%s:[CM3]", &msg_ini[1]);
      printf("$%s:[CM3]", &msg_ini[1]);
      sprintf(cmd, "rdr_cmp_comis man 3 %d %d %d %d %d", YY, MM, DD, HH, MI);
      code = system(cmd);
      fprintf(fp_log, ":%s:%d\n", cmd, code);
      printf(":%s:%d\n", cmd, code);

      fflush(fp_log);
    }

    // 6. Log File Close
    fclose(fp_log);
    sleep(30);
  }
  return 0;
}
