/*******************************************************************************
**
**  ���̴� CAPPI/PPI �ռ��ڷ� ���� ���� ���α׷�
**
**=============================================================================*
**
**   o �ۼ��� : ����ȯ (2015.7.30)
**   o ��  �� : ����ȯ (2018.4.16)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>
#include "rsl.h"
#include "nrutil.h"
#include "stn_inf.h"
#include "map_ini.h"
#include "rdr_cmp_comis_header.h"
#include "pseudo_cappi.h"   //add (RadarCener,KWG,2012.02.13)

#define  LOG_DIR        "/home/rdr/LOGD"       // �α� ���丮
#define  DST_DIR        "/rdr/BUFD/CMP_COM"    // �й� ���丮
#define  DST_OLD_DIR    "/rdr/BUFD/CMP_OLD"    // ���� �ռ��� �ӽ� ���丮
#define  FTP_CMP_DIR    "/rdr/FTPD/CMP_COM"    // �ӽ� �����
#define  RAW_UF_DIR     "/DATA/RDR/RAW"        // ����Ʈ�� ����UF �����
#define  QCD_UF_DIR     "/DATA/RDR/QCD"        // ����Ʈ�� QCD UF �����
#define  SAV_CMP_DIR    "/DATA/RDR/CMP"        // �ռ����� ���� �����
#define  STN_RDR_FILE   "/rdr/REF/STN/stn_rdr.csv"    // ���̴� ����Ʈ ��������
#define  RDR_CMP_INI    "/rdr/REF/INI/rdr_comis.ini"  // �ռ��� �������

#define  DEGRAD  3.1415927/180.0
#define  RADDEG  180.0/3.1415927

#define  BLANK1  -30000   /* No Area */
#define  BLANK2  -25000   /* No Data */
#define  BLANK3  -20000   /* Minimum Data */

//-----------------------------------------------------------------------------
// �ռ��ڷ��� ���ڿ��� (1152 km x 1440 km : 1 km ���ڰ���)
#define  NI  1152
#define  NJ  1440

//-----------------------------------------------------------------------------
// ���̴� �����ڷ� ���ڿ��� (1000.5 km x 1000.5 km : 500m ���ڰ���)
#define  NS  2000
int      MS;

//-----------------------------------------------------------------------------
// ����� �Է� ����
struct INPUT_VAR {
  int  seq_now;       // ���� �ð�
  int  seq;           // �ڷ� �Ϸýð�
  int  YY;            // ��
  int  MM;            // ��
  int  DD;            // ��
  int  HH;            // ��
  int  MI;            // ��
  int  qcd;           // QC ���ϻ�뿩�� (0:non-QC, 1:QCed)
  char fname[120];    // �ռ��� ���ϸ�
  char wname[120];    // �۾��� ���ϸ�
  char mode;          // �۾��ܰ� (n:new, m:man)
  int  rdr_stn_num;   // ó�� ����� ������
  int  num_action;    // �ռ��� ���� ������
} var;

//-----------------------------------------------------------------------------
// ó������ ���̴� ���
struct RDR_STN_LIST {
  char    stn_cd[8];      // ���� �ڵ�
  int     seq;            // �ڷ� ����
  float   lat;            // ���� ����(deg)
  float   lon;            // ���� �浵(deg)
  float   ht;             // ���׳� �ع߰���(m)
  int     org;            // �����ȣ (1:���û,2:����,3:�̰���,4:�����)
  float   seaecho;        // �Ķ����� �ִ� �Ÿ�(km)
  time_t  tm_in;          // ���� ���� �ð�
  int     mode;           // 0 -> C mode, 1 -> S mode
  int     exist;          // ���� ���� ���� (1->����)
  int     action;         // ó�� ��� ���� (1->ó��)
  char    qcd[8];         // QC�� �ڷ� ����, ����� QC����
} stn_list[29];

//-----------------------------------------------------------------------------
// ���� ������
FILE   *log_open();
FILE   *fp_log;
int    YYg, MMg, HHg, DDg, MIg, SSg;
char   msg_ini[120];

struct STN_RDR  stn_rdr;                        // ���̴� ��������
struct RDR_CMP_COMIS_HEAD  rdr_cmp_head;              // �ռ��ڷ� HEAD
struct RDR_CMP_COMIS_STN_LIST  rdr_cmp_stn_list[29];  // �ռ��� ���̴� ���

float  RE, hl;                  // �����ݰ�(m), CAPPI ����(m)
short  rdr_cmp[NJ+1][NI+1];     // �ռ��ڷ� 1km
short  rdr_stn[2][NS+2][NS+2];  // ������ 0.5km �����ڷ�

Radar  *radar;
Volume *volume;
Sweep  *sweep;
Ray    *ray;

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main(int argc, char *argv[])
{
  char  *p;
  int   YY, MM, DD, HH, MI, code;

  // 0. �μ� Ȯ��
  if (argc != 8) {
    printf("[Usage] %s {man|new} {0|1|2|3} YY MM DD HH MI\n", argv[0]);
    printf("   ���� : man(���ų� ������ ������ �߰�), new(���� ���� �ۼ�)\n");
    printf("   ���� : 0(No QC), 1(QC), 2(NQS), 3(+�������)\n");
    printf("   �ð� : KST\n");
    return 0;
  }

  // 1. ����� ��û Ȯ��
  var.mode = argv[1][0];
  var.qcd = atoi(argv[2]);
  var.YY = atoi(argv[3]);
  var.MM = atoi(argv[4]);
  var.DD = atoi(argv[5]);
  var.HH = atoi(argv[6]);
  var.MI = atoi(argv[7]);
  var.seq = time2seq(var.YY, var.MM, var.DD, var.HH, var.MI, 'm');
  var.fname[0] = '\0';

  // 2. Log File Open
  p = strrchr(argv[0],'/');
  if (p == NULL)
    fp_log = log_open(LOG_DIR, argv[0]);
  else {
    p += 1;
    fp_log = log_open(LOG_DIR, p);
  }

  get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);
  var.seq_now = time2seq(YYg, MMg, DDg, HHg, MIg, 'm');
  sprintf(msg_ini, "#%02d%02d%02d:[%04d%02d%02d%02d%02d][CM%d]",
      HHg, MIg, SSg, var.YY, var.MM, var.DD, var.HH, var.MI, var.qcd);

  // 3. �ð� ����
  code = time_error_check(var.YY, var.MM, var.DD, var.HH, var.MI);
  if (code != 0) {
    fprintf(fp_log, "$%s:time error(%d)\n", &msg_ini[1], code);
    fclose(fp_log);
    return -1;
  }

  // 5. ����
  fprintf(fp_log, "$%s:start\n", &msg_ini[1]);
  rdr_cmp_ppi();

  fclose(fp_log);
  return 0;
}

/*******************************************************************************
 *
 *  ���̴� �ռ��ڷ� ����
 *
 *******************************************************************************/
int rdr_cmp_ppi()
{
  char sname[120], cmd[256];
  int  num_stn, num_action, stn_num, ppi, mode;
  int  code, i, n;

  // 1. �ռ� ���ɿ��θ� �Ǵ��Ѵ�.
  num_action = rdr_stn_action();
  if (num_action <= 0) return 0;

  // 2. �ռ��� ���Ͽ� �ռ����� �ӽ������� �����.
  if ((code = rdr_cmp_ini()) < 0 ) {
    fprintf(fp_log, "%s:cmp_ini:error(%d)\n", msg_ini, code);
    return -3;
  }
  else
    fprintf(fp_log, "%s:cmp_ini:%s\n", msg_ini, var.wname);

  // 3. �������� �����ڷḦ ����� �ռ��Ѵ�.
  for (stn_num = 0; stn_num < var.rdr_stn_num; stn_num++) {
    if (stn_list[stn_num].action == 1) {
      // 3.1. ������ ó��
      code = rdr_cmp_stn(stn_num);

      // 3.2. �����ϸ� ��������� ���� ���
      if (code >= 0) rdr_cmp_stn_ins(stn_num);
    }
  }

  // 4. �ռ��ڷ� Smoothing
  for (ppi = 0; ppi <= 2; ppi++) {
    for (mode = 0; mode <= 1; mode++) {
      rdr_cmp_io(ppi, mode, 'r');
      rdr_cmp_sm();
      rdr_cmp_io(ppi, mode, 'w');
    }
  }
  rdr_cmp_io(1, 0, 'c');

  // 5. �ռ��� �ڷ� ����
  if (var.seq_now-var.seq < 24*60)
    sprintf(var.fname, "%s/RDR_CM%d_%04d%02d%02d%02d%02d.bin.gz",
            DST_DIR, var.qcd, var.YY, var.MM, var.DD, var.HH, var.MI);
  else
    sprintf(var.fname, "%s/RDR_CM%d_%04d%02d%02d%02d%02d.bin.gz",
            DST_OLD_DIR, var.qcd, var.YY, var.MM, var.DD, var.HH, var.MI);

  strcpy(sname, var.fname);
  strcat(sname, ".tmp");
  sprintf(cmd, "/bin/gzip -c %s > %s", var.wname, sname);
  code = system(cmd);
  fprintf(fp_log, "%s:gzip:%s:%d\n", msg_ini, sname, code);

  if (code == 0) {
    code = rename(sname, var.fname);
    fprintf(fp_log, "%s:rename:%s:%d\n", msg_ini, var.fname, code);
    if (code == 0) code = remove(var.wname);
  }
  return code;
}

/*******************************************************************************
 *
 *  ó���� ���� Ȯ��
 *
 *******************************************************************************/
int rdr_stn_action()
{
  time_t ts;
  struct tm *tp;
  int    ok_cmp = 0;
  int    num_stn = 0;     // UF�� �ִ� ������
  int    num_same = 0;    // UF�� �ִ� �����߿��� �̹� head�� �ִ� ������
  int    num_action = 0, seq1, code;
  int    i, j;

  // 1. �ش� �ð��뿡 ����Ҽ� �ִ� UF���� �������� Ȯ���Ѵ�.
  num_stn = rdr_stn_list();

  // 1.1. ���翡�� 30�� �̳��̰�, ó���� �������� 7������ ������ �� ������ �ɶ����� ��ٸ���.
  if (var.seq_now-var.seq < 30 && num_stn < 7) {
    fprintf(fp_log, "%s:small stations(%d#)\n", msg_ini, num_stn);
    return -1;
  }

  // 2. ������ �ռ��� ������ ������ �д´�. ������ ���� ����� ���� �����Ѵ�.
  if ( ok_cmp = rdr_cmp_file_read() < 0 ) var.mode = 'n';

  // 3. UF���ϰ� ����� ����� ������ ���Ͽ� �߰� �Ǵ� ����� ���θ� �����Ѵ�.
  for (j = 0; j < var.rdr_stn_num; j++) {
    // 3.1. UF������ �������� �Ǵ��ϰ�, �ִ� �������� ����Ѵ�.
    if (stn_list[j].exist == 0) {
      stn_list[j].action = 0;
      continue;
    }

    // 3.2. �ش������� ������ �ִ��� ���� Ȯ���Ѵ�.
    for (i = 0; i < rdr_cmp_head.num_stn; i++) {
      if (strcmp(stn_list[j].stn_cd, rdr_cmp_stn_list[i].stn_cd) == 0) {
        // 3.2.1. UF���ϰ� �ռ��� �ڷ��� ���Ͻð��� �ٸ� ������ ������ ������ ������Ѵ�.
        seq1 = time2seq((int)(rdr_cmp_stn_list[i].tm.YY),
                        (int)(rdr_cmp_stn_list[i].tm.MM),
                        (int)(rdr_cmp_stn_list[i].tm.DD),
                        (int)(rdr_cmp_stn_list[i].tm.HH),
                        (int)(rdr_cmp_stn_list[i].tm.MI), 'm');
        if (stn_list[j].seq != seq1) {
          var.mode = 'n';
          code = 1;
        }

        // 3.2.2. UF���� �����ð��� ����� ����� �����ð��� �ٸ��� ������ ������Ѵ�.
        else {
          time(&ts);
          tp = localtime(&ts);
          tp->tm_year = rdr_cmp_stn_list[i].tm_in.YY - 1900;
          tp->tm_mon  = rdr_cmp_stn_list[i].tm_in.MM - 1;
          tp->tm_mday = rdr_cmp_stn_list[i].tm_in.DD;
          tp->tm_hour = rdr_cmp_stn_list[i].tm_in.HH;
          tp->tm_min  = rdr_cmp_stn_list[i].tm_in.MI;
          tp->tm_sec  = rdr_cmp_stn_list[i].tm_in.SS;
          ts = mktime(tp);
          if (stn_list[j].tm_in != ts) {
            var.mode = 'n';
            code = 2;
          }

          // 3.2.3. ����� ������ UF���������� ��ġ�ϸ� �߰� �۾��������� �����Ѵ�.
          else {
            code = 0;
          }
        }
        //fprintf(fp_log, "%s:mode(%c):stn_cd(%s):code(%d):seq_file(%d):seq_head(%d):ts_file(%d):ts_head(%d)\n",
        //  msg_ini, var.mode, stn_list[j].stn_cd, code, stn_list[j].seq, seq1, stn_list[j].tm_in, ts);
        fprintf(fp_log, "%s:mode(%c):stn_cd(%s):code(%d)\n", msg_ini, var.mode, stn_list[j].stn_cd, code);

        stn_list[j].action = code;
        if (code == 0) num_same++;
        break;
      }
    }
  }

  // 4. ������� ���� UF������ �ִ� ������ �ռ������ �ȴ�.
  if (var.mode == 'n') {
    for (j = 0; j < var.rdr_stn_num; j++) {
      if (stn_list[j].exist) stn_list[j].action = 1;
    }
  }

  // 5. �߰��� ������ �ִ��� Ȯ���Ѵ�.
  for (num_action = 0, j = 0; j < var.rdr_stn_num; j++) {
    if (stn_list[j].action > 0) num_action++;
  }

  // 6. �α� ���
  fprintf(fp_log, "%s:mode(%c):stn(%d#):same(%d#):action(%d#)\n",
          msg_ini, var.mode, num_stn, num_same, num_action);
  return num_action;
}

/*=============================================================================*
 *  �� 10�а����� ���̴� �ռ���, ����� �ڷ� ���
 *=============================================================================*/
int rdr_stn_list()
{
  FILE   *fp;
  struct stat st;
  char   buf[1000], tmp[1000], fname[120];
  int    now = ((var.YY*100 + var.MM)*100 + var.DD)*100 + var.HH;
  int    fsize, tm_ed, tm_st;
  int    seq, seq1, seq2, num_stn = 0;
  int    YY, MM, DD, HH, MI;
  int    i, n, code;

  // 1. �ռ��� ���̴� �������� ���� OPEN
  if ((fp = fopen(RDR_CMP_INI, "r")) == NULL) {
    fprintf(fp_log, "%s:station infomation file not opened (%s)\n", msg_ini, RDR_CMP_INI);
    return -2;
  }

  // 2. �ռ��� ��������� Ȯ���Ѵ�.
  i = 0;
  while (fgets(buf,1000,fp) != NULL) {
    if (buf[0] == '#') continue;

    // 2.1. �ռ��� ������ ������ �д´�.
    n = 0;
    n += str_split(tmp, &buf[n], ',');  strcpy(stn_list[i].stn_cd, tmp);
    n += str_split(tmp, &buf[n], ',');
    n += str_split(tmp, &buf[n], ',');  tm_ed = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  tm_st = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  stn_list[i].mode = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  stn_list[i].org = atoi(tmp);
    n += str_split(tmp, &buf[n], ',');  strcpy(stn_list[i].qcd, tmp);
    n += str_split(tmp, &buf[n], ',');
    n += str_split(tmp, &buf[n], ',');
    n += str_split(tmp, &buf[n], ',');  stn_list[i].seaecho = atof(tmp)*1000;

    stn_list[i].seq = 0;
    stn_list[i].exist = 0;
    stn_list[i].action = 1;

    // 2.2. �ش� ������ ����� ������ ó���Ѵ�.
    if (tm_st > now || tm_ed <= now) continue;

    // var.qcd = 3 �� ��츸, �ܺα���ڷ� �ռ��� �Ѵ�.
    if (var.qcd != 3 && stn_list[i].org != 1) continue;

    i++;
  }
  fclose(fp);
  var.rdr_stn_num = i;

  // 3. �������� UF������ �ִ��� ���� Ȯ���Ͽ� ó�������� ���� ����� �����Ѵ�.
  //    ���ؽð����� ���� �����Ⱓ���� �����߿��� ���� ����� ������ ����Ѵ�.
  seq1 = (int)(var.seq/5)*5 - 6;
  for (seq2 = seq1; seq2 < seq1+10; seq2++) {
    for (i = 0; i < var.rdr_stn_num; i++) {
      // 3.1. var.qcd �� ���� ���ϸ��� ���Ѵ�.
      fsize = rdr_uf_file(seq2, var.qcd, stn_list[i].stn_cd, stn_list[i].qcd, &st, fname);

      // 3.2. ������ �ִ� ��쿡 �Ǵ��Ѵ�.
      if (fsize > 100) {
        // 3.2.1. ������ ������ ó���� ����Ѵ�.
        if (stn_list[i].exist == 0) {
          stn_list[i].seq = seq2;
          stn_list[i].tm_in = st.st_mtime;
          stn_list[i].exist = 1;
          num_stn++;
        }

        // 3.2.2. �̹� ��ϵǾ� ������, ���ؽð��� ���� ����� �ð��� �ڷḦ ����Ѵ�.
        else {
          if (abs(var.seq-stn_list[i].seq) > abs(var.seq-seq2)) {
            stn_list[i].seq = seq2;
            stn_list[i].tm_in = st.st_mtime;
            stn_list[i].exist = 1;
          }
        }
      }
    }
  }
  return num_stn;
}

/*=============================================================================*
 *  �� 10�а����� ���̴� �ռ���, ����� �ڷ� ��� (����� ���ġ ����)
 *=============================================================================*/
int rdr_stn_list_old()
{
  FILE   *fp;
  struct stat st;
  char   buf[1000], fname[120];
  int    now = ((var.YY*100 + var.MM)*100 + var.DD)*100 + var.HH;
  int    fsize;
  int    seq, seq1, seq2, num_stn = 0;
  int    YY, MM, DD, HH, MI;
  int    i, code;

  // 1. ���̴� ������� ���� OPEN
  if ((fp = fopen(STN_RDR_FILE, "r")) == NULL) {
    printf("station infomation file not opened (%s)\n", STN_RDR_FILE);
    return -2;
  }

  // 2. ������ ������ ���� ó���� ���� ����� �����Ѵ�.
  i = 0;
  while (fgets(buf,1000,fp) != NULL) {
    str2stn_rdr(buf, &stn_rdr);

    // 2.1. �ش� ������ ����� ������ ó���Ѵ�.
    if (stn_rdr.tm_st > now || stn_rdr.tm_ed <= now) continue;

    // 2.2. ���û ����Ʈ�� ó���Ѵ�.(�̰����� ���Ȳ�� �Ҿ�����찡 ���Ƽ� �����Ѵ�.)
    if (stn_rdr.stn_sp[0] != '1') continue;   // ���û�� ���
    if (stn_rdr.stn_sp[1] != 'S' && stn_rdr.stn_sp[1] != 'C') continue;
    if (strcmp(stn_rdr.stn_cd, "MET") == 0) continue;   // ���������Ʈ ����
    if (strcmp(stn_rdr.stn_cd, "YIT") == 0) continue;   // ���ν������Ʈ ����
    if (strcmp(stn_rdr.stn_cd, "IMJ") == 0) continue;   // ����������Ʈ ����

    // 2.3. �ʿ��� ���̴� ����Ʈ ������ �����Ѵ�.
    strcpy(stn_list[i].stn_cd, stn_rdr.stn_cd);
    stn_list[i].lat = stn_rdr.lat;
    stn_list[i].lon = stn_rdr.lon;
    stn_list[i].ht = stn_rdr.ht;
    stn_list[i].seaecho = atof(&(stn_rdr.stn_sp[2]))*1000;
    stn_list[i].seq = 0;
    stn_list[i].exist = 0;
    stn_list[i].action = 1;

    // 2.4. Ư���� ����� S���� ��õ������ ���� ���´�. (C���� �и�)
    if (stn_rdr.stn_sp[1] == 'S' || stn_rdr.stn_id == 47113)
      stn_list[i].mode = 1;
    else
      stn_list[i].mode = 0;
    i++;
  }
  fclose(fp);
  var.rdr_stn_num = i;

  // 3. �������� UF������ �ִ��� ���� Ȯ���Ͽ� ó�������� ���� ����� �����Ѵ�.
  //    ���ؽð����� ���� �����Ⱓ���� �����߿��� ���� ����� ������ ����Ѵ�.
  seq1 = (int)(var.seq/5)*5 - 6;
  for (seq2 = seq1; seq2 < seq1+10; seq2++) {
    for (i = 0; i < var.rdr_stn_num; i++) {
      // 3.1. var.qcd �� ���� ���ϸ��� ���Ѵ�.
      fsize = rdr_uf_file(seq2, var.qcd, stn_list[i].stn_cd, stn_list[i].qcd, &st, fname);

      // 3.2. ������ �ִ� ��쿡 �Ǵ��Ѵ�.
      if (fsize > 100) {
        // 3.2.1. ������ ������ ó���� ����Ѵ�.
        if (stn_list[i].exist == 0) {
          stn_list[i].seq = seq2;
          stn_list[i].tm_in = st.st_mtime;
          stn_list[i].exist = 1;
          num_stn++;
        }

        // 3.2.2. �̹� ��ϵǾ� ������, ���ؽð��� ���� ����� �ð��� �ڷḦ ����Ѵ�.
        else {
          if (abs(var.seq-stn_list[i].seq) > abs(var.seq-seq2)) {
            stn_list[i].seq = seq2;
            stn_list[i].tm_in = st.st_mtime;
            stn_list[i].exist = 1;
          }
        }
      }
    }
  }
  return num_stn;
}

/*=============================================================================*
 *  UF���ϸ��� ���� ���� Ȯ��
 *=============================================================================*/
int rdr_uf_file(int seq, int qcd, char *stn_cd, char *stn_qcd, struct stat *st, char *fname)
{
  //struct stat st;
  int    YY, MM, DD, HH, MI;
  int    size;
  int    code;

  // 1. �ð�Ȯ��
  seq2time(seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

  // 2. ���ϸ�
  if (qcd == 0)
    sprintf(fname, "%s/%04d%02d/%02d/RDR_%s_%04d%02d%02d%02d%02d.uf",
            RAW_UF_DIR, YY, MM, DD, stn_cd, YY, MM, DD, HH, MI);
  else if (qcd == 1 || qcd == 3) {
    if (strcmp(stn_qcd,"FQC") == 0)
      sprintf(fname, "%s/%04d%02d/%02d/RDR_%s_FQC_%04d%02d%02d%02d%02d.uf",
              QCD_UF_DIR, YY, MM, DD, stn_cd, YY, MM, DD, HH, MI);
    else if (strcmp(stn_qcd,"RAW") == 0)
      sprintf(fname, "%s/%04d%02d/%02d/RDR_%s_%04d%02d%02d%02d%02d.uf",
              RAW_UF_DIR, YY, MM, DD, stn_cd, YY, MM, DD, HH, MI);
    else
      sprintf(fname, "%s/%04d%02d/%02d/RDR_%s_QCD_%04d%02d%02d%02d%02d.uf",
              QCD_UF_DIR, YY, MM, DD, stn_cd, YY, MM, DD, HH, MI);
  }
  else if (qcd == 2)
    sprintf(fname, "%s/%04d%02d/%02d/RDR_%s_NQS_%04d%02d%02d%02d%02d.uf",
            RAW_UF_DIR, YY, MM, DD, stn_cd, YY, MM, DD, HH, MI);
  // ������ �����ϰ� �ܺα���ռ������� ��ȯ
  //else if (qcd == 3)
  //  sprintf(fname, "%s/%04d%02d/%02d/RDR_%s_FQC_%04d%02d%02d%02d%02d.uf",
  //          QCD_UF_DIR, YY, MM, DD, stn_cd, YY, MM, DD, HH, MI);

  // 3. ���翩�� Ȯ��
  code = stat(fname, st);
  if (code < 0 || (*st).st_size <= 0)
    size = -1;
  else
    size = (*st).st_size;
  return size;
}

/*=============================================================================*
 *  ���̴� �ռ��ڷ� ���� ���� Ȯ��
 *=============================================================================*/
int rdr_cmp_file_read()
{
  FILE   *fp;
  struct stat st;
  int    n, code;

  // 1. ���ϸ� �� ���翩�� Ȯ��
//  sprintf(var.fname, "%s/%04d%02d/%02d/RDR_CM%d_%04d%02d%02d%02d%02d.bin.gz",
//      SAV_CMP_DIR, var.YY, var.MM, var.DD, var.qcd, var.YY, var.MM, var.DD, var.HH, var.MI);
  sprintf(var.fname, "%s/RDR_CM%d_%04d%02d%02d%02d%02d.bin.gz",
      FTP_CMP_DIR, var.qcd, var.YY, var.MM, var.DD, var.HH, var.MI);
  code = stat(var.fname, &st);
  if (code < 0 || st.st_size <= 0) return -1;

  // 2. ������ ���, �����ڷḦ ����
  fp = gzopen(var.fname,"rb");
  if (fp == NULL) return -2;

  n = gzread(fp, &rdr_cmp_head, 24);
  n = gzread(fp, rdr_cmp_stn_list, 24*29);

  gzclose(fp);
  return 0;
}

/*******************************************************************************
 *
 *  �ռ��� ���̴��ڷ� �ʱ�ȭ
 *
 *******************************************************************************/
int rdr_cmp_ini()
{
  FILE  *fp;
  char  cmd[256];
  int   code = -1;
  int   i, j, k, n;

  // 1. �ӽ� ���ϸ�
  if (var.seq_now - var.seq < 24*60*30)
    sprintf(var.wname, "%s/RDR_CM%d_%04d%02d%02d%02d%02d.bin.tmp",
            DST_DIR, var.qcd, var.YY, var.MM, var.DD, var.HH, var.MI);
  else
    sprintf(var.wname, "%s/RDR_CM%d_%04d%02d%02d%02d%02d.bin.tmp",
            DST_OLD_DIR, var.qcd, var.YY, var.MM, var.DD, var.HH, var.MI);

  // 2. ���� �ռ��忡 �߰��ϴ� ���
  if (var.mode == 'm') {
    sprintf(cmd, "/bin/gunzip -c %s > %s", var.fname, var.wname);
    code = system(cmd);
  }

  // 3. ���� ����� ���
  else if (var.mode == 'n') {
    fp = fopen(var.wname, "wb");
    if (fp != NULL) {
      // 3.1. ������� �ʱ�ȭ
      rdr_cmp_head.kind = 10;
      rdr_cmp_head.YY = var.YY;
      rdr_cmp_head.MM = var.MM;
      rdr_cmp_head.DD = var.DD;
      rdr_cmp_head.HH = var.HH;
      rdr_cmp_head.MI = var.MI;
      rdr_cmp_head.num_stn = 0;
      strcpy(rdr_cmp_head.rem, "    ");

      // 3.2. ������� ���
      n = fwrite(&rdr_cmp_head, 24, 1, fp);
      n = fwrite(rdr_cmp_stn_list, 24*29, 1, fp);

      // 3.3. �������� �ƴ����� �ڷ� �ʱ�ȭ
      for (j = 0; j <= NJ; j++) {
        for (i = 0; i <= NI; i++)
          rdr_cmp[j][i] = BLANK1;
      }

      // 3.4. �ʱ�ȭ�� �����ڷ�� ���
      for (k = 0; k < 6; k++) {
        n = fwrite(rdr_cmp, 2, (NJ+1)*(NI+1), fp);
      }
      fclose(fp);
      code = 0;
    }
  }
  return code;
}

/*******************************************************************************
 *
 *  1�� ������ ���̴� �����ڷ� ����
 *
 *******************************************************************************/
int rdr_cmp_stn(int stn_num)
{
  char   fname[120];
  struct stat st;
  float  elev[2], rl[2];
  int    YY, MM, DD, HH, MI;
  int    ppi, code, nsweep = 0;
  int    i, j, k;

  // 1. UF ���� �б�
  code = rdr_uf_file(stn_list[stn_num].seq, var.qcd, stn_list[stn_num].stn_cd, stn_list[stn_num].qcd, &st, fname);
  fprintf(fp_log, "%s:%s:", msg_ini, fname);
  if ((radar = RSL_uf_to_radar(fname)) == NULL) {
    fprintf(fp_log, "open error\n");
    return -1;
  }

  if (strstr(stn_list[stn_num].stn_cd,"RKJK") || strstr(stn_list[stn_num].stn_cd,"RKSG"))
    volume = radar->v[DZ_INDEX];
  else
    volume = radar->v[CZ_INDEX];
  if (volume == NULL) {
    fprintf(fp_log, "volume error\n");
    return -2;
  }

  // 2. ������ �����ڷ� �ʱ�ȭ
  stn_list[stn_num].lon = radar->h.lond + (radar->h.lonm + (radar->h.lons)/60.0)/60.0;
  stn_list[stn_num].lat = radar->h.latd + (radar->h.latm + (radar->h.lats)/60.0)/60.0;
  stn_list[stn_num].ht  = radar->h.height;

  RE = 6371008.77 + stn_list[stn_num].ht; // unit : m
  hl = 1500 - stn_list[stn_num].ht;       // unit : m

  for (j = 0; j <= NS+1; j++) {
    for (i = 0; i <= NS+1; i++) {
      rdr_stn[0][j][i]  = BLANK1;
      rdr_stn[1][j][i]  = BLANK1;
    }
  }

  // 3. ������ 0.5km �����ڷ� ����
  for (nsweep = 0, k = 0; k < volume->h.nsweeps; k++) {
    if ((sweep = volume->sweep[k]) != NULL) {
      elev[1] = sweep->h.elev;
      rl[1] = sqrt(RE*RE*sin(elev[1]*DEGRAD)*sin(elev[1]*DEGRAD) + hl*hl + 2.0*hl*RE) - RE*sin(elev[1]*DEGRAD);

      for (j = 0; j < sweep->h.nrays; j++) {
        if ((ray = sweep->ray[j]) != NULL) {
          //printf("j = %d\n", j);
          rdr_stn_ray2grd(stn_list[stn_num].stn_cd, stn_list[stn_num].ht, stn_list[stn_num].seaecho, nsweep, rl, elev);
        }
      }
      nsweep++;

      //  PPI0 �켱 ó��
      if (nsweep == 1) {
        rdr_stn_grd_sm(0);
        rdr_stn_grd_down(0);

        rdr_cmp_io(2, stn_list[stn_num].mode, 'r');
        rdr_cmp_grd(stn_num, 0);
        rdr_cmp_io(2, stn_list[stn_num].mode, 'w');

        for (j = 0; j <= NS+1; j++) {
          for (i = 0; i <= NS+1; i++) {
            rdr_stn[0][j][i] = rdr_stn[1][j][i];
          }
        }
      }

      rl[0] = rl[1];
      elev[0] = elev[1];
    }
  }

  // Pseudo_cappi (RadarCener,KWG,2012.02.13)
  for (j = 0; j <= NS+1; j++) {
    for (i = 0; i <= NS+1; i++) {
      rdr_stn[1][j][i]  = BLANK1;
    }
  }

  int lng = (volume->sweep[0]->ray[0]->h.nbins)*(volume->sweep[0]->ray[0]->h.gate_size) + volume->sweep[0]->ray[0]->h.range_bin1;
  pseudo_cappi(volume, hl, NS, NS, lng/1000, 500);
  //Pseudo_cappi:end

  RSL_free_radar(radar);

  //  0.5km grid data smoothing  &  downsizing for 1km
  rdr_stn_grd_sm(1);
  rdr_stn_grd_down(1);

  // ������ �����ڷ� -> �ռ��ڷ� (CMAX, CAPPI)
  rdr_cmp_io(1, stn_list[stn_num].mode, 'r');
  rdr_cmp_grd(stn_num, 0);
  rdr_cmp_io(1, stn_list[stn_num].mode, 'w');

  rdr_cmp_io(0, stn_list[stn_num].mode, 'r');
  rdr_cmp_grd(stn_num, 1);
  rdr_cmp_io(0, stn_list[stn_num].mode, 'w');

  fprintf(fp_log, "sweep(%d#)\n", nsweep);
  fflush(fp_log);
  return 0;
}

/*=============================================================================*
 *  1 Ray -> Griding
 *=============================================================================*/
int rdr_stn_ray2grd(stn_cd, rdr_ht, seaecho, nsweep, rl, elev)
  char  stn_cd[8];
  float rl[2], elev[2], rdr_ht, seaecho;
  int   nsweep;
{
  double tn1, tn2;
  float  angle[3], hs[2];
  float  range, cc, cr, cg, cs, s0, s1, s, r, ec1;
  short  ec, blank2s = BLANK2;
  int    MS1, area, ix, iy;
  int    i, j, k, i1, i2;

  // 1. �̰����ڷ�� �ڷᰡ ������ �̰����������� ó��
  if (strcmp(stn_cd,"RKSG") == 0 || strcmp(stn_cd,"RKJK") == 0)
    blank2s = BLANK1;
  else
    blank2s = BLANK2;

  // 2. ���� �� ��������
  angle[1] = ray->h.azimuth;
  if (strcmp(stn_cd,"IIA") == 0) angle[1] -= 7.53;   // �������� �ںϱ���
  if (angle[1] < 0.0) angle[1] += 360.0;

  area = ((int)angle[1]/45) % 8 + 1;

  if (angle[1] > 45.0) {
    angle[1] -= 45.0;
    angle[1] = fabs( angle[1] - ((int)angle[1]/90)*90 - 45.0 );
  }

  if (ray->h.beam_width == 0) ray->h.beam_width = 1.0;
  angle[0] = angle[1] - ray->h.beam_width - 0.1;
  angle[2] = angle[1] + ray->h.beam_width + 0.1;

  tn1 = tan(angle[0] * DEGRAD);
  tn2 = tan(angle[2] * DEGRAD);

  // 3. ���� �� ��ó��
  cc = 500;         // 500 m ���� ����
  range = (ray->h.nbins)*(ray->h.gate_size) + ray->h.range_bin1;
  MS1 = (int)(range/cc);
  if (MS1 > 1000) MS1 = 1000;
  if (MS < MS1) MS = MS1;

  cr = ray->h.range_bin1;
  cg = ray->h.gate_size;
  cs = cos(elev[1] * DEGRAD);

  // 4. ���
  for (j = 1; j <= MS1; j++) {
    i1 = (int)(tn1 * j + 0.95);
    i2 = (int)(tn2 * j - 0.05);

    if (i2 >= i1) {
      for (i = i1; i <= i2; i++) {
        s = cc * (sqrt(i*i + j*j) - 0.5);   // ������ �Ÿ�
        r = s / cs;                         // ����Ÿ�
        k = (int)((r - cr)/cg);             // ������ ���ڼ�

        if (k >= 0 && k < ray->h.nbins) {
          switch (area) {
            case 1:  iy = 1000 + j;  ix = 1000 + i;  break;
            case 2:  iy = 1000 + i;  ix = 1000 + j;  break;
            case 3:  iy = 1000 - i;  ix = 1000 + j;  break;
            case 4:  iy = 1000 - j;  ix = 1000 + i;  break;
            case 5:  iy = 1000 - j;  ix = 1000 - i;  break;
            case 6:  iy = 1000 - i;  ix = 1000 - j;  break;
            case 7:  iy = 1000 + i;  ix = 1000 - j;  break;
            case 8:  iy = 1000 + j;  ix = 1000 - i;
          }
          ec1 = ray->h.f(ray->range[k]);
          if (ec1 > 200.0 || ec1 < -100)
            ec = blank2s;
          else
            ec = (short)(ec1*100);

          if (nsweep == 0) {
            if (rdr_stn[0][iy][ix] < ec) {
              rdr_stn[0][iy][ix] = ec;
              rdr_stn[1][iy][ix] = ec;
            }
          }
          else if (nsweep > 0) {
            // CMAX
            if (ec > BLANK3 && rdr_stn[0][iy][ix] < ec) rdr_stn[0][iy][ix] = ec;
 
            // CAPPI
            /*
            if (nsweep == 1 && r < seaecho && ec < 700) rdr_stn[1][iy][ix] = ec;
            s0 = 2.0 * RE * sin(elev[0] * DEGRAD);
            s1 = 2.0 * RE * sin(elev[1] * DEGRAD);

            if (r < rl[1])
              rdr_stn[1][iy][ix] = ec;
            else if (r < rl[0])
            {
              if (ec > BLANK3)
              {
                if (rdr_stn[1][iy][ix] > BLANK3)
                {
                  hs[0] = sqrt(r*r + RE*RE + r*s0) - RE;
                  hs[1] = sqrt(r*r + RE*RE + r*s1) - RE;

                  rdr_stn[1][iy][ix] += (ec - rdr_stn[1][iy][ix])/(hs[1] - hs[0])*(hl - hs[0]);
                }
                else
                  rdr_stn[1][iy][ix] = ec;
              }
            }
            */
          }
        }
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  Grid data Smoothing (by 1-2-1 Smoothing)
 *=============================================================================*/
int rdr_stn_grd_sm(int m)
{
  float  e[4], e1, e2;
  int  s1, s2;
  int  i, j, k;

  s1 = 1000 - MS;
  s2 = 1000 + MS;

  for (k = 0; k <= m; k++) {
    for (j = s1; j < s2; j++) {
      e1 = rdr_stn[k][j][s1];
      e[0] = rdr_stn[k][j][s1];
      e[1] = rdr_stn[k][j][s1+1];

      for (i = s1+1; i < s2; i++) {
        e[2] = rdr_stn[k][j][i+1];
        if (e[0] > BLANK3 && e[1] > BLANK3 && e[2] > BLANK3)
          e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
        else if (e[0] > BLANK3 && e[1] <= BLANK3 && e[2] > BLANK3)
          e2 = (e[0] + e[2]) * 0.5;
        else
          e2 = e[1];

        rdr_stn[k][j][i-1] = (short)e1;
        e1 = e2;
        e[0] = e[1];
        e[1] = e[2];
      }
      rdr_stn[k][j][i-1] = (short)e1;
    }

    for (i = s1; i < s2; i++) {
      e1 = rdr_stn[k][s1][i];
      e[0] = rdr_stn[k][s1][i];
      e[1] = rdr_stn[k][s1+1][i];

      for (j = s1+1; j < s2; j++) {
        e[2] = rdr_stn[k][j+1][i];
        if (e[0] > BLANK3 && e[1] > BLANK3 && e[2] > BLANK3)
          e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
        else if (e[0] > BLANK3 && e[1] <= BLANK3 && e[2] > BLANK3)
          e2 = (e[0] + e[2]) * 0.5;
        else
          e2 = e[1];

        rdr_stn[k][j-1][i] = (short)e1;
        e1 = e2;
        e[0] = e[1];
        e[1] = e[2];
      }
      rdr_stn[k][j-1][i] = (short)e1;
    }
  }
  return 0;
}

/*=============================================================================*
 *  ������ �����ڷ� �ػ� ���� (500 m -> 1 km)
 *=============================================================================*/
int rdr_stn_grd_down(int m)
{
  short  e1;
  int  i, j, i1, j1, k;

  for (k = 0; k <= m; k++) {
    for (j = 0; j <= NS; j += 2) {
      j1 = j + 1;

      for (i = 0; i <= NS; i += 2) {
        i1 = i + 1;

        e1 = rdr_stn[k][j][i];
        if (e1 < rdr_stn[k][j][i1] ) e1 = rdr_stn[k][j][i1];
        if (e1 < rdr_stn[k][j1][i] ) e1 = rdr_stn[k][j1][i];
        if (e1 < rdr_stn[k][j1][i1]) e1 = rdr_stn[k][j1][i1];

        rdr_stn[k][j][i] = e1;
        rdr_stn[k][j][i1] = e1;
        rdr_stn[k][j1][i] = e1;
        rdr_stn[k][j1][i1] = e1;
      }
    }
  }
  return 0;
}

/*******************************************************************************
 *
 *  Radar data sum
 *
 *******************************************************************************/
int rdr_cmp_grd(int stn_num, int m)
{
  float  cx[4], cy[4];
  float  xl, yl;
  short  e1;
  int    x_min, x_max, y_min, y_max;
  int    i, j, ia, ja;

  conv_cof(stn_num, cx, cy, &x_min, &x_max, &y_min, &y_max);

  for (j = y_min; j <= y_max; j++) {
    yl = j + 0.5;

    for (i = x_min; i <= x_max; i++) {
      xl = i + 0.5;
      ia = (int)(cx[0] + cx[1]*xl + cx[2]*yl + cx[3]*xl*yl);
      ja = (int)(cy[0] + cy[1]*xl + cy[2]*yl + cy[3]*xl*yl);

      if (ia >= 0 && ia <= NS && ja >= 0 && ja <= NS) {
        e1 = rdr_stn[m][ja][ia];
        if (e1 > rdr_cmp[j][i]) rdr_cmp[j][i] = e1;
      }
    }
  }
  return 0;
}

/*=============================================================================*
 *  ��ǥ��ȯ ��� ���
 *=============================================================================*/
int conv_cof(stn_num, cx, cy, x_min, x_max, y_min, y_max)
  int    stn_num;
  float  cx[4], cy[4];
  int    *x_min, *x_max, *y_min, *y_max;
{
  struct lamc_parameter  map;
  struct azed_parameter  rdr;
  float  xl[4], yl[4], xa[4], ya[4];
  float  lon, lat;
  float  t1, t2;
  int  i, j;

  /* OUT Map parameter */
  map.Re  = 6371.00877;
  map.grid  = 1.0;
  map.slat1 = 30.0;
  map.slat2 = 60.0;
  map.olon  = 126.0;
  map.olat  = 38.0;
  map.xo  = 4.0 * 140.0 / map.grid;
  map.yo  = 4.0 * 210.0 / map.grid;
  map.first = 0;

  /* IN map parameter */
  rdr.Re  = 6371.00877 + stn_list[stn_num].ht * 0.001;
  rdr.grid  = 0.5;
  rdr.slon  = stn_list[stn_num].lon;
  rdr.slat  = stn_list[stn_num].lat;
  rdr.olon  = stn_list[stn_num].lon;
  rdr.olat  = stn_list[stn_num].lat;
  rdr.xo  = 1000.5;
  rdr.yo  = 1000.5;
  rdr.first = 0;

  /* IN map �������� �ױ����� ��ǥ */
  xa[0] = 0.0;
  ya[0] = 0.0;
  xa[1] = rdr.xo * 2.0;
  ya[1] = 0.0;
  xa[2] = rdr.xo * 2.0;
  ya[2] = rdr.yo * 2.0;
  xa[3] = 0.0;
  ya[3] = rdr.yo * 2.0;

  /* OUT map���� �ش�Ǵ� ��ǥ */
  for (i = 0; i < 4; i++) {
    azedproj(&lon, &lat, &xa[i], &ya[i], 1, &rdr);
    lamcproj_ellp(&lon, &lat, &xl[i], &yl[i], 0, &map);
  }

  /* OUT map������ ���� */
  *x_min = 99999;
  *x_max = -99999;
  *y_min = 99999;
  *y_max = -99999;

  for (i = 0; i < 4; i++) {
    if (*x_min > (int)xl[i]) *x_min = (int)xl[i];
    if (*x_max < (int)xl[i]) *x_max = (int)xl[i];
    if (*y_min > (int)yl[i]) *y_min = (int)yl[i];
    if (*y_max < (int)yl[i]) *y_max = (int)yl[i];
  }
  if (*x_min <  0) *x_min = 0;
  if (*x_max > NS) *x_max = NS;
  if (*y_min <  0) *y_min = 0;
  if (*y_max > NS) *y_max = NS;

  /* OUT map���� IN map���� ��ȯ��� ��� */
  matrix_cal(xa, xl, yl, cx);
  matrix_cal(ya, xl, yl, cy);

  return 0;
}

/*=============================================================================*
 *  ��� ���
 *=============================================================================*/
int matrix_cal(a, xl, yl, c)
  float a[4], xl[4], yl[4], c[4];
{
  float  mm[4][4], d;
  int  indx[4];
  int  i, j;

  for (j = 0; j < 4; j++) {
    mm[j][0] = 1.0;
    mm[j][1] = xl[j];
    mm[j][2] = yl[j];
    mm[j][3] = xl[j] * yl[j];
    c[j] = a[j];
  }

  ludcmp(mm,4,indx,&d);
  lubksb(mm,4,indx,c);

  return 0;
}

/*=============================================================================*
 *  < LU decomposition >            from  Numerical Recips
 *=============================================================================*/
int   lubksb(a,n,indx,b)
float a[4][4],b[4];
int   n,*indx;
{
  int  i,ii=-1,ip,j;
  float  sum;

  for (i=0;i<n;i++) {
    ip=indx[i];
    sum=b[ip];
    b[ip]=b[i];
    if (ii >= 0)
      for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
    else if (sum) ii=i;
    b[i]=sum;
  }
  for (i=n-1;i>=0;i--) {
    sum=b[i];
    for (j=i+1;j<n;j++) sum -= a[i][j]*b[j];
    b[i]=sum/a[i][i];
  }
  return 0;
}

/*=============================================================================*
 *  < LU decomposition >            from  Numerical Recips
 *=============================================================================*/
#define TINY 1.0e-20;

int   ludcmp(a,n,indx,d)
float a[4][4];
int   n,*indx;
float *d;
{
  int  i,imax,j,k;
  float  big,dum,sum,temp;
  float  vv[8];

  *d=1.0;
  for (i=0;i<n;i++) {
    big=0.0;
    for (j=0;j<n;j++) {
      if ((temp=fabs(a[i][j])) > big) big=temp;
    }
    if (big == 0.0) printf("Singular matrix in routine LUDCMP\n");
    vv[i]=1.0/big;
  }
  for (j=0;j<n;j++) {
    for (i=0;i<j;i++) {
      sum=a[i][j];
      for (k=0;k<i;k++) sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
    }
    big=0.0;
    for (i=j;i<n;i++) {
      sum=a[i][j];
      for (k=0;k<j;k++)
        sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
      if ( (dum=vv[i]*fabs(sum)) >= big) {
        big=dum;
        imax=i;
      }
    }
    if (j != imax) {
      for (k=0;k<n;k++) {
        dum=a[imax][k];
        a[imax][k]=a[j][k];
        a[j][k]=dum;
      }
      *d = -(*d);
      vv[imax]=vv[j];
    }
    indx[j]=imax;
    if (a[j][j] == 0.0) a[j][j]=TINY;
    if (j != n-1) {
      dum=1.0/(a[j][j]);
      for (i=j+1;i<n;i++) a[i][j] *= dum;
    }
  }
  return 0;
}

/*=============================================================================*
 *  �ռ��� ���̴� ���� ��� �߰�
 *=============================================================================*/
int rdr_cmp_stn_ins(int stn_num)
{
  struct tm *tp;
  int  YY, MM, DD, HH, MI;
  int  i, j;

  rdr_cmp_head.num_stn++;

  j = rdr_cmp_head.num_stn - 1;
  strcpy(rdr_cmp_stn_list[j].stn_cd, stn_list[stn_num].stn_cd);
  seq2time(stn_list[stn_num].seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  rdr_cmp_stn_list[j].tm.YY = (short)YY;
  rdr_cmp_stn_list[j].tm.MM = (char)MM;
  rdr_cmp_stn_list[j].tm.DD = (char)DD;
  rdr_cmp_stn_list[j].tm.HH = (char)HH;
  rdr_cmp_stn_list[j].tm.MI = (char)MI;
  rdr_cmp_stn_list[j].num1 = 0;

  tp = localtime(&(stn_list[stn_num].tm_in));
  rdr_cmp_stn_list[j].tm_in.YY = tp->tm_year + 1900;
  rdr_cmp_stn_list[j].tm_in.MM = tp->tm_mon + 1;
  rdr_cmp_stn_list[j].tm_in.DD = tp->tm_mday;
  rdr_cmp_stn_list[j].tm_in.HH = tp->tm_hour;
  rdr_cmp_stn_list[j].tm_in.MI = tp->tm_min;
  rdr_cmp_stn_list[j].tm_in.SS = tp->tm_sec;
  rdr_cmp_stn_list[j].num2 = 0;

  return 0;
}

/*******************************************************************************
 *
 *  �ռ��� ���̴��ڷ� Smoothing
 *
 *******************************************************************************/
int rdr_cmp_sm()
{
  short  *p, d1, d2, p1, p2, p3;
  int  i, j;

  for (j = 0; j <= NJ; j++) {
    d1 = rdr_cmp[j][0];
    p = &(rdr_cmp[j][1]);

    for (i = 1; i < NI; i++, p++) {
      if (*(p-1) > BLANK3 && *p > BLANK3 && *(p+1) > BLANK3)
        d2 = (short)((float)(*(p-1) + *p*2 + *(p+1))*0.25);
      else if (*(p-1) > BLANK3 && *p <= BLANK3 && *(p+1) > BLANK3)
        d2 = (short)((float)(*(p-1) + *(p+1)) * 0.5);
      else
        d2 = *p;

      *(p-1) = d1;
      d1 = d2;
    }
  }

  for (i = 0; i <= NI; i++) {
    d1 = rdr_cmp[0][i];
    p1 = d1;
    p2 = rdr_cmp[1][i];

    for (j = 1; j < NJ; j++) {
      p3 = rdr_cmp[j+1][i];
      if (p1 > BLANK3 && p2 > BLANK3 && p3 > BLANK3)
        d2 = (short)((float)(p1 + 2*p2 + p3)*0.25);
      else if (p1 > BLANK3 && p2 <= BLANK3 && p3 > BLANK3)
        d2 = (short)((float)(p1 + p2) * 0.5);
      else
        d2 = p2;

      rdr_cmp[j-1][i] = d1;
      d1 = d2;
      p1 = p2;
      p2 = p3;
    }
  }
  return 0;
}

/*******************************************************************************
 *
 *  �ռ��ڷ� Read/Write
 *
 *******************************************************************************/
int rdr_cmp_io(ppi, mode, rw)
  int  ppi, mode;
  char rw;
{
  static FILE *fd;
  static int  first = 0;
  long   offset;
  int  YY, MM, DD, HH, MI, SS;
  int  n, code;

  if (first == 0) {
    fd = fopen(var.wname, "r+");
    if (fd == NULL) return -1;
    first = 1;
  }

  if (rw == 'c') {
    get_time(&YY, &MM, &DD, &HH, &MI, &SS);
    rdr_cmp_head.tm_in.YY = (short)YY;
    rdr_cmp_head.tm_in.MM = (char)MM;
    rdr_cmp_head.tm_in.DD = (char)DD;
    rdr_cmp_head.tm_in.HH = (char)HH;
    rdr_cmp_head.tm_in.MI = (char)MI;

    fseek(fd, 0L, SEEK_SET);
    n = fwrite(&rdr_cmp_head, 24, 1, fd);
    n = fwrite(rdr_cmp_stn_list, 24, 29, fd);
    fclose(fd);

    first = 0;
    return 1;
  }

  offset = 24*30 + 2*ppi*(NJ+1)*(NI+1)*2;
  if (mode) offset += (NJ+1)*(NI+1)*2;
  fseek(fd, offset, SEEK_SET);

  if (rw == 'r')
    n = fread(rdr_cmp, 2, (NJ+1)*(NI+1), fd);
  else if (rw == 'w')
    n = fwrite(rdr_cmp, 2, (NJ+1)*(NI+1), fd);
  return n;
}


//======== add (RadarCener,KWG,2012.02.13) =============================
int pseudo_cappi(Volume* volume,float height,int xdim, int ydim, int range, float grid_size)
{
  int x, y; // The number of CAPPI grid point
  int s,r,b;
  float center_x,center_y;
  center_x = (xdim-1)/2.;
  center_y = (ydim-1)/2.;

  float point_x,point_y;//,point_z;

//printf("read->range=%dkm ,height =%7.1fm \n",range,1500-height);
  float el_limit= 2.0;
  float az_limit= 1.0;

  float elevation;
  float azimuth;
  float echo;
  float slant_range;
  double sum_Z;

  int bin_count;
  int range_out;

  CLOEST_SWEEPS cloest_sweeps;


  //�ʱ�ȭ
  for (s = 0 ; s < 2 ; s++ ) {
    cloest_sweeps.valid[s] = 0;
    cloest_sweeps.s[s] = NULL;
    for (r = 0 ; r < 2 ; r++ ) {
      cloest_sweeps.rays[s].valid[r] = 0;
      cloest_sweeps.rays[s].r[r] = NULL;
      for (b = 0 ; b < 2 ; b++ ) {
        cloest_sweeps.rays[s].values[r].valid[b] = 0;
        cloest_sweeps.rays[s].values[r].dBZ[b] = -127;
      }
    }
  }

  for (y = 0 ; y < ydim ; y++ ) {
    for (x = 0 ; x < xdim ; x++ ) {
      bin_count = 0;
      sum_Z = 0;

      point_x = x - center_x;
      point_y = y - center_y;
      slant_range = get_slant_range(point_x,point_y,height,grid_size);
      //printf("slant_range =%f \n",slant_range);
      elevation = get_elevation(point_x,point_y,height,grid_size);
      azimuth = get_azimuth(point_x,point_y);
      //����� SWEEP 2�� ã��
      cloest_sweeps = get_cloest_2_sweeps(volume, elevation, el_limit);
      //printf("--------(%d,%d)\n",y,x);
      for (s = 0 ; s < 2 ; s++ ) {
        cloest_sweeps.rays[s] = get_cloest_2_rays(cloest_sweeps.s[s],azimuth,az_limit);
        for (r = 0 ; r < 2 ; r++ ) {
          cloest_sweeps.rays[s].values[r] = get_cloest_2_bins(cloest_sweeps.rays[s].r[r],slant_range);
        }
      }
      echo = cal_mohr_cappi_value_f2(volume,cloest_sweeps,azimuth,elevation,slant_range,0,1);

      //BLANK1=No Area, BLANK2=No Data, BLANK3=Minimum Data
      range_out = (int)(sqrt((center_x-x)*(center_x-x)+(center_y-y)*(center_y-y)));
      range_out =range_out*grid_size/1000;

      if (echo > 200.0 || echo < -100) 
        echo = BLANK2;
      else
        echo = (short)(echo*100);

      if (range_out > range) echo = BLANK1;

      rdr_stn[1][ydim-y-1][x] = echo;
      //printf("====== %f \n",rdr_stn[1][y][x]);
    }
  }
return 0;
}

//=======================================================================
float get_slant_range(float x, float y, float height,float grid_size)
{
  float range_x, range_y, range_z;

  range_x = x * grid_size;
  range_y = y * grid_size;
  range_z = height;  // * grid_size;

  return sqrt(pow(range_x,2)+pow(range_y,2)+pow(range_z,2));
}

//=======================================================================
float get_elevation(float x,float y,float h,float grid_size)
{
  double Ae, r;
  float result;

  r = get_slant_range(x,y,h,grid_size);
  Ae = (MAP_RE * 1000.)*4./3.;

  //Doviak and Zrnic, 1993
  result = RADDEG * asin((h*h - r*r + 2*Ae*h) / (2*r*Ae));

  return result;
}

//=======================================================================
float get_azimuth(float x,float y)
{
  float azimuth;

  if (x < 0.0)
    azimuth = (atan(y/x) * RADDEG) + 270.0;
  else if (x > 0.0)
    azimuth = (atan(y/x) * RADDEG) + 90.0;
  else if ((x == 0.0) && (y <= 0.0))
    azimuth = 0.0;
  else
    azimuth = 180.0;
  return azimuth;
}

//=======================================================================
static CLOEST_SWEEPS get_cloest_2_sweeps(Volume* volume,float elevation,float limit)
{
  CLOEST_SWEEPS cloest_sweeps;
  int sweep_index1,sweep_index2;

  cloest_sweeps.s[0] = NULL;
  cloest_sweeps.valid[0] = 0;
  cloest_sweeps.s[1] = NULL;
  cloest_sweeps.valid[1] = 0;

  if (volume == NULL)
    return cloest_sweeps;
  
  if (get_closest_sweep_2_index(volume,elevation,&sweep_index1,&sweep_index2) < 0) {
    cloest_sweeps.valid[0] = 0;
    cloest_sweeps.valid[1] = 0;
    return cloest_sweeps;
  }

  if ((sweep_index1 >= 0) && diff_degree(elevation,volume->sweep[sweep_index1]->h.elev) <= limit) {
    cloest_sweeps.s[0] = volume->sweep[sweep_index1];
    cloest_sweeps.valid[0] = 1;
    cloest_sweeps.phi[0] = volume->sweep[sweep_index1]->h.elev;
  }
  else {
    cloest_sweeps.s[0] = NULL;
    cloest_sweeps.valid[0] = 0;
  }

  if ((sweep_index2 >= 0) && diff_degree(elevation,volume->sweep[sweep_index2]->h.elev) <= limit) {
    cloest_sweeps.s[1] = volume->sweep[sweep_index2];
    cloest_sweeps.valid[1] = 1;
    cloest_sweeps.phi[1] = volume->sweep[sweep_index2]->h.elev;
  }
  else {
    cloest_sweeps.s[1] = NULL;
    cloest_sweeps.valid[1] = 0;
  }
  return cloest_sweeps;
}

//=======================================================================
static CLOEST_RAYS get_cloest_2_rays(Sweep* s,float azimuth,float limit)
{
  CLOEST_RAYS cloest_rays;
  Ray* ray;
  Ray* cw_ray;
  Ray* ccw_ray;
  Ray* ray_temp1 = NULL;
  Ray* ray_temp2 = NULL;

  //�ʱ�ȭ
  cloest_rays.valid[0] = 0;
  cloest_rays.valid[1] = 0;
  cloest_rays.r[0] = NULL;
  cloest_rays.r[1] = NULL;

  if (s == NULL)
    return cloest_rays;
  //���� ����� ray������.
  if ((ray = RSL_get_closest_ray_from_sweep(s,azimuth,limit)) == NULL)
    return cloest_rays;

  ray_temp1 = ray;

  cw_ray = RSL_get_next_cwise_ray(s,ray); 
  ccw_ray = RSL_get_next_ccwise_ray(s,ray);
  //CW_RAY�� ������ �ƴϰ� limit�� ���� ������ &&  CW_RAY�� ������ �ƴϰ� limit�� ���� ������
  if ((cw_ray  != NULL) && (diff_degree(cw_ray->h.azimuth,azimuth) <= limit) &&
      (ccw_ray != NULL) && (diff_degree(ccw_ray->h.azimuth,azimuth) <= limit)) {
    if (diff_degree(cw_ray->h.azimuth,azimuth) > diff_degree(ccw_ray->h.azimuth,azimuth))
      ray_temp2 = ccw_ray;
    else
      ray_temp2 = cw_ray;
  }
  //CW_RAY�� ������ �ƴϰ� limit�� ���� ������(CCW_RAY�� ����)
  else if ((cw_ray != NULL) && (diff_degree(cw_ray->h.azimuth,azimuth) <= limit))
    ray_temp2 = cw_ray;
  //CCW_RAY�� ������ �ƴϰ� limit�� ���� ������(CW_RAY�� ����)
  else if ((ccw_ray != NULL) && (diff_degree(ccw_ray->h.azimuth,azimuth) <= limit))
    ray_temp2 = ccw_ray;

  if (ray_temp1 != NULL) {
    if (minus_degree(ray_temp1->h.azimuth,azimuth) < 0) {
      cloest_rays.r[0] = ray_temp1;
      cloest_rays.valid[0] = 1;
      cloest_rays.theta[0] = ray_temp1->h.azimuth;
    }
    else {
      cloest_rays.r[1] = ray_temp1;
      cloest_rays.valid[1] = 1;
      cloest_rays.theta[1] = ray_temp1->h.azimuth;
    }
  }

  if (ray_temp2 != NULL) {
    if (minus_degree(ray_temp2->h.azimuth,azimuth) < 0) {
      cloest_rays.r[0] = ray_temp2;
      cloest_rays.valid[0] = 1;
      cloest_rays.theta[0] = ray_temp2->h.azimuth;
    }
    else {
      cloest_rays.r[1] = ray_temp2;
      cloest_rays.valid[1] = 1;
      cloest_rays.theta[1] = ray_temp2->h.azimuth;
    }
  }
  return cloest_rays;
}

//=======================================================================
static CLOEST_VALUES get_cloest_2_bins(Ray* r,float range)
{
  CLOEST_VALUES cloest_values;
  float bin_num_f;
  int bin_num1;
  int bin_num2;
  float gate_size;
  float range_bin1;

  //�ʱ�ȭ
  cloest_values.dBZ[0] = BAD_VALUE_F;
  cloest_values.dBZ[1] = BAD_VALUE_F;
  cloest_values.valid[0] = 0;
  cloest_values.valid[1] = 0;

  if (r == NULL)
    return cloest_values;

  range_bin1 = r->h.range_bin1;
  gate_size = r->h.gate_size;

  bin_num_f = (range-range_bin1)/(gate_size*1.0);
  bin_num1 = (int)(bin_num_f);
  bin_num2 = (int)(bin_num_f + 1);
  if ((bin_num1 <= r->h.nbins) && (bin_num1 >= 0) && (r->h.f(r->range[bin_num1]) != BADVAL)) {
    cloest_values.dBZ[0] = r->h.f(r->range[bin_num1]);
    cloest_values.bin_num[0] = bin_num1;
    cloest_values.valid[0] = 1;
    cloest_values.R[0] = bin_num1;
  }

  if ((bin_num2 <= r->h.nbins) && (bin_num2 >= 0) && (r->h.f(r->range[bin_num2]) != BADVAL)) {
    cloest_values.dBZ[1] = r->h.f(r->range[bin_num2]);
    cloest_values.bin_num[1] = bin_num2;
    cloest_values.valid[1] = 1;
    cloest_values.R[1] = bin_num2;
  }
  return cloest_values;
}

//=======================================================================
float cal_mohr_cappi_value_f2(Volume* volume,CLOEST_SWEEPS cs,float azimuth,float elevation,float slant_range, int pseudo_cappi, int is_dBZ)
{
  int s;
  float result;

  float dR,dT;
  float R_Ri,R_Rip1;//R-R_i,R-R_(i+1)
  float T_Tj,T_Tjp1;//T-T_i,T-T_(j+1)
  float Ze_i_j,Ze_ip1_j,Ze_i_jp1,Ze_ip1_jp1;
  float Ze_R_T[2];
  float Ze_R_T_temp1,Ze_R_T_temp2;
  float dP;
  float P_Pk,P_Pkp1;
  int   processed;

  result = BAD_VALUE_F;

  dR = 1.;
  dT = 1.;

  processed = 0;

  //���� ������ �׳� return
  if (!cs.rays[0].values[0].valid[0] && !cs.rays[0].values[0].valid[1] && !cs.rays[0].values[1].valid[0] && !cs.rays[0].values[1].valid[1] &&
      !cs.rays[1].values[0].valid[0] && !cs.rays[1].values[0].valid[1] && !cs.rays[1].values[1].valid[0] && !cs.rays[1].values[1].valid[1])
    return BAD_VALUE_F;

  switch (pseudo_cappi) {
    case 0 : break;
/*    //ù��° sweep���� ���� ���� ���� beamwidth��ŭ�� �׸��� �������� �ȱ׸�
    if (cs.valid[1] && !cs.valid[0] && cs.s[1]->h.sweep_num == 1) {
      if (elevation < (cs.s[1]->h.elev - cs.s[1]->h.beam_width/2.))
        return BAD_VALUE_F;
    }
*/
    //REAL_CAPPI ù��° sweep���� ���� ���� �ȱ׸�
    case 1 : 
      if (cs.valid[1] && !cs.valid[0] && cs.s[1]->h.sweep_num == 1) {
        if (elevation < (cs.s[1]->h.elev))
          return BAD_VALUE_F;
      }
      break;
    default : return -9999;
  }

  /****************************************************
    Ze(R,Theta)
  ****************************************************/
  for (s = 0 ; s < 2 ; s++ )
  {
    //�⺻�� ����
    R_Ri = 0.5;
    R_Rip1 = -0.5;
    T_Tj = 1.;
    T_Tjp1 = -1.;
    Ze_i_j = 0.;
    Ze_ip1_j = 0.;
    Ze_i_jp1 = 0.;
    Ze_ip1_jp1 = 0.;
    Ze_R_T[s] = 0.;

    if (!cs.valid[s])  continue;

//    if (!cs.rays[s].values[0].valid[0] && !cs.rays[s].values[0].valid[1] && !cs.rays[s].values[1].valid[0] && !cs.rays[s].values[1].valid[1])
//      continue;

    if (cs.s[s]->ray[0] != NULL) {
      //R-Ri�� R-Ri+1�� �⺻���� gate_size/2�� ������.
      R_Ri = (cs.s[s]->ray[0]->h.gate_size/1000.)/2.;
      R_Rip1 = -1. * R_Ri;
      //dR�� �⺻���� ù��° ray�� gate_size�� ��.
      dR = cs.s[s]->ray[0]->h.gate_size/1000.;
    }

    if (cs.s[s]->ray[0] != NULL && cs.s[s]->ray[1] != NULL) {
      //Theta - Theta_j�� Theta - Theta_j+1�� �⺻���� ù��° ray�� �ι�° ray�� azimuth��/2�� ������.
      T_Tj = diff_degree(cs.s[s]->ray[0]->h.azimuth,cs.s[s]->ray[1]->h.azimuth)/2.;
      T_Tjp1 = -1. * T_Tj;
      //dT�� �⺻���� ù��° ray�� �ι�° ray�� azimuth�� ������.
      dT = diff_degree(cs.s[s]->ray[0]->h.azimuth,cs.s[s]->ray[1]->h.azimuth);
    }
    //�⺻�� ���� ��

    //Theta - Theata_j �� Theth - Theata_j+1�� ����.
    if (cs.rays[s].valid[0]) T_Tj = minus_degree(azimuth,cs.rays[s].r[0]->h.azimuth);
    if (cs.rays[s].valid[1]) T_Tjp1 = minus_degree(azimuth,cs.rays[s].r[1]->h.azimuth);

    //�� Ze���� ����.
    if (cs.rays[s].valid[0]) {
      if (cs.rays[s].values[0].valid[0]) {
        if (is_dBZ == 1)
          Ze_i_j = pow(10.,(cs.rays[s].values[0].dBZ[0])/10.);
        else
          Ze_i_j = cs.rays[s].values[0].dBZ[0];
      }
      if (cs.rays[s].values[0].valid[1]) {
        if (is_dBZ == 1)
          Ze_ip1_j = pow(10.,(cs.rays[s].values[0].dBZ[1])/10.);
        else
          Ze_ip1_j = cs.rays[s].values[0].dBZ[1];
      }
    }

    if (cs.rays[s].valid[1]) {
      if (cs.rays[s].values[1].valid[0]) {
        if (is_dBZ == 1)
          Ze_i_jp1 = pow(10.,(cs.rays[s].values[1].dBZ[0])/10.);
        else
          Ze_i_jp1 = cs.rays[s].values[1].dBZ[0];
      }
      if (cs.rays[s].values[1].valid[1]) {
        if (is_dBZ == 1)
          Ze_ip1_jp1 = pow(10.,(cs.rays[s].values[1].dBZ[1])/10.);
        else
          Ze_ip1_jp1 = cs.rays[s].values[1].dBZ[1];
      }
    }

    //R-Ri����. dR����.
    if (cs.rays[s].values[0].valid[0]) {
      R_Ri = (slant_range - (cs.rays[s].values[0].bin_num[0] * cs.rays[s].r[0]->h.gate_size + cs.rays[s].r[0]->h.range_bin1))/1000.;
      dR = cs.rays[s].r[0]->h.gate_size/1000.;
    }
    else if (cs.rays[s].values[1].valid[0]) {
      R_Ri = (slant_range - (cs.rays[s].values[1].bin_num[0] * cs.rays[s].r[1]->h.gate_size + cs.rays[s].r[1]->h.range_bin1))/1000.;
      dR = cs.rays[s].r[1]->h.gate_size/1000.;
    }

    //R-Ri+1����. dR����.
    if (cs.rays[s].values[0].valid[1]) {
      R_Rip1 = (slant_range - (cs.rays[s].values[0].bin_num[1] * cs.rays[s].r[0]->h.gate_size + cs.rays[s].r[0]->h.range_bin1))/1000.;
      dR = cs.rays[s].r[0]->h.gate_size/1000.;
      //printf("(%9.1f-%9d*%9d)/1000.(%d)",slant_range,cs.rays[s].values[0].bin_num[1],cs.rays[s].r[0]->h.gate_size,cs.rays[s].r[0]->h.range_bin1);
    }
    else if (cs.rays[s].values[1].valid[1]) {
      R_Rip1 = (slant_range - (cs.rays[s].values[1].bin_num[1] * cs.rays[s].r[1]->h.gate_size + cs.rays[s].r[1]->h.range_bin1))/1000.;
      dR = cs.rays[s].r[1]->h.gate_size/1000.;
    }

    //dTheata
    if (cs.rays[s].valid[0] && cs.rays[s].valid[1]) {
      dT = diff_degree(cs.rays[s].theta[1],cs.rays[s].theta[0]);
      Ze_R_T_temp1 = R_Ri * ((T_Tj * Ze_ip1_jp1) - (T_Tjp1 * Ze_ip1_j));
      Ze_R_T_temp2 = R_Rip1 * ((T_Tj * Ze_i_jp1) - (T_Tjp1 * Ze_i_j));

      Ze_R_T[s] = (1/(dR*dT)) * (Ze_R_T_temp1 - Ze_R_T_temp2);
    }
    //ray�� �ϳ��� ������ ������ ������ ���� ����
    else if (cs.rays[s].valid[0])
      Ze_R_T[s] = (1/(dR)) * (R_Ri * Ze_ip1_j - R_Rip1 * Ze_i_j);
    else if (cs.rays[s].valid[1])
      Ze_R_T[s] = (1/(dR)) * (R_Ri * Ze_i_jp1 - R_Rip1 * Ze_ip1_jp1);
    else
      return BAD_VALUE_F;

    processed++;
  }

  if (processed <= 0)
    return BAD_VALUE_F;

  /****************************************************
    Ze(R,Theta,Phi)
  ****************************************************/
  //�⺻�� ����
  dP = 1.;
  P_Pk = 0.5;
  P_Pkp1 = 0.5;

  //dP����.
  //sweep�� ���������
  if (cs.valid[0] && cs.valid[1]) {
    //elevation�� �Ʒ� sweep�� �������� ������
    if (elevation == cs.phi[0])
      result = Ze_R_T[0];
    //elevation�� �� sweep�� �������� ������
    else if (elevation == cs.phi[1])
      result = Ze_R_T[1];
    else {
      dP = diff_degree(cs.phi[1],cs.phi[0]);
      //P-Pk�� P-Pk+1����.
      if (cs.valid[0]) P_Pk = minus_degree(elevation,cs.phi[0]);
      if (cs.valid[1]) P_Pkp1 = minus_degree(elevation,cs.phi[1]);
      result = (1/dP) * (P_Pk * Ze_R_T[1] - P_Pkp1 * Ze_R_T[0]);
      //printf("(%9.1f)*(%9.1f*%9.1f - %9.1f*%9.1f = %9.1f\n",(1/dP),P_Pk,Ze_R_T[1],P_Pkp1,Ze_R_T[0],result);
    }
  }
  //�Ʒ� sweep�� ������
  else if (cs.valid[0] && !cs.valid[1])
    result = Ze_R_T[0];
  //�� sweep�� ������
  else if (!cs.valid[0] && cs.valid[1])
    result = Ze_R_T[1];
  else
    return BAD_VALUE_F;

  if (is_dBZ == 1) {
    if (result <= 1) 
      return 0;
    else 
      return (10. * log10(result));
  }
  else
    return result;
}

//=======================================================================
int get_closest_sweep_2_index(Volume *v,float sweep_angle,int* sweep_index1,int* sweep_index2)
{
  Sweep *s;
  int i,ci1,ci2;
  float delta_angle = 91;
  float check_angle;
  
  if(v == NULL) return -1;

  ci1 = -1;
  ci2 = -1;

  //first cloest sweep index
  delta_angle = 91;
  for (i=0; i < v->h.nsweeps; i++) {
    s = v->sweep[i];
    if (s == NULL) continue;
    check_angle = diff_degree(s->h.elev,sweep_angle);

    if (s->h.elev > sweep_angle) break;

    if(check_angle <= delta_angle) {
      delta_angle = check_angle;
      ci1 = i;
    }
  }

  //second cloest sweep index
  delta_angle = 91;
  for (i=v->h.nsweeps - 1; i >= 0 ; i--) {
    s = v->sweep[i];
    if (s == NULL) continue;
    if (ci1 == i) continue;  //skip first cloest sweep
    check_angle = diff_degree(s->h.elev,sweep_angle);

    if (s->h.elev < sweep_angle) break;
    if(check_angle <= delta_angle) {
      delta_angle = check_angle;
      ci2 = i;
    }
  }
  if ((ci1 - ci2) < 0) {
    *sweep_index1 = ci1;
    *sweep_index2 = ci2;
  }
  else {
    *sweep_index1 = ci2;
    *sweep_index2 = ci1;
  }
  return 1;
}

//=======================================================================
float diff_degree(float alpha, float beta)
{
  return fabs(minus_degree(alpha,beta));
}

//=======================================================================
float minus_degree(float alpha, float beta)
{
  float min;
  min = alpha - beta;

  if (alpha == beta) return 0.;

  if (min > 180.)
    return min - 360.;
  else if (min < -180.)
    return 360. + min;
  return min;
}
