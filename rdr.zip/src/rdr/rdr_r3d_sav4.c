/*******************************************************************************
**
**  ���̴� 3���� �ռ��ڷ� ���� ���α׷� (�ڵ�)
**
**=============================================================================*
**
**   o �ۼ��� : ����ȯ (2018.8.31)
**
********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <math.h>
#include <zlib.h>
#include <zconf.h>

#define PROC_USER "rdr"              // ���μ��� ����
#define LOG_DIR   "/rdr/LOGD"        // �α� ���丮

FILE   *log_open();
FILE   *fp_log;
int    YYg, MMg, HHg, DDg, MIg, SSg;
char   msg_ini[256];


int main(int argc, char *argv[])
{
  time_t tp;
  DIR  *dp;
  struct dirent  *dirp;
  struct stat st;
  char   fname[120], cmd[256], obs[8], log[256];
  int  seq, YY, MM, DD, HH, MI, SS;
  int  i, k, code;

  // 1. ��ó��
  if ( sav_init(argv[0], PROC_USER, "", 10) < 0 ) return -1;

  // 2. �ݺ� ����
  while (1) {
    // 3. Log File Open
    fp_log = log_open(LOG_DIR, argv[0]);

    // 4. ���ؽð� ����
    get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);
    seq = time2seq(YYg, MMg, DDg, HHg, MIg, 'm') - 2;  // ���� ���ſ� 2�� ���� �ҿ�
    seq = ( seq / 5 ) * 5;
    fprintf(fp_log, "#-----------------------------------------------------------------------------------\n");
    printf("#-----------------------------------------------------------------------------------\n");

    // 5. 15�� ������ ó��
    for (i = 0; i <= 15; i += 5) {
      // 5.1. �ð� ����
      seq2time(seq-i, &YY, &MM, &DD, &HH, &MI, 'm', 'n');

      // 5.4. �ռ��ڷ� ����
      for (k = 3; k < 4; k++) {
        if      (k == 0) strcpy(obs,"CZ");
        else if (k == 1) strcpy(obs,"DR");
        else if (k == 2) strcpy(obs,"RH");
        else if (k == 3) strcpy(obs,"KD");
        else if (k == 4) strcpy(obs,"HC");

        // ����ð�
        get_time(&YYg, &MMg, &DDg, &HHg, &MIg, &SSg);
        sprintf(msg_ini, "#%02d%02d%02d:[%04d%02d%02d%02d%02d]", HHg, MIg, SSg, YY, MM, DD, HH, MI);

        // ���û+����
        sprintf(log, "$%s[EXT_%s]\n", &msg_ini[1], obs);  fprintf(fp_log, log);  printf(log);
        sprintf(cmd, "rdr_r3d_echo man EXT %s %d %d %d %d %d", obs, YY, MM, DD, HH, MI);
        code = system(cmd);
        sprintf(log, "#%s[EXT_%s]:%s (%d)\n", &msg_ini[1], obs, cmd, code);  fprintf(fp_log, log);  printf(log);

        // ���û
        sprintf(log, "$%s[KMA_%s]\n", &msg_ini[1], obs);  fprintf(fp_log, log);  printf(log);
        sprintf(cmd, "rdr_r3d_echo man KMA %s %d %d %d %d %d", obs, YY, MM, DD, HH, MI);
        code = system(cmd);
        sprintf(log, "#%s[EXT_%s]:%s (%d)\n", &msg_ini[1], obs, cmd, code);  fprintf(fp_log, log);  printf(log);
      }
      fflush(fp_log);
    }

    // 6. Log File Close
    fclose(fp_log);
    sleep(15);
  }
  return 0;
}
