/*******************************************************************************
**
**  QC된 레이더 합성자료를 위성, AWS 등으로 보정하여 1km 해상도로 저장
**
**=============================================================================*
**
**     o 작성자 : 이정환 (2015.7.21)
**     o 수정자 : 황동익 (2016.5.23)
**     o 수정자 : 황동익 (2016.12.19)
**
********************************************************************************
**
**   수정이력
**   1. 2016.12.19 : AWS 15분 강수량*4 자료만으로 보정하던 것에 AWS 강수유무
**      자료를 추가한다.
**
********************************************************************************/
#include "qpe_ram_int_img.h"
#define  DST_DIR  "/rdr/BUFD/DFSD"

struct INPUT_VAR var;               // 사용자 입력 변수
struct STN_VAL stn_data[MAX_STN];   // 지점 자료
float  **g;                         // 객관분석결과
float  rct[RDR_NY+1][RDR_NX+1];     // 강수유무 검증 활용을 위한 천리안 운형.2016.12.19.황동익.

FILE   *fp_log;
int grid_smooth(float **g, int nx, int ny, float missing);

/*******************************************************************************
 *
 *  MAIN
 *
 *******************************************************************************/
int main(int argc, char *argv[])
{
  char  tm[16];
  float km_px, rn1, z1, z0;
  int   YY, MM, DD, HH, MI;
  int   code, num_sm;
  int   i, j, k, n;

  // 1. 초기화
  if (argc != 4) {
    printf("[Usage] %s merge acc yyyymmddhhmi\n", argv[0]);
    printf("   - merge : 0-레이더합성, 1-AWS로 편차보정, 2-AWS객관분석과 융합\n");
    printf("   - acc   : 누적기간(단위: 분) 10-1장, 60-1시간 누적\n");
    printf("   - yyyymmddhhmi : 년월일시분(KST)\n");
    return -1;
  }

  var.merge = atoi(argv[1]);
  if (var.merge < 0 || var.merge > 2) return -2;

  var.acc = (int)(atoi(argv[2])/10)*10;
  if (var.acc < 10) var.acc = 10;

  strcpy(tm, argv[3]);

  // 2. 파라미터 설정
  code = user_input(tm);
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  printf("#TIME = %04d.%02d.%02d.%02d:%02d(KST)", YY, MM, DD, HH, MI);
  if (code < 0) {
    printf(" : rdr_cmp file not exist\n");
    return -3;
  }
  else
    printf("\n");

  // 3. 격자점 영역 설정 및 초기화
  g = matrix(0, var.NY, 0, var.NX);
  for (j = 0; j <= var.NY; j++) {
    for (i = 0; i <= var.NX; i++) {
      g[j][i] = BLANK1;
    }
  }

  // 4. 레이더자료를 읽음
  rdr_cmp_get();

  // 5. 평활화
  num_sm = 1;
  for (i = 0; i < num_sm; i++)
    grid_smooth(g, var.NX, var.NY, BLANK3*0.01);

  // 6. AWS자료로 편차장을 계산하여 보정
  if (var.merge >= 1) {
    // 6.1. AWS 강수량자료 읽기
    aws_data_get();

    // 6.2. AWS dBz 객관분석 및 가상지점 강수량 배정.2016.5.23.황동익.
    var.mq_sm = 50.0;
    aws_dbz_obj();

    // 6.3. 레이더-AWS 편차장 객관분석
    var.mq_sm = 500.0;
    aws_rdr_diff_obj();
  }

  // 7 객관분석한 AWS 자료와 융합
  if (var.merge >= 2) {
    var.mq_sm = 50.0;
    aws_data_obj();
  }

  // 8. dBz에서 강수량으로 변환
  rn1 = 0.02; //0.1을 0.02로 수정.2016.12.19.황동익.
  dbz_rain_conv(&z0, &rn1, 1);
  for (j = 0; j <= var.NY; j++) {
    for (i = 0; i <= var.NX; i++) {
      z1 = g[j][i];

      if (z1 <= BLANK2*0.01)
        rn1 = z1;
      else if (z1 < z0)
        rn1 = BLANK3*0.01;
      else
        dbz_rain_conv(&z1, &rn1, 0);

      g[j][i] = rn1;
    }
  }

  // 10. 레이더자료 저장
  rdr_data_sav();

  // 11. 메모리 반납
  free_matrix(g, 0, var.NY, 0, var.NX);
  return 0;
}

/*******************************************************************************
 *
 *  격자자료 웹 이미지 표출시 사용자 요청 분석 부분
 *
 *******************************************************************************/
int user_input(char tm[])
{
  char *qs, fname[120];
  char tmp[256], item[32], value[32];
  int  auto_man = 0, code;
  int  iYY, iMM, iDD, iHH, iMI, iSS;
  int  iseq, i;

  // 1. 변수 초기값 : 자료별 처리 프로그램에서 각자 상황에 맞게 설정
  strcpy(var.map, "B");   // 지도영역
  strcpy(var.obj, "mq");  // 객관분석방법
  var.grid = 1.0;         // 1km 격자간격
  var.zoom_level = 0;     // 전체영역
  var.zoom_rate = 2;      // 2배 확대가 기본
  var.mq_mp = 0.0005;     // MQ: 설정1
  var.mq_sm = 100.0;      // MQ: 설정2
  var.bn_r1 = 30;         // Barnes: 1차 반경 = 30km
  var.bn_r2 = 10;         // Barnes: 2차 반경 = 10km
  var.ZRa = 280.0;
  var.ZRb = 1.45;
  var.itv = 10;
  strcpy(var.obs, "ppi");
  var.qcd = 1;

  if      (strstr(var.obs,"cpp")) var.data = 1;
  else if (strstr(var.obs,"cmx")) var.data = 2;
  else if (strstr(var.obs,"ppi")) var.data = 3;
  else var.data = 4;

  // 2. 지도 영역
  grid_map_inf(var.map, &(var.GX), &(var.GY), &(var.SX), &(var.SY));
  var.NX = (int)(var.GX/var.grid);
  var.NY = (int)(var.GY/var.grid);

  // 3. 현재시간 및 재계산 지연시간 설정
  get_time(&iYY, &iMM, &iDD, &iHH, &iMI, &iSS);
  iseq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm') - 6;
  seq2time(iseq, &iYY, &iMM, &iDD, &iHH, &iMI, 'm', 'n');
  var.seq_now = iseq;

  // 4. 요청시간 설정
  if (strlen(tm) >= 10) {
    strncpy(tmp, &tm[0], 4);  tmp[4] = '\0';  iYY = atoi(tmp);
    strncpy(tmp, &tm[4], 2);  tmp[2] = '\0';  iMM = atoi(tmp);
    strncpy(tmp, &tm[6], 2);  tmp[2] = '\0';  iDD = atoi(tmp);
    strncpy(tmp, &tm[8], 2);  tmp[2] = '\0';  iHH = atoi(tmp);
    strncpy(tmp, &tm[10],2);  tmp[2] = '\0';  iMI = atoi(tmp);
    auto_man = 1;
  }
  else {
    auto_man = 0;
  }
  var.seq = time2seq(iYY, iMM, iDD, iHH, iMI, 'm');
  var.seq = 10*(var.seq/10);

  // 5. 파일 존재여부 확인
  code = -1;
  if (auto_man == 0) {
    for (i = 0; i < 10; i++, var.seq -= 10) {
      if (rdr_cmp_file(var.seq, fname) >= 0) {
        code = 0;
        break;
      }
    }
  }
  else {
    if (rdr_cmp_file(var.seq, fname) >= 0) code = 0;
  }
  if (code < 0) {
    printf("file no eixst = %s\n", fname);
  }
  return code;
}

/*******************************************************************************
 *
 *  분포도 이미지 생성 및 전송
 *
 *******************************************************************************/
int rdr_data_sav()
{
  FILE  *fp;
  char  dir1[100], fname[120], bname[120], tname[120], oname[120], cmd[250], head[720];
  short buf[2000];
  int   fsize = 0, code;
  int   YY, MM, DD, HH, MI;
  int   i, j, k;

  // 1. 자료 시간(KST)을 확인한다
  seq2time(var.seq, &YY, &MM, &DD, &HH, &MI, 'm', 'n');
  printf("tm = %04d.%02d.%02d.%02d:%02d\n", YY, MM, DD, HH, MI);
  printf("NX = %d, NY = %d\n", var.NX, var.NY);

  // 2. 파일명을 생성한다.
  if ((var.seq_now - var.seq) > 120)
    sprintf(dir1, "%s", QPE_DIR);   //2018.03.손명재
  else
    strcpy(dir1, DST_DIR);

  // 과거자료 생성시 자료가 분배 프로세스를 거치지 않고 바로 목적 디렉토리로 이동하도록
  // 조치. 2016.04.21. 황동익 수정
  if (var.merge == 0)
    sprintf(fname, "%s/qpe_rpi_%02dm_%04d%02d%02d%02d%02d.bin", dir1, var.acc, YY, MM, DD, HH, MI);
  else if (var.merge == 1)
    sprintf(fname, "%s/qpe_rac_%02dm_%04d%02d%02d%02d%02d.bin", dir1, var.acc, YY, MM, DD, HH, MI);
  else if (var.merge == 2)
    sprintf(fname, "%s/qpe_ram_%02dm_%04d%02d%02d%02d%02d.bin", dir1, var.acc, YY, MM, DD, HH, MI);

  // 3. 이진파일로 임시 저장한다.
  strcpy(bname, fname);
  strcat(bname, ".tmp");
  fp = fopen(bname,"w");
  fsize = fwrite(head, 1, 720, fp);

  for (j = 0; j <= var.NY; j++) {
    for (i = 0; i <= var.NX; i++) {
      if (g[j][i] < -1000) g[j][i] *= 0.01;
      buf[i] = (short)(g[j][i]*100);
    }
    fsize += fwrite(buf, 2, var.NX+1, fp);
  }
  fclose(fp);

  // 4. 저장된 파일의 크기로 정상적으로 저장되었는지 확인한다.
  printf("FILE SAV : %s(%dbytes)", bname, fsize);
  if (fsize != (var.NY+1)*(var.NX+1)+720) {
    printf(" : error\n");
    return -1;
  }
  else
    printf(" : OK\n");

  // 5. 임시저장된 이진파일을 압축한다.
  strcpy(tname, fname);
  strcat(tname, ".gz.tmp");
  sprintf(cmd, "/bin/gzip -c %s > %s", bname, tname);
  code = system(cmd);
  printf("FILE gzip : %s(%d)", tname, code);
  if (code == 0) {
    strcpy(oname, fname);
    strcat(oname, ".gz");
    code = rename(tname, oname);
    printf(" -> %s(%d)\n", oname, code);
  }
  else {
    printf(" : error\n");
    return -2;
  }

  // 6. 임시저장파일을 삭제한다.
  code = remove(bname);

  return 0;
}

/*=============================================================================*
 *  Grid data Smoothing (by 1-2-1 Smoothing)
 *  by 이정환 (1997. 3. 15)
 *=============================================================================*/
int grid_smooth (
    float **g,      /* input -> output  */
    int   nx,       /* 영역 [0:nx,0:ny] */
    int   ny,
    float missing   /* 이하는 자료 없음 */
)
{
    float  e[4], e1, e2;
    int    i, j;

    for (j = 0; j <= ny; j++) {
        e1 = g[j][0];
        e[0] = g[j][0];
        e[1] = g[j][1];

        for (i = 1; i < nx; i++) {
            e[2] = g[j][i+1];

            if (e[0] > missing && e[1] > missing && e[2] > missing)
                e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
            else if (e[0] > missing && e[1] <= missing && e[2] > missing)
                e2 = (e[0] + e[2]) * 0.5;
            else
                e2 = e[1];

            g[j][i-1] = e1;
            e1 = e2;
            e[0] = e[1];
            e[1] = e[2];
        }
        g[j][i-1] = e1;
    }

    for (i = 0; i <= nx; i++) {
        e1 = g[0][i];
        e[0] = g[0][i];
        e[1] = g[1][i];

        for (j = 1; j < ny; j++) {
            e[2] = g[j+1][i];

            if (e[0] > missing && e[1] > missing && e[2] > missing)
                e2 = (e[0] + 2.0*e[1] + e[2]) * 0.25;
            else if (e[0] > missing && e[1] <= missing && e[2] > missing)
                e2 = (e[0] + e[2]) * 0.5;
            else
                e2 = e[1];

            g[j-1][i] = e1;
            e1 = e2;
            e[0] = e[1];
            e[1] = e[2];
        }
        g[j-1][i] = e1;
    }
    return 0;
}

/*=============================================================================*
 *  지도 영역 정보 읽기
 *
 *      map : inp:지도의 종류
 *      nx  : out:동서방향 지도영역 (km)
 *      ny  : out:남북방향 지도영역 (km)
 *      sx  : out:동서방향 기준위치 (km)
 *      sy  : out:남북방향 기준위치 (km)
 *=============================================================================*/
int grid_map_inf(char *map, int *nx, int *ny, int *sx, int *sy)
{
    FILE  *fp;
    char  buf[1024], map_list[8], value[16];

    fp = fopen(MAP_INI_FILE,"r");
    if (fp == NULL) exit(-1);

    while (fgets(buf,1024,fp)) {
        if (buf[0] == '#') continue;
        getword(map_list, buf, ':');

        if ( !strcmp(map, map_list) ) {
            getword(value, buf, ':');  *nx = atoi(value);
            getword(value, buf, ':');  *ny = atoi(value);
            getword(value, buf, ':');  *sx = atoi(value);
            getword(value, buf, ':');  *sy = atoi(value);
            break;
        }
    }
    fclose(fp);

    return 0;
}
