package kres.us.cmmn.service;

public class UsTyphoonRouteVO {
	private String			LST		= "";
	private String			UTC		= "";
	private float 			LAT		= 0;
	private float 			LON		= 0;
	private float			DIST	= 0;
	private float			DIR		= 0;
	private float 			SPEED	= 0;
	private String			MEMO	= "";
	
	public String getLST() {
		return LST;
	}
	public void setLST(String lST) {
		LST = lST;
	}
	public String getUTC() {
		return UTC;
	}
	public void setUTC(String uTC) {
		UTC = uTC;
	}
	public float getLAT() {
		return LAT;
	}
	public void setLAT(float lAT) {
		LAT = lAT;
	}
	public float getLON() {
		return LON;
	}
	public void setLON(float lON) {
		LON = lON;
	}
	public float getDIST() {
		return DIST;
	}
	public void setDIST(float dIST) {
		DIST = dIST;
	}
	public float getDIR() {
		return DIR;
	}
	public void setDIR(float dIR) {
		DIR = dIR;
	}
	public float getSPEED() {
		return SPEED;
	}
	public void setSPEED(float sPEED) {
		SPEED = sPEED;
	}
	public String getMEMO() {
		return MEMO;
	}
	public void setMEMO(String mEMO) {
		MEMO = mEMO;
	}	
}
