(function() {

    var db = {

        loadData: function(filter) {
            return $.ajax({
                type: "GET",
                url: "/cmmn/typhoonGET.do",
                data: filter
            });
            
/*            return $.grep(this.clients, function(client) {
                return 1;
            });*/
        },

        insertItem: function(insertingClient) {
            this.clients.push(insertingClient);
        },

        updateItem: function(updatingClient) { },

        deleteItem: function(deletingClient) {
            var clientIndex = $.inArray(deletingClient, this.clients);
            this.clients.splice(clientIndex, 1);
        }

    };

    window.db = db;


    db.countries = [
        { Name: "", Id: 0 },
        { Name: "United States", Id: 1 },
        { Name: "Canada", Id: 2 },
        { Name: "United Kingdom", Id: 3 },
        { Name: "France", Id: 4 },
        { Name: "Brazil", Id: 5 },
        { Name: "China", Id: 6 },
        { Name: "Russia", Id: 7 }
    ];

    db.clients = [
        {
            "LST": "201908081359",
            "UTC": "201908080459",
            "LAT": 38.1,
            "LON": 126.8,
            "DIST": 130,
            "DIR": 360,
            "SPEED": 6,
            "MEMO": "한글메모"            
        },
        {
            "LST": "201908081359",
            "UTC": "201908080459",
            "LAT": 38.1,
            "LON": 126.8,
            "DIST": 130,
            "DIR": 360,
            "SPEED": 6,
            "MEMO": "한글메모" 
        }
    ];

    db.users = [
        {
            "ID": "x",
            "Account": "A758A693-0302-03D1-AE53-EEFE22855556",
            "Name": "Carson Kelley",
            "RegisterDate": "2002-04-20T22:55:52-07:00"
        },
        {
            "Account": "D89FF524-1233-0CE7-C9E1-56EFF017A321",
            "Name": "Prescott Griffin",
            "RegisterDate": "2011-02-22T05:59:55-08:00"
        }
     ];

}());