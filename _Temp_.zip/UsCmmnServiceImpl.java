package kres.us.cmmn.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import kres.ad.menu.service.AdMenuMngVO;
import kres.ad.option.service.AdOptionVO;
import kres.us.cmmn.service.UsCmmnService;
import kres.us.cmmn.service.UsCmmnVO;
import kres.us.cmmn.service.UsTyphoonListVO;
import kres.us.cmmn.service.UsTyphoonRouteVO;
import kres.us.comp.service.UsCompRightVO;

import org.codehaus.jettison.json.JSONArray;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.reflect.TypeToken;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;


/**
 *  @Class Name : UsCmmnServiceImpl.java
 *  @Project Name : KRES
 *  @Modification Information
 *  @
 *  @  수정일             수정자               수정내용
 *  @ ------------     -------------     ---------------------------
 *  @ 2016. 9. 21.          류중규      
 *
 *  @author safeKorea(류중규)
 *  @since 2016. 9. 21.
 *  @see UsCmmnServiceImpl
 *  @Description : 
 *
 */
@Service("usCmmnService")
public class UsCmmnServiceImpl extends EgovAbstractServiceImpl implements UsCmmnService{
	
	@Resource(name="usCmmnMapper")
	private UsCmmnMapper usCmmnMapper;
	
	//시군구 리스트 조회
	public Map<String, Object> selectSidoList(Map<String, Object> map) throws Exception{
		
		List<UsCmmnVO> list = usCmmnMapper.selectSidoList(map);
		map.put("list", list);
		return map;
	}
	
	public List<UsCompRightVO> selectSiteSortList() throws Exception{
		return usCmmnMapper.selectSiteSortList();
	}
	
	public List<AdMenuMngVO> selectMenuList(HashMap<String, Object> param) throws Exception {
		return usCmmnMapper.selectMenuList(param);
	}

	public List<AdMenuMngVO> selectMenuTreeList() throws Exception {
		return usCmmnMapper.selectMenuTreeList();
	}
	
	public List<AdOptionVO> getOptionList(String url) throws Exception {
		return usCmmnMapper.getOptionList(url);
	}

	public List<AdOptionVO> getAllOptionList() throws Exception {
		return usCmmnMapper.getAllOptionList();
	}
	
	public int getOptionMenuCount() throws Exception {
		return usCmmnMapper.getOptionMenuCount();
	}
	
	/**
	 * @Method Name : selectObsStation
	 * @date,  2016. 8. 12.
	 * @author 이성규
	 * @description 
	 *
	 * @return
	 * @throws Exception List<UsCmmnVO>
	 */
	public List<UsCompRightVO> selectObsStation(HashMap<String, Object> map) throws Exception{
		return usCmmnMapper.selectObsStation(map);
	}
	
	/**
	 * @Method Name : getOptionListByCno
	 * @date,  2016. 9. 2.
	 * @author 강혜리
	 * @description 
	 *
	 * @param cno
	 * @return
	 * @throws Exception List<AdOptionVO>
	 */
	public List<AdOptionVO> getOptionListByCno(String cno) throws Exception{
		return usCmmnMapper.getOptionListByCno(cno);
	}

	/**
	 * @Method Name : selectMenuListByNm
	 * @date,  2016. 9. 4.
	 * @author 강혜리
	 * @description 
	 *
	 * @param cno
	 * @return
	 * @throws Exception List<AdOptionVO>
	 */
	@Override
	public List<AdOptionVO> getOptionListByNm(String cno) throws Exception {
		return usCmmnMapper.getOptionListByNm(cno);
	}

	public Map<String, Object> selectAWSBranchList(UsCmmnVO usCmmnVO, PaginationInfo paginationInfo) throws Exception{
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("first", paginationInfo.getFirstRecordIndex() + 1);
		map.put("last", paginationInfo.getLastRecordIndex());
		map.put("awsNm1", usCmmnVO.getAwsNm1());
		map.put("awsNm2", usCmmnVO.getAwsNm2());
		map.put("awsLat", usCmmnVO.getAwsLat());
		map.put("awsLon", usCmmnVO.getAwsLon());
		
		
		List<UsCmmnVO> selectAWSNmList = usCmmnMapper.selectAWSNmList();
		List<UsCmmnVO> selectAWSBranchList = usCmmnMapper.selectAWSBranchList(map);
		int tot = usCmmnMapper.selectAWSBranchListCnt(map);
		
		map.put("selectAWSNmList", selectAWSNmList);
		map.put("selectAWSBranchList", selectAWSBranchList);
		map.put("tot", tot);
		
		return map;
	}
	
	@Override
	public List<UsCmmnVO> selectAWSPoint(UsCmmnVO usCmmnVO) throws Exception {
		return usCmmnMapper.selectAWSPoint(usCmmnVO);
	}
	
	/**
	 * @Method Name : selectSitetimeToObsStation
	 * @date,  2017.10.10.
	 * @author 한선묵
	 * @description 
	 *  사이트의 관측주기 조회
	 * @return
	 * @throws int
	 */
	public int selectSitetimeToObsStation(HashMap<String, Object> map){
		List<UsCompRightVO> list = usCmmnMapper.selectSitetimeToObsStation(map);
		
		int sitetime = 10;	// default 사이트 관측주기 10분
		if(!list.isEmpty()) {
			sitetime = list.get(0).getSitetime();
		}
		
		return sitetime;
	}
	
	//oskim 20190804
	public Map<String, Object> selectTyphoonList(UsTyphoonListVO usTyphoonListVO, PaginationInfo paginationInfo) throws Exception{
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("first", paginationInfo.getFirstRecordIndex() + 1);
		map.put("last", paginationInfo.getLastRecordIndex());
		
		int tot = 						usCmmnMapper.selectTyphoonListCnt(map);
		List<UsTyphoonListVO> list = 	usCmmnMapper.selectTyphoonList();
		
		map.put("tot", tot);
		map.put("selectTyphoonList", list);
		
		/*
		if(usTyphoonListVO.getnID() > 0){
			List<UsTyphoonRouteVO> route = 	usCmmnMapper.selectTyphoonRoute(map);
			map.put("selectTyphoonRoute", route);
		}
		*/
		
		return map;
	}

	public JsonArray getTyphoonRouteJSON(String typhoonName) throws Exception {
		List<UsTyphoonRouteVO> list = usCmmnMapper.selectTyphoonRoute(typhoonName);

		JsonArray result = (JsonArray) new Gson().toJsonTree(list,
		            new TypeToken<List<UsTyphoonRouteVO>>() {
		            }.getType());

		return result;
	}
	
	public void insertTyphoonRoute(Map<String, Object> map) throws Exception{
		usCmmnMapper.insertTyphoonRoute(map);
	}
	
	public void updateTyphoonRoute(UsTyphoonRouteVO usTyphoonRouteVO) throws Exception{
		usCmmnMapper.updateTyphoonRoute(usTyphoonRouteVO);
	}
	
	public void deleteTyphoonRoute(String strLST) throws Exception{
		usCmmnMapper.deleteTyphoonRoute(strLST);
	}
	
	/////////////////////////////////////////////////////////////
	
	public JsonArray getTyphoonListJSON() throws Exception {
		List<UsTyphoonListVO> list = usCmmnMapper.selectTyphoonList();

		JsonArray result = (JsonArray) new Gson().toJsonTree(list,
		            new TypeToken<List<UsTyphoonListVO>>() {
		            }.getType());

		return result;
	}
	
	public void insertTyphoonList(UsTyphoonListVO usTyphoonListVO) throws Exception {
		usCmmnMapper.insertTyphoonList(usTyphoonListVO);
	}
	
	public void updateTyphoonList(UsTyphoonListVO usTyphoonListVO) throws Exception {
		usCmmnMapper.updateTyphoonList(usTyphoonListVO);
	}
	
	public void deleteTyphoonList(String strKNAME) throws Exception {
		usCmmnMapper.deleteTyphoonList(strKNAME);
	}	
}
















