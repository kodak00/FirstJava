(function() {

    var db = {   	
        loadData: function(filter) {
        	var selName = $("#typhoonName").val();
        	//name = encodeURIComponent(selName);
        	name = encodeURIComponent('다나스');
        	
            return $.ajax({
                type: "GET",
                url: "/cmmn/typhoonRouteGET.do",
                data: {filter:filter, name:name}
            });
        },

        insertItem: function(item) {
        	var selName = $("#typhoonName").val();
        	
        	//자동 필드 계산
        	item.UTC 	= item.LST;
        	item.DIST 	= item.LAT + 100;
        	item.DIR 	= item.LAT + 200;
        	item.SPEED 	= item.LAT + 300;
        	
        	item.NAME	= selName;
        	
            return $.ajax({
                type: "POST",
                url: "/cmmn/typhoonRoutePOST.do",
                data: item
            });
        },

        updateItem: function(item) {
        	//자동 필드 계산
        	item.UTC 	= item.LST;
        	item.DIST 	= item.LAT + 100;
        	item.DIR 	= item.LAT + 200;
        	item.SPEED 	= item.LAT + 300;        	
        	
            return $.ajax({
                type: "POST",
                url: "/cmmn/typhoonRoutePUT.do",
                data: item
            });        	
        },

        deleteItem: function(item) {
            return $.ajax({
                type: "POST",
                url: "/cmmn/typhoonRouteDELETE.do",
                data: item
            });
        }

    };

    window.db = db;

}());