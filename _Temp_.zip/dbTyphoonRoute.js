(function() {
	
	var prevLST = '';
	var prevLON = '';
	var prevLAT = '';
	
    var db = {   	
        loadData: function(filter) {
        	var selName = $("#typhoonName").val();
        	//name = encodeURIComponent(selName);
        	name = encodeURIComponent('문');
        	
            return $.ajax({
                type: "GET",
                url: "/cmmn/typhoonRouteGET.do",
                data: {filter:filter, name:name}
            });
        },

        insertItem: function(item) {
        	var selName = $("#typhoonName").val();
        	
        	var diffHour = 0;
        	var distance = 0;
        	var azimuth = 0;
        	
        	var LST = item.LST;
        	
        	//LST -> Date형 변환
        	LST = getDateToStr2(LST);
        	currTimeDate = getDateFormatTime(LST);
        	
        	//if(typeof prevLST !== 'undefined' && typeof prevLON !== 'undefined' && typeof prevLAT !== 'undefined'){
        	if( prevLST !== '' &&  prevLON !== '' &&  prevLAT !== ''){
        		prevLST = getDateToStr2(prevLST);
        		prevTimeDate = getDateFormatTime(prevLST);
        		
        		diffHour = (currTimeDate.getTime() - prevTimeDate.getTime()) / (1000*60*60);	//hour
        		distance = cfGetDistance([prevLON,prevLAT,item.LON,item.LAT], 'EPSG:4326') / 1000.0;	//km
        		azimuth = calAzimuth(prevLON,prevLAT,item.LON,item.LAT);
        	}
        	
        	//자동 필드 계산
        	item.UTC 	= getDateToStr(new Date(Date.parse(currTimeDate) - 1000 * 60 * 60 * 9));	//9시간 전
        	item.DIST 	= distance;
        	item.DIR 	= azimuth;
        	item.SPEED 	= diffHour == 0 ? 0 : distance / diffHour;
        	
        	item.NAME	= selName;
        	
        	prevLST = item.LST;
        	prevLON = item.LON;
        	prevLAT = item.LAT;
        	
            return $.ajax({
                type: "POST",
                url: "/cmmn/typhoonRoutePOST.do",
                data: item
            });
        },

        updateItem: function(item) {
        	//수정시 자동 필드 계산 안됨      	
        	
            return $.ajax({
                type: "POST",
                url: "/cmmn/typhoonRoutePUT.do",
                data: item
            });        	
        },

        deleteItem: function(item) {
            return $.ajax({
                type: "POST",
                url: "/cmmn/typhoonRouteDELETE.do",
                data: item
            });
        }

    };

    window.db = db;

}());