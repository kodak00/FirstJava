(function() {

    var db = {   	
        loadData: function(filter) {
            return $.ajax({
                type: "GET",
                url: "/cmmn/typhoonListGET.do",
                data: filter
            });
        },

        insertItem: function(item) {
        	item.INFO = '제' + item.SEQ + '호 태풍';
        	
            return $.ajax({
                type: "POST",
                url: "/cmmn/typhoonListPOST.do",
                data: item
            });        	
        },

        updateItem: function(item) {
        	item.INFO = '제' + item.SEQ + '호 태풍';
        	
            return $.ajax({
                type: "POST",
                url: "/cmmn/typhoonListPUT.do",
                data: item
            }); 
        },

        deleteItem: function(item) {
           return $.ajax({
                type: "POST",
                url: "/cmmn/typhoonListDELETE.do",
                data: item
            });        	
        }

    };

    window.db = db;

}());