/*=============================================================================*
 *  EUC-KR���ڿ��� UTF-8�� ��ȯ
 *=============================================================================*/
int euckr2utf(char *str, char *out)
{
  iconv_t convp;
  size_t  ileft = strlen(str), oleft = strlen(str)*2;
  int     err;

  convp = iconv_open("UTF-8", "euc-kr");
  err = iconv(convp, &str, &ileft, &out, &oleft);
  iconv_close(convp);
  return err;
}

/*=============================================================================*
 *  �������� ǥ��
 *=============================================================================*/
#define TOPO_DIR  "/DATA/GIS/TOPO/KMA"   // �������� ���丮
short **topo;

int topo_disp(
  gdImagePtr im,    // �̹�������
  float data_grid,  // �ڷ��� ����ũ�� (var.NX�� ����,km)
  int topo_color,   // ����� ����ǥ
  int topo_mode,    // ǥ�� ���  (1:���ڿ����� ����)
  int color_area    // �������ȣ
)
{
  FILE  *fp;
  char  fname[120];
  //short **topo;
  long  offset1, offset2, offset3;
  float dg = (float)var.NX/(float)(var.NI);
  float zm = 1.0, xo = 0.0, yo = 0.0, zx, zy, x1, y1, ht;
  float data_topo[40];
  int   color_topo[40];
  int   num_color_topo;
  int   nx, ny, sx, sy;
  int   ix, iy, color1;
  int   i, j, k;
  int   mapHM_NX = 9198,  mapHM_NY = 7998, mapHM_SX = 4599, mapHM_SY = 5434;
  int   mapH5_NX = 5760,  mapH5_NY = 5760, mapH5_SX = 3328, mapH5_SY = 3328;

  // 1. ����� �������� ����ǥ
  if (topo_color == 0) {        // �ط����и�
    color_topo[0] = gdImageColorAllocate(im, 85, 142, 213);   data_topo[0] = 0.5;
    color_topo[1] = gdImageColorAllocate(im, 230, 137,  0);   data_topo[1] = 5000;
    num_color_topo = 2;
  }
  else if (topo_color == 1) {   // ����
    color_topo[0] = gdImageColorAllocate(im,   0,  39, 116);  data_topo[0] = 0.1;
    color_topo[1] = gdImageColorAllocate(im, 244, 183,   0);  data_topo[1] = 100;
    color_topo[2] = gdImageColorAllocate(im, 191, 138,   0);  data_topo[2] = 500;
    color_topo[3] = gdImageColorAllocate(im, 138, 100,   0);  data_topo[3] = 5000;
    num_color_topo = 4;
  }
  else if (topo_color == 2) {   // ����(���)
    color_topo[0] = gdImageColorAllocate(im, 206, 229, 241);  data_topo[0] = 0.1;
    color_topo[1] = gdImageColorAllocate(im, 240, 240, 225);  data_topo[1] = 100;
    color_topo[2] = gdImageColorAllocate(im, 170, 170, 170);  data_topo[2] = 500;
    color_topo[3] = gdImageColorAllocate(im, 120, 120, 120);  data_topo[3] = 5000;
    num_color_topo = 4;
  }
  else if (topo_color == 3) {   // ����(���full����)
    color_topo[0]  = gdImageColorAllocate(im, 206, 229, 241);  data_topo[0]  = 0.1;   // �ٴٻ�
    color_topo[1]  = gdImageColorAllocate(im, 240, 240, 225);  data_topo[1]  = 50;    // - 50m
    color_topo[2]  = gdImageColorAllocate(im, 220, 220, 220);  data_topo[2]  = 100;   // -100m
    color_topo[3]  = gdImageColorAllocate(im, 210, 210, 210);  data_topo[3]  = 150;   // -150m
    color_topo[4]  = gdImageColorAllocate(im, 200, 200, 200);  data_topo[4]  = 200;   // -200m
    color_topo[5]  = gdImageColorAllocate(im, 190, 190, 190);  data_topo[5]  = 300;   // -300m
    color_topo[6]  = gdImageColorAllocate(im, 180, 180, 180);  data_topo[6]  = 400;   // -400m
    color_topo[7]  = gdImageColorAllocate(im, 170, 170, 170);  data_topo[7]  = 500;   // -500m
    color_topo[8]  = gdImageColorAllocate(im, 160, 160, 160);  data_topo[8]  = 600;   // -600m
    color_topo[9]  = gdImageColorAllocate(im, 150, 150, 150);  data_topo[9]  = 700;   // -700m
    color_topo[10] = gdImageColorAllocate(im, 140, 140, 140);  data_topo[10] = 800;   // -800m
    color_topo[11] = gdImageColorAllocate(im, 130, 130, 130);  data_topo[11] = 900;   // -900m
    color_topo[12] = gdImageColorAllocate(im, 120, 120, 120);  data_topo[12] = 1000;  // -1000m
    color_topo[13] = gdImageColorAllocate(im, 110, 110, 110);  data_topo[13] = 1500;  // -1500m
    color_topo[14] = gdImageColorAllocate(im, 100, 100, 100);  data_topo[14] = 3000;  // -5000m
    color_topo[15] = gdImageColorAllocate(im,  90,  90,  90);  data_topo[15] = 9000;  // -9000m
    num_color_topo = 16;
  }
  //color_river = gdImageColorAllocate(im,  98, 169, 213);   // ��

  // 2. ���������ڷ� �б�
  nx = (int)(var.NX*data_grid);  ny = (int)(var.NY*data_grid);
  sx = (int)(var.SX*data_grid);  sy = (int)(var.SY*data_grid);

  if (!strcmp(var.map,"CM") || !strcmp(var.map,"CO") || !strcmp(var.map,"HM")) {
    sprintf(fname, "%s/gmted_meaHM_1km.bin", TOPO_DIR, var.map);
    offset1 = (mapHM_SX - sx)*2;
    offset2 = (mapHM_NX - nx)*2 - offset1;
    offset3 = (mapHM_SY - sy)*(mapHM_NX + 1)*2;
  }
  else {
    sprintf(fname, "%s/gmted_meaH5_1km.bin", TOPO_DIR);
    offset1 = (mapH5_SX - sx)*2;
    offset2 = (mapH5_NX - nx)*2 - offset1;
    offset3 = (mapH5_SY - sy)*(mapH5_NX + 1)*2;
  }
  if ((fp = fopen(fname, "rb")) == NULL) return -1;

  topo = smatrix(0, ny, 0, nx);
  fseek(fp, (long)64, SEEK_SET);    // �ش�(64byts) skip
  fseek(fp, offset3, SEEK_CUR);
  for (j = 0; j <= ny; j++) {
    fseek(fp, offset1, SEEK_CUR);
    fread(topo[j], 2, nx+1, fp);
    fseek(fp, offset2, SEEK_CUR);
  }
  fclose(fp);

  // 3. Ȯ���, �߽���ġ�� Ȯ����� ���
  for (i = 0; i < 7; i++, zm *= 2) {
    zx = var.zoom_x[i]-'0';
    zy = var.zoom_y[i]-'0';
    if (zx == 0 || zy == 0) break;
    xo += (float)nx/8.0*(zx-1)/zm;
    yo += (float)ny/8.0*(zy-1)/zm;
  }

  // 4. �̹��� �ȼ����� ��� (���ڰ� ���� �κи� ǥ��)
  dg = (float)nx/(float)(var.NI*zm);
  for (j = 1; j < var.NJ; j++) {
    y1 = dg*j + yo;
    iy = (int)(y1 + 0.49);
    if (iy < 0 || iy > ny) continue;

    for (i = 1; i < var.NI; i++) {
      x1 = dg*i + xo;
      ix = (int)(x1 + 0.49);
      if (ix < 0 || ix > nx) continue;

      ht = (float)topo[iy][ix];
      if (topo_mode == 0) {
        for (k = 0; k < num_color_topo; k++) {
          if (ht < data_topo[k]) {
            gdImageSetPixel(im, i, var.GJ-j, color_topo[k]);
            break;
          }
        }
      }
      else if (ht > 0) {
        color1 = gdImageGetPixel(im, i, var.GJ-j);
        if (color1 == color_area) {
          for (k = 0; k < num_color_topo; k++) {
            if (ht < data_topo[k]) {
              gdImageSetPixel(im, i, var.GJ-j, color_topo[k]);
              break;
            }
          }
        }
      }
    }
  }

  // 4. ���������ڷ� ���� (�ٽ� ����ϴ� ��쵵 ����)
  //free_smatrix(topo, 0, var.NY, 0, var.NX);
  return 0;
}

/*=============================================================================*
 *  ���� ǥ��
 *=============================================================================*/
#define MAP_DIR "/DATA/GIS/MAP/bln"    // ���������� �ִ� �������

int map_disp(
  gdImagePtr im,    // �̹�������
  char  *map_type,  // ���ð�輱 ���� (�ؾȼ��� map)
  float map_grid,   // var.NX�� ���ڰ���(km)
  int   color_map,  // ���� ����
  int   depth       // 0(�Ǽ�), 1(2��)
)
{
  FILE  *fp;
  char  fname[120], fs[8];
  float zm = 1.0, xo = 0.0, yo = 0.0, x1, y1, x2, y2;
  float rate = (float)(var.NI)/(float)(var.NX);
  float buf[2], ox, oy, km_px;
  int   ibuf[2];
  int   zx, zy, mode;
  int   i, j, k, n;
  int   mapHM_NX = 9198,  mapHM_NY = 7998, mapHM_SX = 4599, mapHM_SY = 5434;
  int   mapH5_NX = 5760,  mapH5_NY = 5760, mapH5_SX = 3328, mapH5_SY = 3328;

  // 1. Ȯ���, �߽���ġ�� Ȯ����� ���
  for (i = 0; i < 7; i++, zm *= 2) {
    zx = var.zoom_x[i]-'0';
    zy = var.zoom_y[i]-'0';
    if (zx == 0 || zy == 0) break;
    xo += (float)(var.NX)/8.0*(zx-1)/zm;
    yo += (float)(var.NY)/8.0*(zy-1)/zm;
  }

  // 2. ���� ���� ���� (��, �ܼ�)
  km_px = (float)(map_grid*var.NX)/(float)(var.NI*zm);
  if (km_px > 1.5)
    strcpy(fs,"s");
  else
    fs[0] = '\0';

  // 3. ���� ��輱 ǥ��
  if (!strcmp(var.map,"CM") || !strcmp(var.map,"CO") || !strcmp(var.map,"HM")) {
    sprintf(fname, "%s/DFS_mapHM%s.bln", MAP_DIR, fs);
    ox = mapHM_SX/map_grid - var.SX;
    oy = mapHM_SY/map_grid - var.SY;
  }
  else {
    if (!strcmp(map_type,"city") || !strcmp(map_type,"road") || !strcmp(map_type,"river"))
      sprintf(fname, "%s/DFS_mapH5_%s.bln", MAP_DIR, map_type);
    else
      sprintf(fname, "%s/DFS_mapH5%s.bln", MAP_DIR, fs);
    ox = mapH5_SX/map_grid - var.SX;
    oy = mapH5_SY/map_grid - var.SY;
  }

  if ((fp = fopen(fname, "rb")) != NULL) {
    while (fread(ibuf, sizeof(int), 2, fp) == 2) {
      for (i = 0; i < ibuf[0]; i++) {
        if (fread(buf, sizeof(float), 2, fp) != 2) break;
        x2 = buf[0]/map_grid - ox;
        y2 = buf[1]/map_grid - oy;
        if (var.zoom_x[0] != '0') {
          x2 = zm*(x2 - xo);
          y2 = zm*(y2 - yo);
        }
        x2 *= rate;
        y2 *= rate;
        if (i > 0) {
          gdImageLine(im, (int)x1, var.GJ-(int)y1, (int)x2, var.GJ-(int)y2, color_map);
          if (depth) gdImageLine(im, (int)x1, var.GJ-(int)y1-1, (int)x2, var.GJ-(int)y2-1, color_map);
        }
        x1 = x2;
        y1 = y2;
      }
    }
    fclose(fp);
  }
  return 0;
}

/*=============================================================================*
 *  ���浵�� ǥ��
 *=============================================================================*/
int latlon_disp(
  gdImagePtr im,
  float map_grid,   // var.NX�� ���ڰ���(km)
  int  color_map
)
{
  FILE   *fp;
  struct lamc_parameter map;
  char   fname[120], fs[8];
  float  zm = 1.0, xo = 0.0, yo = 0.0, x1, y1, x2, y2;
  float  rate = (float)(var.NI)/(float)(var.NX);
  float  lon, lat, x, y;
  int    lon1, lat1, ddeg, lon_min, lon_max, lat_min, lat_max;
  int    styleDashed[4];
  int    ix, iy, zx, zy, mode;
  int    i, j, k, n;

  // 1. Ȯ���, �߽���ġ�� Ȯ����� ���
  for (i = 0; i < 7; i++, zm *= 2) {
    zx = var.zoom_x[i]-'0';
    zy = var.zoom_y[i]-'0';
    if (zx == 0 || zy == 0) break;
    xo += (float)(var.NX)/8.0*(zx-1)/zm;
    yo += (float)(var.NY)/8.0*(zy-1)/zm;
  }

  // 2. ���� ������
  map.Re    = 6371.00877;
  map.grid  = map_grid/(zm*rate);
  map.slat1 = 30.0;    map.slat2 = 60.0;
  map.olon  = 126.0;   map.olat  = 38.0;
  map.xo = (float)(var.SX - xo)*(zm*rate);
  map.yo = (float)(var.SY - yo)*(zm*rate);
  map.first = 0;

  x = 0.0;  y = 0.0;
  lamcproj_ellp(&lon, &lat, &x, &y, 1, &map);
  lat_min = (int)lat;

  x = var.NI;  y = 0.0;
  lamcproj_ellp(&lon, &lat, &x, &y, 1, &map);
  if (lat < lat_min) lat_min = (int)lat;

  x = var.NI*0.5;  y = var.NJ;
  lamcproj_ellp(&lon, &lat, &x, &y, 1, &map);
  lat_max = (int)lat + 1;

  x = 0.0;  y = var.NJ;
  lamcproj_ellp(&lon, &lat, &x, &y, 1, &map);
  lon_min = (int)lon;

  x = var.NI;  y = var.NJ;
  lamcproj_ellp(&lon, &lat, &x, &y, 1, &map);
  lon_max = (int)lon + 1;

  // 3. ����ǥ ����
  styleDashed[0] = color_map;
  styleDashed[1] = color_map;
  styleDashed[2] = gdTransparent;
  styleDashed[3] = gdTransparent;
  gdImageSetStyle(im, styleDashed, 4);

  // 4. ���浵 ����
  if ((float)(lon_max-lon_min)/zm > 30)
    ddeg = 5;
  else if ((float)(lon_max-lon_min)/zm > 12)
    ddeg = 2;
  else
    ddeg = 1;
  //printf("%f %d %d %f / %d %d %d %d\n", var.grid, var.NX, var.NY, rate, lon_min, lon_max, lat_min, lat_max);

  // 5. �浵��
  for (lon1 = lon_min; lon1 <= lon_max; lon1++) {
    if (lon1%ddeg != 0) continue;
    lon = lon1;  lat = lat_min;
    lamcproj_ellp(&lon, &lat, &x1, &y1, 0, &map);
    lon = lon1;  lat = lat_max;
    lamcproj_ellp(&lon, &lat, &x2, &y2, 0, &map);
    gdImageLine(im, x1, var.GJ-y1, x2, var.GJ-y2, gdStyled);
  }

  // 6. ������
  for (lat1 = lat_min; lat1 <= lat_max; lat1++) {
    if (lat1%ddeg != 0) continue;
    lon = lon_min;  lat = lat1;
    lamcproj_ellp(&lon, &lat, &x1, &y1, 0, &map);

    for (lon = lon_min; lon <= lon_max; lon += 0.2) {
      lat = lat1;
      lamcproj_ellp(&lon, &lat, &x2, &y2, 0, &map);
      gdImageLine(im, x1, var.GJ-y1, x2, var.GJ-y2, gdStyled);
      x1 = x2;
      y1 = y2;
    }
  }
  return 0;
}

/*=============================================================================*
 *  �ܸ鼱 ǥ��
 *=============================================================================*/
int cross_line_disp(
  gdImagePtr im,    // �̹�������
  int color_line,   // ���浵�� ����
  int x1,   // �ܸ鵵�� ���۰� ����
  int y1,   // [x1,y1 : x2,y2]
  int x2,
  int y2
)
{
  float zm = 1.0, xo = 0.0, yo = 0.0, zx, zy;
  float grid_nx, grid_ny, dxy;
  int   map_code;
  int   xp1, yp1, xp2, yp2;
  int   i;

  // 1. �ܸ鼱�� �ִ��� �Ǵ�
  if (x1 <= 0) return;

  // 2. 2�� Ȯ���, �߽���ġ�� Ȯ����� ���
  for (i = 0; i < 7; i++, zm *= 2) {
    zx = var.zoom_x[i]-'0';
    zy = var.zoom_y[i]-'0';
    if (zx == 0 || zy == 0) break;
    xo += (var.NX/8.0*(zx-1)/zm);
    yo += (var.NY/8.0*(zy-1)/zm);
  }

  // 4. Ȯ�븦 �����Ͽ� �ܸ鼱�� �ȼ� ��ġ �ľ�
  xp1 = (x1 - xo)*zm*(float)var.NI/(float)var.NX;
  xp2 = (x2 - xo)*zm*(float)var.NI/(float)var.NX;
  yp1 = var.GJ - (y1 - yo)*zm*(float)var.NJ/(float)var.NY;
  yp2 = var.GJ - (y2 - yo)*zm*(float)var.NJ/(float)var.NY;

  // 5. �ܸ鼱 ǥ��
  gdImageLine(im, xp1, yp1, xp2, yp2, color_line);
  gdImageLine(im, xp1, yp1-1, xp2, yp2-1, color_line);
  gdImageFilledArc(im, xp1, yp1, 5, 5, 0, 360, color_line, gdArc);
  gdImageFilledArc(im, xp2, yp2, 5, 5, 0, 360, color_line, gdArc);
  return 0;
}
