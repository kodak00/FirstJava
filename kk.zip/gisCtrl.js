﻿/*
 * gisCtrl.js
 * GIS 컨트롤 관련 함수 
 */
$(function() {
	
	// 위성 체크 이벤트(표출, 미표출)
	$("#stl").click(function() {
		if (this.checked) {
			cfOneLayerVisibleOnOff(ObjectIndex.STL, true);
		} else {
			cfOneLayerVisibleOnOff(ObjectIndex.STL, false);
		}
	});
	// 경위도(그리드 5) 체크 이벤트(표출, 미표출)
	$("#gid").click(function() {
		if (this.checked) {
			cfOneLayerVisibleOnOff(ObjectIndex.GID, true);			
		} else {
			cfOneLayerVisibleOnOff(ObjectIndex.GID, false);
		}
	});
	// 음영기복도 체크 이벤트(표출, 미표출)
	$("#sri").click(function() {
		if (this.checked) {
			cfOneLayerVisibleOnOff(ObjectIndex.SRI, true);
		} else {
			cfOneLayerVisibleOnOff(ObjectIndex.SRI, false);
		}
	});
	// AWS 지점 체크 이벤트(표출, 미표출)
	$("#aws").click(function() {
		if (this.checked) {
			onPoint('AWS');
		} else {
			deletePoint('AWS');
		}
	});
	// 주요공항지점 체크 이벤트(표출, 미표출)
	$("#air").click(function() {
		if (this.checked) {
			onPoint('Air');
		} else {
			deletePoint('Air');
		}
	});

	// 비행정보구역
	$("#fir").click(function() {
		if (this.checked) {
			incheonFIR();
		} else {
			map.removeLayer(firLayer);
		}
	});
	
	// 태풍경계구역 체크 이벤트
	$("#typ").click(function(){
		if(this.checked){
			typhoon();
		}else{
			map.removeLayer(typLayer);
		}
		
	});
	
	// 하천정보 체크 이벤트(표출, 미표출)
	$("#riv-chk").click(function() {
		var rivCnt = 0;
		if(this.checked){
			$("#nationRiv").attr('disabled',false);
			$("#localRiv").attr('disabled',false);
			if($("#nationRiv").prop("checked")){
				cfOneLayerVisibleOnOff(ObjectIndex.NAV, true);
				rivCnt++;
			}
			if($("#localRiv").prop("checked")){
				cfOneLayerVisibleOnOff(ObjectIndex.LCV, true);
				rivCnt++;
			}
			
			if(rivCnt == 0){
				$("#nationRiv").prop("checked", true);
				cfOneLayerVisibleOnOff(ObjectIndex.NAV, true);
			}
			
		}else{
			$("#nationRiv").attr('disabled',true);
			$("#localRiv").attr('disabled',true);
			cfOneLayerVisibleOnOff(ObjectIndex.NAV, false);
			cfOneLayerVisibleOnOff(ObjectIndex.LCV, false);
		}
	});
	
	//국가하천
	$("#nationRiv").click(function(){
		if(this.checked){
			cfOneLayerVisibleOnOff(ObjectIndex.NAV, true);
		}else{
			cfOneLayerVisibleOnOff(ObjectIndex.NAV, false);
		}
	});
	
	// 지방하천
	$("#localRiv").click(function(){
		if(this.checked){
			cfOneLayerVisibleOnOff(ObjectIndex.LCV, true);
		}else{
			cfOneLayerVisibleOnOff(ObjectIndex.LCV, false);
		}
	});
	
	// 도로정보 체크 이벤트(표출, 미표출)
	$("#rod-chk").click(function(){
		var rodCnt = 0;
		if(this.checked){
			$("#express").attr('disabled',false);
			$("#general").attr('disabled',false);
			$("#local").attr('disabled',false);
			if($("#express").prop("checked")){
				cfOneLayerVisibleOnOff(ObjectIndex.EXR, true);
				rodCnt++;
			}
			if($("#general").prop("checked")){
				cfOneLayerVisibleOnOff(ObjectIndex.GNR, true);
				rodCnt++;
			}
			if($("#local").prop("checked")){
				cfOneLayerVisibleOnOff(ObjectIndex.LCR, true);
				rodCnt++;
			}
			if(rodCnt == 0){
				$("#express").prop("checked", true);
				cfOneLayerVisibleOnOff(ObjectIndex.EXR, true);
			}
		}else{
			$("#express").attr('disabled',true);
			$("#general").attr('disabled',true);
			$("#local").attr('disabled',true);
			cfOneLayerVisibleOnOff(ObjectIndex.EXR, false);
			cfOneLayerVisibleOnOff(ObjectIndex.GNR, false);
			cfOneLayerVisibleOnOff(ObjectIndex.LCR, false);
		}
	});
	
	// 고속국도
	$("#express").click(function(){
		if(this.checked){
			cfOneLayerVisibleOnOff(ObjectIndex.EXR, true);
		}else{
			cfOneLayerVisibleOnOff(ObjectIndex.EXR, false);
		}
	});
	
	// 일반국도
	$("#general").click(function(){
		if(this.checked){
			cfOneLayerVisibleOnOff(ObjectIndex.GNR, true);
		}else{
			cfOneLayerVisibleOnOff(ObjectIndex.GNR, false);
		}
	});
	
	// 지방도
	$("#local").click(function(){
		if(this.checked){
			cfOneLayerVisibleOnOff(ObjectIndex.LCR, true);
		}else{
			cfOneLayerVisibleOnOff(ObjectIndex.LCR, false);
		}
	});
	
	
	// 행정구역 체크 이벤트(표출, 미표출)
	// oskim 20180903 ,
	// 행정구역 전체 끄기(그룹처리)
	$("#grp-chk").click(function() {
		if (this.checked) {
			$("#emd").attr('disabled',false);
			$("#txt").attr('disabled',false);
			$("#emd").trigger('click');
		}else{
			$("#emd").attr('disabled',true);
			$("#txt").attr('disabled',true);
			$("#txt").trigger('click');
		}
	});
	// 행정구역+명칭 표시 (행정명은 행정계 폴리곤 내적을 계산하기 때문에, 같이 표출 될 수 밖에 없음)
    $("#emd").click(function() {
		  cfOneLayerVisibleOnOff(ObjectIndex.EML, true);
		  cfOneLayerVisibleOnOff(ObjectIndex.EMD, false);
    });  
    //행정구역 경계만 표시
    $("#txt").click(function() {
    	  cfOneLayerVisibleOnOff(ObjectIndex.EML, false);
		  cfOneLayerVisibleOnOff(ObjectIndex.EMD, true);	    		
    });
	
	// 연직단면
	$("#crossArea").click(function() {
		crossPop();
	});
 	$("#crossSearch").click(function(){
 		atomCrossPop();
 	});

 	//우상단 합성>top메뉴, 그 안의 라디오 버튼 클릭시 legned 업데이트 한다.
 	$(document).on('change', '.radio-inline, input:checkbox[name="top"]', function(){
 	//$(document).on('change', 'input:checkbox[name="top"]', function(){
 		//updateLegendBarImg()는 Image Fetch하는데, delay가 있어 직접 cgi에서 가져오도록 함
 		//여기서 clear 하면, echoLoad()에서 cgi로 직접가져오게 함
 		
 		for(var i = 0; i < gCheckCnt; i++){		//oskim 20171012
 			gLegendUrl[i] = "";
 			gLegendBase64[i] = "";
 		}
 		
		//oskim 20180511 , 대기수상체 전체선택처리는 echoLoad()보다 먼저 처리되어야 정상작동 함
 	    if($(this).text() == "전체"){
 	        atomAllChk();
 	    } 		
 		
        if($("#tabType").val() == "site"){
 		    echoLoad('');		//oskim 20181109 , 중복 redraw() 되는것 같아 막음 -> 20181218 다시 적용
        }
 	}); 
 	
 	// 20181212 khr 레이어추가
 	for (var j = 0; j < 73; j++) {
		cgiAniDataLayer0[j] = new ol.layer.Image({
			source: new ol.source.ImageStatic({
		        url: '',
		        crossOrigin : 'anonymous',
		        projection: 'EPSG:222222',
		        imageExtent: [0,0,0,0]
		    }),
		    opacity: 0
		});
		cgiAniDataLayer0[j].setZIndex(ObjectIndex.CGI + Number(0));
		
		cgiAniDataLayer1[j] = new ol.layer.Image({
			source: new ol.source.ImageStatic({
		        url: '',
		        crossOrigin : 'anonymous',
		        projection: 'EPSG:222222',
		        imageExtent: [0,0,0,0]
		    }),
		    opacity: 0
		});
		cgiAniDataLayer1[j].setZIndex(ObjectIndex.CGI + Number(1));
		
		cgiAniDataLayer2[j] = new ol.layer.Image({
			source: new ol.source.ImageStatic({
		        url: '',
		        crossOrigin : 'anonymous',
		        projection: 'EPSG:222222',
		        imageExtent: [0,0,0,0]
		    }),
		    opacity: 0
		});
		cgiAniDataLayer2[j].setZIndex(ObjectIndex.CGI + Number(2));
		
		cgiAniDataLayer3[j] = new ol.layer.Image({
			source: new ol.source.ImageStatic({
		        url: '',
		        crossOrigin : 'anonymous',
		        projection: 'EPSG:222222',
		        imageExtent: [0,0,0,0]
		    }),
		    opacity: 0
		});
		cgiAniDataLayer3[j].setZIndex(ObjectIndex.CGI + Number(3));
		
		map.addLayer(cgiAniDataLayer0[j]);
		map.addLayer(cgiAniDataLayer1[j]);
		map.addLayer(cgiAniDataLayer2[j]);
		map.addLayer(cgiAniDataLayer3[j]);
		
	}

});

/** 중심점 이동 및 거리표현 가능한 줌레벨 선택 */
function distMoveZoom(lat, lon, dist) {	
	
	/* GIS EXTENT호출시 바로 전 호출 주소와 동일한 경우 지도 중첩 버그로 인해
	 * lon에 한하여 + 0.00000001씩 카운트 하여 url에 변경된 것 처럼 처리함.
	 */
	var urlCnt = $("#urlCnt").val();
	urlCnt = parseFloat(urlCnt)+parseFloat(0.00000001);
	$("#urlCnt").val(urlCnt);
	lon = parseFloat(lon)+parseFloat(urlCnt);

	var point = new Proj4js.Point(lon, lat);
	Proj4js.transform(EPSG_4326, EPSG_222222, point);
	
	var distMinus = (Number(dist)/2)*1000;
	var distWidth = 0; // 가로 영역
	var distHeight = 0; // 세로 영역
	if(Number(dist) == 150){ // 구역별 
		distWidth = (Number(dist)/2)*1000;
		distHeight = 0;
	}else{
		distWidth = (Number(dist)/2)*1000;
		distHeight = (Number(dist)/2)*1000;
	}

	// 해당 위치 이동
	map.getView().fit([point.x - distWidth, point.y - distHeight, point.x + distWidth, point.y + distHeight], cfGetMapSize());
	
	echoLoad('');	
}

//oskim 20171012 - start
var gLegendUrl = ["","",""];
var gLegendBase64 = ["","",""];
var gCheckCnt = 0;

function updateLegendBarImg(){	//oskim 20171012
	
	//gCheckCnt 개수 만큼
	for(var i = 0; i < gCheckCnt; i++){
		if(gLegendUrl[i] != "")
			eval(	"loadImage(	  gLegendUrl["+i+"],	function(legendImg){ gLegendBase64["+i+"] = legendImg; }     )"	);
	}
	
	//wait(500);

}
//oskim 20171012 - end

//우측 상단 옵션설정에 따른 GIS영역 cgi영상 적용
var clearInt;
var removeCgiFlag = false;
function echoLoad(date) {
	removeCgiFlag = true;
	clearInterval(clearInt); // 위험기상경보 타이머 제거

	var url = []; // url
	var legend = []; // 범례 url
	var param = ""; // 파라미터
	var cnt = 1; // 파라미터 그룹 변수
	var optType = ""; // 옵션타입 변수
	var name = ""; // name값, 파라미터명
	var value = ""; // value값
	var ptypeFlag = false;
	var slen = 0;
	var lgtStDate = ""; // 낙뢰 시작시간
	var resultValueTmp = ""; //산출물 value 값 
	
	// 조회시간이 없을 경우 하단 설정된 시간으로
	if (date.length != 12) {
		var dateTime = $("#dateTime").val();
		date = dateTime.replace(/\./gi, "").replace(/:/gi, "").replace(/\s/gi,"");
	}

	var tabType = $("#tabType").val();
	var checkCnt = 0;
	$('input:checkbox[name="top"]:checked').each(function() {
		//기존
		//var chkOpt = $(this).parent().next("td").find(".stitle");
		
		//새로운 탭메뉴구성후 테스트입니다.
		//var chkTmp = $(this).parent().siblings("span").attr("href"); //표출라벨 표시시 
		var chkTmp = $(this).siblings("span").attr("href");
		var chkOpt = $("#"+chkTmp.substring(1, chkTmp.length)).find(".stitle");
		
		for (var i = 0; i < chkOpt.length; i++) {
			ptypeFlag = false;
			optType = chkOpt.eq(i).next().attr("class");

			if (optType == "radio") {
				// radio 버튼
				name = chkOpt.eq(i).next().children().children(":radio").attr("name");
				value = $("input[name='" + name + "']:checked").val();
				
				/*
				 * 20170327
				 * 1) 자료형태를 delay를 주어 값을 받아오기때문에 DB에 임의로 들어있는값(강수) 값이 먼저 체크되어 들어오는 문제가있다.	 
				 * 2) 선택된 자료형태가 selDType이므로 selDType 을 넣는다.			  
				 * 3) q_type, d_type이 선택되지 않았을 경우 value가 undefined로 값이 넘어오는데 그 값을 ""으로 설정
				 * */				
				
				if(tabType == "site"){
					if(typeof(value) == "undefined"){
						value = "";						
					}
					if($("#selRadio").val() == "site" && name.substring(0, name.length - 1) == "d_type"){
						value = $("#selDType").val();
					}
				
				}
			
				//oskim 20180108	강도의 단위 자료별 표시
				if($("#dbz_toggle").hasClass("cross-on")) {
					if(name == "d_type1"){
						var strUnit = "";
						var strUnitTitle = "강도";
						if(value == "RN"){
							strUnit = "(mm/h)";
						}else if(value == "SN"){
							strUnit = "(mm/h)";
						}else if(value == "CZ"){
							strUnit = "(dBZ)";
						}else if(value == "DZ"){
							strUnit = "(dBZ)";
						}else if(value == "VR"){
							strUnitTitle = "시선속도";	//oskim 20181015 ,
							strUnit = "(m/s)";
						}else if(value == "SW"){
							strUnit = "(m/s)";
						}else if(value == "DR"){
							strUnit = "(dB)";
						}else if(value == "RH"){
							strUnit = "";
						}else if(value == "PH"){
							strUnit = "(deg)";
						}else if(value == "KD"){
							strUnit = "(deg/km)";							
						}else{
							strUnit = "";
						}
						
						$("#dbzUnit").text(strUnitTitle + strUnit + " : ");
					}
                    //oskim 20180723 , 
                    if(name == "accum_time1"){
                    	var strUnitTitle = "강도";
                        var strUnit = "";
                        if(value == "10" || value == "60"){
                            strUnit = "(mm/h)";
                        }else{
                            strUnit = "";
                        }

						$("#dbzUnit").text(strUnitTitle + strUnit + " : ");
                    }					
				}
				
			} else if (optType == "checkbox") {
				// checkbox
				var checkQuery = "";
				var checkLen = chkOpt.eq(i).parent().children(".checkbox").length;
				var checkTmp = 0;
				var checkVal = "";
				chkOpt.eq(i).parent().children(".checkbox").each(function() {
					checkTmp++;
					name = $(this).children().children().attr("name");

					if ($(this).children().children().prop("checked"))
						value = "1";
					else
						value = "0";
					
					/* 바람장표시 선택시 바람장고도 파라미터 추가를 조건처리
					   (CGI에서는 파라미터가 없는경우 default = 1로 처리함)
					*/
					/*차후 반영을 위한 임시주석
					*/
					
					if (name.substring(0, name.length - 1) == "v_wind"){
						if(value == "1"){
							checkQuery +=  "WIND_ALT=" + $("#wind_alt").val() + "&"
						}
					}
					
					// 대기수상체 옵션 선택시에만 적용 ex)HC_OPTION=0000010
                    // oskim 20180823 ,
                    /*   
                    if (name.substring(0, name.length - 1) == "hc_option14" || name.substring(0, name.length - 1) == "hc_option7") {
                        var atomId = $(this).children().children().attr("id");
                        if(atomId.substring(0, atomId.length - 1) != "hc_option7_0" && atomId.substring(0, atomId.length - 1) != "hc_option14_0"){
                            checkVal += value;
                        }
                    }*/
                    if (name.substring(0, name.length - 1) == "hc_option") {
                        var atomId = $(this).children().children().attr("id");
                        if(atomId.substring(0, atomId.length - 1) != "hc_option_0"){
                            checkVal += value;
                        }
                    }

                    //if (name.substring(0, name.length - 1) == "hc_option14" || name.substring(0, name.length - 1) == "hc_option7") {
                    //  if (checkLen == checkTmp)
                    //      checkQuery += name.substring(0,name.length - 1).toUpperCase()+ "=" + checkVal + "&";
                    if (name.substring(0, name.length - 1) == "hc_option") {
                        if (checkLen == checkTmp)
                            checkQuery += name.substring(0,name.length - 1).toUpperCase()+ "=" + checkVal + "&"; 
                    } else {
                        checkQuery += name.substring(0,name.length - 1).toUpperCase()+ "=" + value.toUpperCase() + "&"; 
                    } 

				});
			} else if (optType == "select") {
				// selectbox
				name = chkOpt.eq(i).next().children("select").attr("name");
				value = $("select[name='" + name + "']").val();
			} else if (optType == "text") {
				// text
				var textQuery = "";
				chkOpt.eq(i).parent().children(".text").each(function() {
					name = $(this).attr("name");
					value = $(this).html();
					textQuery += name.substring(5, name.length - 1).toUpperCase()+ "=" + value.toUpperCase().substring(5,value.length) + "&";
				});

			}
			if (i == 0) {
				if(checkCnt > 0 )
					param+="|";
					param += $("#imgHeader").val() + "/" + CGIIMG[value] + "&"; //서버
					checkCnt++;

					resultValueTmp = value;
					
				if (tabType == "site")
					param += "SITE_NAME=" + $("[name=site]:checked").val() + "&";

				if (value == "COMP_DEP3_LGT_AREA") {
					var intv = $("[name=lgt_intv3]").val();
					var dateTmp = getDateFormatTime($("#dateTime").val());
					dateTmp = dateTmp.getTime() - Number(intv) * 60 * 1000 * 6;
					lgtStDate = getDateToStr(dateTmp);
				}

			} else if(i < 3 && $("#tabType").val() != "rainfall"){
				
			} else{
				if (optType == "checkbox")
					param += checkQuery;
				else if (optType == "text")
					param += textQuery;
				else if (optType == "link") {
					param += "POINT_RAIN=0&";
				} else
					param += name.substring(0, name.length - 1).toUpperCase() + "="	+ value.toUpperCase() + "&";	
			}
		};
	});
	
	// 좌상우하 위경도 좌표
	var extentVal = extent();
	var extent1 = new Proj4js.Point(extentVal[0], extentVal[3]);
	var extent2 = new Proj4js.Point(extentVal[2], extentVal[1]);
	
	Proj4js.transform(EPSG_222222, EPSG_4326, extent1);
	Proj4js.transform(EPSG_222222, EPSG_4326, extent2);
	
	var coordX = extent1.x;
	var coordY = extent1.y;
	var coordMX = extent2.x;
	var coordMY = extent2.y;

	// GIS 사이즈
	var mapSize = cfGetMapSize();
	var gis_width = mapSize[0];
	var gis_height = mapSize[1];

	// GIS 가로 세로 길이
	var point = extent();
	
   if(param == "") //oskim 20181018 ,
      return;
	
	var paramList = param.split("|");

	//oskim 20181018 , 20181023 , 합성탭 체크항목이 2개 이상이고, 마지막 항목에 '위성'이 있으면 맨 앞으로 이동한다 (강수->바람->낙뢰->위성 고정, 하드코딩)
	if (    (tabType == "comp" && paramList.length > 1 && $("#top4").is(":checked"))
            ||(tabType == "site" && paramList.length > 1 && $("#top2").is(":checked"))
       )
	{
		var sattlite = paramList[paramList.length-1];

		for (var i = paramList.length-2; i >= 0; i--)
			paramList[i+1] = paramList[i];

		paramList[0] = sattlite;
	}

	var findLGTT = "LGTTIME"; // 낙뢰 : 시간순
	var findLGTI = "LGTINTN"; // 낙뢰 : 강도순
	var findLGTA = "LGTAREA"; // 낙뢰 : 위치기반
	var legendArr =""; //범례 
	var hidLegendArr = ""; // 20181120 khr -  범례 url (이미지다운로드를위해) 
	//현재시간 이후 강수예측 자료표출 (합성일경우에만)
    var dateBase = getDateFormatTime($("#dateTimeReal").val());
    var dateFore = getDateFormatTime(date);

    var minDiff = (dateFore - dateBase)/(1000*60);
    if(minDiff > 360) minDiff = 360;    //max min

	//if(!getTimeChk(date)){
    //oskim 20181018 ,
	if($("#top1").is(":checked") && minDiff > 0){
		if(tabType == "comp" || tabType == "rainfall"){ //oskim 20180809
			// paramList값 삭제
			paramList.splice(0);

            //강수예측자료는 maple  //oskim 20180809
            var pType = $("input[name='P_TYPE1']:checked").val();       

            var mapleUrl = "";

            //oskim 20181213 
            if(pType == "COMP_DEP1_REAL" ||pType == "COMP_DEP1_CAPPI_500M" ||pType == "COMP_DEP1_REAL_500M" || pType == "MAPLE_HSR")
            {
                var accumParam = "";
                if( $("input[name='accum_time1']:checked").val() == 60)		//oskim 20180823
                	accumParam = "&ACCUM_TIME=60";
                            	
                mapleUrl = $("#imgHeader").val() + "/" + CGIIMG["MAPLE_HSR"] + accumParam + "&D_TYPE=RN&IS_SMOOTH=1&FCST_TIME=0&CONTOUR_DISP=0&FORE_GUIDE=0&TITAN_DISP=0&CUR_DATE=" + getDataConversion2($("#dateTimeReal").val()) + "&";
            }    
            else if(pType == "MAPLE_LGT_HSR")
            {
                var lgtType = $("input[name='fcst_lgt_type1']:checked").val();
                mapleUrl = $("#imgHeader").val() + "/" + CGIIMG[pType] + "&FCST_TIME=" + minDiff + "&FCST_LGT_TYPE=" + lgtType + "&";
            }
            else if(pType == "KONOS")
            {
                mapleUrl = $("#imgHeader").val() + "/" + CGIIMG[pType] + "&FCST_TIME=" + minDiff + "&D_TYPE=RN&IS_SMOOTH=1&CONTOUR_DISP=0&FORE_GUIDE=0&TITAN_DISP=0&";
            }
            else
                mapleUrl = "";

			paramList.push(mapleUrl);
		}
	}
	
	gCheckCnt = paramList.length;	//oskim 20171012

	for (var i = 0; i < paramList.length; i++) {
		if (paramList[i].indexOf(findLGTT) != -1 || paramList[i].indexOf(findLGTI) != -1) {
			paramList[i] += "LGT_ED_TIME=" + date;
		} else if (paramList[i].indexOf(findLGTA) != -1) {
			paramList[i] += "LGT_ST_TIME=" + lgtStDate;
			paramList[i] += "&LGT_ED_TIME=" + date;
		} else {
			paramList[i] += "DATE=" + date;		
		}
		paramList[i] += "&LU_LON=" + coordX;
		paramList[i] += "&LU_LAT=" + coordY;
		paramList[i] += "&RL_LON=" + coordMX;
		paramList[i] += "&RL_LAT=" + coordMY;
		paramList[i] += "&IMG_XDIM=" + gis_width;
		paramList[i] += "&IMG_YDIM=" + gis_height;
		//paramList[i] += "&CROSSDIST=" + result;
		
		paramList[i] += "&X_DIST=" + (point[2] - point[0]);
		paramList[i] += "&Y_DIST=" + (point[3] - point[1]);
		legend[i] = paramList[i] + "&UNIT_BAR=1";

		paramList[i] += "&UNIT_BAR=0"; // 범례 구분 (0: cgi/ 1: 범례)
		// paramList[i] += "MAP_LEVEL=0&";
		url[i] = paramList[i];
		
		//if(url[i].substring(9, 19) == "radar_comp" || url[i].substring(9, 19) == "radar_site") {
		if(url[i].indexOf("radar_comp") > -1 || url[i].indexOf("radar_site") > -1){ //khr 2018
			$("#dbz_cgi").val(url[i]);
		}
		
		/*$.ajax({
			url : "/cmmn/cgiExeFileCheck.do",
			type : "POST",
			dataType : "json",
			async: false,
			data : {
				cgi_url : url[i]
			},
			success : function(data) {*/
				
				var inner = "";
				var hidInner = "";
				//if(data.result == "200") {					
					// createBitmapdata를 통해 이미지 생성되는데 일정 시간이 필요함.
					// 생성이후 addBitmap으로 이미지를 올리기 전에 약간의 텀을 두어야 한다.
					
					// 범례 지정
					//사이트VAD, 합성 문숫자 시 범례 호출안함, 해당 cgi삭제
					var cgiName = //legend[i].split("?")[0].split("/")[4] + "?";		//oskim 20171012 , 운용서버는 [2], 테스트는 [4]
								"";
					var cgiNameTmp = legend[i].split("?")[0];
					cgiName = cgiNameTmp.substring(cgiNameTmp.lastIndexOf("/")+1, cgiNameTmp.length) + "?"; //20181120 khr cgiName받기
					
					if(cgiName.indexOf("undefined") < 0){
						//위험기상경보 체크시
						if(url[i].match("TITAN_DISP=1")) {
							getGisTitCgi(url[i], i, extentVal);
							clearInt = setInterval("getRiskGisInterval()", 500);  
							
							//oskim 20180706 , clear other parameter option!
							var rsk= url[i].replace("TITAN_DISP=1","TITAN_DISP=0");
							rsk= rsk.replace("CONTOUR_DISP=1","CONTOUR_DISP=0");
							rsk= rsk.replace("FORE_GUIDE=1","FORE_GUIDE=0");
							
							getGisCgi(rsk, i, extentVal);
						} else {	
							map.removeLayer(cgiTitImageLayer);
							getGisCgi(url[i], i, extentVal);
							
						}
						
            			//oskim 20181016 , 20190328
						if(cgiName != 'radar_multi_wind_pending?' && cgiName != 'radar_comp_gis_satellite?'){ // 다중바람장의 경우 범례를 표출하지 않는다.//사이트VAD, 합성 문숫자
							var height = Number($("#legend").css("height").replace("px", ""));
							if (tabType == "site")
								height += 8;
							else
								height += 3;
							
							//oskim 20171012 - start
							gLegendUrl[i] = legend[i];						
							
							/*if(gLegendBase64[i] == "" || $("#top3").prop("checked")){				//oskim 20171204 낙뢰메뉴선택 시에 기존처럼 깜빡이게...(시간업데이트 해야하므로)				
								updateLegendBarImg();	//첫 화면에서는 이미지 로딩이 늦어, 직접 메모리 로딩 걸어놓고 cgi 이미지로 렌더링
								inner = '<img id="legendImg_' + i + '"style="width:43px;height:' + height + 'px;" src="'+ legend[i] + '">';
							}else{
								//두번째 이후로는 메모리 이미지 사용
								inner = '<img id="legendImg_' + i + '"style="width:43px;height:' + height + 'px;" src="'+ gLegendBase64[i] + '">';								
							}*/
							//oskim 20171012 - end
							
							// 20181207 khr
							if($("#ani_play").val() == "on"){
								if(gLegendBase64[i] == "" || $("#top3").prop("checked")){				//oskim 20171204 낙뢰메뉴선택 시에 기존처럼 깜빡이게...(시간업데이트 해야하므로)				
									updateLegendBarImg();	//첫 화면에서는 이미지 로딩이 늦어, 직접 메모리 로딩 걸어놓고 cgi 이미지로 렌더링
									inner = '<img id="legendImg_' + i + '"style="width:43px;height:' + height + 'px;" src="'+ legend[i] + '">';
								}else{
									//두번째 이후로는 메모리 이미지 사용
									inner = '<img id="legendImg_' + i + '"style="width:43px;height:' + height + 'px;" src="'+ gLegendBase64[i] + '">';								
								}
							}else{
								inner = '<img id="legendImg_' + i + '"style="width:43px;height:' + height + 'px;" src="'+ legend[i] + '">';
							}
							
							// 
							
							hidInner = '<input type="hidden" name="hidLegendImg" id="hidLegendVal_'+i+'" value="'+legend[i]+'">';
							hidLegendArr += hidInner;
							
							legendArr += inner;							
						}
						
					}else{
						if (value != "SITE_DEP2_VAD" && value != "COMP_DEP2_VAD" && value != "COMP_DEP2_WIND_VAD"){		//oskim 20180110, 20180118(미적용)	연직시계열 일때, GIS화면 지우지 않는다
							removeGisCgi();			
						}
					}

			/*		}
			},
			error : function() {
			},
			complete :function(){
			}
		});	*/
	}
	
	legendSort(legendArr);
	hidLegend(hidLegendArr);
	visibleAWS();
	visibleAir();
	
}

//oskim 20171012 - start
//javasrcipt용 Sleep함수
function wait(msecs)
{
	var start = new Date().getTime();
	var cur = start;
	while(cur - start < msecs)
	{
		cur = new Date().getTime();
	}
}

//cgi 이미지를 base64 데이터로 변환 (canvas.toDataURL 사용못함 -> Security Error 때문)
function loadImage(url, callback) {
    var req = new XMLHttpRequest();
    req.open ("GET", url, true);
    req.responseType    = "blob";
    req.onreadystatechange = function (aEvt) {
      if (req.readyState == 4) {
        if (req.status === 200) {
            var blob = req.response;
            var reader = new FileReader();
            reader.onload = function(e) {
                var img = new Image();
                img.src = reader.result;
                var varImages = //img.href;
                	img.src;
                callback(varImages);
            }           
            reader.readAsDataURL(blob);
        }
      }
    };
    req.send(null);
}
//oskim 20171012 - end

//범례 순서 
function legendSort(legendArr){
	$("#legend").children().remove();
	$("#legend").append(legendArr);
}

//범례 url
function hidLegend(hidLegendArr){
	$("#hidLegend").children().remove();
	$("#hidLegend").append(hidLegendArr);
}

var term = 0;
function getRiskGisInterval(){
	term++;
	if(term % 2 == 0){
		cgiTitImageLayer.setVisible(false);
	}else{
		cgiTitImageLayer.setVisible(true);
	}
}

//20181212 khr
var cgiAniDataLayer0 = new Array();
var cgiAniDataLayer1 = new Array();
var cgiAniDataLayer2 = new Array();
var cgiAniDataLayer3 = new Array();
function getGisCgi(cgiUrl, i, extent){
	
	/*if($("#top1").is(":checked")){
		$("#echoCgiName").val($("input[name='P_TYPE1']:checked").val());
	}
	
	cgiImageLayer[i].setSource(new ol.source.ImageStatic({
		url: cgiUrl,
	    crossOrigin: 'anonymous',
	    projection: 'EPSG:222222',
	    imageExtent: extent
	}));
	
	cgiImageLayer[i].setVisible(true);*/

	//20181212 khr
	if($("#top1").is(":checked")){
		$("#echoCgiName").val($("input[name='P_TYPE1']:checked").val());
	}
	if($("#ani_play").val() == "off"){
		cgiImageLayer[i].setSource(new ol.source.ImageStatic({
			url: cgiUrl,
		    crossOrigin: 'anonymous',
		    projection: 'EPSG:222222',
		    imageExtent: extent,
		    attributions: cgiUrl
		}));
		cgiImageLayer[i].setVisible(true);
		cgiImageLayer[i].setOpacity(1);
		
		for (var j = 0; j < 4; j++) {
			for(var k = 0; k<eval("cgiAniDataLayer" + j).length ; k++){
				eval("cgiAniDataLayer" + j)[k].setOpacity(0);
			}
		}
	}else{
		var aniDateTime1 = "";
		var aniDataUrl = "";
		var aniDataCgiUrl = "";
		var tmp = 0;
		var aniNow = $(".ani-currnt").parent().attr("title");
		var pType = $("input[name='P_TYPE1']:checked").val();
		
		if(now < (end-1)){
			tmp = 3;
		}else if(now == (end-1)){
			tmp = 2;
		}else if(now == end){
			tmp = 0;
		}
		
		for (var j = 0; j < tmp; j++) {
			aniDateTime1 = $("#aniImg_" + (now + j)).attr("title");
			aniDataUrl = eval("cgiAniDataLayer"+i+"[" + (now + j) + "]").getSource().getAttributions();
			
			if(Number(aniDateTime1) > Number(aniNow)){

	                   

	            var mapleUrl = "";
 
	            if(pType == "COMP_DEP1_REAL" ||pType == "COMP_DEP1_CAPPI_500M" ||pType == "COMP_DEP1_REAL_500M" || pType == "MAPLE_HSR")
	            {
	            	
	                var accumParam = "";
	                if( $("input[name='accum_time1']:checked").val() == 60)		//oskim 20180823
	                	accumParam = "&ACCUM_TIME=60";
	                            	
	                mapleUrl = $("#imgHeader").val() + "/" + CGIIMG["MAPLE_HSR"] + accumParam + "&D_TYPE=RN&IS_SMOOTH=1&FCST_TIME=0&CONTOUR_DISP=0&FORE_GUIDE=0&TITAN_DISP=0&CUR_DATE=" +  getDataConversion2($("#dateTimeReal").val()) + "&";
	                mapleUrl += "DATE=" +  aniDateTime1;
	                
	                mapleUrl += cgiUrl.substr(cgiUrl.indexOf("&LU_LON"), cgiUrl.length);
	                
	                aniDataCgiUrl = mapleUrl;
	            }else{
	            	aniDataCgiUrl = "";
	            }	            
			}else{
				aniDataCgiUrl = cgiUrl.replace($("#aniImg_" + now).attr("title"), aniDateTime1);
			}
			
			if(aniDataUrl != aniDataCgiUrl){
				eval("cgiAniDataLayer"+i+"[" + (now + j) + "]").setSource(new ol.source.ImageStatic({
					url: aniDataCgiUrl,
				    crossOrigin: 'anonymous',
				    projection: 'EPSG:222222',
				    imageExtent: extent,
				    attributions: aniDataCgiUrl
				}));
			}
		}
		
		cgiImageLayer[i].setVisible(false);
		cgiImageLayer[i].setOpacity(0);

		for(var k = 0; k<eval("cgiAniDataLayer"+i).length ; k++){
			if(now == k){
				
				eval("cgiAniDataLayer"+i+"[" + k + "]").setOpacity(1);
			}else{
				eval("cgiAniDataLayer"+i+"[" + k + "]").setOpacity(0);
			}
		}
	}
	
}


function customLoader(tile, src) {
  var client = new XMLHttpRequest();
  client.open('GET', src);
  client.setRequestHeader('foo', 'bar');
  client.onload(function() {
    var data = 'data:image/png;base64,' + btoa(unescape(encodeURIComponent(this.responseText)));
    tile.getImage().src = data;
  });
  client.send();
}


function getGisTitCgi(cgiUrl, i, extent) {
	map.removeLayer(cgiTitImageLayer);
	cgiTitImageLayer = new ol.layer.Image({
		source: new ol.source.ImageStatic({
	        url: cgiUrl,
	        crossOrigin: 'anonymous',
	        projection: 'EPSG:222222',
	        imageExtent: extent
	    }),
	    opacity: 1
	});
	cgiTitImageLayer.setZIndex(ObjectIndex.TIT);
	map.addLayer(cgiTitImageLayer);
}

//CGI 레이어 제거
function removeGisCgi() {
	for(var i=0;i<cgiImageLayer.length;i++){
		cgiImageLayer[i].setVisible(false);
	}
}

// 지도의 좌상 우하 좌표를 반환한다.
function extent() {
	return map.getView().calculateExtent(cfGetMapSize());
};

var lineNumber = 0;
//연직단면 그리기
function crossPop() {
	cfSetMapDragActivity(false); //드레그 비활성화
	
	lineNumber++;
	if($("#top1").is(":checked")){
		$("#echoCgiName").val($("input[name='P_TYPE1']:checked").val());
	}
	
	var echoCgiName = $("#echoCgiName").val();
	
	
	if(echoCgiName.indexOf("ATOM") != -1){
	
		$("#lNum").val(lineNumber);
	
		removeCrossClickEvent();
		// 클릭 이벤트 바인딩		
		map.on('click', crossClick);
	
	}else if((echoCgiName.indexOf("VAD") != -1 || echoCgiName.indexOf("480KM") != -1) && $("#tabType").val() == "site"){
		alert("해당 산출물은 연직단면을 제공하지 않습니다. 사이트메뉴의 경우 480km, VAD 를 제외한 산출물에서만 연직단면이 제공됩니다.");
 		$("#cross_toggle").attr("class", "cross-off"); // 산출물 변경시 연직단면 토글버튼 초기화
		$("#cross_toggle").children("button").addClass("btn-default");
		$("#cross_toggle").children("button").removeClass("btn-warning");
    //oskim 20181219 , HSR cross Section, Add REAL
	}else if((echoCgiName.indexOf("REAL") == -1 && echoCgiName.indexOf("CAPPI") == -1 && echoCgiName.indexOf("PPI") == -1) && $("#tabType").val() != "site"){
		if($("#tabType").val() == "comp"){
			alert("해당 산출물은 연직단면을 제공하지 않습니다. 합성메뉴의 경우 HSR, PPI0, CAPPI(1.5km) 산출물에서만 연직단면이 제공됩니다.");
		}else{
			alert("강수예측은 연직단면을 제공하지 않습니다.");
		}		
 		$("#cross_toggle").attr("class", "cross-off"); // 산출물 변경시 연직단면 토글버튼 초기화
		$("#cross_toggle").children("button").addClass("btn-default");
		$("#cross_toggle").children("button").removeClass("btn-warning");
	}else{
		$("#lNum").val(lineNumber);
		removeCrossClickEvent();
		map.on('click', startPoint);
	}
}

// 20181120 khr 
/////////////////////////////
var pointMv0 = ["",""];		// lat, lon :: 중점
var pointMv240 = ["",""];	// lat, lon :: 경계점 (240km)
function crossClick(e){
	if(crossPopupWin.length == 0){
		pointNumber = 0;
	}
	pointNumber++;
	
	var point = new Proj4js.Point(e.coordinate);
	Proj4js.transform(EPSG_222222, EPSG_4326, point);
	
	$("#azimuth").val("-1"); // 마우스 클릭시 팝업으로 표출되는 연직단면의 방위각 값은 -1로 정의
	$("#crossLon").val(point.x);
	$("#crossLat").val(point.y);

	var p = $("[name=site]:checked").attr('title');
	pointMv0 = p.split("_");

	var brng = getBearing(pointMv0[1], pointMv0[0], point.x, point.y);
	var distance = (getATOMRange() + 5.0) * 1000; // convert km to meters

	pointMv240 = destinationPoint(pointMv0[1], pointMv0[0], distance, brng);

	
	var lineA = new Proj4js.Point([pointMv0[1], pointMv0[0]]);
	var lineB = new Proj4js.Point([pointMv240[1], pointMv240[0]]);
	Proj4js.transform(EPSG_4326, EPSG_222222, lineA);
	Proj4js.transform(EPSG_4326, EPSG_222222, lineB);
	
	var geojsonObject = {
			  'type': 'FeatureCollection',
			  'crs': {
			    'type': 'name',
			    'properties': {
			      'name': 'EPSG:222222'
			    }
			  },
			  'features': [
			    {
			      'type': 'Feature',
			      'geometry': {
			        'type': 'LineString',
			        'coordinates': [[lineA.x, lineA.y], [lineB.x, lineB.y]]
			      },
			      'properties': {
			            "lineNumber": lineNumber
			       }
			    }
			  ]
	};

	geojsonObject.features.push( {
	      'type': 'Feature',
	      'geometry': {
	        'type': 'Point',
	        'coordinates': [lineA.x, lineA.y]
	      },
	      'properties': {
            "label": 'A' + pointNumber,
            "pointNumber" : pointNumber
          }
	});
	geojsonObject.features.push( {
	      'type': 'Feature',
	      'geometry': {
	        'type': 'Point',
	        'coordinates': [lineB.x, lineB.y]
	      },
	      'properties': {
          "label": 'B' + pointNumber,
          "pointNumber" : pointNumber
        }
	});
	
	var styleFunction = function(feature, resolution, index) {
		return new ol.style.Style({
			fill: new ol.style.Fill({
				color: '#ff0000'
			}),
			stroke: new ol.style.Stroke({
				color: '#ff0000',
				width: 2
			}),
			text: new ol.style.Text({
		    	textAlign: 'center',
		        textBaseline: 'middle',
		        font: 'bold 15px Courier New',
		        text: feature.get('label'),
		        fill: new ol.style.Fill({color: '#000000'}),
		        offsetX: 0,
		        offsetY: -10,
		    })
		});
	};
	
	var vectorSource = new ol.source.Vector({
		features: (new ol.format.GeoJSON()).readFeatures(geojsonObject)
	});

	vectorCross  = new ol.layer.Vector({
		name : 'vectorCross',
		source: vectorSource,
		style: styleFunction
	});
		
	map.addLayer(vectorCross);
	
	vectorCross.setZIndex(ObjectIndex.DRAW);	//oskim 20181224 , set to ZIndex high
	
	$("#pNum").val(pointNumber);


	crossPopup();
}

// 대기수상체를 위한 레이더 거리 반환 : 지점별
function getATOMRange(){
	var site = $("input[name='site']:checked").val();

	switch (site) {
	case  'K03':	return 90;	break;
	case  'PSN':	return 240;	break;
	case  'KWK':	return 240;	break;
	case 'RKSG':	return 460;	break;
	case 'RKJK':	return 460;	break;
	case  'KAR':	return 240;	break;
	case  'JWN':	return 120;	break;
	case  'WNJ':	return 120;	break;
	case  'YCN':	return 120;	break;
	case  'SWN':	return 120;	break;
	case  'SAN':	return 120;	break;
	case  'SCN':	return 120;	break;
	case  'TAG':	return 120;	break;
	case  'KWJ':	return 120;	break;
	case  'KAN':	return 120;	break;
	case  'IMJ':	return 180;	break;
	case  'SBS':	return 150;	break;
	case  'SDS':	return 150;	break;
	case  'BSL':	return 150;	break;
	case  'MHS':	return 150;	break;
	case  'GRS':	return 150;	break;
	case  'JNI':	return 240;	break;
	case  'IIA':	return 140;	break;
	case  'YIT':	return 240;	break;
	case  'KSN':	return 240;	break;
	case  'SSP':	return 240;	break;
	case  'BRI':	return 240;	break;
	case  'MYN':	return 240;	break;
	case  'GSN':	return 240;	break;
	case  'GDK':	return 240;	break;
	case  'GNG':	return 280;	break;
	default:		return 240;	break;
	}
}
/////////////////////////////
// Bearing :: all degree values
function getBearing(lon1, lat1, lon2, lat2) {
	
	lon1 = toRad(lon1);
	lat1 = toRad(lat1);
	lon2 = toRad(lon2);
	lat2 = toRad(lat2);

	var y = Math.sin(lon2-lon1) * Math.cos(lat2);
	var x = Math.cos(lat1)*Math.sin(lat2) -
	        Math.sin(lat1)*Math.cos(lat2)*Math.cos(lon2-lon1);
	var brng = toDeg(Math.atan2(y, x));
	
	return brng;
}

// Destination point given distance and bearing from start point
function destinationPoint(lon, lat, distance, bearing) {
    var radius = Number(6378137);

    var delta = Number(distance) / radius; // angular distance in radians
    var theta = toRad(Number(bearing));

    var lat1 = toRad(lat);
    var lon1 = toRad(lon);

    var sinlat2 = Math.sin(lat1)*Math.cos(delta) + Math.cos(lat1)*Math.sin(delta)*Math.cos(theta);
    var lat2 = Math.asin(sinlat2);
    var y = Math.sin(theta) * Math.sin(delta) * Math.cos(lat1);
    var x = Math.cos(delta) - Math.sin(lat1) * sinlat2;
    var lon2 = lon1 + Math.atan2(y, x);

    return [toDeg(lat2), (toDeg(lon2)+540)%360-180]; // normalise to −180..+180°
};

function toRad(deg){
	return (deg * Math.PI / 180);
}

function toDeg(rad){
	return (rad * 180 / Math.PI);
}

function removeCrossClickEvent(){
	map.un('click', crossClick);
	map.un('click', startPoint);
	map.un('pointermove', movePoint);
	map.un('click', endPoint);
}

function focusOnOff(type, onOff){
	if(onOff == "on"){
		$("#" + type + "Val").val("");
	}
	if($("#" + type + "Val").val() == "" && onOff == "off"){
		if(type == "azimuth") $("#azimuthVal").val("방위각");
		if(type == "startDist") $("#startDistVal").val("거리");
		if(type == "endDist") $("#endDistVal").val("거리");
	}
}


// +버튼클릭시 지도확대/슬라이더증가
function setPlusZoom() {
	var zoom = cfGetZoom();
	if (zoom < 24) {
		if(!$("#fore_guide1").prop("checked") && !$("#contour_disp1").prop("checked")){
			zoom += 1;
			cfSetZoom(zoom);
			$("#zoomLvl").val(zoom);
			$("#flat-slider-vertical-1").slider("value", zoom);
		}
	}
}
// -버튼클릭시 지도축소/슬라이더감소
function setMinusZoom() {
	var zoom = cfGetZoom();
	if (zoom > -1) {
		if(!$("#fore_guide1").prop("checked") && !$("#contour_disp1").prop("checked")){
			zoom -= 1;
			cfSetZoom(zoom);
			$("#zoomLvl").val(zoom);
			$("#flat-slider-vertical-1").slider("value", zoom);
		}
	}

}

var crossLineFlag = false;
var pointA = ["",""];
var pointB = ["",""];
// 선그리기시 마우스 커서가 시작하는 지점 정보를 반환한다.
function startPoint(e) {
	if (!crossLineFlag) {
		// 클릭한 위치의 위경도값 호출
		var sPoint = drawLine(e);
		$("#startPointX").val(sPoint.x);
		$("#startPointY").val(sPoint.y);
		pointA = [sPoint.x, sPoint.y];
		
		// 거리재기 기능 제거 
		map.removeInteraction(draw);
		map.un('pointermove', pointerMoveHandler);
	    map.un('singleclick', pointerSingleHandler);
	    
	    //	
		map.un('click', startPoint);
		map.on('pointermove', movePoint);
		map.on('click', endPoint);
		
		
		drawCrossLayer.setVisible(true);
		
		crossLineFlag = true;
	}
} 
//선그리기시 마우스 커서가 움직인 지점 정보를 반환한다.
var vectorCross;
function movePoint(e) {
	// 이동중인 위치의 위경도값 호출
	var movePoint = drawLine(e);
	pointB = [movePoint.x, movePoint.y];
	
	var lineA = new Proj4js.Point(pointA)
	var lineB = new Proj4js.Point(pointB)
	Proj4js.transform(EPSG_4326, EPSG_222222, lineA);
	Proj4js.transform(EPSG_4326, EPSG_222222, lineB);
	if ( crossLineFlag ) {
		var geojsonObject = {
				  'type': 'FeatureCollection',
				  'crs': {
				    'type': 'name',
				    'properties': {
				      'name': 'EPSG:222222'
				    }
				  },
				  'features': [
				    {
				      'type': 'Feature',
				      'geometry': {
				        'type': 'LineString',
				        'coordinates': [[lineA.x, lineA.y], [lineB.x, lineB.y]]
				      },
				      'properties': {
				            "lineNumber": lineNumber
				       }
				    }
				  ]
		};
		
		var vectorSource = new ol.source.Vector({
			features: (new ol.format.GeoJSON()).readFeatures(geojsonObject)
		});
		
		drawCrossLayer.setSource(vectorSource); // 움직인 위치에 맞는 '선'으로 변경
	}
}

// 선그리기시 마우스 커서가 끝나는 지점 정보를 반환한다.
var sourceOb;
var pointNumber = 0;
var crossPopupWin = [];
var tmpPopupWin = [];
function endPoint() {
	map.un('pointermove', movePoint);
	map.un('click', endPoint);
	
	if(crossPopupWin.length == 0){
		pointNumber = 0;
	}
	pointNumber++;

	var st_x, st_y, ed_x, ed_y;
	//if(pointA[0] > pointB[0]){
	//	st_x = pointB[0]; st_y = pointB[1];
	//	ed_x = pointA[0]; ed_y = pointA[1];
	//}else{
		st_x = pointA[0]; st_y = pointA[1];
		ed_x = pointB[0];ed_y = pointB[1];

	//}

	$("#startPointX").val(pointA[0]);
	$("#startPointY").val(pointA[1]);
	$("#endPointX").val(pointB[0]);
	$("#endPointY").val(pointB[1]);
	$("#pNum").val(pointNumber);
	
	var lineA = new Proj4js.Point([st_x, st_y])
	var lineB = new Proj4js.Point([ed_x, ed_y])
	Proj4js.transform(EPSG_4326, EPSG_222222, lineA);
	Proj4js.transform(EPSG_4326, EPSG_222222, lineB);
	
	var geojsonObject = {
			  'type': 'FeatureCollection',
			  'crs': {
			    'type': 'name',
			    'properties': {
			      'name': 'EPSG:222222'
			    }
			  },
			  'features': [
			    {
			      'type': 'Feature',
			      'geometry': {
			        'type': 'LineString',
			        'coordinates': [[lineA.x, lineA.y], [lineB.x, lineB.y]]
			      },
			      'properties': {
			            "pointNumber": pointNumber
			       } 
			    }
			  ]
	};

	geojsonObject.features.push( {
	      'type': 'Feature',
	      'geometry': {
	        'type': 'Point',
	        'coordinates': [lineA.x, lineA.y]
	      },
	      'properties': {
            "label": 'A' + pointNumber,
            "pointNumber": pointNumber
          }
	});
	geojsonObject.features.push( {
	      'type': 'Feature',
	      'geometry': {
	        'type': 'Point',
	        'coordinates': [lineB.x, lineB.y]
	      },
	      'properties': {
          "label": 'B' + pointNumber,
          "pointNumber": pointNumber
        }
	});
	
	var styleFunction = function(feature, resolution, index) {
		return new ol.style.Style({
			fill: new ol.style.Fill({
				color: '#ff0000'
			}),
			stroke: new ol.style.Stroke({
				color: '#ff0000',
				width: 2
			}),
			text: new ol.style.Text({
		    	textAlign: 'center',
		        textBaseline: 'middle',
		        font: 'bold 15px Courier New',
		        text: feature.get('label'),
		        fill: new ol.style.Fill({color: '#000000'}),
		        offsetX: 0,
		        offsetY: -10,
		    })
		});
	};
	
	sourceOb = new ol.source.Vector({
		features: (new ol.format.GeoJSON()).readFeatures(geojsonObject)
	});
	
	vectorCross  = new ol.layer.Vector({
		name : 'vectorCross',
		source: sourceOb,
		style: styleFunction
	});
		
	map.addLayer(vectorCross);
	
	vectorCross.setZIndex(ObjectIndex.DRAW);	//oskim 20181224 , set to ZIndex high
	
	crossLineFlag = false;
	crossPopup();

}

function crossPopup(){
	
	$("#date").val($("#dateTime").val());
	
	var dTypeList = "";
	var list = $("input[name='d_type1']");
	for(var i=0;i<list.length;i++){
		dTypeList += list[i].value;
		if(i != list.length-1){
			dTypeList += ",";
		}
	}
	$("#dTypeList").val(dTypeList);
	
	var pType = $("input[name='P_TYPE1']:checked").val();
	$("#pType").val(pType);
	
    //oskim 20181219 , HSR cross Section , set to default QCD
    //$("#qType").val($("input[name='q_type1']:checked").val());
    var qType = $("input[name='q_type1']:checked").val();
    if(typeof qType == "undefined"){
        qType = "QCD";
    }
    $("#qType").val(qType);

	var dType = $("input[name='d_type1']:checked").val();
	if(typeof dType == "undefined"){
		dType = "";
	}
	$("#dType").val(dType);
	$("#tType").val($("#optTableAll ul .active a").attr("id").toUpperCase());
	$("#siteName").val($("input[name='site']:checked").val());

	if($("input[name='v_wind1']:checked").val() == "1"){
		$("#vWind").val("1");
	}else{
		$("#vWind").val("0");
	}

	if($("input[id='top2']").is(":checked")){
		$("#mWind").val("1");
	}else{
		$("#mWind").val("0");
	}
	
	var tabType = $("#tabType").val();
	var uiTime = "10";
	if( tabType == 'site' ) {
		uiTime = $("input[name='site']:checked").attr("sitetime");
	} else if ( tabType == 'comp' ) {
		uiTime = $("input:radio[name='P_TYPE1']:checked").attr("uitime");
	}

	if((uiTime == "") || (typeof uiTime == "undefined")){
		uiTime = "10";
	}
	$("#uiTime").val(uiTime);

	var winWidth = 810;
	var winHeight = 600;	//645;	//oskim 20180117
	var LeftPosition = (screen.width - winWidth) / 2;
	var TopPosition = (screen.height - winHeight) / 2;

	var d = new Date();
	var id = d.getYear() + '' + d.getMonth() + '' + d.getDate() + '' + d.getHours() + '' + d.getMinutes() + '' + d.getSeconds() + '' + d.getMilliseconds();
	var winId = 'onCrossPop' + id;
	
	var popup = window.open("", winId, 'scrollbars=yes,width='
			+ winWidth + ',height=' + winHeight + ',left=' + LeftPosition
			+ ',top=' + TopPosition
			+ ',menubar=no,status=no,resizable=yes,location=no');
	popup.focus();
	
	crossPopupWin.push(popup);
	tmpPopupWin.push(popup);
	
	$("#crossValue").attr({
		action : "/cmmn/crossPop.do",

		target : winId
	}).submit();
	
	crossPop();
}

function deleteCrossLine(){
	// 연직단면 삭제
	map.getLayers().forEach(function(el){
		if(el.get('name') == "vectorCross"){
			el.getSource().clear();
		}
	});
	
	drawCrossLayer.setVisible(false);
}

function closeCrossPopupWin(){
	pointNumber=0; //번로 리셋
	
	//팝업창 닫기
	for(var i=0; i < tmpPopupWin.length; i++){	  
	   var obj = tmpPopupWin[i];	   
	   if(typeof obj == "undefined"){
		   continue;
	   }
	   obj.close();	   
	}
	crossPopupWin = [];
}

// 20181120 khr
function deleteIndividualCrossLine(ln,pn,opener){

	map.getLayers().forEach(function(el){
		if(el.get('name') == "vectorCross"){
			var source = el.getSource();
			source.forEachFeature(function(feature){
				if(feature.get("pointNumber") == pn){
					source.clear();
				}
				
				if(feature.get("lineNumber") == ln){
					source.clear();
				}
			});
		}
	});
	
	crossPopupWin.splice(opener, 1);
}

function atomCrossPop(){
	var azimuth = $("#azimuthVal").val();
	var startDist = $("#startDistVal").val();
	var endDist = $("#endDistVal").val();
	var pattern = /[^0-9]/g;
	if(pattern.test(azimuth)){
		alert("방위각은 1부터 360까지의 숫자만 입력해주세요.");
		return;
	}else{
		if(Number(azimuth) < 1 || Number(azimuth) > 360){
			alert("방위각은 1부터 360까지의 숫자만 입력해주세요.");
			return;
		}
	}
	if(pattern.test(startDist)){
		alert("거리는 0부터 1200까지의 숫자만 입력해주세요.");
		return;	
	}else{
		if(Number(startDist) < 0 || Number(startDist) > 1200){
			alert("거리는 0부터 1200까지의 숫자만 입력해주세요.");
			return;			
		}
	}
	if(pattern.test(endDist)){
		alert("거리는 0부터 1200까지의 숫자만 입력해주세요.");
		return;
	}else{
		if(Number(endDist) < 0 || Number(endDist) > 1200){
			alert("거리는 0부터 1200까지의 숫자만 입력해주세요.");
			return;			
		}	
	}
	if(Number(startDist) > Number(endDist)){
		alert("시작거리가 종료거리보다 큽니다.");
		return;
	}
	$("#azimuth").val(azimuth);
	$("#startDist").val(startDist);
	$("#endDist").val(endDist);
	crossPopup();
}

// 선그리기
function drawLine(e) {
	var point = new Proj4js.Point(e.coordinate)
	Proj4js.transform(EPSG_222222, EPSG_4326, point);
	return point;
}

var linecnt = 0; // 거리측정 polyline의 갯수
// 거리측정 시작
function measure_init_distance() {
	if($("#measureBtn").parent().attr("class").indexOf("menu-open") > -1){
		deleteCrossLine();
		$("#cross_toggle").attr("class", "cross-off");
		$("#cross_toggle").children("button").removeClass("btn-warning");
		$("#cross_toggle").children("button").addClass("btn-default");
	// cfDeleteKGroup(IMXKey.MapObjectSpace, "Measure");
	MEASURE_CNT = 0;

		cfsetAllMapHandlerActivity(false); // 모든 이벤트 핸들러 비활성화
		map.addInteraction(wheelZoomEvent);	//oskim 20181226 , 거리측정시 휠확대축소 가능 처리 (현업자요청)
		
		// 그리기 이벤트 제거
		map.removeInteraction(draw);
		
		// 연직단면 이벤트 제거
		map.un('click', startPoint);
		map.un('pointermove', movePoint);
		map.un('click', endPoint);
		
		// 거리측정 이벤트 등록
		map.on('pointermove', pointerMoveHandler);
		map.on('singleclick', pointerSingleHandler);
		
		draw = new ol.interaction.Draw({
			source: source2,
			type: 'LineString',
			style: new ol.style.Style({
				fill: new ol.style.Fill({
					color: 'rgba(255, 255, 255, 0.2)'
				}),
				stroke: new ol.style.Stroke({
					color: 'rgba(0, 0, 0, 0.5)',
					width: 3
				}),
				image: new ol.style.Circle({
					radius: 5,
					stroke: new ol.style.Stroke({
						color: 'rgba(0, 0, 0, 0.7)'
					}),
					fill: new ol.style.Fill({
						color: 'rgba(255, 255, 255, 0.2)'
					})
				})
			}),
			maxPoints: 1
		});
		map.addInteraction(draw);
		
		createMeasureTooltip();	//oskim 20181226 , 그리기 기능 메뉴 선택시 createMeasureTooltip() 필요없음 -> pointerSingleHandler 이벤트에 호출 됨
		
		
		// 그리기 이벤트 등록
		draw.on('drawstart',
				function(evt) {
			// set sketch
			sketch = evt.feature;
		}, this);
		
		draw.on('drawend',
				function(evt) {
			measureTooltipElement.className = 'tooltip tooltip-static';
			measureTooltip.setOffset([0, -7]);
			// unset sketch
			sketch = null;
			// unset tooltip so that a new one can be created
			measureTooltipElement = null;
			createMeasureTooltip();
		}, this);
	}else{		
		map.removeInteraction(draw);
	}
}

//거리측정  삭제
function measure_remove_distance(){
	//map.removeInteraction(draw);
	vector2.getSource().clear();
	map.getOverlays().getArray().slice(0).forEach(function(overlay){
		map.removeOverlay(overlay);
	});
}
/**
 * format length output
 * @param {ol.geom.LineString} line
 * @return {string}
 */
var formatLength = function(line) {
  var length = Math.round(line.getLength() * 100) / 100;
  var output;
  if (length > 100) {
    output = (Math.round(length / 1000 * 100) / 100) +
        ' ' + 'km';
  } else {
    output = (Math.round(length * 100) / 100) +
        ' ' + 'm';
  }
  return output;
};

/**
 * Handle pointer move.
 * @param {ol.MapBrowserEvent} evt
 */
var sketch;
var continueLineMsg = 'Click to continue drawing the line';
var pointerMoveHandler = function(evt) {		 
  if (evt.dragging) {
    return;
  }
  /** @type {string} */
  var helpMsg = 'Click to start drawing';
  /** @type {ol.Coordinate|undefined} */
  var tooltipCoord = evt.coordinate;
 
  if (sketch) {
    var output;
    var geom = (sketch.getGeometry());
    if (geom instanceof ol.geom.LineString) {
      output = formatLength( /** @type {ol.geom.LineString} */ (geom));
      helpMsg = continueLineMsg;
      tooltipCoord = geom.getLastCoordinate();
    }
    measureTooltipElement.innerHTML = output;
    measureTooltip.setPosition(tooltipCoord);
    
  }
};

var pointerSingleHandler = function(evt){
	var tooltipCoord = evt.coordinate;
	 
  	if (sketch) {
	    var output;
	    var geom = (sketch.getGeometry());
	    if (geom instanceof ol.geom.LineString) {
	      output = formatLength( (geom));
	      helpMsg = continueLineMsg;
	      tooltipCoord = geom.getLastCoordinate();
	    }
	   
	    //createMeasureTooltip();	//oskim 20181226 , 첫포인트는 길이가 없고, 기존 툴팁삭제 후 재생성 필요 -> createMesureTooltip() 호출
	    measureTooltipElement = document.createElement('div');
  	  	measureTooltipElement.className = 'tooltip tooltip-measure';
  	    measureTooltipElement.innerHTML = output;
  	  	
  	  	measureTooltip = new ol.Overlay({
  	    	element: measureTooltipElement,
  	    	offset: [0, -7],
  	    	positioning: 'bottom-center'
  	    });
  	   
  	    map.addOverlay(measureTooltip);  
	}
}

//거리측정시 거리표출을 위한 tooltip div 생성
var measureTooltipElement;
var measureTooltip;
function createMeasureTooltip() {
  if (measureTooltipElement) {
    measureTooltipElement.parentNode.removeChild(measureTooltipElement);
  }
  measureTooltipElement = document.createElement('div');
  measureTooltipElement.className = 'tooltip tooltip-measure';
  measureTooltip = new ol.Overlay({
    element: measureTooltipElement,
    offset: [0, -7],
    positioning: 'bottom-center'
  });
  map.addOverlay(measureTooltip);
}
// 태풍 경계구역을 표시한다
function typhoon(){
	var typList = new Array();
	var typList2 = new Array();
	var typPointList = new Array();
	var tempList = [132, 48, 132, 28, 119, 28, 135, 48, 135, 25, 119, 25];
	
		
	for(var i=0;i<tempList.length;i=i+2){
		var transPoint = new Proj4js.Point(tempList[i], tempList[i+1]);
		Proj4js.transform(EPSG_4326, EPSG_222222, transPoint);
		if(i < 6){
			typList.push([transPoint.x, transPoint.y]);
		}else{
			typList2.push([transPoint.x, transPoint.y]);
		}
		
		
	}
	
	var styles = {
			  'typ': [new ol.style.Style({
			    stroke: new ol.style.Stroke({
			      color: 'red',
			      width: 3
			    })
			  })],
			  'typ_label1': [new ol.style.Style({
				  text: new ol.style.Text({
			          textAlign: 'center',
			          textBaseline: 'middle',
			          font: 'bold 20px Courier New',
			          text: '132°E',
			          fill: new ol.style.Fill({color: 'red'}),
			          offsetX: -10,
			          offsetY: -10
			      })			      
			  })],
			  'typ_label2': [new ol.style.Style({
				  text: new ol.style.Text({
			          textAlign: 'center',
			          textBaseline: 'middle',
			          font: 'bold 20px Courier New',
			          text: '28°N',
			          fill: new ol.style.Fill({color: 'red'}),
			          offsetX: -30,
			          offsetY: 0
			      })			      
			  })],
			  'typ_label3': [new ol.style.Style({
				  text: new ol.style.Text({
			          textAlign: 'center',
			          textBaseline: 'middle',
			          font: 'bold 20px Courier New',
			          text: '135°E',
			          fill: new ol.style.Fill({color: 'red'}),
			          offsetX: 10,
			          offsetY: -10
			      })			      
			  })],
			  'typ_label4': [new ol.style.Style({
				  text: new ol.style.Text({
			          textAlign: 'center',
			          textBaseline: 'middle',
			          font: 'bold 20px Courier New',
			          text: '25°N',
			          fill: new ol.style.Fill({color: 'red'}),
			          offsetX:-30,
			          offsetY: 0
			      })			      
			  })]
		};

		var styleFunction = function(feature, resolution) {
			return styles[feature.G.name];
		};


		var vectorSource = new ol.source.Vector({
			features: 
				[new ol.Feature({
					  name : "typ",
		              geometry: new ol.geom.LineString(typList)
		          }), 
		          new ol.Feature({
		        	  name : "typ",
		              geometry: new ol.geom.LineString(typList2)
		          }),
		          new ol.Feature({
		        	  name : "typ_label1",
		        	  geometry: new ol.geom.Point(typList[0])
		          }),
		          new ol.Feature({
		        	  name : "typ_label2",
		        	  geometry: new ol.geom.Point(typList[2])
		          }),
		          new ol.Feature({
		        	  name : "typ_label3",
		        	  geometry: new ol.geom.Point(typList2[0])
		          }),
		          new ol.Feature({
		        	  name : "typ_label4",
		        	  geometry: new ol.geom.Point(typList2[2])
		          })
		          ]
		});

		typLayer = new ol.layer.Vector({
			source: vectorSource,
			style: styleFunction
		});
			
		map.addLayer(typLayer);
		typLayer.setZIndex(ObjectIndex.TYP);
		
	
	
	
}

function getLineStylePosition(firstCoor, lastCoor, max)
{
    var deltaX = lastCoor[0] - firstCoor[0];
    var deltaY = lastCoor[1] - firstCoor[1];

    var rotation = Math.atan(deltaY/deltaX) * - 1;

    var offsetX = max * Math.cos(rotation) * (-1);
    var offsetY = max * Math.sin(rotation) * (-1);

    var textAlign = 'right';
    if(deltaX < 0)
    {
        offsetX *= -1;
        offsetY *= -1;
        textAlign = 'left';
    }

    return {
        rotation: rotation,
        textAlign: textAlign,
        offsetX: offsetX,
        offsetY: offsetY
    };
};  
// FIR 인천비행정보 구역을 표시한다.
function incheonFIR() {
	$.ajax({
		url : "/cmmn/incheonFIR.do",
		type : "POST",
		dataType : "json",
		success : function(data) {
			// FIR 외곽선
			var awsAreaList = new Array();
			var tempList = data.awsAreaList[data.awsAreaList.length - 1];
			for(var i=0;i<tempList.length;i=i+2){
				var transPoint = new Proj4js.Point(tempList[i], tempList[i+1]);
				Proj4js.transform(EPSG_4326, EPSG_222222, transPoint);
				awsAreaList.push([transPoint.x, transPoint.y]);
			}
			
			// FIR 내부선
			var awsPathList = new Array();
			for(var i=0;i<data.awsPathList.length;i++){
				var awsPathTempList = new Array();
				var tempList = data.awsPathList[i];
				for(var j=0;j<tempList.length;j=j+2){
					var transPoint = new Proj4js.Point(tempList[j], tempList[j+1]);
					Proj4js.transform(EPSG_4326, EPSG_222222, transPoint);
					awsPathTempList.push([transPoint.x, transPoint.y]);
				}
				awsPathList.push(awsPathTempList);
			}
			
			// FIR 내부점
			var awsPathPointList = new Array();
			var tempList = data.awsPathPointList[data.awsPathPointList.length - 1];
			for(var i=0;i<tempList.length;i=i+2){
				var transPoint = new Proj4js.Point(tempList[i], tempList[i+1]);
				Proj4js.transform(EPSG_4326, EPSG_222222, transPoint);
				awsPathPointList.push([transPoint.x, transPoint.y]);
			}

			var styles = {
					  'MultiLineString': [new ol.style.Style({
					    stroke: new ol.style.Stroke({
					      color: '#0000ff',
					      width: 1
					    })
					  })],
					  'MultiPoint': [new ol.style.Style({
					    image: new ol.style.RegularShape({ // 다각형 모양의 스타일
						      fill: new ol.style.Fill({color: '#0000ff'}),
						      stroke: new ol.style.Stroke({color: '#0000ff', width: 1}),
						      points: 4, 
						      radius: 3,
						      angle: Math.PI / 4
						    })
					  })],
					  'Polygon': [new ol.style.Style({
					    stroke: new ol.style.Stroke({
					      color: '#000000',
					      width: 3
					    })
					  })]
				};

				var styleFunction = function(feature, resolution) {
					return styles[feature.getGeometry().getType()];
				};

				var geojsonObject = {
					  'type': 'FeatureCollection',
					  'crs': {
					    'type': 'name',
					    'properties': {
					      'name': 'EPSG:222222'
					    }
					  },
					  'features': [
					    {
					      'type': 'Feature',
					      'geometry': {
					        'type': 'MultiPoint',
					        'coordinates': awsPathPointList
					      }
					    },
					    {
					      'type': 'Feature',
					      'geometry': {
					        'type': 'Polygon',
					        'coordinates': [awsAreaList]
					      }
					    },
					    {
					      'type': 'Feature',
					      'geometry': {
					        'type': 'MultiLineString',
					        'coordinates': awsPathList
					      }
					    }

					  ]
				};

				var vectorSource = new ol.source.Vector({
					features: (new ol.format.GeoJSON()).readFeatures(geojsonObject)
				});

				firLayer = new ol.layer.Vector({
					source: vectorSource,
					style: styleFunction
				});
					
				map.addLayer(firLayer);
				firLayer.setZIndex(ObjectIndex.FIR);
		},
		error : function() {
		}
	});

}

// 주요공항지점, AWS 지점 표시
function onPoint(type) {
	var pos_han = getPoshan();

	onPointAjax(type);
}

// 파일에서 데이터를 가져온 후 지도상에 표출한다.
function onPointAjax(type) {

	$.ajax({
		url : "/cmmn/getPositionAjax.do",
		type : "POST",
		dataType : "json",
		data : {
			type : type
		},
		success : function(data) {
			var name = String(data.name).split(",");
			var lat = String(data.lat).split(",");
			var lon = String(data.lon).split(",");
			var awsnum = String(data.awsnum).split(",");
			var awslev = String(data.awslev).split(",");
			var start = new Date().getSeconds() * 1000 + new Date().getMilliseconds();
			if(type == "Air"){
				var pointList = new Array();
				var labelList = new Array();
				
				for (var i = 0; i < data.name.length; i++) {
					var point = [lon[i], lat[i]];
					
					if (point != null) {
						pointList.push(point);
					}
					if (name[i] != null) {
						labelList.push(name[i]);
					}
				}
				
				var styleFunction = function(feature, resolution, index) {
					return new ol.style.Style({
					    image: new ol.style.Circle({ // 원 형태의 point
							  radius: 3,
							  fill: new ol.style.Fill({color: '#0000ff'}),
							  stroke: new ol.style.Stroke({color: '#000000', width: 1})
							}),
					    text: new ol.style.Text({
					          textAlign: 'center',
					          textBaseline: 'middle',
					          font: '15px Courier New',
					          text: feature.get('label'),
					          fill: new ol.style.Fill({color: '#ff0000'}),
					          offsetX: 0,
					          offsetY: -10
					      })
					  });
				};

				var geojsonObject = {
					  'type': 'FeatureCollection',
					  'crs': {
					    'type': 'name',
					    'properties': {
					      'name': 'EPSG:222222'
					    }
					  },
					  'features': []
				};
				
				for(var i=0;i<pointList.length;i++){
					var feature = {
						      'type': 'Feature',
						      'geometry': {
						        'type': 'Point',
						        'coordinates': pointList[i]
						      },
						      'properties': {
					            "label": labelList[i]
					          }
						    }
					geojsonObject.features.push(feature);
				}
				
				var vectorSource = new ol.source.Vector({
					features: (new ol.format.GeoJSON()).readFeatures(geojsonObject)
				});

				//vectorSource.addFeature(new ol.Feature(new ol.geom.Circle([5e6, 7e6], 1e6)));

				airLayer = new ol.layer.Vector({
					source: vectorSource,
					style: styleFunction
				});
				
				map.addLayer(airLayer);
				airLayer.setZIndex(ObjectIndex.AIR);
				
			}else if(type == "AWS"){
				for(var lev=1;lev<6;lev++){
					var pointList = new Array();
					var labelList = new Array();
					var awsnumList = new Array();
					for (var i = 0; i < data.name.length; i++) {
						if(Number(awslev[i]) == lev){
							var point = [lon[i], lat[i]];

							if (point != null) {
								pointList.push(point);
							}
							if (name[i] != null) {
								labelList.push(name[i]);
							}
							if(awsnum[i] != null){
								awsnumList.push(awsnum[i]);
							}
						}
					}
				
					var styleFunction = function(feature, resolution, index) {
						return new ol.style.Style({
						    image: new ol.style.Circle({ // 원 형태의 point
								  radius: 3,
								  fill: new ol.style.Fill({color: '#ff0000'}),
								  stroke: new ol.style.Stroke({color: '#000000', width: 1})
								}),
						    text: new ol.style.Text({
						          textAlign: 'center',
						          textBaseline: 'middle',
						          font: 'bold 15px Courier New',
						          text: feature.get('label'),
						          fill: new ol.style.Fill({color: '#000000'}),
						          //stroke: new ol.style.Stroke({color: '#000000', width: 1}),
						          offsetX: 0,
						          offsetY: -10,
						          //placement: 'point',
						          //maxAngle: maxAngle,
						          //overflow: overflow,
						          //rotation: 0
						      })
						  });
					};
	
					var geojsonObject = {
						  'type': 'FeatureCollection',
						  'crs': {
						    'type': 'name',
						    'properties': {
						      'name': 'EPSG:222222'
						    }
						  },
						  'features': []
					};
					
					for(var i=0;i<pointList.length;i++){
						var feature = {
							      'type': 'Feature',
							      'geometry': {
							        'type': 'Point',
							        'coordinates': pointList[i]
							      },
							      'properties': {
						            "label": labelList[i],
						            "name": awsnumList[i]
						          }
							    }
						geojsonObject.features.push(feature);
					}
					
					var vectorSource = new ol.source.Vector({
						features: (new ol.format.GeoJSON()).readFeatures(geojsonObject)
					});

					awsLayer[lev] = new ol.layer.Vector({
						source: vectorSource,
						style: styleFunction
					});

					map.addLayer(awsLayer[lev]);
					awsLayer[lev].setZIndex(ObjectIndex.AWS);
				}
			}
			if (type == "Air") {
				visibleAir();
			} else if (type == "AWS") {
				visibleAWS();
			}
			
		},
		error : function(request, status, error) {

		}
	});
}

// 지도 확대/축소 레벨에 따라 AWS지점 파일을 다르게 가져오기 위한 변수(pos_han) 설정
function getPoshan() {
	var pos_han = "";
	var zm_lvl = cfGetZoom();
	if (zm_lvl < 8) {
		pos_han = "0";
	} else if (8 <= zm_lvl && zm_lvl < 9) {
		pos_han = "1";
	} else if (9 <= zm_lvl && zm_lvl < 10) {
		pos_han = "2";
	} else if (10 <= zm_lvl && zm_lvl < 12) {
		pos_han = "3";
	} else if (12 <= zm_lvl && zm_lvl < 14) {
		pos_han = "4";
	} else if (14 <= zm_lvl && zm_lvl < 20) {
		pos_han = "5";
	} else {
		pos_han = "6";
	}
	return pos_han;
}
var zoomFlagAir = true;
// 주요항공지점에 대해 지도 확대/축소 레벨에 따라 표출, 미표출 여부를 결정
function visibleAir() {
	
	if(typeof(airLayer) != "undefined"){
		if(typeof obj != "undefined"){
			if(obj.event.customProperty.newZoom != obj.event.customProperty.oldZoom){
				if(zoomFlagAWS == true){
					// zoom 이벤트가 3번씩 적용되는 부분에서 1회에 한해 해당 로직을 수행
					var pos_han = getPoshan();
					
					if (pos_han == "6") {
						return;
					} else {
						if(pos_han == "0"){
							airLayer.setVisible(false);	
						}else{
							airLayer.setVisible(true);	
						}
					}
					zoomFlagAWS  = false;
				}else if(zoomFlagAWS == false){
					zoomFlagAWS  = true;
				}
			}
		}else{
			var pos_han = getPoshan();
			
			if (pos_han == "6") {
				return;
			} else {
				if(pos_han == "0"){
					airLayer.setVisible(false);	
				}else{
					airLayer.setVisible(true);	
				}
			}
		}
	}
}

var zoomFlagAWS = true;
// AWS 지점에 대해 지도 확대/축소 레벨에 따라 표출 여부 결정
function visibleAWS(obj) {
	if(typeof obj != "undefined"){
		if(obj.event.customProperty.newZoom != obj.event.customProperty.oldZoom){
			if(zoomFlagAWS == true){
				// zoom 이벤트가 3번씩 적용되는 부분에서 1회에 한해 해당 로직을 수행
				var pos_han = getPoshan();
				if (pos_han == "6") {
					return;
				} else {
					var bool = [];
					for(var i=1;i<6;i++){
						if(i <= pos_han) bool[i] = true;
						else bool[i] = false;
						if(typeof(awsLayer[i]) != "undefined"){
							awsLayer[i].setVisible(bool[i]);
						}
					}
				}
				zoomFlagAWS  = false;
			}else if(zoomFlagAWS == false){
				zoomFlagAWS  = true;
			}
		}
	}else{
		var pos_han = getPoshan();
		if (pos_han == "6") {
			return;
		} else {
			var bool = [];
			for(var i=1;i<6;i++){
				if(i <= pos_han) bool[i] = true;
				else bool[i] = false;
				if(typeof(awsLayer[i]) != "undefined"){
					awsLayer[i].setVisible(bool[i]);
				}
			}
		}
	}

}

// 주요항공지점, AWS 지점에 대한 각각의 Object 제거
// 바인딩된 이벤트도 제거한다.
function deletePoint(type) {
	if (type == "Air") {
		map.removeLayer(airLayer);
	}else if(type == "AWS"){
		for(var i=1;i<6;i++){
			map.removeLayer(awsLayer[i]);
		}
	}
}


//이미지 저장 함수
function save_evt_mClick(type) {
	html2canvas(
			//$("#map .ol-unselectable")[0]
			document.getElementById("gismap")
			, {
	    onrendered: function(canvas) {
	    	var img = new Image ();
	    	img.crossOrigin = "anonymous";
	    	img.src = canvas.toDataURL ("image/png");
		    var data = img.src;
		    var url = "/comp/imgDown.do";
		    var fileName = getTimeStamp("YYYYMMDDhhmmss") + ".png";
		    
		    $.ajax({ 
				url: url,
				data: {
					data : data,
					fileName : fileName
				}, 
				type: 'POST',
				success:function(data){
					if(data.result){
						save_evtResult_captureUpload(fileName, type);
					}else{
						save_evtError_captureUpload();
					}
				},  
				error:function(request,status,error){
					save_evtError_captureUpload();
				}
			});
	    }
	  });
};

// 이미지 저장 성공 시 다운로드 호출
/*
 * type : print 인쇄 로직 실행
 * 		: save 이미지 저장 로직 실행
 * 나중에 이미지 저장경로 수정 필요 !
 * (현재는 프로젝트 바로 밑에 저장된다 ~~/KRES/)
 * */
function save_evtResult_captureUpload(fileName, type) {
	var url = "";
	var target = "";
	var cgiUrl = "";
	$("[name=hidLegendImg]").each(function(){
		cgiUrl += $(this).val() +","; 
	});
	if(type =="print"){
		target = "popImgBranch";
		url = "/cmmn/popImgBranch.do";
		
		var winWidth = $("#gismap").width();
		var winHeight = $("#gismap").height();
		var LeftPosition = (screen.width - winWidth)/2;
		var TopPosition = (screen.height - winHeight) / 2;
		
		var popup = window.open('', 'popImgBranch', 'scrollbars=yes,width=' + winWidth 
				+ ',height=' +  winHeight + ',left=' + LeftPosition
				+ ',top=' + TopPosition
				+ ',menubar=no,status=no,resizable=yes,location=no');
	}
	
	if(type == "save"){
		target = "iframeDown";
		url = "/cmmn/download.do";
	}
	
	var input = document.createElement("input");
	input.type = "hidden";
	input.name = "fileName";
	input.value = fileName;
	
	var inputCgiUrl = document.createElement("input");
	inputCgiUrl.type = "hidden";
	inputCgiUrl.name = "cgiUrl";
	inputCgiUrl.value = cgiUrl;
	
	var form = document.createElement("form");
	form.name = "downForm";
	form.target = target;
	form.action = url;
	form.method = "post";
	form.style = "display:none;";
	form.appendChild(input);
	form.appendChild(inputCgiUrl);
	document.body.appendChild(form);
	form.submit();
	document.body.removeChild(form);

};

// 이미지 저장 실패
function save_evtError_captureUpload() {
	alert("이미지 생성에 실패하였습니다");
};

createBubble = function(feature) {
		deleteBubble();	

		var point = feature.geometry.A;
		var awsnum = feature.name;
		var ptype = $("[name=P_TYPE1]:checked").val();
		var qtype = $("[name=q_type1]:checked").val();
		var dateTime = getDataConversion();
		var result = true;
		if(typeof(qtype) == "undefined") qtype = "";
		
		/**
		 * 1. 강수 일때만 AWS차이 있음
		 * 2. 강수이지만 AWS차이 없을경우
		 * 	1) 산출물 : Vil, etop, 강수예측, 대기수상체, VAD
		 *  2) 품질관리 :CHAFFQC
		 */ 
		var ptypeList = ["VIL", "ETOP", "VSRF", "MAPLE", "KONOS", "ATOM7", "ATOM14", "VAD"];
		if($("#top1").prop("checked")){
			for (var i = 0; i < ptypeList.length; i++) {
				if(ptype.indexOf(ptypeList[i]) > -1){
					result = false;
				}
			}
			
			if(qtype.indexOf("CHAFFQC") > -1){
				result = false;
			}
		}else{
			result = false;
		}
		////////////////////////////////////////
		
		if(result){			
			$.ajax({
				url : "/cmmn/getAWSValue.do",
				type : "POST",
				dataType : "json",
				async: false,
				data : {
					awsnum : awsnum,
					siteName : $("[name=site]:checked").val(),
					ptype : ptype,
					qtype : $("[name=q_type1]:checked").val(),
					avg : $("[name=comp_method1]:checked").val(),
					dateTime : dateTime
				},
				success : function(data) {
					var text = "";
					var value = "";
					var height = 0;
					var marginX = 0;
					var marginY = 0;
					var width = 160;
					if($("#tabType").val() == "comp"){
						text = "AWS : \n레이더 : \nCZ : \nRH : ";
						height = 120; //80 //120  //oskim 20171214 AWS 풍선도움말 디자인 수정
						marginY = -140;
					}else{
						text = "AWS : \n레이더 : \nDR : \nPH : \nRH : \nKD : ";
						height = 160; //120 //160 //oskim 20171214
						marginY = -173;
					}
					
					// 파일에서 불러온 내용이 없을 경우 표출하지 않는다.
					if (data.awsResult != null) {
						var awsResult = data.awsResult.split(",");
						var awsValue = Number(awsResult[1]);
						var dbzValue = Number(awsResult[2]);
						var deviation = 0;
						
						if (dbzValue != -9999 && awsValue != -9999) {
							deviation = (awsValue - dbzValue);
						}
						if(dbzValue == -9999) dbzValue = "-";
						if(awsValue == -9999) awsValue = "-";
						for(var i=0;i<awsResult.length;i++){
							if(awsResult[i] == -9999) awsResult[i] = "-";
						}
					    //oskim 20171214 	
						if($("#tabType").val() == "comp"){
							value = awsValue + " mm/h\n" + dbzValue + " mm/h\n"
							+ awsResult[6] + " dBZ\n" + awsResult[10] + " \n";
						}else{
							value = awsValue + " mm/h\n" + dbzValue + " mm/h\n"
							+ awsResult[8] + " dB\n" + awsResult[9] + " deg.\n" + awsResult[10] + " \n" + awsResult[11] + " deg/km\n";
						}	
					}
					
					// AWS 지점 툴팁 박스 레이어 표출 (khr - 2018)
					////////////////////////////////////////////////////////////////////////////////////
					var tooltipBoxFeature = new ol.Feature({
						geometry: feature.geometry,
				        name: 'boxImage'
				      });

				      var tooltipBoxStyle = new ol.style.Style({
				        image: new ol.style.Icon({
				          anchor: [0.5, 1.0],
				          anchorXUnits: 'fraction',
				          anchorYUnits: 'fraction',
				          src: '/openlayer/images/map-tooltip.png',
				          opacity: 1,
				          size: [width, height] 
				        })
				      });

				      tooltipBoxFeature.setStyle(tooltipBoxStyle);

				      var tooltipBoxSource = new ol.source.Vector({
				        features: [tooltipBoxFeature]
				      });

				      tooltipBoxLayer = new ol.layer.Vector({
				        source: tooltipBoxSource
				      });
				      
				      map.addLayer(tooltipBoxLayer)
				      tooltipBoxLayer.setZIndex(ObjectIndex.AWSV);
					  //////////////////////////////////////////////////////////////////////////////////////				    
				      // AWS 지점 툴팁 텍스트(값) 레이어 표출
					  ////////////////////////////////////////////////////////////////////////////////////
				      var tooltipTextFeature = new ol.Feature({
						geometry: feature.geometry,
				        name: 'textArea'
				      });
				    
				      var tooltipValueFeature = new ol.Feature({
						geometry: feature.geometry,
				        name: 'valueArea'
				      });

				      var tooltipTextStyle = new ol.style.Style({
				        text: new ol.style.Text({
					          textAlign: 'left',
					          textBaseline: 'bottom',
					          font: 'normal 12px Courier New',
					          text: text,
					          fill: new ol.style.Fill({color: '#000000'}),
					          opacity: 1,
					          offsetX: marginX - 70,
					          offsetY: marginY + 60
					      })
				      });
				      
				      var tooltipValueStyle = new ol.style.Style({
					        text: new ol.style.Text({
						          textAlign: 'left',
						          textBaseline: 'bottom',
						          font: 'normal 12px Courier New',
						          text: value,
						          fill: new ol.style.Fill({color: '#000000'}),
						          opacity: 1,
						          offsetX: marginX - 15 ,
							      offsetY: marginY + 67
						    })
					  });
				      
				      tooltipTextFeature.setStyle(tooltipTextStyle);
				      tooltipValueFeature.setStyle(tooltipValueStyle);

				      var tooltipTextSource = new ol.source.Vector({
				        features: [tooltipTextFeature, tooltipValueFeature]
				      });

				      tooltipTextLayer = new ol.layer.Vector({
				        source: tooltipTextSource
				      });
				      
				    map.addLayer(tooltipTextLayer)
				    tooltipTextLayer.setZIndex(ObjectIndex.AWSV);
				    ////////////////////////////////////////////////////////////////////////////////////
				},
				error : function(request, status, error) {
						//alert("code:" + request.status + "\n" + "message:" + request.responseText + "\n" + "error:" + error);
				}
			});
		}
	
}

deleteBubble = function() {
	map.removeLayer(tooltipBoxLayer);
	map.removeLayer(tooltipTextLayer);	
}

/* GIS 도구 - 그리기 */
var draw;
function drawing(type) {
	if($("#drawBtn").parent().attr("class").indexOf("menu-open") != -1){
    	deleteCrossLine();
    	$("#cross_toggle").attr("class", "cross-off");
    	$("#cross_toggle").children("button").removeClass("btn-warning");
    	$("#cross_toggle").children("button").addClass("btn-default");
    	
    	// 거리재기 기능 제거
    	map.removeInteraction(draw);
    	map.un('pointermove', pointerMoveHandler);
        map.un('singleclick', pointerSingleHandler);

        // 연직단면 이벤트 제거
		map.un('click', startPoint);
		map.un('pointermove', movePoint);
		map.un('click', endPoint);
		
		//oskim 20190623 ,
		 
/*		var styleFunction = function (feature) { 
		    var geometry = feature.getGeometry(); 
		    var styles = [ 
		     // linestring 
		     new ol.style.Style({ 
		      stroke: new ol.style.Stroke({ 
		       color: '#ffcc33', 
		       width: 2 
		      }) 
		     }) 
		    ];
		    
	    	geometry.forEachSegment(function (start, end) {
	    		
			     var dx = end[0] - start[0]; 
			     var dy = end[1] - start[1]; 
			     var rotation = Math.atan2(dy, dx); 
			 
			     var lineStr1 = new ol.geom.LineString([end, [end[0] - 200000, end[1] + 200000]]); 
			     lineStr1.rotate(rotation, end); 
			     var lineStr2 = new ol.geom.LineString([end, [end[0] - 200000, end[1] - 200000]]); 
			     lineStr2.rotate(rotation, end); 
			 
			     var stroke = new ol.style.Stroke({ 
			      color: 'green', 
			      width: 1 
			     }); 
			 
			     styles.push(new ol.style.Style({ 
			      geometry: lineStr1, 
			      stroke: stroke 
			     })); 
			 
			     styles.push(new ol.style.Style({ 
			      geometry: lineStr2, 
			      stroke: stroke 
			     })); 
		 
		    }); 
		 
		    return styles; 
		};*/
		
        
    	if(type !="None"){
    		var geometryFunction, maxPoints;
    		if (type === 'Square') {
    			type = 'Circle';
		      geometryFunction = ol.interaction.Draw.createRegularPolygon(4);
		    } else if (type === 'Arrow') {
		    	type = 'LineString';
		    	geometryFunction = function(coordinates, geometry) {
			        if (!geometry) {
			          geometry = new ol.geom.Polygon(null);
			        }
			        var start = coordinates[0];
			        var end = coordinates[1];
			        
			        
			        // Rest of the code
			        var dx = end[0] - start[0];
			        var dy = end[1] - start[1];
			        var rotation = Math.atan2(dy, dx);
			        // arrows
			        styles.push(new ol.style.Style({
			          geometry: new ol.geom.Point(end),
			          image: new ol.style.Icon({
			            src: 'https://openlayers.org/en/v5.3.0/examples/data/arrow.png',
			            anchor: [0.75, 0.5],
			            rotateWithView: true,
			            rotation: -rotation
			          })
			        }));			        
			        
			        
			        geometry.setCoordinates([
			          [start, [start[0], end[1]], end, [end[0], start[1]], start]
		        ]);
		        return geometry;
		      };
		    }/* else if (type === 'Arrow') {
		    	type = 'LineString';
		    }*/
    		
    		if(type!="Polygon"){
    			maxPoints = 1;
    		}
    		
    		draw = new ol.interaction.Draw({
    			source : source,
    			type : type,
    			/*style: styleFunction,*/
    			geometryFunction: geometryFunction,
    		    maxPoints: maxPoints
    		});
    		
    		map.addInteraction(draw);
    		
    	}else{
    		// 도형 지우기
    		vector.getSource().clear();	
    	}
    }else{
    	map.removeInteraction(draw);
    }
    
	cfsetAllMapHandlerActivity(false); // 모든 이벤트 핸들러 비활성화
	map.addInteraction(wheelZoomEvent);	//oskim 20181226 , 그리기 기능에서 휠확대축소 가능 처리 (현업자요청)
	
}

function awsBranchLoad(lat, lon, name) {
	// 좌표변환
	var point = imx.run(IMXKey.MapCoordinates, 'coordConvertor_Points', {
		"projectionSource" : "EPSG:4326", // 입력한 points의 srsCode ;
		"projectionDest" : "U3:7001", // 출력할 points의 srsCode ;
		"points" : [ lon, lat ],
		"returnType" : "array" // 변환 결과 형태 ;
	});
	
	var url = $("#legend img").attr("src");
	url = url.replace("&UNIT_BAR=1", ""); // UNIT_BAR=1 인 경우 CGI에서 예외처리가 되어있어 제거함
	url = url.replace("&POINT_LON=", "");  
	url = url.replace("&POINT_LAT=", "");  
	url += "&POINT_RAIN=1";
	url += "&POINT_LON=" + lon;
	url += "&POINT_LAT=" + lat;
	
	$.ajax({
		url : "/cmmn/getAwsBranchAjax.do",
		type : "POST",
		dataType : "json",
		data : {
			url : url
		},
		success : function(data) {
			if(data.result != "fail"){
				// 점찍기
				imx.run(IMXKey.MapObjectSpace, "addGraphic_Point_Circle", {
					kGroup : "testGroup",
					kName : 'testPoint',
					radius : 3,
					coordX : point.result.points[0],
					coordY : point.result.points[1],
					bCoordinates : true,
					srsCode : 'U3:7001',
					style : {
						kLine : '1|0x0000ff|1.0',
						kFill : '0x0000ff|1.0'
					}
				});
				// 이미지 표출
				imx.run(IMXKey.MapObjectSpace, "addBitmap_Mouse", {
					kGroup : "testGroup",
					kName : "testImage",
					kType : "image",
					kBitmap : "kBitmapAreaBubble",
					bCoordinates : true,
					srsCode : "U3:7001",
					coordX : point.result.points[0],
					coordY : point.result.points[1],
					width : 160,
					height : 100,
					bMargin : true,
					marginX : -80,
					marginY : -105
				});
				// 텍스트 출력
				imx.run(IMXKey.MapObjectSpace, "addTextField", {
					kGroup : "AWS_Rain",
					kName : "AWS_text",
					text : "지점명: \n강우강도 : ",
					bCoordinates : true,
					srsCode : "U3:7001",
					coordX : point.result.points[0],
					coordY : point.result.points[1],
					kTextFormat : "0x000000|batang|13", // RunFunctionsEF_createTextFormat.json 에서 정의하고 최초 맵 로드시 생성된다.
					bMargin : true,
					marginX : -80 + 10,
					marginY : -100 + 5
				});
				imx.run(IMXKey.MapObjectSpace, "addTextField", {
					kGroup : "AWS_Rain",
					kName : "AWS_value",
					text : name + "\n" + data.result,
					bCoordinates : true,
					srsCode : "U3:7001",
					coordX : point.result.points[0],
					coordY : point.result.points[1],
					kTextFormat : "textformAWS", // RunFunctionsEF_createTextFormat.json 에서 정의하고 최초 맵 로드시 생성된다.
					bMargin : true,
					marginX : -80 + 10 + 75,
					marginY : -100 + 5
				});
				// 클릭 이벤트 추가
				imx.run({kGroup : "testGroup", kName : "testImage"}, "addEvent_External", {
					evtType : IMXConst.EVENT_MOUSE.CLICK, // 이벤트 타입. 약속된 이벤트 상수를 입력 ;
					evtFunc : "AWSRainClose", // 이벤트 발생 시 실행시킬 함수 이름 ;
					useCapture : false,// Event의 Bubble 발생 여부;
					priority : 0, // 이벤트 우선 순위;
					useWeakReference : false // 강한 참조, 약한 참조에 대한 설정 여부 ;
				});
				// 비트맵 이미지가 아닌 텍스트 영역에서도 클릭시 이벤트를 주어야 한다.
				imx.run({kGroup : "AWS_Rain", kName : "AWS_text"}, "addEvent_External", {
					evtType : IMXConst.EVENT_MOUSE.CLICK, // 이벤트 타입. 약속된 이벤트 상수를 입력 ;
					evtFunc : "AWSRainClose", // 이벤트 발생 시 실행시킬 함수 이름 ;
					useCapture : false,// Event의 Bubble 발생 여부;
					priority : 0, // 이벤트 우선 순위;
					useWeakReference : false // 강한 참조, 약한 참조에 대한 설정 여부 ;
				});		
				imx.run({kGroup : "AWS_Rain", kName : "AWS_value"}, "addEvent_External", {
					evtType : IMXConst.EVENT_MOUSE.CLICK, // 이벤트 타입. 약속된 이벤트 상수를 입력 ;
					evtFunc : "AWSRainClose", // 이벤트 발생 시 실행시킬 함수 이름 ;
					useCapture : false,// Event의 Bubble 발생 여부;
					priority : 0, // 이벤트 우선 순위;
					useWeakReference : false // 강한 참조, 약한 참조에 대한 설정 여부 ;
				});			

			}
			else{
				//alert(data.error);
			}
		},
		error : function(request, status, error) {
			//alert("code:" + request.status + "\n" + "message:"+ request.responseText + "\n" + "error:" + error);
		}
	});
}
	
// 20181120 khr - 확인필요
function AWSRainClose(){
	if(cfExistKey(IMXKey.MapObjectSpace, 'testGroup', "testImage")){
		// 이벤트 제거
		imx.run({kGroup : "testGroup", kName : "testImage"}, "removeEvent_External", {
			evtType : IMXConst.EVENT_MOUSE.CLICK, // 이벤트 타입. 약속된 이벤트 상수를 입력 ;
			evtFunc : "AWSRainClose", // 이벤트 발생 시 실행시킬 함수 이름 ;
			useCapture : false
		// Event의 Bubble 발생 여부;
		});
		imx.run({kGroup : "AWS_Rain", kName : "AWS_text"}, "removeEvent_External", {
			evtType : IMXConst.EVENT_MOUSE.CLICK, // 이벤트 타입. 약속된 이벤트 상수를 입력 ;
			evtFunc : "AWSRainClose", // 이벤트 발생 시 실행시킬 함수 이름 ;
			useCapture : false
		// Event의 Bubble 발생 여부;
		});
		imx.run({kGroup : "AWS_Rain", kName : "AWS_value"}, "removeEvent_External", {
			evtType : IMXConst.EVENT_MOUSE.CLICK, // 이벤트 타입. 약속된 이벤트 상수를 입력 ;
			evtFunc : "AWSRainClose", // 이벤트 발생 시 실행시킬 함수 이름 ;
			useCapture : false
		// Event의 Bubble 발생 여부;
	});
		cfDeleteKGroup(IMXKey.MapObjectSpace, "testGroup");
		cfDeleteKGroup(IMXKey.MapObjectSpace, "AWS_Rain");
	}

}
