#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <zlib.h>
#include "gd.h"

#include "make_lgt_basin_decade.h"

int main(int arc, char *argv[])
{
  short nStartYear = 0;
  short nEndYear = 0;

  if(arc != 3){
      printf("Usage:$make_lgt_basin_decade 2009 2018\n");
      return 0;
  }

  nStartYear = atoi(argv[1]);
  nEndYear = atoi(argv[2]);

  return 0;
}

int clearBasinData(BASIN_DATA* basin_data)
{
  int i = 0;
  for(i=0; i<basin_data[0].basinCnt; i++){
      basin_data[i].lgtCnt = 0;
      basin_data[i].totImpact = 0.0;
      basin_data[i].maxImpact = 0.0;
      basin_data[i].minImpact = 999.0;
  }
  return 0;
}

int read_src_data(short nYear, BASIN_DATA* basin_data)
{
  return 0;
}

int merge_year_data(short nStart, short nEnd)
{
	FILE *tfp;
	char tFile[1024] = {0,};
	FILE *rfp, *wfp;
	char fcheck[BUFFER_SIZE];
	int i;
	int lerrno;

	int ibuf[2];
	double dbuf[1];
	float fbuf[2];
	int basinLen = 0;

	char command[BUFFER_SIZE];
	char tmpString[BUFFER_SIZE];

	if((rfp = gzopen(writeFile, "rb")) != NULL){
		gzread(rfp, &basinLen, sizeof(int));

    BASIN_DATA *basin_tmp = (BASIN_DATA *)malloc(basinLen * sizeof(BASIN_DATA));

		for(i=0; i<basinLen; i++)
		{
			gzread(rfp, &ibuf, sizeof(ibuf));
			basin_tmp[i].code = ibuf[0];
			basin_tmp[i].lgtCnt = ibuf[1];

			gzread(rfp, &dbuf, sizeof(dbuf));
			basin_tmp[i].totImpact = dbuf[0];

			gzread(rfp, &fbuf, sizeof(fbuf));

			basin_tmp[i].maxImpact = fbuf[0];
			basin_tmp[i].minImpact = fbuf[1];
		}
		gzclose(rfp);
	}

  for(int i = 0; i < nEndYear-nStartYear ; i++){

    BASIN_DATA *basin_data = (BASIN_DATA *)malloc(basinLen * sizeof(BASIN_DATA));
    read_src_data(nStartYear + i, basin_data);

    for(i = 0; i<basinLen; i++){
  		if(basin_tmp[i].code == basin_data[i].code){
  			basin_tmp[i].lgtCnt += basin_data[i].lgtCnt;
  			if(basin_tmp[i].lgtCnt > 0){
  				basin_tmp[i].totImpact += basin_data[i].totImpact;
  				if(basin_tmp[i].maxImpact < basin_data[i].maxImpact){
  					basin_tmp[i].maxImpact = basin_data[i].maxImpact;
  				}
  				if(basin_tmp[i].minImpact > basin_data[i].minImpact){
  					basin_tmp[i].minImpact = basin_data[i].minImpact;
  				}
  			}
  		}
  	}

    free(basin_data);
  }

	if((wfp = gzopen(writeFile, "w")) != NULL){
		if(gzwrite(wfp, &basinLen, sizeof(int)) < 0){
			printf("%s\n",gzerror(wfp, &lerrno));
		}
		for(i=0; i<basinLen; i++){
			if(gzwrite(wfp, &basin_tmp[i].code, sizeof(int)) < 0){
				printf("%s\n",gzerror(wfp, &lerrno));
			}
			if(gzwrite(wfp, &basin_tmp[i].lgtCnt, sizeof(int)) < 0){
				printf("%s\n",gzerror(wfp, &lerrno));
			}
			if(gzwrite(wfp, &basin_tmp[i].totImpact, sizeof(double)) < 0){
				printf("%s\n",gzerror(wfp, &lerrno));
			}
			if(gzwrite(wfp, &basin_tmp[i].maxImpact, sizeof(float)) < 0){
				printf("%s\n",gzerror(wfp, &lerrno));
			}
			if(gzwrite(wfp, &basin_tmp[i].minImpact, sizeof(float)) < 0){
				printf("%s\n",gzerror(wfp, &lerrno));
			}
		}
		gzclose(wfp);
	}

	free(basin_tmp);

	return 0;
}
