//운영서버 sync 20180213
package kres.us.cmmn.web;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kres.ad.option.service.AdOptionVO;
import kres.cm.util.AboutString;
import kres.cm.util.CmUtilApp;
import kres.us.cmmn.service.UsCmmnService;
import kres.us.cmmn.service.UsCmmnVO;
import kres.us.cmmn.service.UsTyphoonListVO;
import kres.us.cmmn.service.UsTyphoonRouteVO;

import org.json.simple.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

//oskim 20180724
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

/**
 *  @Class Name : UsMntrController.java
 *  @Project Name : KRES
 *  @Modification Information
 *  @
 *  @  수정일             수정자               수정내용
 *  @ ------------     -------------     ---------------------------
 *  @ 2016. 8. 5.          이현기      
 *
 *  @author safeKorea(이현기)
 *  @since 2016. 8. 5.
 *  @see UsCmmnController
 *  @Description : 
 *
 */
@Controller
public class UsCmmnController {
	
	/** GISPropertiesService */
	@Resource(name = "ImgesPropertiesService")
	protected EgovPropertyService	ImgesPropertiesService;
	
	/** UsMntrService */
	@Resource(name="usCmmnService")
	private UsCmmnService usCmmnService;
	
	/** DataPropertyService */
	@Resource(name = "DataPropertiesService")
	protected EgovPropertyService DataPropertiesService;	

	/**
	 * @Method Name : CrossPop
	 * @date,  2016. 9. 8.
	 * @author 이성규
	 * @description : 연직단면 팝업 호출
	 *
	 * @param usCmmnVO
	 * @param param
	 * @param model
	 * @return String
	 */
	@RequestMapping(value = {"/cmmn/crossPop.do"})
	public String crossPop(@ModelAttribute("UsCmmnVO") UsCmmnVO usCmmnVO,
							@ModelAttribute("param") String param,
							HttpServletRequest req, 
							HttpServletResponse res,
							 ModelMap model) throws Exception{
		
		ModelAndView mv = new ModelAndView("jsonView");
		
		String date = usCmmnVO.getDate();
		date = date.replace(".", "");
		date = date.replace(" ", "");
		date = date.replace(":", "");
		String  crossUrl =ImgesPropertiesService.getString("CGI_BASE_PATH");
		if(usCmmnVO.getpType().equals("SITE_DEP1_ATOM7") || usCmmnVO.getpType().equals("SITE_DEP2_ATOM14")){
			if(usCmmnVO.getpType().equals("SITE_DEP1_ATOM7")){
				crossUrl += ImgesPropertiesService.getString("CGI_ATOM7_CROSS_NAME");
			}else{
				crossUrl += ImgesPropertiesService.getString("CGI_ATOM14_CROSS_NAME");
			}
			crossUrl += "?DATE=" + date;
			crossUrl += "&AZIMUTH=" + usCmmnVO.getAzimuth();
			crossUrl += "&pNum=" + usCmmnVO.getpNum();
			if(usCmmnVO.getAzimuth().equals("-1")){
				crossUrl += "&CROSS_LAT=" + usCmmnVO.getCrossLat();
				crossUrl += "&CROSS_LON=" + usCmmnVO.getCrossLon();	
			}else{
				crossUrl += "&START_DIST=" + usCmmnVO.getStartDist();
				crossUrl += "&END_DIST=" + usCmmnVO.getEndDist();
			}
		}else{
			crossUrl += ImgesPropertiesService.getString("CGI_"+usCmmnVO.gettType()+"_CROSS_NAME");
			crossUrl += "?DATE=" + date;
			crossUrl += "&X1=" + Double.toString(usCmmnVO.getStartPointX());
			crossUrl += "&Y1=" + Double.toString(usCmmnVO.getStartPointY());
			crossUrl += "&X2=" + Double.toString(usCmmnVO.getEndPointX());
			crossUrl += "&Y2=" + Double.toString(usCmmnVO.getEndPointY());
			crossUrl += "&Q_TYPE=" + usCmmnVO.getqType();
			crossUrl += "&D_TYPE=" + usCmmnVO.getdType();
			crossUrl += "&LEGEND_NUM=1";
			crossUrl += "&pNum=" + usCmmnVO.getpNum();
		}
		
		if(usCmmnVO.gettType().equals("SITE")){
			crossUrl += "&SITE_NAME=" + usCmmnVO.getSiteName();
			crossUrl += "&V_WIND=" + usCmmnVO.getvWind();
		}else{
			crossUrl += "&AWS=A&MAP=M";
			crossUrl += "&M_WIND=" + usCmmnVO.getmWind();
		}
		
		model.addAttribute("crossUrl", crossUrl);		
		model.addAttribute("usCmmnVO", usCmmnVO);
		model.addAttribute("date", date);
		model.addAttribute("uiTime", req.getParameter("uiTime"));
		
		return "us/cmmn/crossPop";
	}
	
	/**
	 * @Method Name : selectSidoList
	 * @date,  2016. 9. 8.
	 * @author 이성규
	 * @description : 상단 툴바
	 * 
	 * @param model
	 * @return
	 * @throws Exception ModelAndView
	 */
	@RequestMapping(value="/cmmn/navi.do")
	public String selectSidoList(Model model) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		map = usCmmnService.selectSidoList(map);		
		model.addAttribute("sigunList", map.get("list"));
		
		String imgHeader = ImgesPropertiesService.getString("CGI_BASE_PATH");
		model.addAttribute("imgHeader", imgHeader);
		
		return "us/inc/navi";	
	}
	
	
	/**
	 * @Method Name : incheonFIR
	 * @date,  2016. 9. 2.
	 * @author 이성규
	 * @description : FIR 기능 호출 시작
	 *
	 * @param model
	 * @return
	 * @throws Exception ModelAndView
	 */
	@RequestMapping(value="/cmmn/incheonFIR.do")
	public ModelAndView incheonFIR(Model model) throws Exception {
		
		ModelAndView mv = new ModelAndView("jsonView");
		List<String[]> result_area = new ArrayList<String[]>();
		
		try { 
			String dataPath = ImgesPropertiesService.getString("DATA_BASE_PATH");
			BufferedReader area = new BufferedReader(new FileReader(dataPath + "/aws/airport_area.txt"));
			
			String s1;
			int cnt1 = 0;
			String temp1 = "";
			while ((s1 = area.readLine()) != null) {
				String[] split = s1.split("\\s+");
				if(cnt1 != 0){
					temp1 += (cnt1 == 1) ? split[1]+","+split[0] : ","+split[1]+ ","+split[0];
					result_area.add(temp1.split(","));
				}
				cnt1++;
			}	
			area.close();
		} catch (IOException e) {
			  System.err.println(e);
			  System.exit(1);
		}
		mv.addObject("awsAreaList", result_area);
		
		List<String[]> result_path = new ArrayList<String[]>();
		List<String[]> result_point = new ArrayList<String[]>();

		try { 
			String dataPath = ImgesPropertiesService.getString("DATA_BASE_PATH");
			BufferedReader path = new BufferedReader(new FileReader(dataPath + "/aws/airport_path2.txt"));
			
			String s2;
			int cnt2 = 0;
			int cnt3 = 0;
			String temp2 = "";
			String point = "";
			while ((s2 = path.readLine()) != null) {
				String[] split = s2.split("\\s+");
				if(split.length == 3){
					if (Integer.valueOf(split[2]) == 1) {
						point += (cnt3 == 0) ? split[1]+","+split[0] : ","+split[1]+ ","+split[0];
						result_point.add(point.split(","));
						cnt3++;
					}
					temp2 += (cnt2 == 0) ? split[1]+","+split[0] : ","+split[1]+ ","+split[0];
					cnt2++;
				}
				else{
					if(cnt2 != 0){
						result_path.add(temp2.split(","));
						temp2 = "";
						cnt2 = 0;
					}
				}
			}	
			path.close();
		} catch (IOException e) {
			  System.err.println(e);
			  System.exit(1);
		}
			
		mv.addObject("awsPathList", result_path);
		mv.addObject("awsPathPointList", result_point);
		
		return mv;
	}
	
	
	/**
	 * @Method Name : getAWSrnValue
	 * @date,  2016. 10. 4.
	 * @author 강혜리
	 * @description 
	 * 수정 : 
	 *	aws 지점 강우강도, aws강수량 값 읽어오기 
	 * @param awsnum
	 * @param siteName
	 * @param ptype
	 * @param qtype
	 * @param dateTime
	 * @return
	 * @throws Exception ModelAndView
	 */
	@RequestMapping(value="/cmmn/getAWSValue.do")
	public ModelAndView getAWSrnValue(
			@RequestParam(value="awsnum", defaultValue = "") String awsnum,
			@RequestParam(value="siteName", defaultValue = "") String siteName,
			@RequestParam(value="ptype", defaultValue = "") String ptype,
			@RequestParam(value="qtype", defaultValue = "") String qtype,
			@RequestParam(value="avg", defaultValue = "") String avg,
			@RequestParam(value="dateTime", defaultValue = "") String dateTime
			) throws Exception {
        ModelAndView mv = new ModelAndView("jsonView");
		
		String dbzValue = ""; // 강우강도 값
		String awsValue = ""; // aws강수량 값
		
		try { 
			String url = "";
			
			if(avg.equals("AVG")) avg = "A"; //평균
			if(avg.equals("DST")) avg = "N"; //최소거리
			if(avg.equals("MAX")) avg = "M"; //최대
			if(avg.equals("MIN")) avg = "I"; //최소
			if(avg.equals("QUY")) avg = "Q"; //품질정보
			if(avg.equals("WGT")) avg = "W"; //거리가중
			
			if(ptype.contains("DEP")){
				String[] temp = ptype.split("_");
				ptype = "";
				for(int i=0;i<temp.length;i++){
					if(i != 1){
						ptype += temp[i];
						if(i != temp.length-1) ptype += "_";
					}
				}
			}
			
			String awsDir = "AWS_" + ptype + "_DIR"; //aws 디렉토리
			String awsFile = "AWS_" + ptype + "_" + qtype + "_FILE"; //aws 파일명
			String str = ""; 
					
			if(qtype.equals(""))	awsFile = "AWS_" + ptype + "_FILE";
			if(!siteName.equals("")){
				str = siteName;
				if(ptype.indexOf("SITE_480KM") > -1) awsDir = "AWS_" + ptype + "_DIR";
				else awsDir = "AWS_" + ptype + "_" + qtype + "_DIR";
			}	
			else str = avg;
			
			//oskim 20180129
			int nSetTime = 0;
			int nDiffHour = 20;	//20분 이내
			String strTempDateTime = dateTime;
			
			for(nSetTime = 0; nSetTime < nDiffHour; nSetTime++)
			{				
				url = DataPropertiesService.getString(awsDir).replace("%Y%m", dateTime.substring(0,6)).replace("%d", dateTime.substring(6,8)) +
						CmUtilApp.getAddStr(DataPropertiesService.getString(awsFile), str, "", strTempDateTime);
				
				File file = new File(url);
				
				if(file.isFile()){
					BufferedReader in = 
							new BufferedReader(new FileReader(url));
					String s;
					
					while ((s = in.readLine()) != null) {
						/*
						 * 파일의 첫번째 내용 
						 * #AWS_ID,AWS_RAIN,RADAR_RAIN~~~~~~
						 * 이 없어질수도 있고 있을수도 있어 
						 * #이 없는 부분의 라인부터 읽는다 
						 * */			
						String[] temp = null;
						String findSharp = "#";
						
						if(!s.contains(findSharp)){
							temp= s.split(",");
							if(awsnum.equals(temp[0])){
								mv.addObject("awsResult", s);
								awsValue = temp[1];
								dbzValue = temp[2];								
							}
						}
					}
					
					in.close();
					
					break; //exit for loop
				} //end of if
				
				strTempDateTime = CmUtilApp.TimeMinuteIncrease(strTempDateTime, -1);	//파일이 없으면, 1분씩 차감해서 다음 파일을 찾는다.
				
			} //end of for
						
		} catch (IOException e) {
			System.out.println("file error");
		}
		
		mv.addObject("dbzValue", dbzValue);
		mv.addObject("awsValue", awsValue);
		
		return mv;
	}	

	
	@RequestMapping(value="/cmmn/getPositionAjax.do")
	public ModelAndView getPositionAjax(
			@RequestParam(value="type", defaultValue = "") String type) throws Exception {

		ModelAndView mv = new ModelAndView("jsonView");
		List<String> name = new ArrayList<String>();
		List<String> lat = new ArrayList<String>();
		List<String> lon = new ArrayList<String>();	
		List<String> awsnum = new ArrayList<String>();
		List<String> awslev = new ArrayList<String>();		
		
		UsCmmnVO usCmmnVO = new UsCmmnVO();
		//usCmmnVO.setAwsLev(Integer.parseInt(pos_han));
		usCmmnVO.setAwsLev(5);
		usCmmnVO.setAwsSort(type.toUpperCase());
		
		List<UsCmmnVO> pointList = usCmmnService.selectAWSPoint(usCmmnVO);
		for(UsCmmnVO temp : pointList){
			if(type.toUpperCase().equals("AIR")){
				// 명칭이 겹치는부분이 존재하여 추가 20181122 khr
				if(!temp.getAwsNm1().equals("-")){
					name.add(temp.getAwsNm2());					
				}
			}else{
				name.add(temp.getAwsNm2());
			}
			
			lat.add(Double.toString(temp.getAwsLat()));
			lon.add(Double.toString(temp.getAwsLon()));
			awsnum.add(Integer.toString(temp.getAwsNum()));
			awslev.add(Integer.toString(temp.getAwsLev()));
		}
		
		mv.addObject("name", name);
		mv.addObject("lat", lat);
		mv.addObject("lon", lon);
		mv.addObject("awsnum", awsnum);
		mv.addObject("awslev", awslev);

		return mv;
	}	
	
	
	/**
	 * @Method Name : getMenuListAjax
	 * @date,  2016. 9. 2.
	 * @author 강혜리
	 * @description 
	 *	: 옵션메뉴 변경 ajax 
	 * @param req
	 * @param resp
	 * @param cno
	 * @return
	 * @throws Exception ModelAndView
	 */
	@RequestMapping(value="/cmmn/selectMenuListAjax.do")
	public ModelAndView getMenuListAjax(HttpServletRequest req, HttpServletResponse resp,
			@RequestParam(value="cno", required=true) String cno) throws Exception{
		ModelAndView mv = new ModelAndView("jsonView");
		
		List<AdOptionVO> optionNmList = usCmmnService.getOptionListByNm(cno);
		List<AdOptionVO> optionList = usCmmnService.getOptionListByCno(cno);
		
		//oskim 20180920 , to be delete...
		//oskim 20181001 , was deleted
		/*
		if (cno.equals("151")) {	//하드코딩
			Collections.swap(optionList, 0, 1);
			Collections.swap(optionList, 1, 2);
		}
		*/
		
		mv.addObject("optionList", optionList);
		mv.addObject("optionNmList", optionNmList);
		
		return mv;
	}
	
	/**
	 * @Method Name : getNearestTime
	 * @date,  2016. 9. 21.
	 * @author 이현기
	 * @description 
	 * : 최근 파일 조회 및 시간 설정
	 * @param dateTime
	 * @param dataType
	 * @param siteName
	 * @return
	 * @throws Exception ModelAndView
	 */
	@RequestMapping(value="/cmmn/getNearestTime.do")
	public ModelAndView getNearestTime(
			@RequestParam(value="dataType", defaultValue = "") String dataType,
			@RequestParam(value="siteName", defaultValue = "") String siteName,
			@RequestParam(value="siteTime", defaultValue = "") String siteTime,
			@RequestParam(value="dateTime", defaultValue = "") String dateTime) throws Exception {
		
		ModelAndView mv = new ModelAndView("jsonView");

		if(dataType.contains("DEP")){
			String[] temp = dataType.split("_");
			dataType = "";
			for(int i=0;i<temp.length;i++){
				if(i != 1){
					dataType += temp[i];
					if(i != temp.length-1) dataType += "_";
				}
			}
		}
		
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmm");		
		if(dateTime.equals("")){
			dateTime = format.format(cal.getTime()); 
		}
		//oskim 20180409 , 낙뢰 안나오는것
		//oskim 20180614 , MAPLE 적용
		if(dataType.contains("_LGT_") || dataType.contains("MAPLE_LGT")){
			//아무것도 하지 않는다. do nothing!
		}		
		else if(dataType.contains("LGT")){	
			int remain = Integer.parseInt(dateTime.substring(11,12));
			if(remain < 2){
				cal.add(Calendar.MINUTE, (-3 - remain));
			}else if(remain >= 2 && remain < 7){
				cal.add(Calendar.MINUTE, (2 - remain));
			}else{
				cal.add(Calendar.MINUTE, (7 - remain));
			}
			dateTime = format.format(cal.getTime());
			mv.addObject("dateTime", dateTime); 
			return mv;
		}
		
		
		String path = "";
		// 자료시간
		/* 20170327
		 * 품질관리 데이터가 없을경우 jsp 에서 넘어오는값 : SITE_PPI -> 이때 현재시간으로 던진다. 
		 * 정상 값 : SITE_PPI_ORPGQC
		 * */
		//if(dataType.split("_").length >= 2){	//oskim 20180206 , 20180626 if 조건 없앰
			
			//oskim 20180206 (time sync, 타임 sync)
			/*
			 * 1. ..length >= 2
			 * 2. context-data-properties.xml 의 키값 현행화 (타임 sync 안되면, 입력파라메터 dataType 확인할것, 운영서버 SITE_DEP1_PPI_NOQC 추가)
			 * 3. dataType + _DIR 에서 날짜 replace 하도록
			 * 4. endsWith() 처리, 확장자 유무에 따른 처리
			 * 5. 운영서버의 cmmnCtrl.js 814 라인 삭제, if( dataType == "COMP_DEP1_REAL"  ) dataType = "AWS_COMP_REAL";
			 * 6. 
			 * 7. AboutString.java는 수정 안해도 됨
			 * 8. AWS 최근 20분내 데이터 찾는것 삭제(원복) -> 최신 radar영상 업데이트 후 1분 정도 Gap이 있어 남겨둠
			 * */
			//oskim 20180614 , MAPLE 패스
			if(!dataType.contains("MAPLE"))
				path = DataPropertiesService.getString("DATA_ROOT_PATH");
			path += DataPropertiesService.getString(dataType+"_DIR");
			
			path = path.replaceAll("%Y", dateTime.substring(0, 4));
			path = path.replaceAll("%m", dateTime.substring(4, 6));
			path = path.replaceAll("%d", dateTime.substring(6, 8));					
			
			if(siteName.endsWith("")){	//확장자가 없는 파일이라면
				path += DataPropertiesService.getString(dataType+"_FILE").replaceAll("%S", siteName);
			}
			
			//oskim 20181023 ,
			if(dataType.contains("_SAT"))
				dateTime = CmUtilApp.TimeMinuteIncrease(dateTime, -1 * 60 * 9);	//UTC time -
			
			dateTime = AboutString.searchFileNearestTime(path, dateTime, siteTime);
			
			//oskim 20181023 ,
			if(dataType.contains("_SAT"))
				dateTime = CmUtilApp.TimeMinuteIncrease(dateTime, +1 * 60 * 9);	//UTC time +
			
			
		//}	//oskim 20180626 if 조건 없앰

		mv.addObject("dateTime", dateTime);
		return mv;
	}	
	
	
	/**
	 * @Method Name : aniImgListAjax
	 * @date,  2016. 8. 8.
	 * @author 강혜리
	 * @description 
	 *	스넵샷 이미지 주소 생성
	 * @return
	 * @throws Exception ModelAndView
	 */
	@RequestMapping(value="/cmmn/aniImgListAjax.do")
	public ModelAndView aniImgListAjax(
			@RequestParam(value="dateTime", required=false) String dateTime,
			@RequestParam(value="site", required=false) String site,
			@RequestParam(value="uiTime", required=false) String uiTime,
			HttpServletRequest req, HttpServletResponse resq) throws Exception{
		if(dateTime == null || dateTime.equals("")){
			Calendar cal = Calendar.getInstance();
			SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmm");
			dateTime = format.format(cal.getTime()); 
		}
		ModelAndView mv = new ModelAndView("jsonView");
		
		// 사이트 관측주기 가져오기
		int sitetime = 10;
		if(site != null) {
			if(!site.isEmpty()) {
				HashMap<String, Object> paramSite = new HashMap<String, Object>();
				paramSite.put("dateTime", dateTime);
				paramSite.put("siteVal", site);
				sitetime = usCmmnService.selectSitetimeToObsStation(paramSite);
			}
		}
		if(uiTime != null) {
			if(!uiTime.isEmpty()) {
				sitetime = Integer.parseInt(uiTime);
			}
		}
		
		String context = req.getSession().getServletContext().getRealPath("/").replaceAll( "\\\\", "/");
		//List<Map<String, Object>> aniImgList = CmUtilApp.createDateList(dateTime, context);
		List<Map<String, Object>> aniImgList = new ArrayList<Map<String,Object>>();
		List<Date> aniImgListTmp =  CmUtilApp.createDateList(dateTime, sitetime, context);
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmm");
		
		for (int i = 0; i < aniImgListTmp.size(); i++) {
			Map<String, Object> map = new HashMap<String, Object>();
			String aniImgDate =format.format(aniImgListTmp.get(i));
			String snapDir = CmUtilApp.getAddStr(DataPropertiesService.getString("SNAPSHOT_DIR"), "", "", aniImgDate) ;
			String snapFile = CmUtilApp.getAddStr(DataPropertiesService.getString("SNAPSHOT_FILE"),"", "", aniImgDate);
			String snapPath = snapDir + snapFile;
			//snapPath = snapPath.substring(0, snapPath.length()-5)  + "0.png";
			File file = new File(snapPath); //스넵샷 이미지 있는지 조회
			map.put("fileExist", file.exists());
			map.put("snapFile", snapFile);
			map.put("aniImgDate", aniImgDate);
			aniImgList.add(map);
		}
		
		mv.addObject("slideTime", sitetime);
		mv.addObject("dateTime", dateTime);
		mv.addObject("aniImgList", aniImgList);
		
		return mv; 
	}
	
	@RequestMapping(value = "/cmmn/popStrBranch.do")
	public String popBranch( @ModelAttribute("UsCmmnVO") UsCmmnVO usCmmnVO,Model model
						   	,@RequestParam(value="pageIndex", defaultValue = "1") int pageNo) throws Exception {
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(pageNo); //현재 페이지 번호
		paginationInfo.setRecordCountPerPage(8); //한 페이지에 게시되는 게시물 건수
		paginationInfo.setPageSize(5); //페이징 리스트의 사이즈	
				
		Map<String, Object> map = usCmmnService.selectAWSBranchList(usCmmnVO, paginationInfo);
		int total = (Integer) map.get("tot");   
		paginationInfo.setTotalRecordCount(total);
		
		model.addAttribute("selectAWSNmList", map.get("selectAWSNmList"));
		model.addAttribute("selectAWSBranchList", map.get("selectAWSBranchList"));
		model.addAttribute("selectAWSBranchListTot", total);
		model.addAttribute("paginationInfo", paginationInfo);
		model.addAttribute("usCmmnVO", usCmmnVO);
			
		return "us/cmmn/popStrBranch";
	}
	
	
	@RequestMapping(value="/cmmn/cgiExeFileCheck.do")
	public ModelAndView cgiExeFileCheck(
			@RequestParam(value="cgi_url", required=false) String cgi_url,HttpServletRequest req) throws Exception{

		ModelAndView mv = new ModelAndView("jsonView");
		InetAddress inet = InetAddress.getLocalHost();
		
		String cgiUrl = "http://"+req.getServerName()+":"+req.getServerPort() + "/" + cgi_url;
		URL url = new URL(cgiUrl);
		HttpURLConnection conn = (HttpURLConnection)url.openConnection();
		mv.addObject("result", conn.getResponseCode());
		return mv; 
	}
	
	/**
	 * @Method Name : popImgBranch
	 * @date,  2016. 10. 12.
	 * @author 강혜리
	 * @description 
	 *	파일 인쇄
	 * @param fileName
	 * @param model
	 * @return
	 * @throws Exception String
	 */
	@RequestMapping(value="/cmmn/popImgBranch.do")
	public String popImgBranch(
			@RequestParam(value="fileName", required=false, defaultValue="") String fileName,
			@RequestParam(value="cgiUrl", required=false, defaultValue="") String cgiUrl,
			HttpServletRequest req, HttpServletResponse resp,
			ModelMap model) throws Exception{
		//넘겨받은 fileName은 cgi이미지 만을 포함
		//File file = new File(ImgesPropertiesService.getString("DATA_BASE_PATH_TMP") +"/saveImage/" + fileName);
				
		String context = req.getSession().getServletContext().getRealPath("/").replaceAll("\\\\", "/") + "saveImage";		
		String path = context +"/" + fileName;
		File file = new File(path);
		
		//범례를 포함한 이미지 생성
		File mergeImgFile = null;
		InputStream is = null;
		List<BufferedImage> legendImgList = new ArrayList<BufferedImage>();
		BufferedImage legendImg = null;
		boolean result = false;
		String legendName = "";
		
		try{
			String cgiStr[] = cgiUrl.split(",");
			for (int i = 0; i < cgiStr.length; i++) {
				if(!cgiStr[i].equals("")){
					//cgi범례이미지
					//기상청에서는 reg.getServerName()으로 접근할수 없음으로 이렇게 처리
					String localHost = InetAddress.getLocalHost().toString();
					String cgiTmp = "http://"+localHost.substring(6, localHost.length())+":"+req.getServerPort() + cgiStr[i];
					
					//cgi범례이미지	  			
					//로컬에서테스트하기위한 방식 
					//String cgiTmp =  "http://"+req.getServerName()+":"+req.getServerPort() + cgiStr[i];
					//String cgiTmp = cgiStr[i];
					//cgiTmp = "http://172.20.132.101:9999" + cgiStr[i];
					
					URL url = new URL(cgiTmp);
					legendImg = ImageIO.read(url);
					legendImgList.add(legendImg);
				}
			}
			
			//cgi이미지
			BufferedImage cgiImg = ImageIO.read(file);
			
			int legendImgWidth = 0;	  		
			for(int j = 0; j < legendImgList.size(); j++){
				legendImgWidth += legendImgList.get(j).getWidth();
			}
			int width = cgiImg.getWidth() + legendImgWidth;
			int height = cgiImg.getHeight();
			
			int pos = fileName.lastIndexOf(".");
			String fileExt = fileName.substring(pos+1);
			String fileRealName = path.substring(0, path.length()-file.getName().length()) + fileName.substring(0, pos) + "_legend" + "." + fileExt;
			legendName = fileName.substring(0, pos) + "_legend" + "." + fileExt;
		
			//합친이미지
			BufferedImage mergeImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			
			Graphics2D graphics = (Graphics2D) mergeImg.getGraphics();
			
			for(int j = 0; j < legendImgList.size(); j++){
				graphics.drawImage(legendImgList.get(j), cgiImg.getWidth()+legendImgList.get(j).getWidth()*j, 0, null);
			}
			
			graphics.fillRect(0, 0, cgiImg.getWidth(), cgiImg.getHeight());
  			graphics.setBackground(Color.WHITE);
			graphics.drawImage(cgiImg, 0, 0, null);
			
			mergeImgFile = new File(fileRealName);
			ImageIO.write(mergeImg, "png", mergeImgFile);
		
			if(mergeImgFile.isFile()){
				result = true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		model.addAttribute("result", result);
		model.addAttribute("fileName", "/saveImage/" + legendName);
		return "us/cmmn/popImgBranch";
	}
	
	
	/**
	 * @Method Name : getDbzNum
	 * @date 2017. 1. 19.
	 * @author 류중규
	 * @description 강도표출
	 * @param dbz_cgi
	 * @param gisWidth
	 * @param gisHeight
	 * @param ndate
	 * @param req
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/cmmn/getDbzNum.do")
	@ResponseBody
	public String getDbzNum(@RequestParam(value = "dbz_cgi", required=true) String dbz_cgi,
			@RequestParam(value = "gisWidth", required=true) String gisWidth,
			@RequestParam(value = "gisHeight", required=true) String gisHeight,
			@RequestParam(value = "ndate", required=true) String ndate,
			HttpServletRequest req) throws Exception {
		
		//oskim 20180724 , 사용 후 코멘트 해 둘것 (상단 import slf4j 까지 포함해서)
		//Logger logger = LoggerFactory.getLogger(UsCmmnController.class);		
		
		JSONObject json = new JSONObject();		
				
		String cgiName = dbz_cgi+"&WFLAG=1&NDATE="+ndate;		
		String localHost = InetAddress.getLocalHost().toString();
		String cgiUrl = "http://"+localHost.substring(6, localHost.length())+":"+req.getServerPort() + cgiName;	//운영서버
		
		//String cgiUrl = "http://172.20.132.101:8080" + cgiName;	//테스트 서버		
		//String cgiUrl = "http://172.20.132.101:8080/cgi-bin/radar_site_gis?P_TYPE=PPI&SITE_NAME=GNG&D_TYPE=RN&Q_TYPE=NOQC&IS_SMOOTH=0&SWEEP_NO=0&V_WIND=0&DATE=201612261230&LU_LON=125.39441108243753&LU_LAT=40.9245328536468&RL_LON=132.38016225398377&RL_LAT=34.7295309855263&IMG_XDIM=883&IMG_YDIM=918&X_DIST=623006.8015691588&Y_DIST=647701.2954025902&UNIT_BAR=0&WFLAG=1&NDATE=20170119000000006";		
		//logger.debug("cgiUrl ~~~~~~~ " + cgiUrl);
		Boolean resultType = false;
		ArrayList<Float> dbzList = new ArrayList<Float>();

		URL url = new URL(cgiUrl);
		InputStream is = url.openStream();
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader in = new BufferedReader(isr);		
		String inputLine;		
		while((inputLine = in.readLine()) != null) {
			if(inputLine.equals("OK")) {
				resultType = true;
				break;
			}
		}
		is.close();
		isr.close();
		in.close();
						
		resultType = true;		
		
		String fileFullName = "/srv/kres/cgi_project/data/temp/load_rain/" + ndate +".bin";
		//String fileFullName = "C:/DATA/load_rain/20170119000000007.bin";
		
		if(resultType) {
			File file = new File(fileFullName);	
			if(file.isFile()) {
				int length = Integer.parseInt(gisWidth)*Integer.parseInt(gisHeight)*4;
				byte[] b = new byte[length];
				int counter = 0 ;					
				
				FileInputStream isr1 = new FileInputStream(fileFullName);
				DataInputStream dis = new DataInputStream(isr1);	
				dis.read(b);

				for(int i = 0 ; i< length ; i++){
					if(counter % 4 == 0){
						dbzList.add(byteArrayToFloat(b, counter));							
					}
					counter++;
				}
				
				isr1.close();
				dis.close();		
			}			
		}

		json.put("DATA", dbzList);
		String result = json.toString();
		
		return result;
	}
	
	//oskim 20180417 , 20180508 
	/**
	 * @Method Name : redirectHTTPpage
	 * @date,  2018. 4. 17.
	 * @author 김언식
	 * @description : 표출시스템의 낙뢰사이트 연결
	 * 
	 * @param model
	 * @return
	 * @throws Exception ModelAndView
	 */
	@RequestMapping(value="/lgt/lgt-time.do")
	public String redirectHTTPpage1(Model model) throws Exception {	
		return "us/cmmn/lgt-link-time";	
	}
	
	@RequestMapping(value="/lgt/lgt-basin.do")
	public String redirectHTTPpage2(Model model) throws Exception {	
		return "us/cmmn/lgt-link-basin";	
	}	

	@RequestMapping(value="/lgt/lgt-monitor.do")
	public String redirectHTTPpage3(Model model) throws Exception {	
		return "us/cmmn/lgt-link-monitor";	
	}
	
	@RequestMapping(value="/lgt/lgt-cloud.do")
	public String redirectHTTPpage4(Model model) throws Exception {	
		return "us/cmmn/lgt-link-cloud";	
	}
	
	@RequestMapping(value="/lgt/lgt-rawdata.do")
	public String redirectHTTPpage5(Model model) throws Exception {	
		return "us/cmmn/lgt-link-rawdata";	
	}		
	
	//oskim 20190728
	@RequestMapping(value="/cmmn/popTyphoonRoute.do")
	public String redirectTyphoonRoute(Model model) throws Exception {	
		return "us/cmmn/popTyphoonRoute";	
	}

	//oskim 20190804
	@RequestMapping(value = "/cmmn/popTyphoonList.do")
	public String getTyphoonList( @ModelAttribute("UsTyphoonListVO") UsTyphoonListVO usTyphoonListVO, Model model
						   	,@RequestParam(value="pageIndex", defaultValue = "1") int pageNo) throws Exception {
		
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(pageNo); //현재 페이지 번호
		paginationInfo.setRecordCountPerPage(8); //한 페이지에 게시되는 게시물 건수
		paginationInfo.setPageSize(5); //페이징 리스트의 사이즈	
				
		Map<String, Object> map = usCmmnService.selectTyphoonList(usTyphoonListVO, paginationInfo);
		int total = (Integer) map.get("tot");   
		paginationInfo.setTotalRecordCount(total);

		model.addAttribute("listTot", total);
		model.addAttribute("typhoonList", map.get("selectTyphoonList"));
		model.addAttribute("typhoonRoute", map.get("selectTyphoonRoute"));
		model.addAttribute("paginationInfo", paginationInfo);
		model.addAttribute("usTyphoonListVO", usTyphoonListVO);

		return "us/cmmn/popTyphoonList";
	}
	
	//oskim 20190806
	/*
	@RequestMapping(value = "/cmmn/getTyphoonRouteAjax.do")
	public ModelAndView getTyphoonNameAjax( @ModelAttribute("UsTyphoonListVO") UsTyphoonListVO usTyphoonListVO,
										Model model) throws Exception {
		
		PaginationInfo paginationInfo = new PaginationInfo();
		ModelAndView mv = new ModelAndView("jsonView");
		Map<String, Object> map = usCmmnService.selectTyphoonName(usTyphoonListVO, paginationInfo);
		mv.addObject("branchList", map.get("branchList"));
		
		return mv;
	}
	*/
	
	public float byteArrayToFloat(byte b[], int start) {
		int i = 0;
		int len = 4;
		int cnt = 0;
		byte[] temp = new byte[len];
		for(i = start; i<(start+len); i++) {
			temp[cnt] = b[i];
			cnt ++;
		}
		
		int accum = 0;
		i = 0;
		for(int shiftBy = 0; shiftBy<32;shiftBy+=8) {
			accum |= ((long)(temp[i] & 0xff)) << shiftBy;
			i++;
		}

		return Float.intBitsToFloat(accum);
	}
	
	/**
	 * @Method Name : download
	 * @date,  2018. 9. 7.
	 * @author 강혜리
	 * @description 
	 *	파일 다운로드
	 * @param request
	 * @param response
	 * @throws Exception void
	 */
	@RequestMapping(value="/cmmn/download.do")	
	public void download(HttpServletRequest request, HttpServletResponse response) throws Exception{	
		String context = request.getSession().getServletContext().getRealPath("/").replaceAll( "\\\\", "/") + "saveImage";
		String fileName = request.getParameter( "fileName" );
		
		if( fileName != null && !"null".equals( fileName ) && fileName.length() > 0 )
		{
			String path = context + "/" + fileName;
			
			File file = new File(path);
			String mimetype = request.getSession().getServletContext().getMimeType(file.getName());
			
			if (file == null || !file.exists() || file.length() <= 0 || file.isDirectory()) {
			  throw new IOException("파일 객체가 Null 혹은 존재하지 않거나 길이가 0, 혹은 파일이 아닌 디렉토리");
			}
			
			File mergeImgFile = null;
			InputStream is = null;
			List<BufferedImage> legendImgList = new ArrayList<BufferedImage>();
			BufferedImage legendImg = null;
			
			try {
				//범례이미지 생성	
			  	String cgiUrl = request.getParameter("cgiUrl");
			  	String cgiStr[] = cgiUrl.split(",");
			  	
			  	for(int i = 0; i < cgiStr.length; i++){
			  		if(!cgiStr[i].equals("")){
			  			//cgi범례이미지
			  			//기상청에서는 request.getServerName() 으로 접근할수 없기때문에 이렇게 처리
			  			String localHost = InetAddress.getLocalHost().toString();
			  			String cgiTmp = "http://"+localHost.substring(6, localHost.length())+":"+request.getServerPort() + cgiStr[i];
			  			
			  			//cgi범례이미지
						//사내테스트하기위한 방식
			  			//String cgiTmp =  "http://"+request.getServerName()+":"+request.getServerPort() + cgiStr[i];
			  			//cgiTmp = "http://172.20.132.101:9999" + cgiStr[i];
			  			
			  			URL url = new URL(cgiTmp);
			  			legendImg = ImageIO.read(url);
			  			legendImgList.add(legendImg);
			  		}
			  	}
		  		//cgi이미지
	  			BufferedImage cgiImg = ImageIO.read(file);
		  		
		  		int legendImgWidth = 0;	  		
		  		for(int j = 0; j < legendImgList.size(); j++){
		  			legendImgWidth += legendImgList.get(j).getWidth();
		  		}
		  		int width = cgiImg.getWidth() + legendImgWidth;
		  		int height = cgiImg.getHeight();
		  		
	  			String fileNameTmp = file.getName();
	  			int pos = fileNameTmp.lastIndexOf(".");
	  			String fileExt = fileNameTmp.substring(pos+1);
	  			fileName = fileNameTmp.substring(0, pos);
	  			String fileRealName = path.substring(0, path.length() - file.getName().length()) +
								fileName + "_legend" + "." + fileExt; //범례를 포함한 파일 생성
									
	  			//합친이미지
		  		BufferedImage mergeImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
	  			
	  			Graphics2D graphics = (Graphics2D) mergeImg.getGraphics();
	  			for(int j = 0; j < legendImgList.size(); j++){
		  			graphics.drawImage(legendImgList.get(j), cgiImg.getWidth()+legendImgList.get(j).getWidth()*j, 0, null);
	  			}
	  			
	  			graphics.fillRect(0, 0, cgiImg.getWidth(), cgiImg.getHeight());
	  			graphics.setBackground(Color.WHITE);
	  			graphics.drawImage(cgiImg, 0, 0, null);
	  			
	  			mergeImgFile = new File(fileRealName);
	  			ImageIO.write(mergeImg, "png", mergeImgFile);
				
				
				is = new FileInputStream(mergeImgFile);
				String filename = file.getName();
				long filesize = mergeImgFile.length();
				// 다운로드 버퍼 크기 
				int BUFFER_SIZE = 8192; // 8kb
				String CHARSET = "UTF-8"; // 문자 인코딩;
				String mime = mimetype;

				if (mimetype == null || mimetype.length() == 0) mime = "application/octet-stream;";
				byte[] buffer = new byte[BUFFER_SIZE];

				response.setContentType(mime + "; charset=" + CHARSET);

				// 아래 부분에서 euc-kr 을 utf-8 로 바꾸거나 URLEncoding을 안하거나 등의 테스트를
				// 해서 한글이 정상적으로 다운로드 되는 것으로 지정한다.
				String userAgent = request.getHeader("User-Agent");
	
				// attachment; 가 붙으면 IE의 경우 무조건 다운로드창이 뜬다. 상황에 따라 써야한다.
				if (userAgent != null && userAgent.indexOf("MSIE 5.5") > -1) { // MS IE 5.5 이하
				  response.setHeader("Content-Disposition", "filename=" + URLEncoder.encode(filename, "UTF-8") + ";");
				} else if (userAgent != null && userAgent.indexOf("MSIE") > -1) { // MS IE (보통은 6.x 이상 가정)
				  response.setHeader("Content-Disposition", "attachment; filename="
					  + java.net.URLEncoder.encode(filename, "UTF-8") + ";");
				} else { // 모질라나 오페라
				  response.setHeader("Content-Disposition", "attachment; filename="
					  + new String(filename.getBytes(CHARSET), "latin1") + ";");
				}

				// 파일 사이즈가 정확하지 않을때는 아예 지정하지 않는다.
				if (filesize > 0) {
				  response.setHeader("Content-Length", "" + filesize);
				}

				BufferedInputStream fin = null;
				BufferedOutputStream outs = null;
			
				try {
				
				  fin = new BufferedInputStream(is);
				  outs = new BufferedOutputStream(response.getOutputStream());
				  int read = 0;
	
				  while ((read = fin.read(buffer)) != -1) {
					outs.write(buffer, 0, read);
				  }
				} catch (IOException ex) {
					// Tomcat ClientAbortException을 잡아서 무시하도록 처리해주는게 좋다.
				} finally {
					if(outs != null) outs.close();
					if(fin != null) fin.close();
				  
				}
			  
			
			} catch(Exception e){
				e.printStackTrace();
			} finally {
				if(is != null) is.close();
			}
			
			//파일 삭제;
			removeDirectory( path );
		}
		
		
	}
	
	/**
	 * @Method Name : removeDirectory
	 * @date,  2018. 9. 7.
	 * @author 강혜리
	 * @description 
	 *	디렉토리 삭제 ( 내부파일도 모두 삭제 )
	 * @param folder
	 * @return boolean
	 */
	public boolean removeDirectory( String folder ){
		boolean result = false;
		try
		{
			File file = new File( folder );
			if( ! file.exists() ) return result;

			if( file.isDirectory() )
			{
				if( file.list().length == 0 ) file.delete();
				else
				{
					String files[] = file.list();
					for( String temp : files ) removeDirectory( folder + "/" + temp );
					if( file.list().length == 0 ) file.delete();
				}
			}
			else file.delete();
			result = true;
		}
		catch( Exception e )
		{
			System.out.println("============ e : " + e);
		}
		return result;
	}
	
}