package kres.us.cmmn.service;

public class UsTyphoonRouteVO {
	private int 			ID 		= 0;
	private String			LST		= "";
	private String			UTC		= "";
	private float 			LAT		= 0;
	private float 			LON		= 0;
	private String			DIR		= "";
	private float 			SPEED	= 0;
	private String			MEMO	= "";
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getLST() {
		return LST;
	}
	public void setLST(String lST) {
		LST = lST;
	}
	public String getUTC() {
		return UTC;
	}
	public void setUTC(String uTC) {
		UTC = uTC;
	}
	public float getLAT() {
		return LAT;
	}
	public void setLAT(float lAT) {
		LAT = lAT;
	}
	public float getLON() {
		return LON;
	}
	public void setLON(float lON) {
		LON = lON;
	}
	public String getDIR() {
		return DIR;
	}
	public void setDIR(String dIR) {
		DIR = dIR;
	}
	public float getSPEED() {
		return SPEED;
	}
	public void setSPEED(float sPEED) {
		SPEED = sPEED;
	}
	public String getMEMO() {
		return MEMO;
	}
	public void setMEMO(String mEMO) {
		MEMO = mEMO;
	}
	
}
