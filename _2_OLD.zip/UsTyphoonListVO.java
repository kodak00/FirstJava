package kres.us.cmmn.service;

//oskim 20190804 new file
public class UsTyphoonListVO {
	private int nID = 0;
	private int nYear = 0;
	private String strTyphoonName = "";
	private String strTyphoonInfo = "";
	
	public int getnID() {
		return nID;
	}
	public void setnID(int nID) {
		this.nID = nID;
	}
	public int getnYear() {
		return nYear;
	}
	public void setnYear(int nYear) {
		this.nYear = nYear;
	}
	public String getStrTyphoonName() {
		return strTyphoonName;
	}
	public void setStrTyphoonName(String strTyphoonName) {
		this.strTyphoonName = strTyphoonName;
	}
	public String getStrTyphoonInfo() {
		return strTyphoonInfo;
	}
	public void setStrTyphoonInfo(String strTyphoonInfo) {
		this.strTyphoonInfo = strTyphoonInfo;
	}

}
