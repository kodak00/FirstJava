#ifndef MAKE_LGT_DSTRIBUTION_FILE_H_
#define MAKE_LGT_DSTRIBUTION_FILE_H_

#include <stdlib.h>
#include <limits.h>


#include "common/macro.h"
#include "common/APP_I.h"
#include "INI_I.h"

#define APP_VERSION "0.1"
#define APP_AUTHOR "SafeKorea"


struct _app_conf
{
    struct tm tm_reqTime;

	char input_lgt_kma_path[PATH_MAX];
	char input_lgt_kar_path[PATH_MAX];
	char input_lgt_kpx_path[PATH_MAX];

	char output_lgt_kma_year_path[PATH_MAX];
	char output_lgt_kar_year_path[PATH_MAX];
	char output_lgt_kpx_year_path[PATH_MAX];

	char output_lgt_kma_month_path[PATH_MAX];
	char output_lgt_kar_month_path[PATH_MAX];
	char output_lgt_kpx_month_path[PATH_MAX];

	char output_lgt_kma_day_path[PATH_MAX];
	char output_lgt_kar_day_path[PATH_MAX];
	char output_lgt_kpx_day_path[PATH_MAX];
};

extern void read_childproc(int sig);
extern int conf_proc();
extern void init_proc();
extern void main_proc();
extern void end_proc();
extern char *strn_token(char *args, int n, int idx, char *delim);
extern int opt_proc(int argc, char** argv);

extern char *strptime(const char *s, const char *format, struct tm *tm);

#endif /* MAKE_LGT_CNT_FILE_H_ */
