#include "lgt_distribution_file.h"

char *strn_token(char *args, int n, int idx, char *delim)
{
	static char values[10][255] = {};
	char file_name[1024] = {};
	char temp[1024] = {};
	char *ptr = NULL;
	char *token = NULL;
	int i = 0;

	if ( args == NULL)
		return NULL;

	sprintf(temp, "%s", args);
	sprintf(file_name, "%s", basename(temp));
	ptr = file_name;
	token = strsep(&ptr, delim);

	while(token != NULL)
	{
		sprintf(values[i], "%s", token);
		token = strsep(&ptr, delim);
		i++;
	}

	values[idx][n] = '\0';

	return values[idx];
}

int opt_proc(int argc, char** argv)
{
	extern struct _app_conf app_conf;
	char temp[512] = {};

	sprintf(temp  , "%s", strn_token(argv[1],  12, 3, "_"));

	strptime(temp, "%Y%m%d%H%M", &app_conf.tm_reqTime);

	return 0;
}
