/*************************************************************************
                                radar_comm

레이더 합성 프로그램 용 기본 라이브러리

                                                                    이정훈

2004.  .  . :	완성
2005.  .  . :	수정
2006.  .  . :	수정
2007. 7.  . :	확대/축소를 위한 코드 수정
2007. 7.16. :	VIL을 위한 코드 수정(KRL_volume_to_vil,KRL_sweep_to_cart_for_vil)
				beam의 고도 계산 추가(beam_height_km)
*************************************************************************/

#include <time.h>
//#include "/usr/local/trmm/GVBOX/include/rsl.h"
#include "rsl.h"

//2014.09 환경파일 통합
//#define CONFIG_PATH "/DATA/APPS_2014/etc/"
//#define CONFIG_FILE "apps.conf"

#define BAD_VALUE_F  (-9999.)
#define OUT_VALUE_F  (-9998.)

#ifndef MAX_STRING_LENGTH
#define	MAX_STRING_LENGTH	(1024)	//일반적 문자열의 최대값(path표출을	위해 길게 정의함)
#endif
#ifndef COLOR_TYPE
#define COLOR_TYPE
typedef	struct
{
	unsigned char	R;	//Red
	unsigned char	G;	//Green
	unsigned char	B;	//Blue
}COLOR;
#endif

#define	MAP_RE	(6371.00877)			//디지털예보에서 사용하는 지구 반경(km)
#define PI_DFS	(3.141592)

#ifndef _DEFINE_KRL_RADAR_
#define _DEFINE_KRL_RADAR_
typedef struct 
{
	char file_type[10];
	unsigned short version;
	char site_initial[6];
	int xdim;
	int ydim;
	int range;
	int height;
	float lat;
	float lon;
	char data_type[2];
	char spare_head_byte[28];
}KRL_RADAR_HEAD;

typedef struct
{
	KRL_RADAR_HEAD head;
	float* data;
}KRL_RADAR;

typedef struct
{
	KRL_RADAR_HEAD head;
	float* data;
}KRL_RAIN_RADAR;
#endif

#define DEFAULT_ZR_A	(200.)
#define DEFAULT_ZR_B	(1.6)

/* From Gunn and East, 1954, 0.0044R^1.17 */
#define DEFAULT_C_BAND_COR_A 0.0044
#define DEFAULT_C_BAND_COR_B 1.17

typedef enum {REAL_CAPPI, PSEUDO_CAPPI} CAPPI_TYPE;

/*********************************************************************************
	dateutils.c
*********************************************************************************/
//struct tm incYearN(struct tm *tm_ptr,struct tm *new_tm_ptr,int addYear);
struct tm incSec(struct tm tm_ptr, int addSec);
struct tm incMin(struct tm tm_ptr,int addMin);
struct tm incHour(struct tm tm_ptr,int addHour);
struct tm incDay(struct tm tm_ptr,int addDay);
struct tm incMonth(struct tm tm_ptr,int addMonth);
struct tm convStrToDateTime(char *str);
int datecmp(struct tm tm1, struct tm tm2);
struct tm now();
char* UTC_to_KST_string(char* UTC_string);
char* UTC_to_KST_int(int year_utc,int month_utc,int day_utc,int hour_utc,int minute_utc,int sec_utc
					,int *year_kst,int *month_kst,int *day_kst,int *hour_kst,int *minute_kst,int *sec_kst);

/*********************************************************************************
	inifiles.c
*********************************************************************************/
#ifndef MAX_INI_LIST_COUNT
#define MAX_INI_LIST_COUNT 32
#endif

int create_ini_file(char* filename);
int destroy_ini_file();

char* read_ini_string(char* section, char* Title, char* default_Value);

int read_ini_int(char* section, char* Title, int default_Value);
float read_ini_float(char* section, char* Title, float default_Value);

COLOR read_ini_COLOR(char* Title);

char** get_comma_list(char* strings,int* in_count);

void trim2(char** in_string);


/*********************************************************************************
	utils.c
*********************************************************************************/
//합성 지도 파일 읽음(COMPOSITION.map_data)-create_comp_map으로 생성
int read_composition_map();

//합성 지도 파일 읽음(COMPOSITION.map_data)-create_comp_map으로 생성
int read_composition_map_2km();

int read_composition_map_5km();
//src에서 dest로 index부터 count개수만큼 복사하여 리턴함.
char* strnmcpy(char* dest, const char* src, int index, int count);

//string에서 sub_string이 있는 위치 리턴함
int pos(char* sub_string,char* string);
int poscase(char* sub_string,char* string);

//string에서 sub_string이 n번째 있는 위치 리턴함
int posn(char* sub_string,char* string,int n);

//in_string 앞뒤 공백 제거
char* trim(char* in_string);
void trim2(char** in_string);

//fileName파일이 있는지 검사(0/1)
int fileExists(char* fileName);

//파일 경로와 이름이 같이 있는 문자열에서 파일 이름만 가져옴.
char *extractFilename(char *filePathName);

int big_endian(void);
int little_endian(void);
void swap_4_bytes(void *word);
void swap_2_bytes(void *word);

COLOR color_to_gray(COLOR color);

char to_big_letter(char c);
char to_small_letter(char C);


/*********************************************************************************
	radar.c
*********************************************************************************/
//독립 에코 제거
int del_indenpent_echo(float *imsi_data,int xdim,int ydim);
//Azimuth Correction
int azimuth_correction(Radar *radar,float corr_value);
//uf 파일을 radar format 파일로 저장함
int write_anyformat_to_radar(char* anyformat_filename, char* radarformat_filename);

//uf 파일을 radar format 파일로 저장함(gzip)
int	write_anyformat_to_radar_gzip(char* anyformat_filename, char* radarformat_filename);
//C-band 보정
int	c_band_attenuation_correction(Volume* v, float cor_A, float cor_B);

//dBZ(unsigned char)를 Ze(double)로 바꿈.
double dBZ_to_Ze(unsigned char dBZ);
double dBZ_to_Ze_s(char dBZ);
double dBZ_to_Ze_f(double dBZ);

//Ze(double)를 dBZ(unsigned char)로 바꿈.
unsigned char Ze_to_dBZ(double Ze);
char Ze_to_dBZ_s(double Ze);
double Ze_to_dBZ_f(double Ze);

//dBZ(unsigned char)를 R(double)로 바꿈.
double dBZ_to_R(unsigned char dBZ,float zr_a,float zr_b);
double dBZ_to_R_s(char dBZ,float zr_a,float zr_b);
double dBZ_to_R_f(double dBZ,float zr_a,float zr_b);

//RAIN -> dBZ
unsigned char R_to_dBZ(double R,float zr_a,float zr_b);
char R_to_dBZ_s(double R,float zr_a,float zr_b);
double R_to_dBZ_f(double R,float zr_a,float zr_b);

float deg_60_to_100(float angle60);
float deg_60_to_100_2(int deg,int min,int sec);

//get beam height
float beam_height_km(float el, float r);

/*********************************************************************************
	cappi.c
*********************************************************************************/
//Mohr방식을 이용한 CAPPI만들기(radar_cappi.c)
						//Volume		cappi고도(km)  , X 크기 , Y 크기  ,관측거리(km),격자크기(km)
float* KRL_cappi_at_h_cart(Volume* volume,float height,int xdim, int ydim, int range,float grid_size,CAPPI_TYPE pseudo_cappi,int is_dBZ);

//x,y,z 한지점에 대한 값 가져옴(x,y = 격자위치, z=meter) - Mohr 알고리즘 사용
float cross_mohr_get_data(Volume* volume,int xdim, int ydim, int range, float grid_size_km, float x, float y, float z, int pseudo_value,int is_dBZ);

//x,y,z 한지점에 대한 값 가져옴(x,y = 격자위치, z=meter)
float cross_get_data(Volume* volume,int xdim, int ydim, int range, float grid_size_km, float x, float y, float z);

float get_azimuth(float x,float y);

/*********************************************************************************
	check_uffile.c
*********************************************************************************/
int check_uffile(char* filename);

/*********************************************************************************
	KRL_radar.c
*********************************************************************************/
//BASE
float* KRL_volume_to_base(Volume* volume, int xdim, int ydim, int range);

//CMAX
float* KRL_volume_to_cmax(Volume* volume, int xdim, int ydim, int range);

//ETOP
float* KRL_volume_to_etop(Volume* volume, int xdim, int ydim, int range,int radar_height,float etop_min_threshold);

KRL_RADAR* KRL_read_radar(char* filename);
void KRL_free_radar(KRL_RADAR* krl_radar);
int KRL_write_radar(char* filename,KRL_RADAR* krl_radar);

//RSL은 char *를 돌려주는데 float *를 돌려주도록 수정함.
float *KRL_sweep_to_cart(Sweep *s, int xdim, int ydim, float range);

//VIL을 위한 cart만들기
float *KRL_sweep_to_cart_for_vil(Sweep *s, int xdim, int ydim, float range, float top_h_km, float bottom_h_km);

//xs1,ys1부터 xdim2와 ydim2의 영역에 해당되는 부분만 돌려줌.
unsigned char *KRL_sweep_to_cart1(Sweep *s, int xdim, int ydim, float range, int xs1, int ys1, int xdim2, int ydim2);
float *KRL_sweep_to_cart2(Sweep *s, int xdim, int ydim, float range, int xs1, int ys1, int xdim2, int ydim2);
//xdim,ydim : 해당 격자 해상도일때의 전체 관측 반경의 X,Y크기
//range : 해당 격자 해상도일때 전체 관측 반경의 거리
//xs1,ys1 : 해당 격자 해상도일때 출력하고자 하는 X,Y의 시작위치
//xdim2,ydim2 : 해당 격자 해상도일때 출력하고자 하는 X,Y의 크기


//VIL
float* KRL_volume_to_vil(Volume* volume, int xdim, int ydim, int range,int top_h_km, int bottom_h_km);

//SWEEP에서 하나의 값만 리턴한다.
float sweep_get_data(Sweep* sweep,int xdim, int ydim, int range, float grid_size_km, float x, float y);
