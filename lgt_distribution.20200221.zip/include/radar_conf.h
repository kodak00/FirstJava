#define CONFIG_PATH "/rdr/src/radar/lgt_distribution/res"
#define CONFIG_FILE "apps.conf"
