#include "APP_I.h"

void APP_I_APP_INIT(int argc, char** argv)
{
    char buff[PATH_MAX] = {};
    char* ptr = NULL;

    APP->_.app_name = program_invocation_short_name;

    APP->_.app_home = basename(program_invocation_name);

    APP->_.argc = argc;

    APP->_.argv = argv;

    APP->_.app_home = getenv("APP_HOME");
    if (APP->_.app_home == NULL)
    {
    //    APP->_.app_home = getenv("HOME");
      sprintf(buff, "/rdr/src/radar");
       APP->_.app_home = strdup(buff);
     }

    APP->_.app_user = getenv("APP_USER");
    if (APP->_.app_user == NULL)
    {
        APP->_.app_user = getenv("USER");
    }

    APP->_.app_conf = getenv("APP_CONF");
    if (APP->_.app_conf == NULL)
    {
        sprintf(buff, "%s/lgt_distribution/res/apps.conf", APP->_.app_home);
        APP->_.app_conf = strdup(buff);
    }


    ptr = getenv("APP_LOG");
    if (ptr == NULL)
    {
        sprintf(buff, "%s/lgt_distribution/log/%s/%%Y%%m%%d.txt", APP->_.app_home, APP->_.app_name);
        APP->_.app_logpath = strdup(buff);
    }
    else
    {
        sprintf(buff, "%s/%s/%%Y%%m%%d.txt", ptr, APP->_.app_name);
        APP->_.app_logpath = strdup(buff);
    }

    APP->_.verbose = 0;

    /*
    {
    struct rlimit rlim = {};

    // stack memory size limit change
    getrlimit(RLIMIT_STACK, &rlim);
    rlim.rlim_cur = 1024 * 1024;
    setrlimit(RLIMIT_STACK, &rlim);
    }
     */

    return;
}

void APP_I_APP_END()
{

    return;
}

APP_I APP_I_INSTANCE = {
    .APP_INIT = APP_I_APP_INIT,
    .APP_END = APP_I_APP_END
};

APP_I* APP = &APP_I_INSTANCE;
