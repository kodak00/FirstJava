/* 
 * File:   TXT_SRFW_VO.h
 * Author: lucid32
 *
 * Created on 2014년 8월 9일 (토), 오후 11:41
 */

#ifndef TXT_SRFW_VO_H
#define	TXT_SRFW_VO_H

#ifdef	__cplusplus
extern "C"
{
#endif

#include "common/macro.h"


#define TXT_SRFW_XDIM 249
#define TXT_SRFW_YDIM 353
#define TXT_SRFW_ZDIM 1

#define TXT_SRFW_UNDEF  -999.0
#define TXT_SRFW_ALT    1500.0
#define TXT_SRFW_HEIGHT   10.0

typedef struct _TXT_SRFW_VO TXT_SRFW_VO;
typedef struct _TXT_SRFW_VO_T TXT_SRFW_VO_T;

/**
 * /DATA/OUTPUT/TXT/SRFW
 * @return 
 */
extern TXT_SRFW_VO* newTXT_SRFW_VO();
extern int TXT_SRFW_VO_GZWRITE(TXT_SRFW_VO* obj, const char* filepath);

struct _TXT_SRFW_VO
{

    struct _TXT_SRFW_VO_T
    {
        float nX;
        float nY;
        float nZ;

        struct
        {
            float u;
            float v;
        } data[TXT_SRFW_YDIM][TXT_SRFW_XDIM];
    } __attribute__((packed)) _;

    int (*GZWRITE)(TXT_SRFW_VO* obj, const char* filepath);

    void (*DISPOSE)(TXT_SRFW_VO** pObj);
};


#ifdef	__cplusplus
}
#endif

#endif	/* TXT_SRFW_VO_H */

