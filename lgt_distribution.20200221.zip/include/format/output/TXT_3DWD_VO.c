#include "TXT_3DWD_VO.h"

int TXT_3DWD_VO_GZREAD(TXT_3DWD_VO* obj, const char* filepath)
{
    gzFile *zfp = NULL;

    zfp = gzopen(filepath, "rb");
    if (unlikely(zfp == NULL))
    {
        _strerror;
        return -1;
    }
    else
    {
        int z = 0, y = 0, x = 0;
        char buff[TXT_3DWD_ROW_SIZE + 1] = {};

        if (unlikely(gzgets(zfp, buff, 512) == Z_NULL))
        {
            goto ZFP_EXCEPTION;
        }

        sscanf(buff, "%f %f %f", &obj->_.nX, &obj->_.nY, &obj->_.nZ);

        //gzread(zfp, buff, TXT_3DWD_ROW_SIZE); // BUG!! need to remove

        if (obj->_.nZ != (float) TXT_3DWD_ZDIM || obj->_.nY != (float) TXT_3DWD_YDIM || obj->_.nX != (float) TXT_3DWD_XDIM)
        {
            fprintf(stderr, "[ERROR]: %s(%s:%d): Z, Y, X size different!!\n", __FILE__, __func__, __LINE__);
            return -1;
        }

        for (z = 0; z < obj->_.nZ; z++)
        {
            for (y = 0; y < obj->_.nY; y++)
            {
                for (x = 0; x < obj->_.nX; x++)
                {
                    if (unlikely(gzread(zfp, buff, TXT_3DWD_ROW_SIZE) <= 0))
                    {
                        goto ZFP_EXCEPTION;
                    }

                    sscanf(buff, "%f %f %f", &obj->_.data[z][y][x].u, &obj->_.data[z][y][x].v, &obj->_.data[z][y][x].w);
                }
            }
        }

        gzclose(zfp);
    }

    return 0;

ZFP_EXCEPTION:
    if (likely(zfp != NULL))
    {
        gzclose(zfp);
    }

    return -1;
}

void TXT_3DWD_VO_DISPOSE(TXT_3DWD_VO** pObj)
{
    _dispose(pObj);

    return;
}

void initTXT_3DWD_VO(TXT_3DWD_VO* obj)
{
    obj->GZREAD = TXT_3DWD_VO_GZREAD;
    obj->DISPOSE = TXT_3DWD_VO_DISPOSE;

    return;
}

TXT_3DWD_VO* newTXT_3DWD_VO()
{
    TXT_3DWD_VO* obj = calloc(1, sizeof (TXT_3DWD_VO));

    if (unlikely(obj == NULL))
    {
        _strerror;
    }
    else
    {
        initTXT_3DWD_VO(obj);

    }

    return obj;
}