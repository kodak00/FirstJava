#include "RDR_VO.h"

/**
 * 
 * @param obj
 * @param filepath
 * @return 
 */
int RDR_VO_GZREAD(RDR_VO* obj, const char* filepath)
{
    gzFile zfp = NULL;

    zfp = gzopen(filepath, "r");
    if (unlikely(zfp == NULL))
    {
        _strerror;
        return -1;
    }
    else
    {
        if (gzread(zfp, obj->_.data, RDR_VO_YDIM * RDR_VO_XDIM * sizeof (int8_t)) == -1)
        {
            goto ZFP_EXCEPTION;
        }

        gzclose(zfp);
    }

    return 0;

ZFP_EXCEPTION:
    if (zfp != NULL)
    {
        gzclose(zfp);
    }
    return -1;
}

void RDR_VO_DISPOSE(RDR_VO** pObj)
{
    _dispose(pObj);

    return;
}

void initRDR_VO(RDR_VO* obj)
{
    obj->GZREAD = RDR_VO_GZREAD;

    obj->DISPOSE = RDR_VO_DISPOSE;

    return;
}

RDR_VO* newRDR_VO()
{
    RDR_VO* obj = calloc(1, sizeof (RDR_VO));
    if (unlikely(obj == NULL))
    {
        _strerror;
        return NULL;
    }
    else
    {
        initRDR_VO(obj);
    }

    return obj;
}

inline float RDR_VO_R_to_dBZ_f(float rain, float zr_a, float zr_b)
{

    return (10 * log10(zr_a) + (zr_b * 10) * log10(rain));
}

inline float RDR_VO_dBZ_to_R_f(float dBZ, float zr_a, float zr_b)
{
    return (pow(pow(10.0, (dBZ / 10.0)) / zr_a, 1.0 / zr_b));
}

double RDR_VO_calc_val(double jj, double ii, double fx, double fy, double fz, double fw)
{
    double dd = 0;
    double x0 = 0;
    double x1 = 0;

    x0 = fx + (fw - fx) * (double) jj / 1.0;
    x1 = fy + (fz - fy) * (double) jj / 1.0;
    dd = x0 + (x1 - x0) * (double) ii / 1.0;

    return dd;
}

double RDR_VO_calc_radar_value(RDR_VO* rdr, int i, int j, int xdim, int ydim)
{
    double fi, fj;
    double fdi, fdj;
    double fx = 0;
    double fy = 0;
    double fz = 0;
    double fw = 0;
    double fval = 0;
    int di = 0;
    int dj = 0;

    fi = i * ((double) RDR_VO_XDIM / (double) xdim);
    //fj = (RDR_YDIM - 1) - (j * ((double) RDR_YDIM / (double) ydim));
    fj = j * ((double) RDR_VO_YDIM / (double) ydim);

    di = (int) fi;
    dj = (int) fj;

    if (rdr->_.data[dj][di] == RDR_VO_BOUND)
    {
        return RDR_VO_BOUND;
    }

    if (fi == di && fj == dj)
    {
        fval = rdr->_.data[dj][di];
    }
    else
    {
        fdi = fi - di;
        fdj = fj - dj;

        if (fdi == 0.0 && fdj != 0.0)
        {
            if (rdr->_.data[dj + 1][di + 0] == RDR_VO_BAD_VAL)
            {
                fx = 0;
            }
            else
            {
                fx = rdr->_.data[dj + 1][di + 0];
            }
            if (rdr->_.data[dj + 1][di + 1] == RDR_VO_BAD_VAL)
            {
                fy = 0;
            }
            else
            {
                fy = rdr->_.data[dj + 1][di + 1];
            }
            if (rdr->_.data[dj + 0][di + 1] == RDR_VO_BAD_VAL)
            {
                fz = 0;
            }
            else
            {
                fz = rdr->_.data[dj + 0][di + 1];
            }
            if (rdr->_.data[dj + 0][di + 0] == RDR_VO_BAD_VAL)
            {
                fw = 0;
            }
            else
            {
                fw = rdr->_.data[dj + 0][di + 0];
            }
            fdj = 1.0 - fdj;

            if (rdr->_.data[dj + 1][di + 0] == RDR_VO_BOUND && rdr->_.data[dj + 1][di + 1] == RDR_VO_BOUND &&
                rdr->_.data[dj + 0][di + 1] == RDR_VO_BOUND && rdr->_.data[dj + 0][di + 0] == RDR_VO_BOUND)
            {
                fval = RDR_VO_BOUND;
            }
            else if (rdr->_.data[dj + 1][di + 0] <= RDR_VO_BAD_VAL && rdr->_.data[dj + 1][di + 1] <= RDR_VO_BAD_VAL &&
                rdr->_.data[dj + 0][di + 1] <= RDR_VO_BAD_VAL && rdr->_.data[dj + 0][di + 0] <= RDR_VO_BAD_VAL)
            {
                fval = RDR_VO_BAD_VAL;
            }
            else
            {
                fval = RDR_VO_calc_val(fdj, fdi, fx, fy, fz, fw) + 0.5;
            }

        }
        else if (fdi != 0.0 && fdj == 0.0)
        {
            if (rdr->_.data[dj + 0][di + 0] == RDR_VO_BAD_VAL) fx = 0;
            else fx = rdr->_.data[dj + 0][di + 0];

            if (rdr->_.data[dj + 0][di + 1] == RDR_VO_BAD_VAL) fy = 0;
            else fy = rdr->_.data[dj + 0][di + 1];

            if (rdr->_.data[dj - 1][di + 1] == RDR_VO_BAD_VAL) fz = 0;
            else fz = rdr->_.data[dj - 1][di + 1];

            if (rdr->_.data[dj - 1][di + 0] == RDR_VO_BAD_VAL) fw = 0;
            else fw = rdr->_.data[dj - 1][di + 0];

            if (rdr->_.data[dj + 0][di + 0] == RDR_VO_BOUND && rdr->_.data[dj + 0][di + 1] == RDR_VO_BOUND &&
                rdr->_.data[dj - 1][di + 1] == RDR_VO_BOUND && rdr->_.data[dj - 1][di + 0] == RDR_VO_BOUND)
            {
                fval = RDR_VO_BOUND;
            }
            else if (rdr->_.data[dj + 0][di + 0] <= RDR_VO_BAD_VAL && rdr->_.data[dj + 0][di + 1] <= RDR_VO_BAD_VAL &&
                rdr->_.data[dj - 1][di + 1] <= RDR_VO_BAD_VAL && rdr->_.data[dj - 1][di + 0] <= RDR_VO_BAD_VAL)
            {
                fval = RDR_VO_BAD_VAL;
            }
            else
            {
                fval = RDR_VO_calc_val(fdj, fdi, fx, fy, fz, fw) + 0.5;
            }
        }
        else if (fdi != 0.0 && fdj != 0.0)
        {
            if (rdr->_.data[dj + 1][di + 0] == RDR_VO_BAD_VAL) fx = 0;
            else fx = rdr->_.data[dj + 1][di + 0];
            if (rdr->_.data[dj + 1][di + 1] == RDR_VO_BAD_VAL) fy = 0;
            else fy = rdr->_.data[dj + 1][di + 1];
            if (rdr->_.data[dj + 0][di + 1] == RDR_VO_BAD_VAL) fz = 0;
            else fz = rdr->_.data[dj + 0][di + 1];
            if (rdr->_.data[dj + 0][di + 0] == RDR_VO_BAD_VAL) fw = 0;
            else fw = rdr->_.data[dj + 0][di + 0];

            fdj = 1.0 - fdj;

            if (rdr->_.data[dj + 1][di + 0] == RDR_VO_BOUND && rdr->_.data[dj + 1][di + 1] == RDR_VO_BOUND &&
                rdr->_.data[dj + 0][di + 1] == RDR_VO_BOUND && rdr->_.data[dj + 0][di + 0] == RDR_VO_BOUND)
            {
                fval = RDR_VO_BOUND;
            }
            else if (rdr->_.data[dj + 1][di + 0] <= RDR_VO_BAD_VAL && rdr->_.data[dj + 1][di + 1] <= RDR_VO_BAD_VAL &&
                rdr->_.data[dj + 0][di + 1] <= RDR_VO_BAD_VAL && rdr->_.data[dj + 0][di + 0] <= RDR_VO_BAD_VAL)
            {
                fval = RDR_VO_BAD_VAL;
            }
            else
            {
                fval = RDR_VO_calc_val(fdj, fdi, fx, fy, fz, fw) + 0.5;
            }
        }
    }

    return fval;
}
