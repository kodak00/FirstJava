#include "DSTR_VO.h"

int DSTR_VO_GZREAD(DSTR_VO* obj, const char* filepath)
{
    gzFile zfp = NULL;

    zfp = gzopen(filepath, "r");
    if (unlikely(zfp == NULL))
    {
        _strerror;
        return -1;
    }
    else
    {
        if (gzread(zfp, &obj->_.data, XDIM * YDIM * sizeof (int)) <= 0)
        {
            goto ZFP_EXCEPTION;
        }
        /*/
        int i, j;
        for (j = 0; j < YDIM; j++)
        {
            for (i = 0; i < XDIM; i++)
            {
                if (gzread(zfp, &obj->_.data[j][i], sizeof (int)) < 0)
                {
                    fprintf("write file error!\n");
                }
            }
        }
        //*/
        gzclose(zfp);
    }

    return 0;

ZFP_EXCEPTION:

    if (zfp != NULL)
    {
        gzclose(zfp);
    }

    return -1;
}

int DSTR_VO_GZWRITE(DSTR_VO* obj, const char* filepath, const char* _mode)
{
    gzFile zfp = NULL;

    zfp = gzopen(filepath, _mode);
    if (unlikely(zfp == NULL))
    {
        _strerror;
        return -1;
    }
    else
    {
        //gzsetparams(zfp, OUTPUT_COMPRESSION_LEVEL, Z_DEFAULT_STRATEGY);

        if (gzwrite(zfp, &obj->_.data, XDIM * YDIM * sizeof (int)) < 0)
        {
            //fprintf("write file error!\n");
            goto ZFP_EXCEPTION;
        }
        /*//
        int i, j;
        for (j = 0; j < YDIM; j++)
        {
            for (i = 0; i < XDIM; i++)
            {
                if (gzwrite(zfp, &obj->_.data[j][i], sizeof (int)) < 0)
                {
                    //fprintf("write file error!\n");
                }
            }
        }
        //*/

        gzclose(zfp);
    }

    return 0;

ZFP_EXCEPTION:

    if (zfp != NULL)
    {
        gzclose(zfp);
    }

    return -1;
}

void DSTR_VO_DISPOSE(DSTR_VO** pObj)
{
    _dispose(pObj);

    return;
}

void initDSTR_VO(DSTR_VO* obj)
{
    obj->GZREAD = DSTR_VO_GZREAD;

    obj->GZWRITE = DSTR_VO_GZWRITE;

    obj->DISPOSE = DSTR_VO_DISPOSE;

    return;
}

DSTR_VO* newDSTR_VO()
{
    DSTR_VO* obj = calloc(1, sizeof (DSTR_VO));
    if (unlikely(obj == NULL))
    {
        _strerror;
    }
    else
    {
        initDSTR_VO(obj);
    }

    return obj;
}
