/* 
 * File:   BASI_VO.h
 * Author: lucid32
 *
 * Created on 2014년 8월 14일 (목), 오후 10:10
 */

#ifndef BASI_VO_H
#define	BASI_VO_H

#ifdef	__cplusplus
extern "C"
{
#endif

#include "common/macro.h"

typedef struct _BASI_VO BASI_VO;
typedef struct _BASI_VO_T BASI_VO_T;

/**
 * /DATA/OUTPUT/BIN/BASI
 * @return 
 */
extern BASI_VO* newBASI_VO();

struct _BASI_VO
{

    struct _BASI_VO_T
    {
        int totalLen, doLen, siguLen;

        int nData; //총 데이터의 수

        struct
        {
            int code; //지역 코드
            int lgtCount; //낙뢰 총 횟수
            double totalImpact; //강도 총합
            float maxFImpact; //최대 강도
            float minImpact; //최소 강도
        } __attribute__((packed)) *pData;
    } _;

    int(*READ)(BASI_VO* obj, const char* filepath);

    int (*WRITE)(BASI_VO* obj, const char* filepath);

    void (*DISPOSE)(BASI_VO** pObj);
};



#ifdef	__cplusplus
}
#endif

#endif	/* BASI_VO_H */

