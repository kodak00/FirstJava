/* 
 * File:   DSTR_VO.h
 * Author: lucid32
 *
 * Created on 2014년 8월 4일 (월), 오후 8:07
 */

#ifndef DSTR_VO_H
#define	DSTR_VO_H

#ifdef	__cplusplus
extern "C"
{
#endif

#include "common/macro.h"

#define XDIM  960
#define YDIM 1200

typedef struct _DSTR_VO DSTR_VO;
typedef struct _DSTR_VO_T DSTR_VO_T;

/**
 * /DATA/OUTPUT/BIN/DSTR
 * @return 
 */
extern DSTR_VO* newDSTR_VO();

struct _DSTR_VO
{

    struct _DSTR_VO_T
    {
        int data[YDIM][XDIM];
    } __attribute__((packed)) _;

    int (*GZREAD)(DSTR_VO* obj, const char* _filepath);
    int (*GZWRITE)(DSTR_VO* obj, const char* _filepath, const char* _mode);

    void (*DISPOSE)(DSTR_VO** pObj);
};

#ifdef	__cplusplus
}
#endif

#endif	/* DSTR_VO_H */

