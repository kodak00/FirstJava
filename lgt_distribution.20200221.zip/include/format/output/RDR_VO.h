/* 
 * File:   RDR_VO.h
 * Author: lucid32
 *
 * Created on 2014년 8월 13일 (수), 오후 11:07
 */

#ifndef RDR_VO_H
#define	RDR_VO_H

#ifdef	__cplusplus
extern "C"
{
#endif

#include <zlib.h>

#include "common/macro.h"

#define RDR_VO_YDIM 1200
#define RDR_VO_XDIM 960
#define RDR_VO_GRID 1.0

#define RDR_VO_NO_DATA_VALUE -9999
#define RDR_VO_BOUND   -128   //Out of bound
#define RDR_VO_BAD_VAL -127   //bad value

typedef struct _RDR_VO RDR_VO;
typedef struct _RDR_VO_T RDR_VO_T;

/**
 * /DATA/OUTPUT/BIN/ZOQC
 * @return 
 */
extern RDR_VO* newRDR_VO();

extern void initRDR_VO(RDR_VO* obj);
extern int RDR_VO_GZREAD(RDR_VO* obj, const char* filepath);
extern inline float RDR_VO_dBZ_to_R_f(float dBZ, float zr_a, float zr_b);
extern double RDR_VO_calc_radar_value(RDR_VO* rdr, int i, int j, int xdim, int ydim);

struct _RDR_VO
{

    struct _RDR_VO_T
    {
        int8_t data[RDR_VO_YDIM][RDR_VO_XDIM];
    } __attribute__((packed)) _;

    int (*GZREAD)(RDR_VO* obj, const char* filepath);

    void (*DISPOSE)(RDR_VO** pObj);
};


#ifdef	__cplusplus
}
#endif

#endif	/* RDR_VO_H */

