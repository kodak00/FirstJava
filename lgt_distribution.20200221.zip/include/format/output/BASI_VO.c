#include "BASI_VO.h"

int BASI_VO_READ(BASI_VO* obj, const char* filepath)
{
    FILE *fp = NULL;
    int totalLen, doLen, siguLen;
    int i, idx;
    int iCode;
    char cName[BUFSIZ];
    char buff[BUFSIZ] = {};
    BASIN_DATA* basin_data;

    fp = fopen(filepath, "r");
    if (fp == NULL)
    {
        _strerror;
        return -1;
    }
    else
    {
        fgets(buff, sizeof (buff), fp);
        sscanf(buff, "%d %d %d", &totalLen, &doLen, &siguLen);

        basin_data = (BASIN_DATA *) malloc((siguLen) * sizeof (BASIN_DATA));
        for (i = 0; i < siguLen; i++)
        {
            basin_data[i].basinCnt = siguLen;
            basin_data[i].color = -1;
            basin_data[i].code = 0;
            basin_data[i].lgtCnt = 0;
            basin_data[i].totImpact = 0.0;
            basin_data[i].maxImpact = 0.0;
            basin_data[i].minImpact = 999.0;
        }

        idx = 0;
        for (i = 0; i < totalLen; i++)
        {
            if (fgets(buff, sizeof(buff), fp) != NULL)
            {
                if (i >= doLen)
                {
                    sscanf(tmpStr, "%s	%d", cName, &iCode);
                    basin_data[idx].code = iCode;
                    idx++;
                }
            }
        }

        fclose(fp);
    }

    return 0;
}

void BASI_VO_DISPOSE(BASI_VO** pObj)
{
    if (unlikely(pObj == NULL))
    {
        return;
    }
    else
    {
        _free((*pObj)->_.pData);

        _free(*pObj);
    }

    return;
}

void initBASI_VO(BASI_VO* obj)
{
    obj->READ = BASI_VO_READ;
    
    obj->DISPOSE = BASI_VO_DISPOSE;
    
    return;
}

BASI_VO* newBASI_VO()
{
    BASI_VO* obj = calloc(1, sizeof (BASI_VO));
    if (unlikely(obj == NULL))
    {
        _strerror;
        return NULL;
    }
    else
    {
        initBASI_VO(obj);
    }

    return obj;
}
