/* 
 * File:   TXT_3DWD_VO.h
 * Author: lucid32
 *
 * Created on 2014년 8월 9일 (토), 오후 10:54
 */

#ifndef TXT_3DWD_VO_H
#define	TXT_3DWD_VO_H

#ifdef	__cplusplus
extern "C"
{
#endif

#include "common/macro.h"

#define TXT_3DWD_XDIM 249
#define TXT_3DWD_YDIM 353
#define TXT_3DWD_ZDIM 11

#define TXT_3DWD_ROW_SIZE 49

typedef struct _TXT_3DWD_VO TXT_3DWD_VO;
typedef struct _TXT_3DWD_VO_T TXT_3DWD_VO_T;

/**
 * /DATA/OUTPUT/TXT/3DWD
 * @return 
 */
extern TXT_3DWD_VO* newTXT_3DWD_VO();

struct _TXT_3DWD_VO
{

    struct _TXT_3DWD_VO_T
    {
        float nX;
        float nY;
        float nZ;

        struct
        {
            float u;
            float v;
            float w;
        } data[TXT_3DWD_ZDIM][TXT_3DWD_YDIM][TXT_3DWD_XDIM];
    } __attribute__((packed)) _;

    int (*GZREAD)(TXT_3DWD_VO* obj, const char* filepath);
    int (*GZWRITE)(TXT_3DWD_VO* obj, const char* filepath);

    void (*DISPOSE)(TXT_3DWD_VO** pObj);
};


#ifdef	__cplusplus
}
#endif

#endif	/* TXT_3DWD_VO_H */

