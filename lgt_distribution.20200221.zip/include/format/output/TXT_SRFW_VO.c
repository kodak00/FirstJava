
#include "TXT_SRFW_VO.h"

int TXT_SRFW_VO_GZWRITE(TXT_SRFW_VO* obj, const char* filepath)
{
    gzFile zfp = NULL;
    int x, y;
    
    zfp = gzopen(filepath, "wb");
    if (unlikely(zfp == NULL))
    {
        _strerror;
        return -1;
    }
    else
    {
        obj->_.nX = TXT_SRFW_XDIM;
        obj->_.nY = TXT_SRFW_YDIM;
        obj->_.nZ = TXT_SRFW_ZDIM;

        if (gzprintf(zfp, " %d %d %d \n", (int) obj->_.nX, (int) obj->_.nY, (int) obj->_.nZ) <= 0)
        {
            goto ZFP_EXCEPTION;
        }

        for (y = 0; y < TXT_SRFW_YDIM; y++)
        {
            for (x = 0; x < TXT_SRFW_XDIM; x++)
            {
                if (gzprintf(zfp, " %f %f \n", obj->_.data[y][x].u, obj->_.data[y][x].v) <= 0)
                {
                    goto ZFP_EXCEPTION;
                }
            }
        }

        gzclose(zfp);
    }

    return 0;

ZFP_EXCEPTION:

    if (likely(zfp != NULL))
    {
        gzclose(zfp);
    }

    return -1;
}

void TXT_SRFW_VO_DISPOSE(TXT_SRFW_VO** pObj)
{
    _dispose(pObj);

    return;
}

void iniTXT_SRFW_VO(TXT_SRFW_VO* obj)
{
    obj->GZWRITE = TXT_SRFW_VO_GZWRITE;

    obj->DISPOSE = TXT_SRFW_VO_DISPOSE;

    return;
}

TXT_SRFW_VO* newTXT_SRFW_VO()
{
    TXT_SRFW_VO* obj = calloc(1, sizeof (TXT_SRFW_VO));
    if (unlikely(obj == NULL))
    {
        _strerror;
        return NULL;
    }
    else
    {
        iniTXT_SRFW_VO(obj);

    }

    return obj;
}