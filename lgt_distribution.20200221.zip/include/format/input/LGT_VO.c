#include "LGT_VO.h"

int LGT_VO_ADD(LGT_VO* obj, const char* strData)
{
    struct tm tm_time = {};
    void* ptr = NULL;

    ptr = realloc(obj->_.pData, (obj->_.nData + 1) * sizeof (struct _LGT_VO_DATA));
    if (unlikely(ptr == NULL))
    {
        return -1;
    }
    else obj->_.pData = ptr;
    memset(&obj->_.pData[obj->_.nData], 0, sizeof(struct _LGT_VO_DATA));
    
    memcpy(&obj->_.pData[obj->_.nData].strData[0], strData, LGT_RAW_LINE_SIZE);
    
    strptime(obj->_.pData[obj->_.nData].strData, "%m/%d/%y %H:%M:%S", &tm_time);

    obj->_.pData[obj->_.nData].time = mktime(&tm_time);

    sscanf(obj->_.pData[obj->_.nData].strData, "%d/%d/%d %d:%d:%f %f %f %f %d %f %f %f %d %f %d %c",
           &obj->_.pData[obj->_.nData].mon,
           &obj->_.pData[obj->_.nData].day,
           &obj->_.pData[obj->_.nData].year,
           &obj->_.pData[obj->_.nData].hour,
           &obj->_.pData[obj->_.nData].min,
           &obj->_.pData[obj->_.nData].sec,

           &obj->_.pData[obj->_.nData].lat,
           &obj->_.pData[obj->_.nData].lon,

           &obj->_.pData[obj->_.nData].impact,

           &obj->_.pData[obj->_.nData].tmp1,
           &obj->_.pData[obj->_.nData].tmp2,
           &obj->_.pData[obj->_.nData].tmp3,
           &obj->_.pData[obj->_.nData].tmp4,
           &obj->_.pData[obj->_.nData].tmp5,
           &obj->_.pData[obj->_.nData].tmp6,

           &obj->_.pData[obj->_.nData].sensor,

           &obj->_.pData[obj->_.nData].type
           );

    obj->_.nData++;

    return 0;
}

/**
 * /INPUT/LGT 의 파일형식을 LGT_VO 객체로 읽어온다.
 * @param obj
 * @param filepath
 * @return 성공시 0
 *          실패시 -1
 */
int LGT_VO_READ(LGT_VO* obj, const char* filepath)
{
    FILE* fp = NULL;
    struct stat file_stat = {};
    struct tm tm_time = {};
    char buf[LGT_RAW_LINE_SIZE + 1] = {};
    int nRows = 0;

    fp = fopen(filepath, "r");
    if (unlikely(fp == NULL))
    {
        //_strerror;
        return -1;
    }
    else
    {
        fstat(fileno(fp), &file_stat);
        nRows = file_stat.st_size / LGT_RAW_LINE_SIZE;

        obj->_.pData = calloc(nRows + 1, sizeof (struct _LGT_VO_DATA));
        obj->_.nData = 0;

        while (fread(buf, LGT_RAW_LINE_SIZE, 1, fp) > 0)
        {
            memcpy(&obj->_.pData[obj->_.nData].strData, &buf, LGT_RAW_LINE_SIZE);

            strptime(obj->_.pData[obj->_.nData].strData, "%m/%d/%y %H:%M:%S", &tm_time);

            obj->_.pData[obj->_.nData].time = mktime(&tm_time);

            sscanf(obj->_.pData[obj->_.nData].strData, "%d/%d/%d %d:%d:%f %f %f %f %d %f %f %f %d %f %d %c",
                   &obj->_.pData[obj->_.nData].mon,
                   &obj->_.pData[obj->_.nData].day,
                   &obj->_.pData[obj->_.nData].year,
                   &obj->_.pData[obj->_.nData].hour,
                   &obj->_.pData[obj->_.nData].min,
                   &obj->_.pData[obj->_.nData].sec,

                   &obj->_.pData[obj->_.nData].lat,
                   &obj->_.pData[obj->_.nData].lon,

                   &obj->_.pData[obj->_.nData].impact,

                   &obj->_.pData[obj->_.nData].tmp1,
                   &obj->_.pData[obj->_.nData].tmp2,
                   &obj->_.pData[obj->_.nData].tmp3,
                   &obj->_.pData[obj->_.nData].tmp4,
                   &obj->_.pData[obj->_.nData].tmp5,
                   &obj->_.pData[obj->_.nData].tmp6,

                   &obj->_.pData[obj->_.nData].sensor,

                   &obj->_.pData[obj->_.nData].type
                   );

            obj->_.nData++;
        }

        fclose(fp);
    }

    return 0;
}

/**
 * LGT_VO 객체의 값을 filepath 파일에 출력한다.
 * @param obj
 * @param filepath 출력파일경로
 * @param _mode    파일 모드 "r" "w" "a"
 *                    
       r      Open  text  file  for  reading.  The stream is
       positioned at the beginning of the file.

       r+     Open for reading and writing.  The stream is
       positioned  at  the  beginning of the file.

       w      Truncate  file  to  zero length or create text file
       for writing.
              The stream is positioned at the beginning of the
              file.

       w+     Open for reading and writing.  The file is created 
       if  it  does
              not  exist, otherwise it is truncated.  The stream
              is positioned at the beginning of the file.

       a      Open for appending (writing at end of file).  The
       file  is  cre-
              ated  if it does not exist.  The stream is
              positioned at the end of the file.

       a+     Open for reading and appending (writing at end  of 
       file).   The
              file is created if it does not exist.  The initial
              file position for reading is at the beginning  of  the  file,  but
               output  is always appended to the end of the file.
 * 
 * @return 성공시 0
 *          실패시 -1
 */

int LGT_VO_WRITE(LGT_VO* obj, const char* filepath, const char* _mode)
{
    FILE* fp = NULL;
    int i;

    fp = fopen(filepath, _mode);
    if (unlikely(fp == NULL))
    {
        _strerror;
        return -1;
    }
    else
    {
        for (i = 0; i < obj->_.nData; i++)
        {
            fwrite(&obj->_.pData[i].strData, LGT_RAW_LINE_SIZE, 1, fp);
        }

        fclose(fp);
    }

    return 0;
}

void LGT_VO_DISPOSE(LGT_VO** pObj)
{
    struct _LGT_VO_DATA* pData = NULL;

    if (unlikely(pObj == NULL))
    {
        return;
    }
    else
    {
        while (unlikely(pData++ != NULL))
        {
            _free((*pObj)->_.pData);
            (*pObj)->_.nData--;
        }

        _free(*pObj);
    }

    return;
}

void initLGT_VO(LGT_VO* obj)
{
    obj->READ = LGT_VO_READ;

    obj->WRITE = LGT_VO_WRITE;

    obj->ADD = LGT_VO_ADD;

    obj->DISPOSE = LGT_VO_DISPOSE;

    return;
}

LGT_VO* newLGT_VO()
{
    LGT_VO* obj = calloc(1, sizeof (LGT_VO));
    if (unlikely(obj == NULL))
    {
        _strerror;
        return NULL;
    }
    else
    {
        initLGT_VO(obj);
    }

    return obj;
}
