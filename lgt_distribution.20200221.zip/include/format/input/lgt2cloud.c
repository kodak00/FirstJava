#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <math.h>
#include "/rdr/src/radar/lgt_distribution/include/format/input/LGT_VO.h"

int main(int argc, char** argv)
{
    FILE* ofp = NULL;
    LGT_VO * lgt = NULL;
    int i = 0;
    float value = 0;
    char imsi[111];

    lgt = newLGT_VO();
    if(lgt == NULL)
    {
        fprintf(stderr, "%s\n", strerror(errno));
    }
    else
    {
        lgt->READ(lgt, "/wrc_nas2/DATA/INPUT/LGT/2014/LGT_KMA_20140612.asc");
/*
        for(i=0; i<lgt->_.nData; i++)
        {
            fprintf(stderr, "%s ", lgt->_.pData[i].strData);
        }
*/
        ofp = fopen("/wrc_nas2/DATA/INPUT/LGT/2014/CLOUD_KMA_20140612.asc", "w+");
        if (ofp == NULL)
        {
            fprintf(stderr, "%s\n", strerror(errno));
        }
        else
        {
            for(i=0; i<lgt->_.nData; i++)
            {
                value = rand() % 16;

                strncpy(imsi, lgt->_.pData[i].strData, strlen(lgt->_.pData[i].strData)-2);
//              fprintf(stderr, "%s %f\n", lgt->_.pData[i].strData, value);
                fprintf(ofp, "%s %f\n", imsi, value);
            }

            fclose(ofp);
        }

        lgt->DISPOSE(&lgt);
    }

    fprintf(stderr, "Program End\n");

    exit(0);
}
