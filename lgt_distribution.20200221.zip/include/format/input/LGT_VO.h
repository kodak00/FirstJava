/* 
 * File:   LGT_VO.h
 * Author: lucid32
 *
 * Created on 2014년 8월 4일 (월), 오후 7:20
 */

#ifndef LGT_VO_H
#define	LGT_VO_H

#ifdef	__cplusplus
extern "C"
{
#endif

#include "common/macro.h"

#define LGT_RAW_LINE_SIZE 84

typedef struct _LGT_VO LGT_VO;
typedef struct _LGT_VO_T LGT_VO_T;
/**
 * /DATA/INPUT/LGT
 * @return LGT_VO*
 */
extern LGT_VO* newLGT_VO();

extern void initLGT_VO(LGT_VO* obj);
extern int LGT_VO_READ(LGT_VO* obj, const char* filepath);
extern int LGT_VO_WRITE(LGT_VO* obj, const char* filepath, const char* _mode);
extern int LGT_VO_ADD(LGT_VO* obj, const char* strData);

struct _LGT_VO
{

    struct _LGT_VO_T
    {
        int nData;

        struct _LGT_VO_DATA
        {
            time_t time;
            char strData[LGT_RAW_LINE_SIZE + 1];

            int mon;
            int day;
            int year;
            int hour;
            int min;
            float sec;

            float lat;
            float lon;
            float impact;
            int tmp1;
            float tmp2;
            float tmp3;
            float tmp4;
            int tmp5;
            float tmp6;
            int sensor;
            char type;
        } *pData;
    } _;

    int (*READ)(LGT_VO* obj, const char* filePath);
    int (*WRITE)(LGT_VO* obj, const char* filePath, const char* _mode);

    int (*ADD)(LGT_VO* obj, const char* strData);

    void (*DISPOSE)(LGT_VO** pObj);
};


#ifdef	__cplusplus
}
#endif

#endif	/* LGT_VO_H */

