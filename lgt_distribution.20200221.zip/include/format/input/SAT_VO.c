
#include "SAT_VO.h"

int SAT_VO_GZREAD(SAT_VO* obj, const char* filepath)
{
    gzFile zfp = NULL;

    zfp = gzopen(filepath, "r");
    if (zfp == NULL)
    {
        _strerror;
        return -1;
    }
    else
    {
        if (gzread(zfp, &obj->_.data, sizeof (int16_t) * SAT_VO_YDIM * SAT_VO_XDIM) <= 0)
        {
            _strerror;
            goto EXCEPTION;
        }

        BYTE->ntoh16(&obj->_.data, SAT_VO_YDIM * SAT_VO_XDIM);

        gzclose(zfp);
    }

    return 0;

EXCEPTION:
    if (zfp != NULL)
    {
        gzclose(zfp);
    }

    return -1;
}

int SAT_VO_SMOOTHING(SAT_VO* obj)
{
    int k;
    int iy, ix;
    float e[4], e1, e2;

    int sm_num = 1;
    FILE* out = fopen("/tmp/ori.txt", "w");

    // smoothing
    for (k = 0; k < sm_num; k++)
    {
        for (iy = 0; iy < SAT_VO_YDIM; iy++)
        {
            e1 = obj->_.data[iy][0];
            e[0] = obj->_.data[iy][0];
            e[1] = obj->_.data[iy][1];

            for (ix = 1; ix < SAT_VO_XDIM; ix++)
            {
                if (iy == SAT_VO_YDIM - 1 && ix == SAT_VO_XDIM - 1)
                    break;

                e[2] = obj->_.data[iy][ix + 1];
                if (e[0] > -1 && e[1] > -1 && e[2] > -1)
                {
                    e2 = (e[0] + 2.0 * e[1] + e[2]) * 0.25;
                }
                else if (e[0] > -1 && e[1] <= -1 && e[2] > -1)
                {
                    e2 = (e[0] + e[2]) * 0.5;
                }
                else
                {
                    e2 = e[1];
                }
                obj->_.data[iy][ix - 1] = e1;
                e1 = e2;
                e[0] = e[1];
                e[1] = e[2];
            }

            obj->_.data[iy][ix - 1] = e1;
        }

        for (ix = 0; ix < SAT_VO_XDIM; ix++)
        {
            e1 = obj->_.data[0][ix];
            e[0] = obj->_.data[0][ix];
            //e[1] = obj->_.data[1][ix]; // BUG!!

            for (iy = 1; iy < SAT_VO_YDIM; iy++)
            {
                if (iy == SAT_VO_YDIM - 1 && ix == SAT_VO_XDIM - 1)
                    break;

                e[2] = obj->_.data[iy + 1][ix];

                if (e[0] > -1 && e[1] > -1 && e[2] > -1)
                {
                    e2 = (e[0] + 2.0 * e[1] + e[2]) * 0.25;
                }
                else if (e[0] > -1 && e[1] <= -1 && e[2] > -1)
                {
                    e2 = (e[0] + e[2]) * 0.5;
                }
                else
                {
                    e2 = e[1];
                }

                obj->_.data[iy - 1][ix] = e1;
                e1 = e2;
                e[0] = e[1];
                e[1] = e[2];
            }

            obj->_.data[iy - 1][ix] = e1;
        }
    }
    
    for (iy = 0; iy < SAT_VO_YDIM; iy++)
    {
        for (ix = 0; ix < SAT_VO_XDIM; ix++)
        {
            fprintf(out, "%d %d, %d\n", iy, ix, obj->_.data[iy][ix]);
        }
    }
    exit(0);
    
    return 0;
}

void SAT_VO_DISPOSE(SAT_VO** pObj)
{
    _dispose(pObj);

    return;
}

void initSAT_VO(SAT_VO* obj)
{
    obj->GZREAD = SAT_VO_GZREAD;

    obj->SMOOTHING = SAT_VO_SMOOTHING;

    obj->DISPOSE = SAT_VO_DISPOSE;
    return;
}

SAT_VO* newSAT_VO()
{
    SAT_VO* obj = calloc(1, sizeof (SAT_VO));

    if (unlikely(obj == NULL))
    {
        _strerror;
        return NULL;
    }
    else
    {
        initSAT_VO(obj);
    }

    return obj;
}