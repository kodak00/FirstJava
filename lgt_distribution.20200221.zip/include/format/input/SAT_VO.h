/* 
 * File:   SAT_VO.h
 * Author: lucid32
 *
 * Created on 2014년 8월 13일 (수), 오후 10:31
 */

#ifndef SAT_VO_H
#define	SAT_VO_H

#ifdef	__cplusplus
extern "C"
{
#endif

#include <zlib.h>

#include "common/macro.h"
#include "common/BYTE_I.h"

#define SAT_VO_XDIM 1024
#define SAT_VO_YDIM 1024
#define SAT_VO_GRID 2

#define SAT_VO_NO_DATA_VALUE -9999

typedef struct _SAT_VO SAT_VO;
typedef struct _SAT_VO_T SAT_VO_T;

/**
 * /DATA/INPUT/SAT
 * @return 
 */
extern SAT_VO* newSAT_VO();
extern void initSAT_VO(SAT_VO* obj);
extern int SAT_VO_GZREAD(SAT_VO* obj, const char* filepath);

struct _SAT_VO
{

    struct _SAT_VO_T
    {
        int16_t data[SAT_VO_YDIM][SAT_VO_XDIM];
    } _;

    int (*GZREAD)(SAT_VO* obj, const char* filepath);

    int (*SMOOTHING)(SAT_VO* obj);

    void (*DISPOSE)(SAT_VO** pObj);
};

#ifdef	__cplusplus
}
#endif

#endif	/* SAT_VO_H */

