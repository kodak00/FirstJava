#!/bin/bash
gcc -o lgt2cloud2 lgt2cloud.c LGT_VO.o LGT_VO.h SAT_VO.o /fsnas_0/APPS_2014/src/include/common/BYTE_I.o -I/fsnas_0/APPS_2014/src/include -lz
