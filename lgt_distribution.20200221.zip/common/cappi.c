#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "parameter.h"
#include "cappi.h"

char *strptime(const char *s, const char *format, struct tm *tm);

//File Name Check 
PARAM_INFO comp_file_name(PARAM_INFO var, char *COMP_FILE)
{
	struct tm tmtime;		
	char datetime[13];		// ����Ͻú�
	char fileName[FILE_SIZE];
	  
  sprintf(datetime, "%04d%02d%02d%02d%02d", var.YY, var.MM, var.DD, var.HH, var.min);	
  strptime(datetime, "%Y%m%d%H%M", &tmtime);  
	strftime(fileName, FILE_SIZE, COMP_FILE, &tmtime);		  
  //fprintf(stderr, "--->%04d%02d%02d%02d%02d\n", var.YY, var.MM, var.DD, var.HH, var.min);	
  
	strcpy(var.fname, fileName);  
  fprintf(stderr,"0.var.fname-->%s\n",var.fname);
   
	return var;
}

int comp_read(PARAM_INFO var, short **DATA)
{
    FILE *fd;
    char buf[960];
    int	i, j, n;
    int fchk=0;
        
    //�ʱ�ȭ
    for (j=0; j<1200; j++) 
    {
        for (i=0; i<960; i++) 
        {
        	DATA[j][i] = -12800;
        }
    }
    
    //File Open 
    //fprintf(stderr,"var.fname-->%s\n",var.fname);    
    if(var.fname!=NULL && (fd=gzopen(var.fname, "rb")) != NULL) {
        
        //Data Read
        for (j=10; j<1200; j++)
        {
            n = gzread(fd, buf, 960);
            
            for (i=0; i<960; i++)
            {
            	DATA[j][i] = buf[i]*100;
            }
        }	    
        gzclose(fd);    
        fchk = 1;
    }

  return fchk;
	
}

int comp_read_rar(PARAM_INFO var, short **DATA)
{
  FILE *fd;
	short value;
  int	i, j;
	int x, y;
  int fchk=0;
      
  //�ʱ�ȭ
  for (j=0; j<1200; j++) 
  {
      for (i=0; i<960; i++) 
      {
      	DATA[j][i] = -12800;
      }
  }
  
 //File Open 
  if(var.fname!=NULL && (fd=gzopen(var.fname, "rb")) != Z_NULL) {
      
      //Data Read
      for (j=0; j < RAR_Y_DIM-1; j++)
      {
        	for(i=0 ; i<RAR_X_DIM ; i++) {
    			gzread(fd, &value, 2);
                
          x = (RAR_DEL_LEFT - COMP_DEL_LEFT + i);  
          y = (RAR_DEL_BOTTOM - COMP_DEL_BOTTOM + j);
          
    			if(value == 128) {
        		DATA[y][x] = -12800;
        	} else if(value == 384) {    		
        		DATA[y][x] = -12700;
         	} else {     	   
    			  DATA[y][x] = value;
         	}
        }
      }
      
      gzclose(fd);    
      fchk = 1;
  }
  
  return fchk;
}

