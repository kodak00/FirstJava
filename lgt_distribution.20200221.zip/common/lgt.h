
#ifndef LGT_H_
#define LGT_H_

#define MAX_STRING_LENGTH 1024
#define FILE_SIZE 128

typedef struct
{
	char  datetime[13];
	float lat;
	float lon;
	float impact;
	char  type;
	int sensor;
} LDATA;

int getImageCircle(gdImagePtr im, int x, int y, int color);
//int getImagePlus(gdImagePtr im, int x, int y, int color);
int getImagePlus(gdImagePtr im, int x, int y, int color, int lsize, char bold);
int getImageCross(gdImagePtr im, int x, int y, int color);

LDATA* ReadLightingRaw(PARAM_INFO var, char* LGT_FILE, int* lcount);

int lgt_comp_disp(PARAM_INFO var, gdImagePtr im, int lcount, LDATA *ldata, int color[], int colorNo, int lgtSize, char bold);
int qc_lgt_comp_disp(PARAM_INFO var, gdImagePtr im, int lcount, LDATA *ldata, int color[], int colorNo, int lgtSize, char bold);
//int qc_lgt_comp_disp(PARAM_INFO var, gdImagePtr im, int lcount, LDATA *ldata, int color[], int colorNo, int lgtSize, char bold, float** SDATA, float** RDATA);

#endif /* LGT_H_ */
