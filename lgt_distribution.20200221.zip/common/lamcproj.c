#include <stdio.h>
#include <math.h>

#include "map_ini.h"

/***************************************************************************
*
*  [ Lambert Conformal Conic Projection ]
*
*      o lon, lat : (longitude,latitude) at earth  [degree]
*      o x, y     : (x,y) cordinate in map  [grid]
*      o code = 0 : (lon,lat) --> (x,y)
*               1 : (x,y) --> (lon,lat)
*
***************************************************************************/

int  lamcproj( lon, lat, x, y, code, map )

float  *lon, *lat;         /* Longitude, Latitude [degree]  */
float  *x, *y;             /* Coordinate in Map   [grid]    */
int    code;               /* (0) lon,lat -> x,y  (1) x,y -> lon,lat */
struct lamc_parameter map;
{
    static double  PI, DEGRAD, RADDEG;
    static double  re, olon, olat, sn, sf, ro;
    //double         slat1, slat2, alon, alat, xn, yn, ra, theta;
    double         slat1, slat2, ra, theta;

   
        PI = asin(1.0)*2.0;
        DEGRAD = PI/180.0;
        RADDEG = 180.0/PI;

        re = map.Re/map.grid;
        slat1 = map.slat1 * DEGRAD;
        slat2 = map.slat2 * DEGRAD;
        olon = map.olon * DEGRAD;
        olat = map.olat * DEGRAD;

        sn = tan(PI*0.25 + slat2*0.5)/tan(PI*0.25 + slat1*0.5);
        sn = log(cos(slat1)/cos(slat2))/log(sn);
        sf = tan(PI*0.25 + slat1*0.5);
        sf = pow(sf,sn)*cos(slat1)/sn;
        ro = tan(PI*0.25 + olat*0.5);
        ro = re*sf/pow(ro,sn);
       
    

   
        ra = tan(PI*0.25+(*lat)*DEGRAD*0.5);
        ra = re*sf/pow(ra,sn);
        theta = (*lon)*DEGRAD - olon;
        if (theta >  PI) theta -= 2.0*PI;
        if (theta < -PI) theta += 2.0*PI;
        theta *= sn;
        *x = (float)(ra*sin(theta)) + map.xo;
        *y = (float)(ro - ra*cos(theta)) + map.yo;
     
    return 0;
}

MAP_INFO comp_map_info()
{
	struct lamc_parameter map;
	
	MAP_INFO rate;
	
	int zm = 2;
	
  //map setting
	map.Re	  = 6371.00877f;
	map.slat1 = 30.0f;
	map.slat2 = 60.0f;
	map.olon  = 126.0f;
	map.olat  = 38.0f;
	map.grid  = 4.0f / zm;
//	map.xo	  = 200;
//	map.yo	  = 400;
//	map.xo	  = 180;
//  map.yo     = 154;

	map.xo	  = 350;
	map.yo	  = 440;

	map.first = 0;	
	
	rate.zm = zm;
	rate.map	= map; 
	
	
	return rate;  
}

