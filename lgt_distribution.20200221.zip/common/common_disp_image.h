
#define FONT_PATH "/DATA/CONFIG/FNT"

#define FILE_SIZE 128

#define BOUND  -12800     //Out of bound
#define BAD_VAL  -12700   //bad value
#define LEGEND_CNT 31

PARAM_INFO getCompFileName(PARAM_INFO var, char *COMP_FILE, int min);
int comp_rdr_read(PARAM_INFO var, short **DATA);

int map_disp(PARAM_INFO var, char *MAP_LINE_FILE, gdImagePtr im,int color[]);
int map_common_disp(PARAM_INFO var, char *MAP_LINE_FILE, gdImagePtr im,int color[]);
int aws_disp(PARAM_INFO var, char *AWS_NAME_FILE, gdImagePtr im,int color[]);
int aws_common_disp(PARAM_INFO var, char *AWS_NAME_FILE, gdImagePtr im,int color[]);
int map_sea_disp(PARAM_INFO var, char *MAP_LINE_FILE, gdImagePtr im,int color[]);

int radar_echo_disp(PARAM_INFO var, short **DATA, gdImagePtr im, int color[], COLOR_INFO color_info, int sat_on);
int radar_echo_data(PARAM_INFO var, short **DATA, float **rdr_data);

double calc_radar_value(PARAM_INFO var, short **DATA, int j, int i);
double lgt_calc_radar_value(PARAM_INFO var, int **DATA, int j, int i);

double calc_val( double jj, double ii, double fx, double fy, double fz, double fw);
int rdr_level_color_disp(short v, int cnt, float *dbz, float dbz_min);
