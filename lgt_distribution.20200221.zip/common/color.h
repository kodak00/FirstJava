/*
 * color.h
 *
 *  Created on: 2011. 9. 9.
 *      Author: radar
 */

#ifndef COLOR_H_
#define COLOR_H_

#define SKIP_COLOR (-99)

typedef struct {
	
	int R;
	int G;
	int B;
    
} COLOR;

typedef struct {
	
	int R;
	int G;
	int B;
	
  int num;
	float rain;
	float dbz;

} COLOR_DATA;

typedef struct {

	int cnt;
	int legend_cnt;

	char tit[20];

	COLOR_DATA* data;

} COLOR_INFO;


COLOR_INFO color_table(char *path);
COLOR_INFO color_table_guidance(char *path);

int color_table_read(gdImagePtr im, int	color[], COLOR_INFO rdr_color);

void freeColorIndex(COLOR_INFO color);

int* getTopoColor(gdImagePtr im);
int getRiverColor(gdImagePtr im);

#endif /* COLOR_H_ */
