/*
 * site.h
 *
 *  Created on: 2011. 8. 2.
 *      Author: radar
 */

#ifndef SITE_INFO_H_
#define SITE_INFO_H_

typedef struct {	
	
	char sitename[4];
	char sitekorname[10];
	float lon;
	float lat;
	float x;
	float y;
	int range;
	
} SITE_DATA;

typedef struct {
	
	int cnt;
	SITE_DATA *data;
	
} SITE_INFO;

typedef struct {	
	char sitename[4];	
}SITENAME_INFO;

SITE_INFO getSiteInfoRead(PARAM_INFO var, char *path);
SITE_INFO chkSiteInfo(PARAM_INFO var, SITE_INFO site_info);

int getFindSiteInfo(SITE_INFO info, char *search);

char* cb_ToUpper(char *s1);
char* cb_ToLower(char *s1);

void freeIndex(SITE_INFO site);

#endif /* SITE_INFO_H_ */

