#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "gd.h"

#include "map_ini.h"
#include "parameter.h"
#include "color.h"  
#include "seq_time.h"
#include "lgt.h"

char *strptime(const char *s, const char *format, struct tm *tm);

// x, y�� �߽����� 5*5pixel ũ���� o ����� �׸��ϴ�.  
int getImageCircle(gdImagePtr im, int x, int y, int color)
{                                                      
   gdImageLine(im, x-3, y-1, x-3, y+1, color);          
   gdImageLine(im, x+3, y-1, x+3, y+1, color);          
   gdImageLine(im, x-1, y-3, x+1, y-3, color);          
   gdImageLine(im, x-1, y+3, x+1, y+3, color);          
   gdImageSetPixel(im, x-2, y-2, color);                
   gdImageSetPixel(im, x+2, y-2, color);                
   gdImageSetPixel(im, x-2, y+2, color);                
   gdImageSetPixel(im, x+2, y+2, color);                
   return 0;                                            
}                                                      
                                                       
// x, y�� �߽����� 5*5pixel ũ���� + ����� �׸��ϴ�.  
int getImagePlus(gdImagePtr im, int x, int y, int color, int lsize, char bold)  
{  
	if(bold == 'Y'){
		gdImageLine(im, x-lsize, y-1, x+lsize, y-1, color);              
		gdImageLine(im, x-lsize, y+1, x+lsize, y+1, color);
		gdImageLine(im, x-1, y-lsize, x-1, y+lsize, color);
		gdImageLine(im, x+1, y-lsize, x+1, y+lsize, color);
	}   
	gdImageLine(im, x-lsize, y, x+lsize, y, color);              
	gdImageLine(im, x, y-lsize, x, y+lsize, color);              
	return 0;                                            
}                                                      
                                                       
// x, y�� �߽����� 5*5pixel ũ���� x ����� �׸��ϴ�.  
int getImageCross(gdImagePtr im, int x, int y, int color) 
{                                                      
   gdImageLine(im, x-3, y+3, x+3, y-3, color);          
   gdImageLine(im, x-3, y-3, x+3, y+3, color);
   return 0; 
} 

/*============================================================================*
 * Lgt File Name Check 
 *============================================================================*/
PARAM_INFO LgtFileName(PARAM_INFO var, char *LGT_FILE)
{
	struct tm tmtime;		
	char datetime[13];		// ����Ͻú�
	char fileName[FILE_SIZE];
	  
  sprintf(datetime, "%04d%02d%02d%02d%02d", var.YY, var.MM, var.DD, var.HH, var.min);	
  strptime(datetime, "%Y%m%d%H%M", &tmtime);  
	strftime(fileName, FILE_SIZE, LGT_FILE, &tmtime);		  
  //fprintf(stderr, "--->%04d%02d%02d%02d%02d\n", var.YY, var.MM, var.DD, var.HH, var.min);	
  
	strcpy(var.fname, fileName);  
  //fprintf(stderr,"0.var.fname-->%s\n",var.fname);
   
	return var;
}
/*============================================================================*
 * Lgt Data Read
 *============================================================================*/
LDATA* ReadLightingRaw(PARAM_INFO var, char* LGT_FILE, int* lcount)
{
	FILE *fp, *fd;
//	struct tm tmpTime;
	int i;
	int itmp,num_sns;
	int yr, mon, day, hr, min;
	float sec, lat, lon, imp, ftmp;
	char type;
	char str[MAX_STRING_LENGTH];
	char datetime1[MAX_STRING_LENGTH];
	char datetime2[MAX_STRING_LENGTH];
	char date1[MAX_STRING_LENGTH];
	char date2[MAX_STRING_LENGTH];
	char filedate[MAX_STRING_LENGTH];
	long lgtline = 0;
	long guessline = 0;
	LDATA *ldata;
	struct stat buf;
	
//	struct tm time;		
	struct tm tmtime;		
	
	char datetime[13];		// ����Ͻú�
	char fileName[FILE_SIZE];

	struct tm run_datetime;		// ���� �ð�
	struct tm tmp_datetime;		// �ӽ� �ð�

	sprintf(datetime, "%04d%02d%02d%02d%02d", var.YY, var.MM, var.DD, var.HH, var.min);
	tmtime = getConvStrToDateTime(datetime);
	run_datetime = getConvStrToDateTime(datetime);

	tmp_datetime = getIncMin(tmtime, 0);
	strftime(datetime1, sizeof(str), "%Y%m%d%H%M", &tmp_datetime);
	strftime(date1, sizeof(str), "%Y%m%d", &tmp_datetime);

	//fprintf(stderr, "datetime1 = %s \n", datetime1);

	if(var.comp_flg == 'T')	{
		tmp_datetime = getIncMin(tmtime, -6*var.intv);
	}else{
		tmp_datetime = getIncMin(tmtime, -1*var.intv);
	}

	strftime(datetime2, sizeof(str), "%Y%m%d%H%M", &tmp_datetime);
	strftime(date2, sizeof(str), "%Y%m%d", &tmp_datetime);

	//fprintf(stderr, "datetime2 = %s \n", datetime2);
	for(i=0; i<100; i++)
	{
		strptime(date1, "%Y%m%d", &run_datetime);
		tmp_datetime = getIncDay(run_datetime, -1*i);
		strftime(filedate, sizeof(str), "%Y%m%d", &tmp_datetime);

		strftime(fileName, FILE_SIZE, LGT_FILE, &tmp_datetime);

		if((fp=fopen(fileName, "r")) == NULL) continue;

		stat(fileName, &buf);

		guessline += buf.st_size;
		
		if (strcmp(filedate, date2) <= 0 )	break;

		fclose(fp);
	}

	// ���� RAW �ڷ� 1 line�� 97 ����Ʈ�̹Ƿ� ������... �� ���� ���μ��� ���´�.
	guessline /= 85;

	ldata = malloc((guessline*2) * sizeof(LDATA));
	
	for(i=0; i<100; i++)
	{
		strptime(date1, "%Y%m%d", &run_datetime);
		tmp_datetime = getIncDay(run_datetime, -1*i);
		strftime(filedate, sizeof(str), "%Y%m%d", &tmp_datetime);

		strftime(fileName, FILE_SIZE, LGT_FILE, &tmp_datetime);

		//fprintf(stderr, "fileName =================> %s\n", fileName);

		// ���� �о� ����
		if((fd=fopen(fileName, "r")) == NULL) continue;
		
		// ���� �о ������, ����, �浵�� �迭�� �����Ѵ�.
		while (fgets(str, MAX_STRING_LENGTH, fd) != NULL) {	  
			//fprintf(stderr, "2.str = %s \n", str);
			sscanf(str, "%d/%d/%d %d:%d:%f %f %f %f %d %f %f %f %d %f %d %c ",
							&mon, &day, &yr, &hr, &min, &sec, &lat, &lon, &imp, &itmp,
							&ftmp, &ftmp, &ftmp, &itmp, &ftmp, &num_sns, &type);
			sprintf(str, "%d%02d%02d%02d%02d", yr + 2000, mon, day, hr, min);

			if (strcmp(datetime1, str) >= 0 && strcmp(datetime2, str) <= 0) {

				sprintf(ldata[lgtline].datetime, "%s", str);
				ldata[lgtline].impact = imp;
				ldata[lgtline].type = type;
				ldata[lgtline].lon = lon;
				ldata[lgtline].lat = lat;
				ldata[lgtline].sensor = num_sns;
				lgtline++;
			}
			
		}

		if (strcmp(filedate, date2) <= 0 || lgtline >= guessline) break;
		
		fclose(fd);

	}
	*lcount = lgtline;

	return ldata;

}

/*============================================================================*
 *  * Lgt Data Read2
 *   *============================================================================*/
LDATA* ReadLightingRaw2(PARAM_INFO var, char* LGT_FILE, int* lcount)
{
    FILE *fp, *fd;
    int i;
    int itmp,num_sns;
    int yr, mon, day, hr, min;
    float sec, lat, lon, imp, ftmp;
    char type;
    char str[MAX_STRING_LENGTH];
    char datetime1[MAX_STRING_LENGTH];
    char datetime2[MAX_STRING_LENGTH];
    char date1[MAX_STRING_LENGTH];
    char date2[MAX_STRING_LENGTH];
    char filedate[MAX_STRING_LENGTH];
    long lgtline = 0;
    long guessline = 0;
    LDATA *ldata;
    struct stat buf;

    struct tm tmtime;
    char datetime[13];      // ����Ͻú�
    char fileName[FILE_SIZE];

    struct tm run_datetime;     // ���� �ð�
    struct tm tmp_datetime;     // �ӽ� �ð�

    sprintf(datetime, "%04d%02d%02d%02d%02d", var.YY, var.MM, var.DD, var.HH, var.min);
    tmtime = getConvStrToDateTime(datetime);
    run_datetime = getConvStrToDateTime(datetime);

    tmp_datetime = getIncMin(tmtime, 0);
    strftime(datetime1, sizeof(str), "%Y%m%d%H%M", &tmp_datetime);
    strftime(date1, sizeof(str), "%Y%m%d", &tmp_datetime);

    if(var.comp_flg == 'T')
    {
        //tmp_datetime = getIncMin(tmtime, -6*var.intv);
        tmp_datetime = getIncMin(tmtime, -1*var.intv);
    }
    else
    {
        tmp_datetime = getIncMin(tmtime, -1*var.intv);
    }
    
    strftime(datetime2, sizeof(str), "%Y%m%d%H%M", &tmp_datetime);
    strftime(date2, sizeof(str), "%Y%m%d", &tmp_datetime);

    for(i=0; i<100; i++)
    {
        strptime(date1, "%Y%m%d", &run_datetime);
        tmp_datetime = getIncDay(run_datetime, -1*i);
        strftime(filedate, sizeof(str), "%Y%m%d", &tmp_datetime);

        strftime(fileName, FILE_SIZE, LGT_FILE, &tmp_datetime);

        if((fp=fopen(fileName, "r")) == NULL)
            continue;

        stat(fileName, &buf);

        guessline += buf.st_size;

        if (strcmp(filedate, date2) <= 0 )
            break;

        fclose(fp);
    }

    guessline /= 85;

    ldata = malloc((guessline*2) * sizeof(LDATA));

    for(i=0; i<100; i++)
    {
        strptime(date1, "%Y%m%d", &run_datetime);
        tmp_datetime = getIncDay(run_datetime, -1*i);
        strftime(filedate, sizeof(str), "%Y%m%d", &tmp_datetime);

        strftime(fileName, FILE_SIZE, LGT_FILE, &tmp_datetime);

        //fprintf(stderr, "fileName =================> %s\n", fileName);
        // ���� �о� ����

        if((fd=fopen(fileName, "r")) == NULL) 
            continue;

        while (fgets(str, MAX_STRING_LENGTH, fd) != NULL)
        {
            sscanf(str, "%d/%d/%d %d:%d:%f %f %f %f %d %f %f %f %d %f %d %c ",
                    &mon, &day, &yr, &hr, &min, &sec, &lat, &lon, &imp, &itmp,
                    &ftmp, &ftmp, &ftmp, &itmp, &ftmp, &num_sns, &type);
            sprintf(str, "%d%02d%02d%02d%02d", yr + 2000, mon, day, hr, min);
        //  if (strcmp(datetime1, str) >= 0 && strcmp(datetime2, str) <= 0) {
            if (strcmp(datetime1, str) > 0 && strcmp(datetime2, str) <= 0) 
            {
                sprintf(ldata[lgtline].datetime, "%s", str);
                ldata[lgtline].impact = imp;
                ldata[lgtline].type = type;
                ldata[lgtline].lon = lon;
                ldata[lgtline].lat = lat;
                ldata[lgtline].sensor = num_sns;
                lgtline++;
            }
        }

        if (strcmp(filedate, date2) <= 0 || lgtline >= guessline) 
            break;

        fclose(fd);
    }
    *lcount = lgtline;
    return ldata;
}



/*============================================================================*
 * Lgt display
 *============================================================================*/
int lgt_comp_disp(PARAM_INFO var, gdImagePtr im, int lcount, LDATA *ldata, int color[], int colorNo, int lgtSize, char bold)
{
   struct lamc_parameter map;
   int i;
   float x, y;
   int _x, _y;
     
   MAP_INFO mapInfo = comp_map_info();
   map = mapInfo.map;
/*
   fprintf(stderr,"%f\n",     map.slat1);// = LAMC_SLAT1;
   fprintf(stderr,"%f\n",     map.slat2);// = LAMC_SLAT2;
   fprintf(stderr,"%f\n",     map.olon);//  = LAMC_OLON;
   fprintf(stderr,"%f\n",     map.olat);//  = LAMC_OLAT;
   fprintf(stderr,"%f\n",     map.xo);//    = LAMC_XO;
   fprintf(stderr,"%f\n",     map.yo);//    = LAMC_YO;
   fprintf(stderr,"%f\n",     map.grid);//  = LAMC_GRID;
*/

   for(i=0 ; i<lcount ; i++) 
   {   
      //��ǥ ��ȯ (DEGREE to PIXEL)
      x = -999.0;
      y = -999.0;
      lamcproj(&ldata[i].lon, &ldata[i].lat, &x, &y, 0, map);
      
      if (x < -3.0 || x > 714.0 || y < -3.0 || y > 714.0) continue;
//fprintf(stderr, "%d %d %f %f\n", var.nOrgX, var.nOrgY, var.nXscalef, var.nXscalef);

      _x = (int) ((x - var.nOrgX ) / var.nXscalef +0.5 );
      _y = (int) (((600.0 - y) - var.nOrgY ) / var.nYscalef +0.5);
      
      if(_x> 0 && _x< 480 && _y>0 && _y< 600) 
      {
		  if(ldata[i].sensor >= 3){
	         getImagePlus(im, _x, _y, color[colorNo], lgtSize, bold);
		  }
      }
   }
   return 0;
}

int qc_lgt_comp_disp(PARAM_INFO var, gdImagePtr im, int lcount, LDATA *ldata, int color[], int colorNo, int lgtSize, char bold)
{
    struct lamc_parameter map;
    int i;
    float x, y;
    int _x, _y;

    MAP_INFO mapInfo = comp_map_info();
    map = mapInfo.map;

    fprintf(stderr,"%f\n",     map.slat1);// = LAMC_SLAT1;
    fprintf(stderr,"%f\n",     map.slat2);// = LAMC_SLAT2;
    fprintf(stderr,"%f\n",     map.olon);//  = LAMC_OLON;
    fprintf(stderr,"%f\n",     map.olat);//  = LAMC_OLAT;
    fprintf(stderr,"%f\n",     map.xo);//    = LAMC_XO;
    fprintf(stderr,"%f\n",     map.yo);//    = LAMC_YO;
    fprintf(stderr,"%f\n",     map.grid);//  = LAMC_GRID;


    for(i=0; i<lcount; i++)
    {
        x = -999.0;
        y = -999.0;
        lamcproj(&ldata[i].lon, &ldata[i].lat, &x, &y, 0, map);

        if (x < -3.0 || x > 714.0 || y < -3.0 || y > 714.0)
            continue;

        _x = (int) ((x - var.nOrgX ) / var.nXscalef +0.5 );
        _y = (int) (((600.0 - y) - var.nOrgY ) / var.nYscalef +0.5);

        if(_x > 0 && _x < 480 && _y > 0 && _y < 600)
        {
	        if( ldata[i].sensor >= 3 ) 
            {
                getImagePlus(im, _x, _y, color[colorNo], lgtSize, bold);
	        }
        }
    }
    return 0;
}
 

/*
int qc_lgt_comp_disp(PARAM_INFO var, gdImagePtr im, int lcount, LDATA *ldata, int color[], int colorNo, int lgtSize, char bold, float** rdr_data, float** sat_data)
{
   struct lamc_parameter map;
   int i;
   float x, y;
   int _x, _y;
     
   MAP_INFO mapInfo = comp_map_info();
   map = mapInfo.map;

   for(i=0 ; i<lcount ; i++) 
   {
      
      //��ǥ ��ȯ (DEGREE to PIXEL)
      x = -999.0;
      y = -999.0;
      lamcproj(&ldata[i].lon, &ldata[i].lat, &x, &y, 0, map);
      
      if (x < -3.0 || x > 714.0 || y < -3.0 || y > 714.0) continue;

      _x = (int) ((x - var.nOrgX ) / var.nXscalef +0.5 );
      _y = (int) (((600.0 - y) - var.nOrgY ) / var.nYscalef +0.5);
      
      if(_x> 0 && _x< 480 && _y>0 && _y< 600) 
      {
      	if( ldata[i].sensor>=3 && 
            ((var.rdr_thresh!=0.f && var.rdr_thresh<rdr_data[_y][_x]) ||
             (var.sat_thresh!=0.f && var.sat_thresh<sat_data[_y][_x]))) {
/
      	if( (var.rdr_thresh!=0.f && var.rdr_thresh<rdr_data[_y][_x]) ||
            (var.sat_thresh!=0.f && var.sat_thresh<sat_data[_y][_x])) {
/
         getImagePlus(im, _x, _y, color[29], lgtSize, bold);
        } else {
        	getImagePlus(im, _x, _y, color[11], lgtSize, bold);
        }
      }
   }
   return 0;
}
*/

