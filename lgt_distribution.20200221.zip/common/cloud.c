#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "gd.h"

#include "map_ini.h"
#include "parameter.h"
#include "color.h"  
#include "seq_time.h"
#include "cloud.h"

char *strptime(const char *s, const char *format, struct tm *tm);

/*============================================================================*
 * Lgt Data Read
 *============================================================================*/
CDATA* ReadLightingRaw_cloud(PARAM_INFO var, char* CLOUD_FILE, int* ccount)
{
	FILE *fp, *fd;
//	struct tm tmpTime;
	int i;
	int itmp,num_sns;
	int yr, mon, day, hr, min;
	float sec, lat, lon, imp, ftmp, altitude;
	char type;
	char str[MAX_STRING_LENGTH];
	char datetime1[MAX_STRING_LENGTH];
	char datetime2[MAX_STRING_LENGTH];
	char date1[MAX_STRING_LENGTH];
	char date2[MAX_STRING_LENGTH];
	char filedate[MAX_STRING_LENGTH];
	long cloudline = 0;
	long guessline = 0;
	CDATA *cdata;
	struct stat buf;
	
//	struct tm time;		
	struct tm tmtime;		
	
	char datetime[13];		// ����Ͻú�
	char fileName[FILE_SIZE];

	struct tm run_datetime;		// ���� �ð�
	struct tm tmp_datetime;		// �ӽ� �ð�

	sprintf(datetime, "%04d%02d%02d%02d%02d", var.YY, var.MM, var.DD, var.HH, var.min); //201406102350

    tmtime          = getConvStrToDateTime(datetime);
	run_datetime    = getConvStrToDateTime(datetime);

	tmp_datetime = getIncMin(tmtime, 0);
	strftime(datetime1, sizeof(str), "%Y%m%d%H%M",  &tmp_datetime);
	strftime(date1,     sizeof(str), "%Y%m%d",      &tmp_datetime);

	tmp_datetime = getIncMin(tmtime, -1 * var.intv);
	strftime(datetime2, sizeof(str), "%Y%m%d%H%M",  &tmp_datetime);
	strftime(date2,     sizeof(str), "%Y%m%d",      &tmp_datetime);

	//fprintf(stderr, "datetime1 = %s \n", datetime1);
	//fprintf(stderr, "datetime2 = %s \n", datetime2);

	for(i=0; i<100; i++)
	{
		strptime(date1, "%Y%m%d", &run_datetime);

        tmp_datetime = getIncDay(run_datetime, -1 * i);
		
        strftime(filedate, sizeof(str), "%Y%m%d",   &tmp_datetime);
		strftime(fileName, FILE_SIZE, CLOUD_FILE,     &tmp_datetime);

		if((fp=fopen(fileName, "r")) == NULL) continue;

		stat(fileName, &buf);

		guessline += buf.st_size;
		
		if (strcmp(filedate, date2) <= 0 )	break;

		fclose(fp);
	}

	// ���� RAW �ڷ� 1 line�� 97 ����Ʈ�̹Ƿ� ������... �� ���� ���μ��� ���´�.
	guessline /= 85;

	cdata = malloc((guessline*2) * sizeof(CDATA));
	
	for(i=0; i<100; i++)
	{
		strptime(date1, "%Y%m%d", &run_datetime);
		tmp_datetime = getIncDay(run_datetime, -1*i);
		strftime(filedate, sizeof(str), "%Y%m%d", &tmp_datetime);

		strftime(fileName, FILE_SIZE, CLOUD_FILE, &tmp_datetime);

		//fprintf(stderr, "fileName =================> %s\n", fileName);

		/// ���� �о� ����
		if((fd=fopen(fileName, "r")) == NULL) continue;
		
		// ���� �о ������, ����, �浵�� �迭�� �����Ѵ�.
		while (fgets(str, MAX_STRING_LENGTH, fd) != NULL)
        {
			//fprintf(stderr, "2.str = %s \n", str);
			sscanf(str, "%d/%d/%d %d:%d:%f %f %f %f %d %f %f %f %d %f %d %c %f ",
							&mon, &day, &yr, &hr, &min, &sec, &lat, &lon, &imp, &itmp,
							&ftmp, &ftmp, &ftmp, &itmp, &ftmp, &num_sns, &type, &altitude);
			sprintf(str, "%d%02d%02d%02d%02d", yr + 2000, mon, day, hr, min);

			if (strcmp(datetime1, str) >= 0 && strcmp(datetime2, str) <= 0)
            {
				sprintf(cdata[cloudline].datetime, "%s", str);
				cdata[cloudline].altitude = altitude;
				cdata[cloudline].type = type;
				cdata[cloudline].lon = lon;
				cdata[cloudline].lat = lat;
				cdata[cloudline].sensor = num_sns;
				cloudline++;
			}
		}

		if (strcmp(filedate, date2) <= 0 || cloudline >= guessline) break;
		
		fclose(fd);
	}
	*ccount = cloudline;

	return cdata;
}

/*============================================================================*
 * Lgt display
 *============================================================================*/
int cloud_comp_disp(PARAM_INFO var, gdImagePtr im, int lcount, CDATA *cdata, int color[], int colorNo, int cloudSize, char bold)
{
    struct lamc_parameter map;
    int i;
    float x, y;
    int _x, _y;
     
    MAP_INFO mapInfo = comp_map_info();
    map = mapInfo.map;
/*
    fprintf(stderr,"%f\n",     map.slat1);// = LAMC_SLAT1;
    fprintf(stderr,"%f\n",     map.slat2);// = LAMC_SLAT2;
    fprintf(stderr,"%f\n",     map.olon);//  = LAMC_OLON;
    fprintf(stderr,"%f\n",     map.olat);//  = LAMC_OLAT;
    fprintf(stderr,"%f\n",     map.xo);//    = LAMC_XO;
    fprintf(stderr,"%f\n",     map.yo);//    = LAMC_YO;
    fprintf(stderr,"%f\n",     map.grid);//  = LAMC_GRID;
*/

    for(i=0 ; i<lcount ; i++) 
    {
        //��ǥ ��ȯ (DEGREE to PIXEL)
        x = -999.0;
        y = -999.0;
        lamcproj(&cdata[i].lon, &cdata[i].lat, &x, &y, 0, map);
      
        if (x < -3.0 || x > 714.0 || y < -3.0 || y > 714.0) continue;
    //  fprintf(stderr, "%d %d %f %f\n", var.nOrgX, var.nOrgY, var.nXscalef, var.nXscalef);

        _x = (int) ((x - var.nOrgX ) / var.nXscalef +0.5 );
        _y = (int) (((600.0 - y) - var.nOrgY ) / var.nYscalef +0.5);
      
        if(_x> 0 && _x< 480 && _y>0 && _y< 600) 
        {
		    if(cdata[i].sensor >= 3)
            {
	            getImagePlus(im, _x, _y, color[colorNo], cloudSize, bold);
		    }
        }
    }
    return 0;
}

int qc_cloud_comp_disp(PARAM_INFO var, gdImagePtr im, int ccount, CDATA *cdata, int color[], int colorNo, int cloudSize, char bold)
{
    struct lamc_parameter map;
    int i;
    float x, y;
    int _x, _y;

    MAP_INFO mapInfo = comp_map_info();
    map = mapInfo.map;

    fprintf(stderr,"%f\n",     map.slat1);// = LAMC_SLAT1;
    fprintf(stderr,"%f\n",     map.slat2);// = LAMC_SLAT2;
    fprintf(stderr,"%f\n",     map.olon);//  = LAMC_OLON;
    fprintf(stderr,"%f\n",     map.olat);//  = LAMC_OLAT;
    fprintf(stderr,"%f\n",     map.xo);//    = LAMC_XO;
    fprintf(stderr,"%f\n",     map.yo);//    = LAMC_YO;
    fprintf(stderr,"%f\n",     map.grid);//  = LAMC_GRID;


    for(i=0 ; i<ccount ; i++)
    {
        x = -999.0;
        y = -999.0;
        lamcproj(&cdata[i].lon, &cdata[i].lat, &x, &y, 0, map);

        if (x < -3.0 || x > 714.0 || y < -3.0 || y > 714.0) continue;

        _x = (int) ((x - var.nOrgX ) / var.nXscalef +0.5 );
        _y = (int) (((600.0 - y) - var.nOrgY ) / var.nYscalef +0.5);

        if(_x> 0 && _x< 480 && _y>0 && _y< 600)
        {
	        if( cdata[i].sensor >= 3)
            {
                getImagePlus(im, _x, _y, color[colorNo], cloudSize, bold);
	        }
        }
    }
    return 0;
}
