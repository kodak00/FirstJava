
#ifndef CLOUD_H_
#define CLOUD_H_

#define MAX_STRING_LENGTH 1024
#define FILE_SIZE 128

typedef struct
{
	char  datetime[13];
	float lat;
	float lon;
	float altitude;
	char  type;
	int sensor;
} CDATA;

CDATA* ReadLightingRaw_cloud(PARAM_INFO var, char* CLOUD_FILE, int* ccount);


int cloud_comp_disp(PARAM_INFO var, gdImagePtr im, int ccount, CDATA *cdata, int color[], int colorNo, int cloudSize, char bold);
int qc_cloud_comp_disp(PARAM_INFO var, gdImagePtr im, int ccount, CDATA *cdata, int color[], int colorNo, int cloudSize, char bold);
//int qc_lgt_comp_disp(PARAM_INFO var, gdImagePtr im, int lcount, LDATA *ldata, int color[], int colorNo, int lgtSize, char bold, float** SDATA, float** RDATA);

#endif /* LGT_H_ */
