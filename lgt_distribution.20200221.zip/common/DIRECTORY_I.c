#include "DIRECTORY_I.h"

char* DIRECTORY_I_DIRNAME(const char* _filepath)
{
    static __thread char filepath[PATH_MAX] = {};

    strcpy(filepath, _filepath);

    return dirname(filepath);
}

int DIRECTORY_I_MKDIR(const char* filepath, __mode_t mode)
{
    struct stat s = {};
    char *tmp, *P;

    if (stat(filepath, &s) == -1)
    {
        P = strdupa(filepath);
        tmp = dirname(P);
        if (DIRECTORY_I_MKDIR(tmp, mode) == -1)
            return -1;

        mkdir(filepath, mode);
    }
    else
    {
        if (!(S_ISDIR(s.st_mode)))
        {
            return -1;
        }
    }

    return 0;
}

char* DIRECTORY_I_SEARCH_TIMEFILE(const char* _filepath, const char* _fmt, int timeunit)
{
    static __thread char filepath[PATH_MAX] = {};
    struct tm tm_time = {};
    time_t epochTime = 0;
    int i = 0;

    strcpy(filepath, _filepath);

    if (access(filepath, F_OK) == 0)
    {
        return filepath;
    }

    if (strptime(_filepath, _fmt, &tm_time) == NULL)
    {
        return NULL;
    }

    tm_time.tm_min -= timeunit;

    for (i = 0; i <= timeunit; i++)
    {
        epochTime = mktime(&tm_time);
        strftime(filepath, sizeof (filepath), _fmt, &tm_time);

        if (access(filepath, F_OK) == 0)
        {
            break;
        }

        tm_time.tm_min += 1;
    }

    return filepath;
}

DIRECTORY_I DIRECTORY_I_INSTANCE = {
    .SEARCH_TIMEFILE = DIRECTORY_I_SEARCH_TIMEFILE,
    .DIRNAME = DIRECTORY_I_DIRNAME,
    .MKDIR = DIRECTORY_I_MKDIR
};


DIRECTORY_I* DIRECTORY = &DIRECTORY_I_INSTANCE;
