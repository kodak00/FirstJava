/*
 * dualwind.h
 *
 *  Created on: 2011. 8. 2.
 *      Author: radar
 */

#ifndef DUALWIND_H_
#define DUALWIND_H_

//2km 해상도 정의
#define	XDIM_ORG_2	(371)			//디지털예보를 기준으로	한 2km해상도 X의 크기
#define	YDIM_ORG_2	(631)			//디지털예보를 기준으로	한 2km해상도 X의 크기

#define	MAP_LANC_XO_ORG_2	(105)		//디지털예보를 기준으로	한 2km해상도 좌표변환	중심 X점
#define	MAP_LANC_YO_ORG_2	(337)		//디지털예보를 기준으로	한 2km해상도 좌표변환	중심 Y점

#define	DIM_EXPAND_2	(125)			//디지털예보에서 상하좌우로	2km해상도 확장할 거리(pixel)

#define	XDIM_2	(XDIM_ORG_2+DIM_EXPAND_2*2)				//실제 합성시 사용하는 2km해상도 X의 크기
#define	YDIM_2	(YDIM_ORG_2+DIM_EXPAND_2*2)				//실제 합성시 사용하는 2km해상도 Y의 크기

#define DEL_UPPER_PIXEL_2  (238)
#define DEL_LEFT_PIXEL_2   (15)
#define DEL_RIGHT_PIXEL_2  (80)
#define DEL_BOTTOM_PIXEL_2 (67)

//5km 해상도 정의
#define	XDIM_ORG_5	(148+1)			//디지털예보를 기준으로	한 5km해상도 X의 크기
#define	YDIM_ORG_5	(252+1)			//디지털예보를 기준으로	한 5km해상도 X의 크기

#define	DIM_EXPAND_5	(50)			//디지털예보에서 상하좌우로	5km해상도 확장할 거리(pixel)

#define	XDIM_5	(XDIM_ORG_5+DIM_EXPAND_5*2)				//실제 합성시 사용하는 5km해상도 X의 크기
#define	YDIM_5	(YDIM_ORG_5+DIM_EXPAND_5*2)				//실제 합성시 사용하는 5km해상도 Y의 크기


#define BAD_VALUE_F  (-9999.)
#define PI_DFS	(3.141592)

typedef struct
{
	float u;
	float v;
	float w;
	float ws;
	float wd;

	float sum_ws;
	int sum_cnt;

	float s[2];
} DUALWIND;//디지털 전체 격자점에 대해서 계산함


DUALWIND** getDualWind(char* filename, int altitude);
float utouc(float u, int altitude);
float dtor(float d);
float rtod(float r);
float uvtos(float u, float v);
float uvtod(float u, float v);
float change_5km_to_2km_pixel(int x_or_y);
float change_2km_to_5km_pixel(int x_or_y);

void freeDualwind(DUALWIND** wind, int cnt);

#endif /* DUALWIND_H_ */
