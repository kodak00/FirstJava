/* 
 * File:   BYTE_I.h
 * Author: minsu
 *
 * Created on March 13, 2014, 3:27 PM
 */

#ifndef BYTE_I_H
#define	BYTE_I_H

#ifdef	__cplusplus
extern "C"
{
#endif

#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <sys/types.h>

#ifndef BYTE_L_ENDIAN
#define BYTE_L_ENDIAN 0
#endif

#ifndef BYTE_B_ENDIAN
#define BYTE_B_ENDIAN 1
#endif

#ifndef BYTESWAP8
#define BYTESWAP8(x)    ((x) & 0xff)
#endif

#ifndef BYTESWAP16
#define BYTESWAP16(x)   ((BYTESWAP8(x) << 8) | BYTESWAP8((x) >> 8))
#endif

#ifndef BYTESWAP32
#define BYTESWAP32(x)   ((BYTESWAP16(x) << 16) | BYTESWAP16((x) >> 16))
#endif

#ifndef BYTESWAP64
#define BYTESWAP64(x)   ((BYTESWAP32(x) << 32) | BYTESWAP32((x) >> 32))
#endif

#ifndef getCHAR
#define getCHAR(p) *((char*)(p))
#endif

//#ifndef getSTRING
//#define getSTRING(p) ((char*)(p))
//#endif

#ifndef getINT8
#define getINT8(p) *((int8_t*)(p))
#endif

#ifndef getINT16
#define getINT16(p) *((int16_t*)(p))
#endif

#ifndef getINT32
#define getINT32(p) *((int32_t*)(p))
#endif

#ifndef getINT64
#define getINT64(p) *((int64_t*)(p))
#endif

#ifndef getFLOAT
#define getFLOAT(p) *((float*)(p))
#endif

#ifndef getDOUBLE
#define getDOUBLE(p) *((double*)(p))
#endif

typedef struct _BYTE_I BYTE_I;

extern BYTE_I* BYTE;

struct _BYTE_I
{
    // method
    int (*padSize)(int);
    int (*isEndian)(void);

    void* (*ntoh16)(void* vptr, int n);
    void* (*ntoh32)(void* vptr, int n);
    void* (*ntoh64)(void* vptr, int n);

    void* (*hton16)(void* vptr, int n);
    void* (*hton32)(void* vptr, int n);
    void* (*hton64)(void* vptr, int n);

    void* (*swap16)(void* vptr, int n);
    void* (*swap32)(void* vptr, int n);
    void* (*swap64)(void* vptr, int n);

    void (*ntoh_16)(void* dest, void* vptr, int n);
    void (*ntoh_32)(void* dest, void* vptr, int n);
    void (*ntoh_64)(void* dest, void* vptr, int n);

    void (*hton_16)(void* dest, void* vptr, int n);
    void (*hton_32)(void* dest, void* vptr, int n);
    void (*hton_64)(void* dest, void* vptr, int n);

    void (*swap_16)(void* dest, void* vptr, int n);
    void (*swap_32)(void* dest, void* vptr, int n);
    void (*swap_64)(void* dest, void* vptr, int n);

    char (*toCHAR)(const void* raw);
    char* (*toPSTRING)(const void* raw, int size);

    int8_t(*toINT8)(const void* raw, int endian);
    int16_t(*toINT16)(const void* raw, int endian);
    int32_t(*toINT32)(const void* raw, int endian);
    int64_t(*toINT64)(const void* raw, int endian);

    uint8_t(*toUINT8)(const void* raw, int endian);
    uint16_t(*toUINT16)(const void* raw, int endian);
    uint32_t(*toUINT32)(const void* raw, int endian);
    uint64_t(*toUINT64)(const void* raw, int endian);

    float (*toFLOAT)(const void* raw, int endian);
    double (*toDOUBLE)(const void* raw, int endian);
};

#ifdef	__cplusplus
}
#endif

#endif	/* BYTE_I_H */

