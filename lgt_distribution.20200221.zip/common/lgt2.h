
#ifndef LGT_H_
#define LGT_H_

#define MAX_STRING_LENGTH 1024
#define FILE_SIZE 128

typedef struct
{
	char  datetime[13];
	float lat;
	float lon;
	float impact;
	char  type;
	int sensor;
} LDATA;

typedef struct
{
    char  datetime[13];
    float lat;
    float lon;
    float impact;
    char  type;
    int   sensor;

    int  group_num;     //그룹 넘버
    char  use;           //그룹 할당
    int  tm_cnt;          //시간 대그룹넘버
    int x;               //지도좌표
    int y;               //지도좌표
} LFDATA;

typedef struct {
    LFDATA *L;
    int count;
} O_LINE;

typedef struct ListCen
{
    float x;
    float y;
    double radius;      //반경
    int  total_lgt;     //그룹안 낙뢰 총갯수
    int  color_num;     //색상번호
    char position[20];
} listCen;

typedef struct ListNode
{
    char  isSea;        //해상 1 지역 -1
    char  SeaNum;       //해상 번호
    float lat;
    float lon;
    double radius;
    double dis;
    double angle;
    int  x;
    int  y;

    int  total_lgt;     //그룹안 낙뢰 총갯수
    int  color_num;     //색상번호
    char position[32];
    char position1[4];
    char datetime[13];
    int out_count;      // 외곽선 점 갯수
    int in_count;       // 내부 낙뢰 갯수
    O_LINE *o_line;
    LFDATA *in_point;
    LFDATA *one_point;
    struct ListNode* link;
} listNode;

typedef struct LinkedList_H
{
    listNode* head;
    int count;
    char SeaCnt;
    char notSeaCnt;
    char E_Sea_H;
    char E_Sea_M;
    char E_Sea_L;
    char W_Sea_H;
    char W_Sea_M;
    char W_Sea_L;
    char S_Sea_E;
    char S_Sea_U;
    char S_Sea_D;
    struct LinkedList_H* link;
} linkedList_h;


typedef struct GroupList_H
{
    struct GroupList_H* head;
    listNode* GROUP;
    int gCnt;
    int TimeCnt;
    char datetime[13];

    struct GroupList_H* link;
} GroupList_h;

typedef struct NextList_H
{
    struct NextList_H* head;
    listNode*          Cen;
    int N_total;

    struct NextList_H* link;
} NextList_h;


typedef struct G_START_P
{
    struct ListNode* head;
    int N_total;
    struct G_START_P* link;
} Start_Point;

typedef struct
{
    char aws_name[32];
    float aws_lat;
    float aws_lon;
} AwsDIS;

typedef struct
{
    int code;
    int part_inx;
    int vertex_inx;
    float lat;
    float lon;
} Fst_set;

typedef struct
{
    int code;
    int part_inx;
    float max_lat;
    float max_lon;
    float min_lat;
    float min_lon;
} Fst_sido;

typedef struct
{
    int code;
    int part_inx;
} imsi_table;

typedef struct
{
    float lat;
    float lon;

} vertex_table;


int getImageCircle(gdImagePtr im, int x, int y, int color);
//int getImagePlus(gdImagePtr im, int x, int y, int color);
int getImagePlus(gdImagePtr im, int x, int y, int color, int lsize, char bold);
int getImageCross(gdImagePtr im, int x, int y, int color);

LDATA* ReadLightingRaw(PARAM_INFO var, char* LGT_FILE, int* lcount);
LDATA* ReadLightingRaw2(PARAM_INFO var, char* LGT_FILE, int* lcount);

int lgt_comp_disp(PARAM_INFO var, gdImagePtr im, int lcount, LDATA *ldata, int color[], int colorNo, int lgtSize, char bold);
int qc_lgt_comp_disp(PARAM_INFO var, gdImagePtr im, int lcount, LDATA *ldata, int color[], int colorNo, int lgtSize, char bold);
//int qc_lgt_comp_disp(PARAM_INFO var, gdImagePtr im, int lcount, LDATA *ldata, int color[], int colorNo, int lgtSize, char bold, float** SDATA, float** RDATA);

int lgt_fst_disp(PARAM_INFO var, gdImagePtr im, int lcount, LFDATA *ldata, int color[], int colorNo, int lgtSize, char bold);

#endif /* LGT_H_ */
