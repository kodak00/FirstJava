
#include "INI_I.h"

int INI_I_LOAD(const char* filepath, const char* section, const char* name)
{
    INI->_.ini_fd = ini_open(filepath, "r", "#");
    if (unlikely(INI->_.ini_fd == NULL))
    {
        return -1;
    }
    else
    {
        if (ini_locateHeading(INI->_.ini_fd, section) == -1)
        {
            return -1;
        }

        if (ini_locateKey(INI->_.ini_fd, name))
        {
            return -1;
        }
    }

    return 0;
}

int INI_I_isVALUE(const char* filepath, const char* section, const char* name)
{
    if (INI_I_LOAD(filepath, section, name) == -1)
    {
        return -1;
    }

    return 0;
}

char* INI_I_getSTRING(const char* filepath, const char* section, const char* name)
{
    static char value[BUFSIZ] = {};

    if (INI_I_LOAD(filepath, section, name) == -1)
    {
        return "";
    }
    else
    {
        memset(value, 0, sizeof (value));
        ini_readString(INI->_.ini_fd, value, BUFSIZ);

        ini_close(INI->_.ini_fd);
    }

    return (char*) value;
}

int32_t INI_I_getINT(const char* filepath, const char* section, const char* name)
{
    int32_t value = 0;

    if (INI_I_LOAD(filepath, section, name) == -1)
    {
        return -1L;
    }
    else
    {
        ini_readInt(INI->_.ini_fd, &value);

        ini_close(INI->_.ini_fd);
    }

    return value;
}

double INI_I_getDOUBLE(const char* filepath, const char* section, const char* name)
{
    double value = 0;

    if (INI_I_LOAD(filepath, section, name) == -1)
    {
        return -1.0;
    }
    else
    {
        ini_readDouble(INI->_.ini_fd, &value);

        ini_close(INI->_.ini_fd);
    }

    return value;
}


INI_I INI_I_INSTANCE = {
    .isVALUE = INI_I_isVALUE,

    .getSTRING = INI_I_getSTRING,

    .getINT = INI_I_getINT,

    .get_DOUBLE = INI_I_getDOUBLE
};


INI_I* INI = &INI_I_INSTANCE;