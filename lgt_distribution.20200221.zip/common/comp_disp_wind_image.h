

//#define FONT_PATH "/DATA/CONFIG/FONT"
#define FONT_PATH "/DATA/CONFIG/FNT"

#define BOUND  -12800     //Out of bound
#define BAD_VAL  -12700   //bad value
#define LEGEND_CNT 31

#define FILE_SIZE 128

typedef struct
{
  float  lat;
  float  lon;
  float  x;
  float  y;    
  float  ws;
  float  wd;
  int  xx;
  int  yy;
  
} WIND;

int data_disp_comp_dualwind(PARAM_INFO var, DUALWIND **wind, gdImagePtr im, int color[], COLOR_INFO color_info);

int dualwind_draw(gdImagePtr im, int x, int y, float ws, float wd, int line_color, int size, int wing);

int data_disp_comp_wind_vad(char* PATH, char* HEAD, char* TAIL, PARAM_INFO var, SITE_INFO site_info, gdImagePtr im, int color[], COLOR_INFO color_info);
int data_disp_comp_wind_vvp(char* PATH, char* HEAD, char* TAIL, PARAM_INFO var, SITE_INFO site_info, gdImagePtr im, int color[], COLOR_INFO color_info);

int wind_draw(PARAM_INFO var, gdImagePtr im, WIND info[], int color[], int size, int wing, int cnt, int color_num);

int findXYInfo(WIND info[], int cnt, int xx, int yy);

