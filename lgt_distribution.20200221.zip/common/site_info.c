/*
 * site_info.c
 *
 *  Created on: 2011. 10. 1.
 *      Author: radar
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "map_ini.h"
#include "parameter.h"
#include "site_info.h"

//??ü ????Ʈ ��?? 
SITE_INFO getSiteInfoRead(PARAM_INFO var, char *path)
{
	struct lamc_parameter  map;
  
	SITE_INFO site_info;
	FILE *fp;
	
	int cnt = 0, i;
	int site_range;
	float site_lat, site_lon,  site_x, site_y;
	char site_engname[4],site_korname[10];	
	int  zm = 1;
	int x,y;
	
	//?ʱ?ȭ 
	memset(&site_info, 0, sizeof(site_info));

	MAP_INFO mapInfo = comp_map_info();
	map = mapInfo.map;
	
	int zoom_level, zm_cnt;
	zoom_level  = var.nzoomdepth;     
	zm_cnt = zoom_level;  

	if( zoom_level > 0 ) {
		for (i=0; i < zoom_level ; i++) {
			if(var.zoomType[i] == 3) zm_cnt -= 1;
		}
	}  
	
	zoom_level = zm_cnt;
	if(zm_cnt > 0) zm = zm_cnt;
	 	
	//?ʱ?ȭ
 	site_info.cnt = 0; 		 	
 	
	//File Read
	fp = fopen(path, "r");   
	
	if (fp != NULL)
	{
	    //fprintf(stderr,"path-------------> %s\n",  path);    
	   
		fscanf(fp, "%d", &cnt);
		site_info.cnt = cnt;		
 	    site_info.data = (SITE_DATA *)malloc(cnt*sizeof(SITE_DATA));
	  	    
		for (i=0; i<cnt; i++)
		{			
			fscanf(fp, "%s%s%f%f%d", site_engname, site_korname, &site_lat, &site_lon, &site_range);			
			//fprintf(stderr," sitename--->%s \n",site_engname);
			
			lamcproj(&site_lon, &site_lat, &site_x, &site_y, 0, map);
			
			x = (int) ((site_x - var.nOrgX ) / var.nXscalef +0.5 );
            y = (int) (((600.0 - site_y) - var.nOrgY ) / var.nYscalef +0.5);
            
			//fprintf(stderr,"%f - %f : %f - %f : %d - %d \n", site_lon, site_lat, site_x, site_y, x, y);    
        
			if ((x >= 0 && x <= var.nDispX) && (y >= 0 && y <= var.nDispY)) {
  						
				strcpy(site_info.data[i].sitename, site_engname);			
				strcpy(site_info.data[i].sitekorname, site_korname);
				site_info.data[i].lon = site_lon;
				site_info.data[i].lat = site_lat;				
				site_info.data[i].x = x;
				site_info.data[i].y = y;
				site_info.data[i].range = site_range;
	  		}
			
		}
	}		
	fclose(fp);
	
	return site_info;
}



int getSiteInfo(PARAM_INFO var, char *path, SITE_INFO *site_info)
{
  struct lamc_parameter  map;
  
	FILE *fp;
	
	int cnt = 0, i;
	int site_range;
	float site_lat, site_lon,  site_x, site_y;
	char site_engname[4],site_korname[10];	
	 	
	//?ʱ?ȭ
 	site_info->cnt = 0; 		 	
 	
	//File Read
	fp = fopen(path, "r");   
	
	if (fp != NULL)
	{  
		fscanf(fp, "%d", &cnt);
		site_info->cnt = cnt;		
 	  site_info->data = (SITE_DATA *)malloc(cnt*sizeof(SITE_DATA));
	  	    
		for (i=0; i<cnt; i++)
		{			
			fscanf(fp, "%s%s%f%f%d", site_engname, site_korname, &site_lat, &site_lon, &site_range);			
 			strcpy(site_info->data[i].sitename, site_engname);			
 			strcpy(site_info->data[i].sitekorname, site_korname);
 			site_info->data[i].lon = site_lon;
 			site_info->data[i].lat = site_lat;				
 			site_info->data[i].range = site_range;		  			
		}
	}		
	fclose(fp);

	return site_info->cnt;
}

SITE_INFO chkSiteInfo(PARAM_INFO var, SITE_INFO site_info)
{
  SITE_INFO site;
  SITENAME_INFO chkSiteinfo[site_info.cnt];
  int i, z, h, sitecnt=0;
  
	char seps[] = "-";
	char *token;
  
  if(strlen(var.site_data) != 0){    
	    
		token = strtok(var.site_data, seps);		
		for(z=0; token!=NULL ; z++) {					
				//fprintf(stderr," sitename--->%s , %s \n", token, var.site_data);
				strcpy(chkSiteinfo[z].sitename, token);
				sitecnt++;						
				token = strtok(NULL, seps); //token ?ʱ?ȭ(?缳��)				
		}
	}
	
	//?????? ????Ʈ?? ǥ??
	site.cnt = sitecnt; 
	site.data = (SITE_DATA *)malloc(sitecnt*sizeof(SITE_DATA));

	for (i=0; i<sitecnt; i++)
	{
		h = getFindSiteInfo(site_info, cb_ToUpper(chkSiteinfo[i].sitename));
		if(h > -1){	
		  
		  //fprintf(stderr," sitename--->%s , %s \n", chkSiteinfo[i].sitename, site_info.data[h].sitename);
		  
		  strcpy(site.data[i].sitename, site_info.data[h].sitename);			
			strcpy(site.data[i].sitekorname, site_info.data[h].sitekorname);
			site.data[i].lon = site_info.data[h].lon;
			site.data[i].lat = site_info.data[h].lat;
			site.data[i].x = site_info.data[h].x;  
      site.data[i].y = site_info.data[h].y;  
			site.data[i].range = site_info.data[h].range;		
		}
	}
  
  return site;
}

//?????? ????Ʈ ã??
int getFindSiteInfo(SITE_INFO info, char *search)
{
	int i, cnt=0;
	
	cnt = info.cnt;	
	for (i=0; i<cnt; i++) {		
		 if ( strcmp(info.data[i].sitename, search) == 0 )
					 return i;
	}

	return -1;
}

//?ҹ??ڸ? ?빮??
char * cb_ToUpper(char *s1)
{
    int i;
    int rlen = strlen(s1);

    for(i = 0; i < rlen; i++)
    {
        if(s1[i] >= 97 && s1[i] <= 122)
        {
            s1[i] = s1[i] - 32;
        }
    }

    return(s1);
}
//?빮?ڸ? ?ҹ???
char * cb_ToLower(char *s1)
{
    int i;
    int rlen = strlen(s1);

    for(i = 0; i < rlen; i++)
    {
        if(s1[i] >= 65 && s1[i] <= 90)
        {
            s1[i] = s1[i] + 32;
        }
    }

    return(s1);
}

void freeIndex(SITE_INFO site)
{
		if(site.cnt > 0) {
			  free(site.data);
		}
}
