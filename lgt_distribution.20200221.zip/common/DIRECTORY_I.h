/* 
 * File:   DIRECTORY_I.h
 * Author: lucid32
 *
 * Created on 2014년 8월 13일 (수), 오후 7:00
 */

#ifndef DIRECTORY_I_H
#define	DIRECTORY_I_H

#ifdef	__cplusplus
extern "C"
{
#endif

#include <stdlib.h>
#include <string.h>
#include <libgen.h>
#include <limits.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
    
typedef struct _DIRECTORY_I DIRECTORY_I;

extern DIRECTORY_I* DIRECTORY;

struct _DIRECTORY_I
{
    
    char* (*SEARCH_TIMEFILE)(const char* _filepath, const char* _fmt, int timeunit);
    char* (*DIRNAME)(const char* filepath);
    int (*MKDIR)(const char* filepath, __mode_t mode);
};

#ifdef	__cplusplus
}
#endif

#endif	/* DIRECTORY_I_H */

