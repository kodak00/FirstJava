/* 
 * File:   macro.h
 * Author: lucid32
 *
 * Created on 2014년 7월 1일 (화), 오전 10:00
 */

#ifndef MACRO_H
#define	MACRO_H

#ifdef	__cplusplus
extern "C"
{
#endif

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <limits.h>
#include <libgen.h>
#include <getopt.h>
#include <omp.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>

#include <iconv.h>
#include <math.h>
#include <zlib.h>


#ifndef SUCC
#define SUCC 0
#endif

#ifndef FAIL
#define FAIL -1
#endif

#ifndef LOOP
#define LOOP true
#endif

#ifndef null
#define null '\0'
#endif

#ifndef likely    
#define likely(x) __builtin_expect(!!(x), 1)
#endif

#ifndef unlikely
#define unlikely(x) __builtin_expect(!!(x), 0)
#endif

#ifndef _free
#define _free(x) do{ if(unlikely(x)) free(x); x = NULL; } while(0)
#endif

#ifndef KST_OFFSET
#define KST_OFFSET (60 * 60 * 9)
#endif

#ifndef NULL_CHECK
#define NULL_CHECK(str) (str == null)? "":(str)
#endif

#ifndef isNULL
#define isNULL(ptr) (ptr == null)? true:false
#endif

#ifndef M_MICRO
#define M_MICRO (1000000) //(10^6)
#endif

#ifndef M_NANO
#define M_NANO (1000000000) //( 10^9)
#endif

#ifndef _dispose
#define _dispose(pObj) \
do{\
    if(unlikely(pObj == NULL))\
    {\
        return;\
    }\
    else{\
        _free(*pObj);\
    }\
}while(0)
#endif

#ifndef _strerror
#define _strerror \
do{ \
    struct timeval tv = {};\
    gettimeofday(&tv, NULL);\
    time_t errTime = tv.tv_sec + KST_OFFSET; \
    struct tm* errTm = gmtime(&errTime); \
    fprintf(stderr, "[ERROR] [%04d-%02d-%02d %02d:%02d:%02d,%03ld] %s(%s:%d): %s\n", errTm->tm_year + 1900, errTm->tm_mon+1, errTm->tm_mday, errTm->tm_hour, errTm->tm_min, errTm->tm_sec, tv.tv_usec/1000, __func__, __FILE__, __LINE__, strerror(errno)); \
}while(0)
#endif

#ifndef _OPENMP
#define _OPENMP
#endif

#ifdef _OPENMP

#ifndef OMP_WTIME_START
#define OMP_WTIME_START double omp_wtime = omp_get_wtime()
#endif

#ifndef OMP_WTIME_PRINT
#define OMP_WTIME_PRINT fprintf(stderr, "%s(%s:%3d)[%2d/%2d]: WaitTime: %lf\n", __FILE__, __func__, __LINE__, omp_get_thread_num(), omp_get_num_threads()-1, omp_get_wtime() - omp_wtime)
#endif

#endif


#ifdef	__cplusplus
}
#endif

#endif	/* MACRO_H */

