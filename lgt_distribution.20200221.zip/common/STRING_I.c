#include "STRING_I.h"

int STRING_I_RTRIM(char* str)
{
    char* ptr = NULL;
    int nTrim = 0;

    // Right Trim
    ptr = str + strlen(str) - 1;
    //while (isspace(*ptr) || !isascii(*ptr))
    while (isspace(*ptr))
    {
        nTrim++;
        *ptr = '\0';
        ptr--;
    }

    return nTrim;
}

int STRING_I_LTRIM(char* str)
{
    char* ptr = NULL;
    int len;
    int nTrim = 0;

    // Left Trim
    ptr = str;
    //while (isspace(*ptr) || !isascii(*ptr))
    while (isspace(*ptr))
    {
        nTrim++;
        ptr++;
    }

    len = strlen(ptr);
    memmove(str, ptr, len);
    str[len] = '\0';

    return nTrim;
}

int STRING_I_TRIM(char* str)
{
    int nTrim = 0;

    nTrim += STRING_I_RTRIM(str);
    nTrim += STRING_I_LTRIM(str);

    return nTrim;
}

int STRING_I_REPLACE_CHAR(char* str, const char oldWord, const char newWord)
{
    char* ptr = NULL;

    ptr = str;
    while (*ptr)
    {
        if (*ptr == oldWord)
        {
            *ptr = newWord;
            break;
        }

        ptr++;
    }

    return 0;
}

STRING_I STRING_I_INSTANCE = {
    .RTRIM = STRING_I_RTRIM,
    .LTRIM = STRING_I_LTRIM,
    .TRIM = STRING_I_TRIM,

    .REPLACE_CHAR = STRING_I_REPLACE_CHAR


};

STRING_I* STRING = &STRING_I_INSTANCE;

