/* 
 * File:   APP_I.h
 * Author: lucid32
 *
 * Created on 2014년 8월 13일 (수), 오후 4:24
 */

#ifndef APP_I_H
#define	APP_I_H

#ifdef	__cplusplus
extern "C"
{
#endif

#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>
#include <sys/resource.h>

#include "DIRECTORY_I.h"
    
typedef struct _APP_I APP_I;

extern APP_I* APP;

struct _APP_I
{
    FILE* fp_log;
    
    struct
    {
        char* app_name;
        char* app_home;
        char* app_user;
        char* app_conf;
        char* app_logpath;
        int argc;
        char** argv;
        int verbose;

        char* tzname[2];
    } _;

    void (*APP_INIT)(int argc, char** argv);

    void (*APP_END)();
};


#ifdef	__cplusplus
}
#endif

#endif	/* APP_I_H */

