/* 
 * File:   INI_I.h
 * Author: lucid32
 *
 * Created on 2014년 8월 12일 (화), 오후 6:43
 */

#ifndef INI_I_H
#define	INI_I_H

#ifdef	__cplusplus
extern "C"
{
#endif

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <stdbool.h>
    
#include <libini.h>
    
#include "common/macro.h"
#include "common/STRING_I.h"

typedef struct _INI_I INI_I;

extern INI_I* INI;

struct _INI_I
{

    struct
    {
        ini_fd_t ini_fd;
    } _;

    /**
     * 값이 존재할 경우 0을 리턴, 없을 경우 -1을 리턴
     */
    int (*isVALUE)(const char* filepath, const char* section, const char* name);
    
    char* (*getSTRING)(const char* filepath, const char* section, const char* name);
    
    int32_t(*getINT)(const char* filepath, const char* section, const char* name);
    
    double (*get_DOUBLE)(const char* filepath, const char* section, const char* name);
};

#ifdef	__cplusplus
}
#endif

#endif	/* INI_I_H */

