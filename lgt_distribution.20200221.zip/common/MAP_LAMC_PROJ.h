/* 
 * File:   MAP_LAMC_PROJ.h
 * Author: lucid32
 *
 * Created on 2014년 8월 20일 (수), 오후 11:18
 */

#ifndef MAP_LAMC_PROJ_H
#define	MAP_LAMC_PROJ_H

#ifdef	__cplusplus
extern "C"
{
#endif

#include "macro.h"
#include <math.h>
typedef struct _MAP_LAMC_PROJ MAP_LAMC_PROJ;

extern MAP_LAMC_PROJ* newMAP_LAMC_PROJ();

struct _MAP_LAMC_PROJ
{

    struct
    {
        float Re; /* 사용할 지구반경 [ km ]      */
        float grid; /* 격자간격        [ km ]      */
        float slat1; /* 표준위도        [degree]    */
        float slat2; /* 표준위도        [degree]    */
        float olon; /* 기준점의 경도   [degree]    */
        float olat; /* 기준점의 위도   [degree]    */
        float ox; /* 기준점의 X좌표  [격자거리]  */
        float oy; /* 기준점의 Y좌표  [격자거리]  */

        struct
        {
            int first; /* ?쒖옉?щ? (0 = 泥섏쓬)         */
            double PI, DEGRAD, RADDEG;
            double re, olon, olat, sn, sf, ro;
        } var;
    } _;

    void (*LATLON2XY)(MAP_LAMC_PROJ* obj, float *x, float *y, float lat, float lon);
    void (*XY2LATLON)(MAP_LAMC_PROJ* obj, float *lat, float *lon, float x, float y);
    void (*DISPOSE)(MAP_LAMC_PROJ** pObj);
};



#ifdef	__cplusplus
}
#endif

#endif	/* MAP_LAMC_PROJ_H */

