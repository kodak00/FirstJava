#ifndef MAP_INI_H_
#define MAP_INI_H_ 1
/****************************************************************
*
*  GPS80 Earth Referance Ellipsoid 의 경우
*
*	  45N 부근에서의 지구반경은 6370.19584 km 이다.
*
****************************************************************/

struct albe_parameter {
	float	Re;		  /* 사용할 지구반경 [ km ]	  */
	float	grid;		/* 격자간격		[ km ]	  */
	float	slat1;	   /* 표준위도		[degree]	*/
	float	slat2;	   /* 표준위도		[degree]	*/
	float	olon;		/* 기준점의 경도   [degree]	*/
	float	olat;		/* 기준점의 위도   [degree]	*/
	float	xo;		  /* 기준점의 X좌표  [격자거리]  */
	float	yo;		  /* 기준점의 Y좌표  [격자거리]  */
	int	first;	   /* 시작여부 (0 = 시작)		 */
};

struct azed_parameter {
	float	Re;		  /* 사용할 지구반경 [ km ]	  */
	float	grid;		/* 격자간격		[ km ]	  */
	float	slon;		/* 중심경도		[degree]	*/
	float	slat;		/* 중심위도		[degree]	*/
	float	olon;		/* 기준점의 경도   [degree]	*/
	float	olat;		/* 기준점의 위도   [degree]	*/
	float	xo;		  /* 기준점의 X좌표  [격자거리]  */
	float	yo;		  /* 기준점의 Y좌표  [격자거리]  */
	int	first;	   /* 시작여부 (0 = 처음)		 */
};

struct eqdc_parameter {
	float	Re;		  /* 사용할 지구반경 [ km ]	  */
	float	grid;		/* 격자간격		[ km ]	  */
	float	slon;		/* 표준경도		[degree]	*/
	float	slat;		/* 표준위도		[degree]	*/
	float	olon;		/* 기준점의 경도   [degree]	*/
	float	olat;		/* 기준점의 위도   [degree]	*/
	float	xo;		  /* 기준점의 X좌표  [격자거리]  */
	float	yo;		  /* 기준점의 Y좌표  [격자거리]  */
	int	first;	   /* 시작여부 (0 = 처음)		 */
};

struct lamc_parameter {
	float	Re;		  /* 사용할 지구반경 [ km ]	  */
	float	grid;		/* 격자간격		[ km ]	  */
	float	slat1;	   /* 표준위도		[degree]	*/
	float	slat2;	   /* 표준위도		[degree]	*/
	float	olon;		/* 기준점의 경도   [degree]	*/
	float	olat;		/* 기준점의 위도   [degree]	*/
	float	xo;		  /* 기준점의 X좌표  [격자거리]  */
	float	yo;		  /* 기준점의 Y좌표  [격자거리]  */
	int	first;	   /* 시작여부 (0 = 시작)		 */
};

struct lame_parameter {
	float	Re;		  /* 사용할 지구반경 [ km ]	  */
	float	grid;		/* 격자간격		[ km ]	  */
	float	slon;		/* 표준경도		[degree]	*/
	float	slat;		/* 표준위도		[degree]	*/
	float	olon;		/* 기준점의 경도   [degree]	*/
	float	olat;		/* 기준점의 위도   [degree]	*/
	float	xo;		  /* 기준점의 X좌표  [격자거리]  */
	float	yo;		  /* 기준점의 Y좌표  [격자거리]  */
	int	first;	   /* 시작여부 (0 = 처음)		 */
};

struct merc_parameter {
	float	Re;		  /* 사용할 지구반경 [ km ]	  */
	float	grid;		/* 격자간격		[ km ]	  */
	float	slon;		/* 표준경도		[degree]	*/
	float	slat;		/* 표준위도		[degree]	*/
	float	olon;		/* 기준점의 경도   [degree]	*/
	float	olat;		/* 기준점의 위도   [degree]	*/
	float	xo;		  /* 기준점의 X좌표  [격자거리]  */
	float	yo;		  /* 기준점의 Y좌표  [격자거리]  */
	int	first;	   /* 시작여부 (0 = 처음)		 */
};

struct milm_parameter {
	float	Re;		  /* 사용할 지구반경 [ km ]	  */
	float	grid;		/* 격자간격		[ km ]	  */
	float	slon;		/* 표준경도		[degree]	*/
	float	olon;		/* 기준점의 경도   [degree]	*/
	float	olat;		/* 기준점의 위도   [degree]	*/
	float	xo;		  /* 기준점의 X좌표  [격자거리]  */
	float	yo;		  /* 기준점의 Y좌표  [격자거리]  */
	int	first;	   /* 시작여부 (0 = 처음)		 */
};
struct oblm_parameter {
	float	Re;		  /* 사용할 지구반경 [ km ]	  */
	float	grid;		/* 격자간격		[ km ]	  */
	float	slon;		/* 지도 극점 경도  [degree]	*/
	float	slat;		/* 지도 극점 위도  [degree]	*/
	float	olon;		/* 기준점의 경도   [degree]	*/
	float	olat;		/* 기준점의 위도   [degree]	*/
	float	xo;		  /* 기준점의 X좌표  [격자거리]  */
	float	yo;		  /* 기준점의 Y좌표  [격자거리]  */
	int	first;	   /* 시작여부 (0 = 처음)		 */
};

struct orth_parameter {
	float	Re;		  /* 사용할 지구반경 [ km ]	  */
	float	grid;		/* 격자간격		[ km ]	  */
	float	slon;		/* 표준경도		[degree]	*/
	float	slat;		/* 표준위도		[degree]	*/
	float	olon;		/* 기준점의 경도   [degree]	*/
	float	olat;		/* 기준점의 위도   [degree]	*/
	float	xo;		  /* 기준점의 X좌표  [격자거리]  */
	float	yo;		  /* 기준점의 Y좌표  [격자거리]  */
	int	first;	   /* 시작여부 (0 = 처음)		 */
};

struct sinu_parameter {
	float	Re;		  /* 사용할 지구반경 [ km ]	  */
	float	grid;		/* 격자간격		[ km ]	  */
	float	slon;		/* 표준경도		[degree]	*/
	float	olon;		/* 기준점의 경도   [degree]	*/
	float	olat;		/* 기준점의 위도   [degree]	*/
	float	xo;		  /* 기준점의 X좌표  [격자거리]  */
	float	yo;		  /* 기준점의 Y좌표  [격자거리]  */
	int	first;	   /* 시작여부 (0 = 처음)		 */
};

struct ster_parameter {
	float	Re;		  /* 사용할 지구반경 [ km ]	  */
	float	grid;		/* 격자간격		[ km ]	  */
	float	slon;		/* 중심경도		[degree]	*/
	float	slat;		/* 중심위도		[degree]	*/
	float	olon;		/* 기준점의 경도   [degree]	*/
	float	olat;		/* 기준점의 위도   [degree]	*/
	float	xo;		  /* 기준점의 X좌표  [격자거리]  */
	float	yo;		  /* 기준점의 Y좌표  [격자거리]  */
	int	first;	   /* 시작여부 (0 = 처음)		 */
	int	polar;	   /* 90N중심에 투영면이 60N을 지나는 경우 (1) */
};

struct trnm_parameter {
	float	Re;		  /* 사용할 지구반경 [ km ]	  */
	float	grid;		/* 격자간격		[ km ]	  */
	float	slon;		/* 원점의 경도	 [degree]	*/
	float	slat;		/* 원점의 위도	 [degree]	*/
	float	olon;		/* 기준점의 경도   [degree]	*/
	float	olat;		/* 기준점의 위도   [degree]	*/
	float	xo;		  /* 기준점의 X좌표  [격자거리]  */
	float	yo;		  /* 기준점의 Y좌표  [격자거리]  */
	int	first;	   /* 시작여부 (0 = 처음)		 */
};

struct vand_parameter {
	float	Re;		  /* 사용할 지구반경 [ km ]	  */
	float	grid;		/* 격자간격		[ km ]	  */
	float	slon;		/* 표준경도		[degree]	*/
	float	olon;		/* 기준점의 경도   [degree]	*/
	float	olat;		/* 기준점의 위도   [degree]	*/
	float	xo;		  /* 기준점의 X좌표  [격자거리]  */
	float	yo;		  /* 기준점의 Y좌표  [격자거리]  */
	int	first;	   /* 시작여부 (0 = 처음)		 */
};

typedef struct {
	
	float zm;	
	struct lamc_parameter map;	
	
} MAP_INFO;

int  lamcproj(float *lon, float *lat, float *x, float *y, int code, struct lamc_parameter map );

MAP_INFO comp_map_info();

#endif /* _MAP_INI_H_ */
