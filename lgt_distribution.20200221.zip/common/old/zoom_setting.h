
#ifndef ZOOM_SETTING_H_
#define ZOOM_SETTING_H_

PARAM_INFO zoom_setting(PARAM_INFO var, int stlen, int zi[100], char zips[50][20]);

PARAM_INFO click_zoom(PARAM_INFO var, int nx, int ny);
PARAM_INFO click_zoomout(PARAM_INFO var, int nx, int ny  );

PARAM_INFO drag_set_position(PARAM_INFO var, int d_stX,int d_stY, int d_edX, int d_edY);
PARAM_INFO drag_dup_position(PARAM_INFO var, int deltaX,int deltaY );

PARAM_INFO boxzoom_set_position(PARAM_INFO var, int d_stX,int d_stY, int d_edX,int d_edY);

#endif /* ZOOM_SETTING_H_ */
