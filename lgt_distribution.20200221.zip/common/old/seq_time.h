/*
 * seq_time.h
 *
 *  Created on: 2011. 9. 9.
 *      Author: radar
 */

#ifndef SEQ_TIME_H_
#define SEQ_TIME_H_

int get_time(int  *YY, int *MM, int *DD, int *HH, int *min, int *sec);
int time2seq(int YY, int MM, int DD, int HH, int min, char mode);
int seq2time( int seq, int  *YY, int *MM, int *DD, int *HH, int *min, char mode, char c24 );

struct tm getIncMin(struct tm tm_ptr, int addmin);
struct tm getIncHour(struct tm tm_ptr,int addHour);
struct tm getIncDay(struct tm tm_ptr,int addday);
struct tm getIncYear(struct tm tm_ptr,int addday);
struct tm getIncMonth(struct tm tm_ptr,int addMonth);
struct tm getConvStrToDateTime(char *str);

#endif /* SEQ_TIME_H_ */
