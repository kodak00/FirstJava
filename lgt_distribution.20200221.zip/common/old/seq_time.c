#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "seq_time.h"       

char *strptime(const char *s, const char *format, struct tm *tm);

/******************************************************************
*
*  ����ð��� ���� (�����ð�, KST-9)
*
******************************************************************/

int  get_time( YY, MM, DD, HH, min, sec )

int  *YY, *MM, *DD, *HH, *min, *sec;
{
    struct tm  *now;
    time_t     ctm;

    time( &ctm );
    now  = localtime( &ctm );
    *YY  = ( now -> tm_year );
    if (*YY < 50)
        *YY += 2000;
    else
        *YY += 1900;
    *MM  = ( now -> tm_mon  ) + 1;
    *DD  = now -> tm_mday;
    *HH  = now -> tm_hour;
    *min = now -> tm_min;
    *sec = now -> tm_sec;

    return 0;
}

/******************************************************************
*
*  �ð������� ���� �Ϸù�ȣ�� ��ȯ
*
*    o YY,MM,DD,HH,min : ��,��,��,��,��
*    o mode            : ��ȯ�� ����
*         . mode = 'd' : 1900. 1. 1.       ���� �ϼ�
*         . mode = 'h' : 1900. 1. 1. 00    ���� �ð���
*         . mode = 'm' : 1900. 1. 1. 00:00 ���� �м�
*
******************************************************************/

int  time2seq( YY, MM, DD, HH, min, mode )

int  YY, MM, DD, HH, min;
char mode;
{
    static int  month[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
    int  seq;
    int  i;

    seq = YY - 1900;
    seq = seq*365 + (seq + 3)/4;
    for( i = 0; i < MM-1; i++ )
        seq += month[i];
    if( ( MM > 2 ) && ( YY % 4 == 0 ) )  seq += 1;
    seq += DD - 1;

    if( mode == 'h' )
        seq = seq*24 + HH;
    else if( mode == 'm' )
        seq = ( seq*24 + HH )*60 + min;

    return seq;
}

/******************************************************************
*
*  �Ϸù�ȣ�� �ð����� ��ȯ
*
*    o seq             : �Ϸù�ȣ
*    o YY,MM,DD,HH,min : �ð�
*    o mode            : seq�� ����
*         . mode = 'd' : 1900. 1. 1.       ���� �ϼ�
*         . mode = 'h' : 1900. 1. 1. 00    ���� �ð���
*         . mode = 'm' : 1900. 1. 1. 00:00 ���� �м�
*    o c24             : �ð���ȯ ���
*         . c24  = 'n' : 00:00
*         . c24  = 'y' : 24:00
*
******************************************************************/

int  seq2time( seq, YY, MM, DD, HH, min, mode, c24 )

int  seq;
int  *YY, *MM, *DD, *HH, *min;
char mode, c24;
//int  seq2time( int seq, int  *YY, int *MM, int *DD, int *HH, int *min, char mode, char c24 )
{
    static int  month[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
    //int  iseq, i;
    int i;

    *min = 0;
    if( mode == 'm' ) {
        *min = seq % 60;
        seq /= 60;
    }
    *HH = 0;
    if( mode == 'h' || mode == 'm' ) {
        *HH  = seq % 24;
        seq /= 24;
        if( c24 == 'y' ) {
            if( *HH == 0 && *min == 0 ) {
                *HH  = 24;
                *min = 0;
                seq -= 1;
            }
        }
    }
    *YY = (seq/1461)*4 + 1900;
    if( (seq %= 1461) > 365 ) {
        seq -= 366;
        *YY += seq/365 + 1;
        seq %= 365;
    }

    seq += 1;
    if( (*YY % 4) == 0 )
        month[1] = 29;
    else
        month[1] = 28;

    for( i = 0; i < 12; i++ ) {
        if( seq > month[i] )
            seq -= month[i];
        else {
            *MM = i + 1;
            *DD = seq;
            break;
        }
    }
    return 0;
}

struct tm getIncMin(struct tm tm_ptr, int addmin)
{
	time_t the_time;
	struct tm new_tm_ptr;
	the_time = mktime(&tm_ptr);
	the_time = the_time + (60 * addmin);
	new_tm_ptr = *(localtime(&the_time));
	return new_tm_ptr;
}

struct tm getIncHour(struct tm tm_ptr,int addHour)
{
	time_t the_time;
	struct tm new_tm_ptr;
	the_time = mktime(&tm_ptr);
	the_time = the_time + (60 * 60 * addHour);
	new_tm_ptr = *(localtime(&the_time));
	return new_tm_ptr;
}

struct tm getIncDay(struct tm tm_ptr,int addday)
{
	time_t the_time;
	struct tm new_tm_ptr;
	the_time = mktime(&tm_ptr);
	the_time = the_time + (60 * 60 * 24 * addday);
	new_tm_ptr = *(localtime(&the_time));
	return new_tm_ptr;
}

struct tm getIncYear(struct tm tm_ptr,int addday)
{
	time_t the_time;
	struct tm new_tm_ptr;
	the_time = mktime(&tm_ptr);
	the_time = the_time + (60 * 60 * 24 * 365 * addday);
	new_tm_ptr = *(localtime(&the_time));
	return new_tm_ptr;
}

struct tm getIncMonth(struct tm tm_ptr,int addMonth){
	struct tm new_tm_ptr;
	char day_str[3];
	char month_str[3];
	char temp_str[3];
	int month,month_temp;
	int day,day_temp;
	int month_change_count = 0;
	int sign;
	int isFirst=1;

	if (addMonth < 0)
		sign = -1;
	else if(addMonth > 0)
		sign = 1;
	else
		return tm_ptr;

	strftime(month_str,sizeof(month_str),"%m",&tm_ptr);
	month = atoi(month_str);
	strftime(day_str,sizeof(day_str),"%d",&tm_ptr);
	day = atoi(day_str);

	new_tm_ptr = tm_ptr;

	while(1){
		new_tm_ptr = getIncDay(new_tm_ptr,sign);
		strftime(temp_str,sizeof(temp_str),"%m",&new_tm_ptr);
		month_temp = atoi(temp_str);
		if (month != month_temp)
		{
			month_change_count++;
			month = month_temp;
			if (month_change_count == abs(addMonth))
			{
				break;
			}
		}
	}

	while(1){
		if (sign > 0)
		{
			strftime(temp_str,sizeof(temp_str),"%d",&new_tm_ptr);
			day_temp = atoi(temp_str);
			if (day == day_temp)
			{
				break;
			}
			strftime(temp_str,sizeof(month_temp),"%m",&new_tm_ptr);
			month_temp = atoi(temp_str);
			if (month != month_temp){
				new_tm_ptr = getIncDay(new_tm_ptr,-1);
				break;
			}
			new_tm_ptr = getIncDay(new_tm_ptr,sign);
		}
		else
		{
			strftime(temp_str,sizeof(temp_str),"%d",&new_tm_ptr);
			day_temp = atoi(temp_str);
			if (isFirst)
			{
				isFirst = 0;
				if (day >= day_temp)
				{
					break;
				}
			}
			if (day == day_temp)
			{
				break;
			}
			new_tm_ptr = getIncDay(new_tm_ptr,sign);
		}
	}
	return new_tm_ptr;
};

struct tm getConvStrToDateTime(char *str)
{
	struct tm tm_ptr;
	char buf[15];
	switch (strlen(str))
	{
		case 14 : 
			sprintf(buf,"%s",str);
			break;
		case 12 : 
			sprintf(buf,"%s00",str);
			break;
		case 10 : 
			sprintf(buf,"%s0000",str);
			break;
		case 8 : 
			sprintf(buf,"%s000000",str);
			break;
		case 6 : 
			sprintf(buf,"%s01000000",str);
			break;
		case 4 : 
			sprintf(buf,"%s0101000000",str);
			break;
		case 0 : 
			sprintf(buf,"%s20000101000000",str);
			break;
		default :
			sprintf(buf,"%s20000101000000",str);
			break;
	}

	strptime(buf,"%Y%m%d%H%M%S",&tm_ptr);

	return tm_ptr;
}
