#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "parameter.h"
#include "cgiutil.h"
#include "map_ini.h"
#include "zoom_setting.h"

PARAM_INFO zoom_setting(PARAM_INFO var, int stlen, int zi[100], char zips[50][20])
{
	int i, j;
	int  zarg[4];
	char zpiv[4][20];
    	
	if( stlen > 0 ) {

		for (i=0; i<stlen ; i++)
		{
//    	var.nXscalef =  (double)(var.nSizeX-1) /(double)(var.nDispX-1) ;
//    	var.nYscalef =  (double)(var.nSizeY-1) /(double)(var.nDispY-1) ;
		  var.nXscalef =  (double)(var.nSizeX) / (double)(var.nDispX) ;
		  var.nYscalef =  (double)(var.nSizeY) / (double)(var.nDispY) ;
  
			switch( zi[i] ){
			case 2:
				for (j=0; j<2; j++){
					getword(zpiv[j], zips[i], '-');
					zarg[j] = atoi(zpiv[j] ) ;
				}
				var = click_zoom(var, zarg[0], zarg[1]);
				var.nzoomdepth++;                                              //����
				break;
			case 3:
				for (j=0; j<4; j++){
					getword(zpiv[j], zips[i], '-');
					zarg[j] = atoi(zpiv[j] ) ;
				}
				var = drag_set_position(var, zarg[0], zarg[1],  zarg[2], zarg[3] );
				break;
			case 4:
				for (j=0; j<4; j++){
					getword(zpiv[j], zips[i], '-');
					zarg[j] = atoi(zpiv[j] ) ;
				}
				var = boxzoom_set_position(var, zarg[0], zarg[1],  zarg[2], zarg[3] );
				break;                                                      //
      case 5:                                                          
  				for (j=0; j<2; j++){                                           
  					getword(zpiv[j], zips[i], '-');                              
  					zarg[j] = atoi(zpiv[j] ) ;                                   
  				}                                                              
  				var = click_zoomout(var, zarg[0], zarg[1]  ); 
  				var.nzoomdepth--;                                                 //����
  				break;                                                         
      case 6:                                         
  				for (j=0; j<2; j++){                                          
  					getword(zpiv[j], zips[i], '-');                              
  					zarg[j] = atoi(zpiv[j] ) ;                                   
  				}                                                              
          var = drag_dup_position(var, zarg[0], zarg[1]);          
          break;  
          
			}
		}
	}
	
	//fprintf(stderr, "3.stlen : %d\n\n", var.nzoomdepth);
	
//    	var.nXscalef =  (double)(var.nSizeX-1) /(double)(var.nDispX-1) ;
//    	var.nYscalef =  (double)(var.nSizeY-1) /(double)(var.nDispY-1) ;
  var.nXscalef =  (double)(var.nSizeX) /(double)(var.nDispX) ;
  var.nYscalef =  (double)(var.nSizeY) /(double)(var.nDispY) ;
	
	return var;
}

PARAM_INFO click_zoom(PARAM_INFO var, int nx, int ny)
{	 
	int zorgX=0;
	int zorgY=0;

	if( var.nSizeX < 10 ) {
		return var;
	}
	zorgX = (int)( var.nOrgX + ( nx * var.nXscalef ) - var.nSizeX/4.f  + 0.5);
	zorgY = (int)( var.nOrgY + ( ny * var.nYscalef ) - var.nSizeY/4.f  + 0.5); 

	var.nSizeX /= 2;
	var.nSizeY /= 2;

//	if((zorgX + var.nSizeX) > 480-1 ){
	if((zorgX + var.nSizeX) > var.nDispX ){
//		zorgX = 480 - var.nSizeX - 1;
		zorgX = var.nDispX - var.nSizeX;
	}
	
	if(zorgX < 0 ){     
	  zorgX = 0;  
	}

//	if((zorgY + var.nSizeY) > 600-1 ){
	if((zorgY + var.nSizeY) > var.nDispY ){
//		zorgY = 600 - var.nSizeY - 1;
		zorgY = var.nDispY - var.nSizeY;
	}
	
	if(zorgY < 0){
	  zorgY = 0;
	}
	
	var.nOrgX = zorgX;
	var.nOrgY = zorgY;
		
	return var;
}

PARAM_INFO click_zoomout(PARAM_INFO var, int nx, int ny)
{
  
  //var.nzoomdepth --;
  
	int zorgX=0;
	int zorgY=0;

	zorgX = (int)( var.nOrgX + ( nx * var.nXscalef ) - var.nSizeX  + 0.5);
	zorgY = (int)( var.nOrgY + ( ny * var.nYscalef ) - var.nSizeY  + 0.5); 

	var.nSizeX *= 2;
	var.nSizeY *= 2;

//	if( ( zorgX + var.nSizeX ) > 480-1 ){
//		zorgX = 480 - var.nSizeX - 1;
	if( ( zorgX + var.nSizeX ) > var.nDispX ){
		zorgX = var.nDispX - var.nSizeX;
	}
	if(   zorgX   < 0 ){
		zorgX = 0;
	}

//	if( (zorgY + var.nSizeY   ) > 600-1 ){
//		zorgY = 600 - var.nSizeY - 1;
	if( (zorgY + var.nSizeY   ) > var.nDispY ){
		zorgY = var.nDispY - var.nSizeY;
	}
	if(  zorgY  < 0 ){
		zorgY = 0 ;
	}

	var.nOrgX = zorgX;
	var.nOrgY = zorgY;


	return var;
}

PARAM_INFO drag_set_position(PARAM_INFO var, int d_stX,int d_stY, int d_edX, int d_edY)
{

	var.nOrgX  =   (int)( var.nOrgX - ( (d_edX - d_stX ) * var.nXscalef )  + 0.5);  
	var.nOrgY  =   (int)( var.nOrgY - ( (d_edY - d_stY ) * var.nYscalef )  + 0.5); 

	if( ( var.nOrgX ) < 0 ){
		var.nOrgX = 0;
	}
	if( (var.nOrgY  ) < 0 ){
		var.nOrgY = 0 ;
	}

//	if( ( var.nOrgX + var.nSizeX ) > 480-1 ){
//		var.nOrgX = 480 - var.nSizeX - 1;
	if( ( var.nOrgX + var.nSizeX ) > var.nDispX ){
		var.nOrgX = var.nDispX - var.nSizeX;
	}
//	if( (var.nOrgY + var.nSizeY  ) > 600-1 ){
//		var.nOrgY = 600 - var.nSizeY - 1;
	if( (var.nOrgY + var.nSizeY  ) > var.nDispY ){
		var.nOrgY = var.nDispY - var.nSizeY;
	}
	
  	return var;
	
}

PARAM_INFO drag_dup_position(PARAM_INFO var, int deltaX, int deltaY )
{

		var.nOrgX  =   (int)( var.nOrgX - ( ( deltaX - 10000 ) * var.nXscalef )  + 0.5);  
		var.nOrgY  =   (int)( var.nOrgY - ( ( deltaY - 10000 ) * var.nYscalef )  + 0.5); 
		
		if( ( var.nOrgX  ) < 0 ){
			var.nOrgX = 0;
		}
		if( (var.nOrgY  ) < 0 ){
			var.nOrgY = 0 ;
		}
		
//		if( ( var.nOrgX + var.nSizeX ) > 480-1 ){
//			var.nOrgX = 480 - var.nSizeX - 1;
		if( ( var.nOrgX + var.nSizeX ) > var.nDispX ){
			var.nOrgX = var.nDispX - var.nSizeX;
		}
//		if( (var.nOrgY + var.nSizeY  ) > 600-1 ){
//			var.nOrgY = 600 - var.nSizeY - 1;
		if( (var.nOrgY + var.nSizeY  ) > var.nDispY ){
			var.nOrgY = var.nDispY - var.nSizeY;
		}
	
  	return var;
	
}

PARAM_INFO  boxzoom_set_position(PARAM_INFO var, int d_stX, int d_stY, int d_edX, int d_edY)
{
	int imsi;
	if( d_stX > d_edX ){
		imsi = d_edX;
		d_edX = d_stX;
		d_stX = imsi;

	}
	if( d_stY > d_edY ){
		imsi = d_edY;
		d_edY = d_stY;
		d_stY = imsi;
	}

	var.nOrgX  = (int)( var.nOrgX + ( d_stX * var.nXscalef)  + 0.5);
	var.nOrgY  = (int)( var.nOrgY + ( d_stY * var.nYscalef)  + 0.5);

	var.nSizeX = (int)( (var.nOrgX + ( d_edX * var.nXscalef )) - (var.nOrgX + ( d_stX * var.nXscalef ))  + 0.5);
	var.nSizeY = (int)( (var.nOrgY + ( d_edY * var.nYscalef )) - (var.nOrgY + ( d_stY * var.nYscalef ))  + 0.5);

	return var;
}
