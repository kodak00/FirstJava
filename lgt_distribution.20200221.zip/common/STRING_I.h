/* 
 * File:   STRING_I.h
 * Author: lucid32
 *
 * Created on 2014년 8월 12일 (화), 오후 8:46
 */

#ifndef STRING_I_H
#define	STRING_I_H

#ifdef	__cplusplus
extern "C"
{
#endif

#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "common/macro.h"
    
typedef struct _STRING_I STRING_I;

extern STRING_I* STRING;

struct _STRING_I
{
    int (*LTRIM)(char* str);
    int (*RTRIM)(char* str);
    int (*TRIM)(char* str);

    int (*REPLACE_CHAR)(char* str, const char oldChar, const char newChar);

};

#ifdef	__cplusplus
}
#endif

#endif	/* STRING_I_H */

