
#ifndef CAPPI_H_
#define CAPPI_H_

#define FILE_SIZE 128

#define X_DIM		1241
#define Y_DIM		1761

#define COMP_DEL_LEFT	60
#define COMP_DEL_RIGHT	221
#define COMP_DEL_UPPER	425
#define COMP_DEL_BOTTOM	136

#define RAR_DEL_LEFT   95
#define RAR_DEL_RIGHT	 245
#define RAR_DEL_UPPER	 555
#define RAR_DEL_BOTTOM 155

#define RAR_X_DIM	(X_DIM-RAR_DEL_LEFT-RAR_DEL_RIGHT)
#define RAR_Y_DIM (Y_DIM-RAR_DEL_UPPER-RAR_DEL_BOTTOM)

PARAM_INFO comp_file_name(PARAM_INFO var, char *COMP_FILE);
int comp_read(PARAM_INFO var, short **DATA);
int comp_read_rar(PARAM_INFO var, short **DATA);

#endif /* CAPPI_H_ */
