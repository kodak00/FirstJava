#ifndef PARAMETER_H_
#define PARAMETER_H_ 1

//typedef struct tm;

typedef struct {

	char  zoom[16];             // 확대지역

	int   size;                 // 이미지 크기

	int   seq;                  // 시간 SEQ(분)
	int   YY;                   // 년
	int   MM;                   // 월
	int   DD;                   // 일
	int   HH;                   // 시
	int   min;                  // 분
	int   move;                 // 이동시간(분)
	int   fmove;                // 파일 지연시각(분)
	int   winnum;               // WINDOW num        
	int   rand;                 // 난수
	 
	char  fname[120];           //해당되는 파일이름
	int   seq_file;             //해당 파일의 생성시각(분)
	int   seq_img;              //이미지파일  생성시각(분)
	int   NI;                   //이미지 자료영역 가로 Pixel
	int   NJ;                   //이미지 자료영역 세로 Pixel
	int   GI;                   //이미지 가로 Pixel
	int   GJ;                   //이미지 세로 Pixel
	float rate;                 //이미지 비율
	char  coordinate[7][10];
	
	//영상 사이즈(확대영역) 조절	
	char  size_flg;  			//일반 페이지와 popup페이지 구분

	int	zoomType[10];
	int nOrgX;
	int nOrgY;
	int nSizeX;
	int nSizeY;
	int nDispX;
	int nDispY;
	int nzoomdepth;
	double nXscalef;
	double nYscalef; 

	int title_width;
  
	char  comp_flg;  			//자료형태
	char  site_data[1024];  //사이트명
 
	char   datetime[13];		// 년월일시분
	char   int_datetime[13][7];	// 시간 간격 (시계열의 경우 중간 시간 처리를 위해)
	
	int   num_total;            // 일기도: 전체 일기도 수 
	int   num_cur;              // 일기도: 해당 일기도 번호
							  
	int   uf_volume[32];        // 레이더: 파일에 포함된 변수의 종류 
	float uf_sweep[64];         // 레이더: 파일에 포함된 고도의 종류
	float elev;                 // 레이더: 빔의 고도각(deg) 
	int   nbins;                // 레이더: 빔 Pixel 수      
	int   gate_size;            // 레이더: 빔 Pixel 폭(m)   
	int   range;                // 레이더: 자료 최대반경(m) 
  	
	int	num_sns;		        // 낙뢰 센서수
	char  mode;                 // 표출양식

	int   intv;					// 시간 간격
	char  fmode[4];				// 낙뢰자료 (기상청, 항공우주연구소, 전력연구원)
	char  tmode;				// 검색모드 (실시간, 일별, 월별, 연별)
	int	  data_stlen;			// DATA_zoom
	int   data_zi[20];			// DATA_zoom
	char  data_zips[50][20];		// DATA_zoom
	
	//struct tm run_datetime;		// 실행 시간
	//struct tm tmp_datetime;		// 임시 시간

	float altitude;
	char wind_flg;	
	char  unit_flg;  			//단위 (mm/hr, dBZ)

   int cloudLegend[16];

  char isRDR;
  char isSAT;

} PARAM_INFO;

PARAM_INFO param_setting();

#endif /* PARAMETER_H_ */
