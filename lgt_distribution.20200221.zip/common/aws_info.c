/*
 * aws_info.c
 *
 *  Created on: 2011. 10. 1.
 *      Author: radar
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "parameter.h"
#include "seq_time.h"

#include "aws_info.h"

char *strptime(const char *s, const char *format, struct tm *tm);

AWS_INFO readAWS(char *AWS_FILE)
{
	AWS_INFO aws; 
	FILE *fp;
	int i, cnt;
  
	int awsid, x, y;
	float lat, lon;
	char awsname[30];	
  
	//�ʱ�ȭ
	memset(&aws, 0, sizeof(aws));
 	aws.cnt = 0; 		 	
 	
 	//File Read
	if(AWS_FILE!=NULL && (fp=fopen(AWS_FILE, "r")) != NULL)
	{  	
		//fprintf(stderr,"path-------------> %s\n",  path);    
	   
		fscanf(fp, "%d", &cnt);
		aws.cnt = cnt;		
		aws.data = (AWS_DATA *)malloc(cnt*sizeof(AWS_DATA));
	  	    
		for (i=0; i<cnt; i++)
		{		  
			fscanf(fp, "%d %f %f %d %d %s", &awsid, &lat, &lon, &x, &y, awsname);			
			  
			aws.data[i].awsid = awsid;				
			aws.data[i].lat = lat;
			aws.data[i].lon = lon;
			aws.data[i].x = x;
			aws.data[i].y = y;
			strcpy(aws.data[i].awsname, awsname);
	  
		}		
		fclose(fp);
	}
  return aws;
}



AWS_RAR_INFO **initAWS_RAR()
{
	AWS_RAR_INFO** AWSDATA = NULL;
	int j;
  
	//�ʱ�ȭ
	AWSDATA = malloc(8 * sizeof(AWS_RAR_INFO *));
	for (j = 0; j < 8; j++) {
		AWSDATA[j] = malloc(643 * sizeof(AWS_RAR_INFO));
	}	
	
	return AWSDATA;
}

int compReadAWS(PARAM_INFO var, AWS_RAR_INFO** AWSDATA, char *AWS_FILE)
{
  
  //AWS_RAR_INFO** AWSDATA = NULL;
  
	FILE *fp;
	int z, p, j;
  
	struct tm tmtime;		
	struct tm newtime;
	
	char datetime[13];		// ����Ͻú�
	char fileName[FILE_SIZE];
	
	int aws_count = 642;
	char 	*token;
	
  
	//����ð�~6�ð� ����  
	for (z=0; z < 7; z++){
		
		sprintf(datetime, "%04d%02d%02d%02d%02d", var.YY, var.MM, var.DD, var.HH, var.min);
		tmtime = getConvStrToDateTime(datetime);
		
		newtime = getIncHour(tmtime, z);
		sprintf(datetime, "%04d%02d%02d%02d%02d", newtime.tm_year+1900, newtime.tm_mon+1, newtime.tm_mday, newtime.tm_hour, newtime.tm_min);
		strptime(datetime, "%Y%m%d%H%M", &tmtime); 
		
		strftime(fileName, FILE_SIZE, AWS_FILE, &tmtime);	
		
		//fprintf(stderr,"%d.var.fname-->%s\n",z, fileName);	  
		
		if(fileName!=NULL && (fp=fopen(fileName, "r")) != NULL)
		{  	    	  
		  for (p=0; p<aws_count; p++)
				{
					//����ID#������# ��������#15�� �̵� ���� ������#60�� �̵� ���� ������#Radar data
					fscanf(fp, "%s",fileName);
					token = strtok(fileName, "#");
					for(j=0; token!=NULL ; j++) {		
						switch(j){
							case 0:
								AWSDATA[z][p].awsid = atoi(token);
								break;
							case 1:
								strcpy(AWSDATA[z][p].awsname, token);
								break;
							case 2:	
								AWSDATA[z][p].awsSense = atof(token);
								break;				
							case 3:
								AWSDATA[z][p].rain15 = atof(token);
								break;
							case 4:
								AWSDATA[z][p].rain60 = atof(token);
								break;
							case 5:			
								AWSDATA[z][p].rain = atof(token);
								break;	
						}
						token = strtok(NULL, "#"); //token �ʱ�ȭ(�缳��)				
					}
						
					//if(AWSDATA[z][p].awsid == 112) printf("%d -- %d -- %0.3f \n", z, AWSDATA[z][p].awsid, AWSDATA[z][p].rain);
				}
			  fclose(fp);
		}
	}
   
  //return AWSDATA;	
  return 1;	
}

//AWS ID �˻��ϱ�
int findAwsInfo(AWS_INFO info, int search)
{
	int i, cnt;
	
	cnt = info.cnt;	
	for (i=0; i<cnt; i++) {
		if (info.data[i].awsid == search)
		 return i;
	}

	return -1;
}

int findAwsRarInfo(AWS_RAR_INFO* info, int cnt, int search)
{
	int i;

	for (i=0; i<cnt; i++) {
		if ( info[i].awsid == search)
		 return i;
	}

	return -1;
}

//����
void freeAWS(AWS_RAR_INFO** data, int cnt)
{
	int y;
	if(data != NULL) {		  		  
		for (y = 0 ; y < (cnt+1) ; y++ ) {
    		free(data[y]);
    	}
		free(data);
	}
}
