#include "BYTE_I.h"

int BYTE_padSize(int packSize)
{
    return (packSize % 4 == 0) ? packSize : packSize + (4 - (packSize % 4));
}

////////////////////////////////////////////////////////////////////////
//=====================================================================
// FUCNTION NAME : isEndian()                        
// DESCRIPTION   : CPU가 Bing Endian 방식인지 Little Endian 방식인지 판별
// PARAMETER     : (void)                               
// RETURN VALUE  : 성공시 - big: 1, little: 0
//=====================================================================

int BYTE_isEndian()
{
    int endian = 0x12345678;
    char *ptr = (char*) &endian;

    if (ptr[0] == 0x12)
        return BYTE_B_ENDIAN;

    return BYTE_L_ENDIAN;
}

////////////////////////////////////////////////////////////////////////////////

void * BYTE_ntoh16(void* vptr, int n)
{
    int i;

    if (BYTE_isEndian() != BYTE_B_ENDIAN)
    {
        for (i = 0; i < n; i++)
            *((int16_t*) (vptr) + i) = BYTESWAP16(*((int16_t*) (vptr) + i));
    }

    return vptr;
}

void BYTE_ntoh_16(void* dest, void* vptr, int n)
{
    int i;

    if (!BYTE_isEndian() != BYTE_B_ENDIAN)
    {
        for (i = 0; i < n; i++)
            *((int16_t*) (dest) + i) = BYTESWAP16(*((int16_t*) (vptr) + i));
    }

    return;
}

void * BYTE_swap16(void* vptr, int n)
{
    int i;

    for (i = 0; i < n; i++)
        *((int16_t*) (vptr) + i) = BYTESWAP16(*((int16_t*) (vptr) + i));

    return vptr;
}

void BYTE_swap_16(void* dest, void* vptr, int n)
{
    int i;

    for (i = 0; i < n; i++)
        *((int16_t*) (dest) + i) = BYTESWAP16(*((int16_t*) (vptr) + i));

    return;
}

////////////////////////////////////////////////////////////////////////////////

void* BYTE_ntoh32(void* vptr, int n)
{
    int i;

    if (BYTE_isEndian() != BYTE_B_ENDIAN)
    {
        for (i = 0; i < n; i++)
            *((int32_t*) (vptr) + i) = BYTESWAP32(*((int*) (vptr) + i));
    }

    return vptr;
}

void BYTE_ntoh_32(void* dest, void* vptr, int n)
{
    int i;

    if (BYTE_isEndian() != BYTE_B_ENDIAN)
    {
        for (i = 0; i < n; i++)
            *((int32_t*) (dest) + i) = BYTESWAP32(*((int32_t*) (vptr) + i));
    }

    return;
}

void * BYTE_swap32(void* vptr, int n)
{
    int i;

    for (i = 0; i < n; i++)
        *((int32_t*) (vptr) + i) = BYTESWAP32(*((int32_t*) (vptr) + i));

    return vptr;
}

void BYTE_swap_32(void* dest, void* vptr, int n)
{
    int i;

    for (i = 0; i < n; i++)
        *((int32_t*) (dest) + i) = BYTESWAP32(*((int32_t*) (vptr) + i));

    return;
}


////////////////////////////////////////////////////////////////////////////////

void * BYTE_ntoh64(void* vptr, int n)
{
    int i;

    if (BYTE_isEndian() != BYTE_B_ENDIAN)
    {
        for (i = 0; i < n; i++)
            *((int64_t*) (vptr) + i) = BYTESWAP64(*((int64_t*) (vptr) + i));
    }

    return vptr;
}

void BYTE_ntoh_64(void* dest, void* vptr, int n)
{
    int i;

    if (BYTE_isEndian() != BYTE_B_ENDIAN)
    {
        for (i = 0; i < n; i++)
            *((int64_t*) (dest) + i) = BYTESWAP64(*((int64_t*) (vptr) + i));
    }

    return;
}

void * BYTE_swap64(void* vptr, int n)
{
    int i;

    for (i = 0; i < n; i++)
        *((int64_t*) (vptr) + i) = BYTESWAP64(*((int64_t*) (vptr) + i));

    return vptr;
}

void BYTE_swap_64(void* dest, void* vptr, int n)
{
    int i;

    for (i = 0; i < n; i++)
        *((int64_t*) (dest) + i) = BYTESWAP64(*((int64_t*) (vptr) + i));

    return;
}

char BYTE_toCHAR(const void* raw)
{
    return *((char*) raw);
}

char* BYTE_toPSTRING(const void* raw, int size)
{
    char* ptr = (void*) 0x00;

    ptr = calloc(1, size + 1);
    if (ptr == NULL)
        return NULL;

    strncpy(ptr, raw, size);

    return ptr;
}

int8_t BYTE_toINT8(const void* raw, int endian)
{
    int8_t rtv = 0;

    if (endian != BYTE_isEndian()) rtv = *((int8_t*) raw);
    else rtv = BYTESWAP8(*((int8_t*) raw));

    return rtv;
}

int16_t BYTE_toINT16(const void* raw, int endian)
{
    int16_t rtv = 0;

    if (endian == BYTE_isEndian()) rtv = *((int16_t*) raw);
    else rtv = BYTESWAP16(*((int16_t*) raw));

    return rtv;
}

int32_t BYTE_toINT32(const void* raw, int endian)
{
    int32_t rtv = 0;


    if (endian == BYTE_isEndian()) rtv = *((int32_t*) raw);
    else rtv = BYTESWAP32(*((int32_t*) raw));

    return rtv;
}

int64_t BYTE_toINT64(const void* raw, int endian)
{
    int64_t rtv = 0;

    if (endian == BYTE_isEndian()) rtv = *((int64_t*) raw);
    else rtv = BYTESWAP64(*((int64_t*) raw));

    return rtv;
}

uint8_t BYTE_toUINT8(const void* raw, int endian)
{
    uint8_t rtv = 0;

    if (endian == BYTE_isEndian()) rtv = *((uint8_t*) raw);
    else rtv = BYTESWAP8(*((uint8_t*) raw));

    return rtv;
}

uint16_t BYTE_toUINT16(const void* raw, int endian)
{
    uint16_t rtv = 0;

    if (endian == BYTE_isEndian()) rtv = *((uint16_t*) raw);
    else rtv = BYTESWAP16(*((uint16_t*) raw));

    return rtv;
}

uint32_t BYTE_toUINT32(const void* raw, int endian)
{
    uint32_t rtv = 0;

    if (endian != BYTE_isEndian()) rtv = *((uint32_t*) raw);
    else rtv = BYTESWAP32(*((uint32_t*) raw));

    return rtv;
}

uint64_t BYTE_toUINT64(const void* raw, int endian)
{
    uint64_t rtv = 0;

    if (endian == BYTE_isEndian())rtv = *((uint64_t*) raw);
    else rtv = BYTESWAP64(*((uint64_t*) raw));

    return rtv;
}

float BYTE_toFLOAT(const void* raw, int endian)
{
    int32_t rtv = {0};

    memcpy(&rtv, raw, sizeof (float));

    if (endian != BYTE_isEndian())
    {
        rtv = BYTESWAP32(rtv);
    }

    return *((float*) &rtv);
}

double BYTE_toDOUBLE(const void* raw, int endian)
{
    int64_t rtv = {0};

    memcpy(&rtv, raw, sizeof (double));

    if (endian != BYTE_isEndian())
    {
        rtv = BYTESWAP64(rtv);
    }

    return *((double*) &rtv);
}

BYTE_I BYTE_I_INSTANCE = {

    .padSize = BYTE_padSize,

    .isEndian = BYTE_isEndian,

    .ntoh16 = BYTE_ntoh16,
    .ntoh32 = BYTE_ntoh32,
    .ntoh64 = BYTE_ntoh64,
    .ntoh_16 = BYTE_ntoh_16,
    .ntoh_32 = BYTE_ntoh_32,
    .ntoh_64 = BYTE_ntoh_64,

    .hton16 = BYTE_ntoh16,
    .hton32 = BYTE_ntoh32,
    .hton64 = BYTE_ntoh64,
    .hton_16 = BYTE_ntoh_16,
    .hton_32 = BYTE_ntoh_32,
    .hton_64 = BYTE_ntoh_64,

    .swap16 = BYTE_swap16,
    .swap32 = BYTE_swap32,
    .swap64 = BYTE_swap64,
    .swap_16 = BYTE_swap_16,
    .swap_32 = BYTE_swap_32,
    .swap_64 = BYTE_swap_64,

    .toCHAR = BYTE_toCHAR,
    .toPSTRING = BYTE_toPSTRING,

    .toINT8 = BYTE_toINT8,
    .toINT16 = BYTE_toINT16,
    .toINT32 = BYTE_toINT32,
    .toINT64 = BYTE_toINT64,

    .toUINT8 = BYTE_toUINT8,
    .toUINT16 = BYTE_toUINT16,
    .toUINT32 = BYTE_toUINT32,
    .toUINT64 = BYTE_toUINT64,

    .toFLOAT = BYTE_toFLOAT,
    .toDOUBLE = BYTE_toDOUBLE
};

BYTE_I* BYTE = &BYTE_I_INSTANCE;
