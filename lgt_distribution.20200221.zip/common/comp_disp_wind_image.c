#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "gd.h"

#include "parameter.h"
#include "map_ini.h"
#include "seq_time.h"        
#include "color.h"  
#include "dualwind.h" 
#include "site_info.h"

#include "comp_disp_wind_image.h"

char *strptime(const char *s, const char *format, struct tm *tm);

/*============================================================================*
 * Dualwind ������ �׸��� ���� ���
 *============================================================================*/
int data_disp_comp_dualwind(PARAM_INFO var, DUALWIND **wind, gdImagePtr im, int color[], COLOR_INFO color_info)
{
  int x, y;
	int y5,x5,x2,y2,y2_img,x2_img;
	float ws=0.0f, wd=0.0f;

	int p_size = 10;
	int wing_size = 5;

	int kkk = 4;
	
	//int map_xdim = 520;
	//int map_ydim = 632;
	int map_xdim = 480;
	int map_ydim = 600;
	int COMP_X_DIM = 960;
	int COMP_Y_DIM = 1200;
	
	int nix1, niy1;
		
	if(var.nDispX <= 300){
	    p_size = 5;
	    wing_size = 3;	    
	}else if(var.nDispX > 300 && var.nDispX < 400){
	   p_size = 7;
	   wing_size = 4;
	}else{
     p_size = 10;
     wing_size = 5;	
  }

	if(var.nzoomdepth>0) {
		p_size *= (var.nzoomdepth*1.5);
		wing_size *= (var.nzoomdepth*1.5);
	}
	 
  for (y5 = (int)change_2km_to_5km_pixel(DEL_BOTTOM_PIXEL_2) ; y5 < (int)change_2km_to_5km_pixel(YDIM_2-DEL_UPPER_PIXEL_2) ; y5 += kkk )
	{
		y2 = (int)change_5km_to_2km_pixel(y5);
		y2_img = YDIM_2 - y2 - DEL_UPPER_PIXEL_2 + 20;
		
		for (x5 = (int)change_2km_to_5km_pixel(DEL_LEFT_PIXEL_2) ; x5 < (int)change_2km_to_5km_pixel(XDIM_2 - DEL_RIGHT_PIXEL_2) ; x5 += kkk )
		{
			x2 = (int)change_5km_to_2km_pixel(x5);
			x2_img = x2 - DEL_LEFT_PIXEL_2 - 15;

			if (wind[y5][x5].u > BAD_VALUE_F && wind[y5][x5].v > BAD_VALUE_F)
			{
        ws = uvtos(wind[y5][x5].u,wind[y5][x5].v);
        wd = uvtod(wind[y5][x5].u,wind[y5][x5].v);
        
        x = x2_img*(map_xdim / (float)COMP_X_DIM * 2.);
        y = y2_img*(map_ydim / (float)COMP_Y_DIM * 2.);

        nix1 =(int) ((x - var.nOrgX ) / var.nXscalef +0.5 );
        //niy1 =(int) (((600.0 -  y) - var.nOrgY ) / var.nYscalef +0.5);			
        niy1 =(int) ((y - var.nOrgY ) / var.nYscalef +0.5);			
        
        //dualwind_draw(im, x, y, ws, wd, color[37], p_size, wing_size);
        dualwind_draw(im, nix1, niy1, ws, wd, color[37], p_size, wing_size);
     
			}
		}
	}

  return 0;
}

/*============================================================================*
 *  dualwind draw
 *============================================================================*/
int dualwind_draw(gdImagePtr im, int x, int y, float ws, float wd, int line_color, int size, int wing)
{
	int i = 0;
	float r;
	float x1, y1;
	float x2, y2;
	gdPoint w_2[5][2];
	gdPoint w_5[5][2];
	gdPoint w_25[5][3];
	int cnt_25 = 0, cnt_5 = 0, flg_2 = 0;
	float u_x, u_y, w_r;

	if (ws > 0)
	{
			//continue;
			//return 1;

		x1 = x;
		y1 = y;
		r = dtor(wd - 90);

		x2 = x1 + (cos(r) * size);
		y2 = y1 + (sin(r) * size);

		gdImageLine(im, x1, y1, x2, y2, line_color);

		u_x = (x2 - x1) / 5.;
		u_y = (y2 - y1) / 5.;
		w_r = dtor(wd - 30);

		for(i = 0; i < 5; i++)
		{
			w_5[i][0].x = x2 - u_x * i;
			w_5[i][0].y = y2 - u_y * i;
			w_5[i][1].x = w_5[i][0].x + (cos(w_r) * wing);
			w_5[i][1].y = w_5[i][0].y + (sin(w_r) * wing);

			w_2[i][0].x = x2 - u_x * i;
			w_2[i][0].y = y2 - u_y * i;
			w_2[i][1].x = w_2[i][0].x + (cos(w_r) * (wing / 2.));
			w_2[i][1].y = w_2[i][0].y + (sin(w_r) * (wing / 2.));

			w_25[i][0].x = x2 - u_x * (i - 1);
			w_25[i][0].y = y2 - u_y * (i - 1);
			w_25[i][1].x = x2 - u_x * i;
			w_25[i][1].y = y2 - u_y * i;
			w_25[i][2].x = w_25[i][1].x + (cos(w_r) * wing);
			w_25[i][2].y = w_25[i][1].y + (sin(w_r) * wing);
		}

		cnt_25 = floor(ws / 25.);
		cnt_25 += (ws - (cnt_25 * 25) >= 24) ? 1 : 0;
		r = ws - (cnt_25 * 25);

		if(r > 0)
		{
			cnt_5 = floor(r / 5.);
			cnt_5 += r - (cnt_5 * 5) >= 4 ? 1 : 0;
			r = r - ((cnt_25 * 25) + (cnt_5 * 5));
		}

		if(r >= 1.5)
		{
			flg_2 = 1;
		}

		// 25 m/s
		for(i = 0; i < cnt_25; i++)
		{
			gdImageFilledPolygon(im, w_25[i], 3, line_color);
		}

		// 5 m/s
		for(i = cnt_25; i < cnt_5 + cnt_25; i++)
		{
			gdImageLine(im, w_5[i][0].x, w_5[i][0].y, w_5[i][1].x, w_5[i][1].y, line_color);
		}

		// 2 m/s
		if(flg_2 == 1)
		{
			if(i == 0) i = 1;
			gdImageLine(im, w_2[i][0].x, w_2[i][0].y, w_2[i][1].x, w_2[i][1].y, line_color);
		}

	}
	return 0;

}


/*============================================================================*
 *  wind vvp display
 *============================================================================*/
int data_disp_comp_wind_vad(char* PATH, char* HEAD, char* TAIL, PARAM_INFO var, SITE_INFO site_info, gdImagePtr im, int color[], COLOR_INFO color_info)
{
  struct tm tmtime;		
	
	int i, sitecnt=0;
	char fName[FILE_SIZE], fileName[FILE_SIZE];
	
	char datetime[13];		// ����Ͻú�
	FILE *vadSitefile;
  FILE* fp=NULL;
  char min1[3], times[3], f[FILE_SIZE];
  char str[FILE_SIZE];
  int imin=0, slen=0;
  
  int vCnt=0, k=0;
	float site_altitude, wind_speed,  wind_direction, wind_u, wind_v, wind_rms, wind_w, wind_wrms;
	int pageCnt;
	int imgZoom = 1;
	int zm_cnt=0, zoom_level=0;
	int wind_size = 40;
	int wSize = 30;
	
	if(var.nDispX <= 300){
	    wind_size = 20;  
	    wSize = 10;  
	}else if(var.nDispX > 300 && var.nDispX < 400){
	    wind_size = 30;  
	    wSize = 15;  
	}else{
	    wind_size = 40;   
	    wSize = 30; 
  }
	
	
  //zooming rate
  zoom_level  = var.nzoomdepth;     
  zm_cnt = zoom_level;  
  if( zoom_level > 0 ) {
   for (i=0; i < zoom_level ; i++)
   {
    if(var.zoomType[i] == 3) zm_cnt -= 1;
   }
  }  
  zoom_level = zm_cnt;
  if(zoom_level > 0 ) imgZoom = zoom_level * 2;
	
	  
  sprintf(datetime, "%04d%02d%02d%02d%02d", var.YY, var.MM, var.DD, var.HH, var.min);	
  strptime(datetime, "%Y%m%d%H%M", &tmtime);
  			
	sitecnt = site_info.cnt;
	
	WIND vad_windinfo[sitecnt];	  
	pageCnt = 100;	
	
  for (i=0; i<sitecnt; i++)
	{
    //File Name
    sprintf(times, "%02d",var.min);
    strncpy(min1, (char *)times, 1);
    min1[1] = '\0';
    imin = atoi(min1);
    
    //sprintf(fName, "%s%s%s%d?%s", PATH, cb_ToLower(site_info.data[i].sitename), HEAD, imin, TAIL);	
    sprintf(fName, "%s%s%s%d?%s", PATH, cb_ToUpper(site_info.data[i].sitename), HEAD, imin, TAIL);	
    strftime(fileName, FILE_SIZE, fName, &tmtime);    
    //fprintf(stderr,"VAD fileName-------------> %s $$\n",  fName);  
    
    sprintf(f, "ls -r %s | sort -r", fileName);       
    //fprintf(stderr,"f-------------> %s\n",  f);
    
    if((fp = popen(f, "r")) != NULL)
    {
        while(fgets(str, 1024, fp) != NULL) {
          
          slen = strlen(str)-1;
          str[slen] = '\0';            
          sprintf(fName, "%s", str);           
          //fprintf(stderr,"---------------->[%s]$$\n",strFile);
          break;
        }
        pclose(fp);
    }
    
    slen = strlen(fName);
    if(slen != 0) 
    {
      if(fName !=NULL && (vadSitefile=fopen(fName, "r")) != NULL) 
	    {
					vad_windinfo[vCnt].lat = site_info.data[i].lat;
					vad_windinfo[vCnt].lon = site_info.data[i].lon;
					vad_windinfo[vCnt].x = site_info.data[i].x;
					vad_windinfo[vCnt].y = site_info.data[i].y;
					
          for (k=0; k< pageCnt; k++)
          {
          	//���� ǳ�� ǳ�� U V rms W W_rms
          	fscanf(vadSitefile, "    %f    %f  %f   %f    %f    %f   %f    %f", &site_altitude, &wind_speed,  &wind_direction, &wind_u, &wind_v, &wind_rms, &wind_w, &wind_wrms);
          	  
          	//������ ���� ���� ����Ѵ�.
          	if(var.altitude == site_altitude){				     	
          		vad_windinfo[vCnt].ws = wind_speed;
          		vad_windinfo[vCnt].wd = wind_direction;
          		break;
          	}
          }
          fclose(vadSitefile);
          vCnt++;
	    }      
    }
//    gdImageFilledEllipse(im, site_info.data[i].x,site_info.data[i].y, 5, 5, color[34]);
	}
	
	if(vCnt > 0) wind_draw(var, im, vad_windinfo, color, wind_size*imgZoom, wSize*imgZoom, vCnt, 34);
	
  return 0;
}
/*============================================================================*
 *  wind vvp display
 *============================================================================*/
int data_disp_comp_wind_vvp(char* PATH, char* HEAD, char* TAIL, PARAM_INFO var, SITE_INFO site_info, gdImagePtr im, int color[], COLOR_INFO color_info)
{
  struct tm tmtime;
	char datetime[13];
	
  FILE* fp=NULL;
	char fName[FILE_SIZE], fileName[FILE_SIZE];
	
	int i;
	int sitecnt=0;
	int zm_cnt=0, zoom_level=0;
	int pageCnt = 6250;
	
	int vCnt=0, k=0;
	int imgZoom = 1;
	
	float wind_u, wind_v, wind_w;	
	int wind_x, wind_y, wind_z;
	int wing_size = 10;
	
	if(var.nDispX <= 300){
	   wing_size = 4;	    
	}else if(var.nDispX > 300 && var.nDispX < 400){
	   wing_size = 6;
	}else{
     wing_size = 10;	
  }
	
  //zooming rate
  zoom_level  = var.nzoomdepth;     
  zm_cnt = zoom_level;  
  if( zoom_level > 0 ) {
   for (i=0; i < zoom_level ; i++)
   {
    if(var.zoomType[i] == 3) zm_cnt -= 1;
   }
  }  
  zoom_level = zm_cnt;
  if(zoom_level > 0 ) imgZoom = zoom_level * 2;
	
  
  int   xdots = 480 ;           //�ʱⰪ 
  float originXlength= 100.0f;// 480dot ��  400km ��� 
  float dotwidth  = originXlength/xdots;
  
  float deltaX=0;  //�߾������� ��dot ������ 
  float deltaY=0;
   
  float celltocell= 2.0f; // dot ���� 2.0
  int ix, iy;
  int nxx=0, nyy=0;
  
  sprintf(datetime, "%04d%02d%02d%02d%02d", var.YY, var.MM, var.DD, var.HH, var.min);	
  strptime(datetime, "%Y%m%d%H%M", &tmtime);
  
	WIND vvp_siteinfo[pageCnt];	
	
  //������ Site
  sitecnt = site_info.cnt;
  for (i=0; i<sitecnt; i++)
	{	 
	  ix = site_info.data[i].x;
	  iy = site_info.data[i].y;
	  
    //gdImageFilledEllipse(im, site_info.data[i].x, site_info.data[i].y,8,8,color[34]); 
    
  	sprintf(fName, "%s%s%s%s", PATH, cb_ToUpper(site_info.data[i].sitename), HEAD, TAIL);	
    strftime(fileName, FILE_SIZE, fName, &tmtime);   
       
    if(fileName !=NULL && (fp=fopen(fileName, "r")) != NULL) 
	  {
      vCnt = 0;
      for (k=0; k< pageCnt; k++)
      {
        //����Ʈ �� ���� : X Y Z U V W
      	fscanf(fp, "  %d    %d    %d      %f    %f    %f", &wind_x, &wind_y, &wind_z,&wind_u, &wind_v, &wind_w);
      	
        //���õ� ����Ʈ �� ��ϵ� ���� ���� DATA ó��.
      	if(var.altitude == wind_z){
      	        	  
			    deltaX =  ( 13 - wind_x ) * celltocell; 
			    deltaY =  ( -13 + wind_y ) * celltocell; 
		      nxx = ix - (int)( deltaX / ( dotwidth * var.nXscalef) );    
		      nyy = iy - (int)( deltaY / ( dotwidth * var.nYscalef) );   
		      
          vvp_siteinfo[vCnt].xx = wind_x;							
          vvp_siteinfo[vCnt].yy = wind_y;						
          
          vvp_siteinfo[vCnt].x = nxx;
          vvp_siteinfo[vCnt].y = nyy;
          
          vvp_siteinfo[vCnt].ws = uvtos(wind_u, wind_v);
          vvp_siteinfo[vCnt].wd = uvtod(wind_u, wind_v);				  
          
		      //gdImageFilledEllipse(im, nxx, nyy, 5, 5,color[33]);  		      
      	  vCnt++; 
      	}
      }
	    fclose(fp);       
	    
      //�ٶ��� �׸���
      if(vCnt > 0) wind_draw(var, im, vvp_siteinfo, color, wing_size*imgZoom, 5*imgZoom, vCnt, 37);        
	  }
    
	}
  	
  return 0;
}

/*============================================================================*
 *  wind draw
 *============================================================================*/
int wind_draw(PARAM_INFO var, gdImagePtr im, WIND info[], int color[], int size, int wing, int cnt, int color_num)
{
	int i = 0, j = 0;
	float r;
//	float x, y;
	float x1, y1;
	float x2, y2;
	gdPoint w_2[5][2];
	gdPoint w_5[5][2];
	gdPoint w_25[5][3];
	int cnt_25 = 0, cnt_5 = 0, flg_2 = 0;
	float u_x, u_y, w_r;
	
	
	int line_color;
	
	for (j=0; j<cnt; j++) {	
		
		//fprintf(stderr,"%d --->%f - %f - %f - %f - %f - %f<BR>\n",j ,  info[j].lat,  info[j].lon,  info[j].x,  info[j].y, info[j].ws, info[j].wd);  
		  
		if (info[j].ws > 0)
		{
				x1 = info[j].x;
				y1 = info[j].y;
				
				//fprintf(stderr,"%d --->%f - %f - %f - %f - %f - %f<BR>\n",j ,  info[j].lat,  info[j].lon,  info[j].x,  info[j].y, info[j].ws, info[j].wd);  
				line_color = color[color_num];
			
				r = dtor(info[j].wd - 90.0f);
				
				x2 = x1 + (cos(r) * size);
				y2 = y1 + (sin(r) * size);
				
				gdImageLine(im, x1,  y1, x2,  y2, line_color);
				
				u_x = (x2 - x1) / 5.0f;
				u_y = (y2 - y1) / 5.0f;
				w_r = dtor(info[j].wd - 30.0f);
			
				for(i = 0; i < 5; i++)
				{
					w_5[i][0].x = x2 - u_x * i;
					w_5[i][0].y = y2 - u_y * i;
					w_5[i][1].x = w_5[i][0].x + (cos(w_r) * wing);
					w_5[i][1].y = w_5[i][0].y + (sin(w_r) * wing);
			
					w_2[i][0].x = x2 - u_x * i;
					w_2[i][0].y = y2 - u_y * i;
					w_2[i][1].x = w_2[i][0].x + (cos(w_r) * (wing / 2.0f));
					w_2[i][1].y = w_2[i][0].y + (sin(w_r) * (wing / 2.0f));
					
					w_25[i][0].x = x2 - u_x * (i - 1);
					w_25[i][0].y = y2 - u_y * (i - 1);
					w_25[i][1].x = x2 - u_x * i;
					w_25[i][1].y = y2 - u_y * i;
					w_25[i][2].x = w_25[i][1].x + (cos(w_r) * wing);
					w_25[i][2].y = w_25[i][1].y + (sin(w_r) * wing);
				}
				
				cnt_25 = floor(info[j].ws / 25.0f);
				cnt_25 += (info[j].ws - (cnt_25 * 25) >= 24) ? 1 : 0;
				r = info[j].ws - (cnt_25 * 25);
			
				if(r > 0)
				{
					cnt_5 = floor(r / 5.0f);
					cnt_5 += r - (cnt_5 * 5) >= 4 ? 1 : 0;
					r = r - ((cnt_25 * 25.0f) + (cnt_5 * 5.0f));
				}
			
				if(r >= 1.5f)
				{
					flg_2 = 1;
				}
			
				// 25 m/s
				for(i = 0; i < cnt_25; i++)
				{
					gdImageFilledPolygon(im, w_25[i], 3, line_color);
				}
			
				// 5 m/s
				for(i = cnt_25; i < cnt_5 + cnt_25; i++)
				{
					//gdImageLine(im, w_5[i][0].x,  var.GJ-w_5[i][0].y, w_5[i][1].x,  var.GJ-w_5[i][1].y, line_color);
					gdImageLine(im, w_5[i][0].x,  w_5[i][0].y, w_5[i][1].x,  w_5[i][1].y, line_color);
				}
			
				// 2 m/s
				if(flg_2 == 1)
				{
					if(i == 0) i = 1;
					//gdImageLine(im, w_2[i][0].x, var.GJ-w_2[i][0].y, w_2[i][1].x, var.GJ-w_2[i][1].y, line_color);
					gdImageLine(im, w_2[i][0].x, w_2[i][0].y, w_2[i][1].x, w_2[i][1].y, line_color);
				}
			
		} //if end
	
	}
	
	return 0;
}

/*==========================================================*/
/* ����Ʈ�� ���ڹ��̿��� xy��ǥ���� �����´�.        */
/*==========================================================*/
int findXYInfo(WIND info[], int cnt, int xx, int yy)
{
	int i;
	for (i=0; i<cnt; i++) {
		if ( info[i].xx == xx && info[i].yy == yy){
		 return i;
		}
	}
	return -1;
}

