/*
 * dualwind.c
 *
 *  Created on: 2011. 8. 2.
 *      Author: radar
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <zlib.h>

#include "dualwind.h"

#define MAX_STRING_LENGTH 1024

DUALWIND** getDualWind(char* filename, int altitude) {
	FILE *fp;

	DUALWIND** wind = NULL;

	char buffer[MAX_STRING_LENGTH];
	float xdimf, ydimf, zdimf;
	float u, v, w;
	int x, y, z;
	int zdim;

	int skip_line;
	int zNo;

	if ((fp = gzopen(filename, "rt")) == NULL) {
		fprintf(stderr, "file openr error : %s\n", filename);
		return NULL;
	}

	//제목 읽기
	if (gzgets(fp, buffer, MAX_STRING_LENGTH) == Z_NULL) {
		fprintf(stderr, "read title error\n");
		return NULL;
	} else {
		sscanf(buffer, "%f %f %f", &xdimf, &ydimf, &zdimf);
		if ((int) xdimf != XDIM_5 || (int) ydimf != YDIM_5) {
			return NULL;
		}
		zdim = (int) zdimf;
	}

	wind = malloc(YDIM_5 * sizeof(DUALWIND *));
	for (y = 0; y < YDIM_5; y++) {
		wind[y] = malloc(XDIM_5 * sizeof(DUALWIND));
	}

	/* Data Read */
	x = 0;
	y = 0;
	z = 0;

	//고도 1km
	zNo = altitude - 1;
	skip_line = (XDIM_5 * 49) * YDIM_5 * zNo + 45;
	gzseek(fp, skip_line, SEEK_CUR);

	for (y = 0; y < YDIM_5; y++) {
		for (x = 0; x < XDIM_5; x++) {
			if (gzgets(fp, buffer, MAX_STRING_LENGTH) == Z_NULL) {
				fprintf(stderr, "read data error\n");
				gzclose(fp);
				return NULL;
			}

			sscanf(buffer, "%f %f %f", &u, &v, &w);

			if (u < -990 || v < -990) {
				wind[y][x].u = 0.0f;
				wind[y][x].v = 0.0f;
			} else {
				wind[y][x].u = u;
				//wind[y][x].u = utouc(u, altitude);
				wind[y][x].v = v;
				//wind_draw(im, x, var.NJ-y, wind[z][y][x].ws, wind[z][y][x].wd, color[247], 10, 5);
			}
		}
	}
	// ******************	 File Close
	gzclose(fp);

	return wind;

}

//u 를 재계산
float utouc(float u, int altitude) {
	float cf = 1.0; // 흐름왜곡고정계수 (1:흐름왜곡무시, 0:왜곡이심함)
	float ct = 1.0; // 지형교정계수 (지역 평균풍속 대 관측소 풍속 비율)
	float zo = 0.5; // 거칠기 길이(m)

	float a = 0.014; // 경험상수
	float g = 9.8; // 중력가속도(m/s)
	float zou = a * u * 2. / g;

	float z = altitude * 1000.0; // km -> m

	float uc;

	uc = u * cf * ct * ((logf(10. / zou) * logf(60. / zou) * logf(10. / zo))
			/ (logf(z / zou) * logf(10. / zou) * logf(60. / zo)));

	return uc;
}

/*============================================================================*
 * Wind Data 계산
 *============================================================================*/
//degree -> radian로 변환.
float dtor(float d) {
	return (d * PI_DFS) / 180.;
}
//radian -> degree로 변환.
float rtod(float r) {
	return (r * 180.) / PI_DFS;
}
//u,v vector -> wind speed로 변환.
float uvtos(float u, float v) {
	return pow(pow(u, 2) + pow(v, 2), 0.5);
}
// uu,v vector -> wind direction로 변환.
float uvtod(float u, float v) {
	if (u >= 0 && v >= 0) {
		return 270. - rtod(atan2(fabs(v), fabs(u)));
	} else if (u >= 0 && v < 0) {
		return 270. + rtod(atan2(fabs(v), fabs(u)));
	} else if (u < 0 && v >= 0) {
		return 180. - rtod(atan2(fabs(u), fabs(v)));
	} else if (u < 0 && v < 0) {
		return rtod(atan2(fabs(u), fabs(v)));
	} else {
		return 0.;
	}
}

/*============================================================================*
 * km Pixel 변환 공식
 *============================================================================*/
// 5km -> 2km 변환
float change_5km_to_2km_pixel(int x_or_y) {
	return ((x_or_y * 5) / 2.);
}

// 2km -> 5km 변환
float change_2km_to_5km_pixel(int x_or_y) {
	return ((x_or_y * 2) / 5.);
}


void freeDualwind(DUALWIND** wind, int cnt)
{
		int y;

		if(wind != NULL) {		  		  
    	for (y = 0 ; y < (cnt+1) ; y++ ) {
    		free(wind[y]);
    	}
      free(wind);
		}
}

