#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "gd.h"

#include "parameter.h"
#include "map_ini.h"
#include "seq_time.h"        
#include "color.h"  

#include "common_disp_image.h"

char *strptime(const char *s, const char *format, struct tm *tm);

/*============================================================================*
 *  Fiel Read 
 *============================================================================*/
PARAM_INFO getCompFileName(PARAM_INFO var, char *COMP_FILE, int min)
{
	struct tm tmtime;		
	char datetime[13], tmpTime[13];		// ?????Ͻú?
	char fileName[FILE_SIZE];
	
	sprintf(datetime, "%04d%02d%02d%02d%02d", var.YY, var.MM, var.DD, var.HH, var.min);
	
	if(min == 10){
		strncpy(tmpTime, datetime, 11);
		sprintf(datetime, "%s0", tmpTime);
	}
	strptime(datetime, "%Y%m%d%H%M", &tmtime);
	strftime(fileName, FILE_SIZE, COMP_FILE, &tmtime); 	
	
  //fprintf(stderr, "--->%04d%02d%02d%02d%02d\n", var.YY, var.MM, var.DD, var.HH, var.min);	
  
	strcpy(var.fname, fileName);  
  //fprintf(stderr,"0.var.fname-->%s\n",var.fname);
   
	return var;
}

int comp_rdr_read(PARAM_INFO var, short **DATA)
{
    FILE *fd;
    char buf[1440];
    int	i, j, n;
    int fchk=0;
        
    //?ʱ?ȭ
    for (j=0; j<1440; j++) 
    {
        for (i=0; i<1440; i++) 
        {
        	DATA[j][i] = -12800;
        }
    }
    
    //File Open 
    //fprintf(stderr,"var.fname-->%s\n",var.fname);    
    if(var.fname!=NULL && (fd=gzopen(var.fname, "rb")) != NULL) {
        
        //Data Read
        for (j=10; j<1440; j++)
        {
            n = gzread(fd, buf, 1440);
            
            for (i=0; i<1440; i++)
            {
            	DATA[j][i] = buf[i]*100;
            }
        }	    
        gzclose(fd);    
        fchk = 1;
    }

  return fchk;
	
}

/*============================================================================*
 *  GIS data display
 *============================================================================*/
int map_disp(PARAM_INFO var, char *MAP_LINE_FILE, gdImagePtr im,int color[])
{
	FILE   *fd;
	char   fname[120];
	float	num, code, ibuf[2];
	float  buf[2];
	int	map_color;
	int	ix1, iy1, ix2, iy2;
	float  zm = 1, xo = 0, yo = 0;
	int	i,zoom_level=0;
		
	int nix1=0;
	int nix2=0;
	int niy1=0;
	int niy2=0;

	int sizeX=150;
	int sizeY=80;

	if(var.comp_flg == 'O' || var.comp_flg == 'L' ||var.comp_flg == 'R' ||var.comp_flg == 'S' || var.comp_flg == 'M' || var.comp_flg == 'W') {
		sizeX = 0;
		sizeY = 0;
	}

	/* zooming rate */
	xo = 0;
	yo = 0;
	zm = 2;
	zoom_level  = var.nzoomdepth;
 
	/* Per Map data */
/*
	if(var.comp_flg == 'L') map_color = color[17];
	else if(var.comp_flg == 'R') map_color = color[17];
	else if(var.comp_flg == 'S') map_color = color[17];
	else map_color = color[36];
*/
	map_color = color[36];

	sprintf(fname, "%s", MAP_LINE_FILE);
	
	if ((fd = fopen(fname, "rb")) != NULL ){

		while (fread(ibuf, sizeof(float), 2, fd) > 0)
		{
			num  = ibuf[0];
			code = ibuf[1];
			fread(buf, sizeof(float), 2, fd);
			ix1 = (int)(zm * (buf[0] - xo) + 0.5);
			iy1 = var.nDispY - (int)(zm * (buf[1] - yo) + 0.5);

			nix1 =   (int) ( ( (zm * (buf[0] - xo)) - (var.nOrgX-sizeX) ) / var.nXscalef + 0.5);
			niy1 =   (int) ( ( ( (600.0+sizeY) - (zm * (buf[1] - yo) )) - var.nOrgY ) / var.nYscalef + 0.5);
  
			for (i=1; i<num; i++)
			{
				fread(buf, sizeof(float), 2, fd);

				ix2 = (int)(zm * (buf[0] - xo) + 0.5);
				iy2 = var.nDispY - (int)(zm * (buf[1] - yo) + 0.5);

				nix2 =   (int) ( ( (zm * (buf[0] - xo)) - (var.nOrgX-sizeX) ) / var.nXscalef  + 0.5  );
				niy2 =   (int) ( ( ((600.0+sizeY) - (zm * (buf[1] - yo) )) - var.nOrgY ) / var.nYscalef  + 0.5  );

        /*
					  0:?ѹݵ? ?ؾȼ?, ???漱, ��?ֵ?, ?︪??, ???? 
            1:?????? ?? 
            2:??????, ?????ð??? 
            3:??/?? ????, ?????? ?????? 
            5:?ѹݵ? ?̿? ?ڷ? - ????
            6:?ѹݵ? ?̿? ?ڷ? - ?߱?
            7:?ѹݵ? ?̿? ?ڷ? - ?Ϻ?
            8:?ؾȼ?
				*/
        if (zoom_level >= 0 && (code == 0 || code == 1 || code == 2 || code == 5 || code == 6 || code == 7 || code == 8 ))
				{
				  
				  gdImageLine(im, nix1, niy1, nix2, niy2, map_color);
					if (zoom_level > 1 && var.nDispX > 400)
						gdImageLine(im, nix1 + 1, niy1, nix2 + 1, niy2, map_color);
					if (zoom_level > 2 && var.nDispX > 400)
						gdImageLine(im, nix1, niy1 + 1, nix2, niy2 + 1, map_color);
				}
	
				if (zoom_level > 2 && code == 3 )
				{
					gdImageLine(im, nix1, niy1, nix2, niy2, map_color);
				}
				
				ix1 = ix2;
				iy1 = iy2;
				nix1 = nix2;
				niy1 = niy2;

			}
		}
		fclose(fd);
	}
	
	return 0;
}

/*============================================================================*
 *  GIS data display
 *============================================================================*/
int map_common_disp(PARAM_INFO var, char *MAP_LINE_FILE, gdImagePtr im,int color[])
{
	FILE   *fd;
	char   fname[120];
	float	num, code, ibuf[2];
	float  buf[2];
	int	map_color;
	int	ix1, iy1, ix2, iy2;
	float  zm = 1, xo = 0, yo = 0;
	int	i,zoom_level=0;
	//int zm_cnt=0;
		
  int nix1=0;
  int nix2=0;
  int niy1=0;
  int niy2=0;

	/* zooming rate */
	xo = 0;
	yo = 0;
	zm = 2;
  zoom_level = var.nzoomdepth;  
  //zoom_level = getZoomLevel(zm_cnt, var); 
  
	/* Per Map data */
	map_color = color[36];

	sprintf(fname, "%s", MAP_LINE_FILE);
	
	
  fprintf(stderr,"map_disp zoom_level-->%d\n",zoom_level);
  
	
	if ((fd = fopen(fname, "rb")) != NULL ){

		while (fread(ibuf, sizeof(float), 2, fd) > 0)
		{
			num  = ibuf[0];
			code = ibuf[1];
			fread(buf, sizeof(float), 2, fd);
			ix1 = (int)(zm * (buf[0] - xo) + 0.5);
			iy1 = var.nDispY - (int)(zm * (buf[1] - yo) + 0.5);

			nix1 =   (int) ( ( (zm * (buf[0] - xo)) - var.nOrgX ) / var.nXscalef + 0.5);
			niy1 =   (int) ( ( (600.0 - (zm * (buf[1] - yo) )) - var.nOrgY ) / var.nYscalef + 0.5);
  
			for (i=1; i<num; i++)
			{
				fread(buf, sizeof(float), 2, fd);

				ix2 = (int)(zm * (buf[0] - xo) + 0.5);
				iy2 = var.nDispY - (int)(zm * (buf[1] - yo) + 0.5);

				nix2 =   (int) ( ( (zm * (buf[0] - xo)) - var.nOrgX ) / var.nXscalef  + 0.5  );
				niy2 =   (int) ( ( (600.0 - (zm * (buf[1] - yo) )) - var.nOrgY ) / var.nYscalef  + 0.5  );

        /*
					  0:?ѹݵ? ?ؾȼ?, ???漱, ��?ֵ?, ?︪??, ???? 
            1:?????? ?? 
            2:??????, ?????ð??? 
            3:??/?? ????, ?????? ?????? 
            5:?ѹݵ? ?̿? ?ڷ? - ????
            6:?ѹݵ? ?̿? ?ڷ? - ?߱?
            7:?ѹݵ? ?̿? ?ڷ? - ?Ϻ?
            8:?ؾȼ?
				*/
        if (zoom_level >= 0 && (code == 0 || code == 1 || code == 2 || code == 5 || code == 6 || code == 7 || code == 8 ))
				{
				  
				  gdImageLine(im, nix1, niy1, nix2, niy2, map_color);
					if (zoom_level > 1 && var.nDispX > 400)
						gdImageLine(im, nix1 + 1, niy1, nix2 + 1, niy2, map_color);
					if (zoom_level > 2 && var.nDispX > 400)
						gdImageLine(im, nix1, niy1 + 1, nix2, niy2 + 1, map_color);
				}
	
				if (zoom_level > 2 && code == 3 )
				{
					gdImageLine(im, nix1, niy1, nix2, niy2, map_color);
				}
				
				ix1 = ix2;
				iy1 = iy2;
				nix1 = nix2;
				niy1 = niy2;

			}
		}
		fclose(fd);
	}
	
	return 0;
}

/*============================================================================*
 *  AWS data display
 *============================================================================*/
int aws_disp(PARAM_INFO var, char *AWS_NAME_FILE, gdImagePtr im,int color[])
{
  struct lamc_parameter  map;
 
	float x2, y2;
	float aws_lat,aws_lon;
	char  aws_file[120],aws_name[32],text[32];
	int	  i, zoom_level=0,aws_count;      
	int   nix1=0, niy1=0;	
	
	FILE *awsfile;
	int brect[8];
	char *err;
	double sz = 9.;	
	char f[37];	
	
	int sizeX=150;
	int sizeY=80;

	if(var.comp_flg == 'O' || var.comp_flg == 'D' || var.comp_flg == 'M' || var.comp_flg=='L' || var.comp_flg=='S') {
		sizeX = 0;
		sizeY = 0;
	}

	sprintf(f, "%s/gulim.ttc", FONT_PATH); // User supplied font
	
	//zooming rate
	zoom_level  = var.nzoomdepth;     
  
  
	MAP_INFO mapInfo = comp_map_info();
	map = mapInfo.map;
	 
	if (zoom_level > 0)
	{
		if (zoom_level > 5)	zoom_level = 5;
		
		sprintf(aws_file, "%s%d.txt", AWS_NAME_FILE, zoom_level);
		awsfile = fopen(aws_file, "r");

		if (awsfile != NULL)
		{
			fscanf(awsfile, "%d", &aws_count);
			sprintf(text, "%d", aws_count);
			err = gdImageStringFT(NULL, &brect[0], 0, f, sz, 0.0, 0, 0, aws_name);

			if (err)
				fprintf(stderr, err);

			for (i=0; i<aws_count; i++)
			{
				fscanf(awsfile, "%s%f%f", aws_name, &aws_lat, &aws_lon);
				lamcproj(&aws_lon, &aws_lat, &x2, &y2, 0, map);

				  nix1 =   (int) ( ( x2 - (var.nOrgX-sizeX) ) / var.nXscalef +0.5 );
					niy1 =   (int) ( ( ((600.0+sizeY) -  y2) - var.nOrgY ) / var.nYscalef +0.5);
					
			 		if ((nix1 >= 0 && nix1 <= var.nDispX) && (niy1 >= 0 && niy1 <= var.nDispY)) {	
				   	sprintf(text, "%s", aws_name);
					  err = gdImageStringFT(im, &brect[0], color[38], f, sz, 0.0, nix1, niy1, text);
					  gdImageFilledRectangle(im, nix1-1, niy1-1, nix1+1, niy1+1, color[37]);
         }
          
			}
			fclose(awsfile);
		}
		else
		{
			exit(0);
		}
	}

	return 0;
}

/*============================================================================*
 *  AWS data display
 *============================================================================*/
int aws_common_disp(PARAM_INFO var, char *AWS_NAME_FILE, gdImagePtr im,int color[])
{
    struct lamc_parameter  map;
 
	float x2, y2;
	float aws_lat,aws_lon;
    char  aws_file[120],aws_name[32],text[32];
    int	  i, zoom_level=0,aws_count;      
	int   nix1=0, niy1=0;	
	
	FILE *awsfile;
	int brect[8];
	char *err;
	double sz = 9.;	
	char f[37];	
	int zm_cnt=0;
	
	sprintf(f, "%s/gulim.ttc", FONT_PATH); // User supplied font
	
    //zooming rate
    zoom_level  = var.nzoomdepth;    
    //zoom_level = getZoomLevel(zm_cnt, var); 
    
    fprintf(stderr,"aws_disp zoom_level-->%d - %d\n",zoom_level, zm_cnt);
  
	MAP_INFO mapInfo = comp_map_info();
	map = mapInfo.map;
	 
	if (zoom_level > 0)
	{
		if (zoom_level > 5)	zoom_level = 5;
		
		sprintf(aws_file, "%s%d.txt", AWS_NAME_FILE, zoom_level);
		awsfile = fopen(aws_file, "r");

		if (awsfile != NULL)
		{
			fscanf(awsfile, "%d", &aws_count);
			sprintf(text, "%d", aws_count);
			err = gdImageStringFT(NULL, &brect[0], 0, f, sz, 0.0, 0, 0, aws_name);

			if (err)
				fprintf(stderr, err);

			for (i=0; i<aws_count; i++)
			{
				fscanf(awsfile, "%s%f%f", aws_name, &aws_lat, &aws_lon);
				lamcproj(&aws_lon, &aws_lat, &x2, &y2, 0, map);

				  nix1 =   (int) ( ( x2 - var.nOrgX ) / var.nXscalef +0.5 );
					niy1 =   (int) ( ( (600.0 -  y2) - var.nOrgY ) / var.nYscalef +0.5);
					
			 		if ((nix1 >= 0 && nix1 <= var.nDispX) && (niy1 >= 0 && niy1 <= var.nDispY)) {	
				   	sprintf(text, "%s", aws_name);
					  err = gdImageStringFT(im, &brect[0], color[38], f, sz, 0.0, nix1, niy1, text);
					  gdImageFilledRectangle(im, nix1-1, niy1-1, nix1+1, niy1+1, color[37]);
         }
          
			}
			fclose(awsfile);
		}
		else
		{
			exit(0);
		}
	}

	return 0;
}

int map_sea_disp(PARAM_INFO var, char *MAP_LINE_FILE, gdImagePtr im,int color[])
{
	FILE   *fd;
	char   fname[120];
	float	num, code, ibuf[2];
	float  buf[2];
	int	map_color;
	int	ix1, iy1, ix2, iy2;
	float  zm = 1, xo = 0, yo = 0;
	int	i,zoom_level=0;
	//int zm_cnt=0;
		
  int nix1=0;
  int nix2=0;
  int niy1=0;
  int niy2=0;

	/* zooming rate */
	xo = 0;
	yo = 0;
	zm = 2;
  zoom_level = var.nzoomdepth;  
  //zoom_level = getZoomLevel(zm_cnt, var); 
  
	/* Per Map data */
	map_color = color[36];

	sprintf(fname, "%s", MAP_LINE_FILE);
	
	
  fprintf(stderr,"map_disp zoom_level-->%d\n",zoom_level);
  
	
	if ((fd = fopen(fname, "rb")) != NULL ){

		while (fread(ibuf, sizeof(float), 2, fd) > 0)
		{
			num  = ibuf[0];
			code = ibuf[1];
			fread(buf, sizeof(float), 2, fd);
			ix1 = (int)(zm * (buf[0] - xo) + 0.5);
			iy1 = var.nDispY - (int)(zm * (buf[1] - yo) + 0.5);

			nix1 =   (int) ( ( (zm * (buf[0] - xo)) - var.nOrgX ) / var.nXscalef + 0.5);
			niy1 =   (int) ( ( (600.0 - (zm * (buf[1] - yo) )) - var.nOrgY ) / var.nYscalef + 0.5);
  
			for (i=1; i<num; i++)
			{
				fread(buf, sizeof(float), 2, fd);

				ix2 = (int)(zm * (buf[0] - xo) + 0.5);
				iy2 = var.nDispY - (int)(zm * (buf[1] - yo) + 0.5);

				nix2 =   (int) ( ( (zm * (buf[0] - xo)) - var.nOrgX ) / var.nXscalef  + 0.5  );
				niy2 =   (int) ( ( (600.0 - (zm * (buf[1] - yo) )) - var.nOrgY ) / var.nYscalef  + 0.5  );

        /*
					  0:?ѹݵ? ?ؾȼ?, ???漱, ��?ֵ?, ?︪??, ???? 
            1:?????? ?? 
            2:??????, ?????ð??? 
            3:??/?? ????, ?????? ?????? 
            5:?ѹݵ? ?̿? ?ڷ? - ????
            6:?ѹݵ? ?̿? ?ڷ? - ?߱?
            7:?ѹݵ? ?̿? ?ڷ? - ?Ϻ?
            8:?ؾȼ?
				*/
        if (zoom_level >= 0 && (code == 0 || code == 1 || code == 6 || code == 7 || code == 8 ))
				{
				  
				  gdImageLine(im, nix1, niy1, nix2, niy2, map_color);
					if (zoom_level > 1 && var.nDispX > 400)
						gdImageLine(im, nix1 + 1, niy1, nix2 + 1, niy2, map_color);
					if (zoom_level > 2 && var.nDispX > 400)
						gdImageLine(im, nix1, niy1 + 1, nix2, niy2 + 1, map_color);
				}
/*	
				if (zoom_level > 2 )
				{
					gdImageLine(im, nix1, niy1, nix2, niy2, map_color);
				}
*/				
				ix1 = ix2;
				iy1 = iy2;
				nix1 = nix2;
				niy1 = niy2;

			}
		}
		fclose(fd);
	}
	
	return 0;
}

/*============================================================================*
 *  Radar data display
 *============================================================================*/
float R_to_dBZ_f(float rain, float zr_a, float zr_b)
{
	return (10*log10(zr_a) + (zr_b*10)*log10(rain));
}

float dBZ_to_R_f(float dBZ, float zr_a, float zr_b)
{
	return (pow(pow(10.,((float)dBZ/10.))/zr_a, 1/zr_b));
}

int radar_echo_data(PARAM_INFO var, short **DATA, float **rdr_data)
{ 
  int ii,jj;
  double fval;
	
	
	for( jj=0;jj<var.nDispY ;jj++){
		 for( ii=0;ii<var.nDispX ;ii++){		  
			  fval = calc_radar_value(var, DATA, jj,ii);
			  rdr_data[jj][ii] = fval/100.f;
		 }
	 }
	 
	return 0;
}

int radar_echo_disp(PARAM_INFO var, short **DATA, gdImagePtr im, int color[], COLOR_INFO color_info, int sat_on)
{
	int	c, i;
	int legend_cnt;
  
  int ii,jj;
  double fval;
	
	float rain;
	float zr_a = 200.0f, zr_b = 1.6f; 
	
	legend_cnt = color_info.legend_cnt;
	
	float dbz[legend_cnt];
	float dbz_min = 0.0f;   
		
	//?????? ?ܰ??? ǥ??
	for (i=0; i<legend_cnt; i++)
	{
		rain = color_info.data[i].rain; 
		if(var.unit_flg == 'D')	{
			dbz[i] = color_info.data[i].dbz * 100;  //display dBZ
		} else {
			dbz[i] = R_to_dBZ_f(rain, zr_a, zr_b) * 100;  //display mm/hr
		}

	}
	
	for( jj=0;jj<var.nDispY ;jj++){
		 for( ii=0;ii<var.nDispX ;ii++){		  
			  fval = calc_radar_value(var, DATA, jj,ii);
			  c = rdr_level_color_disp((short)fval, legend_cnt, dbz, dbz_min);
			  //if(c >= 0 && c != 33) gdImageSetPixel(im, ii, jj, color[c]);
			  if(sat_on == 0 && (c >= 0 && c != 33)) gdImageSetPixel(im, ii, jj, color[c]);
			  else if(sat_on == 1 && c >= 0) gdImageSetPixel(im, ii, jj, color[c]);
			  	
			
		 }
	 }
	return 0;
}

double calc_radar_value(PARAM_INFO var, short **DATA, int j, int i)
{
	double  fi , fj ;
	double  fdi, fdj;
	double  fx= 0;
	double  fy= 0;
	double  fz= 0;
	double  fw= 0;
	double  fval=0;
	int di =0;
	int dj =0;

	fi =  ( ( (double)i *  var.nXscalef  ) + (double)var.nOrgX ) *  2.0 ;
	fj =  1199.0 - (double)var.nOrgY*2.0  - (((double)j * var.nYscalef ) * 2.0) ;

	di = (int)fi;
	dj = (int)fj;
	
	//if(j == var.nDispY-1) return BAD_VAL;
	
  //fprintf(stderr, "4-->%d - %d ==  fi:%f , fj:%f ==  di:%d , dj:%d \n",j, i, (float)fi , (float)fj, di, dj);
  //fprintf(stderr, "4-->%d - %d ==  fi:%f , fj:%f ==  di:%d , dj:%d \n",j, i, (float)fi , (float)fj, di, dj);
 
    if (di < 0 || dj < 0)
        return 0;


	if(  DATA[dj][di] == BOUND   ) return BOUND;
	
	if( fi == di && fj == dj ){
		fval =  DATA[dj][di];
	}
	else{
		fdi =  fi - di;
		fdj =  fj - dj;

		if( fdi == 0.0 && fdj != 0.0 ){
			if(  DATA[dj+1][di+0] == BAD_VAL ) { fx = 0; }	 else{ fx = DATA[dj+1][di+0];  }
			if(  DATA[dj+1][di+1] == BAD_VAL ) { fy = 0; }	 else{ fy = DATA[dj+1][di+1];  }
			if(  DATA[dj+0][di+1] == BAD_VAL ) { fz = 0; }	 else{ fz = DATA[dj+0][di+1];  }
			if(  DATA[dj+0][di+0] == BAD_VAL ) { fw = 0; }	 else{ fw = DATA[dj+0][di+0];  }
			fdj = 1.0 - fdj;

			 
				if(     DATA[dj+1][di+0] == BOUND &&
                DATA[dj+1][di+1] == BOUND &&
                DATA[dj+0][di+1] == BOUND &&
                DATA[dj+0][di+0] == BOUND  ) {
					fval = BOUND ;
				}
				else if(  DATA[dj+1][di+0] <= BAD_VAL &&
              	  DATA[dj+1][di+1] <= BAD_VAL &&
              	  DATA[dj+0][di+1] <= BAD_VAL &&
              	  DATA[dj+0][di+0] <= BAD_VAL  ) {
					fval = BAD_VAL ;
			  }
        else{
				   fval = calc_val( fdj, fdi, fx, fy, fz ,fw) +0.5;
        }

		}
		else if( fdi != 0.0 && fdj == 0.0 ){
			if(  DATA[dj+0][di+0] == BAD_VAL ) { fx = 0; }	 else{ fx = DATA[dj+0][di+0];  }
			if(  DATA[dj+0][di+1] == BAD_VAL ) { fy = 0; }	 else{ fy = DATA[dj+0][di+1];  }
			if(  DATA[dj-1][di+1] == BAD_VAL ) { fz = 0; }	 else{ fz = DATA[dj-1][di+1];  }
			if(  DATA[dj-1][di+0] == BAD_VAL ) { fw = 0; }	 else{ fw = DATA[dj-1][di+0];  }

				if(     DATA[dj+0][di+0] == BOUND &&
                DATA[dj+0][di+1] == BOUND &&
                DATA[dj-1][di+1] == BOUND &&
                DATA[dj-1][di+0] == BOUND  ) {
					fval = BOUND ;
				}
				else if(  DATA[dj+0][di+0] <= BAD_VAL &&
              	  DATA[dj+0][di+1] <= BAD_VAL &&
              	  DATA[dj-1][di+1] <= BAD_VAL &&
              	  DATA[dj-1][di+0] <= BAD_VAL  ) {
					fval = BAD_VAL ;
			  }
        else{
				   fval = calc_val( fdj, fdi, fx, fy, fz ,fw) +0.5;
        }
		}
		else if( fdi != 0.0 && fdj != 0.0 ){
			if(  DATA[dj+1][di+0] == BAD_VAL ) { fx = 0; }	 else{ fx = DATA[dj+1][di+0];  }
			if(  DATA[dj+1][di+1] == BAD_VAL ) { fy = 0; }	 else{ fy = DATA[dj+1][di+1];  }
			if(  DATA[dj+0][di+1] == BAD_VAL ) { fz = 0; }	 else{ fz = DATA[dj+0][di+1];  }
			if(  DATA[dj+0][di+0] == BAD_VAL ) { fw = 0; }	 else{ fw = DATA[dj+0][di+0];  }
			fdj = 1.0 - fdj;

				if(     DATA[dj+1][di+0] == BOUND &&
                DATA[dj+1][di+1] == BOUND &&
                DATA[dj+0][di+1] == BOUND &&
                DATA[dj+0][di+0] == BOUND  ) {
					fval = BOUND ;
				}
				else if(  DATA[dj+1][di+0] <= BAD_VAL &&
              	  DATA[dj+1][di+1] <= BAD_VAL &&
              	  DATA[dj+0][di+1] <= BAD_VAL &&
              	  DATA[dj+0][di+0] <= BAD_VAL  ) {
					fval = BAD_VAL ;
			  }
        else{
				   fval = calc_val( fdj, fdi, fx, fy, fz ,fw) +0.5;
        }
		}
	}
	return fval;
}
double lgt_calc_radar_value(PARAM_INFO var, int **DATA, int j, int i)
{
	double  fi , fj ;
	double  fdi, fdj;
	double  fx= 0;
	double  fy= 0;
	double  fz= 0;
	double  fw= 0;
	double  fval=0;
	int di =0;
	int dj =0;

	fi = ( ( ( (double)i *  var.nXscalef  ) + (double)var.nOrgX ) *  2.0 ) / 2.0;
	fj = ( 1199.0 - (double)var.nOrgY*2.0  - (((double)j * var.nYscalef ) * 2.0) )/ 2.0;
	
	di = (int)fi;
	dj = (int)fj;
	
	//if(j == var.nDispY-1) return BAD_VAL;
	
  //fprintf(stderr, "4-->%d - %d ==  fi:%f , fj:%f ==  di:%d , dj:%d \n",j, i, (float)fi , (float)fj, di, dj);
  //fprintf(stderr, "4-->%d - %d ==  fi:%f , fj:%f ==  di:%d , dj:%d \n",j, i, (float)fi , (float)fj, di, dj);
  
  if(dj==0)
  	return DATA[dj][di];
  
	if(  DATA[dj][di] == BOUND   ) return BOUND;
	
	if( fi == di && fj == dj ){
		fval =  DATA[dj][di];
	}
	else{
		fdi =  fi - di;
		fdj =  fj - dj;

		if( fdi == 0.0 && fdj != 0.0 ){
			if(  DATA[dj+1][di+0] == BAD_VAL ) { fx = 0; }	 else{ fx = DATA[dj+1][di+0];  }
			if(  DATA[dj+1][di+1] == BAD_VAL ) { fy = 0; }	 else{ fy = DATA[dj+1][di+1];  }
			if(  DATA[dj+0][di+1] == BAD_VAL ) { fz = 0; }	 else{ fz = DATA[dj+0][di+1];  }
			if(  DATA[dj+0][di+0] == BAD_VAL ) { fw = 0; }	 else{ fw = DATA[dj+0][di+0];  }
			fdj = 1.0 - fdj;

			 
				if(     DATA[dj+1][di+0] == BOUND &&
                DATA[dj+1][di+1] == BOUND &&
                DATA[dj+0][di+1] == BOUND &&
                DATA[dj+0][di+0] == BOUND  ) {
					fval = BOUND ;
				}
				else if(  DATA[dj+1][di+0] <= BAD_VAL &&
              	  DATA[dj+1][di+1] <= BAD_VAL &&
              	  DATA[dj+0][di+1] <= BAD_VAL &&
              	  DATA[dj+0][di+0] <= BAD_VAL  ) {
					fval = BAD_VAL ;
			  }
        else{
				   fval = calc_val( fdj, fdi, fx, fy, fz ,fw) +0.5;
        }

		}
		else if( fdi != 0.0 && fdj == 0.0 ){
			if(  DATA[dj+0][di+0] == BAD_VAL ) { fx = 0; }	 else{ fx = DATA[dj+0][di+0];  }
			if(  DATA[dj+0][di+1] == BAD_VAL ) { fy = 0; }	 else{ fy = DATA[dj+0][di+1];  }
			if(  DATA[dj-1][di+1] == BAD_VAL ) { fz = 0; }	 else{ fz = DATA[dj-1][di+1];  }
			if(  DATA[dj-1][di+0] == BAD_VAL ) { fw = 0; }	 else{ fw = DATA[dj-1][di+0];  }

				if(     DATA[dj+0][di+0] == BOUND &&
                DATA[dj+0][di+1] == BOUND &&
                DATA[dj-1][di+1] == BOUND &&
                DATA[dj-1][di+0] == BOUND  ) {
					fval = BOUND ;
				}
				else if(  DATA[dj+0][di+0] <= BAD_VAL &&
              	  DATA[dj+0][di+1] <= BAD_VAL &&
              	  DATA[dj-1][di+1] <= BAD_VAL &&
              	  DATA[dj-1][di+0] <= BAD_VAL  ) {
					fval = BAD_VAL ;
			  }
        else{
				   fval = calc_val( fdj, fdi, fx, fy, fz ,fw) +0.5;
        }
		}
		else if( fdi != 0.0 && fdj != 0.0 ){
			if(  DATA[dj+1][di+0] == BAD_VAL ) { fx = 0; }	 else{ fx = DATA[dj+1][di+0];  }
			if(  DATA[dj+1][di+1] == BAD_VAL ) { fy = 0; }	 else{ fy = DATA[dj+1][di+1];  }
			if(  DATA[dj+0][di+1] == BAD_VAL ) { fz = 0; }	 else{ fz = DATA[dj+0][di+1];  }
			if(  DATA[dj+0][di+0] == BAD_VAL ) { fw = 0; }	 else{ fw = DATA[dj+0][di+0];  }
			fdj = 1.0 - fdj;

				if(     DATA[dj+1][di+0] == BOUND &&
                DATA[dj+1][di+1] == BOUND &&
                DATA[dj+0][di+1] == BOUND &&
                DATA[dj+0][di+0] == BOUND  ) {
					fval = BOUND ;
				}
				else if(  DATA[dj+1][di+0] <= BAD_VAL &&
              	  DATA[dj+1][di+1] <= BAD_VAL &&
              	  DATA[dj+0][di+1] <= BAD_VAL &&
              	  DATA[dj+0][di+0] <= BAD_VAL  ) {
					fval = BAD_VAL ;
			  }
        else{
				   fval = calc_val( fdj, fdi, fx, fy, fz ,fw) +0.5;
        }
		}
	}
	return fval;
}

double calc_val( double jj, double ii, double fx, double fy, double fz, double fw)
{
	double dd=0;
	double x0=0;
	double x1=0;

	x0 =  fx + ( fw-fx ) * (double)jj / 1.0 ;
	x1 =  fy + ( fz-fy ) * (double)jj / 1.0 ;

	dd =  x0 + ( x1-x0 ) * (double)ii / 1.0 ;

	return dd;
}

/*============================================================================*
 *  Color of level display
 *============================================================================*/    
int rdr_level_color_disp(short v, int cnt, float *dbz, float dbz_min)   
{
  int c = -1, i;
		
	if ((int)v == BOUND) 
	{
		c = 33;		// NO area
				
	}else	if ((int)v == BAD_VAL) {
		c = -254;				// bad value
	}
	else if ((int)v < dbz_min) 
	{
		c = -254;		// NO data 
	}
	else
	{
		for (i=0; i < cnt; i++)
		{
			if ((float)v < dbz[i])
			{
			  //fprintf(stderr,"fileName-->%\n",dbz[i], v);
				c = i;
				break;
			}
		}
		
		if(i==cnt && (float)v >= dbz[i-1]) {
			c = i-1;
		}
	}
	return c;
}
