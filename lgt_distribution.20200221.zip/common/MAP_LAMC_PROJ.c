
#include "MAP_LAMC_PROJ.h"

void MAP_LAMC_PROJ_LATLON2XY(MAP_LAMC_PROJ* obj, float *x, float *y, float lat, float lon)
{
    double slat1, slat2, ra, theta;
    
    //if (obj->_.var.first == 0)
    {
        obj->_.var.PI = M_PI; //asin(1.0)*2.0;
        obj->_.var.DEGRAD = obj->_.var.PI / 180.0;
        obj->_.var.RADDEG = 180.0 / obj->_.var.PI;
        obj->_.var.re = obj->_.Re / obj->_.grid;
        slat1 = obj->_.slat1 * obj->_.var.DEGRAD;
        slat2 = obj->_.slat2 * obj->_.var.DEGRAD;
        obj->_.var.olon = obj->_.olon * obj->_.var.DEGRAD;
        obj->_.var.olat = obj->_.olat * obj->_.var.DEGRAD;
        obj->_.var.sn = tan(obj->_.var.PI * 0.25 + slat2 * 0.5) / tan(obj->_.var.PI * 0.25 + slat1 * 0.5);
        obj->_.var.sn = log(cos(slat1) / cos(slat2)) / log(obj->_.var.sn);
        obj->_.var.sf = tan(obj->_.var.PI * 0.25 + slat1 * 0.5);
        obj->_.var.sf = pow(obj->_.var.sf, obj->_.var.sn) * cos(slat1) / obj->_.var.sn;
        obj->_.var.ro = tan(obj->_.var.PI * 0.25 + obj->_.var.olat * 0.5);
        obj->_.var.ro = obj->_.var.re * obj->_.var.sf / pow(obj->_.var.ro, obj->_.var.sn);
        obj->_.var.first = 1;
    }
    
    /*
    FILE* fp = fopen("/tmp/new.txt", "w");
    fprintf(fp, "%lf %lf %lf %lf %lf %lf %lf %lf\n",
            obj->_.var.PI, obj->_.var.DEGRAD, obj->_.var.RADDEG, obj->_.var.re,
            slat1, slat2,
            obj->_.var.olat, obj->_.var.olon
            );
*/
    
    ra = tan(obj->_.var.PI * 0.25 + (lat) * obj->_.var.DEGRAD * 0.5);
    ra = obj->_.var.re * obj->_.var.sf / pow(ra, obj->_.var.sn);
    theta = (lon) * obj->_.var.DEGRAD - obj->_.var.olon;
    if (theta > obj->_.var.PI) theta -= 2.0 * obj->_.var.PI;
    if (theta < -obj->_.var.PI) theta += 2.0 * obj->_.var.PI;
    theta *= obj->_.var.sn;
    *x = (float) (ra * sin(theta)) + obj->_.ox;
    *y = (float) (obj->_.var.ro - ra * cos(theta)) + obj->_.oy;

    return;
}

void MAP_LAMC_PROJ_XY2LATLON(MAP_LAMC_PROJ* obj, float *lat, float *lon, float x, float y)
{
    double slat1, slat2, alon, alat, xn, yn, ra, theta;
    double DEGRAD = M_PI / 180.0;
    double RADDEG = 180.0 / M_PI;
    double re = obj->_.Re / obj->_.grid;

    //if (obj->_.var.first == 0)
    {
        slat1 = obj->_.slat1 * DEGRAD;
        slat2 = obj->_.slat2 * DEGRAD;
        obj->_.var.sn = tan(M_PI * 0.25 + slat2 * 0.5) / tan(M_PI * 0.25 + slat1 * 0.5);
        obj->_.var.sn = log(cos(slat1) / cos(slat2)) / log(obj->_.var.sn);
        obj->_.var.sf = tan(M_PI * 0.25 + slat1 * 0.5);
        obj->_.var.sf = pow(obj->_.var.sf, obj->_.var.sn) * cos(slat1) / obj->_.var.sn;
        obj->_.var.ro = tan(M_PI * 0.25 + (obj->_.olat * DEGRAD) * 0.5);
        obj->_.var.ro = re * obj->_.var.sf / pow(obj->_.var.ro, obj->_.var.sn);
        obj->_.var.first = 1;
    }

    xn = x - obj->_.ox;
    yn = obj->_.var.ro - y + obj->_.oy;
    ra = sqrt(xn * xn + yn * yn);

    //    if (obj->_.var.sn < 0.0)//BUG!!
    //        -ra; //BUG!!

    alat = pow((re * obj->_.var.sf / ra), (1.0 / obj->_.var.sn));
    alat = 2.0 * atan(alat) - M_PI * 0.5;
    if (fabs(xn) <= 0.0)
    {
        theta = 0.0;
    }
    else
    {
        if (fabs(yn) <= 0.0)
        {
            theta = M_PI * 0.5;
            //if (xn < 0.0) //BUG!!
            //                -theta; //BUG!!
        }
        else
            theta = atan2(xn, yn);
    }

    alon = theta / obj->_.var.sn + (obj->_.olon * DEGRAD);
    *lat = (float) (alat * RADDEG);
    *lon = (float) (alon * RADDEG);

    return;
}

void MAP_LAMC_PROJ_DISPOSE(MAP_LAMC_PROJ** pObj)
{
    _dispose(pObj);

    return;
}

void initMAP_LAMC_PROJ(MAP_LAMC_PROJ* obj)
{
    obj->_.Re = (6371.00877);
    obj->_.slat1 = 30.0;
    obj->_.slat2 = 60.0;
    obj->_.olon = 126.0;
    obj->_.olat = 38.0;
    obj->_.ox = 200;
    obj->_.oy = 400;
    obj->_.grid = 2.0;
    
    obj->_.var.first = 0;
    
    obj->LATLON2XY = MAP_LAMC_PROJ_LATLON2XY;

    obj->XY2LATLON = MAP_LAMC_PROJ_XY2LATLON;

    obj->DISPOSE = MAP_LAMC_PROJ_DISPOSE;

    return;
}

MAP_LAMC_PROJ* newMAP_LAMC_PROJ()
{
    MAP_LAMC_PROJ* obj = calloc(1, sizeof (MAP_LAMC_PROJ));
    if (unlikely(obj == NULL))
    {
        _strerror;
        return NULL;
    }
    else
    {
        initMAP_LAMC_PROJ(obj);
    }

    return obj;
}