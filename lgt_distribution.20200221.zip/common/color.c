/*
 * color.c
 *
 *  Created on: 2011. 9. 9.
 *      Author: radar
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gd.h>

#include "color.h"

COLOR_INFO color_table_backup(char *path)
{
		COLOR_INFO color, color_tmp;
		FILE *fp;
		int col_num, R, G, B;
		float col_rain, col_dbz, rain;
		int cnt = 0, i, l_cnt=0;
		char col_tit[20];
		int j = 0;

		//초기화
 		color_tmp.cnt=0;
 		color_tmp.legend_cnt=0;
 		    
		fp = fopen(path, "r");
		
		if (fp != NULL)
		{
			fscanf(fp, "%d", &cnt);
			//fprintf(stderr,"cnt -> %d  \n", cnt);
			
			color_tmp.cnt = cnt;

			fscanf(fp, "%s", col_tit);
			strcpy(color.tit, col_tit);
   	  
			//fprintf(stderr,"COLOR_INFO -> %d\n", cnt);

			color_tmp.data = (COLOR_DATA*)malloc(cnt*sizeof(COLOR_DATA));  
    
			for (i=0; i<cnt; i++)
			{
		        fscanf(fp,"%d  %d  %d  %d  %f  %f", &col_num, &R, &G, &B, &col_rain, &col_dbz);
		  	    //fprintf(stderr,"j:%d, i:%d --> COLOR_INFO -> %d  %d  %d  %d  %f  %f  \n", j, i, col_num, R,G,B,col_rain,col_dbz);
    				color_tmp.data[i].num = col_num;
    				color_tmp.data[i].R = R;
    				color_tmp.data[i].G = G;
    				color_tmp.data[i].B = B;
    				color_tmp.data[i].rain = col_rain;
    				color_tmp.data[i].dbz = col_dbz;
			}
			//color.legend_cnt = l_cnt;
		}
		fclose(fp);


		if(color_tmp.cnt > 0){

		  color.cnt = color_tmp.cnt;
 		  color.legend_cnt=0;

 		  color.data = (COLOR_DATA *)malloc(cnt*sizeof(COLOR_DATA));

 		  for (i=0; i<color.cnt; i++)
 		  {
 		     col_rain = color_tmp.data[i+1].rain;
 		     rain = color_tmp.data[i].rain;

		     if(i < 32){
				if(i == 31){
					color.data[j].num = j;
					color.data[j].R   = color_tmp.data[i].R;
					color.data[j].G   = color_tmp.data[i].G;
					color.data[j].B   = color_tmp.data[i].B;
					color.data[j].rain= color_tmp.data[i].rain;
					color.data[j].dbz = color_tmp.data[i].dbz;
					j++;
					l_cnt++;

				}else if(rain != 0. && col_rain == 0.){
					color.data[j].num = j;
					color.data[j].R   = color_tmp.data[i].R;
					color.data[j].G   = color_tmp.data[i].G;
					color.data[j].B   = color_tmp.data[i].B;
					color.data[j].rain= color_tmp.data[i].rain;
					color.data[j].dbz = color_tmp.data[i].dbz;
					j++;
					l_cnt++;

				}else if(rain == 0. && col_rain == 0. && (color_tmp.data[i+2].rain == 0. && (i+2) < 32 )){ //중간에 0값 구하기
					color.data[j].num = j;
					color.data[j].R   = color_tmp.data[i].R;
					color.data[j].G   = color_tmp.data[i].G;
					color.data[j].B   = color_tmp.data[i].B;
					color.data[j].rain= color_tmp.data[i].rain;
					color.data[j].dbz = color_tmp.data[i].dbz;
					j++;
					l_cnt++;
				}
		     }else{
				color.data[i].num = i;
				color.data[i].R   = color_tmp.data[i].R;
				color.data[i].G   = color_tmp.data[i].G;
				color.data[i].B   = color_tmp.data[i].B;
				color.data[i].rain= color_tmp.data[i].rain;
				color.data[i].dbz = color_tmp.data[i].dbz;
		     }
		  }
			//fprintf(stderr,"j:%d, i:%d --> COLOR_INFO -> %d  %d  %d  %d  %f  %f  \n", j, i, color.data[i].num, color.data[i].R,color.data[i].G,color.data[i].B,color.data[i].rain,color.data[i].dbz);
			color.legend_cnt = l_cnt;
			
			freeColorIndex(color_tmp);
		}

		return color;
}

COLOR_INFO color_table(char *path)
{
                COLOR_INFO color, color_tmp;
                FILE *fp;
                int col_num, R, G, B;
                float col_rain, col_dbz, rain;
                int cnt = 0, i, l_cnt=0;
                char col_tit[20];
                int j = 0;

                color_tmp.cnt=0;
                color_tmp.legend_cnt=0;
                    
                fp = fopen(path, "r");

                if (fp != NULL)
                {
                        fscanf(fp, "%d", &cnt);

                        color_tmp.cnt = cnt;

                        fscanf(fp, "%s", col_tit);
                        strcpy(color.tit, col_tit);

                        color_tmp.data = (COLOR_DATA*)malloc(cnt*sizeof(COLOR_DATA));  
    
                        for (i=0; i<cnt; i++)
                        {
                        fscanf(fp,"%d  %d  %d  %d  %f  %f", &col_num, &R, &G, &B, &col_rain, &col_dbz);
                                color_tmp.data[i].num = col_num;
                                color_tmp.data[i].R = R;
                                color_tmp.data[i].G = G;
                                color_tmp.data[i].B = B;
                                color_tmp.data[i].rain = col_rain;
                                color_tmp.data[i].dbz = col_dbz;
                        }
                }
                fclose(fp);

                if(color_tmp.cnt > 0){

                  color.cnt = color_tmp.cnt;
                  color.legend_cnt=0;

                  color.data = (COLOR_DATA *)malloc(cnt*sizeof(COLOR_DATA));

                  for (i=0; i<color.cnt; i++)
                  {
                     col_rain = color_tmp.data[i+1].rain;
                     rain = color_tmp.data[i].rain;

                     if(i < 32){
                                if(rain != SKIP_COLOR){
                                        color.data[j].num = j;
                                        color.data[j].R   = color_tmp.data[i].R;
                                        color.data[j].G   = color_tmp.data[i].G;
                                        color.data[j].B   = color_tmp.data[i].B;
                                        color.data[j].rain= color_tmp.data[i].rain;
                                        color.data[j].dbz = color_tmp.data[i].dbz;
                                        j++;
                                        l_cnt++;

                                }
                     }else{
                                color.data[i].num = i;
                                color.data[i].R   = color_tmp.data[i].R;
                                color.data[i].G   = color_tmp.data[i].G;
                                color.data[i].B   = color_tmp.data[i].B;
                                color.data[i].rain= color_tmp.data[i].rain;
                                color.data[i].dbz = color_tmp.data[i].dbz;
                     }
                  }
                        color.legend_cnt = l_cnt;

                        freeColorIndex(color_tmp);
                }

                return color;
}

COLOR_INFO color_table_guidance(char *path)
{
		COLOR_INFO color, color_tmp;
		FILE *fp;
		int col_num, R, G, B;
		float col_rain, col_dbz, rain;
		int cnt = 0, i, l_cnt=0;
		char col_tit[20];
		int j = 0;

		//초기화
 		color_tmp.cnt=0;
 		color_tmp.legend_cnt=0;
 		    
		fp = fopen(path, "r");
		
		if (fp != NULL)
		{
			fscanf(fp, "%d", &cnt);
			//fprintf(stderr,"cnt -> %d  \n", cnt);
			
			color_tmp.cnt = cnt;

			fscanf(fp, "%s", col_tit);
		  strcpy(color.tit, col_tit);
   	  
   	  //fprintf(stderr,"COLOR_INFO -> %d\n", cnt);

      color_tmp.data = (COLOR_DATA*)malloc(cnt*sizeof(COLOR_DATA));  
    
			for (i=0; i<cnt; i++)
			{
		    fscanf(fp,"%d  %d  %d  %d  %f  %f", &col_num, &R, &G, &B, &col_rain, &col_dbz);
		  	//fprintf(stderr,"j:%d, i:%d --> COLOR_INFO -> %d  %d  %d  %d  %f  %f  \n", j, i, col_num, R,G,B,col_rain,col_dbz);

    				color_tmp.data[i].num = col_num;
    				color_tmp.data[i].R = R;
    				color_tmp.data[i].G = G;
    				color_tmp.data[i].B = B;
    				color_tmp.data[i].rain = col_rain;
    				color_tmp.data[i].dbz = col_dbz;

    	}
    	//color.legend_cnt = l_cnt;
		}
		fclose(fp);


		if(color_tmp.cnt > 0){

		  color.cnt = color_tmp.cnt;
 		  color.legend_cnt=0;

   	  color.data = (COLOR_DATA *)malloc(cnt*sizeof(COLOR_DATA));

			for (i=0; i<color.cnt; i++)
			{
        col_rain = color_tmp.data[i+1].rain;
        rain = color_tmp.data[i].rain;

       if(i < 32){
          if(rain != -9999.){
            color.data[j].num = j;
            color.data[j].R   = color_tmp.data[i].R;
            color.data[j].G   = color_tmp.data[i].G;
            color.data[j].B   = color_tmp.data[i].B;
            color.data[j].rain= color_tmp.data[i].rain;
            color.data[j].dbz = color_tmp.data[i].dbz;
            j++;
            l_cnt++;
          }
        
       }else{
          color.data[i].num = i;
       		color.data[i].R   = color_tmp.data[i].R;
       		color.data[i].G   = color_tmp.data[i].G;
       		color.data[i].B   = color_tmp.data[i].B;
       		color.data[i].rain= color_tmp.data[i].rain;
       		color.data[i].dbz = color_tmp.data[i].dbz;
       }
      }
      //fprintf(stderr,"j:%d, i:%d --> COLOR_INFO -> %d  %d  %d  %d  %f  %f  \n", j, i, color.data[i].num, color.data[i].R,color.data[i].G,color.data[i].B,color.data[i].rain,color.data[i].dbz);
			color.legend_cnt = l_cnt;
			
			freeColorIndex(color_tmp);
		}

		return color;
}

/**
 *
 */

int color_table_read(gdImagePtr im, int	color[], COLOR_INFO rdr_color)
{
	int R, G, B;
	int i;
	int cnt=0;

	// data level color
	cnt = rdr_color.cnt;

	for (i=0; i<cnt; i++)
	{
		R = rdr_color.data[i].R;
		G = rdr_color.data[i].G;
		B = rdr_color.data[i].B;

		color[i] = gdImageColorAllocate(im, R, G, B);
		//rain[i] = rdr_color.data[i].rain;
		//dbz[i] = rdr_color.data[i].dbz;
//		fprintf(stderr,"color[%d] = gdImageColorAllocate(im, %d, %d, %d); // rain = %f  \n", i, R,G,B,rdr_color.data[i].rain);
	}

	return 0;
}

/**
 *
 */
void freeColorIndex(COLOR_INFO color)
{
		if(color.cnt > 0) {
			  free(color.data);
		}
}
