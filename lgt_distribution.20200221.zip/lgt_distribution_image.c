#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <zlib.h>

#include "nrutil.h"
#include "map_ini.h"
#include "lgt_distribution_image.h"

char *strptime(const char *s, const char *format, struct tm *tm);

/* 현재 시간부터 10분 누적 낙뢰 자료 읽기 */
int** read_lgt_txt_data(int **DATA, char* readFile, struct tm curTime)
{
	FILE *rfp;
	char buf[BUFFER_SIZE];
	int mon, day, yr, hr, min, itmp, num_sns;
	float sec, lat, lon, imp, ftmp;
	char type;
	float x,y;
	int ix, iy;
	
	long ltmp; double fftmp;
	char stmp[BUFFER_SIZE];

	struct lamc_parameter map;
	MAP_INFO mapInfo = comp_map_info();
	//MAP_INFO mapInfo = comp_map_info_1km();
	map = mapInfo.map;
	
	//시간 설정
	char nowTimeStr[BUFFER_SIZE];
	char agoTimeStr[BUFFER_SIZE];
	char dataTimeStr[BUFFER_SIZE];
	struct tm agoTime;

	strftime(nowTimeStr, BUFFER_SIZE, "%Y%m%d%H%M", &curTime);

	agoTime = incMin(curTime, -10);
	strftime(agoTimeStr, BUFFER_SIZE, "%Y%m%d%H%M", &agoTime);

	if( (rfp = fopen(readFile, "r")) != NULL ){
		fprintf(stderr, "\n--------------------------------------------------------------------------------\n");		
		fprintf(stderr, "TXT read file name : %s\n", readFile);		
		fprintf(stderr, "[ %s ~ %s ]\n", agoTimeStr , nowTimeStr );
		
		while (fgets(buf, BUFFER_SIZE, rfp) != NULL) {	  
/*    낙뢰 구버전 자료 읽기.....
			sscanf(buf, "%d/%d/%d %d:%d:%f %f %f %f %d %f %f %f %d %f %d %c ",
				&mon, &day, &yr,
				&hr, &min, &sec,
				&lat, &lon, &imp, &itmp, &ftmp, &ftmp, &ftmp, &itmp, &ftmp, &num_sns, &type);				
			sprintf(dataTimeStr, "%04d%02d%02d%02d%02d", yr + 2000, mon, day, hr, min);
*/
			// 낙뢰 신버전  자료 읽기
			sscanf(buf, "%ld %d-%d-%d %d:%d:%lf+%d:%d %d %s %f %f %f %f %f %d %d" , 
					&ltmp , &yr, &mon, &day , &hr, &min, &fftmp, &itmp , &itmp , &itmp , &stmp , &lon, &lat , &ftmp, &imp , &ftmp, &type , &num_sns);
             sprintf(dataTimeStr, "%04d%02d%02d%02d%02d", yr, mon, day, hr, min);



			if(strcmp(dataTimeStr, agoTimeStr) <= 0) continue;
			if(strcmp(dataTimeStr, nowTimeStr) > 0) break;

			x = -999.0;
			y = -999.0;
			lamcproj(&lon, &lat, &x, &y, 0, map);
			ix = (int)x;
			iy = (int)y;
			if (ix < 0 || ix > MI || iy < 0 || iy > MJ) continue;
			
			// 2013.05.09
			//DATA[iy][ix]++;
//			if(num_sns > 2 && (imp < 0 || imp > 10)) {
			if(  num_sns > 2  ) {
				fprintf(stderr, "-> %s %f %f %f %d %d \n", dataTimeStr , lon , lat , imp ,type , num_sns);
				DATA[iy][ix]++;
			}
		}

		fclose(rfp);
	}else{
		printf("file not found : %s\n", readFile);
	}

	return DATA;
}

// 낙뢰 자료 합산 후 쓰기 
int write_lgt_data(int **DATA, char* writeFile)
{
	FILE *rfp, *wfp;
	int **TDATA;
	int i,j,n;
	int ibuf[MI];
	
	char command[BUFFER_SIZE];
	char tmpString[BUFFER_SIZE];

	TDATA = imatrix(0, MJ, 0, MI);
	TDATA = data_init(TDATA);

	// create directory
	strncpy(tmpString, writeFile, strlen(writeFile)-strlen(strrchr( writeFile, '/')));
	tmpString[strlen(writeFile)-strlen(strrchr( writeFile, '/'))] = '\0';
	sprintf(command, "mkdir -p %s", tmpString);
	system(command);

	//file read
	if( (rfp = gzopen(writeFile, "r")) != NULL ){
		//printf("\t\t read file name : %s\n", writeFile);
		for(j=0; j<MJ; j++){
			n = gzread(rfp, ibuf, MI*sizeof(int));
			for(i=0; i<MI; i++){
				TDATA[j][i] = ibuf[i];
			}
		}
		gzclose(rfp);
	}


	for(j=0; j<MJ; j++){
		for(i=0; i<MI; i++){
			TDATA[j][i] += DATA[j][i];
		}
	}

	if((wfp = gzopen(writeFile, "w")) != NULL){
		//printf("\t\t DAY write file name : %s\n", writeFile);
		for(j=0; j<MJ; j++){
			for(i=0; i<MI; i++){
				if(gzwrite(wfp, &TDATA[j][i], sizeof(int)) < 0){
					printf("write file error!\n");
					return -1;
				}
			}
		}
		gzclose(wfp);
	}
	
	free_imatrix(TDATA, 0, MJ, 0, MI);

	return 0;
}

int** data_init(int** DATA)
{
	int i, j;

	for(j=0; j<MJ; j++){
		for(i=0; i<MI; i++){
			DATA[j][i] = 0;
		}
	}

	return DATA;
}

struct tm incMin(struct tm tm_ptr,int addMin)
{
	time_t the_time;
	struct tm new_tm_ptr;
	the_time = mktime(&tm_ptr);
	the_time = the_time + (60 * addMin);
	new_tm_ptr = *(localtime(&the_time));
	return new_tm_ptr;
}

