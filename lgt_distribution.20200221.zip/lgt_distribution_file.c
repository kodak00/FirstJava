/**
 * @file make_comp_zoom.h
 * @brief 낙뢰횟수 분포도 연/월/일별 파일 생성
 * @date 2012.06.25
 * @version 1.0
 * 프로그램 최초 배포버전
 * @author Weather Radar Center
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <zlib.h>

#include "nrutil.h"
#include "lgt_distribution_image.h"
#include "lgt_distribution_file.h"

struct _app_conf app_conf;

int **DATA = NULL;

int main(int argc, char **argv)
{
	APP->APP_INIT(argc, argv);

	// 옵션 파싱
	opt_proc(argc, argv);

	// 시그널 설정 작업
	signal_proc();

	// 설정파일 로드
	conf_proc();

	// 초기화 작업
	init_proc();

	// 메인 작업
	main_proc();

	// 마무리 작업
	end_proc();

	// 종료코드
	exit(EXIT_SUCCESS);
}

void signal_proc(void)
{
	struct sigaction ign_act = {}, child_act = {};

	ign_act.sa_handler = SIG_IGN;
	sigemptyset(&ign_act.sa_mask);
	ign_act.sa_flags = SA_RESTART;
	sigaction(SIGPIPE, &ign_act, NULL);

	child_act.sa_handler = read_childproc;
	sigemptyset(&ign_act.sa_mask);
	child_act.sa_flags = SA_RESTART | SA_NOCLDSTOP;
	sigaction(SIGCHLD, &child_act, NULL);

	return;
}

//설정파일 로드
int conf_proc()
{
	char* conf_path = NULL;
	char* section = "LGT_DSTR";
	extern struct _app_conf app_conf;

	/* log path */
	char log_path[PATH_MAX] = {};

	strptime(APP->_.argv[1], "%Y%m%d%H%M", &app_conf.tm_reqTime);

	conf_path = APP->_.app_conf;

	strftime(log_path, PATH_MAX, APP->_.app_logpath, &app_conf.tm_reqTime);
	APP->_.app_logpath = strdup(log_path);
	DIRECTORY->MKDIR(DIRECTORY->DIRNAME(log_path), 0755);
	APP->fp_log = fopen(APP->_.app_logpath, "a+");
	if (APP->fp_log == NULL)
		APP->fp_log = stderr;

	if (INI->isVALUE(conf_path, section, "INPUT_LGT_KMA_PATH") == -1)
	{
		fprintf(APP->fp_log, "[FATAL] %s(%05d): %s(%s:%s)\n", APP->_.app_name, getpid(), conf_path, section, "INPUT_LGT_KMA_PATH");
		exit(EXIT_FAILURE);
	}
	else strftime(app_conf.input_lgt_kma_path, PATH_MAX, INI->getSTRING(conf_path, section, "INPUT_LGT_KMA_PATH"), &app_conf.tm_reqTime);

	if (INI->isVALUE(conf_path, section, "INPUT_LGT_KAR_PATH") == -1)
	{
		fprintf(APP->fp_log, "[FATAL] %s(%05d): %s(%s:%s)\n", APP->_.app_name, getpid(), conf_path, section, "INPUT_LGT_KAR_PATH");
		exit(EXIT_FAILURE);
	}
	else strftime(app_conf.input_lgt_kar_path, PATH_MAX, INI->getSTRING(conf_path, section, "INPUT_LGT_KAR_PATH"), &app_conf.tm_reqTime);

	if (INI->isVALUE(conf_path, section, "INPUT_LGT_KPX_PATH") == -1)
	{
		fprintf(APP->fp_log, "[FATAL] %s(%05d): %s(%s:%s)\n", APP->_.app_name, getpid(), conf_path, section, "INPUT_LGT_KPX_PATH");
		exit(EXIT_FAILURE);
	}
	else strftime(app_conf.input_lgt_kpx_path, PATH_MAX, INI->getSTRING(conf_path, section, "INPUT_LGT_KPX_PATH"), &app_conf.tm_reqTime);

	if (INI->isVALUE(conf_path, section, "OUTPUT_LGT_KMA_YEAR_PATH") == -1)
	{
		fprintf(APP->fp_log, "[FATAL] %s(%05d): %s(%s:%s)\n", APP->_.app_name, getpid(), conf_path, section, "OUTPUT_LGT_KMA_YEAR_PATH");
		exit(EXIT_FAILURE);
	}
	else strftime(app_conf.output_lgt_kma_year_path,  PATH_MAX, INI->getSTRING(conf_path, section, "OUTPUT_LGT_KMA_YEAR_PATH"), &app_conf.tm_reqTime);

	if (INI->isVALUE(conf_path, section, "OUTPUT_LGT_KAR_YEAR_PATH") == -1)
	{
		fprintf(APP->fp_log, "[FATAL] %s(%05d): %s(%s:%s)\n", APP->_.app_name, getpid(), conf_path, section, "OUTPUT_LGT_KAR_YEAR_PATH");
		exit(EXIT_FAILURE);
	}
	else strftime(app_conf.output_lgt_kar_year_path,  PATH_MAX, INI->getSTRING(conf_path, section, "OUTPUT_LGT_KAR_YEAR_PATH"), &app_conf.tm_reqTime);

	if (INI->isVALUE(conf_path, section, "OUTPUT_LGT_KPX_YEAR_PATH") == -1)
	{
		fprintf(APP->fp_log, "[FATAL] %s(%05d): %s(%s:%s)\n", APP->_.app_name, getpid(), conf_path, section, "OUTPUT_LGT_KPX_YEAR_PATH");
		exit(EXIT_FAILURE);
	}
	else strftime(app_conf.output_lgt_kpx_year_path,  PATH_MAX, INI->getSTRING(conf_path, section, "OUTPUT_LGT_KPX_YEAR_PATH"), &app_conf.tm_reqTime);

	if (INI->isVALUE(conf_path, section, "OUTPUT_LGT_KMA_MON_PATH") == -1)
	{
		fprintf(APP->fp_log, "[FATAL] %s(%05d): %s(%s:%s)\n", APP->_.app_name, getpid(), conf_path, section, "OUTPUT_LGT_KMA_MON_PATH");
		exit(EXIT_FAILURE);
	}
	else strftime(app_conf.output_lgt_kma_month_path, PATH_MAX, INI->getSTRING(conf_path, section, "OUTPUT_LGT_KMA_MON_PATH"), &app_conf.tm_reqTime);

	if (INI->isVALUE(conf_path, section, "OUTPUT_LGT_KAR_MON_PATH") == -1)
	{
		fprintf(APP->fp_log, "[FATAL] %s(%05d): %s(%s:%s)\n", APP->_.app_name, getpid(), conf_path, section, "OUTPUT_LGT_KAR_MON_PATH");
		exit(EXIT_FAILURE);
	}
	else strftime(app_conf.output_lgt_kar_month_path, PATH_MAX, INI->getSTRING(conf_path, section, "OUTPUT_LGT_KAR_MON_PATH"), &app_conf.tm_reqTime);

	if (INI->isVALUE(conf_path, section, "OUTPUT_LGT_KPX_MON_PATH") == -1)
	{
		fprintf(APP->fp_log, "[FATAL] %s(%05d): %s(%s:%s)\n", APP->_.app_name, getpid(), conf_path, section, "OUTPUT_LGT_KPX_YEAR_PATH");
		exit(EXIT_FAILURE);
	}
	else strftime(app_conf.output_lgt_kpx_month_path, PATH_MAX, INI->getSTRING(conf_path, section, "OUTPUT_LGT_KPX_MON_PATH"), &app_conf.tm_reqTime);

	if (INI->isVALUE(conf_path, section, "OUTPUT_LGT_KMA_DAY_PATH") == -1)
	{
		fprintf(APP->fp_log, "[FATAL] %s(%05d): %s(%s:%s)\n", APP->_.app_name, getpid(), conf_path, section, "OUTPUT_LGT_KMA_DAY_PATH");
		exit(EXIT_FAILURE);
	}
	else strftime(app_conf.output_lgt_kma_day_path,   PATH_MAX, INI->getSTRING(conf_path, section, "OUTPUT_LGT_KMA_DAY_PATH"), &app_conf.tm_reqTime);

	if (INI->isVALUE(conf_path, section, "OUTPUT_LGT_KAR_DAY_PATH") == -1)
	{
		fprintf(APP->fp_log, "[FATAL] %s(%05d): %s(%s:%s)\n", APP->_.app_name, getpid(), conf_path, section, "OUTPUT_LGT_KAR_DAY_PATH");
		exit(EXIT_FAILURE);
	}
	else strftime(app_conf.output_lgt_kar_day_path,   PATH_MAX, INI->getSTRING(conf_path, section, "OUTPUT_LGT_KAR_DAY_PATH"), &app_conf.tm_reqTime);

	if (INI->isVALUE(conf_path, section, "OUTPUT_LGT_KPX_DAY_PATH") == -1)
	{
		fprintf(APP->fp_log, "[FATAL] %s(%05d): %s(%s:%s)\n", APP->_.app_name, getpid(), conf_path, section, "OUTPUT_LGT_KPX_DAY_PATH");
		exit(EXIT_FAILURE);
	}
	else strftime(app_conf.output_lgt_kpx_day_path, PATH_MAX, INI->getSTRING(conf_path, section, "OUTPUT_LGT_KPX_DAY_PATH"), &app_conf.tm_reqTime);

	return 0;
}

void init_proc()
{
	DATA = imatrix(0, MJ, 0, MI);

	DATA = data_init(DATA);

	return;
}

void main_proc()
{
#ifdef KMA_MODE
	read_lgt_txt_data(DATA, app_conf.input_lgt_kma_path, app_conf.tm_reqTime);

#pragma omp parallel default(none) firstprivate(DATA, app_conf)
	{
#pragma omp sections
		{
#pragma omp section
			{
				//day 생성
				write_lgt_data(DATA, app_conf.output_lgt_kma_day_path);
			}

#pragma omp section
			{
				//month 누적
				write_lgt_data(DATA, app_conf.output_lgt_kma_month_path);
			}

#pragma omp section
			{
				//year 누적
				write_lgt_data(DATA, app_conf.output_lgt_kma_year_path);
			}
		}
	}
#endif

#ifdef KAR_MODE
	DATA = read_lgt_txt_data(DATA, app_conf.input_lgt_kar_path, app_conf.tm_reqTime);

#pragma omp parallel default(none) firstprivate(DATA, app_conf)
	{
#pragma omp sections
		{
#pragma omp section
			{
				//day 생성
				write_lgt_data(DATA, app_conf.output_lgt_kar_day_path);
			}

#pragma omp section
			{
				//month 누적
				write_lgt_data(DATA, app_conf.output_lgt_kar_month_path);
			}

#pragma omp section
			{
				//year 누적
				write_lgt_data(DATA, app_conf.output_lgt_kar_year_path);
			}
		}
	}
#endif

#ifdef KPX_MODE
	DATA = read_lgt_txt_data(DATA, app_conf.input_lgt_kpx_path, app_conf.tm_reqTime);

#pragma omp parallel default(none) firstprivate(DATA, app_conf)
	{
#pragma omp sections
		{
#pragma omp section
			{
				//day 생성
				write_lgt_data(DATA, app_conf.output_lgt_kpx_day_path);
			}

#pragma omp section
			{
				//month 누적
				write_lgt_data(DATA, app_conf.output_lgt_kpx_month_path);
			}

#pragma omp section
			{
				//year 누적
				write_lgt_data(DATA, app_conf.output_lgt_kpx_year_path);
			}
		}
	}
#endif
	return 0;
}


void end_proc()
{
	if(DATA != NULL)
		free_imatrix(DATA, 0, MJ, 0, MI);

	return;
}

void read_childproc(int sig)
{
	int status = 0;

	pid_t pid = 0;

	do
	{
		pid = waitpid(-1, &status, WNOHANG);
	}
	while (pid == -1 && errno == EINTR);

#ifdef DEBUG
	if (WIFEXITED(status))
	{
		fprintf(stderr, "[INFO] Exit Status from %d(return %d)", pid, WEXITSTATUS(status));
	}
	else
	{
		fprintf(stderr, "[WARNING] Exit Status from %d(return %d)", pid, WEXITSTATUS(status));
	}
#endif

	return;
}

void usage(int status)
{
    if (status != EXIT_SUCCESS)
    {
        fprintf(stderr, "Try `%s -h' for more information.\n", program_invocation_short_name);
    }
    else
    {
        fprintf(stdout, "Usage: %s [OPTION] start_time\n", program_invocation_short_name);
        fprintf(stdout, " start_time: yyyyMMddhhmi\n");
        fprintf(stdout, "  -v, --verbose  Verbose Mode - Can use multiple\n");
        fprintf(stdout, "  -V, --version  output version information and exit\n");
        fprintf(stdout, "  -h, --help     display this help and exit\n");
    }

    //fprintf(stdout, "\nReport \'%s\' bugs to %s\n", program_invocation_short_name, EMAIL);
    fprintf(stdout, "  Make by %s\n\n", APP_AUTHOR);

    exit(status);
}

void usage_version(void)
{
    fprintf(stdout, "==============================\n");
    fprintf(stdout, "Program Name: %s\n", program_invocation_short_name);
    fprintf(stdout, "Version: %s\n", APP_VERSION);
    fprintf(stdout, "Build: %s (%s)\n", __DATE__, __TIME__);
    fprintf(stdout, "==============================\n");

    exit(EXIT_SUCCESS);
}
