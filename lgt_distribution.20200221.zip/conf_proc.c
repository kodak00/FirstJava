#include "conf_proc.h"

int conf_proc()
{
    char* conf_path = NULL;
    char* section = NULL;
    extern struct _app_conf* app_conf;

    app_conf = calloc(1, sizeof (struct _app_conf));
    if (app_conf == NULL)
    {
        return -1;
    }

    conf_path = app_conf->conf_path = CONF_PATH;
    section = "TEST";

    if (INI->setPSTRING(conf_path, section, "INPUT_LGT_KMA_PATH") == -1)
    {
        _strerror;
        exit(EXIT_FAILURE);
    }
    strncpy(buff, INI->getPSTRING(), sizeof (buff));
    input_path = malloc(PATH_MAX);
    strftime(input_path, sizeof (buff), buff, &tm_reqTime);


    
     if (!strcasecmp(fmode, "KMA"))
    {
        strftime(lgt_path, sizeof (lgt_path), LGT_KMA_READ_TXT, &curTime);
        strftime(output_dstr_day_path, sizeof (output_dstr_day_path), LGT_KMA_DSTR_DAY, &curTime);
        strftime(output_dstr_month_path, sizeof (output_dstr_month_path), LGT_KMA_DSTR_MONTH, &curTime);
        strftime(output_dstr_year_path, sizeof (output_dstr_year_path), LGT_KMA_DSTR_YEAR, &curTime);
    }
    else if (!strcasecmp(fmode, "KPX"))
    {
        strftime(lgt_path, sizeof (lgt_path), LGT_KPX_READ_TXT, &curTime);
        strftime(output_dstr_day_path, sizeof (output_dstr_day_path), LGT_KPX_DSTR_DAY, &curTime);
        strftime(output_dstr_month_path, sizeof (output_dstr_month_path), LGT_KPX_DSTR_MONTH, &curTime);
        strftime(output_dstr_year_path, sizeof (output_dstr_year_path), LGT_KPX_DSTR_YEAR, &curTime);
    }
    else if (!strcasecmp(fmode, "KAR"))
    {
        strftime(lgt_path, sizeof (lgt_path), LGT_KAR_READ_TXT, &curTime);
        strftime(output_dstr_day_path, sizeof (output_dstr_day_path), LGT_KAR_DSTR_DAY, &curTime);
        strftime(output_dstr_month_path, sizeof (output_dstr_month_path), LGT_KAR_DSTR_MONTH, &curTime);
        strftime(output_dstr_year_path, sizeof (output_dstr_year_path), LGT_KAR_DSTR_YEAR, &curTime);
    }
    
    return 0;
}
