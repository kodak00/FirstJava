
#include <stdio.h>
#include <unistd.h>
#include <libgen.h>
#include <string.h>

int ExtractFileName(char *pFullPath, char *pResult, char *pObsType)
{
	char *ptr;

	if( !pFullPath || !pResult )
		return 0;
	
	ptr = strrchr(pFullPath, '\\');
	if( !ptr )
		ptr = strrchr(pFullPath, '/');
	
	if( ptr )
		strcpy(pResult, ptr+1);
	else
		strcpy(pResult, pFullPath);

	return 1;
}

// argv[1] = /DATA/INPUT/UFL/201709/27/RDR_BRI_LNG_201709270525.uf
int main(int argc, char *argv[])
{
	char szExe[1024] = "/rdr/src/radar/lgt_distribution/bin/lgt_dist_kma";
	char szFile[100] = {0,};
	char szSite[20] = {0,};
	char szDate[20] = {0,};
	char szType[5] = {0,};
    char szProp[5] = {0,};
    char sysCmd[365];
//   char *pszEnv[] = {  "LD_LIBRARY_PATH=/DATA/APPS_2018/MAKE_HSR_RAIN_V4.0_FULL/LIB/lib:$LD_LIBRARY_PATH", NULL};
	char *ptr1, *ptr2, *ptr=NULL, *base=NULL;
	char infname[1024] = {0,}, *seperate[10]={NULL,};
	int i, count=0;

	if( argc < 2 )
	{
		fprintf(stderr, "No input...\n");
		return 0;
	}

	fprintf(stderr, "App Start\n");

	fprintf(stderr, "Command: \n");
    for(i=0;  i < argc;  i++)
		fprintf(stderr, "%s\n", argv[i]);

    // 파일 이름 추출
    strcpy(infname, argv[1]);
    base = basename(infname);

    // Underbar( _ )를 기준으로 파일 이름 분리
    ptr = strtok(base, "_"); count=0;
    while (ptr != NULL)
    {
      seperate[count++] = ptr;
      ptr = strtok(NULL, "_");
    }

    // 지점명 및 날짜 추출
    strcpy(szSite, seperate[1]);
    strncpy(szDate, seperate[count-1], 12);

    
	
    fprintf(stderr, "sysCmd: %s %s", szExe, argv[1]);
    sprintf(sysCmd, "%s %s", szExe, argv[1]);
    system(sysCmd);
//	execl(szExe, szExe, szSite, szMode, szDate, NULL);
    //execle(szExe, szExe, szSite, szDate, argv[1], NULL, pszEnv);

	fprintf(stderr, "App End\n");
	return 0;

Fail:
	fprintf(stderr, "Fail.\n");
	return 0;
}
