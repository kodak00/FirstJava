/* ================================================================================ */
//
// 
// 
// 2016.09.09
//
// SnK
//
/* ================================================================================ */
// INCLUDE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gd.h>

#include "cgi_comp_value.h"
#include "cgi_cmm_color.h"
#include "cgi_comp_echo_disp.h"
#include "cgi_comp_extra_disp.h"
#include "cgi_cmm_wst_disp.h"
#include "parameter.h"
#include "main.h"
#include "disp_img.h"

/* ================================================================================ */
// FUNCTION

int fnCreateCompRealtimeImg(void)
{
#define COMP_RT_FREE() \
    free(pColor_ini); \
    gdImageDestroy(pImg);

    gdImagePtr      pImg                                 = NULL;     
    int             nTransparent                         = 0;        
    int             echoColorBar[CGI_DF_COLOR_MAX]       = { 0, };   
    int             dispColorBar[CGI_EN_DISP_COLOR_MAX]  = { 0, };   
    CGI_COLOR_TBL*  pColor_ini                           = NULL;     

    pImg = gdImageCreateTrueColor(g_option.m_nImgXdim, g_option.m_nImgYdim);
    gdImageAlphaBlending(pImg, 0);
    gdImageSaveAlpha(pImg, 1);
    nTransparent  = gdTrueColorAlpha(255, 255, 255, 127);

    if(strcmp(g_option.m_szP_type, "ETOP") == 0)
    {
        pColor_ini = fnReadColorTable(CGI_DF_ETOP_COLOR_FILE);
    }
    else if(strcmp(g_option.m_szP_type, "VIL") == 0)
    {
        pColor_ini = fnReadColorTable(CGI_DF_VIL_COLOR_FILE);
    }
    else
    {
        if(strcmp(g_option.m_szUnit, "SN") == 0)
        {
            pColor_ini = fnReadColorTable(CGI_DF_SN_COLOR_FILE);     
        }
        else
        {
            pColor_ini = fnReadColorTable(CGI_DF_RN_COLOR_FILE);
        }
    }

    fnAllocColorTbl(pImg, pColor_ini, echoColorBar, dispColorBar);
    gdImageFilledRectangle(pImg, 0, 0, g_option.m_nImgXdim, g_option.m_nImgYdim, nTransparent);

    if(g_option.m_nEcho3d == 1)
    {
        if(fnComp3dEchoDisp(g_option.m_nImgXdim, g_option.m_nImgYdim, g_option.m_szP_type, g_option.m_szUnit, 
                    g_pImgData, pImg, echoColorBar, pColor_ini) < 0)
        {
            COMP_RT_FREE()
            return -1;
        }
    }
    else
    {
        if(fnCompEchoDisp(g_option.m_nImgXdim, g_option.m_nImgYdim, g_option.m_szP_type, g_option.m_szUnit, 
                    g_pImgData, pImg, echoColorBar, pColor_ini) < 0)
        {
            COMP_RT_FREE()
            return -1;
        }
    }
    
    if(fnBoundDisp(g_option.m_nImgXdim, g_option.m_nImgYdim, g_pImgData, pImg, BOUND_VALUE_F) < 0 )
    {
        COMP_RT_FREE()
        return -1;
    }

    if(g_option.m_nWst == 1)
    {
        if(fnCompWstDisp(g_option.m_fLU_lon, g_option.m_fLU_lat, g_option.m_szDate, g_option.m_nImgXdim, 
                    g_option.m_nImgYdim, g_option.m_fXDist, g_option.m_fYDist, pImg) < 0)
        {
            COMP_RT_FREE()
            return -1;
        }
    }
  
    if(fnImgTopTextDisp(pImg, "", "", g_option.m_szUnit, g_option.m_szDate, g_option.m_nImgXdim, 0, "") < 0)
    {
        COMP_RT_FREE()
        return -1;
    } 
    
    fprintf(stdout, "Content-type: image/png\r\n\r\n");
    gdImagePng(pImg, stdout);
    fflush(stdout);

    COMP_RT_FREE()

    return 0;
}

/* ================================================================================ */



