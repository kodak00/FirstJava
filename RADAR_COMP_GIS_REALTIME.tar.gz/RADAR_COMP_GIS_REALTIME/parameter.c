/* ================================================================================ */
//
// 레이더 에코 영상 GIS - parameter.c (파라미터 분리)
//
// 2016.07.29
//
// SnK
//
/* ================================================================================ */
// INCLUDE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "cgi_cmm_util.h"
#include "parameter.h"
#include "main.h"

char *strptime(const char *s, const char *format, struct tm *tm);
/* ================================================================================ */
// FUNCTION

int fnParamSet(void)
{
    char*       szQueryString           = NULL;   
    char*       szEqualPos              = NULL;   
    char*       szToken                 = NULL;   
    char        szTemp[PARAM_MAX_STR]   = "";     
    char        szTimes[PARAM_MAX_STR]  = "";     
    struct tm   stTime;                           

    memset(&stTime, 0x00, sizeof(struct tm));

    if((szQueryString = getenv("QUERY_STRING")) == NULL)
    {
        return -1;
    }

    snprintf(szTemp, sizeof(szTemp), "%s", szQueryString);

    szToken = strtok(szTemp, "&");

    while(szToken != NULL)
    {
        szEqualPos = strstr(szToken, "=");

        if(strncmp(szToken, "LU_LAT", strlen("LU_LAT")) == 0)
        {
            g_option.m_fLU_lat = atof(szEqualPos+1);
        }
        else if(strncmp(szToken, "LU_LON", strlen("LU_LON")) == 0)
        {
            g_option.m_fLU_lon = atof(szEqualPos+1);
        }
        else if(strncmp(szToken, "RL_LAT", strlen("RL_LAT")) == 0)
        {
            g_option.m_fRL_lat = atof(szEqualPos+1);
        }
        else if(strncmp(szToken, "RL_LON", strlen("RL_LON")) == 0)
        {
            g_option.m_fRL_lon = atof(szEqualPos+1);
        }
        else if(strncmp(szToken, "IMG_XDIM", strlen("IMG_XDIM")) == 0)
        {
            g_option.m_nImgXdim = atoi(szEqualPos+1);
        }
        else if(strncmp(szToken, "IMG_YDIM", strlen("IMG_YDIM")) == 0)
        {
            g_option.m_nImgYdim = atoi(szEqualPos+1);
        }
        else if(strncmp(szToken, "X_DIST", strlen("X_DIST")) == 0)
        {
            g_option.m_fXDist = atof(szEqualPos+1);
        }
        else if(strncmp(szToken, "Y_DIST", strlen("Y_DIST")) == 0)
        {
            g_option.m_fYDist = atof(szEqualPos+1);
        } 
        else if(strncmp(szToken, "DATE", strlen("DATE")) == 0)
        {
            strcpy(szTimes, szEqualPos+1);
            strptime(szTimes, "%Y%m%d%H%M", &stTime);
            strftime(g_option.m_szDate, sizeof(g_option.m_szDate), "%Y%m%d%H%M", &stTime);
        }
        else if(strncmp(szToken, "D_TYPE", strlen("D_TYPE")) == 0)
        {
            sprintf(g_option.m_szUnit, "%s", szEqualPos+1);
        }
        else if(strncmp(szToken, "IS_SMOOTH", strlen("IS_SMOOTH")) == 0)
        {
            g_option.m_nSmooth = atoi(szEqualPos+1);
        }
        else if(strncmp(szToken, "ECHO_3D", strlen("ECHO_3D")) == 0)
        {
            g_option.m_nEcho3d = atoi(szEqualPos+1);
        }
        else if(strncmp(szToken, "WST_DISP", strlen("WST_DISP")) == 0)
        {
            g_option.m_nWst = atoi(szEqualPos+1);
        }
        else if(strncmp(szToken, "UNIT_BAR", strlen("UNIT_BAR")) == 0)
        {
            g_option.m_nUnitBar = atoi(szEqualPos+1);
        }
        else if(strncmp(szToken, "POINT_RAIN", strlen("POINT_RAIN")) == 0)
        {
            g_option.m_nPointRain = atoi(szEqualPos+1);
        }
        else if(strncmp(szToken, "POINT_LON", strlen("POINT_LON")) == 0)
        {
            g_option.m_fPointLon = atof(szEqualPos+1);
        } 
        else if(strncmp(szToken, "POINT_LAT", strlen("POINT_LAT")) == 0)
        {
            g_option.m_fPointLat = atof(szEqualPos+1);
        }
        else if(strncmp(szToken, "WFLAG", strlen("WFLAG")) == 0)
        {
            g_option.m_nW_Flag = atoi(szEqualPos+1);
        }
        else if(strncmp(szToken, "NDATE", strlen("NDATE")) == 0)
        {
            g_option.m_lN_Date = atol(szEqualPos+1);
        } 
        
        szToken = strtok(NULL, "&");
    }
    
    g_option.m_szP_type      = PTYPE_DEFAULT;
    g_option.m_szQ_type      = QTYPE_DEFAULT;
    g_option.m_szC_method    = COMP_METHOD_DEFAULT;
    if(strcmp(g_option.m_szC_method, "MAX") == 0)
    {
        g_option.m_szComp_method = 'M';
    }
    else if(strcmp(g_option.m_szC_method, "MIN") == 0)
    {
        g_option.m_szComp_method = 'I';
    }
    else if(strcmp(g_option.m_szC_method, "AVG") == 0)
    {
        g_option.m_szComp_method = 'A';
    }
    else if(strcmp(g_option.m_szC_method, "WGT") == 0)
    {
        g_option.m_szComp_method = 'W';
    }
    else if(strcmp(g_option.m_szC_method, "QUY") == 0)
    {
        g_option.m_szComp_method = 'Q';
    } 

    return 0;
}

int fnFileFormatName(char *HDF5_FILE_FORMAT_NAME, char *BIN_FILE_FORMAT_NAME)
{
    struct tm   stTime;
    int         nXIdx                = 0;
    int         nFileTypeFlag        = 0;

    memset(&stTime,    0x00, sizeof(struct tm));

    strptime(g_option.m_szDate, "%Y%m%d%H%M", &stTime);
    
    for(nXIdx = 0; nXIdx < 360; nXIdx++)
    {
        // HDF5
        strftime(g_option.m_szF_name, sizeof(g_option.m_szF_name), HDF5_FILE_FORMAT_NAME, &stTime);

        if(!access(g_option.m_szF_name, 0))
        {
            nFileTypeFlag = 1;
            break;
        }
        

        // KMA
        strftime(g_option.m_szF_name, sizeof(g_option.m_szF_name), BIN_FILE_FORMAT_NAME, &stTime);

        if(!access(g_option.m_szF_name, 0))
        {
            nFileTypeFlag = 2;
            break;
        }

        stTime= fnGetIncMin(stTime, -1);
    }  

    strftime(g_option.m_szDate, sizeof(g_option.m_szDate), "%Y%m%d%H%M", &stTime);

    return nFileTypeFlag; 
}

/* ================================================================================ */



