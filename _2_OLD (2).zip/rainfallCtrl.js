﻿$(function() {	
	$("input:radio[name=siteMenu]").change(function(){
		var siteMenu = $("input:radio[name=siteMenu]:checked").val();
		if(siteMenu == 2) $("#selectSite").val("GRS");
		else if(siteMenu == 5) $("#selectSite").val("KAN");
		else if(siteMenu == 3) $("#selectSite").val("KAR");
		else if(siteMenu == 4) $("#selectSite").val("RKJK");
		else $("#selectSite").val("GNG");
		onChangeSiteCgi();
	});
	
	onChangeSiteCgi();	
	/*
	//등치선
	$(document).on("click","[name^=contour_disp]", function(){
		dispColorIndex($(this), "contour_disp");
	});
	
	//예측가이던스
	$(document).on("click","[name^=fore_guide]", function(){
		dispColorIndex($(this), "fore_guide");
	});
	
	//위험기상정보
	$(document).on("click","[name^=titan_disp]", function(){
		dispColorIndex($(this), "titan_disp");
	});
	*/
});

function getSiteOpt(){	
	var site = $("#selectSite").val();
	var prod = $("#selectProd").val();
	var current = "";
	var siteMenu = $("input:radio[name=siteMenu]:checked").val();
	var dateTime = $("#dateTime").val();
	var fileChk = $("#fileChk").val();
	var url;
	if( fileChk  == "success") url ="/comp/getSiteOptSuccessAjax.do";
	else url = "/comp/getSiteOptFailAjax.do";
	
	$.ajax({
		url : url,
		type : "post",
		data : {
			dateTime : dateTime,
			site : site,
			prod : prod
		},
		success: function(data){
			var selectSiteVal = $("#selectSite").val();
			var temp = "<li>[지점]</li>";	//oskim 20180713 , 사이트 명칭 변경
			for(var i=0;i<data.obsStationList.length;i++){
				if(data.obsStationList[i].siteSort == siteMenu){
					if(data.obsStationList[i].siteVal == selectSiteVal){
						    current ="current";
					}else{
							current ="";
					}
					temp += "<li><a href='#' class='"+current+"' name='' id='"+data.obsStationList[i].siteVal;
					temp += "' onclick='selectSiteType(&quot;"+data.obsStationList[i].siteVal+"&quot;); return false;'>"+data.obsStationList[i].siteName+"</a></li>";
				}
			}
			$("#siteType").html(temp);
			
			var selectDataVal = $("#selectData").val();
			if(data.siteOptList.length != 0){
				var dataTypeList = data.siteOptList[0].siteDType;
				var temp2 = "<li>[자료표출]</li>";
				for(var i=0;i<dataTypeList.length;i++){
					if(dataTypeList[i] == selectDataVal) current ="current";
					else current ="";
					
					temp2 += "<li><a href='#' class='"+current+"' onclick='selectDataType(&quot;"+dataTypeList[i]+"&quot;); return false;'>";
					if(dataTypeList[i] == "RN") dataTypeList[i] ="강수";
					if(dataTypeList[i] == "SN") dataTypeList[i] ="강설";
					temp2 += dataTypeList[i]+"</a></li>"; 
				}
				$("#dataType").html(temp2);
				
				var selectElevVal = $("#selectElev").val();
				var temp3 = "";
				if(prod == "CAPPI") temp3 = "<li>[km]</li>";
				else  				temp3 = "<li>[deg]</li>";
				for(var i=0;i<data.siteOptList[0].siteElev.length;i++){
					var elev = Math.round(data.siteOptList[0].siteElev[i]*100)/100;
					if(prod == "CAPPI"){	
						if(elev == selectElevVal)	current ="current";
						else						current ="";
						elevTypeVal = elev;
					}else{
						if(i == selectElevVal)	current ="current";
						else					current ="";
						elevTypeVal = i;
					}
				
					temp3 += "<li><a href='#' class='"+current+"' onclick='selectElevType(&quot;"+elevTypeVal+"&quot;); return false;'>"+elev.toFixed(2);+"</a></li>";
				}
				$("#elevType").html(temp3);
			}
			
			var temp4 = "<li>[산출물]</li>";
			for(var i=0;i<data.prodType.length;i++){
				if(prod == data.prodType[i]) current = "current";
				else current = "";
				temp4 +="<li><a href='#' class='"+current+"' onclick='selectProdType(&quot;"+data.prodType[i]+"&quot;); return false;'>"+(data.prodType[i]=='ATOM7' ? '대기수상체' : data.prodType[i])+"</a>&nbsp;</li>";
			}
			$("#prodType").html(temp4);
				
			/*
			if($("#siteType").find(".current").length == 0){
				$("#siteType").find("a").eq(0).trigger("click");
			}
			*/
			
		}
	});
}

function selectSiteType(siteType){
	$("#selectSite").val(siteType);
	$("#selectData").val("RN");
	selectProdChk();
	onChangeSiteCgi();
}

function selectDataType(dataType){
	$("#selectData").val(dataType);
	onChangeSiteCgi();
}

function selectElevType(elevType){
	$("#selectElev").val(elevType);
	onChangeSiteCgi();
}

function selectProdType(prodType){
	$("#selectProd").val(prodType);
	if(prodType == 'ATOM7') {
		$("#dataType").hide();
		$("#dataTypeAtom7").show();
	} else {
		$("#dataType").show();
		$("#dataTypeAtom7").hide();
	}
	selectProdChk();
	onChangeSiteCgi();
}

function selectProdChk(){
	var selectProd = $("#selectProd").val();
	if(selectProd == "CAPPI") $("#selectElev").val("1"); 
	else 					$("#selectElev").val("0");
}

function onChangeSiteCgi(){
	var selectSite = $("#selectSite").val();
	var selectData = $("#selectData").val();
	var selectElev = $("#selectElev").val();
	var selectProd = $("#selectProd").val();
	var selectDate = getDataConversion($("#dateTime").val());

	var url = "http://172.20.134.222:80/cgi-bin" ;//20181120 khr test	//로컬 PC
	//var url = "/cgi-bin";   //oskim 20181123	//운영 서버
	url +="/radar_site_map?";
	url +="DATE="+selectDate;
	url +="&P_TYPE="+selectProd;
	url +="&SITE_NAME="+selectSite;
	url +="&D_TYPE="+selectData;
	if(selectProd == "PPI") url +="&SWEEP_NO="+selectElev; 
	else url +="&CAPPI_ALT="+selectElev;

	var cgiUrl = url.replace("radar_site_map", "site_map_info");

	$.ajax({
		url : cgiUrl,
		type : "post",
		success: function(data){
			var res = data.trim();
			$("#siteSide").attr("src", url);
			$("#fileChk").val(res);
			getSiteOpt();
		}
	});
}

function loadSiteCgi(lat,lon){
	var selectDate = getDataConversion($("#dateTime").val());
	$.ajax({
		url : "/comp/loadSiteCgi.do",
		type : "POST",
		dataType : "json",
		data : {
			clcLat : lat,
			clcLon : lon,
			selectDate : selectDate
		},
		success : function(data){
			$("input:radio[name='siteMenu']:input[value='"+data.usCmmnVO[0].siteSort+"']").prop("checked", true);
			$("#selectSite").val(data.usCmmnVO[0].siteVal);
			
			$("#"+data.usCmmnVO[0].siteVal).trigger("click");
			//selectSiteType(data.usCmmnVO[0].siteVal);

			//$("#siteSide").attr("src",data.siteInfo);
		},
		error : function(){}
	}); 
}

