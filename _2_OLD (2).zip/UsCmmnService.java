package kres.us.cmmn.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonArray;

import kres.ad.menu.service.AdMenuMngVO;
import kres.ad.option.service.AdOptionVO;
import kres.us.comp.service.UsCompRightVO;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/**
 *  @Class Name : UsCmmnService.java
 *  @Project Name : KRES
 *  @Modification Information
 *  @
 *  @  수정일             수정자               수정내용
 *  @ ------------     -------------     ---------------------------
 *  @ 2016. 9. 21.          류중규      
 *
 *  @author safeKorea(류중규)
 *  @since 2016. 9. 21.
 *  @see UsCmmnService
 *  @Description : 
 *
 */
public interface UsCmmnService {
	
	//시군구 리스트 조회
	public Map<String, Object> selectSidoList(Map<String, Object> map) throws Exception;
	
	/**
	 * @Method Name : selectMenuList
	 * @date,  2016. 7. 6.
	 * @author 이현기
	 * @description 
	 *
	 * @return
	 * @throws Exception List<AdMenuMngVO>
	 */
	public List<AdMenuMngVO> selectMenuList(HashMap<String, Object> param) throws Exception;
	
	
	public List<UsCompRightVO> selectSiteSortList() throws Exception;
	
	
	/**
	 * @Method Name : selectMenuTreeList
	 * @date,  2016. 8. 8.
	 * @author 이현기
	 * @description 
	 *
	 * @return
	 * @throws Exception List<AdMenuMngVO>
	 */
	public List<AdMenuMngVO> selectMenuTreeList() throws Exception;
	
	public List<AdOptionVO> getOptionList(String url) throws Exception;

	/**
	 * @Method Name : getAllOptionList
	 * @date,  2016. 8. 8.
	 * @author 이현기
	 * @description 
	 *
	 * @return
	 * @throws Exception List<AdOptionVO>
	 */
	public List<AdOptionVO> getAllOptionList() throws Exception;

	/**
	 * @Method Name : getOptionMenuCount
	 * @date,  2016. 8. 8.
	 * @author 이현기
	 * @description 
	 *
	 * @return
	 * @throws Exception int
	 */
	public int getOptionMenuCount() throws Exception;
	
	/**
	 * @Method Name : selectObsStation
	 * @date,  2016. 8. 12.
	 * @author 이성규
	 * @description 
	 *
	 * @return
	 * @throws Exception List<UsCmmnVO>
	 */
	public List<UsCompRightVO> selectObsStation(HashMap<String, Object> map) throws Exception;
	
	/**
	 * @Method Name : getOptionListByCno
	 * @date,  2016. 9. 2.
	 * @author 강혜리
	 * @description 
	 *
	 * @param cno
	 * @return
	 * @throws Exception List<AdOptionVO>
	 */
	public List<AdOptionVO> getOptionListByCno(String cno) throws Exception;
	
	
	/**
	 * @Method Name : selectMenuListByNm
	 * @date,  2016. 9. 4.
	 * @author 강혜리
	 * @description 
	 *
	 * @param cno
	 * @return
	 * @throws Exception List<AdOptionVO>
	 */
	public List<AdOptionVO> getOptionListByNm(String cno) throws Exception;
	
	
	public Map<String, Object> selectAWSBranchList(UsCmmnVO usCmmnVO, PaginationInfo paginationInfo) throws Exception;
	
	/**
	 * @Method Name : selectAWSPoint
	 * @date,  2016. 9. 29.
	 * @author 이현기
	 * @description 
	 *
	 * @param usCmmnVO
	 * @return
	 * @throws Exception List<UsCmmnVO>
	 */
	public List<UsCmmnVO> selectAWSPoint(UsCmmnVO usCmmnVO) throws Exception;

	/**
	 * @Method Name : selectSitetimeToObsStation
	 * @date,  2017.10.10.
	 * @author 한선묵
	 * @description 
	 *  사이트의 관측주기 조회
	 * @return int
	 */
	public int selectSitetimeToObsStation(HashMap<String, Object> paramSite);
	
	/**
	 * @Method Name : selectTyphoonList
	 * @date,  20190804
	 * @author 김언식
	 * @description 
	 *  태풍목록
	 * @return Map<String, Object>
	 */
	public Map<String, Object> selectTyphoonList(UsTyphoonListVO usTyphoonListVO, PaginationInfo paginationInfo) throws Exception;	
	public JsonArray getTyphoonRouteJSON(String typhoonName) throws Exception;
	public JsonArray getTyphoonListJSON() throws Exception;
}
