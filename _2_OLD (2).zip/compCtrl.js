﻿$(function() {
	$("input:radio[name=siteMenu]").change(function(){
		var siteMenu = $("input:radio[name=siteMenu]:checked").val();
		//oskim 20190110 ,
		if(siteMenu == 2) $("#selectSite").val("GRS");		//환경부
		else if(siteMenu == 5) $("#selectSite").val("KAR");	//항우연
		else if(siteMenu == 3) $("#selectSite").val("RKSG");//미공군
		else if(siteMenu == 4) $("#selectSite").val("SWN");//공군
		else $("#selectSite").val("GNG");
		onChangeSiteCgi();
	});
	
	//메인페이지가 합성인경우 우측하단 사이트 관련 옵션 호출
	if(hrefArrayVal == "comp" || hrefArrayVal == "") onChangeSiteCgi();	
	
	//낙뢰 메뉴 선택
	/*
	 * 문숫자선택->낙뢰메뉴선택
	 * 산출물이 문숫자 일 경우, 낙뢰의 첫번째 산출물이 선택되도록 처리
	 * (문숫자는 팝업이므로 top메뉴 해제해야함) 
	 * 
	 * -> 메뉴 순서가 변경될시 변경필요
	 * */
//	$("#top3").click(function(){
//		$(this).closest("tr").find("[name^=P_TYPE]").each(function(){
//			if($(this).prop("checked")){
//				if($(this).val() == "LGT_AWS"){
//					var name = $(this).attr("name");
//					$("[name="+ name +"]").eq(0).trigger("click");
//				}
//			}
//
//		});
//	});
	
	//문숫자 선택
	$("input:radio[name^=P_TYPE]").click(function(){
		var winWidth = 860;
		var winHeight = 645;
		if($(this).val() == "SITE_DEP3_VAD"){
		    winWidth = 1320;
		    winHeight = 750;
        }
		var LeftPosition = (screen.width - winWidth)/2;
		var TopPosition = (screen.height - winHeight) / 2;
		
		if($(this).val() == "COMP_DEP2_LGT_AWS"){
			/*
			 * 낙뢰 문숫자 산출물 선택시 
			 * 낙뢰 top 메뉴 체크해제 하기위해 
			 * 	-> 메뉴 순서가 변경될시 변경해줘야됨  
			 * */
			if($("#top3").prop("checked")){
//				$("#top3").prop("checked", false);
				echoLoad(getDataConversion()); //////
			}
			///////////////////////////////////////
			var popup = window.open("", 'onPopAws', 'scrollbars=yes,width=' + winWidth
					+ ',height=' + winHeight + ',left=' + LeftPosition
					+ ',top=' + TopPosition
					+ ',menubar=no,status=no,resizable=yes,location=no');
			popup.focus();
			
			$("#lgtAWSForm input[name=dateForm]").val(getDataConversion($("#dateTime").val()));	//oskim 20180108, (적용)
			$("#lgtAWSForm").attr({action:"/lgt/getLgtAws.do" , target:"onPopAws"}).submit();
				
		}
		//oskim 20190712
		if($(this).val() == "COMP_DEP3_QVP"){

			var popup = window.open("http://rdr.kma.go.kr/rdr/rdr_qvp.php",
									'QVP',
									'scrollbars=yes,width=' + 1032	+ ',height=' + 763 + ',left=' + LeftPosition	+ ',top=' + TopPosition	+ ',menubar=no,status=no,resizable=yes,location=no');
			popup.focus();
			
		}
		
	});
});


function getSiteOpt(){
	var site = $("#selectSite").val();
	var prod = $("#selectProd").val();
	var current = "";
	var siteMenu = $("input:radio[name=siteMenu]:checked").val();
	var dateTime = $("#dateTime").val();
	var fileChk = $("#fileChk").val();
	var url;
	if( fileChk  == "success") url ="/comp/getSiteOptSuccessAjax.do";
	else url = "/comp/getSiteOptFailAjax.do";
	
	$.ajax({
		url : url,
		type : "post",
		data : {
			dateTime : dateTime,
			site : site,
			prod : prod,
		},
		success: function(data){
			var selectSiteVal = $("#selectSite").val();
			var temp = "<li>[지점]</li>";	//oskim 20180713 , 사이트 명칭 변경
			for(var i=0;i<data.obsStationList.length;i++){
				if(data.obsStationList[i].siteSort == siteMenu){
					if(data.obsStationList[i].siteVal == selectSiteVal) current ="current";
					else current ="";
					
					temp += "<li><a href='#' class='"+current+"' name='' id='"+data.obsStationList[i].siteVal;
					temp += "' onclick='selectSiteType(&quot;"+data.obsStationList[i].siteVal+"&quot;); return false;'>"+data.obsStationList[i].siteName+"</a></li>";
				}
			}
			$("#siteType").html(temp);
			
			var selectDataVal = $("#selectData").val();
			if(data.siteOptList.length != 0){
				var dataTypeList = data.siteOptList[0].siteDType;
				var temp2 = "<li>[자료표출]</li>";
				for(var i=0;i<dataTypeList.length;i++){
					if(dataTypeList[i] == selectDataVal) current ="current";
					else current ="";
					
					temp2 += "<li><a href='#' class='"+current+"' onclick='selectDataType(&quot;"+dataTypeList[i]+"&quot;); return false;'>";
					if(dataTypeList[i] == "RN") dataTypeList[i] ="강수";
					if(dataTypeList[i] == "SN") dataTypeList[i] ="강설";
					temp2 += dataTypeList[i]+"</a></li>"; 
				}
				$("#dataType").html(temp2);
				
				var selectElevVal = $("#selectElev").val();
				var temp3 = "";
				if(prod == "CAPPI") temp3 = "<li>[km]</li>";
				else  				temp3 = "<li>[deg]</li>";
				for(var i=0;i<data.siteOptList[0].siteElev.length;i++){
					var elev = Math.round(data.siteOptList[0].siteElev[i]*100)/100;
					if(prod == "CAPPI"){	
						if(elev == selectElevVal)	current ="current";
						else						current ="";
						elevTypeVal = elev;
					}else{
						if(i == selectElevVal)	current ="current";
						else					current ="";
						elevTypeVal = i;
					}
					
					temp3 += "<li><a href='#' class='"+current+"' onclick='selectElevType(&quot;"+elevTypeVal+"&quot;); return false;'>"+elev.toFixed(2);+"</a></li>";
				}
				$("#elevType").html(temp3);
			}
			
			var temp4 = "<li>[산출물]</li>";
			for(var i=0;i<data.prodType.length;i++){
				if(prod == data.prodType[i]) current = "current";
				else current = "";
				temp4 +="<li><a href='#' class='"+current+"' onclick='selectProdType(&quot;"+data.prodType[i]+"&quot;); return false;'>"+(data.prodType[i]=='ATOM7' ? '대기수상체' : data.prodType[i])+"</a>&nbsp;</li>";
			}
			$("#prodType").html(temp4);
			/*
			if($("#siteType").find(".current").length == 0){
				$("#siteType").find("a").eq(0).trigger("click");
			}
			*/
		}
	});
}

function selectSiteType(siteType){
	$("#selectSite").val(siteType);
	$("#selectData").val("RN");
	selectProdChk();
	onChangeSiteCgi();
}

function selectDataType(dataType){
	$("#selectData").val(dataType);
	onChangeSiteCgi();
}

function selectElevType(elevType){
	$("#selectElev").val(elevType);
	onChangeSiteCgi();
}

function selectProdType(prodType){
	$("#selectProd").val(prodType);
	if(prodType == 'ATOM7') {
		$("#dataType").hide();
		$("#dataTypeAtom7").show();
	} else {
		$("#dataType").show();
		$("#dataTypeAtom7").hide();
	}
	selectProdChk();
	onChangeSiteCgi();
}

function selectProdChk(){
	var selectProd = $("#selectProd").val();
	if(selectProd == "CAPPI") $("#selectElev").val("1"); 
	else 					$("#selectElev").val("0");
}


function onChangeSiteCgi(){
	var selectSite = $("#selectSite").val();
	var selectData = $("#selectData").val();
	var selectElev = $("#selectElev").val();
	var selectProd = $("#selectProd").val();
	var selectDate = getDataConversion($("#dateTime").val());

	var url = "http://172.20.134.222:80/cgi-bin" ;	//로컬 PC
	//var url = "/cgi-bin";		//운영 서버
	url +="/radar_site_map?";
	url +="DATE="+selectDate;
	url +="&P_TYPE="+selectProd;
	url +="&SITE_NAME="+selectSite;
	url +="&D_TYPE="+selectData;
	if(selectProd == "PPI" || selectProd == "ATOM7") url +="&SWEEP_NO="+selectElev; 
	else url +="&CAPPI_ALT="+selectElev;

	var cgiUrl = url.replace("radar_site_map", "site_map_info");

	$.ajax({
		url : cgiUrl,
		type : "post",
		success: function(data){
			var res = data.trim();
			$("#siteSide").attr("src", url);
			$("#fileChk").val(res);
			getSiteOpt();
		}
	});
}

function loadSiteCgi(lat,lon){
	var selectDate = getDataConversion($("#dateTime").val());
	var selectData = $("#selectData").val();
	var selectElev = $("#selectElev").val();
	
	var site
	$.ajax({
		url : "/comp/loadSiteCgi.do",
		type : "POST",
		dataType : "json",
		data : {
			clcLat : lat,
			clcLon : lon,
			selectDate : selectDate,
			selectData : selectData,
			selectElev : selectElev
		},
		success : function(data){
			$("input:radio[name='siteMenu']:input[value='"+data.usCmmnVO[0].siteSort+"']").prop("checked", true);
			$("#selectSite").val(data.usCmmnVO[0].siteVal);
			
			$("#"+data.usCmmnVO[0].siteVal).trigger("click");
			//selectSiteType(data.usCmmnVO[0].siteVal);

			//$("#siteSide").attr("src",data.siteInfo);
		},
		error : function(){}
	}); 
}


function popBranch(){
	var winWidth = 507;
	var winHeight = 473;
	var LeftPosition = (screen.width - winWidth)/2;
	var TopPosition = (screen.height - winHeight) / 2;
	var url ='/lgt/popBranch.do';
	var popup = window.open(url, 'onAreaPop', 'scrollbars=yes,width=' + winWidth
						+ ',height=' + winHeight + ',left=' + LeftPosition
						+ ',top=' + TopPosition
						+ ',menubar=no,status=no,resizable=yes,location=no');
	popup.focus();
}



//낙뢰 도로명 주소 팝업 호출
function popAdress(){
	var winWidth = 507;
	var winHeight = 600;
	var LeftPosition = (screen.width - winWidth)/2;
	var TopPosition = (screen.height - winHeight) / 2;
	var url ='/lgt/popAdress.do';
	var popup = window.open(url, 'onAdressPop', 'scrollbars=yes,width=' + winWidth
						+ ',height=' + winHeight + ',left=' + LeftPosition
						+ ',top=' + TopPosition
						+ ',menubar=no,status=no,resizable=yes,location=no');
	popup.focus();
}

//oskim 20190728
function set_drawing_typhoon_routes(multipoints){
	drawing_typhoon_routes(multipoints);
}

//태풍경로 입력 , oskim 20190804
function popTyphoonRoute(){
	var winWidth = 800;
	var winHeight = 600;
	var LeftPosition = (screen.width - winWidth)/2;
	var TopPosition = (screen.height - winHeight) / 2;
	var url ='/cmmn/popTyphoonRoute.do';
	var popup = window.open(url, 'onTyphoonRoutePop', 'scrollbars=yes,width=' + winWidth
						+ ',height=' + winHeight + ',left=' + LeftPosition
						+ ',top=' + TopPosition
						+ ',menubar=no,status=no,resizable=yes,location=no');
	popup.focus();
}

//태풍목록
function popTyphoonList(){
	var winWidth = 800;
	var winHeight = 440;
	var LeftPosition = (screen.width - winWidth)/2;
	var TopPosition = (screen.height - winHeight) / 2;
	var url ='/cmmn/popTyphoonList.do';
	var popup = window.open(url, 'onTyphoonListPop', 'scrollbars=yes,width=' + winWidth
						+ ',height=' + winHeight + ',left=' + LeftPosition
						+ ',top=' + TopPosition
						+ ',menubar=no,status=no,resizable=yes,location=no');
	popup.focus();
}

function setChildDoro(lat,lon){
	 loadArea(lat,lon);
}

function setChildBranch(lat,lon) {
	$("#lgt_disp_lat3").html("위도 : " + lat);//
	$("#lgt_disp_lon3").html("경도 : " + lon);	//

	//관심지역 위경도 선택시 에코로드수행
	echoLoad(getDataConversion());
}



function loadArea(lat,lon){
	$.ajax({
		url : "/lgt/loadArea.do",
		type : "POST",
		dataType : "json",
		data : {
			lat : lat,
			lon : lon
		},
		success : function(data){	
		$("#lgt_disp_lat3").html("위도 : " + data.resultList[0].grid_LAT);//
		$("#lgt_disp_lon3").html("경도 : " + data.resultList[0].grid_LON);	//
		/*
		window.GISMap.swf.r( 'Map', 'MapObjectSpace', 'removeAllChildren_As', null );	
		
		window.GISMap.swf.r( 'Map', 'MapObjectSpace', 'addGraphic_Diagram_Circle', {
	            kGroup : 'Diagram'
	            , kName : 'Circle'
	            , radius : rad_val
	            , coordX : data.resultList[0].grid_LON
	            , coordY : data.resultList[0].grid_LAT
	            , bCoordinates : true
	            , srsCode : 'EPSG:4326'
	            , style : { kLine : '2|0x0000ff|1', kFill : '0xffff00|0.3' }
	    } );
	    */
		//도로명주소 위도경도 입력후 에코로드 수행
		echoLoad(getDataConversion());
	},
		error : function(){}
	});
	
}


