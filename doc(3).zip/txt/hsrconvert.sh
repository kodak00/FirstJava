#!/bin/sh

YMD=$1
YYMM=`echo $YMD|cut -c1-6`
DD=`echo $YMD|cut -c7-8`

echo "YMD = ${YMD}"
echo "YYMM = ${YYMM}"
echo "DD = ${DD}"

site_name=("BRI" "KWK" "KSN" "GDK" "JNI" "MYN" "GSN" "SSP" "GNG" "SBS" "BSL" "MHS" "GRS" "SDS" "YIT")

PROJECT_PATH=/DATA/APPS_2018/bin/shsr_dst_full

file_cnt=$(ls -Rl /DATA/INPUT/UFV/${YYMM}/${DD}/RDR_???_${YMD}*.uf | grep ^- | wc -l)
    for LIST in `ls -tr /DATA/INPUT/UFV/${YYMM}/${DD}/RDR_???_${YMD}*.uf`
    do
				site=`echo $LIST|cut -c21-23`
				echo $site

				for value in "${site_name[@]}"; do
						#echo $value
						if [[ "$site" == "$value" ]]; then
								echo "./shsr_dst_full $LIST"
								#/DATA/APPS_2018/bin/shsr_dst_full $LIST
						fi
				done

       sleep 1
    done

echo "file_cnt = ${file_cnt}"
#done

/DATA/INPUT/UFV/201803/01/RDR_K01_201803011229.uf

/DATA/APPS_2018/MAKE_HSR_RAIN_V4.0_RE/DST_RUN/shsr_dst_full_re /DATA/INPUT/UFV/201803/01/RDR_GNG_201803010040.uf

SCN
KSN